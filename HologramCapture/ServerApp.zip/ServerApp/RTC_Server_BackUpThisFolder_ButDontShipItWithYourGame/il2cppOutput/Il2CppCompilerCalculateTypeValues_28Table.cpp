﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "il2cpp-class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"


// Byn.Awrtc.CallEventArgs
struct CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0;
// Byn.Awrtc.CallEventHandler
struct CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F;
// Byn.Awrtc.ErrorInfo
struct ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167;
// Byn.Awrtc.IFrame
struct IFrame_t2FE867CC6939ADD4973D8276E9AEFD826F88DF29;
// Byn.Awrtc.IMediaNetwork
struct IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780;
// Byn.Awrtc.MediaConfig
struct MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D;
// Byn.Awrtc.NetworkConfig
struct NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47;
// System.Action
struct Action_t591D2A86165F896B4B800BB5C25CE18672A55579;
// System.Action`1<System.Boolean>
struct Action_1_tAA0F894C98302D68F7D5034E8104E9AB4763CCAD;
// System.Action`1<System.String>
struct Action_1_t32A9EECF5D4397CC1B9A7C7079870875411B06D0;
// System.Action`1<UnityEngine.Camera>
struct Action_1_t6D83B4F361CDBC0D6B559F8DA3A9646E2ED9561C;
// System.Action`3<System.Boolean,System.Boolean,System.Int32>
struct Action_3_tEE1FB0623176AFA5109FAA9BA7E82293445CAE1E;
// System.AsyncCallback
struct AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4;
// System.Byte[]
struct ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821;
// System.Char[]
struct CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2;
// System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>
struct Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB;
// System.Collections.Generic.Dictionary`2<System.String,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>
struct Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2;
// System.Collections.Generic.List`1<Byn.Awrtc.ByteArrayBuffer>[]
struct List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592;
// System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>
struct List_1_tCB9967EC4C00221A410117D712FF423882EB5832;
// System.Collections.Generic.List`1<Byn.Awrtc.IceServer>
struct List_1_t071E9AF889461644CC5513065D8B09A62D4EE708;
// System.Collections.Generic.List`1<System.String>
struct List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3;
// System.Collections.Generic.List`1<UnityEngine.Yoga.YogaNode>
struct List_1_tC208E7A364FF0C3FDC57107BD002A16939F7EE92;
// System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent>
struct Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF;
// System.DelegateData
struct DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE;
// System.Delegate[]
struct DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86;
// System.IAsyncResult
struct IAsyncResult_t8E194308510B375B42432981AE5E7488C458D598;
// System.Int32[]
struct Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.String
struct String_t;
// System.Text.RegularExpressions.Regex
struct Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF;
// System.Void
struct Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017;
// UnityEngine.Analytics.AnalyticsSessionInfo/SessionStateChanged
struct SessionStateChanged_t9084549A636BD45086D66CC6765DA8C3DD31066F;
// UnityEngine.Canvas/WillRenderCanvases
struct WillRenderCanvases_tBD5AD090B5938021DEAA679A5AEEA790F60A8BEE;
// UnityEngine.Experimental.TerrainAPI.TerrainUtility/<CollectTerrains>c__AnonStorey1
struct U3CCollectTerrainsU3Ec__AnonStorey1_t41DA2A02D290EE5FEF14389A4391CBC1E3E622A5;
// UnityEngine.GameObject
struct GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F;
// UnityEngine.RemoteSettings/UpdatedEventHandler
struct UpdatedEventHandler_tB0230BC83686D7126AB4D3800A66351028CA514F;
// UnityEngine.Sprite
struct Sprite_tCA09498D612D08DE668653AF1E9C12BF53434198;
// UnityEngine.Sprite[]
struct SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7;
// UnityEngine.Terrain
struct Terrain_t0BF7371FA90643325F50A87C7894D7BEBBE08943;
// UnityEngine.Tilemaps.Tilemap
struct Tilemap_t0F92148668211805A631B93488D4A629EC378B10;
// UnityEngine.Vector3[]
struct Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28;
// UnityEngine.Video.VideoPlayer
struct VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2;
// UnityEngine.Video.VideoPlayer/ErrorEventHandler
struct ErrorEventHandler_tF5863946928B48BE13146ED5FF70AC92678FE222;
// UnityEngine.Video.VideoPlayer/EventHandler
struct EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308;
// UnityEngine.Video.VideoPlayer/FrameReadyEventHandler
struct FrameReadyEventHandler_t518B277D916AB292680CAA186BCDB3D3EF130422;
// UnityEngine.Video.VideoPlayer/TimeEventHandler
struct TimeEventHandler_tDD815DAABFADDD98C8993B2A97A2FCE858266BC1;
// UnityEngine.Yoga.BaselineFunction
struct BaselineFunction_t0A87479762FB382A84709009E9B6DCC597C6C9DF;
// UnityEngine.Yoga.MeasureFunction
struct MeasureFunction_tC5585E81380F4017044CE57AE21E178BAE2607AB;
// UnityEngine.Yoga.YogaNode
struct YogaNode_tFCB801A447DAC7A335C686ABC5941A4357102A2C;

struct Delegate_t_marshaled_com;
struct Delegate_t_marshaled_pinvoke;



#ifndef U3CMODULEU3E_TAF0352AF459FC6ADDA335387111E96B1480224D6_H
#define U3CMODULEU3E_TAF0352AF459FC6ADDA335387111E96B1480224D6_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_tAF0352AF459FC6ADDA335387111E96B1480224D6 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_TAF0352AF459FC6ADDA335387111E96B1480224D6_H
#ifndef U3CMODULEU3E_TCD4309F8DDA0F37A98DBCDFE49F6C8F300C242B0_H
#define U3CMODULEU3E_TCD4309F8DDA0F37A98DBCDFE49F6C8F300C242B0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_tCD4309F8DDA0F37A98DBCDFE49F6C8F300C242B0 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_TCD4309F8DDA0F37A98DBCDFE49F6C8F300C242B0_H
#ifndef U3CMODULEU3E_T2FBFFC67F8D6B1FA13284515F9BBD8C9333B5C86_H
#define U3CMODULEU3E_T2FBFFC67F8D6B1FA13284515F9BBD8C9333B5C86_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t2FBFFC67F8D6B1FA13284515F9BBD8C9333B5C86 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T2FBFFC67F8D6B1FA13284515F9BBD8C9333B5C86_H
#ifndef U3CMODULEU3E_T091C966E943CA3E1F5D551C43C6FE64881C5BB24_H
#define U3CMODULEU3E_T091C966E943CA3E1F5D551C43C6FE64881C5BB24_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t091C966E943CA3E1F5D551C43C6FE64881C5BB24 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T091C966E943CA3E1F5D551C43C6FE64881C5BB24_H
#ifndef U3CMODULEU3E_T5E9BCCF782B7911AFF113E864B4B636EFE0B6BF0_H
#define U3CMODULEU3E_T5E9BCCF782B7911AFF113E864B4B636EFE0B6BF0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t5E9BCCF782B7911AFF113E864B4B636EFE0B6BF0 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T5E9BCCF782B7911AFF113E864B4B636EFE0B6BF0_H
#ifndef U3CMODULEU3E_T79D7DE725655CFC1B063EA359E8D75692CF5DC2F_H
#define U3CMODULEU3E_T79D7DE725655CFC1B063EA359E8D75692CF5DC2F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t79D7DE725655CFC1B063EA359E8D75692CF5DC2F 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T79D7DE725655CFC1B063EA359E8D75692CF5DC2F_H
#ifndef U3CMODULEU3E_T064756C4EE8D64CEFE107E600CEBCB3F77894990_H
#define U3CMODULEU3E_T064756C4EE8D64CEFE107E600CEBCB3F77894990_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t064756C4EE8D64CEFE107E600CEBCB3F77894990 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T064756C4EE8D64CEFE107E600CEBCB3F77894990_H
#ifndef U3CMODULEU3E_TB054F17A779AC945E3659AF119A96DB806541AF9_H
#define U3CMODULEU3E_TB054F17A779AC945E3659AF119A96DB806541AF9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_tB054F17A779AC945E3659AF119A96DB806541AF9 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_TB054F17A779AC945E3659AF119A96DB806541AF9_H
#ifndef U3CMODULEU3E_T140A63E1069F1772D5238396CDA7CE5372253E44_H
#define U3CMODULEU3E_T140A63E1069F1772D5238396CDA7CE5372253E44_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t140A63E1069F1772D5238396CDA7CE5372253E44 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T140A63E1069F1772D5238396CDA7CE5372253E44_H
#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
#ifndef BYTEARRAYBUFFER_T39C5A4320D8C9053876A3C5A596EF95EB40E257B_H
#define BYTEARRAYBUFFER_T39C5A4320D8C9053876A3C5A596EF95EB40E257B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.ByteArrayBuffer
struct  ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B  : public RuntimeObject
{
public:
	// System.Byte[] Byn.Awrtc.ByteArrayBuffer::array
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___array_2;
	// System.Int32 Byn.Awrtc.ByteArrayBuffer::positionWrite
	int32_t ___positionWrite_3;
	// System.Int32 Byn.Awrtc.ByteArrayBuffer::positionRead
	int32_t ___positionRead_4;
	// System.Int32 Byn.Awrtc.ByteArrayBuffer::offset
	int32_t ___offset_5;
	// System.Boolean Byn.Awrtc.ByteArrayBuffer::mFromPool
	bool ___mFromPool_6;
	// System.Boolean Byn.Awrtc.ByteArrayBuffer::mDisposed
	bool ___mDisposed_7;

public:
	inline static int32_t get_offset_of_array_2() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B, ___array_2)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get_array_2() const { return ___array_2; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of_array_2() { return &___array_2; }
	inline void set_array_2(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		___array_2 = value;
		Il2CppCodeGenWriteBarrier((&___array_2), value);
	}

	inline static int32_t get_offset_of_positionWrite_3() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B, ___positionWrite_3)); }
	inline int32_t get_positionWrite_3() const { return ___positionWrite_3; }
	inline int32_t* get_address_of_positionWrite_3() { return &___positionWrite_3; }
	inline void set_positionWrite_3(int32_t value)
	{
		___positionWrite_3 = value;
	}

	inline static int32_t get_offset_of_positionRead_4() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B, ___positionRead_4)); }
	inline int32_t get_positionRead_4() const { return ___positionRead_4; }
	inline int32_t* get_address_of_positionRead_4() { return &___positionRead_4; }
	inline void set_positionRead_4(int32_t value)
	{
		___positionRead_4 = value;
	}

	inline static int32_t get_offset_of_offset_5() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B, ___offset_5)); }
	inline int32_t get_offset_5() const { return ___offset_5; }
	inline int32_t* get_address_of_offset_5() { return &___offset_5; }
	inline void set_offset_5(int32_t value)
	{
		___offset_5 = value;
	}

	inline static int32_t get_offset_of_mFromPool_6() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B, ___mFromPool_6)); }
	inline bool get_mFromPool_6() const { return ___mFromPool_6; }
	inline bool* get_address_of_mFromPool_6() { return &___mFromPool_6; }
	inline void set_mFromPool_6(bool value)
	{
		___mFromPool_6 = value;
	}

	inline static int32_t get_offset_of_mDisposed_7() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B, ___mDisposed_7)); }
	inline bool get_mDisposed_7() const { return ___mDisposed_7; }
	inline bool* get_address_of_mDisposed_7() { return &___mDisposed_7; }
	inline void set_mDisposed_7(bool value)
	{
		___mDisposed_7 = value;
	}
};

struct ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields
{
public:
	// System.Collections.Generic.List`1<Byn.Awrtc.ByteArrayBuffer>[] Byn.Awrtc.ByteArrayBuffer::sPool
	List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* ___sPool_0;
	// System.Boolean Byn.Awrtc.ByteArrayBuffer::LOG_GC_CALLS
	bool ___LOG_GC_CALLS_1;
	// System.Int32[] Byn.Awrtc.ByteArrayBuffer::MultiplyDeBruijnBitPosition
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___MultiplyDeBruijnBitPosition_8;

public:
	inline static int32_t get_offset_of_sPool_0() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields, ___sPool_0)); }
	inline List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* get_sPool_0() const { return ___sPool_0; }
	inline List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592** get_address_of_sPool_0() { return &___sPool_0; }
	inline void set_sPool_0(List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* value)
	{
		___sPool_0 = value;
		Il2CppCodeGenWriteBarrier((&___sPool_0), value);
	}

	inline static int32_t get_offset_of_LOG_GC_CALLS_1() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields, ___LOG_GC_CALLS_1)); }
	inline bool get_LOG_GC_CALLS_1() const { return ___LOG_GC_CALLS_1; }
	inline bool* get_address_of_LOG_GC_CALLS_1() { return &___LOG_GC_CALLS_1; }
	inline void set_LOG_GC_CALLS_1(bool value)
	{
		___LOG_GC_CALLS_1 = value;
	}

	inline static int32_t get_offset_of_MultiplyDeBruijnBitPosition_8() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields, ___MultiplyDeBruijnBitPosition_8)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_MultiplyDeBruijnBitPosition_8() const { return ___MultiplyDeBruijnBitPosition_8; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_MultiplyDeBruijnBitPosition_8() { return &___MultiplyDeBruijnBitPosition_8; }
	inline void set_MultiplyDeBruijnBitPosition_8(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___MultiplyDeBruijnBitPosition_8 = value;
		Il2CppCodeGenWriteBarrier((&___MultiplyDeBruijnBitPosition_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BYTEARRAYBUFFER_T39C5A4320D8C9053876A3C5A596EF95EB40E257B_H
#ifndef DEFAULTVALUES_TFB168B56BA06FD7096D0B3A6454AD6873A4104CA_H
#define DEFAULTVALUES_TFB168B56BA06FD7096D0B3A6454AD6873A4104CA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.DefaultValues
struct  DefaultValues_tFB168B56BA06FD7096D0B3A6454AD6873A4104CA  : public RuntimeObject
{
public:

public:
};

struct DefaultValues_tFB168B56BA06FD7096D0B3A6454AD6873A4104CA_StaticFields
{
public:
	// System.Boolean Byn.Awrtc.DefaultValues::sAuthenticateAsClientBugWorkaround
	bool ___sAuthenticateAsClientBugWorkaround_0;

public:
	inline static int32_t get_offset_of_sAuthenticateAsClientBugWorkaround_0() { return static_cast<int32_t>(offsetof(DefaultValues_tFB168B56BA06FD7096D0B3A6454AD6873A4104CA_StaticFields, ___sAuthenticateAsClientBugWorkaround_0)); }
	inline bool get_sAuthenticateAsClientBugWorkaround_0() const { return ___sAuthenticateAsClientBugWorkaround_0; }
	inline bool* get_address_of_sAuthenticateAsClientBugWorkaround_0() { return &___sAuthenticateAsClientBugWorkaround_0; }
	inline void set_sAuthenticateAsClientBugWorkaround_0(bool value)
	{
		___sAuthenticateAsClientBugWorkaround_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEFAULTVALUES_TFB168B56BA06FD7096D0B3A6454AD6873A4104CA_H
#ifndef ERRORINFO_T7BF4629517FDF63B912A4B6AE78C4B2BD9207167_H
#define ERRORINFO_T7BF4629517FDF63B912A4B6AE78C4B2BD9207167_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.ErrorInfo
struct  ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167  : public RuntimeObject
{
public:
	// System.String Byn.Awrtc.ErrorInfo::mErrorMessage
	String_t* ___mErrorMessage_10;

public:
	inline static int32_t get_offset_of_mErrorMessage_10() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167, ___mErrorMessage_10)); }
	inline String_t* get_mErrorMessage_10() const { return ___mErrorMessage_10; }
	inline String_t** get_address_of_mErrorMessage_10() { return &___mErrorMessage_10; }
	inline void set_mErrorMessage_10(String_t* value)
	{
		___mErrorMessage_10 = value;
		Il2CppCodeGenWriteBarrier((&___mErrorMessage_10), value);
	}
};

struct ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields
{
public:
	// System.String Byn.Awrtc.ErrorInfo::SERVER_INIT_FAILED_ADDRESS_IN_USE
	String_t* ___SERVER_INIT_FAILED_ADDRESS_IN_USE_0;
	// System.String Byn.Awrtc.ErrorInfo::CONNECTION_FAILED_ADDRESS_UNKNOWN
	String_t* ___CONNECTION_FAILED_ADDRESS_UNKNOWN_1;
	// System.String Byn.Awrtc.ErrorInfo::SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE
	String_t* ___SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2;
	// System.String Byn.Awrtc.ErrorInfo::CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE
	String_t* ___CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3;
	// System.String Byn.Awrtc.ErrorInfo::DISCONNECTED_REQURED_CONNECTION_OFFLINE
	String_t* ___DISCONNECTED_REQURED_CONNECTION_OFFLINE_4;
	// System.String Byn.Awrtc.ErrorInfo::SERVER_CLOSED_REQURED_CONNECTION_OFFLINE
	String_t* ___SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5;
	// System.String Byn.Awrtc.ErrorInfo::CONNECTION_FAILED_TO_CONNECT_DIRECTLY
	String_t* ___CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6;
	// System.String Byn.Awrtc.ErrorInfo::INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY
	String_t* ___INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7;
	// System.String Byn.Awrtc.ErrorInfo::DISCONNECTED_DUE_TO_TIMEOUT
	String_t* ___DISCONNECTED_DUE_TO_TIMEOUT_8;
	// System.String Byn.Awrtc.ErrorInfo::CONFIGURATION_FAILED
	String_t* ___CONFIGURATION_FAILED_9;

public:
	inline static int32_t get_offset_of_SERVER_INIT_FAILED_ADDRESS_IN_USE_0() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___SERVER_INIT_FAILED_ADDRESS_IN_USE_0)); }
	inline String_t* get_SERVER_INIT_FAILED_ADDRESS_IN_USE_0() const { return ___SERVER_INIT_FAILED_ADDRESS_IN_USE_0; }
	inline String_t** get_address_of_SERVER_INIT_FAILED_ADDRESS_IN_USE_0() { return &___SERVER_INIT_FAILED_ADDRESS_IN_USE_0; }
	inline void set_SERVER_INIT_FAILED_ADDRESS_IN_USE_0(String_t* value)
	{
		___SERVER_INIT_FAILED_ADDRESS_IN_USE_0 = value;
		Il2CppCodeGenWriteBarrier((&___SERVER_INIT_FAILED_ADDRESS_IN_USE_0), value);
	}

	inline static int32_t get_offset_of_CONNECTION_FAILED_ADDRESS_UNKNOWN_1() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___CONNECTION_FAILED_ADDRESS_UNKNOWN_1)); }
	inline String_t* get_CONNECTION_FAILED_ADDRESS_UNKNOWN_1() const { return ___CONNECTION_FAILED_ADDRESS_UNKNOWN_1; }
	inline String_t** get_address_of_CONNECTION_FAILED_ADDRESS_UNKNOWN_1() { return &___CONNECTION_FAILED_ADDRESS_UNKNOWN_1; }
	inline void set_CONNECTION_FAILED_ADDRESS_UNKNOWN_1(String_t* value)
	{
		___CONNECTION_FAILED_ADDRESS_UNKNOWN_1 = value;
		Il2CppCodeGenWriteBarrier((&___CONNECTION_FAILED_ADDRESS_UNKNOWN_1), value);
	}

	inline static int32_t get_offset_of_SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2)); }
	inline String_t* get_SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2() const { return ___SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2; }
	inline String_t** get_address_of_SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2() { return &___SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2; }
	inline void set_SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2(String_t* value)
	{
		___SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2 = value;
		Il2CppCodeGenWriteBarrier((&___SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2), value);
	}

	inline static int32_t get_offset_of_CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3)); }
	inline String_t* get_CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3() const { return ___CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3; }
	inline String_t** get_address_of_CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3() { return &___CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3; }
	inline void set_CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3(String_t* value)
	{
		___CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3 = value;
		Il2CppCodeGenWriteBarrier((&___CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3), value);
	}

	inline static int32_t get_offset_of_DISCONNECTED_REQURED_CONNECTION_OFFLINE_4() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___DISCONNECTED_REQURED_CONNECTION_OFFLINE_4)); }
	inline String_t* get_DISCONNECTED_REQURED_CONNECTION_OFFLINE_4() const { return ___DISCONNECTED_REQURED_CONNECTION_OFFLINE_4; }
	inline String_t** get_address_of_DISCONNECTED_REQURED_CONNECTION_OFFLINE_4() { return &___DISCONNECTED_REQURED_CONNECTION_OFFLINE_4; }
	inline void set_DISCONNECTED_REQURED_CONNECTION_OFFLINE_4(String_t* value)
	{
		___DISCONNECTED_REQURED_CONNECTION_OFFLINE_4 = value;
		Il2CppCodeGenWriteBarrier((&___DISCONNECTED_REQURED_CONNECTION_OFFLINE_4), value);
	}

	inline static int32_t get_offset_of_SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5)); }
	inline String_t* get_SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5() const { return ___SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5; }
	inline String_t** get_address_of_SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5() { return &___SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5; }
	inline void set_SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5(String_t* value)
	{
		___SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5 = value;
		Il2CppCodeGenWriteBarrier((&___SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5), value);
	}

	inline static int32_t get_offset_of_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6)); }
	inline String_t* get_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6() const { return ___CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6; }
	inline String_t** get_address_of_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6() { return &___CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6; }
	inline void set_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6(String_t* value)
	{
		___CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6 = value;
		Il2CppCodeGenWriteBarrier((&___CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6), value);
	}

	inline static int32_t get_offset_of_INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7)); }
	inline String_t* get_INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7() const { return ___INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7; }
	inline String_t** get_address_of_INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7() { return &___INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7; }
	inline void set_INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7(String_t* value)
	{
		___INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7 = value;
		Il2CppCodeGenWriteBarrier((&___INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7), value);
	}

	inline static int32_t get_offset_of_DISCONNECTED_DUE_TO_TIMEOUT_8() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___DISCONNECTED_DUE_TO_TIMEOUT_8)); }
	inline String_t* get_DISCONNECTED_DUE_TO_TIMEOUT_8() const { return ___DISCONNECTED_DUE_TO_TIMEOUT_8; }
	inline String_t** get_address_of_DISCONNECTED_DUE_TO_TIMEOUT_8() { return &___DISCONNECTED_DUE_TO_TIMEOUT_8; }
	inline void set_DISCONNECTED_DUE_TO_TIMEOUT_8(String_t* value)
	{
		___DISCONNECTED_DUE_TO_TIMEOUT_8 = value;
		Il2CppCodeGenWriteBarrier((&___DISCONNECTED_DUE_TO_TIMEOUT_8), value);
	}

	inline static int32_t get_offset_of_CONFIGURATION_FAILED_9() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___CONFIGURATION_FAILED_9)); }
	inline String_t* get_CONFIGURATION_FAILED_9() const { return ___CONFIGURATION_FAILED_9; }
	inline String_t** get_address_of_CONFIGURATION_FAILED_9() { return &___CONFIGURATION_FAILED_9; }
	inline void set_CONFIGURATION_FAILED_9(String_t* value)
	{
		___CONFIGURATION_FAILED_9 = value;
		Il2CppCodeGenWriteBarrier((&___CONFIGURATION_FAILED_9), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ERRORINFO_T7BF4629517FDF63B912A4B6AE78C4B2BD9207167_H
#ifndef ICESERVER_T423A5044DD3B2346555973AF68F71585262E07FA_H
#define ICESERVER_T423A5044DD3B2346555973AF68F71585262E07FA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.IceServer
struct  IceServer_t423A5044DD3B2346555973AF68F71585262E07FA  : public RuntimeObject
{
public:
	// System.Collections.Generic.List`1<System.String> Byn.Awrtc.IceServer::mUrls
	List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * ___mUrls_0;
	// System.String Byn.Awrtc.IceServer::mUsername
	String_t* ___mUsername_1;
	// System.String Byn.Awrtc.IceServer::mCredential
	String_t* ___mCredential_2;

public:
	inline static int32_t get_offset_of_mUrls_0() { return static_cast<int32_t>(offsetof(IceServer_t423A5044DD3B2346555973AF68F71585262E07FA, ___mUrls_0)); }
	inline List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * get_mUrls_0() const { return ___mUrls_0; }
	inline List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 ** get_address_of_mUrls_0() { return &___mUrls_0; }
	inline void set_mUrls_0(List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * value)
	{
		___mUrls_0 = value;
		Il2CppCodeGenWriteBarrier((&___mUrls_0), value);
	}

	inline static int32_t get_offset_of_mUsername_1() { return static_cast<int32_t>(offsetof(IceServer_t423A5044DD3B2346555973AF68F71585262E07FA, ___mUsername_1)); }
	inline String_t* get_mUsername_1() const { return ___mUsername_1; }
	inline String_t** get_address_of_mUsername_1() { return &___mUsername_1; }
	inline void set_mUsername_1(String_t* value)
	{
		___mUsername_1 = value;
		Il2CppCodeGenWriteBarrier((&___mUsername_1), value);
	}

	inline static int32_t get_offset_of_mCredential_2() { return static_cast<int32_t>(offsetof(IceServer_t423A5044DD3B2346555973AF68F71585262E07FA, ___mCredential_2)); }
	inline String_t* get_mCredential_2() const { return ___mCredential_2; }
	inline String_t** get_address_of_mCredential_2() { return &___mCredential_2; }
	inline void set_mCredential_2(String_t* value)
	{
		___mCredential_2 = value;
		Il2CppCodeGenWriteBarrier((&___mCredential_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ICESERVER_T423A5044DD3B2346555973AF68F71585262E07FA_H
#ifndef MESSAGEDATABUFFEREXT_T97D4A96C74CBA57E4A36C43BC6C79FBDDFA9DA4F_H
#define MESSAGEDATABUFFEREXT_T97D4A96C74CBA57E4A36C43BC6C79FBDDFA9DA4F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.MessageDataBufferExt
struct  MessageDataBufferExt_t97D4A96C74CBA57E4A36C43BC6C79FBDDFA9DA4F  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MESSAGEDATABUFFEREXT_T97D4A96C74CBA57E4A36C43BC6C79FBDDFA9DA4F_H
#ifndef NETWORKCONFIG_T91786901660F3E2FB39AA6F01F3F9295D0751A47_H
#define NETWORKCONFIG_T91786901660F3E2FB39AA6F01F3F9295D0751A47_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.NetworkConfig
struct  NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47  : public RuntimeObject
{
public:
	// System.Collections.Generic.List`1<Byn.Awrtc.IceServer> Byn.Awrtc.NetworkConfig::mIceServers
	List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 * ___mIceServers_0;
	// System.String Byn.Awrtc.NetworkConfig::mSignalingUrl
	String_t* ___mSignalingUrl_1;
	// System.Boolean Byn.Awrtc.NetworkConfig::mAllowRenegotiation
	bool ___mAllowRenegotiation_2;
	// System.Boolean Byn.Awrtc.NetworkConfig::mIsConference
	bool ___mIsConference_3;

public:
	inline static int32_t get_offset_of_mIceServers_0() { return static_cast<int32_t>(offsetof(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47, ___mIceServers_0)); }
	inline List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 * get_mIceServers_0() const { return ___mIceServers_0; }
	inline List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 ** get_address_of_mIceServers_0() { return &___mIceServers_0; }
	inline void set_mIceServers_0(List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 * value)
	{
		___mIceServers_0 = value;
		Il2CppCodeGenWriteBarrier((&___mIceServers_0), value);
	}

	inline static int32_t get_offset_of_mSignalingUrl_1() { return static_cast<int32_t>(offsetof(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47, ___mSignalingUrl_1)); }
	inline String_t* get_mSignalingUrl_1() const { return ___mSignalingUrl_1; }
	inline String_t** get_address_of_mSignalingUrl_1() { return &___mSignalingUrl_1; }
	inline void set_mSignalingUrl_1(String_t* value)
	{
		___mSignalingUrl_1 = value;
		Il2CppCodeGenWriteBarrier((&___mSignalingUrl_1), value);
	}

	inline static int32_t get_offset_of_mAllowRenegotiation_2() { return static_cast<int32_t>(offsetof(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47, ___mAllowRenegotiation_2)); }
	inline bool get_mAllowRenegotiation_2() const { return ___mAllowRenegotiation_2; }
	inline bool* get_address_of_mAllowRenegotiation_2() { return &___mAllowRenegotiation_2; }
	inline void set_mAllowRenegotiation_2(bool value)
	{
		___mAllowRenegotiation_2 = value;
	}

	inline static int32_t get_offset_of_mIsConference_3() { return static_cast<int32_t>(offsetof(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47, ___mIsConference_3)); }
	inline bool get_mIsConference_3() const { return ___mIsConference_3; }
	inline bool* get_address_of_mIsConference_3() { return &___mIsConference_3; }
	inline void set_mIsConference_3(bool value)
	{
		___mIsConference_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NETWORKCONFIG_T91786901660F3E2FB39AA6F01F3F9295D0751A47_H
#ifndef VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#define VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_com
{
};
#endif // VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#ifndef ANALYTICSSESSIONINFO_TE075F764A74D2B095CFD57F3B179397F504B7D8C_H
#define ANALYTICSSESSIONINFO_TE075F764A74D2B095CFD57F3B179397F504B7D8C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Analytics.AnalyticsSessionInfo
struct  AnalyticsSessionInfo_tE075F764A74D2B095CFD57F3B179397F504B7D8C  : public RuntimeObject
{
public:

public:
};

struct AnalyticsSessionInfo_tE075F764A74D2B095CFD57F3B179397F504B7D8C_StaticFields
{
public:
	// UnityEngine.Analytics.AnalyticsSessionInfo_SessionStateChanged UnityEngine.Analytics.AnalyticsSessionInfo::sessionStateChanged
	SessionStateChanged_t9084549A636BD45086D66CC6765DA8C3DD31066F * ___sessionStateChanged_0;

public:
	inline static int32_t get_offset_of_sessionStateChanged_0() { return static_cast<int32_t>(offsetof(AnalyticsSessionInfo_tE075F764A74D2B095CFD57F3B179397F504B7D8C_StaticFields, ___sessionStateChanged_0)); }
	inline SessionStateChanged_t9084549A636BD45086D66CC6765DA8C3DD31066F * get_sessionStateChanged_0() const { return ___sessionStateChanged_0; }
	inline SessionStateChanged_t9084549A636BD45086D66CC6765DA8C3DD31066F ** get_address_of_sessionStateChanged_0() { return &___sessionStateChanged_0; }
	inline void set_sessionStateChanged_0(SessionStateChanged_t9084549A636BD45086D66CC6765DA8C3DD31066F * value)
	{
		___sessionStateChanged_0 = value;
		Il2CppCodeGenWriteBarrier((&___sessionStateChanged_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ANALYTICSSESSIONINFO_TE075F764A74D2B095CFD57F3B179397F504B7D8C_H
#ifndef CONTINUOUSEVENT_TBAB6336255F3FC327CBA03CE368CD4D8D027107A_H
#define CONTINUOUSEVENT_TBAB6336255F3FC327CBA03CE368CD4D8D027107A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Analytics.ContinuousEvent
struct  ContinuousEvent_tBAB6336255F3FC327CBA03CE368CD4D8D027107A  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONTINUOUSEVENT_TBAB6336255F3FC327CBA03CE368CD4D8D027107A_H
#ifndef U3CCOLLECTTERRAINSU3EC__ANONSTOREY0_T4BCCA12171A915F3BCE4B2B0F9A4EBD484BC78CA_H
#define U3CCOLLECTTERRAINSU3EC__ANONSTOREY0_T4BCCA12171A915F3BCE4B2B0F9A4EBD484BC78CA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.TerrainAPI.TerrainUtility_<CollectTerrains>c__AnonStorey0
struct  U3CCollectTerrainsU3Ec__AnonStorey0_t4BCCA12171A915F3BCE4B2B0F9A4EBD484BC78CA  : public RuntimeObject
{
public:
	// UnityEngine.Terrain UnityEngine.Experimental.TerrainAPI.TerrainUtility_<CollectTerrains>c__AnonStorey0::t
	Terrain_t0BF7371FA90643325F50A87C7894D7BEBBE08943 * ___t_0;
	// UnityEngine.Experimental.TerrainAPI.TerrainUtility_<CollectTerrains>c__AnonStorey1 UnityEngine.Experimental.TerrainAPI.TerrainUtility_<CollectTerrains>c__AnonStorey0::<>f__refU241
	U3CCollectTerrainsU3Ec__AnonStorey1_t41DA2A02D290EE5FEF14389A4391CBC1E3E622A5 * ___U3CU3Ef__refU241_1;

public:
	inline static int32_t get_offset_of_t_0() { return static_cast<int32_t>(offsetof(U3CCollectTerrainsU3Ec__AnonStorey0_t4BCCA12171A915F3BCE4B2B0F9A4EBD484BC78CA, ___t_0)); }
	inline Terrain_t0BF7371FA90643325F50A87C7894D7BEBBE08943 * get_t_0() const { return ___t_0; }
	inline Terrain_t0BF7371FA90643325F50A87C7894D7BEBBE08943 ** get_address_of_t_0() { return &___t_0; }
	inline void set_t_0(Terrain_t0BF7371FA90643325F50A87C7894D7BEBBE08943 * value)
	{
		___t_0 = value;
		Il2CppCodeGenWriteBarrier((&___t_0), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__refU241_1() { return static_cast<int32_t>(offsetof(U3CCollectTerrainsU3Ec__AnonStorey0_t4BCCA12171A915F3BCE4B2B0F9A4EBD484BC78CA, ___U3CU3Ef__refU241_1)); }
	inline U3CCollectTerrainsU3Ec__AnonStorey1_t41DA2A02D290EE5FEF14389A4391CBC1E3E622A5 * get_U3CU3Ef__refU241_1() const { return ___U3CU3Ef__refU241_1; }
	inline U3CCollectTerrainsU3Ec__AnonStorey1_t41DA2A02D290EE5FEF14389A4391CBC1E3E622A5 ** get_address_of_U3CU3Ef__refU241_1() { return &___U3CU3Ef__refU241_1; }
	inline void set_U3CU3Ef__refU241_1(U3CCollectTerrainsU3Ec__AnonStorey1_t41DA2A02D290EE5FEF14389A4391CBC1E3E622A5 * value)
	{
		___U3CU3Ef__refU241_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__refU241_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CCOLLECTTERRAINSU3EC__ANONSTOREY0_T4BCCA12171A915F3BCE4B2B0F9A4EBD484BC78CA_H
#ifndef U3CCOLLECTTERRAINSU3EC__ANONSTOREY1_T41DA2A02D290EE5FEF14389A4391CBC1E3E622A5_H
#define U3CCOLLECTTERRAINSU3EC__ANONSTOREY1_T41DA2A02D290EE5FEF14389A4391CBC1E3E622A5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.TerrainAPI.TerrainUtility_<CollectTerrains>c__AnonStorey1
struct  U3CCollectTerrainsU3Ec__AnonStorey1_t41DA2A02D290EE5FEF14389A4391CBC1E3E622A5  : public RuntimeObject
{
public:
	// System.Boolean UnityEngine.Experimental.TerrainAPI.TerrainUtility_<CollectTerrains>c__AnonStorey1::onlyAutoConnectedTerrains
	bool ___onlyAutoConnectedTerrains_0;

public:
	inline static int32_t get_offset_of_onlyAutoConnectedTerrains_0() { return static_cast<int32_t>(offsetof(U3CCollectTerrainsU3Ec__AnonStorey1_t41DA2A02D290EE5FEF14389A4391CBC1E3E622A5, ___onlyAutoConnectedTerrains_0)); }
	inline bool get_onlyAutoConnectedTerrains_0() const { return ___onlyAutoConnectedTerrains_0; }
	inline bool* get_address_of_onlyAutoConnectedTerrains_0() { return &___onlyAutoConnectedTerrains_0; }
	inline void set_onlyAutoConnectedTerrains_0(bool value)
	{
		___onlyAutoConnectedTerrains_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CCOLLECTTERRAINSU3EC__ANONSTOREY1_T41DA2A02D290EE5FEF14389A4391CBC1E3E622A5_H
#ifndef VFXMANAGER_TDE794F20EA719507EADF091F8042A8B097F1E8E5_H
#define VFXMANAGER_TDE794F20EA719507EADF091F8042A8B097F1E8E5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.VFX.VFXManager
struct  VFXManager_tDE794F20EA719507EADF091F8042A8B097F1E8E5  : public RuntimeObject
{
public:

public:
};

struct VFXManager_tDE794F20EA719507EADF091F8042A8B097F1E8E5_StaticFields
{
public:
	// System.Action`1<UnityEngine.Camera> UnityEngine.Experimental.VFX.VFXManager::<>f__mgU24cache0
	Action_1_t6D83B4F361CDBC0D6B559F8DA3A9646E2ED9561C * ___U3CU3Ef__mgU24cache0_0;
	// System.Action`1<UnityEngine.Camera> UnityEngine.Experimental.VFX.VFXManager::<>f__mgU24cache1
	Action_1_t6D83B4F361CDBC0D6B559F8DA3A9646E2ED9561C * ___U3CU3Ef__mgU24cache1_1;

public:
	inline static int32_t get_offset_of_U3CU3Ef__mgU24cache0_0() { return static_cast<int32_t>(offsetof(VFXManager_tDE794F20EA719507EADF091F8042A8B097F1E8E5_StaticFields, ___U3CU3Ef__mgU24cache0_0)); }
	inline Action_1_t6D83B4F361CDBC0D6B559F8DA3A9646E2ED9561C * get_U3CU3Ef__mgU24cache0_0() const { return ___U3CU3Ef__mgU24cache0_0; }
	inline Action_1_t6D83B4F361CDBC0D6B559F8DA3A9646E2ED9561C ** get_address_of_U3CU3Ef__mgU24cache0_0() { return &___U3CU3Ef__mgU24cache0_0; }
	inline void set_U3CU3Ef__mgU24cache0_0(Action_1_t6D83B4F361CDBC0D6B559F8DA3A9646E2ED9561C * value)
	{
		___U3CU3Ef__mgU24cache0_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__mgU24cache0_0), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__mgU24cache1_1() { return static_cast<int32_t>(offsetof(VFXManager_tDE794F20EA719507EADF091F8042A8B097F1E8E5_StaticFields, ___U3CU3Ef__mgU24cache1_1)); }
	inline Action_1_t6D83B4F361CDBC0D6B559F8DA3A9646E2ED9561C * get_U3CU3Ef__mgU24cache1_1() const { return ___U3CU3Ef__mgU24cache1_1; }
	inline Action_1_t6D83B4F361CDBC0D6B559F8DA3A9646E2ED9561C ** get_address_of_U3CU3Ef__mgU24cache1_1() { return &___U3CU3Ef__mgU24cache1_1; }
	inline void set_U3CU3Ef__mgU24cache1_1(Action_1_t6D83B4F361CDBC0D6B559F8DA3A9646E2ED9561C * value)
	{
		___U3CU3Ef__mgU24cache1_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__mgU24cache1_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VFXMANAGER_TDE794F20EA719507EADF091F8042A8B097F1E8E5_H
#ifndef RECTTRANSFORMUTILITY_T9B90669A72B05A33DD88BEBB817BC9CDBB614BBA_H
#define RECTTRANSFORMUTILITY_T9B90669A72B05A33DD88BEBB817BC9CDBB614BBA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RectTransformUtility
struct  RectTransformUtility_t9B90669A72B05A33DD88BEBB817BC9CDBB614BBA  : public RuntimeObject
{
public:

public:
};

struct RectTransformUtility_t9B90669A72B05A33DD88BEBB817BC9CDBB614BBA_StaticFields
{
public:
	// UnityEngine.Vector3[] UnityEngine.RectTransformUtility::s_Corners
	Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28* ___s_Corners_0;

public:
	inline static int32_t get_offset_of_s_Corners_0() { return static_cast<int32_t>(offsetof(RectTransformUtility_t9B90669A72B05A33DD88BEBB817BC9CDBB614BBA_StaticFields, ___s_Corners_0)); }
	inline Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28* get_s_Corners_0() const { return ___s_Corners_0; }
	inline Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28** get_address_of_s_Corners_0() { return &___s_Corners_0; }
	inline void set_s_Corners_0(Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28* value)
	{
		___s_Corners_0 = value;
		Il2CppCodeGenWriteBarrier((&___s_Corners_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RECTTRANSFORMUTILITY_T9B90669A72B05A33DD88BEBB817BC9CDBB614BBA_H
#ifndef REMOTESETTINGS_T3F7E07D15288B0DF84A4A32044592D8AFA6D36ED_H
#define REMOTESETTINGS_T3F7E07D15288B0DF84A4A32044592D8AFA6D36ED_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RemoteSettings
struct  RemoteSettings_t3F7E07D15288B0DF84A4A32044592D8AFA6D36ED  : public RuntimeObject
{
public:

public:
};

struct RemoteSettings_t3F7E07D15288B0DF84A4A32044592D8AFA6D36ED_StaticFields
{
public:
	// UnityEngine.RemoteSettings_UpdatedEventHandler UnityEngine.RemoteSettings::Updated
	UpdatedEventHandler_tB0230BC83686D7126AB4D3800A66351028CA514F * ___Updated_0;
	// System.Action UnityEngine.RemoteSettings::BeforeFetchFromServer
	Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * ___BeforeFetchFromServer_1;
	// System.Action`3<System.Boolean,System.Boolean,System.Int32> UnityEngine.RemoteSettings::Completed
	Action_3_tEE1FB0623176AFA5109FAA9BA7E82293445CAE1E * ___Completed_2;

public:
	inline static int32_t get_offset_of_Updated_0() { return static_cast<int32_t>(offsetof(RemoteSettings_t3F7E07D15288B0DF84A4A32044592D8AFA6D36ED_StaticFields, ___Updated_0)); }
	inline UpdatedEventHandler_tB0230BC83686D7126AB4D3800A66351028CA514F * get_Updated_0() const { return ___Updated_0; }
	inline UpdatedEventHandler_tB0230BC83686D7126AB4D3800A66351028CA514F ** get_address_of_Updated_0() { return &___Updated_0; }
	inline void set_Updated_0(UpdatedEventHandler_tB0230BC83686D7126AB4D3800A66351028CA514F * value)
	{
		___Updated_0 = value;
		Il2CppCodeGenWriteBarrier((&___Updated_0), value);
	}

	inline static int32_t get_offset_of_BeforeFetchFromServer_1() { return static_cast<int32_t>(offsetof(RemoteSettings_t3F7E07D15288B0DF84A4A32044592D8AFA6D36ED_StaticFields, ___BeforeFetchFromServer_1)); }
	inline Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * get_BeforeFetchFromServer_1() const { return ___BeforeFetchFromServer_1; }
	inline Action_t591D2A86165F896B4B800BB5C25CE18672A55579 ** get_address_of_BeforeFetchFromServer_1() { return &___BeforeFetchFromServer_1; }
	inline void set_BeforeFetchFromServer_1(Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * value)
	{
		___BeforeFetchFromServer_1 = value;
		Il2CppCodeGenWriteBarrier((&___BeforeFetchFromServer_1), value);
	}

	inline static int32_t get_offset_of_Completed_2() { return static_cast<int32_t>(offsetof(RemoteSettings_t3F7E07D15288B0DF84A4A32044592D8AFA6D36ED_StaticFields, ___Completed_2)); }
	inline Action_3_tEE1FB0623176AFA5109FAA9BA7E82293445CAE1E * get_Completed_2() const { return ___Completed_2; }
	inline Action_3_tEE1FB0623176AFA5109FAA9BA7E82293445CAE1E ** get_address_of_Completed_2() { return &___Completed_2; }
	inline void set_Completed_2(Action_3_tEE1FB0623176AFA5109FAA9BA7E82293445CAE1E * value)
	{
		___Completed_2 = value;
		Il2CppCodeGenWriteBarrier((&___Completed_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REMOTESETTINGS_T3F7E07D15288B0DF84A4A32044592D8AFA6D36ED_H
#ifndef ITILEMAP_T784A442A8BD2283058F44E8C0FE5257168459BE3_H
#define ITILEMAP_T784A442A8BD2283058F44E8C0FE5257168459BE3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Tilemaps.ITilemap
struct  ITilemap_t784A442A8BD2283058F44E8C0FE5257168459BE3  : public RuntimeObject
{
public:
	// UnityEngine.Tilemaps.Tilemap UnityEngine.Tilemaps.ITilemap::m_Tilemap
	Tilemap_t0F92148668211805A631B93488D4A629EC378B10 * ___m_Tilemap_1;

public:
	inline static int32_t get_offset_of_m_Tilemap_1() { return static_cast<int32_t>(offsetof(ITilemap_t784A442A8BD2283058F44E8C0FE5257168459BE3, ___m_Tilemap_1)); }
	inline Tilemap_t0F92148668211805A631B93488D4A629EC378B10 * get_m_Tilemap_1() const { return ___m_Tilemap_1; }
	inline Tilemap_t0F92148668211805A631B93488D4A629EC378B10 ** get_address_of_m_Tilemap_1() { return &___m_Tilemap_1; }
	inline void set_m_Tilemap_1(Tilemap_t0F92148668211805A631B93488D4A629EC378B10 * value)
	{
		___m_Tilemap_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_Tilemap_1), value);
	}
};

struct ITilemap_t784A442A8BD2283058F44E8C0FE5257168459BE3_StaticFields
{
public:
	// UnityEngine.Tilemaps.ITilemap UnityEngine.Tilemaps.ITilemap::s_Instance
	ITilemap_t784A442A8BD2283058F44E8C0FE5257168459BE3 * ___s_Instance_0;

public:
	inline static int32_t get_offset_of_s_Instance_0() { return static_cast<int32_t>(offsetof(ITilemap_t784A442A8BD2283058F44E8C0FE5257168459BE3_StaticFields, ___s_Instance_0)); }
	inline ITilemap_t784A442A8BD2283058F44E8C0FE5257168459BE3 * get_s_Instance_0() const { return ___s_Instance_0; }
	inline ITilemap_t784A442A8BD2283058F44E8C0FE5257168459BE3 ** get_address_of_s_Instance_0() { return &___s_Instance_0; }
	inline void set_s_Instance_0(ITilemap_t784A442A8BD2283058F44E8C0FE5257168459BE3 * value)
	{
		___s_Instance_0 = value;
		Il2CppCodeGenWriteBarrier((&___s_Instance_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ITILEMAP_T784A442A8BD2283058F44E8C0FE5257168459BE3_H
#ifndef UISYSTEMPROFILERAPI_TD33E558B2D0176096E5DB375956ACA9F03678F1B_H
#define UISYSTEMPROFILERAPI_TD33E558B2D0176096E5DB375956ACA9F03678F1B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UISystemProfilerApi
struct  UISystemProfilerApi_tD33E558B2D0176096E5DB375956ACA9F03678F1B  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UISYSTEMPROFILERAPI_TD33E558B2D0176096E5DB375956ACA9F03678F1B_H
#ifndef XRDEVICE_T392FCA3D1DCEB95FF500C8F374C88B034C31DF4A_H
#define XRDEVICE_T392FCA3D1DCEB95FF500C8F374C88B034C31DF4A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.XR.XRDevice
struct  XRDevice_t392FCA3D1DCEB95FF500C8F374C88B034C31DF4A  : public RuntimeObject
{
public:

public:
};

struct XRDevice_t392FCA3D1DCEB95FF500C8F374C88B034C31DF4A_StaticFields
{
public:
	// System.Action`1<System.String> UnityEngine.XR.XRDevice::deviceLoaded
	Action_1_t32A9EECF5D4397CC1B9A7C7079870875411B06D0 * ___deviceLoaded_0;

public:
	inline static int32_t get_offset_of_deviceLoaded_0() { return static_cast<int32_t>(offsetof(XRDevice_t392FCA3D1DCEB95FF500C8F374C88B034C31DF4A_StaticFields, ___deviceLoaded_0)); }
	inline Action_1_t32A9EECF5D4397CC1B9A7C7079870875411B06D0 * get_deviceLoaded_0() const { return ___deviceLoaded_0; }
	inline Action_1_t32A9EECF5D4397CC1B9A7C7079870875411B06D0 ** get_address_of_deviceLoaded_0() { return &___deviceLoaded_0; }
	inline void set_deviceLoaded_0(Action_1_t32A9EECF5D4397CC1B9A7C7079870875411B06D0 * value)
	{
		___deviceLoaded_0 = value;
		Il2CppCodeGenWriteBarrier((&___deviceLoaded_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // XRDEVICE_T392FCA3D1DCEB95FF500C8F374C88B034C31DF4A_H
#ifndef NATIVE_TAB7B2E3A68EEFE9B7A356DB4CC8EC664EB765C2A_H
#define NATIVE_TAB7B2E3A68EEFE9B7A356DB4CC8EC664EB765C2A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Yoga.Native
struct  Native_tAB7B2E3A68EEFE9B7A356DB4CC8EC664EB765C2A  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NATIVE_TAB7B2E3A68EEFE9B7A356DB4CC8EC664EB765C2A_H
#ifndef WEBREQUESTUTILS_TBE8F8607E3A9633419968F6AF2F706A029AE1296_H
#define WEBREQUESTUTILS_TBE8F8607E3A9633419968F6AF2F706A029AE1296_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngineInternal.WebRequestUtils
struct  WebRequestUtils_tBE8F8607E3A9633419968F6AF2F706A029AE1296  : public RuntimeObject
{
public:

public:
};

struct WebRequestUtils_tBE8F8607E3A9633419968F6AF2F706A029AE1296_StaticFields
{
public:
	// System.Text.RegularExpressions.Regex UnityEngineInternal.WebRequestUtils::domainRegex
	Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF * ___domainRegex_0;

public:
	inline static int32_t get_offset_of_domainRegex_0() { return static_cast<int32_t>(offsetof(WebRequestUtils_tBE8F8607E3A9633419968F6AF2F706A029AE1296_StaticFields, ___domainRegex_0)); }
	inline Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF * get_domainRegex_0() const { return ___domainRegex_0; }
	inline Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF ** get_address_of_domainRegex_0() { return &___domainRegex_0; }
	inline void set_domainRegex_0(Regex_tFD46E63A462E852189FD6AB4E2B0B67C4D8FDBDF * value)
	{
		___domainRegex_0 = value;
		Il2CppCodeGenWriteBarrier((&___domainRegex_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WEBREQUESTUTILS_TBE8F8607E3A9633419968F6AF2F706A029AE1296_H
#ifndef CONNECTIONID_T47DBB761AF0DB1559EACE774B317DA2B8B67F66D_H
#define CONNECTIONID_T47DBB761AF0DB1559EACE774B317DA2B8B67F66D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.ConnectionId
struct  ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D 
{
public:
	// System.Int16 Byn.Awrtc.ConnectionId::id
	int16_t ___id_1;

public:
	inline static int32_t get_offset_of_id_1() { return static_cast<int32_t>(offsetof(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D, ___id_1)); }
	inline int16_t get_id_1() const { return ___id_1; }
	inline int16_t* get_address_of_id_1() { return &___id_1; }
	inline void set_id_1(int16_t value)
	{
		___id_1 = value;
	}
};

struct ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields
{
public:
	// Byn.Awrtc.ConnectionId Byn.Awrtc.ConnectionId::INVALID
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___INVALID_0;

public:
	inline static int32_t get_offset_of_INVALID_0() { return static_cast<int32_t>(offsetof(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields, ___INVALID_0)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_INVALID_0() const { return ___INVALID_0; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_INVALID_0() { return &___INVALID_0; }
	inline void set_INVALID_0(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___INVALID_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONNECTIONID_T47DBB761AF0DB1559EACE774B317DA2B8B67F66D_H
#ifndef BOOLEAN_TB53F6830F670160873277339AA58F15CAED4399C_H
#define BOOLEAN_TB53F6830F670160873277339AA58F15CAED4399C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Boolean
struct  Boolean_tB53F6830F670160873277339AA58F15CAED4399C 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C, ___m_value_0)); }
	inline bool get_m_value_0() const { return ___m_value_0; }
	inline bool* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(bool value)
	{
		___m_value_0 = value;
	}
};

struct Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields
{
public:
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;

public:
	inline static int32_t get_offset_of_TrueString_5() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields, ___TrueString_5)); }
	inline String_t* get_TrueString_5() const { return ___TrueString_5; }
	inline String_t** get_address_of_TrueString_5() { return &___TrueString_5; }
	inline void set_TrueString_5(String_t* value)
	{
		___TrueString_5 = value;
		Il2CppCodeGenWriteBarrier((&___TrueString_5), value);
	}

	inline static int32_t get_offset_of_FalseString_6() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields, ___FalseString_6)); }
	inline String_t* get_FalseString_6() const { return ___FalseString_6; }
	inline String_t** get_address_of_FalseString_6() { return &___FalseString_6; }
	inline void set_FalseString_6(String_t* value)
	{
		___FalseString_6 = value;
		Il2CppCodeGenWriteBarrier((&___FalseString_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BOOLEAN_TB53F6830F670160873277339AA58F15CAED4399C_H
#ifndef DOUBLE_T358B8F23BDC52A5DD700E727E204F9F7CDE12409_H
#define DOUBLE_T358B8F23BDC52A5DD700E727E204F9F7CDE12409_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Double
struct  Double_t358B8F23BDC52A5DD700E727E204F9F7CDE12409 
{
public:
	// System.Double System.Double::m_value
	double ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Double_t358B8F23BDC52A5DD700E727E204F9F7CDE12409, ___m_value_0)); }
	inline double get_m_value_0() const { return ___m_value_0; }
	inline double* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(double value)
	{
		___m_value_0 = value;
	}
};

struct Double_t358B8F23BDC52A5DD700E727E204F9F7CDE12409_StaticFields
{
public:
	// System.Double System.Double::NegativeZero
	double ___NegativeZero_7;

public:
	inline static int32_t get_offset_of_NegativeZero_7() { return static_cast<int32_t>(offsetof(Double_t358B8F23BDC52A5DD700E727E204F9F7CDE12409_StaticFields, ___NegativeZero_7)); }
	inline double get_NegativeZero_7() const { return ___NegativeZero_7; }
	inline double* get_address_of_NegativeZero_7() { return &___NegativeZero_7; }
	inline void set_NegativeZero_7(double value)
	{
		___NegativeZero_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DOUBLE_T358B8F23BDC52A5DD700E727E204F9F7CDE12409_H
#ifndef ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#define ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t2AF27C02B8653AE29442467390005ABC74D8F521  : public ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF
{
public:

public:
};

struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((&___enumSeperatorCharArray_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_com
{
};
#endif // ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#ifndef INT64_T7A386C2FF7B0280A0F516992401DDFCF0FF7B436_H
#define INT64_T7A386C2FF7B0280A0F516992401DDFCF0FF7B436_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Int64
struct  Int64_t7A386C2FF7B0280A0F516992401DDFCF0FF7B436 
{
public:
	// System.Int64 System.Int64::m_value
	int64_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int64_t7A386C2FF7B0280A0F516992401DDFCF0FF7B436, ___m_value_0)); }
	inline int64_t get_m_value_0() const { return ___m_value_0; }
	inline int64_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int64_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INT64_T7A386C2FF7B0280A0F516992401DDFCF0FF7B436_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef NULLABLE_1_T0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_H
#define NULLABLE_1_T0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Nullable`1<System.Int32>
struct  Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB 
{
public:
	// T System.Nullable`1::value
	int32_t ___value_0;
	// System.Boolean System.Nullable`1::has_value
	bool ___has_value_1;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB, ___value_0)); }
	inline int32_t get_value_0() const { return ___value_0; }
	inline int32_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(int32_t value)
	{
		___value_0 = value;
	}

	inline static int32_t get_offset_of_has_value_1() { return static_cast<int32_t>(offsetof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB, ___has_value_1)); }
	inline bool get_has_value_1() const { return ___has_value_1; }
	inline bool* get_address_of_has_value_1() { return &___has_value_1; }
	inline void set_has_value_1(bool value)
	{
		___has_value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NULLABLE_1_T0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_H
#ifndef SINGLE_TDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1_H
#define SINGLE_TDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Single
struct  Single_tDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1 
{
public:
	// System.Single System.Single::m_value
	float ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Single_tDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1, ___m_value_0)); }
	inline float get_m_value_0() const { return ___m_value_0; }
	inline float* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(float value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SINGLE_TDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1_H
#ifndef VOID_T22962CB4C05B1D89B55A6E1139F0E87A90987017_H
#define VOID_T22962CB4C05B1D89B55A6E1139F0E87A90987017_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Void
struct  Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017__padding[1];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VOID_T22962CB4C05B1D89B55A6E1139F0E87A90987017_H
#ifndef COLOR_T119BCA590009762C7223FDD3AF9706653AC84ED2_H
#define COLOR_T119BCA590009762C7223FDD3AF9706653AC84ED2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Color
struct  Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 
{
public:
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;

public:
	inline static int32_t get_offset_of_r_0() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___r_0)); }
	inline float get_r_0() const { return ___r_0; }
	inline float* get_address_of_r_0() { return &___r_0; }
	inline void set_r_0(float value)
	{
		___r_0 = value;
	}

	inline static int32_t get_offset_of_g_1() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___g_1)); }
	inline float get_g_1() const { return ___g_1; }
	inline float* get_address_of_g_1() { return &___g_1; }
	inline void set_g_1(float value)
	{
		___g_1 = value;
	}

	inline static int32_t get_offset_of_b_2() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___b_2)); }
	inline float get_b_2() const { return ___b_2; }
	inline float* get_address_of_b_2() { return &___b_2; }
	inline void set_b_2(float value)
	{
		___b_2 = value;
	}

	inline static int32_t get_offset_of_a_3() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___a_3)); }
	inline float get_a_3() const { return ___a_3; }
	inline float* get_address_of_a_3() { return &___a_3; }
	inline void set_a_3(float value)
	{
		___a_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLOR_T119BCA590009762C7223FDD3AF9706653AC84ED2_H
#ifndef MATRIX4X4_T6BF60F70C9169DF14C9D2577672A44224B236ECA_H
#define MATRIX4X4_T6BF60F70C9169DF14C9D2577672A44224B236ECA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Matrix4x4
struct  Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA 
{
public:
	// System.Single UnityEngine.Matrix4x4::m00
	float ___m00_0;
	// System.Single UnityEngine.Matrix4x4::m10
	float ___m10_1;
	// System.Single UnityEngine.Matrix4x4::m20
	float ___m20_2;
	// System.Single UnityEngine.Matrix4x4::m30
	float ___m30_3;
	// System.Single UnityEngine.Matrix4x4::m01
	float ___m01_4;
	// System.Single UnityEngine.Matrix4x4::m11
	float ___m11_5;
	// System.Single UnityEngine.Matrix4x4::m21
	float ___m21_6;
	// System.Single UnityEngine.Matrix4x4::m31
	float ___m31_7;
	// System.Single UnityEngine.Matrix4x4::m02
	float ___m02_8;
	// System.Single UnityEngine.Matrix4x4::m12
	float ___m12_9;
	// System.Single UnityEngine.Matrix4x4::m22
	float ___m22_10;
	// System.Single UnityEngine.Matrix4x4::m32
	float ___m32_11;
	// System.Single UnityEngine.Matrix4x4::m03
	float ___m03_12;
	// System.Single UnityEngine.Matrix4x4::m13
	float ___m13_13;
	// System.Single UnityEngine.Matrix4x4::m23
	float ___m23_14;
	// System.Single UnityEngine.Matrix4x4::m33
	float ___m33_15;

public:
	inline static int32_t get_offset_of_m00_0() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m00_0)); }
	inline float get_m00_0() const { return ___m00_0; }
	inline float* get_address_of_m00_0() { return &___m00_0; }
	inline void set_m00_0(float value)
	{
		___m00_0 = value;
	}

	inline static int32_t get_offset_of_m10_1() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m10_1)); }
	inline float get_m10_1() const { return ___m10_1; }
	inline float* get_address_of_m10_1() { return &___m10_1; }
	inline void set_m10_1(float value)
	{
		___m10_1 = value;
	}

	inline static int32_t get_offset_of_m20_2() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m20_2)); }
	inline float get_m20_2() const { return ___m20_2; }
	inline float* get_address_of_m20_2() { return &___m20_2; }
	inline void set_m20_2(float value)
	{
		___m20_2 = value;
	}

	inline static int32_t get_offset_of_m30_3() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m30_3)); }
	inline float get_m30_3() const { return ___m30_3; }
	inline float* get_address_of_m30_3() { return &___m30_3; }
	inline void set_m30_3(float value)
	{
		___m30_3 = value;
	}

	inline static int32_t get_offset_of_m01_4() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m01_4)); }
	inline float get_m01_4() const { return ___m01_4; }
	inline float* get_address_of_m01_4() { return &___m01_4; }
	inline void set_m01_4(float value)
	{
		___m01_4 = value;
	}

	inline static int32_t get_offset_of_m11_5() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m11_5)); }
	inline float get_m11_5() const { return ___m11_5; }
	inline float* get_address_of_m11_5() { return &___m11_5; }
	inline void set_m11_5(float value)
	{
		___m11_5 = value;
	}

	inline static int32_t get_offset_of_m21_6() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m21_6)); }
	inline float get_m21_6() const { return ___m21_6; }
	inline float* get_address_of_m21_6() { return &___m21_6; }
	inline void set_m21_6(float value)
	{
		___m21_6 = value;
	}

	inline static int32_t get_offset_of_m31_7() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m31_7)); }
	inline float get_m31_7() const { return ___m31_7; }
	inline float* get_address_of_m31_7() { return &___m31_7; }
	inline void set_m31_7(float value)
	{
		___m31_7 = value;
	}

	inline static int32_t get_offset_of_m02_8() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m02_8)); }
	inline float get_m02_8() const { return ___m02_8; }
	inline float* get_address_of_m02_8() { return &___m02_8; }
	inline void set_m02_8(float value)
	{
		___m02_8 = value;
	}

	inline static int32_t get_offset_of_m12_9() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m12_9)); }
	inline float get_m12_9() const { return ___m12_9; }
	inline float* get_address_of_m12_9() { return &___m12_9; }
	inline void set_m12_9(float value)
	{
		___m12_9 = value;
	}

	inline static int32_t get_offset_of_m22_10() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m22_10)); }
	inline float get_m22_10() const { return ___m22_10; }
	inline float* get_address_of_m22_10() { return &___m22_10; }
	inline void set_m22_10(float value)
	{
		___m22_10 = value;
	}

	inline static int32_t get_offset_of_m32_11() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m32_11)); }
	inline float get_m32_11() const { return ___m32_11; }
	inline float* get_address_of_m32_11() { return &___m32_11; }
	inline void set_m32_11(float value)
	{
		___m32_11 = value;
	}

	inline static int32_t get_offset_of_m03_12() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m03_12)); }
	inline float get_m03_12() const { return ___m03_12; }
	inline float* get_address_of_m03_12() { return &___m03_12; }
	inline void set_m03_12(float value)
	{
		___m03_12 = value;
	}

	inline static int32_t get_offset_of_m13_13() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m13_13)); }
	inline float get_m13_13() const { return ___m13_13; }
	inline float* get_address_of_m13_13() { return &___m13_13; }
	inline void set_m13_13(float value)
	{
		___m13_13 = value;
	}

	inline static int32_t get_offset_of_m23_14() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m23_14)); }
	inline float get_m23_14() const { return ___m23_14; }
	inline float* get_address_of_m23_14() { return &___m23_14; }
	inline void set_m23_14(float value)
	{
		___m23_14 = value;
	}

	inline static int32_t get_offset_of_m33_15() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m33_15)); }
	inline float get_m33_15() const { return ___m33_15; }
	inline float* get_address_of_m33_15() { return &___m33_15; }
	inline void set_m33_15(float value)
	{
		___m33_15 = value;
	}
};

struct Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA_StaticFields
{
public:
	// UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::zeroMatrix
	Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  ___zeroMatrix_16;
	// UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::identityMatrix
	Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  ___identityMatrix_17;

public:
	inline static int32_t get_offset_of_zeroMatrix_16() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA_StaticFields, ___zeroMatrix_16)); }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  get_zeroMatrix_16() const { return ___zeroMatrix_16; }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA * get_address_of_zeroMatrix_16() { return &___zeroMatrix_16; }
	inline void set_zeroMatrix_16(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  value)
	{
		___zeroMatrix_16 = value;
	}

	inline static int32_t get_offset_of_identityMatrix_17() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA_StaticFields, ___identityMatrix_17)); }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  get_identityMatrix_17() const { return ___identityMatrix_17; }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA * get_address_of_identityMatrix_17() { return &___identityMatrix_17; }
	inline void set_identityMatrix_17(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  value)
	{
		___identityMatrix_17 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MATRIX4X4_T6BF60F70C9169DF14C9D2577672A44224B236ECA_H
#ifndef TILEANIMATIONDATA_T2A9C81AD1F3E916C2DE292A6F3953FC8C38EFDA8_H
#define TILEANIMATIONDATA_T2A9C81AD1F3E916C2DE292A6F3953FC8C38EFDA8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Tilemaps.TileAnimationData
struct  TileAnimationData_t2A9C81AD1F3E916C2DE292A6F3953FC8C38EFDA8 
{
public:
	// UnityEngine.Sprite[] UnityEngine.Tilemaps.TileAnimationData::m_AnimatedSprites
	SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* ___m_AnimatedSprites_0;
	// System.Single UnityEngine.Tilemaps.TileAnimationData::m_AnimationSpeed
	float ___m_AnimationSpeed_1;
	// System.Single UnityEngine.Tilemaps.TileAnimationData::m_AnimationStartTime
	float ___m_AnimationStartTime_2;

public:
	inline static int32_t get_offset_of_m_AnimatedSprites_0() { return static_cast<int32_t>(offsetof(TileAnimationData_t2A9C81AD1F3E916C2DE292A6F3953FC8C38EFDA8, ___m_AnimatedSprites_0)); }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* get_m_AnimatedSprites_0() const { return ___m_AnimatedSprites_0; }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7** get_address_of_m_AnimatedSprites_0() { return &___m_AnimatedSprites_0; }
	inline void set_m_AnimatedSprites_0(SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* value)
	{
		___m_AnimatedSprites_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_AnimatedSprites_0), value);
	}

	inline static int32_t get_offset_of_m_AnimationSpeed_1() { return static_cast<int32_t>(offsetof(TileAnimationData_t2A9C81AD1F3E916C2DE292A6F3953FC8C38EFDA8, ___m_AnimationSpeed_1)); }
	inline float get_m_AnimationSpeed_1() const { return ___m_AnimationSpeed_1; }
	inline float* get_address_of_m_AnimationSpeed_1() { return &___m_AnimationSpeed_1; }
	inline void set_m_AnimationSpeed_1(float value)
	{
		___m_AnimationSpeed_1 = value;
	}

	inline static int32_t get_offset_of_m_AnimationStartTime_2() { return static_cast<int32_t>(offsetof(TileAnimationData_t2A9C81AD1F3E916C2DE292A6F3953FC8C38EFDA8, ___m_AnimationStartTime_2)); }
	inline float get_m_AnimationStartTime_2() const { return ___m_AnimationStartTime_2; }
	inline float* get_address_of_m_AnimationStartTime_2() { return &___m_AnimationStartTime_2; }
	inline void set_m_AnimationStartTime_2(float value)
	{
		___m_AnimationStartTime_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Tilemaps.TileAnimationData
struct TileAnimationData_t2A9C81AD1F3E916C2DE292A6F3953FC8C38EFDA8_marshaled_pinvoke
{
	SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* ___m_AnimatedSprites_0;
	float ___m_AnimationSpeed_1;
	float ___m_AnimationStartTime_2;
};
// Native definition for COM marshalling of UnityEngine.Tilemaps.TileAnimationData
struct TileAnimationData_t2A9C81AD1F3E916C2DE292A6F3953FC8C38EFDA8_marshaled_com
{
	SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* ___m_AnimatedSprites_0;
	float ___m_AnimationSpeed_1;
	float ___m_AnimationStartTime_2;
};
#endif // TILEANIMATIONDATA_T2A9C81AD1F3E916C2DE292A6F3953FC8C38EFDA8_H
#ifndef YOGASIZE_T0F2077727A4CBD4C36F3DC0CBE1FB0A67D9EAD23_H
#define YOGASIZE_T0F2077727A4CBD4C36F3DC0CBE1FB0A67D9EAD23_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Yoga.YogaSize
struct  YogaSize_t0F2077727A4CBD4C36F3DC0CBE1FB0A67D9EAD23 
{
public:
	// System.Single UnityEngine.Yoga.YogaSize::width
	float ___width_0;
	// System.Single UnityEngine.Yoga.YogaSize::height
	float ___height_1;

public:
	inline static int32_t get_offset_of_width_0() { return static_cast<int32_t>(offsetof(YogaSize_t0F2077727A4CBD4C36F3DC0CBE1FB0A67D9EAD23, ___width_0)); }
	inline float get_width_0() const { return ___width_0; }
	inline float* get_address_of_width_0() { return &___width_0; }
	inline void set_width_0(float value)
	{
		___width_0 = value;
	}

	inline static int32_t get_offset_of_height_1() { return static_cast<int32_t>(offsetof(YogaSize_t0F2077727A4CBD4C36F3DC0CBE1FB0A67D9EAD23, ___height_1)); }
	inline float get_height_1() const { return ___height_1; }
	inline float* get_address_of_height_1() { return &___height_1; }
	inline void set_height_1(float value)
	{
		___height_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // YOGASIZE_T0F2077727A4CBD4C36F3DC0CBE1FB0A67D9EAD23_H
#ifndef CALLSTATE_T4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_H
#define CALLSTATE_T4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.AWebRtcCall_CallState
struct  CallState_t4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC 
{
public:
	// System.Int32 Byn.Awrtc.Base.AWebRtcCall_CallState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(CallState_t4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLSTATE_T4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_H
#ifndef CALLEVENTTYPE_T83E9DB342D0F2580C5FB1EC4C26A3C3C035AD62B_H
#define CALLEVENTTYPE_T83E9DB342D0F2580C5FB1EC4C26A3C3C035AD62B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.CallEventType
struct  CallEventType_t83E9DB342D0F2580C5FB1EC4C26A3C3C035AD62B 
{
public:
	// System.Int32 Byn.Awrtc.CallEventType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(CallEventType_t83E9DB342D0F2580C5FB1EC4C26A3C3C035AD62B, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLEVENTTYPE_T83E9DB342D0F2580C5FB1EC4C26A3C3C035AD62B_H
#ifndef FRAMEPIXELFORMAT_TDCE4288D3AD386370E428FCC0668229B6994D9BB_H
#define FRAMEPIXELFORMAT_TDCE4288D3AD386370E428FCC0668229B6994D9BB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.FramePixelFormat
struct  FramePixelFormat_tDCE4288D3AD386370E428FCC0668229B6994D9BB 
{
public:
	// System.Int32 Byn.Awrtc.FramePixelFormat::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(FramePixelFormat_tDCE4288D3AD386370E428FCC0668229B6994D9BB, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FRAMEPIXELFORMAT_TDCE4288D3AD386370E428FCC0668229B6994D9BB_H
#ifndef LOCALNETWORK_T6CC9C9ABD435AA34E75B28DA1079343D30AEA562_H
#define LOCALNETWORK_T6CC9C9ABD435AA34E75B28DA1079343D30AEA562_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.LocalNetwork
struct  LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562  : public RuntimeObject
{
public:
	// System.Int32 Byn.Awrtc.LocalNetwork::mId
	int32_t ___mId_3;
	// Byn.Awrtc.ConnectionId Byn.Awrtc.LocalNetwork::mNextNetworkId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mNextNetworkId_4;
	// System.String Byn.Awrtc.LocalNetwork::mServerAddress
	String_t* ___mServerAddress_5;
	// System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent> Byn.Awrtc.LocalNetwork::mEvents
	Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * ___mEvents_6;
	// System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork_WeakRef`1<Byn.Awrtc.LocalNetwork>> Byn.Awrtc.LocalNetwork::mConnectionNetwork
	Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * ___mConnectionNetwork_7;
	// System.Boolean Byn.Awrtc.LocalNetwork::disposedValue
	bool ___disposedValue_8;

public:
	inline static int32_t get_offset_of_mId_3() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562, ___mId_3)); }
	inline int32_t get_mId_3() const { return ___mId_3; }
	inline int32_t* get_address_of_mId_3() { return &___mId_3; }
	inline void set_mId_3(int32_t value)
	{
		___mId_3 = value;
	}

	inline static int32_t get_offset_of_mNextNetworkId_4() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562, ___mNextNetworkId_4)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mNextNetworkId_4() const { return ___mNextNetworkId_4; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mNextNetworkId_4() { return &___mNextNetworkId_4; }
	inline void set_mNextNetworkId_4(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mNextNetworkId_4 = value;
	}

	inline static int32_t get_offset_of_mServerAddress_5() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562, ___mServerAddress_5)); }
	inline String_t* get_mServerAddress_5() const { return ___mServerAddress_5; }
	inline String_t** get_address_of_mServerAddress_5() { return &___mServerAddress_5; }
	inline void set_mServerAddress_5(String_t* value)
	{
		___mServerAddress_5 = value;
		Il2CppCodeGenWriteBarrier((&___mServerAddress_5), value);
	}

	inline static int32_t get_offset_of_mEvents_6() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562, ___mEvents_6)); }
	inline Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * get_mEvents_6() const { return ___mEvents_6; }
	inline Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF ** get_address_of_mEvents_6() { return &___mEvents_6; }
	inline void set_mEvents_6(Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * value)
	{
		___mEvents_6 = value;
		Il2CppCodeGenWriteBarrier((&___mEvents_6), value);
	}

	inline static int32_t get_offset_of_mConnectionNetwork_7() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562, ___mConnectionNetwork_7)); }
	inline Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * get_mConnectionNetwork_7() const { return ___mConnectionNetwork_7; }
	inline Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB ** get_address_of_mConnectionNetwork_7() { return &___mConnectionNetwork_7; }
	inline void set_mConnectionNetwork_7(Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * value)
	{
		___mConnectionNetwork_7 = value;
		Il2CppCodeGenWriteBarrier((&___mConnectionNetwork_7), value);
	}

	inline static int32_t get_offset_of_disposedValue_8() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562, ___disposedValue_8)); }
	inline bool get_disposedValue_8() const { return ___disposedValue_8; }
	inline bool* get_address_of_disposedValue_8() { return &___disposedValue_8; }
	inline void set_disposedValue_8(bool value)
	{
		___disposedValue_8 = value;
	}
};

struct LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields
{
public:
	// System.String Byn.Awrtc.LocalNetwork::LOCK_ADDRESS
	String_t* ___LOCK_ADDRESS_0;
	// System.Int32 Byn.Awrtc.LocalNetwork::sNextId
	int32_t ___sNextId_1;
	// System.Collections.Generic.Dictionary`2<System.String,Byn.Awrtc.LocalNetwork_WeakRef`1<Byn.Awrtc.LocalNetwork>> Byn.Awrtc.LocalNetwork::mServers
	Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * ___mServers_2;

public:
	inline static int32_t get_offset_of_LOCK_ADDRESS_0() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields, ___LOCK_ADDRESS_0)); }
	inline String_t* get_LOCK_ADDRESS_0() const { return ___LOCK_ADDRESS_0; }
	inline String_t** get_address_of_LOCK_ADDRESS_0() { return &___LOCK_ADDRESS_0; }
	inline void set_LOCK_ADDRESS_0(String_t* value)
	{
		___LOCK_ADDRESS_0 = value;
		Il2CppCodeGenWriteBarrier((&___LOCK_ADDRESS_0), value);
	}

	inline static int32_t get_offset_of_sNextId_1() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields, ___sNextId_1)); }
	inline int32_t get_sNextId_1() const { return ___sNextId_1; }
	inline int32_t* get_address_of_sNextId_1() { return &___sNextId_1; }
	inline void set_sNextId_1(int32_t value)
	{
		___sNextId_1 = value;
	}

	inline static int32_t get_offset_of_mServers_2() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields, ___mServers_2)); }
	inline Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * get_mServers_2() const { return ___mServers_2; }
	inline Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 ** get_address_of_mServers_2() { return &___mServers_2; }
	inline void set_mServers_2(Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * value)
	{
		___mServers_2 = value;
		Il2CppCodeGenWriteBarrier((&___mServers_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOCALNETWORK_T6CC9C9ABD435AA34E75B28DA1079343D30AEA562_H
#ifndef MEDIACONFIGURATIONSTATE_TD278B71006BEF0BB2F003EB306E41EB133453629_H
#define MEDIACONFIGURATIONSTATE_TD278B71006BEF0BB2F003EB306E41EB133453629_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.MediaConfigurationState
struct  MediaConfigurationState_tD278B71006BEF0BB2F003EB306E41EB133453629 
{
public:
	// System.Byte Byn.Awrtc.MediaConfigurationState::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(MediaConfigurationState_tD278B71006BEF0BB2F003EB306E41EB133453629, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MEDIACONFIGURATIONSTATE_TD278B71006BEF0BB2F003EB306E41EB133453629_H
#ifndef NETEVENTDATATYPE_T1C43B214D57FA8D91EC846A2FB89918433D613C6_H
#define NETEVENTDATATYPE_T1C43B214D57FA8D91EC846A2FB89918433D613C6_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.NetEventDataType
struct  NetEventDataType_t1C43B214D57FA8D91EC846A2FB89918433D613C6 
{
public:
	// System.Byte Byn.Awrtc.NetEventDataType::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(NetEventDataType_t1C43B214D57FA8D91EC846A2FB89918433D613C6, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NETEVENTDATATYPE_T1C43B214D57FA8D91EC846A2FB89918433D613C6_H
#ifndef NETEVENTTYPE_TD5213CE1DD8CDE1161395E0973FC1F8E5FB7B0A8_H
#define NETEVENTTYPE_TD5213CE1DD8CDE1161395E0973FC1F8E5FB7B0A8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.NetEventType
struct  NetEventType_tD5213CE1DD8CDE1161395E0973FC1F8E5FB7B0A8 
{
public:
	// System.Byte Byn.Awrtc.NetEventType::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(NetEventType_tD5213CE1DD8CDE1161395E0973FC1F8E5FB7B0A8, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NETEVENTTYPE_TD5213CE1DD8CDE1161395E0973FC1F8E5FB7B0A8_H
#ifndef DELEGATE_T_H
#define DELEGATE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Delegate
struct  Delegate_t  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::extra_arg
	intptr_t ___extra_arg_5;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_6;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_7;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_8;
	// System.DelegateData System.Delegate::data
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	// System.Boolean System.Delegate::method_is_virtual
	bool ___method_is_virtual_10;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t, ___invoke_impl_1)); }
	inline intptr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline intptr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(intptr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_target_2), value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_3)); }
	inline intptr_t get_method_3() const { return ___method_3; }
	inline intptr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(intptr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t, ___delegate_trampoline_4)); }
	inline intptr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline intptr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(intptr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_extra_arg_5() { return static_cast<int32_t>(offsetof(Delegate_t, ___extra_arg_5)); }
	inline intptr_t get_extra_arg_5() const { return ___extra_arg_5; }
	inline intptr_t* get_address_of_extra_arg_5() { return &___extra_arg_5; }
	inline void set_extra_arg_5(intptr_t value)
	{
		___extra_arg_5 = value;
	}

	inline static int32_t get_offset_of_method_code_6() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_code_6)); }
	inline intptr_t get_method_code_6() const { return ___method_code_6; }
	inline intptr_t* get_address_of_method_code_6() { return &___method_code_6; }
	inline void set_method_code_6(intptr_t value)
	{
		___method_code_6 = value;
	}

	inline static int32_t get_offset_of_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_info_7)); }
	inline MethodInfo_t * get_method_info_7() const { return ___method_info_7; }
	inline MethodInfo_t ** get_address_of_method_info_7() { return &___method_info_7; }
	inline void set_method_info_7(MethodInfo_t * value)
	{
		___method_info_7 = value;
		Il2CppCodeGenWriteBarrier((&___method_info_7), value);
	}

	inline static int32_t get_offset_of_original_method_info_8() { return static_cast<int32_t>(offsetof(Delegate_t, ___original_method_info_8)); }
	inline MethodInfo_t * get_original_method_info_8() const { return ___original_method_info_8; }
	inline MethodInfo_t ** get_address_of_original_method_info_8() { return &___original_method_info_8; }
	inline void set_original_method_info_8(MethodInfo_t * value)
	{
		___original_method_info_8 = value;
		Il2CppCodeGenWriteBarrier((&___original_method_info_8), value);
	}

	inline static int32_t get_offset_of_data_9() { return static_cast<int32_t>(offsetof(Delegate_t, ___data_9)); }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * get_data_9() const { return ___data_9; }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE ** get_address_of_data_9() { return &___data_9; }
	inline void set_data_9(DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * value)
	{
		___data_9 = value;
		Il2CppCodeGenWriteBarrier((&___data_9), value);
	}

	inline static int32_t get_offset_of_method_is_virtual_10() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_is_virtual_10)); }
	inline bool get_method_is_virtual_10() const { return ___method_is_virtual_10; }
	inline bool* get_address_of_method_is_virtual_10() { return &___method_is_virtual_10; }
	inline void set_method_is_virtual_10(bool value)
	{
		___method_is_virtual_10 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Delegate
struct Delegate_t_marshaled_pinvoke
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};
// Native definition for COM marshalling of System.Delegate
struct Delegate_t_marshaled_com
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};
#endif // DELEGATE_T_H
#ifndef ANALYTICSSESSIONSTATE_T61CA873937E9A3B881B71B32F518A954A4C8F267_H
#define ANALYTICSSESSIONSTATE_T61CA873937E9A3B881B71B32F518A954A4C8F267_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Analytics.AnalyticsSessionState
struct  AnalyticsSessionState_t61CA873937E9A3B881B71B32F518A954A4C8F267 
{
public:
	// System.Int32 UnityEngine.Analytics.AnalyticsSessionState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(AnalyticsSessionState_t61CA873937E9A3B881B71B32F518A954A4C8F267, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ANALYTICSSESSIONSTATE_T61CA873937E9A3B881B71B32F518A954A4C8F267_H
#ifndef VFXEVENTATTRIBUTE_T8FE74C5425505C55B4F79299C569CCE1A47BE325_H
#define VFXEVENTATTRIBUTE_T8FE74C5425505C55B4F79299C569CCE1A47BE325_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.VFX.VFXEventAttribute
struct  VFXEventAttribute_t8FE74C5425505C55B4F79299C569CCE1A47BE325  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Experimental.VFX.VFXEventAttribute::m_Ptr
	intptr_t ___m_Ptr_0;
	// System.Boolean UnityEngine.Experimental.VFX.VFXEventAttribute::m_Owner
	bool ___m_Owner_1;

public:
	inline static int32_t get_offset_of_m_Ptr_0() { return static_cast<int32_t>(offsetof(VFXEventAttribute_t8FE74C5425505C55B4F79299C569CCE1A47BE325, ___m_Ptr_0)); }
	inline intptr_t get_m_Ptr_0() const { return ___m_Ptr_0; }
	inline intptr_t* get_address_of_m_Ptr_0() { return &___m_Ptr_0; }
	inline void set_m_Ptr_0(intptr_t value)
	{
		___m_Ptr_0 = value;
	}

	inline static int32_t get_offset_of_m_Owner_1() { return static_cast<int32_t>(offsetof(VFXEventAttribute_t8FE74C5425505C55B4F79299C569CCE1A47BE325, ___m_Owner_1)); }
	inline bool get_m_Owner_1() const { return ___m_Owner_1; }
	inline bool* get_address_of_m_Owner_1() { return &___m_Owner_1; }
	inline void set_m_Owner_1(bool value)
	{
		___m_Owner_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Experimental.VFX.VFXEventAttribute
struct VFXEventAttribute_t8FE74C5425505C55B4F79299C569CCE1A47BE325_marshaled_pinvoke
{
	intptr_t ___m_Ptr_0;
	int32_t ___m_Owner_1;
};
// Native definition for COM marshalling of UnityEngine.Experimental.VFX.VFXEventAttribute
struct VFXEventAttribute_t8FE74C5425505C55B4F79299C569CCE1A47BE325_marshaled_com
{
	intptr_t ___m_Ptr_0;
	int32_t ___m_Owner_1;
};
#endif // VFXEVENTATTRIBUTE_T8FE74C5425505C55B4F79299C569CCE1A47BE325_H
#ifndef VFXEXPRESSIONVALUES_TBEEC793A9CD5134400899D1AAE1ABF13AF6562F2_H
#define VFXEXPRESSIONVALUES_TBEEC793A9CD5134400899D1AAE1ABF13AF6562F2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.VFX.VFXExpressionValues
struct  VFXExpressionValues_tBEEC793A9CD5134400899D1AAE1ABF13AF6562F2  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Experimental.VFX.VFXExpressionValues::m_Ptr
	intptr_t ___m_Ptr_0;

public:
	inline static int32_t get_offset_of_m_Ptr_0() { return static_cast<int32_t>(offsetof(VFXExpressionValues_tBEEC793A9CD5134400899D1AAE1ABF13AF6562F2, ___m_Ptr_0)); }
	inline intptr_t get_m_Ptr_0() const { return ___m_Ptr_0; }
	inline intptr_t* get_address_of_m_Ptr_0() { return &___m_Ptr_0; }
	inline void set_m_Ptr_0(intptr_t value)
	{
		___m_Ptr_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Experimental.VFX.VFXExpressionValues
struct VFXExpressionValues_tBEEC793A9CD5134400899D1AAE1ABF13AF6562F2_marshaled_pinvoke
{
	intptr_t ___m_Ptr_0;
};
// Native definition for COM marshalling of UnityEngine.Experimental.VFX.VFXExpressionValues
struct VFXExpressionValues_tBEEC793A9CD5134400899D1AAE1ABF13AF6562F2_marshaled_com
{
	intptr_t ___m_Ptr_0;
};
#endif // VFXEXPRESSIONVALUES_TBEEC793A9CD5134400899D1AAE1ABF13AF6562F2_H
#ifndef VFXSPAWNERSTATE_T614A1AADC2EDB20E82A625BE053A22DB31D89AC7_H
#define VFXSPAWNERSTATE_T614A1AADC2EDB20E82A625BE053A22DB31D89AC7_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.VFX.VFXSpawnerState
struct  VFXSpawnerState_t614A1AADC2EDB20E82A625BE053A22DB31D89AC7  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Experimental.VFX.VFXSpawnerState::m_Ptr
	intptr_t ___m_Ptr_0;
	// System.Boolean UnityEngine.Experimental.VFX.VFXSpawnerState::m_Owner
	bool ___m_Owner_1;

public:
	inline static int32_t get_offset_of_m_Ptr_0() { return static_cast<int32_t>(offsetof(VFXSpawnerState_t614A1AADC2EDB20E82A625BE053A22DB31D89AC7, ___m_Ptr_0)); }
	inline intptr_t get_m_Ptr_0() const { return ___m_Ptr_0; }
	inline intptr_t* get_address_of_m_Ptr_0() { return &___m_Ptr_0; }
	inline void set_m_Ptr_0(intptr_t value)
	{
		___m_Ptr_0 = value;
	}

	inline static int32_t get_offset_of_m_Owner_1() { return static_cast<int32_t>(offsetof(VFXSpawnerState_t614A1AADC2EDB20E82A625BE053A22DB31D89AC7, ___m_Owner_1)); }
	inline bool get_m_Owner_1() const { return ___m_Owner_1; }
	inline bool* get_address_of_m_Owner_1() { return &___m_Owner_1; }
	inline void set_m_Owner_1(bool value)
	{
		___m_Owner_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Experimental.VFX.VFXSpawnerState
struct VFXSpawnerState_t614A1AADC2EDB20E82A625BE053A22DB31D89AC7_marshaled_pinvoke
{
	intptr_t ___m_Ptr_0;
	int32_t ___m_Owner_1;
};
// Native definition for COM marshalling of UnityEngine.Experimental.VFX.VFXSpawnerState
struct VFXSpawnerState_t614A1AADC2EDB20E82A625BE053A22DB31D89AC7_marshaled_com
{
	intptr_t ___m_Ptr_0;
	int32_t ___m_Owner_1;
};
#endif // VFXSPAWNERSTATE_T614A1AADC2EDB20E82A625BE053A22DB31D89AC7_H
#ifndef CERTIFICATEHANDLER_TBD070BF4150A44AB482FD36EA3882C363117E8C0_H
#define CERTIFICATEHANDLER_TBD070BF4150A44AB482FD36EA3882C363117E8C0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Networking.CertificateHandler
struct  CertificateHandler_tBD070BF4150A44AB482FD36EA3882C363117E8C0  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Networking.CertificateHandler::m_Ptr
	intptr_t ___m_Ptr_0;

public:
	inline static int32_t get_offset_of_m_Ptr_0() { return static_cast<int32_t>(offsetof(CertificateHandler_tBD070BF4150A44AB482FD36EA3882C363117E8C0, ___m_Ptr_0)); }
	inline intptr_t get_m_Ptr_0() const { return ___m_Ptr_0; }
	inline intptr_t* get_address_of_m_Ptr_0() { return &___m_Ptr_0; }
	inline void set_m_Ptr_0(intptr_t value)
	{
		___m_Ptr_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Networking.CertificateHandler
struct CertificateHandler_tBD070BF4150A44AB482FD36EA3882C363117E8C0_marshaled_pinvoke
{
	intptr_t ___m_Ptr_0;
};
// Native definition for COM marshalling of UnityEngine.Networking.CertificateHandler
struct CertificateHandler_tBD070BF4150A44AB482FD36EA3882C363117E8C0_marshaled_com
{
	intptr_t ___m_Ptr_0;
};
#endif // CERTIFICATEHANDLER_TBD070BF4150A44AB482FD36EA3882C363117E8C0_H
#ifndef OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#define OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Object
struct  Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};
#endif // OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#ifndef PLAYABLEHANDLE_T9D3B4E540D4413CED81DDD6A24C5373BEFA1D182_H
#define PLAYABLEHANDLE_T9D3B4E540D4413CED81DDD6A24C5373BEFA1D182_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Playables.PlayableHandle
struct  PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182 
{
public:
	// System.IntPtr UnityEngine.Playables.PlayableHandle::m_Handle
	intptr_t ___m_Handle_0;
	// System.UInt32 UnityEngine.Playables.PlayableHandle::m_Version
	uint32_t ___m_Version_1;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182, ___m_Handle_0)); }
	inline intptr_t get_m_Handle_0() const { return ___m_Handle_0; }
	inline intptr_t* get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(intptr_t value)
	{
		___m_Handle_0 = value;
	}

	inline static int32_t get_offset_of_m_Version_1() { return static_cast<int32_t>(offsetof(PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182, ___m_Version_1)); }
	inline uint32_t get_m_Version_1() const { return ___m_Version_1; }
	inline uint32_t* get_address_of_m_Version_1() { return &___m_Version_1; }
	inline void set_m_Version_1(uint32_t value)
	{
		___m_Version_1 = value;
	}
};

struct PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182_StaticFields
{
public:
	// UnityEngine.Playables.PlayableHandle UnityEngine.Playables.PlayableHandle::m_Null
	PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  ___m_Null_2;

public:
	inline static int32_t get_offset_of_m_Null_2() { return static_cast<int32_t>(offsetof(PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182_StaticFields, ___m_Null_2)); }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  get_m_Null_2() const { return ___m_Null_2; }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182 * get_address_of_m_Null_2() { return &___m_Null_2; }
	inline void set_m_Null_2(PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  value)
	{
		___m_Null_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLAYABLEHANDLE_T9D3B4E540D4413CED81DDD6A24C5373BEFA1D182_H
#ifndef REMOTECONFIGSETTINGS_T97154F5546B47CE72257CC2F0B677BDF696AEC4A_H
#define REMOTECONFIGSETTINGS_T97154F5546B47CE72257CC2F0B677BDF696AEC4A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RemoteConfigSettings
struct  RemoteConfigSettings_t97154F5546B47CE72257CC2F0B677BDF696AEC4A  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.RemoteConfigSettings::m_Ptr
	intptr_t ___m_Ptr_0;
	// System.Action`1<System.Boolean> UnityEngine.RemoteConfigSettings::Updated
	Action_1_tAA0F894C98302D68F7D5034E8104E9AB4763CCAD * ___Updated_1;

public:
	inline static int32_t get_offset_of_m_Ptr_0() { return static_cast<int32_t>(offsetof(RemoteConfigSettings_t97154F5546B47CE72257CC2F0B677BDF696AEC4A, ___m_Ptr_0)); }
	inline intptr_t get_m_Ptr_0() const { return ___m_Ptr_0; }
	inline intptr_t* get_address_of_m_Ptr_0() { return &___m_Ptr_0; }
	inline void set_m_Ptr_0(intptr_t value)
	{
		___m_Ptr_0 = value;
	}

	inline static int32_t get_offset_of_Updated_1() { return static_cast<int32_t>(offsetof(RemoteConfigSettings_t97154F5546B47CE72257CC2F0B677BDF696AEC4A, ___Updated_1)); }
	inline Action_1_tAA0F894C98302D68F7D5034E8104E9AB4763CCAD * get_Updated_1() const { return ___Updated_1; }
	inline Action_1_tAA0F894C98302D68F7D5034E8104E9AB4763CCAD ** get_address_of_Updated_1() { return &___Updated_1; }
	inline void set_Updated_1(Action_1_tAA0F894C98302D68F7D5034E8104E9AB4763CCAD * value)
	{
		___Updated_1 = value;
		Il2CppCodeGenWriteBarrier((&___Updated_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.RemoteConfigSettings
struct RemoteConfigSettings_t97154F5546B47CE72257CC2F0B677BDF696AEC4A_marshaled_pinvoke
{
	intptr_t ___m_Ptr_0;
	Il2CppMethodPointer ___Updated_1;
};
// Native definition for COM marshalling of UnityEngine.RemoteConfigSettings
struct RemoteConfigSettings_t97154F5546B47CE72257CC2F0B677BDF696AEC4A_marshaled_com
{
	intptr_t ___m_Ptr_0;
	Il2CppMethodPointer ___Updated_1;
};
#endif // REMOTECONFIGSETTINGS_T97154F5546B47CE72257CC2F0B677BDF696AEC4A_H
#ifndef RENDERMODE_TB54632E74CDC4A990E815EB8C3CC515D3A9E2F60_H
#define RENDERMODE_TB54632E74CDC4A990E815EB8C3CC515D3A9E2F60_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RenderMode
struct  RenderMode_tB54632E74CDC4A990E815EB8C3CC515D3A9E2F60 
{
public:
	// System.Int32 UnityEngine.RenderMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(RenderMode_tB54632E74CDC4A990E815EB8C3CC515D3A9E2F60, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RENDERMODE_TB54632E74CDC4A990E815EB8C3CC515D3A9E2F60_H
#ifndef COLLIDERTYPE_TCF48B308BF04CE1D262A726D500126E8C8859F2B_H
#define COLLIDERTYPE_TCF48B308BF04CE1D262A726D500126E8C8859F2B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Tilemaps.Tile_ColliderType
struct  ColliderType_tCF48B308BF04CE1D262A726D500126E8C8859F2B 
{
public:
	// System.Int32 UnityEngine.Tilemaps.Tile_ColliderType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ColliderType_tCF48B308BF04CE1D262A726D500126E8C8859F2B, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLLIDERTYPE_TCF48B308BF04CE1D262A726D500126E8C8859F2B_H
#ifndef TILEFLAGS_TBD601639E3CC4B4BA675548F3B8F17B709A974AF_H
#define TILEFLAGS_TBD601639E3CC4B4BA675548F3B8F17B709A974AF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Tilemaps.TileFlags
struct  TileFlags_tBD601639E3CC4B4BA675548F3B8F17B709A974AF 
{
public:
	// System.Int32 UnityEngine.Tilemaps.TileFlags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(TileFlags_tBD601639E3CC4B4BA675548F3B8F17B709A974AF, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TILEFLAGS_TBD601639E3CC4B4BA675548F3B8F17B709A974AF_H
#ifndef SAMPLETYPE_T2144AEAF3447ACAFCE1C13AF669F63192F8E75EC_H
#define SAMPLETYPE_T2144AEAF3447ACAFCE1C13AF669F63192F8E75EC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UISystemProfilerApi_SampleType
struct  SampleType_t2144AEAF3447ACAFCE1C13AF669F63192F8E75EC 
{
public:
	// System.Int32 UnityEngine.UISystemProfilerApi_SampleType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(SampleType_t2144AEAF3447ACAFCE1C13AF669F63192F8E75EC, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SAMPLETYPE_T2144AEAF3447ACAFCE1C13AF669F63192F8E75EC_H
#ifndef VIDEO3DLAYOUT_T5F64D0CE5E9B37C2FCE67F397FA5CFE9C047E4A1_H
#define VIDEO3DLAYOUT_T5F64D0CE5E9B37C2FCE67F397FA5CFE9C047E4A1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Video.Video3DLayout
struct  Video3DLayout_t5F64D0CE5E9B37C2FCE67F397FA5CFE9C047E4A1 
{
public:
	// System.Int32 UnityEngine.Video.Video3DLayout::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Video3DLayout_t5F64D0CE5E9B37C2FCE67F397FA5CFE9C047E4A1, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEO3DLAYOUT_T5F64D0CE5E9B37C2FCE67F397FA5CFE9C047E4A1_H
#ifndef VIDEOASPECTRATIO_T5739968D28C4F8F802B085E293F22110205B8379_H
#define VIDEOASPECTRATIO_T5739968D28C4F8F802B085E293F22110205B8379_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Video.VideoAspectRatio
struct  VideoAspectRatio_t5739968D28C4F8F802B085E293F22110205B8379 
{
public:
	// System.Int32 UnityEngine.Video.VideoAspectRatio::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(VideoAspectRatio_t5739968D28C4F8F802B085E293F22110205B8379, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEOASPECTRATIO_T5739968D28C4F8F802B085E293F22110205B8379_H
#ifndef VIDEOAUDIOOUTPUTMODE_T8CDE10B382F3C321345EC57C9164A9177139DC6F_H
#define VIDEOAUDIOOUTPUTMODE_T8CDE10B382F3C321345EC57C9164A9177139DC6F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Video.VideoAudioOutputMode
struct  VideoAudioOutputMode_t8CDE10B382F3C321345EC57C9164A9177139DC6F 
{
public:
	// System.Int32 UnityEngine.Video.VideoAudioOutputMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(VideoAudioOutputMode_t8CDE10B382F3C321345EC57C9164A9177139DC6F, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEOAUDIOOUTPUTMODE_T8CDE10B382F3C321345EC57C9164A9177139DC6F_H
#ifndef VIDEORENDERMODE_T0DBAABB576FDA890C49C6AD3EE641623F93E9161_H
#define VIDEORENDERMODE_T0DBAABB576FDA890C49C6AD3EE641623F93E9161_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Video.VideoRenderMode
struct  VideoRenderMode_t0DBAABB576FDA890C49C6AD3EE641623F93E9161 
{
public:
	// System.Int32 UnityEngine.Video.VideoRenderMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(VideoRenderMode_t0DBAABB576FDA890C49C6AD3EE641623F93E9161, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEORENDERMODE_T0DBAABB576FDA890C49C6AD3EE641623F93E9161_H
#ifndef VIDEOSOURCE_T32501B57EA7F9CF835FBA8184C9AF427CBBEFD0A_H
#define VIDEOSOURCE_T32501B57EA7F9CF835FBA8184C9AF427CBBEFD0A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Video.VideoSource
struct  VideoSource_t32501B57EA7F9CF835FBA8184C9AF427CBBEFD0A 
{
public:
	// System.Int32 UnityEngine.Video.VideoSource::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(VideoSource_t32501B57EA7F9CF835FBA8184C9AF427CBBEFD0A, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEOSOURCE_T32501B57EA7F9CF835FBA8184C9AF427CBBEFD0A_H
#ifndef VIDEOTIMEREFERENCE_T9EAEBD354AE5E56F0D0F36E73A428BB2A0B8B31B_H
#define VIDEOTIMEREFERENCE_T9EAEBD354AE5E56F0D0F36E73A428BB2A0B8B31B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Video.VideoTimeReference
struct  VideoTimeReference_t9EAEBD354AE5E56F0D0F36E73A428BB2A0B8B31B 
{
public:
	// System.Int32 UnityEngine.Video.VideoTimeReference::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(VideoTimeReference_t9EAEBD354AE5E56F0D0F36E73A428BB2A0B8B31B, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEOTIMEREFERENCE_T9EAEBD354AE5E56F0D0F36E73A428BB2A0B8B31B_H
#ifndef VIDEOTIMESOURCE_T15F04FD6B3D75A8D98480E8B77117C0FF691BB77_H
#define VIDEOTIMESOURCE_T15F04FD6B3D75A8D98480E8B77117C0FF691BB77_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Video.VideoTimeSource
struct  VideoTimeSource_t15F04FD6B3D75A8D98480E8B77117C0FF691BB77 
{
public:
	// System.Int32 UnityEngine.Video.VideoTimeSource::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(VideoTimeSource_t15F04FD6B3D75A8D98480E8B77117C0FF691BB77, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEOTIMESOURCE_T15F04FD6B3D75A8D98480E8B77117C0FF691BB77_H
#ifndef YOGAMEASUREMODE_T29AF57E74BCD4C16019B8BE88A317D54DA70C29F_H
#define YOGAMEASUREMODE_T29AF57E74BCD4C16019B8BE88A317D54DA70C29F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Yoga.YogaMeasureMode
struct  YogaMeasureMode_t29AF57E74BCD4C16019B8BE88A317D54DA70C29F 
{
public:
	// System.Int32 UnityEngine.Yoga.YogaMeasureMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(YogaMeasureMode_t29AF57E74BCD4C16019B8BE88A317D54DA70C29F, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // YOGAMEASUREMODE_T29AF57E74BCD4C16019B8BE88A317D54DA70C29F_H
#ifndef YOGANODE_TFCB801A447DAC7A335C686ABC5941A4357102A2C_H
#define YOGANODE_TFCB801A447DAC7A335C686ABC5941A4357102A2C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Yoga.YogaNode
struct  YogaNode_tFCB801A447DAC7A335C686ABC5941A4357102A2C  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Yoga.YogaNode::_ygNode
	intptr_t ____ygNode_0;
	// System.Collections.Generic.List`1<UnityEngine.Yoga.YogaNode> UnityEngine.Yoga.YogaNode::_children
	List_1_tC208E7A364FF0C3FDC57107BD002A16939F7EE92 * ____children_1;
	// UnityEngine.Yoga.MeasureFunction UnityEngine.Yoga.YogaNode::_measureFunction
	MeasureFunction_tC5585E81380F4017044CE57AE21E178BAE2607AB * ____measureFunction_2;
	// UnityEngine.Yoga.BaselineFunction UnityEngine.Yoga.YogaNode::_baselineFunction
	BaselineFunction_t0A87479762FB382A84709009E9B6DCC597C6C9DF * ____baselineFunction_3;

public:
	inline static int32_t get_offset_of__ygNode_0() { return static_cast<int32_t>(offsetof(YogaNode_tFCB801A447DAC7A335C686ABC5941A4357102A2C, ____ygNode_0)); }
	inline intptr_t get__ygNode_0() const { return ____ygNode_0; }
	inline intptr_t* get_address_of__ygNode_0() { return &____ygNode_0; }
	inline void set__ygNode_0(intptr_t value)
	{
		____ygNode_0 = value;
	}

	inline static int32_t get_offset_of__children_1() { return static_cast<int32_t>(offsetof(YogaNode_tFCB801A447DAC7A335C686ABC5941A4357102A2C, ____children_1)); }
	inline List_1_tC208E7A364FF0C3FDC57107BD002A16939F7EE92 * get__children_1() const { return ____children_1; }
	inline List_1_tC208E7A364FF0C3FDC57107BD002A16939F7EE92 ** get_address_of__children_1() { return &____children_1; }
	inline void set__children_1(List_1_tC208E7A364FF0C3FDC57107BD002A16939F7EE92 * value)
	{
		____children_1 = value;
		Il2CppCodeGenWriteBarrier((&____children_1), value);
	}

	inline static int32_t get_offset_of__measureFunction_2() { return static_cast<int32_t>(offsetof(YogaNode_tFCB801A447DAC7A335C686ABC5941A4357102A2C, ____measureFunction_2)); }
	inline MeasureFunction_tC5585E81380F4017044CE57AE21E178BAE2607AB * get__measureFunction_2() const { return ____measureFunction_2; }
	inline MeasureFunction_tC5585E81380F4017044CE57AE21E178BAE2607AB ** get_address_of__measureFunction_2() { return &____measureFunction_2; }
	inline void set__measureFunction_2(MeasureFunction_tC5585E81380F4017044CE57AE21E178BAE2607AB * value)
	{
		____measureFunction_2 = value;
		Il2CppCodeGenWriteBarrier((&____measureFunction_2), value);
	}

	inline static int32_t get_offset_of__baselineFunction_3() { return static_cast<int32_t>(offsetof(YogaNode_tFCB801A447DAC7A335C686ABC5941A4357102A2C, ____baselineFunction_3)); }
	inline BaselineFunction_t0A87479762FB382A84709009E9B6DCC597C6C9DF * get__baselineFunction_3() const { return ____baselineFunction_3; }
	inline BaselineFunction_t0A87479762FB382A84709009E9B6DCC597C6C9DF ** get_address_of__baselineFunction_3() { return &____baselineFunction_3; }
	inline void set__baselineFunction_3(BaselineFunction_t0A87479762FB382A84709009E9B6DCC597C6C9DF * value)
	{
		____baselineFunction_3 = value;
		Il2CppCodeGenWriteBarrier((&____baselineFunction_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // YOGANODE_TFCB801A447DAC7A335C686ABC5941A4357102A2C_H
#ifndef AWEBRTCCALL_T8643A5C98F146CCA1CACDB911820319270507AD3_H
#define AWEBRTCCALL_T8643A5C98F146CCA1CACDB911820319270507AD3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.AWebRtcCall
struct  AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3  : public RuntimeObject
{
public:
	// Byn.Awrtc.NetworkConfig Byn.Awrtc.Base.AWebRtcCall::mNetworkConfig
	NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * ___mNetworkConfig_1;
	// Byn.Awrtc.MediaConfig Byn.Awrtc.Base.AWebRtcCall::mMediaConfig
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___mMediaConfig_2;
	// Byn.Awrtc.CallEventHandler Byn.Awrtc.Base.AWebRtcCall::CallEvent
	CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * ___CallEvent_3;
	// Byn.Awrtc.IMediaNetwork Byn.Awrtc.Base.AWebRtcCall::mNetwork
	RuntimeObject* ___mNetwork_4;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mConferenceMode
	bool ___mConferenceMode_5;
	// Byn.Awrtc.Base.AWebRtcCall_CallState Byn.Awrtc.Base.AWebRtcCall::mState
	int32_t ___mState_8;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mIsDisposed
	bool ___mIsDisposed_9;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mLocalFrameEvents
	bool ___mLocalFrameEvents_10;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mServerInactive
	bool ___mServerInactive_11;
	// System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId> Byn.Awrtc.Base.AWebRtcCall::mConnectionIds
	List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * ___mConnectionIds_12;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mPendingListenCall
	bool ___mPendingListenCall_13;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mPendingCallCall
	bool ___mPendingCallCall_14;
	// System.String Byn.Awrtc.Base.AWebRtcCall::mPendingAddress
	String_t* ___mPendingAddress_15;

public:
	inline static int32_t get_offset_of_mNetworkConfig_1() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mNetworkConfig_1)); }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * get_mNetworkConfig_1() const { return ___mNetworkConfig_1; }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 ** get_address_of_mNetworkConfig_1() { return &___mNetworkConfig_1; }
	inline void set_mNetworkConfig_1(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * value)
	{
		___mNetworkConfig_1 = value;
		Il2CppCodeGenWriteBarrier((&___mNetworkConfig_1), value);
	}

	inline static int32_t get_offset_of_mMediaConfig_2() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mMediaConfig_2)); }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * get_mMediaConfig_2() const { return ___mMediaConfig_2; }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D ** get_address_of_mMediaConfig_2() { return &___mMediaConfig_2; }
	inline void set_mMediaConfig_2(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * value)
	{
		___mMediaConfig_2 = value;
		Il2CppCodeGenWriteBarrier((&___mMediaConfig_2), value);
	}

	inline static int32_t get_offset_of_CallEvent_3() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___CallEvent_3)); }
	inline CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * get_CallEvent_3() const { return ___CallEvent_3; }
	inline CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F ** get_address_of_CallEvent_3() { return &___CallEvent_3; }
	inline void set_CallEvent_3(CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * value)
	{
		___CallEvent_3 = value;
		Il2CppCodeGenWriteBarrier((&___CallEvent_3), value);
	}

	inline static int32_t get_offset_of_mNetwork_4() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mNetwork_4)); }
	inline RuntimeObject* get_mNetwork_4() const { return ___mNetwork_4; }
	inline RuntimeObject** get_address_of_mNetwork_4() { return &___mNetwork_4; }
	inline void set_mNetwork_4(RuntimeObject* value)
	{
		___mNetwork_4 = value;
		Il2CppCodeGenWriteBarrier((&___mNetwork_4), value);
	}

	inline static int32_t get_offset_of_mConferenceMode_5() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mConferenceMode_5)); }
	inline bool get_mConferenceMode_5() const { return ___mConferenceMode_5; }
	inline bool* get_address_of_mConferenceMode_5() { return &___mConferenceMode_5; }
	inline void set_mConferenceMode_5(bool value)
	{
		___mConferenceMode_5 = value;
	}

	inline static int32_t get_offset_of_mState_8() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mState_8)); }
	inline int32_t get_mState_8() const { return ___mState_8; }
	inline int32_t* get_address_of_mState_8() { return &___mState_8; }
	inline void set_mState_8(int32_t value)
	{
		___mState_8 = value;
	}

	inline static int32_t get_offset_of_mIsDisposed_9() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mIsDisposed_9)); }
	inline bool get_mIsDisposed_9() const { return ___mIsDisposed_9; }
	inline bool* get_address_of_mIsDisposed_9() { return &___mIsDisposed_9; }
	inline void set_mIsDisposed_9(bool value)
	{
		___mIsDisposed_9 = value;
	}

	inline static int32_t get_offset_of_mLocalFrameEvents_10() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mLocalFrameEvents_10)); }
	inline bool get_mLocalFrameEvents_10() const { return ___mLocalFrameEvents_10; }
	inline bool* get_address_of_mLocalFrameEvents_10() { return &___mLocalFrameEvents_10; }
	inline void set_mLocalFrameEvents_10(bool value)
	{
		___mLocalFrameEvents_10 = value;
	}

	inline static int32_t get_offset_of_mServerInactive_11() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mServerInactive_11)); }
	inline bool get_mServerInactive_11() const { return ___mServerInactive_11; }
	inline bool* get_address_of_mServerInactive_11() { return &___mServerInactive_11; }
	inline void set_mServerInactive_11(bool value)
	{
		___mServerInactive_11 = value;
	}

	inline static int32_t get_offset_of_mConnectionIds_12() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mConnectionIds_12)); }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * get_mConnectionIds_12() const { return ___mConnectionIds_12; }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 ** get_address_of_mConnectionIds_12() { return &___mConnectionIds_12; }
	inline void set_mConnectionIds_12(List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * value)
	{
		___mConnectionIds_12 = value;
		Il2CppCodeGenWriteBarrier((&___mConnectionIds_12), value);
	}

	inline static int32_t get_offset_of_mPendingListenCall_13() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mPendingListenCall_13)); }
	inline bool get_mPendingListenCall_13() const { return ___mPendingListenCall_13; }
	inline bool* get_address_of_mPendingListenCall_13() { return &___mPendingListenCall_13; }
	inline void set_mPendingListenCall_13(bool value)
	{
		___mPendingListenCall_13 = value;
	}

	inline static int32_t get_offset_of_mPendingCallCall_14() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mPendingCallCall_14)); }
	inline bool get_mPendingCallCall_14() const { return ___mPendingCallCall_14; }
	inline bool* get_address_of_mPendingCallCall_14() { return &___mPendingCallCall_14; }
	inline void set_mPendingCallCall_14(bool value)
	{
		___mPendingCallCall_14 = value;
	}

	inline static int32_t get_offset_of_mPendingAddress_15() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mPendingAddress_15)); }
	inline String_t* get_mPendingAddress_15() const { return ___mPendingAddress_15; }
	inline String_t** get_address_of_mPendingAddress_15() { return &___mPendingAddress_15; }
	inline void set_mPendingAddress_15(String_t* value)
	{
		___mPendingAddress_15 = value;
		Il2CppCodeGenWriteBarrier((&___mPendingAddress_15), value);
	}
};

struct AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields
{
public:
	// System.String Byn.Awrtc.Base.AWebRtcCall::LOGTAG
	String_t* ___LOGTAG_0;
	// System.Byte Byn.Awrtc.Base.AWebRtcCall::MESSAGE_TYPE_DATA
	uint8_t ___MESSAGE_TYPE_DATA_6;
	// System.Byte Byn.Awrtc.Base.AWebRtcCall::MESSAGE_TYPE_STRING
	uint8_t ___MESSAGE_TYPE_STRING_7;

public:
	inline static int32_t get_offset_of_LOGTAG_0() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields, ___LOGTAG_0)); }
	inline String_t* get_LOGTAG_0() const { return ___LOGTAG_0; }
	inline String_t** get_address_of_LOGTAG_0() { return &___LOGTAG_0; }
	inline void set_LOGTAG_0(String_t* value)
	{
		___LOGTAG_0 = value;
		Il2CppCodeGenWriteBarrier((&___LOGTAG_0), value);
	}

	inline static int32_t get_offset_of_MESSAGE_TYPE_DATA_6() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields, ___MESSAGE_TYPE_DATA_6)); }
	inline uint8_t get_MESSAGE_TYPE_DATA_6() const { return ___MESSAGE_TYPE_DATA_6; }
	inline uint8_t* get_address_of_MESSAGE_TYPE_DATA_6() { return &___MESSAGE_TYPE_DATA_6; }
	inline void set_MESSAGE_TYPE_DATA_6(uint8_t value)
	{
		___MESSAGE_TYPE_DATA_6 = value;
	}

	inline static int32_t get_offset_of_MESSAGE_TYPE_STRING_7() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields, ___MESSAGE_TYPE_STRING_7)); }
	inline uint8_t get_MESSAGE_TYPE_STRING_7() const { return ___MESSAGE_TYPE_STRING_7; }
	inline uint8_t* get_address_of_MESSAGE_TYPE_STRING_7() { return &___MESSAGE_TYPE_STRING_7; }
	inline void set_MESSAGE_TYPE_STRING_7(uint8_t value)
	{
		___MESSAGE_TYPE_STRING_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AWEBRTCCALL_T8643A5C98F146CCA1CACDB911820319270507AD3_H
#ifndef CALLEVENTARGS_T818567BF1A3D4FFC096A4A4018C229D78D8ECFC0_H
#define CALLEVENTARGS_T818567BF1A3D4FFC096A4A4018C229D78D8ECFC0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.CallEventArgs
struct  CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0  : public RuntimeObject
{
public:
	// Byn.Awrtc.CallEventType Byn.Awrtc.CallEventArgs::mType
	int32_t ___mType_0;

public:
	inline static int32_t get_offset_of_mType_0() { return static_cast<int32_t>(offsetof(CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0, ___mType_0)); }
	inline int32_t get_mType_0() const { return ___mType_0; }
	inline int32_t* get_address_of_mType_0() { return &___mType_0; }
	inline void set_mType_0(int32_t value)
	{
		___mType_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLEVENTARGS_T818567BF1A3D4FFC096A4A4018C229D78D8ECFC0_H
#ifndef MEDIACONFIG_T27C1D9728366F53BC7E49A1E16B020363B3A304D_H
#define MEDIACONFIG_T27C1D9728366F53BC7E49A1E16B020363B3A304D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.MediaConfig
struct  MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D  : public RuntimeObject
{
public:
	// System.Boolean Byn.Awrtc.MediaConfig::mAudio
	bool ___mAudio_0;
	// System.Boolean Byn.Awrtc.MediaConfig::mVideo
	bool ___mVideo_1;
	// System.String Byn.Awrtc.MediaConfig::mVideoDeviceName
	String_t* ___mVideoDeviceName_2;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMinWidth
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMinWidth_3;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMinHeight
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMinHeight_4;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMaxWidth
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMaxWidth_5;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMaxHeight
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMaxHeight_6;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mIdealWidth
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mIdealWidth_7;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mIdealHeight
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mIdealHeight_8;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mIdealFrameRate
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mIdealFrameRate_9;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMinFrameRate
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMinFrameRate_10;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMaxFrameRate
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMaxFrameRate_11;
	// Byn.Awrtc.FramePixelFormat Byn.Awrtc.MediaConfig::mFormat
	int32_t ___mFormat_12;

public:
	inline static int32_t get_offset_of_mAudio_0() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mAudio_0)); }
	inline bool get_mAudio_0() const { return ___mAudio_0; }
	inline bool* get_address_of_mAudio_0() { return &___mAudio_0; }
	inline void set_mAudio_0(bool value)
	{
		___mAudio_0 = value;
	}

	inline static int32_t get_offset_of_mVideo_1() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mVideo_1)); }
	inline bool get_mVideo_1() const { return ___mVideo_1; }
	inline bool* get_address_of_mVideo_1() { return &___mVideo_1; }
	inline void set_mVideo_1(bool value)
	{
		___mVideo_1 = value;
	}

	inline static int32_t get_offset_of_mVideoDeviceName_2() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mVideoDeviceName_2)); }
	inline String_t* get_mVideoDeviceName_2() const { return ___mVideoDeviceName_2; }
	inline String_t** get_address_of_mVideoDeviceName_2() { return &___mVideoDeviceName_2; }
	inline void set_mVideoDeviceName_2(String_t* value)
	{
		___mVideoDeviceName_2 = value;
		Il2CppCodeGenWriteBarrier((&___mVideoDeviceName_2), value);
	}

	inline static int32_t get_offset_of_mMinWidth_3() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMinWidth_3)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMinWidth_3() const { return ___mMinWidth_3; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMinWidth_3() { return &___mMinWidth_3; }
	inline void set_mMinWidth_3(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMinWidth_3 = value;
	}

	inline static int32_t get_offset_of_mMinHeight_4() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMinHeight_4)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMinHeight_4() const { return ___mMinHeight_4; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMinHeight_4() { return &___mMinHeight_4; }
	inline void set_mMinHeight_4(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMinHeight_4 = value;
	}

	inline static int32_t get_offset_of_mMaxWidth_5() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMaxWidth_5)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMaxWidth_5() const { return ___mMaxWidth_5; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMaxWidth_5() { return &___mMaxWidth_5; }
	inline void set_mMaxWidth_5(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMaxWidth_5 = value;
	}

	inline static int32_t get_offset_of_mMaxHeight_6() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMaxHeight_6)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMaxHeight_6() const { return ___mMaxHeight_6; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMaxHeight_6() { return &___mMaxHeight_6; }
	inline void set_mMaxHeight_6(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMaxHeight_6 = value;
	}

	inline static int32_t get_offset_of_mIdealWidth_7() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mIdealWidth_7)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mIdealWidth_7() const { return ___mIdealWidth_7; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mIdealWidth_7() { return &___mIdealWidth_7; }
	inline void set_mIdealWidth_7(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mIdealWidth_7 = value;
	}

	inline static int32_t get_offset_of_mIdealHeight_8() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mIdealHeight_8)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mIdealHeight_8() const { return ___mIdealHeight_8; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mIdealHeight_8() { return &___mIdealHeight_8; }
	inline void set_mIdealHeight_8(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mIdealHeight_8 = value;
	}

	inline static int32_t get_offset_of_mIdealFrameRate_9() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mIdealFrameRate_9)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mIdealFrameRate_9() const { return ___mIdealFrameRate_9; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mIdealFrameRate_9() { return &___mIdealFrameRate_9; }
	inline void set_mIdealFrameRate_9(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mIdealFrameRate_9 = value;
	}

	inline static int32_t get_offset_of_mMinFrameRate_10() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMinFrameRate_10)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMinFrameRate_10() const { return ___mMinFrameRate_10; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMinFrameRate_10() { return &___mMinFrameRate_10; }
	inline void set_mMinFrameRate_10(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMinFrameRate_10 = value;
	}

	inline static int32_t get_offset_of_mMaxFrameRate_11() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMaxFrameRate_11)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMaxFrameRate_11() const { return ___mMaxFrameRate_11; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMaxFrameRate_11() { return &___mMaxFrameRate_11; }
	inline void set_mMaxFrameRate_11(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMaxFrameRate_11 = value;
	}

	inline static int32_t get_offset_of_mFormat_12() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mFormat_12)); }
	inline int32_t get_mFormat_12() const { return ___mFormat_12; }
	inline int32_t* get_address_of_mFormat_12() { return &___mFormat_12; }
	inline void set_mFormat_12(int32_t value)
	{
		___mFormat_12 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MEDIACONFIG_T27C1D9728366F53BC7E49A1E16B020363B3A304D_H
#ifndef NETWORKEVENT_T4DD89489B65D724D8D201A81F4243CF3CF96827C_H
#define NETWORKEVENT_T4DD89489B65D724D8D201A81F4243CF3CF96827C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.NetworkEvent
struct  NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C 
{
public:
	// Byn.Awrtc.NetEventType Byn.Awrtc.NetworkEvent::type
	uint8_t ___type_0;
	// Byn.Awrtc.ConnectionId Byn.Awrtc.NetworkEvent::connectionId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___connectionId_1;
	// System.Object Byn.Awrtc.NetworkEvent::data
	RuntimeObject * ___data_2;

public:
	inline static int32_t get_offset_of_type_0() { return static_cast<int32_t>(offsetof(NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C, ___type_0)); }
	inline uint8_t get_type_0() const { return ___type_0; }
	inline uint8_t* get_address_of_type_0() { return &___type_0; }
	inline void set_type_0(uint8_t value)
	{
		___type_0 = value;
	}

	inline static int32_t get_offset_of_connectionId_1() { return static_cast<int32_t>(offsetof(NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C, ___connectionId_1)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_connectionId_1() const { return ___connectionId_1; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_connectionId_1() { return &___connectionId_1; }
	inline void set_connectionId_1(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___connectionId_1 = value;
	}

	inline static int32_t get_offset_of_data_2() { return static_cast<int32_t>(offsetof(NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C, ___data_2)); }
	inline RuntimeObject * get_data_2() const { return ___data_2; }
	inline RuntimeObject ** get_address_of_data_2() { return &___data_2; }
	inline void set_data_2(RuntimeObject * value)
	{
		___data_2 = value;
		Il2CppCodeGenWriteBarrier((&___data_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of Byn.Awrtc.NetworkEvent
struct NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshaled_pinvoke
{
	uint8_t ___type_0;
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___connectionId_1;
	Il2CppIUnknown* ___data_2;
};
// Native definition for COM marshalling of Byn.Awrtc.NetworkEvent
struct NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshaled_com
{
	uint8_t ___type_0;
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___connectionId_1;
	Il2CppIUnknown* ___data_2;
};
#endif // NETWORKEVENT_T4DD89489B65D724D8D201A81F4243CF3CF96827C_H
#ifndef MULTICASTDELEGATE_T_H
#define MULTICASTDELEGATE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MulticastDelegate
struct  MulticastDelegate_t  : public Delegate_t
{
public:
	// System.Delegate[] System.MulticastDelegate::delegates
	DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* ___delegates_11;

public:
	inline static int32_t get_offset_of_delegates_11() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___delegates_11)); }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* get_delegates_11() const { return ___delegates_11; }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86** get_address_of_delegates_11() { return &___delegates_11; }
	inline void set_delegates_11(DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* value)
	{
		___delegates_11 = value;
		Il2CppCodeGenWriteBarrier((&___delegates_11), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_pinvoke : public Delegate_t_marshaled_pinvoke
{
	Delegate_t_marshaled_pinvoke** ___delegates_11;
};
// Native definition for COM marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_com : public Delegate_t_marshaled_com
{
	Delegate_t_marshaled_com** ___delegates_11;
};
#endif // MULTICASTDELEGATE_T_H
#ifndef COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#define COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Component
struct  Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#ifndef VIDEOCLIPPLAYABLE_T4B7997FDB02C74F9E88F37574F0F4F9DE08CCC12_H
#define VIDEOCLIPPLAYABLE_T4B7997FDB02C74F9E88F37574F0F4F9DE08CCC12_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.Video.VideoClipPlayable
struct  VideoClipPlayable_t4B7997FDB02C74F9E88F37574F0F4F9DE08CCC12 
{
public:
	// UnityEngine.Playables.PlayableHandle UnityEngine.Experimental.Video.VideoClipPlayable::m_Handle
	PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  ___m_Handle_0;

public:
	inline static int32_t get_offset_of_m_Handle_0() { return static_cast<int32_t>(offsetof(VideoClipPlayable_t4B7997FDB02C74F9E88F37574F0F4F9DE08CCC12, ___m_Handle_0)); }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  get_m_Handle_0() const { return ___m_Handle_0; }
	inline PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182 * get_address_of_m_Handle_0() { return &___m_Handle_0; }
	inline void set_m_Handle_0(PlayableHandle_t9D3B4E540D4413CED81DDD6A24C5373BEFA1D182  value)
	{
		___m_Handle_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEOCLIPPLAYABLE_T4B7997FDB02C74F9E88F37574F0F4F9DE08CCC12_H
#ifndef SCRIPTABLEOBJECT_TAB015486CEAB714DA0D5C1BA389B84FB90427734_H
#define SCRIPTABLEOBJECT_TAB015486CEAB714DA0D5C1BA389B84FB90427734_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.ScriptableObject
struct  ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734_marshaled_pinvoke : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
};
// Native definition for COM marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734_marshaled_com : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
};
#endif // SCRIPTABLEOBJECT_TAB015486CEAB714DA0D5C1BA389B84FB90427734_H
#ifndef TILEDATA_T8A50A35CAFD87C12E27D7E596D968C9114A4CBB5_H
#define TILEDATA_T8A50A35CAFD87C12E27D7E596D968C9114A4CBB5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Tilemaps.TileData
struct  TileData_t8A50A35CAFD87C12E27D7E596D968C9114A4CBB5 
{
public:
	// UnityEngine.Sprite UnityEngine.Tilemaps.TileData::m_Sprite
	Sprite_tCA09498D612D08DE668653AF1E9C12BF53434198 * ___m_Sprite_0;
	// UnityEngine.Color UnityEngine.Tilemaps.TileData::m_Color
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___m_Color_1;
	// UnityEngine.Matrix4x4 UnityEngine.Tilemaps.TileData::m_Transform
	Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  ___m_Transform_2;
	// UnityEngine.GameObject UnityEngine.Tilemaps.TileData::m_GameObject
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___m_GameObject_3;
	// UnityEngine.Tilemaps.TileFlags UnityEngine.Tilemaps.TileData::m_Flags
	int32_t ___m_Flags_4;
	// UnityEngine.Tilemaps.Tile_ColliderType UnityEngine.Tilemaps.TileData::m_ColliderType
	int32_t ___m_ColliderType_5;

public:
	inline static int32_t get_offset_of_m_Sprite_0() { return static_cast<int32_t>(offsetof(TileData_t8A50A35CAFD87C12E27D7E596D968C9114A4CBB5, ___m_Sprite_0)); }
	inline Sprite_tCA09498D612D08DE668653AF1E9C12BF53434198 * get_m_Sprite_0() const { return ___m_Sprite_0; }
	inline Sprite_tCA09498D612D08DE668653AF1E9C12BF53434198 ** get_address_of_m_Sprite_0() { return &___m_Sprite_0; }
	inline void set_m_Sprite_0(Sprite_tCA09498D612D08DE668653AF1E9C12BF53434198 * value)
	{
		___m_Sprite_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_Sprite_0), value);
	}

	inline static int32_t get_offset_of_m_Color_1() { return static_cast<int32_t>(offsetof(TileData_t8A50A35CAFD87C12E27D7E596D968C9114A4CBB5, ___m_Color_1)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_m_Color_1() const { return ___m_Color_1; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_m_Color_1() { return &___m_Color_1; }
	inline void set_m_Color_1(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___m_Color_1 = value;
	}

	inline static int32_t get_offset_of_m_Transform_2() { return static_cast<int32_t>(offsetof(TileData_t8A50A35CAFD87C12E27D7E596D968C9114A4CBB5, ___m_Transform_2)); }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  get_m_Transform_2() const { return ___m_Transform_2; }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA * get_address_of_m_Transform_2() { return &___m_Transform_2; }
	inline void set_m_Transform_2(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  value)
	{
		___m_Transform_2 = value;
	}

	inline static int32_t get_offset_of_m_GameObject_3() { return static_cast<int32_t>(offsetof(TileData_t8A50A35CAFD87C12E27D7E596D968C9114A4CBB5, ___m_GameObject_3)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_m_GameObject_3() const { return ___m_GameObject_3; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_m_GameObject_3() { return &___m_GameObject_3; }
	inline void set_m_GameObject_3(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___m_GameObject_3 = value;
		Il2CppCodeGenWriteBarrier((&___m_GameObject_3), value);
	}

	inline static int32_t get_offset_of_m_Flags_4() { return static_cast<int32_t>(offsetof(TileData_t8A50A35CAFD87C12E27D7E596D968C9114A4CBB5, ___m_Flags_4)); }
	inline int32_t get_m_Flags_4() const { return ___m_Flags_4; }
	inline int32_t* get_address_of_m_Flags_4() { return &___m_Flags_4; }
	inline void set_m_Flags_4(int32_t value)
	{
		___m_Flags_4 = value;
	}

	inline static int32_t get_offset_of_m_ColliderType_5() { return static_cast<int32_t>(offsetof(TileData_t8A50A35CAFD87C12E27D7E596D968C9114A4CBB5, ___m_ColliderType_5)); }
	inline int32_t get_m_ColliderType_5() const { return ___m_ColliderType_5; }
	inline int32_t* get_address_of_m_ColliderType_5() { return &___m_ColliderType_5; }
	inline void set_m_ColliderType_5(int32_t value)
	{
		___m_ColliderType_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Tilemaps.TileData
struct TileData_t8A50A35CAFD87C12E27D7E596D968C9114A4CBB5_marshaled_pinvoke
{
	Sprite_tCA09498D612D08DE668653AF1E9C12BF53434198 * ___m_Sprite_0;
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___m_Color_1;
	Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  ___m_Transform_2;
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___m_GameObject_3;
	int32_t ___m_Flags_4;
	int32_t ___m_ColliderType_5;
};
// Native definition for COM marshalling of UnityEngine.Tilemaps.TileData
struct TileData_t8A50A35CAFD87C12E27D7E596D968C9114A4CBB5_marshaled_com
{
	Sprite_tCA09498D612D08DE668653AF1E9C12BF53434198 * ___m_Sprite_0;
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___m_Color_1;
	Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  ___m_Transform_2;
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___m_GameObject_3;
	int32_t ___m_Flags_4;
	int32_t ___m_ColliderType_5;
};
#endif // TILEDATA_T8A50A35CAFD87C12E27D7E596D968C9114A4CBB5_H
#ifndef VIDEOCLIP_TA4039CBBC6F9C3AD62B067964A6C20C6FB7376D5_H
#define VIDEOCLIP_TA4039CBBC6F9C3AD62B067964A6C20C6FB7376D5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Video.VideoClip
struct  VideoClip_tA4039CBBC6F9C3AD62B067964A6C20C6FB7376D5  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEOCLIP_TA4039CBBC6F9C3AD62B067964A6C20C6FB7376D5_H
#ifndef CALLACCEPTEDEVENTARGS_T66A1A51D65180197BBA42227E68BF517AC6503DA_H
#define CALLACCEPTEDEVENTARGS_T66A1A51D65180197BBA42227E68BF517AC6503DA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.CallAcceptedEventArgs
struct  CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA  : public CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0
{
public:
	// Byn.Awrtc.ConnectionId Byn.Awrtc.CallAcceptedEventArgs::mConnectionId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mConnectionId_1;

public:
	inline static int32_t get_offset_of_mConnectionId_1() { return static_cast<int32_t>(offsetof(CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA, ___mConnectionId_1)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mConnectionId_1() const { return ___mConnectionId_1; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mConnectionId_1() { return &___mConnectionId_1; }
	inline void set_mConnectionId_1(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mConnectionId_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLACCEPTEDEVENTARGS_T66A1A51D65180197BBA42227E68BF517AC6503DA_H
#ifndef CALLENDEDEVENTARGS_TE3A3B50FDE883A4D052920EB6073028ACFF81128_H
#define CALLENDEDEVENTARGS_TE3A3B50FDE883A4D052920EB6073028ACFF81128_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.CallEndedEventArgs
struct  CallEndedEventArgs_tE3A3B50FDE883A4D052920EB6073028ACFF81128  : public CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0
{
public:
	// Byn.Awrtc.ConnectionId Byn.Awrtc.CallEndedEventArgs::mConnectionId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mConnectionId_1;

public:
	inline static int32_t get_offset_of_mConnectionId_1() { return static_cast<int32_t>(offsetof(CallEndedEventArgs_tE3A3B50FDE883A4D052920EB6073028ACFF81128, ___mConnectionId_1)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mConnectionId_1() const { return ___mConnectionId_1; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mConnectionId_1() { return &___mConnectionId_1; }
	inline void set_mConnectionId_1(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mConnectionId_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLENDEDEVENTARGS_TE3A3B50FDE883A4D052920EB6073028ACFF81128_H
#ifndef CALLEVENTHANDLER_TC9D919E3867CEBE6B3D26923028AB6E2A713387F_H
#define CALLEVENTHANDLER_TC9D919E3867CEBE6B3D26923028AB6E2A713387F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.CallEventHandler
struct  CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLEVENTHANDLER_TC9D919E3867CEBE6B3D26923028AB6E2A713387F_H
#ifndef DATAMESSAGEEVENTARGS_TB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37_H
#define DATAMESSAGEEVENTARGS_TB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.DataMessageEventArgs
struct  DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37  : public CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0
{
public:
	// Byn.Awrtc.ConnectionId Byn.Awrtc.DataMessageEventArgs::mConnectionId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mConnectionId_1;
	// System.Byte[] Byn.Awrtc.DataMessageEventArgs::mContent
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___mContent_2;
	// System.Boolean Byn.Awrtc.DataMessageEventArgs::mReliable
	bool ___mReliable_3;

public:
	inline static int32_t get_offset_of_mConnectionId_1() { return static_cast<int32_t>(offsetof(DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37, ___mConnectionId_1)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mConnectionId_1() const { return ___mConnectionId_1; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mConnectionId_1() { return &___mConnectionId_1; }
	inline void set_mConnectionId_1(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mConnectionId_1 = value;
	}

	inline static int32_t get_offset_of_mContent_2() { return static_cast<int32_t>(offsetof(DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37, ___mContent_2)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get_mContent_2() const { return ___mContent_2; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of_mContent_2() { return &___mContent_2; }
	inline void set_mContent_2(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		___mContent_2 = value;
		Il2CppCodeGenWriteBarrier((&___mContent_2), value);
	}

	inline static int32_t get_offset_of_mReliable_3() { return static_cast<int32_t>(offsetof(DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37, ___mReliable_3)); }
	inline bool get_mReliable_3() const { return ___mReliable_3; }
	inline bool* get_address_of_mReliable_3() { return &___mReliable_3; }
	inline void set_mReliable_3(bool value)
	{
		___mReliable_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DATAMESSAGEEVENTARGS_TB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37_H
#ifndef ERROREVENTARGS_T5A287854C72ED85A9C48B9F18F88C56475C02246_H
#define ERROREVENTARGS_T5A287854C72ED85A9C48B9F18F88C56475C02246_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.ErrorEventArgs
struct  ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246  : public CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0
{
public:
	// Byn.Awrtc.ErrorInfo Byn.Awrtc.ErrorEventArgs::mErrorInfo
	ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * ___mErrorInfo_1;

public:
	inline static int32_t get_offset_of_mErrorInfo_1() { return static_cast<int32_t>(offsetof(ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246, ___mErrorInfo_1)); }
	inline ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * get_mErrorInfo_1() const { return ___mErrorInfo_1; }
	inline ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 ** get_address_of_mErrorInfo_1() { return &___mErrorInfo_1; }
	inline void set_mErrorInfo_1(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * value)
	{
		___mErrorInfo_1 = value;
		Il2CppCodeGenWriteBarrier((&___mErrorInfo_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ERROREVENTARGS_T5A287854C72ED85A9C48B9F18F88C56475C02246_H
#ifndef FRAMEUPDATEEVENTARGS_T634A4325664A8B135DEB37E87967686C9690DE6C_H
#define FRAMEUPDATEEVENTARGS_T634A4325664A8B135DEB37E87967686C9690DE6C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.FrameUpdateEventArgs
struct  FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C  : public CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0
{
public:
	// Byn.Awrtc.FramePixelFormat Byn.Awrtc.FrameUpdateEventArgs::mFormat
	int32_t ___mFormat_1;
	// Byn.Awrtc.ConnectionId Byn.Awrtc.FrameUpdateEventArgs::mConnectionId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mConnectionId_2;
	// Byn.Awrtc.IFrame Byn.Awrtc.FrameUpdateEventArgs::mFrame
	RuntimeObject* ___mFrame_3;

public:
	inline static int32_t get_offset_of_mFormat_1() { return static_cast<int32_t>(offsetof(FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C, ___mFormat_1)); }
	inline int32_t get_mFormat_1() const { return ___mFormat_1; }
	inline int32_t* get_address_of_mFormat_1() { return &___mFormat_1; }
	inline void set_mFormat_1(int32_t value)
	{
		___mFormat_1 = value;
	}

	inline static int32_t get_offset_of_mConnectionId_2() { return static_cast<int32_t>(offsetof(FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C, ___mConnectionId_2)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mConnectionId_2() const { return ___mConnectionId_2; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mConnectionId_2() { return &___mConnectionId_2; }
	inline void set_mConnectionId_2(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mConnectionId_2 = value;
	}

	inline static int32_t get_offset_of_mFrame_3() { return static_cast<int32_t>(offsetof(FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C, ___mFrame_3)); }
	inline RuntimeObject* get_mFrame_3() const { return ___mFrame_3; }
	inline RuntimeObject** get_address_of_mFrame_3() { return &___mFrame_3; }
	inline void set_mFrame_3(RuntimeObject* value)
	{
		___mFrame_3 = value;
		Il2CppCodeGenWriteBarrier((&___mFrame_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FRAMEUPDATEEVENTARGS_T634A4325664A8B135DEB37E87967686C9690DE6C_H
#ifndef MESSAGEEVENTARGS_TB3C1E5D169AD3A3A277DADD79A5F098F53040899_H
#define MESSAGEEVENTARGS_TB3C1E5D169AD3A3A277DADD79A5F098F53040899_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.MessageEventArgs
struct  MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899  : public CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0
{
public:
	// Byn.Awrtc.ConnectionId Byn.Awrtc.MessageEventArgs::mConnectionId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mConnectionId_1;
	// System.Boolean Byn.Awrtc.MessageEventArgs::mReliable
	bool ___mReliable_2;
	// System.String Byn.Awrtc.MessageEventArgs::mContent
	String_t* ___mContent_3;

public:
	inline static int32_t get_offset_of_mConnectionId_1() { return static_cast<int32_t>(offsetof(MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899, ___mConnectionId_1)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mConnectionId_1() const { return ___mConnectionId_1; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mConnectionId_1() { return &___mConnectionId_1; }
	inline void set_mConnectionId_1(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mConnectionId_1 = value;
	}

	inline static int32_t get_offset_of_mReliable_2() { return static_cast<int32_t>(offsetof(MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899, ___mReliable_2)); }
	inline bool get_mReliable_2() const { return ___mReliable_2; }
	inline bool* get_address_of_mReliable_2() { return &___mReliable_2; }
	inline void set_mReliable_2(bool value)
	{
		___mReliable_2 = value;
	}

	inline static int32_t get_offset_of_mContent_3() { return static_cast<int32_t>(offsetof(MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899, ___mContent_3)); }
	inline String_t* get_mContent_3() const { return ___mContent_3; }
	inline String_t** get_address_of_mContent_3() { return &___mContent_3; }
	inline void set_mContent_3(String_t* value)
	{
		___mContent_3 = value;
		Il2CppCodeGenWriteBarrier((&___mContent_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MESSAGEEVENTARGS_TB3C1E5D169AD3A3A277DADD79A5F098F53040899_H
#ifndef WAITFORINCOMINGCALLEVENTARGS_TD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86_H
#define WAITFORINCOMINGCALLEVENTARGS_TD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.WaitForIncomingCallEventArgs
struct  WaitForIncomingCallEventArgs_tD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86  : public CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0
{
public:
	// System.String Byn.Awrtc.WaitForIncomingCallEventArgs::mAddress
	String_t* ___mAddress_1;

public:
	inline static int32_t get_offset_of_mAddress_1() { return static_cast<int32_t>(offsetof(WaitForIncomingCallEventArgs_tD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86, ___mAddress_1)); }
	inline String_t* get_mAddress_1() const { return ___mAddress_1; }
	inline String_t** get_address_of_mAddress_1() { return &___mAddress_1; }
	inline void set_mAddress_1(String_t* value)
	{
		___mAddress_1 = value;
		Il2CppCodeGenWriteBarrier((&___mAddress_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WAITFORINCOMINGCALLEVENTARGS_TD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86_H
#ifndef SESSIONSTATECHANGED_T9084549A636BD45086D66CC6765DA8C3DD31066F_H
#define SESSIONSTATECHANGED_T9084549A636BD45086D66CC6765DA8C3DD31066F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Analytics.AnalyticsSessionInfo_SessionStateChanged
struct  SessionStateChanged_t9084549A636BD45086D66CC6765DA8C3DD31066F  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SESSIONSTATECHANGED_T9084549A636BD45086D66CC6765DA8C3DD31066F_H
#ifndef BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#define BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Behaviour
struct  Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8  : public Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#ifndef WILLRENDERCANVASES_TBD5AD090B5938021DEAA679A5AEEA790F60A8BEE_H
#define WILLRENDERCANVASES_TBD5AD090B5938021DEAA679A5AEEA790F60A8BEE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Canvas_WillRenderCanvases
struct  WillRenderCanvases_tBD5AD090B5938021DEAA679A5AEEA790F60A8BEE  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WILLRENDERCANVASES_TBD5AD090B5938021DEAA679A5AEEA790F60A8BEE_H
#ifndef CANVASRENDERER_TB4D9C9FE77FD5C9C4546FC022D6E956960BC2B72_H
#define CANVASRENDERER_TB4D9C9FE77FD5C9C4546FC022D6E956960BC2B72_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.CanvasRenderer
struct  CanvasRenderer_tB4D9C9FE77FD5C9C4546FC022D6E956960BC2B72  : public Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621
{
public:
	// System.Boolean UnityEngine.CanvasRenderer::<isMask>k__BackingField
	bool ___U3CisMaskU3Ek__BackingField_4;

public:
	inline static int32_t get_offset_of_U3CisMaskU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(CanvasRenderer_tB4D9C9FE77FD5C9C4546FC022D6E956960BC2B72, ___U3CisMaskU3Ek__BackingField_4)); }
	inline bool get_U3CisMaskU3Ek__BackingField_4() const { return ___U3CisMaskU3Ek__BackingField_4; }
	inline bool* get_address_of_U3CisMaskU3Ek__BackingField_4() { return &___U3CisMaskU3Ek__BackingField_4; }
	inline void set_U3CisMaskU3Ek__BackingField_4(bool value)
	{
		___U3CisMaskU3Ek__BackingField_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CANVASRENDERER_TB4D9C9FE77FD5C9C4546FC022D6E956960BC2B72_H
#ifndef VFXSPAWNERCALLBACKS_T4A28725CC33298516D1479C1D2BFEC00034373A1_H
#define VFXSPAWNERCALLBACKS_T4A28725CC33298516D1479C1D2BFEC00034373A1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.VFX.VFXSpawnerCallbacks
struct  VFXSpawnerCallbacks_t4A28725CC33298516D1479C1D2BFEC00034373A1  : public ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VFXSPAWNERCALLBACKS_T4A28725CC33298516D1479C1D2BFEC00034373A1_H
#ifndef UPDATEDEVENTHANDLER_TB0230BC83686D7126AB4D3800A66351028CA514F_H
#define UPDATEDEVENTHANDLER_TB0230BC83686D7126AB4D3800A66351028CA514F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RemoteSettings_UpdatedEventHandler
struct  UpdatedEventHandler_tB0230BC83686D7126AB4D3800A66351028CA514F  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UPDATEDEVENTHANDLER_TB0230BC83686D7126AB4D3800A66351028CA514F_H
#ifndef TILEBASE_TD2158024AAA28EB0EC62F253FA1D1A76BC50F85E_H
#define TILEBASE_TD2158024AAA28EB0EC62F253FA1D1A76BC50F85E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Tilemaps.TileBase
struct  TileBase_tD2158024AAA28EB0EC62F253FA1D1A76BC50F85E  : public ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TILEBASE_TD2158024AAA28EB0EC62F253FA1D1A76BC50F85E_H
#ifndef ERROREVENTHANDLER_TF5863946928B48BE13146ED5FF70AC92678FE222_H
#define ERROREVENTHANDLER_TF5863946928B48BE13146ED5FF70AC92678FE222_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Video.VideoPlayer_ErrorEventHandler
struct  ErrorEventHandler_tF5863946928B48BE13146ED5FF70AC92678FE222  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ERROREVENTHANDLER_TF5863946928B48BE13146ED5FF70AC92678FE222_H
#ifndef EVENTHANDLER_T5069D72E1ED46BD04F19D8D4534811B95A8E2308_H
#define EVENTHANDLER_T5069D72E1ED46BD04F19D8D4534811B95A8E2308_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Video.VideoPlayer_EventHandler
struct  EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EVENTHANDLER_T5069D72E1ED46BD04F19D8D4534811B95A8E2308_H
#ifndef FRAMEREADYEVENTHANDLER_T518B277D916AB292680CAA186BCDB3D3EF130422_H
#define FRAMEREADYEVENTHANDLER_T518B277D916AB292680CAA186BCDB3D3EF130422_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Video.VideoPlayer_FrameReadyEventHandler
struct  FrameReadyEventHandler_t518B277D916AB292680CAA186BCDB3D3EF130422  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FRAMEREADYEVENTHANDLER_T518B277D916AB292680CAA186BCDB3D3EF130422_H
#ifndef TIMEEVENTHANDLER_TDD815DAABFADDD98C8993B2A97A2FCE858266BC1_H
#define TIMEEVENTHANDLER_TDD815DAABFADDD98C8993B2A97A2FCE858266BC1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Video.VideoPlayer_TimeEventHandler
struct  TimeEventHandler_tDD815DAABFADDD98C8993B2A97A2FCE858266BC1  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TIMEEVENTHANDLER_TDD815DAABFADDD98C8993B2A97A2FCE858266BC1_H
#ifndef BASELINEFUNCTION_T0A87479762FB382A84709009E9B6DCC597C6C9DF_H
#define BASELINEFUNCTION_T0A87479762FB382A84709009E9B6DCC597C6C9DF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Yoga.BaselineFunction
struct  BaselineFunction_t0A87479762FB382A84709009E9B6DCC597C6C9DF  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BASELINEFUNCTION_T0A87479762FB382A84709009E9B6DCC597C6C9DF_H
#ifndef MEASUREFUNCTION_TC5585E81380F4017044CE57AE21E178BAE2607AB_H
#define MEASUREFUNCTION_TC5585E81380F4017044CE57AE21E178BAE2607AB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Yoga.MeasureFunction
struct  MeasureFunction_tC5585E81380F4017044CE57AE21E178BAE2607AB  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MEASUREFUNCTION_TC5585E81380F4017044CE57AE21E178BAE2607AB_H
#ifndef CANVAS_TBC28BF1DD8D8499A89B5781505833D3728CF8591_H
#define CANVAS_TBC28BF1DD8D8499A89B5781505833D3728CF8591_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Canvas
struct  Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591  : public Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8
{
public:

public:
};

struct Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591_StaticFields
{
public:
	// UnityEngine.Canvas_WillRenderCanvases UnityEngine.Canvas::willRenderCanvases
	WillRenderCanvases_tBD5AD090B5938021DEAA679A5AEEA790F60A8BEE * ___willRenderCanvases_4;

public:
	inline static int32_t get_offset_of_willRenderCanvases_4() { return static_cast<int32_t>(offsetof(Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591_StaticFields, ___willRenderCanvases_4)); }
	inline WillRenderCanvases_tBD5AD090B5938021DEAA679A5AEEA790F60A8BEE * get_willRenderCanvases_4() const { return ___willRenderCanvases_4; }
	inline WillRenderCanvases_tBD5AD090B5938021DEAA679A5AEEA790F60A8BEE ** get_address_of_willRenderCanvases_4() { return &___willRenderCanvases_4; }
	inline void set_willRenderCanvases_4(WillRenderCanvases_tBD5AD090B5938021DEAA679A5AEEA790F60A8BEE * value)
	{
		___willRenderCanvases_4 = value;
		Il2CppCodeGenWriteBarrier((&___willRenderCanvases_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CANVAS_TBC28BF1DD8D8499A89B5781505833D3728CF8591_H
#ifndef CANVASGROUP_TE2C664C60990D1DCCEE0CC6545CC3E80369C7F90_H
#define CANVASGROUP_TE2C664C60990D1DCCEE0CC6545CC3E80369C7F90_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.CanvasGroup
struct  CanvasGroup_tE2C664C60990D1DCCEE0CC6545CC3E80369C7F90  : public Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CANVASGROUP_TE2C664C60990D1DCCEE0CC6545CC3E80369C7F90_H
#ifndef VISUALEFFECT_TBB62FCDE4826BA7FE8BEB728EC616C8E7ED5A506_H
#define VISUALEFFECT_TBB62FCDE4826BA7FE8BEB728EC616C8E7ED5A506_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.VFX.VisualEffect
struct  VisualEffect_tBB62FCDE4826BA7FE8BEB728EC616C8E7ED5A506  : public Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VISUALEFFECT_TBB62FCDE4826BA7FE8BEB728EC616C8E7ED5A506_H
#ifndef GRIDLAYOUT_T271F88A0992C64FE8E229D03480E3862B22D57F9_H
#define GRIDLAYOUT_T271F88A0992C64FE8E229D03480E3862B22D57F9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.GridLayout
struct  GridLayout_t271F88A0992C64FE8E229D03480E3862B22D57F9  : public Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GRIDLAYOUT_T271F88A0992C64FE8E229D03480E3862B22D57F9_H
#ifndef TILE_T275C7CE9C854F2912C851F345CCC00C45EDDE7AE_H
#define TILE_T275C7CE9C854F2912C851F345CCC00C45EDDE7AE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Tilemaps.Tile
struct  Tile_t275C7CE9C854F2912C851F345CCC00C45EDDE7AE  : public TileBase_tD2158024AAA28EB0EC62F253FA1D1A76BC50F85E
{
public:
	// UnityEngine.Sprite UnityEngine.Tilemaps.Tile::m_Sprite
	Sprite_tCA09498D612D08DE668653AF1E9C12BF53434198 * ___m_Sprite_4;
	// UnityEngine.Color UnityEngine.Tilemaps.Tile::m_Color
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___m_Color_5;
	// UnityEngine.Matrix4x4 UnityEngine.Tilemaps.Tile::m_Transform
	Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  ___m_Transform_6;
	// UnityEngine.GameObject UnityEngine.Tilemaps.Tile::m_InstancedGameObject
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___m_InstancedGameObject_7;
	// UnityEngine.Tilemaps.TileFlags UnityEngine.Tilemaps.Tile::m_Flags
	int32_t ___m_Flags_8;
	// UnityEngine.Tilemaps.Tile_ColliderType UnityEngine.Tilemaps.Tile::m_ColliderType
	int32_t ___m_ColliderType_9;

public:
	inline static int32_t get_offset_of_m_Sprite_4() { return static_cast<int32_t>(offsetof(Tile_t275C7CE9C854F2912C851F345CCC00C45EDDE7AE, ___m_Sprite_4)); }
	inline Sprite_tCA09498D612D08DE668653AF1E9C12BF53434198 * get_m_Sprite_4() const { return ___m_Sprite_4; }
	inline Sprite_tCA09498D612D08DE668653AF1E9C12BF53434198 ** get_address_of_m_Sprite_4() { return &___m_Sprite_4; }
	inline void set_m_Sprite_4(Sprite_tCA09498D612D08DE668653AF1E9C12BF53434198 * value)
	{
		___m_Sprite_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_Sprite_4), value);
	}

	inline static int32_t get_offset_of_m_Color_5() { return static_cast<int32_t>(offsetof(Tile_t275C7CE9C854F2912C851F345CCC00C45EDDE7AE, ___m_Color_5)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_m_Color_5() const { return ___m_Color_5; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_m_Color_5() { return &___m_Color_5; }
	inline void set_m_Color_5(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___m_Color_5 = value;
	}

	inline static int32_t get_offset_of_m_Transform_6() { return static_cast<int32_t>(offsetof(Tile_t275C7CE9C854F2912C851F345CCC00C45EDDE7AE, ___m_Transform_6)); }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  get_m_Transform_6() const { return ___m_Transform_6; }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA * get_address_of_m_Transform_6() { return &___m_Transform_6; }
	inline void set_m_Transform_6(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  value)
	{
		___m_Transform_6 = value;
	}

	inline static int32_t get_offset_of_m_InstancedGameObject_7() { return static_cast<int32_t>(offsetof(Tile_t275C7CE9C854F2912C851F345CCC00C45EDDE7AE, ___m_InstancedGameObject_7)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_m_InstancedGameObject_7() const { return ___m_InstancedGameObject_7; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_m_InstancedGameObject_7() { return &___m_InstancedGameObject_7; }
	inline void set_m_InstancedGameObject_7(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___m_InstancedGameObject_7 = value;
		Il2CppCodeGenWriteBarrier((&___m_InstancedGameObject_7), value);
	}

	inline static int32_t get_offset_of_m_Flags_8() { return static_cast<int32_t>(offsetof(Tile_t275C7CE9C854F2912C851F345CCC00C45EDDE7AE, ___m_Flags_8)); }
	inline int32_t get_m_Flags_8() const { return ___m_Flags_8; }
	inline int32_t* get_address_of_m_Flags_8() { return &___m_Flags_8; }
	inline void set_m_Flags_8(int32_t value)
	{
		___m_Flags_8 = value;
	}

	inline static int32_t get_offset_of_m_ColliderType_9() { return static_cast<int32_t>(offsetof(Tile_t275C7CE9C854F2912C851F345CCC00C45EDDE7AE, ___m_ColliderType_9)); }
	inline int32_t get_m_ColliderType_9() const { return ___m_ColliderType_9; }
	inline int32_t* get_address_of_m_ColliderType_9() { return &___m_ColliderType_9; }
	inline void set_m_ColliderType_9(int32_t value)
	{
		___m_ColliderType_9 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TILE_T275C7CE9C854F2912C851F345CCC00C45EDDE7AE_H
#ifndef VIDEOPLAYER_TFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2_H
#define VIDEOPLAYER_TFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Video.VideoPlayer
struct  VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2  : public Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8
{
public:
	// UnityEngine.Video.VideoPlayer_EventHandler UnityEngine.Video.VideoPlayer::prepareCompleted
	EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 * ___prepareCompleted_4;
	// UnityEngine.Video.VideoPlayer_EventHandler UnityEngine.Video.VideoPlayer::loopPointReached
	EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 * ___loopPointReached_5;
	// UnityEngine.Video.VideoPlayer_EventHandler UnityEngine.Video.VideoPlayer::started
	EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 * ___started_6;
	// UnityEngine.Video.VideoPlayer_EventHandler UnityEngine.Video.VideoPlayer::frameDropped
	EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 * ___frameDropped_7;
	// UnityEngine.Video.VideoPlayer_ErrorEventHandler UnityEngine.Video.VideoPlayer::errorReceived
	ErrorEventHandler_tF5863946928B48BE13146ED5FF70AC92678FE222 * ___errorReceived_8;
	// UnityEngine.Video.VideoPlayer_EventHandler UnityEngine.Video.VideoPlayer::seekCompleted
	EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 * ___seekCompleted_9;
	// UnityEngine.Video.VideoPlayer_TimeEventHandler UnityEngine.Video.VideoPlayer::clockResyncOccurred
	TimeEventHandler_tDD815DAABFADDD98C8993B2A97A2FCE858266BC1 * ___clockResyncOccurred_10;
	// UnityEngine.Video.VideoPlayer_FrameReadyEventHandler UnityEngine.Video.VideoPlayer::frameReady
	FrameReadyEventHandler_t518B277D916AB292680CAA186BCDB3D3EF130422 * ___frameReady_11;

public:
	inline static int32_t get_offset_of_prepareCompleted_4() { return static_cast<int32_t>(offsetof(VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2, ___prepareCompleted_4)); }
	inline EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 * get_prepareCompleted_4() const { return ___prepareCompleted_4; }
	inline EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 ** get_address_of_prepareCompleted_4() { return &___prepareCompleted_4; }
	inline void set_prepareCompleted_4(EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 * value)
	{
		___prepareCompleted_4 = value;
		Il2CppCodeGenWriteBarrier((&___prepareCompleted_4), value);
	}

	inline static int32_t get_offset_of_loopPointReached_5() { return static_cast<int32_t>(offsetof(VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2, ___loopPointReached_5)); }
	inline EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 * get_loopPointReached_5() const { return ___loopPointReached_5; }
	inline EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 ** get_address_of_loopPointReached_5() { return &___loopPointReached_5; }
	inline void set_loopPointReached_5(EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 * value)
	{
		___loopPointReached_5 = value;
		Il2CppCodeGenWriteBarrier((&___loopPointReached_5), value);
	}

	inline static int32_t get_offset_of_started_6() { return static_cast<int32_t>(offsetof(VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2, ___started_6)); }
	inline EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 * get_started_6() const { return ___started_6; }
	inline EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 ** get_address_of_started_6() { return &___started_6; }
	inline void set_started_6(EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 * value)
	{
		___started_6 = value;
		Il2CppCodeGenWriteBarrier((&___started_6), value);
	}

	inline static int32_t get_offset_of_frameDropped_7() { return static_cast<int32_t>(offsetof(VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2, ___frameDropped_7)); }
	inline EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 * get_frameDropped_7() const { return ___frameDropped_7; }
	inline EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 ** get_address_of_frameDropped_7() { return &___frameDropped_7; }
	inline void set_frameDropped_7(EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 * value)
	{
		___frameDropped_7 = value;
		Il2CppCodeGenWriteBarrier((&___frameDropped_7), value);
	}

	inline static int32_t get_offset_of_errorReceived_8() { return static_cast<int32_t>(offsetof(VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2, ___errorReceived_8)); }
	inline ErrorEventHandler_tF5863946928B48BE13146ED5FF70AC92678FE222 * get_errorReceived_8() const { return ___errorReceived_8; }
	inline ErrorEventHandler_tF5863946928B48BE13146ED5FF70AC92678FE222 ** get_address_of_errorReceived_8() { return &___errorReceived_8; }
	inline void set_errorReceived_8(ErrorEventHandler_tF5863946928B48BE13146ED5FF70AC92678FE222 * value)
	{
		___errorReceived_8 = value;
		Il2CppCodeGenWriteBarrier((&___errorReceived_8), value);
	}

	inline static int32_t get_offset_of_seekCompleted_9() { return static_cast<int32_t>(offsetof(VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2, ___seekCompleted_9)); }
	inline EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 * get_seekCompleted_9() const { return ___seekCompleted_9; }
	inline EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 ** get_address_of_seekCompleted_9() { return &___seekCompleted_9; }
	inline void set_seekCompleted_9(EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308 * value)
	{
		___seekCompleted_9 = value;
		Il2CppCodeGenWriteBarrier((&___seekCompleted_9), value);
	}

	inline static int32_t get_offset_of_clockResyncOccurred_10() { return static_cast<int32_t>(offsetof(VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2, ___clockResyncOccurred_10)); }
	inline TimeEventHandler_tDD815DAABFADDD98C8993B2A97A2FCE858266BC1 * get_clockResyncOccurred_10() const { return ___clockResyncOccurred_10; }
	inline TimeEventHandler_tDD815DAABFADDD98C8993B2A97A2FCE858266BC1 ** get_address_of_clockResyncOccurred_10() { return &___clockResyncOccurred_10; }
	inline void set_clockResyncOccurred_10(TimeEventHandler_tDD815DAABFADDD98C8993B2A97A2FCE858266BC1 * value)
	{
		___clockResyncOccurred_10 = value;
		Il2CppCodeGenWriteBarrier((&___clockResyncOccurred_10), value);
	}

	inline static int32_t get_offset_of_frameReady_11() { return static_cast<int32_t>(offsetof(VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2, ___frameReady_11)); }
	inline FrameReadyEventHandler_t518B277D916AB292680CAA186BCDB3D3EF130422 * get_frameReady_11() const { return ___frameReady_11; }
	inline FrameReadyEventHandler_t518B277D916AB292680CAA186BCDB3D3EF130422 ** get_address_of_frameReady_11() { return &___frameReady_11; }
	inline void set_frameReady_11(FrameReadyEventHandler_t518B277D916AB292680CAA186BCDB3D3EF130422 * value)
	{
		___frameReady_11 = value;
		Il2CppCodeGenWriteBarrier((&___frameReady_11), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEOPLAYER_TFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2_H
#ifndef TILEMAP_T0F92148668211805A631B93488D4A629EC378B10_H
#define TILEMAP_T0F92148668211805A631B93488D4A629EC378B10_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Tilemaps.Tilemap
struct  Tilemap_t0F92148668211805A631B93488D4A629EC378B10  : public GridLayout_t271F88A0992C64FE8E229D03480E3862B22D57F9
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TILEMAP_T0F92148668211805A631B93488D4A629EC378B10_H





#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2800 = { sizeof (U3CCollectTerrainsU3Ec__AnonStorey1_t41DA2A02D290EE5FEF14389A4391CBC1E3E622A5), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2800[1] = 
{
	U3CCollectTerrainsU3Ec__AnonStorey1_t41DA2A02D290EE5FEF14389A4391CBC1E3E622A5::get_offset_of_onlyAutoConnectedTerrains_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2801 = { sizeof (U3CCollectTerrainsU3Ec__AnonStorey0_t4BCCA12171A915F3BCE4B2B0F9A4EBD484BC78CA), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2801[2] = 
{
	U3CCollectTerrainsU3Ec__AnonStorey0_t4BCCA12171A915F3BCE4B2B0F9A4EBD484BC78CA::get_offset_of_t_0(),
	U3CCollectTerrainsU3Ec__AnonStorey0_t4BCCA12171A915F3BCE4B2B0F9A4EBD484BC78CA::get_offset_of_U3CU3Ef__refU241_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2802 = { sizeof (U3CModuleU3E_t140A63E1069F1772D5238396CDA7CE5372253E44), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2803 = { sizeof (ITilemap_t784A442A8BD2283058F44E8C0FE5257168459BE3), -1, sizeof(ITilemap_t784A442A8BD2283058F44E8C0FE5257168459BE3_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2803[2] = 
{
	ITilemap_t784A442A8BD2283058F44E8C0FE5257168459BE3_StaticFields::get_offset_of_s_Instance_0(),
	ITilemap_t784A442A8BD2283058F44E8C0FE5257168459BE3::get_offset_of_m_Tilemap_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2804 = { sizeof (Tile_t275C7CE9C854F2912C851F345CCC00C45EDDE7AE), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2804[6] = 
{
	Tile_t275C7CE9C854F2912C851F345CCC00C45EDDE7AE::get_offset_of_m_Sprite_4(),
	Tile_t275C7CE9C854F2912C851F345CCC00C45EDDE7AE::get_offset_of_m_Color_5(),
	Tile_t275C7CE9C854F2912C851F345CCC00C45EDDE7AE::get_offset_of_m_Transform_6(),
	Tile_t275C7CE9C854F2912C851F345CCC00C45EDDE7AE::get_offset_of_m_InstancedGameObject_7(),
	Tile_t275C7CE9C854F2912C851F345CCC00C45EDDE7AE::get_offset_of_m_Flags_8(),
	Tile_t275C7CE9C854F2912C851F345CCC00C45EDDE7AE::get_offset_of_m_ColliderType_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2805 = { sizeof (ColliderType_tCF48B308BF04CE1D262A726D500126E8C8859F2B)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2805[4] = 
{
	ColliderType_tCF48B308BF04CE1D262A726D500126E8C8859F2B::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2806 = { sizeof (TileBase_tD2158024AAA28EB0EC62F253FA1D1A76BC50F85E), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2807 = { sizeof (Tilemap_t0F92148668211805A631B93488D4A629EC378B10), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2808 = { sizeof (TileFlags_tBD601639E3CC4B4BA675548F3B8F17B709A974AF)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2808[6] = 
{
	TileFlags_tBD601639E3CC4B4BA675548F3B8F17B709A974AF::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2809 = { sizeof (TileData_t8A50A35CAFD87C12E27D7E596D968C9114A4CBB5)+ sizeof (RuntimeObject), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2809[6] = 
{
	TileData_t8A50A35CAFD87C12E27D7E596D968C9114A4CBB5::get_offset_of_m_Sprite_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	TileData_t8A50A35CAFD87C12E27D7E596D968C9114A4CBB5::get_offset_of_m_Color_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	TileData_t8A50A35CAFD87C12E27D7E596D968C9114A4CBB5::get_offset_of_m_Transform_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	TileData_t8A50A35CAFD87C12E27D7E596D968C9114A4CBB5::get_offset_of_m_GameObject_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
	TileData_t8A50A35CAFD87C12E27D7E596D968C9114A4CBB5::get_offset_of_m_Flags_4() + static_cast<int32_t>(sizeof(RuntimeObject)),
	TileData_t8A50A35CAFD87C12E27D7E596D968C9114A4CBB5::get_offset_of_m_ColliderType_5() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2810 = { sizeof (TileAnimationData_t2A9C81AD1F3E916C2DE292A6F3953FC8C38EFDA8)+ sizeof (RuntimeObject), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2810[3] = 
{
	TileAnimationData_t2A9C81AD1F3E916C2DE292A6F3953FC8C38EFDA8::get_offset_of_m_AnimatedSprites_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	TileAnimationData_t2A9C81AD1F3E916C2DE292A6F3953FC8C38EFDA8::get_offset_of_m_AnimationSpeed_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	TileAnimationData_t2A9C81AD1F3E916C2DE292A6F3953FC8C38EFDA8::get_offset_of_m_AnimationStartTime_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2811 = { sizeof (U3CModuleU3E_t091C966E943CA3E1F5D551C43C6FE64881C5BB24), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2812 = { sizeof (BaselineFunction_t0A87479762FB382A84709009E9B6DCC597C6C9DF), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2813 = { sizeof (MeasureFunction_tC5585E81380F4017044CE57AE21E178BAE2607AB), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2814 = { sizeof (YogaMeasureMode_t29AF57E74BCD4C16019B8BE88A317D54DA70C29F)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2814[4] = 
{
	YogaMeasureMode_t29AF57E74BCD4C16019B8BE88A317D54DA70C29F::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2815 = { sizeof (Native_tAB7B2E3A68EEFE9B7A356DB4CC8EC664EB765C2A), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2816 = { sizeof (YogaNode_tFCB801A447DAC7A335C686ABC5941A4357102A2C), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2816[4] = 
{
	YogaNode_tFCB801A447DAC7A335C686ABC5941A4357102A2C::get_offset_of__ygNode_0(),
	YogaNode_tFCB801A447DAC7A335C686ABC5941A4357102A2C::get_offset_of__children_1(),
	YogaNode_tFCB801A447DAC7A335C686ABC5941A4357102A2C::get_offset_of__measureFunction_2(),
	YogaNode_tFCB801A447DAC7A335C686ABC5941A4357102A2C::get_offset_of__baselineFunction_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2817 = { sizeof (YogaSize_t0F2077727A4CBD4C36F3DC0CBE1FB0A67D9EAD23)+ sizeof (RuntimeObject), sizeof(YogaSize_t0F2077727A4CBD4C36F3DC0CBE1FB0A67D9EAD23 ), 0, 0 };
extern const int32_t g_FieldOffsetTable2817[2] = 
{
	YogaSize_t0F2077727A4CBD4C36F3DC0CBE1FB0A67D9EAD23::get_offset_of_width_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	YogaSize_t0F2077727A4CBD4C36F3DC0CBE1FB0A67D9EAD23::get_offset_of_height_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2818 = { sizeof (U3CModuleU3E_t79D7DE725655CFC1B063EA359E8D75692CF5DC2F), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2819 = { sizeof (RenderMode_tB54632E74CDC4A990E815EB8C3CC515D3A9E2F60)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2819[4] = 
{
	RenderMode_tB54632E74CDC4A990E815EB8C3CC515D3A9E2F60::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2820 = { sizeof (Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591), -1, sizeof(Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2820[1] = 
{
	Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591_StaticFields::get_offset_of_willRenderCanvases_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2821 = { sizeof (WillRenderCanvases_tBD5AD090B5938021DEAA679A5AEEA790F60A8BEE), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2822 = { sizeof (UISystemProfilerApi_tD33E558B2D0176096E5DB375956ACA9F03678F1B), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2823 = { sizeof (SampleType_t2144AEAF3447ACAFCE1C13AF669F63192F8E75EC)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2823[3] = 
{
	SampleType_t2144AEAF3447ACAFCE1C13AF669F63192F8E75EC::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2824 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2825 = { sizeof (CanvasGroup_tE2C664C60990D1DCCEE0CC6545CC3E80369C7F90), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2826 = { sizeof (CanvasRenderer_tB4D9C9FE77FD5C9C4546FC022D6E956960BC2B72), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2826[1] = 
{
	CanvasRenderer_tB4D9C9FE77FD5C9C4546FC022D6E956960BC2B72::get_offset_of_U3CisMaskU3Ek__BackingField_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2827 = { sizeof (RectTransformUtility_t9B90669A72B05A33DD88BEBB817BC9CDBB614BBA), -1, sizeof(RectTransformUtility_t9B90669A72B05A33DD88BEBB817BC9CDBB614BBA_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2827[1] = 
{
	RectTransformUtility_t9B90669A72B05A33DD88BEBB817BC9CDBB614BBA_StaticFields::get_offset_of_s_Corners_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2828 = { sizeof (U3CModuleU3E_tCD4309F8DDA0F37A98DBCDFE49F6C8F300C242B0), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2829 = { sizeof (ContinuousEvent_tBAB6336255F3FC327CBA03CE368CD4D8D027107A), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2830 = { sizeof (AnalyticsSessionState_t61CA873937E9A3B881B71B32F518A954A4C8F267)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2830[5] = 
{
	AnalyticsSessionState_t61CA873937E9A3B881B71B32F518A954A4C8F267::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2831 = { sizeof (AnalyticsSessionInfo_tE075F764A74D2B095CFD57F3B179397F504B7D8C), -1, sizeof(AnalyticsSessionInfo_tE075F764A74D2B095CFD57F3B179397F504B7D8C_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2831[1] = 
{
	AnalyticsSessionInfo_tE075F764A74D2B095CFD57F3B179397F504B7D8C_StaticFields::get_offset_of_sessionStateChanged_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2832 = { sizeof (SessionStateChanged_t9084549A636BD45086D66CC6765DA8C3DD31066F), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2833 = { sizeof (RemoteSettings_t3F7E07D15288B0DF84A4A32044592D8AFA6D36ED), -1, sizeof(RemoteSettings_t3F7E07D15288B0DF84A4A32044592D8AFA6D36ED_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2833[3] = 
{
	RemoteSettings_t3F7E07D15288B0DF84A4A32044592D8AFA6D36ED_StaticFields::get_offset_of_Updated_0(),
	RemoteSettings_t3F7E07D15288B0DF84A4A32044592D8AFA6D36ED_StaticFields::get_offset_of_BeforeFetchFromServer_1(),
	RemoteSettings_t3F7E07D15288B0DF84A4A32044592D8AFA6D36ED_StaticFields::get_offset_of_Completed_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2834 = { sizeof (UpdatedEventHandler_tB0230BC83686D7126AB4D3800A66351028CA514F), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2835 = { sizeof (RemoteConfigSettings_t97154F5546B47CE72257CC2F0B677BDF696AEC4A), sizeof(RemoteConfigSettings_t97154F5546B47CE72257CC2F0B677BDF696AEC4A_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable2835[2] = 
{
	RemoteConfigSettings_t97154F5546B47CE72257CC2F0B677BDF696AEC4A::get_offset_of_m_Ptr_0(),
	RemoteConfigSettings_t97154F5546B47CE72257CC2F0B677BDF696AEC4A::get_offset_of_Updated_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2836 = { sizeof (U3CModuleU3E_t2FBFFC67F8D6B1FA13284515F9BBD8C9333B5C86), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2837 = { sizeof (WebRequestUtils_tBE8F8607E3A9633419968F6AF2F706A029AE1296), -1, sizeof(WebRequestUtils_tBE8F8607E3A9633419968F6AF2F706A029AE1296_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2837[1] = 
{
	WebRequestUtils_tBE8F8607E3A9633419968F6AF2F706A029AE1296_StaticFields::get_offset_of_domainRegex_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2838 = { sizeof (CertificateHandler_tBD070BF4150A44AB482FD36EA3882C363117E8C0), sizeof(CertificateHandler_tBD070BF4150A44AB482FD36EA3882C363117E8C0_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable2838[1] = 
{
	CertificateHandler_tBD070BF4150A44AB482FD36EA3882C363117E8C0::get_offset_of_m_Ptr_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2839 = { sizeof (U3CModuleU3E_tAF0352AF459FC6ADDA335387111E96B1480224D6), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2840 = { sizeof (VFXEventAttribute_t8FE74C5425505C55B4F79299C569CCE1A47BE325), sizeof(VFXEventAttribute_t8FE74C5425505C55B4F79299C569CCE1A47BE325_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable2840[2] = 
{
	VFXEventAttribute_t8FE74C5425505C55B4F79299C569CCE1A47BE325::get_offset_of_m_Ptr_0(),
	VFXEventAttribute_t8FE74C5425505C55B4F79299C569CCE1A47BE325::get_offset_of_m_Owner_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2841 = { sizeof (VFXExpressionValues_tBEEC793A9CD5134400899D1AAE1ABF13AF6562F2), sizeof(VFXExpressionValues_tBEEC793A9CD5134400899D1AAE1ABF13AF6562F2_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable2841[1] = 
{
	VFXExpressionValues_tBEEC793A9CD5134400899D1AAE1ABF13AF6562F2::get_offset_of_m_Ptr_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2842 = { sizeof (VFXManager_tDE794F20EA719507EADF091F8042A8B097F1E8E5), -1, sizeof(VFXManager_tDE794F20EA719507EADF091F8042A8B097F1E8E5_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2842[2] = 
{
	VFXManager_tDE794F20EA719507EADF091F8042A8B097F1E8E5_StaticFields::get_offset_of_U3CU3Ef__mgU24cache0_0(),
	VFXManager_tDE794F20EA719507EADF091F8042A8B097F1E8E5_StaticFields::get_offset_of_U3CU3Ef__mgU24cache1_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2843 = { sizeof (VFXSpawnerCallbacks_t4A28725CC33298516D1479C1D2BFEC00034373A1), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2844 = { sizeof (VFXSpawnerState_t614A1AADC2EDB20E82A625BE053A22DB31D89AC7), sizeof(VFXSpawnerState_t614A1AADC2EDB20E82A625BE053A22DB31D89AC7_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable2844[2] = 
{
	VFXSpawnerState_t614A1AADC2EDB20E82A625BE053A22DB31D89AC7::get_offset_of_m_Ptr_0(),
	VFXSpawnerState_t614A1AADC2EDB20E82A625BE053A22DB31D89AC7::get_offset_of_m_Owner_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2845 = { sizeof (VisualEffect_tBB62FCDE4826BA7FE8BEB728EC616C8E7ED5A506), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2846 = { sizeof (U3CModuleU3E_tB054F17A779AC945E3659AF119A96DB806541AF9), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2847 = { sizeof (XRDevice_t392FCA3D1DCEB95FF500C8F374C88B034C31DF4A), -1, sizeof(XRDevice_t392FCA3D1DCEB95FF500C8F374C88B034C31DF4A_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2847[1] = 
{
	XRDevice_t392FCA3D1DCEB95FF500C8F374C88B034C31DF4A_StaticFields::get_offset_of_deviceLoaded_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2848 = { sizeof (U3CModuleU3E_t064756C4EE8D64CEFE107E600CEBCB3F77894990), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2849 = { sizeof (VideoClip_tA4039CBBC6F9C3AD62B067964A6C20C6FB7376D5), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2850 = { sizeof (VideoClipPlayable_t4B7997FDB02C74F9E88F37574F0F4F9DE08CCC12)+ sizeof (RuntimeObject), sizeof(VideoClipPlayable_t4B7997FDB02C74F9E88F37574F0F4F9DE08CCC12 ), 0, 0 };
extern const int32_t g_FieldOffsetTable2850[1] = 
{
	VideoClipPlayable_t4B7997FDB02C74F9E88F37574F0F4F9DE08CCC12::get_offset_of_m_Handle_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2851 = { sizeof (VideoRenderMode_t0DBAABB576FDA890C49C6AD3EE641623F93E9161)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2851[6] = 
{
	VideoRenderMode_t0DBAABB576FDA890C49C6AD3EE641623F93E9161::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2852 = { sizeof (Video3DLayout_t5F64D0CE5E9B37C2FCE67F397FA5CFE9C047E4A1)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2852[4] = 
{
	Video3DLayout_t5F64D0CE5E9B37C2FCE67F397FA5CFE9C047E4A1::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2853 = { sizeof (VideoAspectRatio_t5739968D28C4F8F802B085E293F22110205B8379)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2853[7] = 
{
	VideoAspectRatio_t5739968D28C4F8F802B085E293F22110205B8379::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2854 = { sizeof (VideoTimeSource_t15F04FD6B3D75A8D98480E8B77117C0FF691BB77)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2854[3] = 
{
	VideoTimeSource_t15F04FD6B3D75A8D98480E8B77117C0FF691BB77::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2855 = { sizeof (VideoTimeReference_t9EAEBD354AE5E56F0D0F36E73A428BB2A0B8B31B)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2855[4] = 
{
	VideoTimeReference_t9EAEBD354AE5E56F0D0F36E73A428BB2A0B8B31B::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2856 = { sizeof (VideoSource_t32501B57EA7F9CF835FBA8184C9AF427CBBEFD0A)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2856[3] = 
{
	VideoSource_t32501B57EA7F9CF835FBA8184C9AF427CBBEFD0A::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2857 = { sizeof (VideoAudioOutputMode_t8CDE10B382F3C321345EC57C9164A9177139DC6F)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2857[5] = 
{
	VideoAudioOutputMode_t8CDE10B382F3C321345EC57C9164A9177139DC6F::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2858 = { sizeof (VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2858[8] = 
{
	VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2::get_offset_of_prepareCompleted_4(),
	VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2::get_offset_of_loopPointReached_5(),
	VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2::get_offset_of_started_6(),
	VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2::get_offset_of_frameDropped_7(),
	VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2::get_offset_of_errorReceived_8(),
	VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2::get_offset_of_seekCompleted_9(),
	VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2::get_offset_of_clockResyncOccurred_10(),
	VideoPlayer_tFC1C27AF83D59A5213B2AC561B43FD7E19FE02F2::get_offset_of_frameReady_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2859 = { sizeof (EventHandler_t5069D72E1ED46BD04F19D8D4534811B95A8E2308), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2860 = { sizeof (ErrorEventHandler_tF5863946928B48BE13146ED5FF70AC92678FE222), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2861 = { sizeof (FrameReadyEventHandler_t518B277D916AB292680CAA186BCDB3D3EF130422), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2862 = { sizeof (TimeEventHandler_tDD815DAABFADDD98C8993B2A97A2FCE858266BC1), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2863 = { sizeof (U3CModuleU3E_t5E9BCCF782B7911AFF113E864B4B636EFE0B6BF0), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2864 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2865 = { sizeof (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3), -1, sizeof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2865[16] = 
{
	AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields::get_offset_of_LOGTAG_0(),
	AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3::get_offset_of_mNetworkConfig_1(),
	AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3::get_offset_of_mMediaConfig_2(),
	AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3::get_offset_of_CallEvent_3(),
	AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3::get_offset_of_mNetwork_4(),
	AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3::get_offset_of_mConferenceMode_5(),
	AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields::get_offset_of_MESSAGE_TYPE_DATA_6(),
	AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields::get_offset_of_MESSAGE_TYPE_STRING_7(),
	AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3::get_offset_of_mState_8(),
	AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3::get_offset_of_mIsDisposed_9(),
	AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3::get_offset_of_mLocalFrameEvents_10(),
	AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3::get_offset_of_mServerInactive_11(),
	AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3::get_offset_of_mConnectionIds_12(),
	AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3::get_offset_of_mPendingListenCall_13(),
	AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3::get_offset_of_mPendingCallCall_14(),
	AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3::get_offset_of_mPendingAddress_15(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2866 = { sizeof (CallState_t4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2866[10] = 
{
	CallState_t4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2867 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2868 = { sizeof (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B), -1, sizeof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2868[9] = 
{
	ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields::get_offset_of_sPool_0(),
	ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields::get_offset_of_LOG_GC_CALLS_1(),
	ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B::get_offset_of_array_2(),
	ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B::get_offset_of_positionWrite_3(),
	ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B::get_offset_of_positionRead_4(),
	ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B::get_offset_of_offset_5(),
	ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B::get_offset_of_mFromPool_6(),
	ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B::get_offset_of_mDisposed_7(),
	ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields::get_offset_of_MultiplyDeBruijnBitPosition_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2869 = { sizeof (CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2870 = { sizeof (CallEventType_t83E9DB342D0F2580C5FB1EC4C26A3C3C035AD62B)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2870[12] = 
{
	CallEventType_t83E9DB342D0F2580C5FB1EC4C26A3C3C035AD62B::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2871 = { sizeof (CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2871[1] = 
{
	CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0::get_offset_of_mType_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2872 = { sizeof (CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2872[1] = 
{
	CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA::get_offset_of_mConnectionId_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2873 = { sizeof (CallEndedEventArgs_tE3A3B50FDE883A4D052920EB6073028ACFF81128), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2873[1] = 
{
	CallEndedEventArgs_tE3A3B50FDE883A4D052920EB6073028ACFF81128::get_offset_of_mConnectionId_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2874 = { sizeof (ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2874[1] = 
{
	ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246::get_offset_of_mErrorInfo_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2875 = { sizeof (WaitForIncomingCallEventArgs_tD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2875[1] = 
{
	WaitForIncomingCallEventArgs_tD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86::get_offset_of_mAddress_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2876 = { sizeof (MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2876[3] = 
{
	MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899::get_offset_of_mConnectionId_1(),
	MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899::get_offset_of_mReliable_2(),
	MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899::get_offset_of_mContent_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2877 = { sizeof (DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2877[3] = 
{
	DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37::get_offset_of_mConnectionId_1(),
	DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37::get_offset_of_mContent_2(),
	DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37::get_offset_of_mReliable_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2878 = { sizeof (FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2878[3] = 
{
	FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C::get_offset_of_mFormat_1(),
	FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C::get_offset_of_mConnectionId_2(),
	FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C::get_offset_of_mFrame_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2879 = { sizeof (ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D)+ sizeof (RuntimeObject), sizeof(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D ), sizeof(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2879[2] = 
{
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields::get_offset_of_INVALID_0(),
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D::get_offset_of_id_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2880 = { sizeof (DefaultValues_tFB168B56BA06FD7096D0B3A6454AD6873A4104CA), -1, sizeof(DefaultValues_tFB168B56BA06FD7096D0B3A6454AD6873A4104CA_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2880[1] = 
{
	DefaultValues_tFB168B56BA06FD7096D0B3A6454AD6873A4104CA_StaticFields::get_offset_of_sAuthenticateAsClientBugWorkaround_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2881 = { sizeof (ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167), -1, sizeof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2881[11] = 
{
	ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields::get_offset_of_SERVER_INIT_FAILED_ADDRESS_IN_USE_0(),
	ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields::get_offset_of_CONNECTION_FAILED_ADDRESS_UNKNOWN_1(),
	ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields::get_offset_of_SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2(),
	ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields::get_offset_of_CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3(),
	ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields::get_offset_of_DISCONNECTED_REQURED_CONNECTION_OFFLINE_4(),
	ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields::get_offset_of_SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5(),
	ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields::get_offset_of_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6(),
	ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields::get_offset_of_INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7(),
	ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields::get_offset_of_DISCONNECTED_DUE_TO_TIMEOUT_8(),
	ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields::get_offset_of_CONFIGURATION_FAILED_9(),
	ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167::get_offset_of_mErrorMessage_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2882 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2883 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2884 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2885 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2886 = { sizeof (IceServer_t423A5044DD3B2346555973AF68F71585262E07FA), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2886[3] = 
{
	IceServer_t423A5044DD3B2346555973AF68F71585262E07FA::get_offset_of_mUrls_0(),
	IceServer_t423A5044DD3B2346555973AF68F71585262E07FA::get_offset_of_mUsername_1(),
	IceServer_t423A5044DD3B2346555973AF68F71585262E07FA::get_offset_of_mCredential_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2887 = { sizeof (MediaConfigurationState_tD278B71006BEF0BB2F003EB306E41EB133453629)+ sizeof (RuntimeObject), sizeof(uint8_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2887[6] = 
{
	MediaConfigurationState_tD278B71006BEF0BB2F003EB306E41EB133453629::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2888 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2889 = { sizeof (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562), -1, sizeof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2889[9] = 
{
	LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields::get_offset_of_LOCK_ADDRESS_0(),
	LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields::get_offset_of_sNextId_1(),
	LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields::get_offset_of_mServers_2(),
	LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562::get_offset_of_mId_3(),
	LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562::get_offset_of_mNextNetworkId_4(),
	LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562::get_offset_of_mServerAddress_5(),
	LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562::get_offset_of_mEvents_6(),
	LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562::get_offset_of_mConnectionNetwork_7(),
	LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562::get_offset_of_disposedValue_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2890 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable2890[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2891 = { sizeof (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2891[13] = 
{
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D::get_offset_of_mAudio_0(),
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D::get_offset_of_mVideo_1(),
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D::get_offset_of_mVideoDeviceName_2(),
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D::get_offset_of_mMinWidth_3(),
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D::get_offset_of_mMinHeight_4(),
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D::get_offset_of_mMaxWidth_5(),
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D::get_offset_of_mMaxHeight_6(),
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D::get_offset_of_mIdealWidth_7(),
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D::get_offset_of_mIdealHeight_8(),
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D::get_offset_of_mIdealFrameRate_9(),
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D::get_offset_of_mMinFrameRate_10(),
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D::get_offset_of_mMaxFrameRate_11(),
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D::get_offset_of_mFormat_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2892 = { sizeof (MessageDataBufferExt_t97D4A96C74CBA57E4A36C43BC6C79FBDDFA9DA4F), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2893 = { sizeof (NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2893[4] = 
{
	NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47::get_offset_of_mIceServers_0(),
	NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47::get_offset_of_mSignalingUrl_1(),
	NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47::get_offset_of_mAllowRenegotiation_2(),
	NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47::get_offset_of_mIsConference_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2894 = { sizeof (NetEventType_tD5213CE1DD8CDE1161395E0973FC1F8E5FB7B0A8)+ sizeof (RuntimeObject), sizeof(uint8_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2894[16] = 
{
	NetEventType_tD5213CE1DD8CDE1161395E0973FC1F8E5FB7B0A8::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2895 = { sizeof (NetEventDataType_t1C43B214D57FA8D91EC846A2FB89918433D613C6)+ sizeof (RuntimeObject), sizeof(uint8_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2895[4] = 
{
	NetEventDataType_t1C43B214D57FA8D91EC846A2FB89918433D613C6::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2896 = { sizeof (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C)+ sizeof (RuntimeObject), sizeof(NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable2896[3] = 
{
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C::get_offset_of_type_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C::get_offset_of_connectionId_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C::get_offset_of_data_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2897 = { sizeof (FramePixelFormat_tDCE4288D3AD386370E428FCC0668229B6994D9BB)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2897[6] = 
{
	FramePixelFormat_tDCE4288D3AD386370E428FCC0668229B6994D9BB::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2898 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2899 = { 0, -1, 0, 0 };
#ifdef __clang__
#pragma clang diagnostic pop
#endif
