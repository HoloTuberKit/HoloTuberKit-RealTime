﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "il2cpp-class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"


// Byn.Awrtc.Base.Configuration
struct Configuration_tBB4510742434F3421303DD936FD4461242012925;
// Byn.Awrtc.Base.IInternalMediaStream
struct IInternalMediaStream_t178708DABB4E77FC680D3626743B15568907917D;
// Byn.Awrtc.Base.IWebsocketClient
struct IWebsocketClient_tC132826011647FF5715FFD2A718D56D8433E2CDE;
// Byn.Awrtc.Base.SignalingConfig
struct SignalingConfig_tAE908484943C078C7439EB1A31243A983F6904EB;
// Byn.Awrtc.Base.SignalingInfo
struct SignalingInfo_t62D1320AC25FE0DB1A8F1DDEA007028162531DB1;
// Byn.Awrtc.BufferedFrame
struct BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028;
// Byn.Awrtc.CallEventHandler
struct CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F;
// Byn.Awrtc.IBasicNetwork
struct IBasicNetwork_t60318DADF4A0AF6F2063D0F7E9CE5611F6CB198D;
// Byn.Awrtc.IMediaNetwork
struct IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780;
// Byn.Awrtc.IceServer[]
struct IceServerU5BU5D_t77B1ADF58E5BEF879817A80953BA71C121730B4A;
// Byn.Awrtc.MediaConfig
struct MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D;
// Byn.Awrtc.Native.NativeAudioOptions
struct NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456;
// Byn.Awrtc.Native.NativeAwrtcFactory
struct NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0;
// Byn.Awrtc.Native.NativeVideoInput
struct NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C;
// Byn.Awrtc.NetworkConfig
struct NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47;
// System.Action
struct Action_t591D2A86165F896B4B800BB5C25CE18672A55579;
// System.Action`1<System.Byte[]>
struct Action_1_t67D6E8441D0DE589716B25B9D8F0D4412B593398;
// System.Action`1<System.Exception>
struct Action_1_t18E730906A964925D355310DF8D8719A7B2CB3FC;
// System.Action`1<System.Int64>
struct Action_1_t74F6DAC6E0AC7CAEE1EB04923F21C044D4939B1A;
// System.Action`2<System.Object,System.String[]>
struct Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944;
// System.AsyncCallback
struct AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4;
// System.Byte[]
struct ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821;
// System.Char[]
struct CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2;
// System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.Base.IDataPeer>
struct Dictionary_2_tDE069D3BDE2BBD3406F01575E28822C09A2F5591;
// System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>
struct List_1_tCB9967EC4C00221A410117D712FF423882EB5832;
// System.Collections.Generic.List`1<Byn.Awrtc.IBasicNetwork>
struct List_1_tA9F4001828A90CEB6EE5E47FF812F909BD858861;
// System.Collections.Generic.List`1<Byn.Awrtc.Native.NativeWebRtcCall>
struct List_1_t00993CA2C97E3BE02361D34E70A43B4134EAA9DD;
// System.Collections.Generic.List`1<System.Byte>
struct List_1_t2E429D48492C9F1ED16C7D74224A8AAB590A7B32;
// System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent>
struct Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF;
// System.Collections.Generic.Queue`1<System.String>
struct Queue_1_t234B58D376F3C134441C47D5A9EF7789374EE172;
// System.Collections.Specialized.NameValueCollection
struct NameValueCollection_t7C7CED43E4C6E997E3C8012F1D2CC4027FAD10D1;
// System.DelegateData
struct DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE;
// System.Delegate[]
struct DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86;
// System.Exception
struct Exception_t;
// System.Func`2<System.Int32,System.Boolean>
struct Func_2_tCFDBA11D752C6255254F6FE7B5D68152CA5D2618;
// System.Func`2<System.String,System.Boolean>
struct Func_2_t3AD4B0F443BFD399C4AC2D6EE99FFE3BC0970017;
// System.IAsyncResult
struct IAsyncResult_t8E194308510B375B42432981AE5E7488C458D598;
// System.IO.MemoryStream
struct MemoryStream_t495F44B85E6B4DDE2BB7E17DE963256A74E2298C;
// System.IO.Stream
struct Stream_tFC50657DD5AAB87770987F9179D934A51D99D5E7;
// System.Int32[]
struct Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83;
// System.Random
struct Random_t18A28484F67EFA289C256F508A5C71D9E6DEE09F;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.String
struct String_t;
// System.String[]
struct StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E;
// System.Text.StringBuilder
struct StringBuilder_t;
// System.Type
struct Type_t;
// System.Version
struct Version_tDBE6876C59B6F56D4F8CAA03851177ABC6FE0DFD;
// System.Void
struct Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017;
// WebRtcCSharp.IceServers
struct IceServers_t731B0B5709F7A24F85388A737619AAD7EC1A73D5;
// WebRtcCSharp.LogCallback
struct LogCallback_t74314F131710C13918F247941A914B2BBA5C2C6D;
// WebRtcCSharp.PollingMediaStreamRef
struct PollingMediaStreamRef_t18D181FB11B17D2C311E98F81850263E3BA73798;
// WebRtcCSharp.PollingPeerRef
struct PollingPeerRef_t5BD3A5F6E4F213003FB6D6D5648B96F7002DB6A2;
// WebRtcCSharp.RTCPeerConnectionFactoryRef
struct RTCPeerConnectionFactoryRef_tD457372C81A9E9436643652EBB7351D4E35035DF;
// WebRtcCSharp.StringVector
struct StringVector_t7957DE03AFED56C21E38C8C9CBB09D735C95B00C;
// WebRtcCSharp.VideoInputRef
struct VideoInputRef_t27BF06AD74106BD604BAF613B5FB44934E920732;
// WebRtcCSharp.WebRtcSwigPINVOKE/SWIGExceptionHelper
struct SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B;
// WebRtcCSharp.WebRtcSwigPINVOKE/SWIGExceptionHelper/ExceptionArgumentDelegate
struct ExceptionArgumentDelegate_t6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C;
// WebRtcCSharp.WebRtcSwigPINVOKE/SWIGExceptionHelper/ExceptionDelegate
struct ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6;
// WebRtcCSharp.WebRtcSwigPINVOKE/SWIGStringHelper
struct SWIGStringHelper_t64516B80BD5B451423C2FF303C67724660167FAE;
// WebRtcCSharp.WebRtcSwigPINVOKE/SWIGStringHelper/SWIGStringDelegate
struct SWIGStringDelegate_t27E7F38AF0AE0B2F586E097415E20C13A0C17EB4;
// WebSocketSharpUnityMod.Ext/<>c__DisplayClassd
struct U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF;
// WebSocketSharpUnityMod.PayloadData
struct PayloadData_t4B96E74F30C652A6DB0D6FCDA1CF1C88E1791ECE;

struct Delegate_t_marshaled_com;
struct Delegate_t_marshaled_pinvoke;



#ifndef U3CMODULEU3E_T56CA3936A9EFABF2ED20401359C40BFE63F85A11_H
#define U3CMODULEU3E_T56CA3936A9EFABF2ED20401359C40BFE63F85A11_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t56CA3936A9EFABF2ED20401359C40BFE63F85A11 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T56CA3936A9EFABF2ED20401359C40BFE63F85A11_H
#ifndef U3CMODULEU3E_T410187D184BFEA098C57AA90C1EEBB14DCD72176_H
#define U3CMODULEU3E_T410187D184BFEA098C57AA90C1EEBB14DCD72176_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t410187D184BFEA098C57AA90C1EEBB14DCD72176 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T410187D184BFEA098C57AA90C1EEBB14DCD72176_H
#ifndef U3CMODULEU3E_T9F01D6EDA4850AF0D472900DDB14FF9FEAEB2B05_H
#define U3CMODULEU3E_T9F01D6EDA4850AF0D472900DDB14FF9FEAEB2B05_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t9F01D6EDA4850AF0D472900DDB14FF9FEAEB2B05 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T9F01D6EDA4850AF0D472900DDB14FF9FEAEB2B05_H
#ifndef U3CMODULEU3E_TB308A2384DEB86F8845A4E61970976B8944B5DC4_H
#define U3CMODULEU3E_TB308A2384DEB86F8845A4E61970976B8944B5DC4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_tB308A2384DEB86F8845A4E61970976B8944B5DC4 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_TB308A2384DEB86F8845A4E61970976B8944B5DC4_H
#ifndef U3CMODULEU3E_TDE5A299227351E064CF5069210AC8ED1294BD51A_H
#define U3CMODULEU3E_TDE5A299227351E064CF5069210AC8ED1294BD51A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_tDE5A299227351E064CF5069210AC8ED1294BD51A 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_TDE5A299227351E064CF5069210AC8ED1294BD51A_H
#ifndef U3CMODULEU3E_T4CB3A0D321EC260EF057B1B18FF3649D10F25CD0_H
#define U3CMODULEU3E_T4CB3A0D321EC260EF057B1B18FF3649D10F25CD0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t4CB3A0D321EC260EF057B1B18FF3649D10F25CD0 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T4CB3A0D321EC260EF057B1B18FF3649D10F25CD0_H
#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
#ifndef AWEBSOCKETFACTORY_T7E099AA13C364DEC0D3C5702B9E0759390651DCE_H
#define AWEBSOCKETFACTORY_T7E099AA13C364DEC0D3C5702B9E0759390651DCE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.AWebsocketFactory
struct  AWebsocketFactory_t7E099AA13C364DEC0D3C5702B9E0759390651DCE  : public RuntimeObject
{
public:
	// System.Boolean Byn.Awrtc.Base.AWebsocketFactory::disposedValue
	bool ___disposedValue_1;

public:
	inline static int32_t get_offset_of_disposedValue_1() { return static_cast<int32_t>(offsetof(AWebsocketFactory_t7E099AA13C364DEC0D3C5702B9E0759390651DCE, ___disposedValue_1)); }
	inline bool get_disposedValue_1() const { return ___disposedValue_1; }
	inline bool* get_address_of_disposedValue_1() { return &___disposedValue_1; }
	inline void set_disposedValue_1(bool value)
	{
		___disposedValue_1 = value;
	}
};

struct AWebsocketFactory_t7E099AA13C364DEC0D3C5702B9E0759390651DCE_StaticFields
{
public:
	// Byn.Awrtc.Base.AWebsocketFactory Byn.Awrtc.Base.AWebsocketFactory::sDefaultFactory
	AWebsocketFactory_t7E099AA13C364DEC0D3C5702B9E0759390651DCE * ___sDefaultFactory_0;

public:
	inline static int32_t get_offset_of_sDefaultFactory_0() { return static_cast<int32_t>(offsetof(AWebsocketFactory_t7E099AA13C364DEC0D3C5702B9E0759390651DCE_StaticFields, ___sDefaultFactory_0)); }
	inline AWebsocketFactory_t7E099AA13C364DEC0D3C5702B9E0759390651DCE * get_sDefaultFactory_0() const { return ___sDefaultFactory_0; }
	inline AWebsocketFactory_t7E099AA13C364DEC0D3C5702B9E0759390651DCE ** get_address_of_sDefaultFactory_0() { return &___sDefaultFactory_0; }
	inline void set_sDefaultFactory_0(AWebsocketFactory_t7E099AA13C364DEC0D3C5702B9E0759390651DCE * value)
	{
		___sDefaultFactory_0 = value;
		Il2CppCodeGenWriteBarrier((&___sDefaultFactory_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AWEBSOCKETFACTORY_T7E099AA13C364DEC0D3C5702B9E0759390651DCE_H
#ifndef CONFIGURATION_TBB4510742434F3421303DD936FD4461242012925_H
#define CONFIGURATION_TBB4510742434F3421303DD936FD4461242012925_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.Configuration
struct  Configuration_tBB4510742434F3421303DD936FD4461242012925  : public RuntimeObject
{
public:
	// System.Int32 Byn.Awrtc.Base.Configuration::mHeartbeat
	int32_t ___mHeartbeat_0;
	// System.Boolean Byn.Awrtc.Base.Configuration::mIsLocked
	bool ___mIsLocked_1;

public:
	inline static int32_t get_offset_of_mHeartbeat_0() { return static_cast<int32_t>(offsetof(Configuration_tBB4510742434F3421303DD936FD4461242012925, ___mHeartbeat_0)); }
	inline int32_t get_mHeartbeat_0() const { return ___mHeartbeat_0; }
	inline int32_t* get_address_of_mHeartbeat_0() { return &___mHeartbeat_0; }
	inline void set_mHeartbeat_0(int32_t value)
	{
		___mHeartbeat_0 = value;
	}

	inline static int32_t get_offset_of_mIsLocked_1() { return static_cast<int32_t>(offsetof(Configuration_tBB4510742434F3421303DD936FD4461242012925, ___mIsLocked_1)); }
	inline bool get_mIsLocked_1() const { return ___mIsLocked_1; }
	inline bool* get_address_of_mIsLocked_1() { return &___mIsLocked_1; }
	inline void set_mIsLocked_1(bool value)
	{
		___mIsLocked_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONFIGURATION_TBB4510742434F3421303DD936FD4461242012925_H
#ifndef SIGNALINGCONFIG_TAE908484943C078C7439EB1A31243A983F6904EB_H
#define SIGNALINGCONFIG_TAE908484943C078C7439EB1A31243A983F6904EB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.SignalingConfig
struct  SignalingConfig_tAE908484943C078C7439EB1A31243A983F6904EB  : public RuntimeObject
{
public:
	// System.Boolean Byn.Awrtc.Base.SignalingConfig::mInUse
	bool ___mInUse_0;
	// Byn.Awrtc.IBasicNetwork Byn.Awrtc.Base.SignalingConfig::mNetwork
	RuntimeObject* ___mNetwork_1;
	// System.Boolean Byn.Awrtc.Base.SignalingConfig::mKeepSignalingAlive
	bool ___mKeepSignalingAlive_2;
	// System.Int32 Byn.Awrtc.Base.SignalingConfig::mSignalingTimeout
	int32_t ___mSignalingTimeout_3;

public:
	inline static int32_t get_offset_of_mInUse_0() { return static_cast<int32_t>(offsetof(SignalingConfig_tAE908484943C078C7439EB1A31243A983F6904EB, ___mInUse_0)); }
	inline bool get_mInUse_0() const { return ___mInUse_0; }
	inline bool* get_address_of_mInUse_0() { return &___mInUse_0; }
	inline void set_mInUse_0(bool value)
	{
		___mInUse_0 = value;
	}

	inline static int32_t get_offset_of_mNetwork_1() { return static_cast<int32_t>(offsetof(SignalingConfig_tAE908484943C078C7439EB1A31243A983F6904EB, ___mNetwork_1)); }
	inline RuntimeObject* get_mNetwork_1() const { return ___mNetwork_1; }
	inline RuntimeObject** get_address_of_mNetwork_1() { return &___mNetwork_1; }
	inline void set_mNetwork_1(RuntimeObject* value)
	{
		___mNetwork_1 = value;
		Il2CppCodeGenWriteBarrier((&___mNetwork_1), value);
	}

	inline static int32_t get_offset_of_mKeepSignalingAlive_2() { return static_cast<int32_t>(offsetof(SignalingConfig_tAE908484943C078C7439EB1A31243A983F6904EB, ___mKeepSignalingAlive_2)); }
	inline bool get_mKeepSignalingAlive_2() const { return ___mKeepSignalingAlive_2; }
	inline bool* get_address_of_mKeepSignalingAlive_2() { return &___mKeepSignalingAlive_2; }
	inline void set_mKeepSignalingAlive_2(bool value)
	{
		___mKeepSignalingAlive_2 = value;
	}

	inline static int32_t get_offset_of_mSignalingTimeout_3() { return static_cast<int32_t>(offsetof(SignalingConfig_tAE908484943C078C7439EB1A31243A983F6904EB, ___mSignalingTimeout_3)); }
	inline int32_t get_mSignalingTimeout_3() const { return ___mSignalingTimeout_3; }
	inline int32_t* get_address_of_mSignalingTimeout_3() { return &___mSignalingTimeout_3; }
	inline void set_mSignalingTimeout_3(int32_t value)
	{
		___mSignalingTimeout_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SIGNALINGCONFIG_TAE908484943C078C7439EB1A31243A983F6904EB_H
#ifndef WEBSOCKETCLOSESTATUS_TBD293DB70FBE1059C1963C590268417F875EA0D0_H
#define WEBSOCKETCLOSESTATUS_TBD293DB70FBE1059C1963C590268417F875EA0D0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.WebsocketCloseStatus
struct  WebsocketCloseStatus_tBD293DB70FBE1059C1963C590268417F875EA0D0  : public RuntimeObject
{
public:

public:
};

struct WebsocketCloseStatus_tBD293DB70FBE1059C1963C590268417F875EA0D0_StaticFields
{
public:
	// System.UInt16 Byn.Awrtc.Base.WebsocketCloseStatus::NORMAL_CLOSURE
	uint16_t ___NORMAL_CLOSURE_0;
	// System.UInt16 Byn.Awrtc.Base.WebsocketCloseStatus::ABNORMAL_CLOSURE
	uint16_t ___ABNORMAL_CLOSURE_1;
	// System.UInt16 Byn.Awrtc.Base.WebsocketCloseStatus::TLS_HANDSHAKE
	uint16_t ___TLS_HANDSHAKE_2;
	// System.UInt16 Byn.Awrtc.Base.WebsocketCloseStatus::UNKNOWN_WEBSOCKET_ERROR
	uint16_t ___UNKNOWN_WEBSOCKET_ERROR_3;

public:
	inline static int32_t get_offset_of_NORMAL_CLOSURE_0() { return static_cast<int32_t>(offsetof(WebsocketCloseStatus_tBD293DB70FBE1059C1963C590268417F875EA0D0_StaticFields, ___NORMAL_CLOSURE_0)); }
	inline uint16_t get_NORMAL_CLOSURE_0() const { return ___NORMAL_CLOSURE_0; }
	inline uint16_t* get_address_of_NORMAL_CLOSURE_0() { return &___NORMAL_CLOSURE_0; }
	inline void set_NORMAL_CLOSURE_0(uint16_t value)
	{
		___NORMAL_CLOSURE_0 = value;
	}

	inline static int32_t get_offset_of_ABNORMAL_CLOSURE_1() { return static_cast<int32_t>(offsetof(WebsocketCloseStatus_tBD293DB70FBE1059C1963C590268417F875EA0D0_StaticFields, ___ABNORMAL_CLOSURE_1)); }
	inline uint16_t get_ABNORMAL_CLOSURE_1() const { return ___ABNORMAL_CLOSURE_1; }
	inline uint16_t* get_address_of_ABNORMAL_CLOSURE_1() { return &___ABNORMAL_CLOSURE_1; }
	inline void set_ABNORMAL_CLOSURE_1(uint16_t value)
	{
		___ABNORMAL_CLOSURE_1 = value;
	}

	inline static int32_t get_offset_of_TLS_HANDSHAKE_2() { return static_cast<int32_t>(offsetof(WebsocketCloseStatus_tBD293DB70FBE1059C1963C590268417F875EA0D0_StaticFields, ___TLS_HANDSHAKE_2)); }
	inline uint16_t get_TLS_HANDSHAKE_2() const { return ___TLS_HANDSHAKE_2; }
	inline uint16_t* get_address_of_TLS_HANDSHAKE_2() { return &___TLS_HANDSHAKE_2; }
	inline void set_TLS_HANDSHAKE_2(uint16_t value)
	{
		___TLS_HANDSHAKE_2 = value;
	}

	inline static int32_t get_offset_of_UNKNOWN_WEBSOCKET_ERROR_3() { return static_cast<int32_t>(offsetof(WebsocketCloseStatus_tBD293DB70FBE1059C1963C590268417F875EA0D0_StaticFields, ___UNKNOWN_WEBSOCKET_ERROR_3)); }
	inline uint16_t get_UNKNOWN_WEBSOCKET_ERROR_3() const { return ___UNKNOWN_WEBSOCKET_ERROR_3; }
	inline uint16_t* get_address_of_UNKNOWN_WEBSOCKET_ERROR_3() { return &___UNKNOWN_WEBSOCKET_ERROR_3; }
	inline void set_UNKNOWN_WEBSOCKET_ERROR_3(uint16_t value)
	{
		___UNKNOWN_WEBSOCKET_ERROR_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WEBSOCKETCLOSESTATUS_TBD293DB70FBE1059C1963C590268417F875EA0D0_H
#ifndef DIRECTMEMORYFRAME_TB02233733990ED13957B176CEEF1A0389AB7309D_H
#define DIRECTMEMORYFRAME_TB02233733990ED13957B176CEEF1A0389AB7309D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Native.DirectMemoryFrame
struct  DirectMemoryFrame_tB02233733990ED13957B176CEEF1A0389AB7309D  : public RuntimeObject
{
public:
	// System.Int32 Byn.Awrtc.Native.DirectMemoryFrame::mHeight
	int32_t ___mHeight_0;
	// System.Int32 Byn.Awrtc.Native.DirectMemoryFrame::mWidth
	int32_t ___mWidth_1;
	// System.Int32 Byn.Awrtc.Native.DirectMemoryFrame::mRotation
	int32_t ___mRotation_2;
	// WebRtcCSharp.PollingMediaStreamRef Byn.Awrtc.Native.DirectMemoryFrame::mParent
	PollingMediaStreamRef_t18D181FB11B17D2C311E98F81850263E3BA73798 * ___mParent_3;

public:
	inline static int32_t get_offset_of_mHeight_0() { return static_cast<int32_t>(offsetof(DirectMemoryFrame_tB02233733990ED13957B176CEEF1A0389AB7309D, ___mHeight_0)); }
	inline int32_t get_mHeight_0() const { return ___mHeight_0; }
	inline int32_t* get_address_of_mHeight_0() { return &___mHeight_0; }
	inline void set_mHeight_0(int32_t value)
	{
		___mHeight_0 = value;
	}

	inline static int32_t get_offset_of_mWidth_1() { return static_cast<int32_t>(offsetof(DirectMemoryFrame_tB02233733990ED13957B176CEEF1A0389AB7309D, ___mWidth_1)); }
	inline int32_t get_mWidth_1() const { return ___mWidth_1; }
	inline int32_t* get_address_of_mWidth_1() { return &___mWidth_1; }
	inline void set_mWidth_1(int32_t value)
	{
		___mWidth_1 = value;
	}

	inline static int32_t get_offset_of_mRotation_2() { return static_cast<int32_t>(offsetof(DirectMemoryFrame_tB02233733990ED13957B176CEEF1A0389AB7309D, ___mRotation_2)); }
	inline int32_t get_mRotation_2() const { return ___mRotation_2; }
	inline int32_t* get_address_of_mRotation_2() { return &___mRotation_2; }
	inline void set_mRotation_2(int32_t value)
	{
		___mRotation_2 = value;
	}

	inline static int32_t get_offset_of_mParent_3() { return static_cast<int32_t>(offsetof(DirectMemoryFrame_tB02233733990ED13957B176CEEF1A0389AB7309D, ___mParent_3)); }
	inline PollingMediaStreamRef_t18D181FB11B17D2C311E98F81850263E3BA73798 * get_mParent_3() const { return ___mParent_3; }
	inline PollingMediaStreamRef_t18D181FB11B17D2C311E98F81850263E3BA73798 ** get_address_of_mParent_3() { return &___mParent_3; }
	inline void set_mParent_3(PollingMediaStreamRef_t18D181FB11B17D2C311E98F81850263E3BA73798 * value)
	{
		___mParent_3 = value;
		Il2CppCodeGenWriteBarrier((&___mParent_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DIRECTMEMORYFRAME_TB02233733990ED13957B176CEEF1A0389AB7309D_H
#ifndef INTERNALMEDIASTREAM_T32927ED6BA0825B6E3496C839448E13C69C9AFE1_H
#define INTERNALMEDIASTREAM_T32927ED6BA0825B6E3496C839448E13C69C9AFE1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Native.InternalMediaStream
struct  InternalMediaStream_t32927ED6BA0825B6E3496C839448E13C69C9AFE1  : public RuntimeObject
{
public:
	// Byn.Awrtc.Native.NativeAwrtcFactory Byn.Awrtc.Native.InternalMediaStream::mFactory
	NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 * ___mFactory_0;
	// Byn.Awrtc.MediaConfig Byn.Awrtc.Native.InternalMediaStream::mConfig
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___mConfig_1;
	// WebRtcCSharp.PollingMediaStreamRef Byn.Awrtc.Native.InternalMediaStream::mStream
	PollingMediaStreamRef_t18D181FB11B17D2C311E98F81850263E3BA73798 * ___mStream_2;
	// Byn.Awrtc.BufferedFrame Byn.Awrtc.Native.InternalMediaStream::mBuffer
	BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028 * ___mBuffer_3;

public:
	inline static int32_t get_offset_of_mFactory_0() { return static_cast<int32_t>(offsetof(InternalMediaStream_t32927ED6BA0825B6E3496C839448E13C69C9AFE1, ___mFactory_0)); }
	inline NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 * get_mFactory_0() const { return ___mFactory_0; }
	inline NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 ** get_address_of_mFactory_0() { return &___mFactory_0; }
	inline void set_mFactory_0(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 * value)
	{
		___mFactory_0 = value;
		Il2CppCodeGenWriteBarrier((&___mFactory_0), value);
	}

	inline static int32_t get_offset_of_mConfig_1() { return static_cast<int32_t>(offsetof(InternalMediaStream_t32927ED6BA0825B6E3496C839448E13C69C9AFE1, ___mConfig_1)); }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * get_mConfig_1() const { return ___mConfig_1; }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D ** get_address_of_mConfig_1() { return &___mConfig_1; }
	inline void set_mConfig_1(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * value)
	{
		___mConfig_1 = value;
		Il2CppCodeGenWriteBarrier((&___mConfig_1), value);
	}

	inline static int32_t get_offset_of_mStream_2() { return static_cast<int32_t>(offsetof(InternalMediaStream_t32927ED6BA0825B6E3496C839448E13C69C9AFE1, ___mStream_2)); }
	inline PollingMediaStreamRef_t18D181FB11B17D2C311E98F81850263E3BA73798 * get_mStream_2() const { return ___mStream_2; }
	inline PollingMediaStreamRef_t18D181FB11B17D2C311E98F81850263E3BA73798 ** get_address_of_mStream_2() { return &___mStream_2; }
	inline void set_mStream_2(PollingMediaStreamRef_t18D181FB11B17D2C311E98F81850263E3BA73798 * value)
	{
		___mStream_2 = value;
		Il2CppCodeGenWriteBarrier((&___mStream_2), value);
	}

	inline static int32_t get_offset_of_mBuffer_3() { return static_cast<int32_t>(offsetof(InternalMediaStream_t32927ED6BA0825B6E3496C839448E13C69C9AFE1, ___mBuffer_3)); }
	inline BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028 * get_mBuffer_3() const { return ___mBuffer_3; }
	inline BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028 ** get_address_of_mBuffer_3() { return &___mBuffer_3; }
	inline void set_mBuffer_3(BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028 * value)
	{
		___mBuffer_3 = value;
		Il2CppCodeGenWriteBarrier((&___mBuffer_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTERNALMEDIASTREAM_T32927ED6BA0825B6E3496C839448E13C69C9AFE1_H
#ifndef NATIVEVIDEOINPUT_TED1E44C6598D8C56781E19484E523B74C654315C_H
#define NATIVEVIDEOINPUT_TED1E44C6598D8C56781E19484E523B74C654315C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Native.NativeVideoInput
struct  NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C  : public RuntimeObject
{
public:
	// WebRtcCSharp.VideoInputRef Byn.Awrtc.Native.NativeVideoInput::mVideoInput
	VideoInputRef_t27BF06AD74106BD604BAF613B5FB44934E920732 * ___mVideoInput_0;

public:
	inline static int32_t get_offset_of_mVideoInput_0() { return static_cast<int32_t>(offsetof(NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C, ___mVideoInput_0)); }
	inline VideoInputRef_t27BF06AD74106BD604BAF613B5FB44934E920732 * get_mVideoInput_0() const { return ___mVideoInput_0; }
	inline VideoInputRef_t27BF06AD74106BD604BAF613B5FB44934E920732 ** get_address_of_mVideoInput_0() { return &___mVideoInput_0; }
	inline void set_mVideoInput_0(VideoInputRef_t27BF06AD74106BD604BAF613B5FB44934E920732 * value)
	{
		___mVideoInput_0 = value;
		Il2CppCodeGenWriteBarrier((&___mVideoInput_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NATIVEVIDEOINPUT_TED1E44C6598D8C56781E19484E523B74C654315C_H
#ifndef WRAPPERCONVERTER_T85E22D97F43975E960015802134CEC7873374E28_H
#define WRAPPERCONVERTER_T85E22D97F43975E960015802134CEC7873374E28_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Native.WrapperConverter
struct  WrapperConverter_t85E22D97F43975E960015802134CEC7873374E28  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WRAPPERCONVERTER_T85E22D97F43975E960015802134CEC7873374E28_H
#ifndef SLOG_T859DA99D2A0A51C719F956D188DCA86775781CE0_H
#define SLOG_T859DA99D2A0A51C719F956D188DCA86775781CE0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.SLog
struct  SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0  : public RuntimeObject
{
public:

public:
};

struct SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields
{
public:
	// System.String Byn.Awrtc.SLog::TAG_WARNING
	String_t* ___TAG_WARNING_0;
	// System.String Byn.Awrtc.SLog::TAG_ERROR
	String_t* ___TAG_ERROR_1;
	// System.String Byn.Awrtc.SLog::TAG_EXCEPTION
	String_t* ___TAG_EXCEPTION_2;
	// System.String Byn.Awrtc.SLog::TAG_INFO
	String_t* ___TAG_INFO_3;
	// System.String Byn.Awrtc.SLog::TAG_DEBUG
	String_t* ___TAG_DEBUG_4;
	// System.String Byn.Awrtc.SLog::TAG_VERBOSE
	String_t* ___TAG_VERBOSE_5;
	// System.Action`2<System.Object,System.String[]> Byn.Awrtc.SLog::sLogger
	Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 * ___sLogger_6;

public:
	inline static int32_t get_offset_of_TAG_WARNING_0() { return static_cast<int32_t>(offsetof(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields, ___TAG_WARNING_0)); }
	inline String_t* get_TAG_WARNING_0() const { return ___TAG_WARNING_0; }
	inline String_t** get_address_of_TAG_WARNING_0() { return &___TAG_WARNING_0; }
	inline void set_TAG_WARNING_0(String_t* value)
	{
		___TAG_WARNING_0 = value;
		Il2CppCodeGenWriteBarrier((&___TAG_WARNING_0), value);
	}

	inline static int32_t get_offset_of_TAG_ERROR_1() { return static_cast<int32_t>(offsetof(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields, ___TAG_ERROR_1)); }
	inline String_t* get_TAG_ERROR_1() const { return ___TAG_ERROR_1; }
	inline String_t** get_address_of_TAG_ERROR_1() { return &___TAG_ERROR_1; }
	inline void set_TAG_ERROR_1(String_t* value)
	{
		___TAG_ERROR_1 = value;
		Il2CppCodeGenWriteBarrier((&___TAG_ERROR_1), value);
	}

	inline static int32_t get_offset_of_TAG_EXCEPTION_2() { return static_cast<int32_t>(offsetof(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields, ___TAG_EXCEPTION_2)); }
	inline String_t* get_TAG_EXCEPTION_2() const { return ___TAG_EXCEPTION_2; }
	inline String_t** get_address_of_TAG_EXCEPTION_2() { return &___TAG_EXCEPTION_2; }
	inline void set_TAG_EXCEPTION_2(String_t* value)
	{
		___TAG_EXCEPTION_2 = value;
		Il2CppCodeGenWriteBarrier((&___TAG_EXCEPTION_2), value);
	}

	inline static int32_t get_offset_of_TAG_INFO_3() { return static_cast<int32_t>(offsetof(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields, ___TAG_INFO_3)); }
	inline String_t* get_TAG_INFO_3() const { return ___TAG_INFO_3; }
	inline String_t** get_address_of_TAG_INFO_3() { return &___TAG_INFO_3; }
	inline void set_TAG_INFO_3(String_t* value)
	{
		___TAG_INFO_3 = value;
		Il2CppCodeGenWriteBarrier((&___TAG_INFO_3), value);
	}

	inline static int32_t get_offset_of_TAG_DEBUG_4() { return static_cast<int32_t>(offsetof(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields, ___TAG_DEBUG_4)); }
	inline String_t* get_TAG_DEBUG_4() const { return ___TAG_DEBUG_4; }
	inline String_t** get_address_of_TAG_DEBUG_4() { return &___TAG_DEBUG_4; }
	inline void set_TAG_DEBUG_4(String_t* value)
	{
		___TAG_DEBUG_4 = value;
		Il2CppCodeGenWriteBarrier((&___TAG_DEBUG_4), value);
	}

	inline static int32_t get_offset_of_TAG_VERBOSE_5() { return static_cast<int32_t>(offsetof(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields, ___TAG_VERBOSE_5)); }
	inline String_t* get_TAG_VERBOSE_5() const { return ___TAG_VERBOSE_5; }
	inline String_t** get_address_of_TAG_VERBOSE_5() { return &___TAG_VERBOSE_5; }
	inline void set_TAG_VERBOSE_5(String_t* value)
	{
		___TAG_VERBOSE_5 = value;
		Il2CppCodeGenWriteBarrier((&___TAG_VERBOSE_5), value);
	}

	inline static int32_t get_offset_of_sLogger_6() { return static_cast<int32_t>(offsetof(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields, ___sLogger_6)); }
	inline Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 * get_sLogger_6() const { return ___sLogger_6; }
	inline Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 ** get_address_of_sLogger_6() { return &___sLogger_6; }
	inline void set_sLogger_6(Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 * value)
	{
		___sLogger_6 = value;
		Il2CppCodeGenWriteBarrier((&___sLogger_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SLOG_T859DA99D2A0A51C719F956D188DCA86775781CE0_H
#ifndef ATTRIBUTE_TF048C13FB3C8CFCC53F82290E4A3F621089F9A74_H
#define ATTRIBUTE_TF048C13FB3C8CFCC53F82290E4A3F621089F9A74_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Attribute
struct  Attribute_tF048C13FB3C8CFCC53F82290E4A3F621089F9A74  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ATTRIBUTE_TF048C13FB3C8CFCC53F82290E4A3F621089F9A74_H
#ifndef EVENTARGS_T8E6CA180BE0E56674C6407011A94BAF7C757352E_H
#define EVENTARGS_T8E6CA180BE0E56674C6407011A94BAF7C757352E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.EventArgs
struct  EventArgs_t8E6CA180BE0E56674C6407011A94BAF7C757352E  : public RuntimeObject
{
public:

public:
};

struct EventArgs_t8E6CA180BE0E56674C6407011A94BAF7C757352E_StaticFields
{
public:
	// System.EventArgs System.EventArgs::Empty
	EventArgs_t8E6CA180BE0E56674C6407011A94BAF7C757352E * ___Empty_0;

public:
	inline static int32_t get_offset_of_Empty_0() { return static_cast<int32_t>(offsetof(EventArgs_t8E6CA180BE0E56674C6407011A94BAF7C757352E_StaticFields, ___Empty_0)); }
	inline EventArgs_t8E6CA180BE0E56674C6407011A94BAF7C757352E * get_Empty_0() const { return ___Empty_0; }
	inline EventArgs_t8E6CA180BE0E56674C6407011A94BAF7C757352E ** get_address_of_Empty_0() { return &___Empty_0; }
	inline void set_Empty_0(EventArgs_t8E6CA180BE0E56674C6407011A94BAF7C757352E * value)
	{
		___Empty_0 = value;
		Il2CppCodeGenWriteBarrier((&___Empty_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EVENTARGS_T8E6CA180BE0E56674C6407011A94BAF7C757352E_H
#ifndef VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#define VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_com
{
};
#endif // VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#ifndef ICESERVERSENUMERATOR_TFDB2479A21A7AC100DDAAFAE9E3DB95255D97453_H
#define ICESERVERSENUMERATOR_TFDB2479A21A7AC100DDAAFAE9E3DB95255D97453_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.IceServers_IceServersEnumerator
struct  IceServersEnumerator_tFDB2479A21A7AC100DDAAFAE9E3DB95255D97453  : public RuntimeObject
{
public:
	// WebRtcCSharp.IceServers WebRtcCSharp.IceServers_IceServersEnumerator::collectionRef
	IceServers_t731B0B5709F7A24F85388A737619AAD7EC1A73D5 * ___collectionRef_0;
	// System.Int32 WebRtcCSharp.IceServers_IceServersEnumerator::currentIndex
	int32_t ___currentIndex_1;
	// System.Object WebRtcCSharp.IceServers_IceServersEnumerator::currentObject
	RuntimeObject * ___currentObject_2;
	// System.Int32 WebRtcCSharp.IceServers_IceServersEnumerator::currentSize
	int32_t ___currentSize_3;

public:
	inline static int32_t get_offset_of_collectionRef_0() { return static_cast<int32_t>(offsetof(IceServersEnumerator_tFDB2479A21A7AC100DDAAFAE9E3DB95255D97453, ___collectionRef_0)); }
	inline IceServers_t731B0B5709F7A24F85388A737619AAD7EC1A73D5 * get_collectionRef_0() const { return ___collectionRef_0; }
	inline IceServers_t731B0B5709F7A24F85388A737619AAD7EC1A73D5 ** get_address_of_collectionRef_0() { return &___collectionRef_0; }
	inline void set_collectionRef_0(IceServers_t731B0B5709F7A24F85388A737619AAD7EC1A73D5 * value)
	{
		___collectionRef_0 = value;
		Il2CppCodeGenWriteBarrier((&___collectionRef_0), value);
	}

	inline static int32_t get_offset_of_currentIndex_1() { return static_cast<int32_t>(offsetof(IceServersEnumerator_tFDB2479A21A7AC100DDAAFAE9E3DB95255D97453, ___currentIndex_1)); }
	inline int32_t get_currentIndex_1() const { return ___currentIndex_1; }
	inline int32_t* get_address_of_currentIndex_1() { return &___currentIndex_1; }
	inline void set_currentIndex_1(int32_t value)
	{
		___currentIndex_1 = value;
	}

	inline static int32_t get_offset_of_currentObject_2() { return static_cast<int32_t>(offsetof(IceServersEnumerator_tFDB2479A21A7AC100DDAAFAE9E3DB95255D97453, ___currentObject_2)); }
	inline RuntimeObject * get_currentObject_2() const { return ___currentObject_2; }
	inline RuntimeObject ** get_address_of_currentObject_2() { return &___currentObject_2; }
	inline void set_currentObject_2(RuntimeObject * value)
	{
		___currentObject_2 = value;
		Il2CppCodeGenWriteBarrier((&___currentObject_2), value);
	}

	inline static int32_t get_offset_of_currentSize_3() { return static_cast<int32_t>(offsetof(IceServersEnumerator_tFDB2479A21A7AC100DDAAFAE9E3DB95255D97453, ___currentSize_3)); }
	inline int32_t get_currentSize_3() const { return ___currentSize_3; }
	inline int32_t* get_address_of_currentSize_3() { return &___currentSize_3; }
	inline void set_currentSize_3(int32_t value)
	{
		___currentSize_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ICESERVERSENUMERATOR_TFDB2479A21A7AC100DDAAFAE9E3DB95255D97453_H
#ifndef STRINGVECTORENUMERATOR_T6639D180BB44143917F8940944CC54662413FBB3_H
#define STRINGVECTORENUMERATOR_T6639D180BB44143917F8940944CC54662413FBB3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.StringVector_StringVectorEnumerator
struct  StringVectorEnumerator_t6639D180BB44143917F8940944CC54662413FBB3  : public RuntimeObject
{
public:
	// WebRtcCSharp.StringVector WebRtcCSharp.StringVector_StringVectorEnumerator::collectionRef
	StringVector_t7957DE03AFED56C21E38C8C9CBB09D735C95B00C * ___collectionRef_0;
	// System.Int32 WebRtcCSharp.StringVector_StringVectorEnumerator::currentIndex
	int32_t ___currentIndex_1;
	// System.Object WebRtcCSharp.StringVector_StringVectorEnumerator::currentObject
	RuntimeObject * ___currentObject_2;
	// System.Int32 WebRtcCSharp.StringVector_StringVectorEnumerator::currentSize
	int32_t ___currentSize_3;

public:
	inline static int32_t get_offset_of_collectionRef_0() { return static_cast<int32_t>(offsetof(StringVectorEnumerator_t6639D180BB44143917F8940944CC54662413FBB3, ___collectionRef_0)); }
	inline StringVector_t7957DE03AFED56C21E38C8C9CBB09D735C95B00C * get_collectionRef_0() const { return ___collectionRef_0; }
	inline StringVector_t7957DE03AFED56C21E38C8C9CBB09D735C95B00C ** get_address_of_collectionRef_0() { return &___collectionRef_0; }
	inline void set_collectionRef_0(StringVector_t7957DE03AFED56C21E38C8C9CBB09D735C95B00C * value)
	{
		___collectionRef_0 = value;
		Il2CppCodeGenWriteBarrier((&___collectionRef_0), value);
	}

	inline static int32_t get_offset_of_currentIndex_1() { return static_cast<int32_t>(offsetof(StringVectorEnumerator_t6639D180BB44143917F8940944CC54662413FBB3, ___currentIndex_1)); }
	inline int32_t get_currentIndex_1() const { return ___currentIndex_1; }
	inline int32_t* get_address_of_currentIndex_1() { return &___currentIndex_1; }
	inline void set_currentIndex_1(int32_t value)
	{
		___currentIndex_1 = value;
	}

	inline static int32_t get_offset_of_currentObject_2() { return static_cast<int32_t>(offsetof(StringVectorEnumerator_t6639D180BB44143917F8940944CC54662413FBB3, ___currentObject_2)); }
	inline RuntimeObject * get_currentObject_2() const { return ___currentObject_2; }
	inline RuntimeObject ** get_address_of_currentObject_2() { return &___currentObject_2; }
	inline void set_currentObject_2(RuntimeObject * value)
	{
		___currentObject_2 = value;
		Il2CppCodeGenWriteBarrier((&___currentObject_2), value);
	}

	inline static int32_t get_offset_of_currentSize_3() { return static_cast<int32_t>(offsetof(StringVectorEnumerator_t6639D180BB44143917F8940944CC54662413FBB3, ___currentSize_3)); }
	inline int32_t get_currentSize_3() const { return ___currentSize_3; }
	inline int32_t* get_address_of_currentSize_3() { return &___currentSize_3; }
	inline void set_currentSize_3(int32_t value)
	{
		___currentSize_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRINGVECTORENUMERATOR_T6639D180BB44143917F8940944CC54662413FBB3_H
#ifndef WEBRTCSWIGPINVOKE_T921BB9F3105BE7E71866D140294C388567A5FE10_H
#define WEBRTCSWIGPINVOKE_T921BB9F3105BE7E71866D140294C388567A5FE10_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.WebRtcSwigPINVOKE
struct  WebRtcSwigPINVOKE_t921BB9F3105BE7E71866D140294C388567A5FE10  : public RuntimeObject
{
public:

public:
};

struct WebRtcSwigPINVOKE_t921BB9F3105BE7E71866D140294C388567A5FE10_StaticFields
{
public:
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper WebRtcCSharp.WebRtcSwigPINVOKE::swigExceptionHelper
	SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B * ___swigExceptionHelper_0;
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGStringHelper WebRtcCSharp.WebRtcSwigPINVOKE::swigStringHelper
	SWIGStringHelper_t64516B80BD5B451423C2FF303C67724660167FAE * ___swigStringHelper_1;

public:
	inline static int32_t get_offset_of_swigExceptionHelper_0() { return static_cast<int32_t>(offsetof(WebRtcSwigPINVOKE_t921BB9F3105BE7E71866D140294C388567A5FE10_StaticFields, ___swigExceptionHelper_0)); }
	inline SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B * get_swigExceptionHelper_0() const { return ___swigExceptionHelper_0; }
	inline SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B ** get_address_of_swigExceptionHelper_0() { return &___swigExceptionHelper_0; }
	inline void set_swigExceptionHelper_0(SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B * value)
	{
		___swigExceptionHelper_0 = value;
		Il2CppCodeGenWriteBarrier((&___swigExceptionHelper_0), value);
	}

	inline static int32_t get_offset_of_swigStringHelper_1() { return static_cast<int32_t>(offsetof(WebRtcSwigPINVOKE_t921BB9F3105BE7E71866D140294C388567A5FE10_StaticFields, ___swigStringHelper_1)); }
	inline SWIGStringHelper_t64516B80BD5B451423C2FF303C67724660167FAE * get_swigStringHelper_1() const { return ___swigStringHelper_1; }
	inline SWIGStringHelper_t64516B80BD5B451423C2FF303C67724660167FAE ** get_address_of_swigStringHelper_1() { return &___swigStringHelper_1; }
	inline void set_swigStringHelper_1(SWIGStringHelper_t64516B80BD5B451423C2FF303C67724660167FAE * value)
	{
		___swigStringHelper_1 = value;
		Il2CppCodeGenWriteBarrier((&___swigStringHelper_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WEBRTCSWIGPINVOKE_T921BB9F3105BE7E71866D140294C388567A5FE10_H
#ifndef SWIGEXCEPTIONHELPER_TCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_H
#define SWIGEXCEPTIONHELPER_TCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper
struct  SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B  : public RuntimeObject
{
public:

public:
};

struct SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields
{
public:
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper_ExceptionDelegate WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper::applicationDelegate
	ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * ___applicationDelegate_0;
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper_ExceptionDelegate WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper::arithmeticDelegate
	ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * ___arithmeticDelegate_1;
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper_ExceptionDelegate WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper::divideByZeroDelegate
	ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * ___divideByZeroDelegate_2;
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper_ExceptionDelegate WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper::indexOutOfRangeDelegate
	ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * ___indexOutOfRangeDelegate_3;
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper_ExceptionDelegate WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper::invalidCastDelegate
	ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * ___invalidCastDelegate_4;
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper_ExceptionDelegate WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper::invalidOperationDelegate
	ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * ___invalidOperationDelegate_5;
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper_ExceptionDelegate WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper::ioDelegate
	ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * ___ioDelegate_6;
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper_ExceptionDelegate WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper::nullReferenceDelegate
	ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * ___nullReferenceDelegate_7;
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper_ExceptionDelegate WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper::outOfMemoryDelegate
	ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * ___outOfMemoryDelegate_8;
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper_ExceptionDelegate WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper::overflowDelegate
	ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * ___overflowDelegate_9;
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper_ExceptionDelegate WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper::systemDelegate
	ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * ___systemDelegate_10;
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper_ExceptionArgumentDelegate WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper::argumentDelegate
	ExceptionArgumentDelegate_t6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C * ___argumentDelegate_11;
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper_ExceptionArgumentDelegate WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper::argumentNullDelegate
	ExceptionArgumentDelegate_t6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C * ___argumentNullDelegate_12;
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper_ExceptionArgumentDelegate WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper::argumentOutOfRangeDelegate
	ExceptionArgumentDelegate_t6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C * ___argumentOutOfRangeDelegate_13;

public:
	inline static int32_t get_offset_of_applicationDelegate_0() { return static_cast<int32_t>(offsetof(SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields, ___applicationDelegate_0)); }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * get_applicationDelegate_0() const { return ___applicationDelegate_0; }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 ** get_address_of_applicationDelegate_0() { return &___applicationDelegate_0; }
	inline void set_applicationDelegate_0(ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * value)
	{
		___applicationDelegate_0 = value;
		Il2CppCodeGenWriteBarrier((&___applicationDelegate_0), value);
	}

	inline static int32_t get_offset_of_arithmeticDelegate_1() { return static_cast<int32_t>(offsetof(SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields, ___arithmeticDelegate_1)); }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * get_arithmeticDelegate_1() const { return ___arithmeticDelegate_1; }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 ** get_address_of_arithmeticDelegate_1() { return &___arithmeticDelegate_1; }
	inline void set_arithmeticDelegate_1(ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * value)
	{
		___arithmeticDelegate_1 = value;
		Il2CppCodeGenWriteBarrier((&___arithmeticDelegate_1), value);
	}

	inline static int32_t get_offset_of_divideByZeroDelegate_2() { return static_cast<int32_t>(offsetof(SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields, ___divideByZeroDelegate_2)); }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * get_divideByZeroDelegate_2() const { return ___divideByZeroDelegate_2; }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 ** get_address_of_divideByZeroDelegate_2() { return &___divideByZeroDelegate_2; }
	inline void set_divideByZeroDelegate_2(ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * value)
	{
		___divideByZeroDelegate_2 = value;
		Il2CppCodeGenWriteBarrier((&___divideByZeroDelegate_2), value);
	}

	inline static int32_t get_offset_of_indexOutOfRangeDelegate_3() { return static_cast<int32_t>(offsetof(SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields, ___indexOutOfRangeDelegate_3)); }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * get_indexOutOfRangeDelegate_3() const { return ___indexOutOfRangeDelegate_3; }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 ** get_address_of_indexOutOfRangeDelegate_3() { return &___indexOutOfRangeDelegate_3; }
	inline void set_indexOutOfRangeDelegate_3(ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * value)
	{
		___indexOutOfRangeDelegate_3 = value;
		Il2CppCodeGenWriteBarrier((&___indexOutOfRangeDelegate_3), value);
	}

	inline static int32_t get_offset_of_invalidCastDelegate_4() { return static_cast<int32_t>(offsetof(SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields, ___invalidCastDelegate_4)); }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * get_invalidCastDelegate_4() const { return ___invalidCastDelegate_4; }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 ** get_address_of_invalidCastDelegate_4() { return &___invalidCastDelegate_4; }
	inline void set_invalidCastDelegate_4(ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * value)
	{
		___invalidCastDelegate_4 = value;
		Il2CppCodeGenWriteBarrier((&___invalidCastDelegate_4), value);
	}

	inline static int32_t get_offset_of_invalidOperationDelegate_5() { return static_cast<int32_t>(offsetof(SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields, ___invalidOperationDelegate_5)); }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * get_invalidOperationDelegate_5() const { return ___invalidOperationDelegate_5; }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 ** get_address_of_invalidOperationDelegate_5() { return &___invalidOperationDelegate_5; }
	inline void set_invalidOperationDelegate_5(ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * value)
	{
		___invalidOperationDelegate_5 = value;
		Il2CppCodeGenWriteBarrier((&___invalidOperationDelegate_5), value);
	}

	inline static int32_t get_offset_of_ioDelegate_6() { return static_cast<int32_t>(offsetof(SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields, ___ioDelegate_6)); }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * get_ioDelegate_6() const { return ___ioDelegate_6; }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 ** get_address_of_ioDelegate_6() { return &___ioDelegate_6; }
	inline void set_ioDelegate_6(ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * value)
	{
		___ioDelegate_6 = value;
		Il2CppCodeGenWriteBarrier((&___ioDelegate_6), value);
	}

	inline static int32_t get_offset_of_nullReferenceDelegate_7() { return static_cast<int32_t>(offsetof(SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields, ___nullReferenceDelegate_7)); }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * get_nullReferenceDelegate_7() const { return ___nullReferenceDelegate_7; }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 ** get_address_of_nullReferenceDelegate_7() { return &___nullReferenceDelegate_7; }
	inline void set_nullReferenceDelegate_7(ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * value)
	{
		___nullReferenceDelegate_7 = value;
		Il2CppCodeGenWriteBarrier((&___nullReferenceDelegate_7), value);
	}

	inline static int32_t get_offset_of_outOfMemoryDelegate_8() { return static_cast<int32_t>(offsetof(SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields, ___outOfMemoryDelegate_8)); }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * get_outOfMemoryDelegate_8() const { return ___outOfMemoryDelegate_8; }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 ** get_address_of_outOfMemoryDelegate_8() { return &___outOfMemoryDelegate_8; }
	inline void set_outOfMemoryDelegate_8(ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * value)
	{
		___outOfMemoryDelegate_8 = value;
		Il2CppCodeGenWriteBarrier((&___outOfMemoryDelegate_8), value);
	}

	inline static int32_t get_offset_of_overflowDelegate_9() { return static_cast<int32_t>(offsetof(SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields, ___overflowDelegate_9)); }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * get_overflowDelegate_9() const { return ___overflowDelegate_9; }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 ** get_address_of_overflowDelegate_9() { return &___overflowDelegate_9; }
	inline void set_overflowDelegate_9(ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * value)
	{
		___overflowDelegate_9 = value;
		Il2CppCodeGenWriteBarrier((&___overflowDelegate_9), value);
	}

	inline static int32_t get_offset_of_systemDelegate_10() { return static_cast<int32_t>(offsetof(SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields, ___systemDelegate_10)); }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * get_systemDelegate_10() const { return ___systemDelegate_10; }
	inline ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 ** get_address_of_systemDelegate_10() { return &___systemDelegate_10; }
	inline void set_systemDelegate_10(ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6 * value)
	{
		___systemDelegate_10 = value;
		Il2CppCodeGenWriteBarrier((&___systemDelegate_10), value);
	}

	inline static int32_t get_offset_of_argumentDelegate_11() { return static_cast<int32_t>(offsetof(SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields, ___argumentDelegate_11)); }
	inline ExceptionArgumentDelegate_t6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C * get_argumentDelegate_11() const { return ___argumentDelegate_11; }
	inline ExceptionArgumentDelegate_t6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C ** get_address_of_argumentDelegate_11() { return &___argumentDelegate_11; }
	inline void set_argumentDelegate_11(ExceptionArgumentDelegate_t6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C * value)
	{
		___argumentDelegate_11 = value;
		Il2CppCodeGenWriteBarrier((&___argumentDelegate_11), value);
	}

	inline static int32_t get_offset_of_argumentNullDelegate_12() { return static_cast<int32_t>(offsetof(SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields, ___argumentNullDelegate_12)); }
	inline ExceptionArgumentDelegate_t6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C * get_argumentNullDelegate_12() const { return ___argumentNullDelegate_12; }
	inline ExceptionArgumentDelegate_t6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C ** get_address_of_argumentNullDelegate_12() { return &___argumentNullDelegate_12; }
	inline void set_argumentNullDelegate_12(ExceptionArgumentDelegate_t6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C * value)
	{
		___argumentNullDelegate_12 = value;
		Il2CppCodeGenWriteBarrier((&___argumentNullDelegate_12), value);
	}

	inline static int32_t get_offset_of_argumentOutOfRangeDelegate_13() { return static_cast<int32_t>(offsetof(SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields, ___argumentOutOfRangeDelegate_13)); }
	inline ExceptionArgumentDelegate_t6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C * get_argumentOutOfRangeDelegate_13() const { return ___argumentOutOfRangeDelegate_13; }
	inline ExceptionArgumentDelegate_t6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C ** get_address_of_argumentOutOfRangeDelegate_13() { return &___argumentOutOfRangeDelegate_13; }
	inline void set_argumentOutOfRangeDelegate_13(ExceptionArgumentDelegate_t6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C * value)
	{
		___argumentOutOfRangeDelegate_13 = value;
		Il2CppCodeGenWriteBarrier((&___argumentOutOfRangeDelegate_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SWIGEXCEPTIONHELPER_TCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_H
#ifndef SWIGPENDINGEXCEPTION_T1777B1503C90F4B51470811A9BA0E4B6CA09C366_H
#define SWIGPENDINGEXCEPTION_T1777B1503C90F4B51470811A9BA0E4B6CA09C366_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGPendingException
struct  SWIGPendingException_t1777B1503C90F4B51470811A9BA0E4B6CA09C366  : public RuntimeObject
{
public:

public:
};

struct SWIGPendingException_t1777B1503C90F4B51470811A9BA0E4B6CA09C366_StaticFields
{
public:
	// System.Int32 WebRtcCSharp.WebRtcSwigPINVOKE_SWIGPendingException::numExceptionsPending
	int32_t ___numExceptionsPending_1;

public:
	inline static int32_t get_offset_of_numExceptionsPending_1() { return static_cast<int32_t>(offsetof(SWIGPendingException_t1777B1503C90F4B51470811A9BA0E4B6CA09C366_StaticFields, ___numExceptionsPending_1)); }
	inline int32_t get_numExceptionsPending_1() const { return ___numExceptionsPending_1; }
	inline int32_t* get_address_of_numExceptionsPending_1() { return &___numExceptionsPending_1; }
	inline void set_numExceptionsPending_1(int32_t value)
	{
		___numExceptionsPending_1 = value;
	}
};

struct SWIGPendingException_t1777B1503C90F4B51470811A9BA0E4B6CA09C366_ThreadStaticFields
{
public:
	// System.Exception WebRtcCSharp.WebRtcSwigPINVOKE_SWIGPendingException::pendingException
	Exception_t * ___pendingException_0;

public:
	inline static int32_t get_offset_of_pendingException_0() { return static_cast<int32_t>(offsetof(SWIGPendingException_t1777B1503C90F4B51470811A9BA0E4B6CA09C366_ThreadStaticFields, ___pendingException_0)); }
	inline Exception_t * get_pendingException_0() const { return ___pendingException_0; }
	inline Exception_t ** get_address_of_pendingException_0() { return &___pendingException_0; }
	inline void set_pendingException_0(Exception_t * value)
	{
		___pendingException_0 = value;
		Il2CppCodeGenWriteBarrier((&___pendingException_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SWIGPENDINGEXCEPTION_T1777B1503C90F4B51470811A9BA0E4B6CA09C366_H
#ifndef SWIGSTRINGHELPER_T64516B80BD5B451423C2FF303C67724660167FAE_H
#define SWIGSTRINGHELPER_T64516B80BD5B451423C2FF303C67724660167FAE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGStringHelper
struct  SWIGStringHelper_t64516B80BD5B451423C2FF303C67724660167FAE  : public RuntimeObject
{
public:

public:
};

struct SWIGStringHelper_t64516B80BD5B451423C2FF303C67724660167FAE_StaticFields
{
public:
	// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGStringHelper_SWIGStringDelegate WebRtcCSharp.WebRtcSwigPINVOKE_SWIGStringHelper::stringDelegate
	SWIGStringDelegate_t27E7F38AF0AE0B2F586E097415E20C13A0C17EB4 * ___stringDelegate_0;

public:
	inline static int32_t get_offset_of_stringDelegate_0() { return static_cast<int32_t>(offsetof(SWIGStringHelper_t64516B80BD5B451423C2FF303C67724660167FAE_StaticFields, ___stringDelegate_0)); }
	inline SWIGStringDelegate_t27E7F38AF0AE0B2F586E097415E20C13A0C17EB4 * get_stringDelegate_0() const { return ___stringDelegate_0; }
	inline SWIGStringDelegate_t27E7F38AF0AE0B2F586E097415E20C13A0C17EB4 ** get_address_of_stringDelegate_0() { return &___stringDelegate_0; }
	inline void set_stringDelegate_0(SWIGStringDelegate_t27E7F38AF0AE0B2F586E097415E20C13A0C17EB4 * value)
	{
		___stringDelegate_0 = value;
		Il2CppCodeGenWriteBarrier((&___stringDelegate_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SWIGSTRINGHELPER_T64516B80BD5B451423C2FF303C67724660167FAE_H
#ifndef EXT_T756812041453FEF828B4FC514A1A83EC29124E3F_H
#define EXT_T756812041453FEF828B4FC514A1A83EC29124E3F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebSocketSharpUnityMod.Ext
struct  Ext_t756812041453FEF828B4FC514A1A83EC29124E3F  : public RuntimeObject
{
public:

public:
};

struct Ext_t756812041453FEF828B4FC514A1A83EC29124E3F_StaticFields
{
public:
	// System.Byte[] WebSocketSharpUnityMod.Ext::_last
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ____last_0;
	// System.Func`2<System.String,System.Boolean> WebSocketSharpUnityMod.Ext::CSU24<>9__CachedAnonymousMethodDelegate1
	Func_2_t3AD4B0F443BFD399C4AC2D6EE99FFE3BC0970017 * ___CSU24U3CU3E9__CachedAnonymousMethodDelegate1_1;

public:
	inline static int32_t get_offset_of__last_0() { return static_cast<int32_t>(offsetof(Ext_t756812041453FEF828B4FC514A1A83EC29124E3F_StaticFields, ____last_0)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get__last_0() const { return ____last_0; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of__last_0() { return &____last_0; }
	inline void set__last_0(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		____last_0 = value;
		Il2CppCodeGenWriteBarrier((&____last_0), value);
	}

	inline static int32_t get_offset_of_CSU24U3CU3E9__CachedAnonymousMethodDelegate1_1() { return static_cast<int32_t>(offsetof(Ext_t756812041453FEF828B4FC514A1A83EC29124E3F_StaticFields, ___CSU24U3CU3E9__CachedAnonymousMethodDelegate1_1)); }
	inline Func_2_t3AD4B0F443BFD399C4AC2D6EE99FFE3BC0970017 * get_CSU24U3CU3E9__CachedAnonymousMethodDelegate1_1() const { return ___CSU24U3CU3E9__CachedAnonymousMethodDelegate1_1; }
	inline Func_2_t3AD4B0F443BFD399C4AC2D6EE99FFE3BC0970017 ** get_address_of_CSU24U3CU3E9__CachedAnonymousMethodDelegate1_1() { return &___CSU24U3CU3E9__CachedAnonymousMethodDelegate1_1; }
	inline void set_CSU24U3CU3E9__CachedAnonymousMethodDelegate1_1(Func_2_t3AD4B0F443BFD399C4AC2D6EE99FFE3BC0970017 * value)
	{
		___CSU24U3CU3E9__CachedAnonymousMethodDelegate1_1 = value;
		Il2CppCodeGenWriteBarrier((&___CSU24U3CU3E9__CachedAnonymousMethodDelegate1_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXT_T756812041453FEF828B4FC514A1A83EC29124E3F_H
#ifndef U3CU3EC__DISPLAYCLASS3_TD2AD6483A06BF14044CC5EF480A7D0DE718AF59E_H
#define U3CU3EC__DISPLAYCLASS3_TD2AD6483A06BF14044CC5EF480A7D0DE718AF59E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebSocketSharpUnityMod.Ext_<>c__DisplayClass3
struct  U3CU3Ec__DisplayClass3_tD2AD6483A06BF14044CC5EF480A7D0DE718AF59E  : public RuntimeObject
{
public:
	// System.Int32 WebSocketSharpUnityMod.Ext_<>c__DisplayClass3::len
	int32_t ___len_0;
	// System.Func`2<System.Int32,System.Boolean> WebSocketSharpUnityMod.Ext_<>c__DisplayClass3::contains
	Func_2_tCFDBA11D752C6255254F6FE7B5D68152CA5D2618 * ___contains_1;
	// System.String[] WebSocketSharpUnityMod.Ext_<>c__DisplayClass3::values
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___values_2;

public:
	inline static int32_t get_offset_of_len_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass3_tD2AD6483A06BF14044CC5EF480A7D0DE718AF59E, ___len_0)); }
	inline int32_t get_len_0() const { return ___len_0; }
	inline int32_t* get_address_of_len_0() { return &___len_0; }
	inline void set_len_0(int32_t value)
	{
		___len_0 = value;
	}

	inline static int32_t get_offset_of_contains_1() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass3_tD2AD6483A06BF14044CC5EF480A7D0DE718AF59E, ___contains_1)); }
	inline Func_2_tCFDBA11D752C6255254F6FE7B5D68152CA5D2618 * get_contains_1() const { return ___contains_1; }
	inline Func_2_tCFDBA11D752C6255254F6FE7B5D68152CA5D2618 ** get_address_of_contains_1() { return &___contains_1; }
	inline void set_contains_1(Func_2_tCFDBA11D752C6255254F6FE7B5D68152CA5D2618 * value)
	{
		___contains_1 = value;
		Il2CppCodeGenWriteBarrier((&___contains_1), value);
	}

	inline static int32_t get_offset_of_values_2() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass3_tD2AD6483A06BF14044CC5EF480A7D0DE718AF59E, ___values_2)); }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* get_values_2() const { return ___values_2; }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E** get_address_of_values_2() { return &___values_2; }
	inline void set_values_2(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* value)
	{
		___values_2 = value;
		Il2CppCodeGenWriteBarrier((&___values_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC__DISPLAYCLASS3_TD2AD6483A06BF14044CC5EF480A7D0DE718AF59E_H
#ifndef U3CU3EC__DISPLAYCLASS9_T4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2_H
#define U3CU3EC__DISPLAYCLASS9_T4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebSocketSharpUnityMod.Ext_<>c__DisplayClass9
struct  U3CU3Ec__DisplayClass9_t4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2  : public RuntimeObject
{
public:
	// System.Byte[] WebSocketSharpUnityMod.Ext_<>c__DisplayClass9::buff
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___buff_0;
	// System.Int32 WebSocketSharpUnityMod.Ext_<>c__DisplayClass9::offset
	int32_t ___offset_1;
	// System.AsyncCallback WebSocketSharpUnityMod.Ext_<>c__DisplayClass9::callback
	AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4 * ___callback_2;
	// System.IO.Stream WebSocketSharpUnityMod.Ext_<>c__DisplayClass9::stream
	Stream_tFC50657DD5AAB87770987F9179D934A51D99D5E7 * ___stream_3;
	// System.Int32 WebSocketSharpUnityMod.Ext_<>c__DisplayClass9::length
	int32_t ___length_4;
	// System.Action`1<System.Byte[]> WebSocketSharpUnityMod.Ext_<>c__DisplayClass9::completed
	Action_1_t67D6E8441D0DE589716B25B9D8F0D4412B593398 * ___completed_5;
	// System.Action`1<System.Exception> WebSocketSharpUnityMod.Ext_<>c__DisplayClass9::error
	Action_1_t18E730906A964925D355310DF8D8719A7B2CB3FC * ___error_6;

public:
	inline static int32_t get_offset_of_buff_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass9_t4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2, ___buff_0)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get_buff_0() const { return ___buff_0; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of_buff_0() { return &___buff_0; }
	inline void set_buff_0(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		___buff_0 = value;
		Il2CppCodeGenWriteBarrier((&___buff_0), value);
	}

	inline static int32_t get_offset_of_offset_1() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass9_t4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2, ___offset_1)); }
	inline int32_t get_offset_1() const { return ___offset_1; }
	inline int32_t* get_address_of_offset_1() { return &___offset_1; }
	inline void set_offset_1(int32_t value)
	{
		___offset_1 = value;
	}

	inline static int32_t get_offset_of_callback_2() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass9_t4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2, ___callback_2)); }
	inline AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4 * get_callback_2() const { return ___callback_2; }
	inline AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4 ** get_address_of_callback_2() { return &___callback_2; }
	inline void set_callback_2(AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4 * value)
	{
		___callback_2 = value;
		Il2CppCodeGenWriteBarrier((&___callback_2), value);
	}

	inline static int32_t get_offset_of_stream_3() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass9_t4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2, ___stream_3)); }
	inline Stream_tFC50657DD5AAB87770987F9179D934A51D99D5E7 * get_stream_3() const { return ___stream_3; }
	inline Stream_tFC50657DD5AAB87770987F9179D934A51D99D5E7 ** get_address_of_stream_3() { return &___stream_3; }
	inline void set_stream_3(Stream_tFC50657DD5AAB87770987F9179D934A51D99D5E7 * value)
	{
		___stream_3 = value;
		Il2CppCodeGenWriteBarrier((&___stream_3), value);
	}

	inline static int32_t get_offset_of_length_4() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass9_t4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2, ___length_4)); }
	inline int32_t get_length_4() const { return ___length_4; }
	inline int32_t* get_address_of_length_4() { return &___length_4; }
	inline void set_length_4(int32_t value)
	{
		___length_4 = value;
	}

	inline static int32_t get_offset_of_completed_5() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass9_t4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2, ___completed_5)); }
	inline Action_1_t67D6E8441D0DE589716B25B9D8F0D4412B593398 * get_completed_5() const { return ___completed_5; }
	inline Action_1_t67D6E8441D0DE589716B25B9D8F0D4412B593398 ** get_address_of_completed_5() { return &___completed_5; }
	inline void set_completed_5(Action_1_t67D6E8441D0DE589716B25B9D8F0D4412B593398 * value)
	{
		___completed_5 = value;
		Il2CppCodeGenWriteBarrier((&___completed_5), value);
	}

	inline static int32_t get_offset_of_error_6() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass9_t4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2, ___error_6)); }
	inline Action_1_t18E730906A964925D355310DF8D8719A7B2CB3FC * get_error_6() const { return ___error_6; }
	inline Action_1_t18E730906A964925D355310DF8D8719A7B2CB3FC ** get_address_of_error_6() { return &___error_6; }
	inline void set_error_6(Action_1_t18E730906A964925D355310DF8D8719A7B2CB3FC * value)
	{
		___error_6 = value;
		Il2CppCodeGenWriteBarrier((&___error_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC__DISPLAYCLASS9_T4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2_H
#ifndef U3CU3EC__DISPLAYCLASSD_TFD96FE44A9970FD916A0B430D0895FF58CDEA7FF_H
#define U3CU3EC__DISPLAYCLASSD_TFD96FE44A9970FD916A0B430D0895FF58CDEA7FF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebSocketSharpUnityMod.Ext_<>c__DisplayClassd
struct  U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF  : public RuntimeObject
{
public:
	// System.IO.MemoryStream WebSocketSharpUnityMod.Ext_<>c__DisplayClassd::dest
	MemoryStream_t495F44B85E6B4DDE2BB7E17DE963256A74E2298C * ___dest_0;
	// System.Byte[] WebSocketSharpUnityMod.Ext_<>c__DisplayClassd::buff
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___buff_1;
	// System.Action`1<System.Int64> WebSocketSharpUnityMod.Ext_<>c__DisplayClassd::read
	Action_1_t74F6DAC6E0AC7CAEE1EB04923F21C044D4939B1A * ___read_2;
	// System.IO.Stream WebSocketSharpUnityMod.Ext_<>c__DisplayClassd::stream
	Stream_tFC50657DD5AAB87770987F9179D934A51D99D5E7 * ___stream_3;
	// System.Int32 WebSocketSharpUnityMod.Ext_<>c__DisplayClassd::bufferLength
	int32_t ___bufferLength_4;
	// System.Action`1<System.Byte[]> WebSocketSharpUnityMod.Ext_<>c__DisplayClassd::completed
	Action_1_t67D6E8441D0DE589716B25B9D8F0D4412B593398 * ___completed_5;
	// System.Action`1<System.Exception> WebSocketSharpUnityMod.Ext_<>c__DisplayClassd::error
	Action_1_t18E730906A964925D355310DF8D8719A7B2CB3FC * ___error_6;

public:
	inline static int32_t get_offset_of_dest_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF, ___dest_0)); }
	inline MemoryStream_t495F44B85E6B4DDE2BB7E17DE963256A74E2298C * get_dest_0() const { return ___dest_0; }
	inline MemoryStream_t495F44B85E6B4DDE2BB7E17DE963256A74E2298C ** get_address_of_dest_0() { return &___dest_0; }
	inline void set_dest_0(MemoryStream_t495F44B85E6B4DDE2BB7E17DE963256A74E2298C * value)
	{
		___dest_0 = value;
		Il2CppCodeGenWriteBarrier((&___dest_0), value);
	}

	inline static int32_t get_offset_of_buff_1() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF, ___buff_1)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get_buff_1() const { return ___buff_1; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of_buff_1() { return &___buff_1; }
	inline void set_buff_1(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		___buff_1 = value;
		Il2CppCodeGenWriteBarrier((&___buff_1), value);
	}

	inline static int32_t get_offset_of_read_2() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF, ___read_2)); }
	inline Action_1_t74F6DAC6E0AC7CAEE1EB04923F21C044D4939B1A * get_read_2() const { return ___read_2; }
	inline Action_1_t74F6DAC6E0AC7CAEE1EB04923F21C044D4939B1A ** get_address_of_read_2() { return &___read_2; }
	inline void set_read_2(Action_1_t74F6DAC6E0AC7CAEE1EB04923F21C044D4939B1A * value)
	{
		___read_2 = value;
		Il2CppCodeGenWriteBarrier((&___read_2), value);
	}

	inline static int32_t get_offset_of_stream_3() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF, ___stream_3)); }
	inline Stream_tFC50657DD5AAB87770987F9179D934A51D99D5E7 * get_stream_3() const { return ___stream_3; }
	inline Stream_tFC50657DD5AAB87770987F9179D934A51D99D5E7 ** get_address_of_stream_3() { return &___stream_3; }
	inline void set_stream_3(Stream_tFC50657DD5AAB87770987F9179D934A51D99D5E7 * value)
	{
		___stream_3 = value;
		Il2CppCodeGenWriteBarrier((&___stream_3), value);
	}

	inline static int32_t get_offset_of_bufferLength_4() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF, ___bufferLength_4)); }
	inline int32_t get_bufferLength_4() const { return ___bufferLength_4; }
	inline int32_t* get_address_of_bufferLength_4() { return &___bufferLength_4; }
	inline void set_bufferLength_4(int32_t value)
	{
		___bufferLength_4 = value;
	}

	inline static int32_t get_offset_of_completed_5() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF, ___completed_5)); }
	inline Action_1_t67D6E8441D0DE589716B25B9D8F0D4412B593398 * get_completed_5() const { return ___completed_5; }
	inline Action_1_t67D6E8441D0DE589716B25B9D8F0D4412B593398 ** get_address_of_completed_5() { return &___completed_5; }
	inline void set_completed_5(Action_1_t67D6E8441D0DE589716B25B9D8F0D4412B593398 * value)
	{
		___completed_5 = value;
		Il2CppCodeGenWriteBarrier((&___completed_5), value);
	}

	inline static int32_t get_offset_of_error_6() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF, ___error_6)); }
	inline Action_1_t18E730906A964925D355310DF8D8719A7B2CB3FC * get_error_6() const { return ___error_6; }
	inline Action_1_t18E730906A964925D355310DF8D8719A7B2CB3FC ** get_address_of_error_6() { return &___error_6; }
	inline void set_error_6(Action_1_t18E730906A964925D355310DF8D8719A7B2CB3FC * value)
	{
		___error_6 = value;
		Il2CppCodeGenWriteBarrier((&___error_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC__DISPLAYCLASSD_TFD96FE44A9970FD916A0B430D0895FF58CDEA7FF_H
#ifndef U3CU3EC__DISPLAYCLASSF_T820CDEE2E00B3094A0F79408D0A677A3FBFD74D9_H
#define U3CU3EC__DISPLAYCLASSF_T820CDEE2E00B3094A0F79408D0A677A3FBFD74D9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebSocketSharpUnityMod.Ext_<>c__DisplayClassd_<>c__DisplayClassf
struct  U3CU3Ec__DisplayClassf_t820CDEE2E00B3094A0F79408D0A677A3FBFD74D9  : public RuntimeObject
{
public:
	// WebSocketSharpUnityMod.Ext_<>c__DisplayClassd WebSocketSharpUnityMod.Ext_<>c__DisplayClassd_<>c__DisplayClassf::CSU24<>8__localse
	U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF * ___CSU24U3CU3E8__localse_0;
	// System.Int64 WebSocketSharpUnityMod.Ext_<>c__DisplayClassd_<>c__DisplayClassf::len
	int64_t ___len_1;

public:
	inline static int32_t get_offset_of_CSU24U3CU3E8__localse_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClassf_t820CDEE2E00B3094A0F79408D0A677A3FBFD74D9, ___CSU24U3CU3E8__localse_0)); }
	inline U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF * get_CSU24U3CU3E8__localse_0() const { return ___CSU24U3CU3E8__localse_0; }
	inline U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF ** get_address_of_CSU24U3CU3E8__localse_0() { return &___CSU24U3CU3E8__localse_0; }
	inline void set_CSU24U3CU3E8__localse_0(U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF * value)
	{
		___CSU24U3CU3E8__localse_0 = value;
		Il2CppCodeGenWriteBarrier((&___CSU24U3CU3E8__localse_0), value);
	}

	inline static int32_t get_offset_of_len_1() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClassf_t820CDEE2E00B3094A0F79408D0A677A3FBFD74D9, ___len_1)); }
	inline int64_t get_len_1() const { return ___len_1; }
	inline int64_t* get_address_of_len_1() { return &___len_1; }
	inline void set_len_1(int64_t value)
	{
		___len_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC__DISPLAYCLASSF_T820CDEE2E00B3094A0F79408D0A677A3FBFD74D9_H
#ifndef U3CSPLITHEADERVALUEU3ED__11_T5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04_H
#define U3CSPLITHEADERVALUEU3ED__11_T5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebSocketSharpUnityMod.Ext_<SplitHeaderValue>d__11
struct  U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04  : public RuntimeObject
{
public:
	// System.String WebSocketSharpUnityMod.Ext_<SplitHeaderValue>d__11::<>2__current
	String_t* ___U3CU3E2__current_0;
	// System.Int32 WebSocketSharpUnityMod.Ext_<SplitHeaderValue>d__11::<>1__state
	int32_t ___U3CU3E1__state_1;
	// System.Int32 WebSocketSharpUnityMod.Ext_<SplitHeaderValue>d__11::<>l__initialThreadId
	int32_t ___U3CU3El__initialThreadId_2;
	// System.String WebSocketSharpUnityMod.Ext_<SplitHeaderValue>d__11::value
	String_t* ___value_3;
	// System.String WebSocketSharpUnityMod.Ext_<SplitHeaderValue>d__11::<>3__value
	String_t* ___U3CU3E3__value_4;
	// System.Char[] WebSocketSharpUnityMod.Ext_<SplitHeaderValue>d__11::separators
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___separators_5;
	// System.Char[] WebSocketSharpUnityMod.Ext_<SplitHeaderValue>d__11::<>3__separators
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___U3CU3E3__separators_6;
	// System.Int32 WebSocketSharpUnityMod.Ext_<SplitHeaderValue>d__11::<len>5__12
	int32_t ___U3ClenU3E5__12_7;
	// System.String WebSocketSharpUnityMod.Ext_<SplitHeaderValue>d__11::<seps>5__13
	String_t* ___U3CsepsU3E5__13_8;
	// System.Text.StringBuilder WebSocketSharpUnityMod.Ext_<SplitHeaderValue>d__11::<buff>5__14
	StringBuilder_t * ___U3CbuffU3E5__14_9;
	// System.Boolean WebSocketSharpUnityMod.Ext_<SplitHeaderValue>d__11::<escaped>5__15
	bool ___U3CescapedU3E5__15_10;
	// System.Boolean WebSocketSharpUnityMod.Ext_<SplitHeaderValue>d__11::<quoted>5__16
	bool ___U3CquotedU3E5__16_11;
	// System.Int32 WebSocketSharpUnityMod.Ext_<SplitHeaderValue>d__11::<i>5__17
	int32_t ___U3CiU3E5__17_12;
	// System.Char WebSocketSharpUnityMod.Ext_<SplitHeaderValue>d__11::<c>5__18
	Il2CppChar ___U3CcU3E5__18_13;

public:
	inline static int32_t get_offset_of_U3CU3E2__current_0() { return static_cast<int32_t>(offsetof(U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04, ___U3CU3E2__current_0)); }
	inline String_t* get_U3CU3E2__current_0() const { return ___U3CU3E2__current_0; }
	inline String_t** get_address_of_U3CU3E2__current_0() { return &___U3CU3E2__current_0; }
	inline void set_U3CU3E2__current_0(String_t* value)
	{
		___U3CU3E2__current_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_0), value);
	}

	inline static int32_t get_offset_of_U3CU3E1__state_1() { return static_cast<int32_t>(offsetof(U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04, ___U3CU3E1__state_1)); }
	inline int32_t get_U3CU3E1__state_1() const { return ___U3CU3E1__state_1; }
	inline int32_t* get_address_of_U3CU3E1__state_1() { return &___U3CU3E1__state_1; }
	inline void set_U3CU3E1__state_1(int32_t value)
	{
		___U3CU3E1__state_1 = value;
	}

	inline static int32_t get_offset_of_U3CU3El__initialThreadId_2() { return static_cast<int32_t>(offsetof(U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04, ___U3CU3El__initialThreadId_2)); }
	inline int32_t get_U3CU3El__initialThreadId_2() const { return ___U3CU3El__initialThreadId_2; }
	inline int32_t* get_address_of_U3CU3El__initialThreadId_2() { return &___U3CU3El__initialThreadId_2; }
	inline void set_U3CU3El__initialThreadId_2(int32_t value)
	{
		___U3CU3El__initialThreadId_2 = value;
	}

	inline static int32_t get_offset_of_value_3() { return static_cast<int32_t>(offsetof(U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04, ___value_3)); }
	inline String_t* get_value_3() const { return ___value_3; }
	inline String_t** get_address_of_value_3() { return &___value_3; }
	inline void set_value_3(String_t* value)
	{
		___value_3 = value;
		Il2CppCodeGenWriteBarrier((&___value_3), value);
	}

	inline static int32_t get_offset_of_U3CU3E3__value_4() { return static_cast<int32_t>(offsetof(U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04, ___U3CU3E3__value_4)); }
	inline String_t* get_U3CU3E3__value_4() const { return ___U3CU3E3__value_4; }
	inline String_t** get_address_of_U3CU3E3__value_4() { return &___U3CU3E3__value_4; }
	inline void set_U3CU3E3__value_4(String_t* value)
	{
		___U3CU3E3__value_4 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E3__value_4), value);
	}

	inline static int32_t get_offset_of_separators_5() { return static_cast<int32_t>(offsetof(U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04, ___separators_5)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_separators_5() const { return ___separators_5; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_separators_5() { return &___separators_5; }
	inline void set_separators_5(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___separators_5 = value;
		Il2CppCodeGenWriteBarrier((&___separators_5), value);
	}

	inline static int32_t get_offset_of_U3CU3E3__separators_6() { return static_cast<int32_t>(offsetof(U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04, ___U3CU3E3__separators_6)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_U3CU3E3__separators_6() const { return ___U3CU3E3__separators_6; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_U3CU3E3__separators_6() { return &___U3CU3E3__separators_6; }
	inline void set_U3CU3E3__separators_6(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___U3CU3E3__separators_6 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E3__separators_6), value);
	}

	inline static int32_t get_offset_of_U3ClenU3E5__12_7() { return static_cast<int32_t>(offsetof(U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04, ___U3ClenU3E5__12_7)); }
	inline int32_t get_U3ClenU3E5__12_7() const { return ___U3ClenU3E5__12_7; }
	inline int32_t* get_address_of_U3ClenU3E5__12_7() { return &___U3ClenU3E5__12_7; }
	inline void set_U3ClenU3E5__12_7(int32_t value)
	{
		___U3ClenU3E5__12_7 = value;
	}

	inline static int32_t get_offset_of_U3CsepsU3E5__13_8() { return static_cast<int32_t>(offsetof(U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04, ___U3CsepsU3E5__13_8)); }
	inline String_t* get_U3CsepsU3E5__13_8() const { return ___U3CsepsU3E5__13_8; }
	inline String_t** get_address_of_U3CsepsU3E5__13_8() { return &___U3CsepsU3E5__13_8; }
	inline void set_U3CsepsU3E5__13_8(String_t* value)
	{
		___U3CsepsU3E5__13_8 = value;
		Il2CppCodeGenWriteBarrier((&___U3CsepsU3E5__13_8), value);
	}

	inline static int32_t get_offset_of_U3CbuffU3E5__14_9() { return static_cast<int32_t>(offsetof(U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04, ___U3CbuffU3E5__14_9)); }
	inline StringBuilder_t * get_U3CbuffU3E5__14_9() const { return ___U3CbuffU3E5__14_9; }
	inline StringBuilder_t ** get_address_of_U3CbuffU3E5__14_9() { return &___U3CbuffU3E5__14_9; }
	inline void set_U3CbuffU3E5__14_9(StringBuilder_t * value)
	{
		___U3CbuffU3E5__14_9 = value;
		Il2CppCodeGenWriteBarrier((&___U3CbuffU3E5__14_9), value);
	}

	inline static int32_t get_offset_of_U3CescapedU3E5__15_10() { return static_cast<int32_t>(offsetof(U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04, ___U3CescapedU3E5__15_10)); }
	inline bool get_U3CescapedU3E5__15_10() const { return ___U3CescapedU3E5__15_10; }
	inline bool* get_address_of_U3CescapedU3E5__15_10() { return &___U3CescapedU3E5__15_10; }
	inline void set_U3CescapedU3E5__15_10(bool value)
	{
		___U3CescapedU3E5__15_10 = value;
	}

	inline static int32_t get_offset_of_U3CquotedU3E5__16_11() { return static_cast<int32_t>(offsetof(U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04, ___U3CquotedU3E5__16_11)); }
	inline bool get_U3CquotedU3E5__16_11() const { return ___U3CquotedU3E5__16_11; }
	inline bool* get_address_of_U3CquotedU3E5__16_11() { return &___U3CquotedU3E5__16_11; }
	inline void set_U3CquotedU3E5__16_11(bool value)
	{
		___U3CquotedU3E5__16_11 = value;
	}

	inline static int32_t get_offset_of_U3CiU3E5__17_12() { return static_cast<int32_t>(offsetof(U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04, ___U3CiU3E5__17_12)); }
	inline int32_t get_U3CiU3E5__17_12() const { return ___U3CiU3E5__17_12; }
	inline int32_t* get_address_of_U3CiU3E5__17_12() { return &___U3CiU3E5__17_12; }
	inline void set_U3CiU3E5__17_12(int32_t value)
	{
		___U3CiU3E5__17_12 = value;
	}

	inline static int32_t get_offset_of_U3CcU3E5__18_13() { return static_cast<int32_t>(offsetof(U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04, ___U3CcU3E5__18_13)); }
	inline Il2CppChar get_U3CcU3E5__18_13() const { return ___U3CcU3E5__18_13; }
	inline Il2CppChar* get_address_of_U3CcU3E5__18_13() { return &___U3CcU3E5__18_13; }
	inline void set_U3CcU3E5__18_13(Il2CppChar value)
	{
		___U3CcU3E5__18_13 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CSPLITHEADERVALUEU3ED__11_T5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04_H
#ifndef HTTPBASE_TEAFC723C72301668B9EE251A06C4F3A1389C9827_H
#define HTTPBASE_TEAFC723C72301668B9EE251A06C4F3A1389C9827_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebSocketSharpUnityMod.HttpBase
struct  HttpBase_tEAFC723C72301668B9EE251A06C4F3A1389C9827  : public RuntimeObject
{
public:
	// System.Collections.Specialized.NameValueCollection WebSocketSharpUnityMod.HttpBase::_headers
	NameValueCollection_t7C7CED43E4C6E997E3C8012F1D2CC4027FAD10D1 * ____headers_0;
	// System.Version WebSocketSharpUnityMod.HttpBase::_version
	Version_tDBE6876C59B6F56D4F8CAA03851177ABC6FE0DFD * ____version_1;
	// System.Byte[] WebSocketSharpUnityMod.HttpBase::EntityBodyData
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___EntityBodyData_2;

public:
	inline static int32_t get_offset_of__headers_0() { return static_cast<int32_t>(offsetof(HttpBase_tEAFC723C72301668B9EE251A06C4F3A1389C9827, ____headers_0)); }
	inline NameValueCollection_t7C7CED43E4C6E997E3C8012F1D2CC4027FAD10D1 * get__headers_0() const { return ____headers_0; }
	inline NameValueCollection_t7C7CED43E4C6E997E3C8012F1D2CC4027FAD10D1 ** get_address_of__headers_0() { return &____headers_0; }
	inline void set__headers_0(NameValueCollection_t7C7CED43E4C6E997E3C8012F1D2CC4027FAD10D1 * value)
	{
		____headers_0 = value;
		Il2CppCodeGenWriteBarrier((&____headers_0), value);
	}

	inline static int32_t get_offset_of__version_1() { return static_cast<int32_t>(offsetof(HttpBase_tEAFC723C72301668B9EE251A06C4F3A1389C9827, ____version_1)); }
	inline Version_tDBE6876C59B6F56D4F8CAA03851177ABC6FE0DFD * get__version_1() const { return ____version_1; }
	inline Version_tDBE6876C59B6F56D4F8CAA03851177ABC6FE0DFD ** get_address_of__version_1() { return &____version_1; }
	inline void set__version_1(Version_tDBE6876C59B6F56D4F8CAA03851177ABC6FE0DFD * value)
	{
		____version_1 = value;
		Il2CppCodeGenWriteBarrier((&____version_1), value);
	}

	inline static int32_t get_offset_of_EntityBodyData_2() { return static_cast<int32_t>(offsetof(HttpBase_tEAFC723C72301668B9EE251A06C4F3A1389C9827, ___EntityBodyData_2)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get_EntityBodyData_2() const { return ___EntityBodyData_2; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of_EntityBodyData_2() { return &___EntityBodyData_2; }
	inline void set_EntityBodyData_2(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		___EntityBodyData_2 = value;
		Il2CppCodeGenWriteBarrier((&___EntityBodyData_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HTTPBASE_TEAFC723C72301668B9EE251A06C4F3A1389C9827_H
#ifndef U3CU3EC__DISPLAYCLASS1_T53206D4373207FB34286B48742E1C6004AF5AD5A_H
#define U3CU3EC__DISPLAYCLASS1_T53206D4373207FB34286B48742E1C6004AF5AD5A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebSocketSharpUnityMod.HttpBase_<>c__DisplayClass1
struct  U3CU3Ec__DisplayClass1_t53206D4373207FB34286B48742E1C6004AF5AD5A  : public RuntimeObject
{
public:
	// System.Collections.Generic.List`1<System.Byte> WebSocketSharpUnityMod.HttpBase_<>c__DisplayClass1::buff
	List_1_t2E429D48492C9F1ED16C7D74224A8AAB590A7B32 * ___buff_0;
	// System.Int32 WebSocketSharpUnityMod.HttpBase_<>c__DisplayClass1::cnt
	int32_t ___cnt_1;

public:
	inline static int32_t get_offset_of_buff_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass1_t53206D4373207FB34286B48742E1C6004AF5AD5A, ___buff_0)); }
	inline List_1_t2E429D48492C9F1ED16C7D74224A8AAB590A7B32 * get_buff_0() const { return ___buff_0; }
	inline List_1_t2E429D48492C9F1ED16C7D74224A8AAB590A7B32 ** get_address_of_buff_0() { return &___buff_0; }
	inline void set_buff_0(List_1_t2E429D48492C9F1ED16C7D74224A8AAB590A7B32 * value)
	{
		___buff_0 = value;
		Il2CppCodeGenWriteBarrier((&___buff_0), value);
	}

	inline static int32_t get_offset_of_cnt_1() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass1_t53206D4373207FB34286B48742E1C6004AF5AD5A, ___cnt_1)); }
	inline int32_t get_cnt_1() const { return ___cnt_1; }
	inline int32_t* get_address_of_cnt_1() { return &___cnt_1; }
	inline void set_cnt_1(int32_t value)
	{
		___cnt_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC__DISPLAYCLASS1_T53206D4373207FB34286B48742E1C6004AF5AD5A_H
#ifndef __STATICARRAYINITTYPESIZEU3D128_TA1E351C123D4FE21E27968CB84AB3C9993E5ABDE_H
#define __STATICARRAYINITTYPESIZEU3D128_TA1E351C123D4FE21E27968CB84AB3C9993E5ABDE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>U7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D___StaticArrayInitTypeSizeU3D128
struct  __StaticArrayInitTypeSizeU3D128_tA1E351C123D4FE21E27968CB84AB3C9993E5ABDE 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D128_tA1E351C123D4FE21E27968CB84AB3C9993E5ABDE__padding[128];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // __STATICARRAYINITTYPESIZEU3D128_TA1E351C123D4FE21E27968CB84AB3C9993E5ABDE_H
#ifndef CONNECTIONID_T47DBB761AF0DB1559EACE774B317DA2B8B67F66D_H
#define CONNECTIONID_T47DBB761AF0DB1559EACE774B317DA2B8B67F66D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.ConnectionId
struct  ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D 
{
public:
	// System.Int16 Byn.Awrtc.ConnectionId::id
	int16_t ___id_1;

public:
	inline static int32_t get_offset_of_id_1() { return static_cast<int32_t>(offsetof(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D, ___id_1)); }
	inline int16_t get_id_1() const { return ___id_1; }
	inline int16_t* get_address_of_id_1() { return &___id_1; }
	inline void set_id_1(int16_t value)
	{
		___id_1 = value;
	}
};

struct ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields
{
public:
	// Byn.Awrtc.ConnectionId Byn.Awrtc.ConnectionId::INVALID
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___INVALID_0;

public:
	inline static int32_t get_offset_of_INVALID_0() { return static_cast<int32_t>(offsetof(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields, ___INVALID_0)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_INVALID_0() const { return ___INVALID_0; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_INVALID_0() { return &___INVALID_0; }
	inline void set_INVALID_0(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___INVALID_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONNECTIONID_T47DBB761AF0DB1559EACE774B317DA2B8B67F66D_H
#ifndef DATETIME_T349B7449FBAAFF4192636E2B7A07694DA9236132_H
#define DATETIME_T349B7449FBAAFF4192636E2B7A07694DA9236132_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.DateTime
struct  DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132 
{
public:
	// System.UInt64 System.DateTime::dateData
	uint64_t ___dateData_44;

public:
	inline static int32_t get_offset_of_dateData_44() { return static_cast<int32_t>(offsetof(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132, ___dateData_44)); }
	inline uint64_t get_dateData_44() const { return ___dateData_44; }
	inline uint64_t* get_address_of_dateData_44() { return &___dateData_44; }
	inline void set_dateData_44(uint64_t value)
	{
		___dateData_44 = value;
	}
};

struct DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132_StaticFields
{
public:
	// System.Int32[] System.DateTime::DaysToMonth365
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___DaysToMonth365_29;
	// System.Int32[] System.DateTime::DaysToMonth366
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___DaysToMonth366_30;
	// System.DateTime System.DateTime::MinValue
	DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  ___MinValue_31;
	// System.DateTime System.DateTime::MaxValue
	DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  ___MaxValue_32;

public:
	inline static int32_t get_offset_of_DaysToMonth365_29() { return static_cast<int32_t>(offsetof(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132_StaticFields, ___DaysToMonth365_29)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_DaysToMonth365_29() const { return ___DaysToMonth365_29; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_DaysToMonth365_29() { return &___DaysToMonth365_29; }
	inline void set_DaysToMonth365_29(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___DaysToMonth365_29 = value;
		Il2CppCodeGenWriteBarrier((&___DaysToMonth365_29), value);
	}

	inline static int32_t get_offset_of_DaysToMonth366_30() { return static_cast<int32_t>(offsetof(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132_StaticFields, ___DaysToMonth366_30)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_DaysToMonth366_30() const { return ___DaysToMonth366_30; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_DaysToMonth366_30() { return &___DaysToMonth366_30; }
	inline void set_DaysToMonth366_30(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___DaysToMonth366_30 = value;
		Il2CppCodeGenWriteBarrier((&___DaysToMonth366_30), value);
	}

	inline static int32_t get_offset_of_MinValue_31() { return static_cast<int32_t>(offsetof(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132_StaticFields, ___MinValue_31)); }
	inline DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  get_MinValue_31() const { return ___MinValue_31; }
	inline DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132 * get_address_of_MinValue_31() { return &___MinValue_31; }
	inline void set_MinValue_31(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  value)
	{
		___MinValue_31 = value;
	}

	inline static int32_t get_offset_of_MaxValue_32() { return static_cast<int32_t>(offsetof(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132_StaticFields, ___MaxValue_32)); }
	inline DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  get_MaxValue_32() const { return ___MaxValue_32; }
	inline DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132 * get_address_of_MaxValue_32() { return &___MaxValue_32; }
	inline void set_MaxValue_32(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  value)
	{
		___MaxValue_32 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DATETIME_T349B7449FBAAFF4192636E2B7A07694DA9236132_H
#ifndef ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#define ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t2AF27C02B8653AE29442467390005ABC74D8F521  : public ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF
{
public:

public:
};

struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((&___enumSeperatorCharArray_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_com
{
};
#endif // ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#ifndef INT32_T585191389E07734F19F3156FF88FB3EF4800D102_H
#define INT32_T585191389E07734F19F3156FF88FB3EF4800D102_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Int32
struct  Int32_t585191389E07734F19F3156FF88FB3EF4800D102 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int32_t585191389E07734F19F3156FF88FB3EF4800D102, ___m_value_0)); }
	inline int32_t get_m_value_0() const { return ___m_value_0; }
	inline int32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int32_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INT32_T585191389E07734F19F3156FF88FB3EF4800D102_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef NULLABLE_1_T9E6A67BECE376F0623B5C857F5674A0311C41793_H
#define NULLABLE_1_T9E6A67BECE376F0623B5C857F5674A0311C41793_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Nullable`1<System.Boolean>
struct  Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793 
{
public:
	// T System.Nullable`1::value
	bool ___value_0;
	// System.Boolean System.Nullable`1::has_value
	bool ___has_value_1;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793, ___value_0)); }
	inline bool get_value_0() const { return ___value_0; }
	inline bool* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(bool value)
	{
		___value_0 = value;
	}

	inline static int32_t get_offset_of_has_value_1() { return static_cast<int32_t>(offsetof(Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793, ___has_value_1)); }
	inline bool get_has_value_1() const { return ___has_value_1; }
	inline bool* get_address_of_has_value_1() { return &___has_value_1; }
	inline void set_has_value_1(bool value)
	{
		___has_value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NULLABLE_1_T9E6A67BECE376F0623B5C857F5674A0311C41793_H
#ifndef NULLABLE_1_T0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_H
#define NULLABLE_1_T0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Nullable`1<System.Int32>
struct  Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB 
{
public:
	// T System.Nullable`1::value
	int32_t ___value_0;
	// System.Boolean System.Nullable`1::has_value
	bool ___has_value_1;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB, ___value_0)); }
	inline int32_t get_value_0() const { return ___value_0; }
	inline int32_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(int32_t value)
	{
		___value_0 = value;
	}

	inline static int32_t get_offset_of_has_value_1() { return static_cast<int32_t>(offsetof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB, ___has_value_1)); }
	inline bool get_has_value_1() const { return ___has_value_1; }
	inline bool* get_address_of_has_value_1() { return &___has_value_1; }
	inline void set_has_value_1(bool value)
	{
		___has_value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NULLABLE_1_T0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_H
#ifndef VOID_T22962CB4C05B1D89B55A6E1139F0E87A90987017_H
#define VOID_T22962CB4C05B1D89B55A6E1139F0E87A90987017_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Void
struct  Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017__padding[1];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VOID_T22962CB4C05B1D89B55A6E1139F0E87A90987017_H
#ifndef MONOPINVOKECALLBACKATTRIBUTE_TC67C9F6F4A2466F4173DDF27B809EE8F118A3E15_H
#define MONOPINVOKECALLBACKATTRIBUTE_TC67C9F6F4A2466F4173DDF27B809EE8F118A3E15_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.MonoPInvokeCallbackAttribute
struct  MonoPInvokeCallbackAttribute_tC67C9F6F4A2466F4173DDF27B809EE8F118A3E15  : public Attribute_tF048C13FB3C8CFCC53F82290E4A3F621089F9A74
{
public:
	// System.Type WebRtcCSharp.MonoPInvokeCallbackAttribute::type
	Type_t * ___type_0;

public:
	inline static int32_t get_offset_of_type_0() { return static_cast<int32_t>(offsetof(MonoPInvokeCallbackAttribute_tC67C9F6F4A2466F4173DDF27B809EE8F118A3E15, ___type_0)); }
	inline Type_t * get_type_0() const { return ___type_0; }
	inline Type_t ** get_address_of_type_0() { return &___type_0; }
	inline void set_type_0(Type_t * value)
	{
		___type_0 = value;
		Il2CppCodeGenWriteBarrier((&___type_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONOPINVOKECALLBACKATTRIBUTE_TC67C9F6F4A2466F4173DDF27B809EE8F118A3E15_H
#ifndef CLOSEEVENTARGS_TB42CE0192EA8BBCD8652D0B99DB0410D1BF7D438_H
#define CLOSEEVENTARGS_TB42CE0192EA8BBCD8652D0B99DB0410D1BF7D438_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebSocketSharpUnityMod.CloseEventArgs
struct  CloseEventArgs_tB42CE0192EA8BBCD8652D0B99DB0410D1BF7D438  : public EventArgs_t8E6CA180BE0E56674C6407011A94BAF7C757352E
{
public:
	// System.Boolean WebSocketSharpUnityMod.CloseEventArgs::_clean
	bool ____clean_1;
	// System.UInt16 WebSocketSharpUnityMod.CloseEventArgs::_code
	uint16_t ____code_2;
	// WebSocketSharpUnityMod.PayloadData WebSocketSharpUnityMod.CloseEventArgs::_payloadData
	PayloadData_t4B96E74F30C652A6DB0D6FCDA1CF1C88E1791ECE * ____payloadData_3;
	// System.String WebSocketSharpUnityMod.CloseEventArgs::_reason
	String_t* ____reason_4;

public:
	inline static int32_t get_offset_of__clean_1() { return static_cast<int32_t>(offsetof(CloseEventArgs_tB42CE0192EA8BBCD8652D0B99DB0410D1BF7D438, ____clean_1)); }
	inline bool get__clean_1() const { return ____clean_1; }
	inline bool* get_address_of__clean_1() { return &____clean_1; }
	inline void set__clean_1(bool value)
	{
		____clean_1 = value;
	}

	inline static int32_t get_offset_of__code_2() { return static_cast<int32_t>(offsetof(CloseEventArgs_tB42CE0192EA8BBCD8652D0B99DB0410D1BF7D438, ____code_2)); }
	inline uint16_t get__code_2() const { return ____code_2; }
	inline uint16_t* get_address_of__code_2() { return &____code_2; }
	inline void set__code_2(uint16_t value)
	{
		____code_2 = value;
	}

	inline static int32_t get_offset_of__payloadData_3() { return static_cast<int32_t>(offsetof(CloseEventArgs_tB42CE0192EA8BBCD8652D0B99DB0410D1BF7D438, ____payloadData_3)); }
	inline PayloadData_t4B96E74F30C652A6DB0D6FCDA1CF1C88E1791ECE * get__payloadData_3() const { return ____payloadData_3; }
	inline PayloadData_t4B96E74F30C652A6DB0D6FCDA1CF1C88E1791ECE ** get_address_of__payloadData_3() { return &____payloadData_3; }
	inline void set__payloadData_3(PayloadData_t4B96E74F30C652A6DB0D6FCDA1CF1C88E1791ECE * value)
	{
		____payloadData_3 = value;
		Il2CppCodeGenWriteBarrier((&____payloadData_3), value);
	}

	inline static int32_t get_offset_of__reason_4() { return static_cast<int32_t>(offsetof(CloseEventArgs_tB42CE0192EA8BBCD8652D0B99DB0410D1BF7D438, ____reason_4)); }
	inline String_t* get__reason_4() const { return ____reason_4; }
	inline String_t** get_address_of__reason_4() { return &____reason_4; }
	inline void set__reason_4(String_t* value)
	{
		____reason_4 = value;
		Il2CppCodeGenWriteBarrier((&____reason_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CLOSEEVENTARGS_TB42CE0192EA8BBCD8652D0B99DB0410D1BF7D438_H
#ifndef ERROREVENTARGS_T4BAD210F4B2115EE3C212AF622ECE6B81679FA26_H
#define ERROREVENTARGS_T4BAD210F4B2115EE3C212AF622ECE6B81679FA26_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebSocketSharpUnityMod.ErrorEventArgs
struct  ErrorEventArgs_t4BAD210F4B2115EE3C212AF622ECE6B81679FA26  : public EventArgs_t8E6CA180BE0E56674C6407011A94BAF7C757352E
{
public:
	// System.Exception WebSocketSharpUnityMod.ErrorEventArgs::_exception
	Exception_t * ____exception_1;
	// System.String WebSocketSharpUnityMod.ErrorEventArgs::_message
	String_t* ____message_2;

public:
	inline static int32_t get_offset_of__exception_1() { return static_cast<int32_t>(offsetof(ErrorEventArgs_t4BAD210F4B2115EE3C212AF622ECE6B81679FA26, ____exception_1)); }
	inline Exception_t * get__exception_1() const { return ____exception_1; }
	inline Exception_t ** get_address_of__exception_1() { return &____exception_1; }
	inline void set__exception_1(Exception_t * value)
	{
		____exception_1 = value;
		Il2CppCodeGenWriteBarrier((&____exception_1), value);
	}

	inline static int32_t get_offset_of__message_2() { return static_cast<int32_t>(offsetof(ErrorEventArgs_t4BAD210F4B2115EE3C212AF622ECE6B81679FA26, ____message_2)); }
	inline String_t* get__message_2() const { return ____message_2; }
	inline String_t** get_address_of__message_2() { return &____message_2; }
	inline void set__message_2(String_t* value)
	{
		____message_2 = value;
		Il2CppCodeGenWriteBarrier((&____message_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ERROREVENTARGS_T4BAD210F4B2115EE3C212AF622ECE6B81679FA26_H
#ifndef U3CPRIVATEIMPLEMENTATIONDETAILSU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_T0EF491E7C6CA3D3B0D052D94577A25F2983BB080_H
#define U3CPRIVATEIMPLEMENTATIONDETAILSU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_T0EF491E7C6CA3D3B0D052D94577A25F2983BB080_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>U7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D
struct  U3CPrivateImplementationDetailsU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_t0EF491E7C6CA3D3B0D052D94577A25F2983BB080  : public RuntimeObject
{
public:

public:
};

struct U3CPrivateImplementationDetailsU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_t0EF491E7C6CA3D3B0D052D94577A25F2983BB080_StaticFields
{
public:
	// <PrivateImplementationDetails>U7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D___StaticArrayInitTypeSizeU3D128 <PrivateImplementationDetails>U7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D::U24U24method0x6000054U2D1
	__StaticArrayInitTypeSizeU3D128_tA1E351C123D4FE21E27968CB84AB3C9993E5ABDE  ___U24U24method0x6000054U2D1_0;

public:
	inline static int32_t get_offset_of_U24U24method0x6000054U2D1_0() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_t0EF491E7C6CA3D3B0D052D94577A25F2983BB080_StaticFields, ___U24U24method0x6000054U2D1_0)); }
	inline __StaticArrayInitTypeSizeU3D128_tA1E351C123D4FE21E27968CB84AB3C9993E5ABDE  get_U24U24method0x6000054U2D1_0() const { return ___U24U24method0x6000054U2D1_0; }
	inline __StaticArrayInitTypeSizeU3D128_tA1E351C123D4FE21E27968CB84AB3C9993E5ABDE * get_address_of_U24U24method0x6000054U2D1_0() { return &___U24U24method0x6000054U2D1_0; }
	inline void set_U24U24method0x6000054U2D1_0(__StaticArrayInitTypeSizeU3D128_tA1E351C123D4FE21E27968CB84AB3C9993E5ABDE  value)
	{
		___U24U24method0x6000054U2D1_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CPRIVATEIMPLEMENTATIONDETAILSU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_T0EF491E7C6CA3D3B0D052D94577A25F2983BB080_H
#ifndef CALLSTATE_T4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_H
#define CALLSTATE_T4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.AWebRtcCall_CallState
struct  CallState_t4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC 
{
public:
	// System.Int32 Byn.Awrtc.Base.AWebRtcCall_CallState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(CallState_t4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLSTATE_T4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_H
#ifndef WEBRTCNETWORKSERVERSTATE_TE46275F448A11A2F249BB43F91C89A10AEDB8053_H
#define WEBRTCNETWORKSERVERSTATE_TE46275F448A11A2F249BB43F91C89A10AEDB8053_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.AWebRtcNetwork_WebRtcNetworkServerState
struct  WebRtcNetworkServerState_tE46275F448A11A2F249BB43F91C89A10AEDB8053 
{
public:
	// System.Int32 Byn.Awrtc.Base.AWebRtcNetwork_WebRtcNetworkServerState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(WebRtcNetworkServerState_tE46275F448A11A2F249BB43F91C89A10AEDB8053, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WEBRTCNETWORKSERVERSTATE_TE46275F448A11A2F249BB43F91C89A10AEDB8053_H
#ifndef PEERCONNECTIONSTATE_TCE73F728B7B0EF108AD4E81A34882E4FD8B8AA4D_H
#define PEERCONNECTIONSTATE_TCE73F728B7B0EF108AD4E81A34882E4FD8B8AA4D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.PeerConnectionState
struct  PeerConnectionState_tCE73F728B7B0EF108AD4E81A34882E4FD8B8AA4D 
{
public:
	// System.Int32 Byn.Awrtc.Base.PeerConnectionState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(PeerConnectionState_tCE73F728B7B0EF108AD4E81A34882E4FD8B8AA4D, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PEERCONNECTIONSTATE_TCE73F728B7B0EF108AD4E81A34882E4FD8B8AA4D_H
#ifndef PEERSIGNALINGSTATE_TAF6FA770361CD53D090BDB684198425CF0C0C268_H
#define PEERSIGNALINGSTATE_TAF6FA770361CD53D090BDB684198425CF0C0C268_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.PeerSignalingState
struct  PeerSignalingState_tAF6FA770361CD53D090BDB684198425CF0C0C268 
{
public:
	// System.Int32 Byn.Awrtc.Base.PeerSignalingState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(PeerSignalingState_tAF6FA770361CD53D090BDB684198425CF0C0C268, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PEERSIGNALINGSTATE_TAF6FA770361CD53D090BDB684198425CF0C0C268_H
#ifndef SIGNALINGINFO_T62D1320AC25FE0DB1A8F1DDEA007028162531DB1_H
#define SIGNALINGINFO_T62D1320AC25FE0DB1A8F1DDEA007028162531DB1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.SignalingInfo
struct  SignalingInfo_t62D1320AC25FE0DB1A8F1DDEA007028162531DB1  : public RuntimeObject
{
public:
	// System.Boolean Byn.Awrtc.Base.SignalingInfo::mSignalingConnected
	bool ___mSignalingConnected_0;
	// Byn.Awrtc.ConnectionId Byn.Awrtc.Base.SignalingInfo::mConnectionId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mConnectionId_1;
	// System.Boolean Byn.Awrtc.Base.SignalingInfo::mIsIncoming
	bool ___mIsIncoming_2;
	// System.DateTime Byn.Awrtc.Base.SignalingInfo::mSignalingStartTime
	DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  ___mSignalingStartTime_3;

public:
	inline static int32_t get_offset_of_mSignalingConnected_0() { return static_cast<int32_t>(offsetof(SignalingInfo_t62D1320AC25FE0DB1A8F1DDEA007028162531DB1, ___mSignalingConnected_0)); }
	inline bool get_mSignalingConnected_0() const { return ___mSignalingConnected_0; }
	inline bool* get_address_of_mSignalingConnected_0() { return &___mSignalingConnected_0; }
	inline void set_mSignalingConnected_0(bool value)
	{
		___mSignalingConnected_0 = value;
	}

	inline static int32_t get_offset_of_mConnectionId_1() { return static_cast<int32_t>(offsetof(SignalingInfo_t62D1320AC25FE0DB1A8F1DDEA007028162531DB1, ___mConnectionId_1)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mConnectionId_1() const { return ___mConnectionId_1; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mConnectionId_1() { return &___mConnectionId_1; }
	inline void set_mConnectionId_1(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mConnectionId_1 = value;
	}

	inline static int32_t get_offset_of_mIsIncoming_2() { return static_cast<int32_t>(offsetof(SignalingInfo_t62D1320AC25FE0DB1A8F1DDEA007028162531DB1, ___mIsIncoming_2)); }
	inline bool get_mIsIncoming_2() const { return ___mIsIncoming_2; }
	inline bool* get_address_of_mIsIncoming_2() { return &___mIsIncoming_2; }
	inline void set_mIsIncoming_2(bool value)
	{
		___mIsIncoming_2 = value;
	}

	inline static int32_t get_offset_of_mSignalingStartTime_3() { return static_cast<int32_t>(offsetof(SignalingInfo_t62D1320AC25FE0DB1A8F1DDEA007028162531DB1, ___mSignalingStartTime_3)); }
	inline DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  get_mSignalingStartTime_3() const { return ___mSignalingStartTime_3; }
	inline DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132 * get_address_of_mSignalingStartTime_3() { return &___mSignalingStartTime_3; }
	inline void set_mSignalingStartTime_3(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  value)
	{
		___mSignalingStartTime_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SIGNALINGINFO_T62D1320AC25FE0DB1A8F1DDEA007028162531DB1_H
#ifndef WEBSOCKETCONNECTIONSTATUS_T05C18D61394CDA14C094F6DA8DFFD8086CB44B58_H
#define WEBSOCKETCONNECTIONSTATUS_T05C18D61394CDA14C094F6DA8DFFD8086CB44B58_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.WebsocketConnectionStatus
struct  WebsocketConnectionStatus_t05C18D61394CDA14C094F6DA8DFFD8086CB44B58 
{
public:
	// System.Int32 Byn.Awrtc.Base.WebsocketConnectionStatus::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(WebsocketConnectionStatus_t05C18D61394CDA14C094F6DA8DFFD8086CB44B58, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WEBSOCKETCONNECTIONSTATUS_T05C18D61394CDA14C094F6DA8DFFD8086CB44B58_H
#ifndef WEBSOCKETREADYSTATE_T62CE7FF86F3B4F3ACB58822938BE9D5680DF986A_H
#define WEBSOCKETREADYSTATE_T62CE7FF86F3B4F3ACB58822938BE9D5680DF986A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.WebsocketReadyState
struct  WebsocketReadyState_t62CE7FF86F3B4F3ACB58822938BE9D5680DF986A 
{
public:
	// System.Int32 Byn.Awrtc.Base.WebsocketReadyState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(WebsocketReadyState_t62CE7FF86F3B4F3ACB58822938BE9D5680DF986A, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WEBSOCKETREADYSTATE_T62CE7FF86F3B4F3ACB58822938BE9D5680DF986A_H
#ifndef WEBSOCKETSERVERSTATUS_T299849ECEF221B16D04813471B5EEC427ED43C00_H
#define WEBSOCKETSERVERSTATUS_T299849ECEF221B16D04813471B5EEC427ED43C00_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.WebsocketServerStatus
struct  WebsocketServerStatus_t299849ECEF221B16D04813471B5EEC427ED43C00 
{
public:
	// System.Int32 Byn.Awrtc.Base.WebsocketServerStatus::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(WebsocketServerStatus_t299849ECEF221B16D04813471B5EEC427ED43C00, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WEBSOCKETSERVERSTATUS_T299849ECEF221B16D04813471B5EEC427ED43C00_H
#ifndef FRAMEPIXELFORMAT_TDCE4288D3AD386370E428FCC0668229B6994D9BB_H
#define FRAMEPIXELFORMAT_TDCE4288D3AD386370E428FCC0668229B6994D9BB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.FramePixelFormat
struct  FramePixelFormat_tDCE4288D3AD386370E428FCC0668229B6994D9BB 
{
public:
	// System.Int32 Byn.Awrtc.FramePixelFormat::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(FramePixelFormat_tDCE4288D3AD386370E428FCC0668229B6994D9BB, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FRAMEPIXELFORMAT_TDCE4288D3AD386370E428FCC0668229B6994D9BB_H
#ifndef MEDIACONFIGURATIONSTATE_TD278B71006BEF0BB2F003EB306E41EB133453629_H
#define MEDIACONFIGURATIONSTATE_TD278B71006BEF0BB2F003EB306E41EB133453629_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.MediaConfigurationState
struct  MediaConfigurationState_tD278B71006BEF0BB2F003EB306E41EB133453629 
{
public:
	// System.Byte Byn.Awrtc.MediaConfigurationState::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(MediaConfigurationState_tD278B71006BEF0BB2F003EB306E41EB133453629, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MEDIACONFIGURATIONSTATE_TD278B71006BEF0BB2F003EB306E41EB133453629_H
#ifndef NATIVEAUDIOOPTIONS_T726C7EAE8C560178FF83C793652033436FC75456_H
#define NATIVEAUDIOOPTIONS_T726C7EAE8C560178FF83C793652033436FC75456_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Native.NativeAudioOptions
struct  NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456  : public RuntimeObject
{
public:
	// System.Boolean Byn.Awrtc.Native.NativeAudioOptions::rawAudioAccess
	bool ___rawAudioAccess_0;
	// System.Nullable`1<System.Boolean> Byn.Awrtc.Native.NativeAudioOptions::<echo_cancellation>k__BackingField
	Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  ___U3Cecho_cancellationU3Ek__BackingField_1;
	// System.Nullable`1<System.Boolean> Byn.Awrtc.Native.NativeAudioOptions::<extended_filter_aec>k__BackingField
	Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  ___U3Cextended_filter_aecU3Ek__BackingField_2;
	// System.Nullable`1<System.Boolean> Byn.Awrtc.Native.NativeAudioOptions::<delay_agnostic_aec>k__BackingField
	Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  ___U3Cdelay_agnostic_aecU3Ek__BackingField_3;
	// System.Nullable`1<System.Boolean> Byn.Awrtc.Native.NativeAudioOptions::<noise_suppression>k__BackingField
	Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  ___U3Cnoise_suppressionU3Ek__BackingField_4;
	// System.Nullable`1<System.Boolean> Byn.Awrtc.Native.NativeAudioOptions::<auto_gain_control>k__BackingField
	Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  ___U3Cauto_gain_controlU3Ek__BackingField_5;

public:
	inline static int32_t get_offset_of_rawAudioAccess_0() { return static_cast<int32_t>(offsetof(NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456, ___rawAudioAccess_0)); }
	inline bool get_rawAudioAccess_0() const { return ___rawAudioAccess_0; }
	inline bool* get_address_of_rawAudioAccess_0() { return &___rawAudioAccess_0; }
	inline void set_rawAudioAccess_0(bool value)
	{
		___rawAudioAccess_0 = value;
	}

	inline static int32_t get_offset_of_U3Cecho_cancellationU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456, ___U3Cecho_cancellationU3Ek__BackingField_1)); }
	inline Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  get_U3Cecho_cancellationU3Ek__BackingField_1() const { return ___U3Cecho_cancellationU3Ek__BackingField_1; }
	inline Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793 * get_address_of_U3Cecho_cancellationU3Ek__BackingField_1() { return &___U3Cecho_cancellationU3Ek__BackingField_1; }
	inline void set_U3Cecho_cancellationU3Ek__BackingField_1(Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  value)
	{
		___U3Cecho_cancellationU3Ek__BackingField_1 = value;
	}

	inline static int32_t get_offset_of_U3Cextended_filter_aecU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456, ___U3Cextended_filter_aecU3Ek__BackingField_2)); }
	inline Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  get_U3Cextended_filter_aecU3Ek__BackingField_2() const { return ___U3Cextended_filter_aecU3Ek__BackingField_2; }
	inline Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793 * get_address_of_U3Cextended_filter_aecU3Ek__BackingField_2() { return &___U3Cextended_filter_aecU3Ek__BackingField_2; }
	inline void set_U3Cextended_filter_aecU3Ek__BackingField_2(Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  value)
	{
		___U3Cextended_filter_aecU3Ek__BackingField_2 = value;
	}

	inline static int32_t get_offset_of_U3Cdelay_agnostic_aecU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456, ___U3Cdelay_agnostic_aecU3Ek__BackingField_3)); }
	inline Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  get_U3Cdelay_agnostic_aecU3Ek__BackingField_3() const { return ___U3Cdelay_agnostic_aecU3Ek__BackingField_3; }
	inline Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793 * get_address_of_U3Cdelay_agnostic_aecU3Ek__BackingField_3() { return &___U3Cdelay_agnostic_aecU3Ek__BackingField_3; }
	inline void set_U3Cdelay_agnostic_aecU3Ek__BackingField_3(Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  value)
	{
		___U3Cdelay_agnostic_aecU3Ek__BackingField_3 = value;
	}

	inline static int32_t get_offset_of_U3Cnoise_suppressionU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456, ___U3Cnoise_suppressionU3Ek__BackingField_4)); }
	inline Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  get_U3Cnoise_suppressionU3Ek__BackingField_4() const { return ___U3Cnoise_suppressionU3Ek__BackingField_4; }
	inline Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793 * get_address_of_U3Cnoise_suppressionU3Ek__BackingField_4() { return &___U3Cnoise_suppressionU3Ek__BackingField_4; }
	inline void set_U3Cnoise_suppressionU3Ek__BackingField_4(Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  value)
	{
		___U3Cnoise_suppressionU3Ek__BackingField_4 = value;
	}

	inline static int32_t get_offset_of_U3Cauto_gain_controlU3Ek__BackingField_5() { return static_cast<int32_t>(offsetof(NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456, ___U3Cauto_gain_controlU3Ek__BackingField_5)); }
	inline Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  get_U3Cauto_gain_controlU3Ek__BackingField_5() const { return ___U3Cauto_gain_controlU3Ek__BackingField_5; }
	inline Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793 * get_address_of_U3Cauto_gain_controlU3Ek__BackingField_5() { return &___U3Cauto_gain_controlU3Ek__BackingField_5; }
	inline void set_U3Cauto_gain_controlU3Ek__BackingField_5(Nullable_1_t9E6A67BECE376F0623B5C857F5674A0311C41793  value)
	{
		___U3Cauto_gain_controlU3Ek__BackingField_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NATIVEAUDIOOPTIONS_T726C7EAE8C560178FF83C793652033436FC75456_H
#ifndef OBJINITSTATE_T56C7A4A78939C731F3817071BB80EF546E79EF67_H
#define OBJINITSTATE_T56C7A4A78939C731F3817071BB80EF546E79EF67_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Native.NativeAwrtcFactory_ObjInitState
struct  ObjInitState_t56C7A4A78939C731F3817071BB80EF546E79EF67 
{
public:
	// System.Int32 Byn.Awrtc.Native.NativeAwrtcFactory_ObjInitState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ObjInitState_t56C7A4A78939C731F3817071BB80EF546E79EF67, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OBJINITSTATE_T56C7A4A78939C731F3817071BB80EF546E79EF67_H
#ifndef STATICINITSTATE_T5577CE5712FF8171B0A94566C59DE07F7E4CA68A_H
#define STATICINITSTATE_T5577CE5712FF8171B0A94566C59DE07F7E4CA68A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Native.NativeAwrtcFactory_StaticInitState
struct  StaticInitState_t5577CE5712FF8171B0A94566C59DE07F7E4CA68A 
{
public:
	// System.Int32 Byn.Awrtc.Native.NativeAwrtcFactory_StaticInitState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(StaticInitState_t5577CE5712FF8171B0A94566C59DE07F7E4CA68A, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STATICINITSTATE_T5577CE5712FF8171B0A94566C59DE07F7E4CA68A_H
#ifndef DELEGATE_T_H
#define DELEGATE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Delegate
struct  Delegate_t  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::extra_arg
	intptr_t ___extra_arg_5;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_6;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_7;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_8;
	// System.DelegateData System.Delegate::data
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	// System.Boolean System.Delegate::method_is_virtual
	bool ___method_is_virtual_10;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t, ___invoke_impl_1)); }
	inline intptr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline intptr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(intptr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_target_2), value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_3)); }
	inline intptr_t get_method_3() const { return ___method_3; }
	inline intptr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(intptr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t, ___delegate_trampoline_4)); }
	inline intptr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline intptr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(intptr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_extra_arg_5() { return static_cast<int32_t>(offsetof(Delegate_t, ___extra_arg_5)); }
	inline intptr_t get_extra_arg_5() const { return ___extra_arg_5; }
	inline intptr_t* get_address_of_extra_arg_5() { return &___extra_arg_5; }
	inline void set_extra_arg_5(intptr_t value)
	{
		___extra_arg_5 = value;
	}

	inline static int32_t get_offset_of_method_code_6() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_code_6)); }
	inline intptr_t get_method_code_6() const { return ___method_code_6; }
	inline intptr_t* get_address_of_method_code_6() { return &___method_code_6; }
	inline void set_method_code_6(intptr_t value)
	{
		___method_code_6 = value;
	}

	inline static int32_t get_offset_of_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_info_7)); }
	inline MethodInfo_t * get_method_info_7() const { return ___method_info_7; }
	inline MethodInfo_t ** get_address_of_method_info_7() { return &___method_info_7; }
	inline void set_method_info_7(MethodInfo_t * value)
	{
		___method_info_7 = value;
		Il2CppCodeGenWriteBarrier((&___method_info_7), value);
	}

	inline static int32_t get_offset_of_original_method_info_8() { return static_cast<int32_t>(offsetof(Delegate_t, ___original_method_info_8)); }
	inline MethodInfo_t * get_original_method_info_8() const { return ___original_method_info_8; }
	inline MethodInfo_t ** get_address_of_original_method_info_8() { return &___original_method_info_8; }
	inline void set_original_method_info_8(MethodInfo_t * value)
	{
		___original_method_info_8 = value;
		Il2CppCodeGenWriteBarrier((&___original_method_info_8), value);
	}

	inline static int32_t get_offset_of_data_9() { return static_cast<int32_t>(offsetof(Delegate_t, ___data_9)); }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * get_data_9() const { return ___data_9; }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE ** get_address_of_data_9() { return &___data_9; }
	inline void set_data_9(DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * value)
	{
		___data_9 = value;
		Il2CppCodeGenWriteBarrier((&___data_9), value);
	}

	inline static int32_t get_offset_of_method_is_virtual_10() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_is_virtual_10)); }
	inline bool get_method_is_virtual_10() const { return ___method_is_virtual_10; }
	inline bool* get_address_of_method_is_virtual_10() { return &___method_is_virtual_10; }
	inline void set_method_is_virtual_10(bool value)
	{
		___method_is_virtual_10 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Delegate
struct Delegate_t_marshaled_pinvoke
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};
// Native definition for COM marshalling of System.Delegate
struct Delegate_t_marshaled_com
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};
#endif // DELEGATE_T_H
#ifndef HANDLEREF_T876E76124F400D12395BF61D562162AB6822204A_H
#define HANDLEREF_T876E76124F400D12395BF61D562162AB6822204A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Runtime.InteropServices.HandleRef
struct  HandleRef_t876E76124F400D12395BF61D562162AB6822204A 
{
public:
	// System.Object System.Runtime.InteropServices.HandleRef::m_wrapper
	RuntimeObject * ___m_wrapper_0;
	// System.IntPtr System.Runtime.InteropServices.HandleRef::m_handle
	intptr_t ___m_handle_1;

public:
	inline static int32_t get_offset_of_m_wrapper_0() { return static_cast<int32_t>(offsetof(HandleRef_t876E76124F400D12395BF61D562162AB6822204A, ___m_wrapper_0)); }
	inline RuntimeObject * get_m_wrapper_0() const { return ___m_wrapper_0; }
	inline RuntimeObject ** get_address_of_m_wrapper_0() { return &___m_wrapper_0; }
	inline void set_m_wrapper_0(RuntimeObject * value)
	{
		___m_wrapper_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_wrapper_0), value);
	}

	inline static int32_t get_offset_of_m_handle_1() { return static_cast<int32_t>(offsetof(HandleRef_t876E76124F400D12395BF61D562162AB6822204A, ___m_handle_1)); }
	inline intptr_t get_m_handle_1() const { return ___m_handle_1; }
	inline intptr_t* get_address_of_m_handle_1() { return &___m_handle_1; }
	inline void set_m_handle_1(intptr_t value)
	{
		___m_handle_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HANDLEREF_T876E76124F400D12395BF61D562162AB6822204A_H
#ifndef LOGGINGSEVERITY_T963167393F6858EBBE523CFF6683524F6297BB94_H
#define LOGGINGSEVERITY_T963167393F6858EBBE523CFF6683524F6297BB94_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.LoggingSeverity
struct  LoggingSeverity_t963167393F6858EBBE523CFF6683524F6297BB94 
{
public:
	// System.Int32 WebRtcCSharp.LoggingSeverity::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(LoggingSeverity_t963167393F6858EBBE523CFF6683524F6297BB94, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOGGINGSEVERITY_T963167393F6858EBBE523CFF6683524F6297BB94_H
#ifndef CONNECTIONSTATE_T410124846AFCB648B6240C2D9FAC21A1FC663FFF_H
#define CONNECTIONSTATE_T410124846AFCB648B6240C2D9FAC21A1FC663FFF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.PollingPeer_ConnectionState
struct  ConnectionState_t410124846AFCB648B6240C2D9FAC21A1FC663FFF 
{
public:
	// System.Int32 WebRtcCSharp.PollingPeer_ConnectionState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ConnectionState_t410124846AFCB648B6240C2D9FAC21A1FC663FFF, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONNECTIONSTATE_T410124846AFCB648B6240C2D9FAC21A1FC663FFF_H
#ifndef SDPSEMANTICS_TA4B48D14B9F86E2DCA08A853836BA4CF17A8B2D7_H
#define SDPSEMANTICS_TA4B48D14B9F86E2DCA08A853836BA4CF17A8B2D7_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.SdpSemantics
struct  SdpSemantics_tA4B48D14B9F86E2DCA08A853836BA4CF17A8B2D7 
{
public:
	// System.Int32 WebRtcCSharp.SdpSemantics::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(SdpSemantics_tA4B48D14B9F86E2DCA08A853836BA4CF17A8B2D7, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SDPSEMANTICS_TA4B48D14B9F86E2DCA08A853836BA4CF17A8B2D7_H
#ifndef VIDEOTYPE_T5267934728C2CAFE0C4C0C6C8CBDFD20C268B9CE_H
#define VIDEOTYPE_T5267934728C2CAFE0C4C0C6C8CBDFD20C268B9CE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.VideoType
struct  VideoType_t5267934728C2CAFE0C4C0C6C8CBDFD20C268B9CE 
{
public:
	// System.Int32 WebRtcCSharp.VideoType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(VideoType_t5267934728C2CAFE0C4C0C6C8CBDFD20C268B9CE, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEOTYPE_T5267934728C2CAFE0C4C0C6C8CBDFD20C268B9CE_H
#ifndef BYTEORDER_TAB45B8AEC08BC2569F11B6AA5586AF15CF990241_H
#define BYTEORDER_TAB45B8AEC08BC2569F11B6AA5586AF15CF990241_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebSocketSharpUnityMod.ByteOrder
struct  ByteOrder_tAB45B8AEC08BC2569F11B6AA5586AF15CF990241 
{
public:
	// System.Int32 WebSocketSharpUnityMod.ByteOrder::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ByteOrder_tAB45B8AEC08BC2569F11B6AA5586AF15CF990241, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BYTEORDER_TAB45B8AEC08BC2569F11B6AA5586AF15CF990241_H
#ifndef CLOSESTATUSCODE_T5E07B813259D8C02E749C3E3E498AA8BD2BE0B22_H
#define CLOSESTATUSCODE_T5E07B813259D8C02E749C3E3E498AA8BD2BE0B22_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebSocketSharpUnityMod.CloseStatusCode
struct  CloseStatusCode_t5E07B813259D8C02E749C3E3E498AA8BD2BE0B22 
{
public:
	// System.UInt16 WebSocketSharpUnityMod.CloseStatusCode::value__
	uint16_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(CloseStatusCode_t5E07B813259D8C02E749C3E3E498AA8BD2BE0B22, ___value___2)); }
	inline uint16_t get_value___2() const { return ___value___2; }
	inline uint16_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint16_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CLOSESTATUSCODE_T5E07B813259D8C02E749C3E3E498AA8BD2BE0B22_H
#ifndef COMPRESSIONMETHOD_T813F9401D7C9910DA414FDE6F6329CB5E931DD20_H
#define COMPRESSIONMETHOD_T813F9401D7C9910DA414FDE6F6329CB5E931DD20_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebSocketSharpUnityMod.CompressionMethod
struct  CompressionMethod_t813F9401D7C9910DA414FDE6F6329CB5E931DD20 
{
public:
	// System.Byte WebSocketSharpUnityMod.CompressionMethod::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(CompressionMethod_t813F9401D7C9910DA414FDE6F6329CB5E931DD20, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPRESSIONMETHOD_T813F9401D7C9910DA414FDE6F6329CB5E931DD20_H
#ifndef FIN_T57E86F17A46BB574BA272A65852BAA5374A62F44_H
#define FIN_T57E86F17A46BB574BA272A65852BAA5374A62F44_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebSocketSharpUnityMod.Fin
struct  Fin_t57E86F17A46BB574BA272A65852BAA5374A62F44 
{
public:
	// System.Byte WebSocketSharpUnityMod.Fin::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Fin_t57E86F17A46BB574BA272A65852BAA5374A62F44, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FIN_T57E86F17A46BB574BA272A65852BAA5374A62F44_H
#ifndef AWEBRTCCALL_T8643A5C98F146CCA1CACDB911820319270507AD3_H
#define AWEBRTCCALL_T8643A5C98F146CCA1CACDB911820319270507AD3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.AWebRtcCall
struct  AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3  : public RuntimeObject
{
public:
	// Byn.Awrtc.NetworkConfig Byn.Awrtc.Base.AWebRtcCall::mNetworkConfig
	NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * ___mNetworkConfig_1;
	// Byn.Awrtc.MediaConfig Byn.Awrtc.Base.AWebRtcCall::mMediaConfig
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___mMediaConfig_2;
	// Byn.Awrtc.CallEventHandler Byn.Awrtc.Base.AWebRtcCall::CallEvent
	CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * ___CallEvent_3;
	// Byn.Awrtc.IMediaNetwork Byn.Awrtc.Base.AWebRtcCall::mNetwork
	RuntimeObject* ___mNetwork_4;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mConferenceMode
	bool ___mConferenceMode_5;
	// Byn.Awrtc.Base.AWebRtcCall_CallState Byn.Awrtc.Base.AWebRtcCall::mState
	int32_t ___mState_8;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mIsDisposed
	bool ___mIsDisposed_9;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mLocalFrameEvents
	bool ___mLocalFrameEvents_10;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mServerInactive
	bool ___mServerInactive_11;
	// System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId> Byn.Awrtc.Base.AWebRtcCall::mConnectionIds
	List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * ___mConnectionIds_12;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mPendingListenCall
	bool ___mPendingListenCall_13;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mPendingCallCall
	bool ___mPendingCallCall_14;
	// System.String Byn.Awrtc.Base.AWebRtcCall::mPendingAddress
	String_t* ___mPendingAddress_15;

public:
	inline static int32_t get_offset_of_mNetworkConfig_1() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mNetworkConfig_1)); }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * get_mNetworkConfig_1() const { return ___mNetworkConfig_1; }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 ** get_address_of_mNetworkConfig_1() { return &___mNetworkConfig_1; }
	inline void set_mNetworkConfig_1(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * value)
	{
		___mNetworkConfig_1 = value;
		Il2CppCodeGenWriteBarrier((&___mNetworkConfig_1), value);
	}

	inline static int32_t get_offset_of_mMediaConfig_2() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mMediaConfig_2)); }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * get_mMediaConfig_2() const { return ___mMediaConfig_2; }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D ** get_address_of_mMediaConfig_2() { return &___mMediaConfig_2; }
	inline void set_mMediaConfig_2(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * value)
	{
		___mMediaConfig_2 = value;
		Il2CppCodeGenWriteBarrier((&___mMediaConfig_2), value);
	}

	inline static int32_t get_offset_of_CallEvent_3() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___CallEvent_3)); }
	inline CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * get_CallEvent_3() const { return ___CallEvent_3; }
	inline CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F ** get_address_of_CallEvent_3() { return &___CallEvent_3; }
	inline void set_CallEvent_3(CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * value)
	{
		___CallEvent_3 = value;
		Il2CppCodeGenWriteBarrier((&___CallEvent_3), value);
	}

	inline static int32_t get_offset_of_mNetwork_4() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mNetwork_4)); }
	inline RuntimeObject* get_mNetwork_4() const { return ___mNetwork_4; }
	inline RuntimeObject** get_address_of_mNetwork_4() { return &___mNetwork_4; }
	inline void set_mNetwork_4(RuntimeObject* value)
	{
		___mNetwork_4 = value;
		Il2CppCodeGenWriteBarrier((&___mNetwork_4), value);
	}

	inline static int32_t get_offset_of_mConferenceMode_5() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mConferenceMode_5)); }
	inline bool get_mConferenceMode_5() const { return ___mConferenceMode_5; }
	inline bool* get_address_of_mConferenceMode_5() { return &___mConferenceMode_5; }
	inline void set_mConferenceMode_5(bool value)
	{
		___mConferenceMode_5 = value;
	}

	inline static int32_t get_offset_of_mState_8() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mState_8)); }
	inline int32_t get_mState_8() const { return ___mState_8; }
	inline int32_t* get_address_of_mState_8() { return &___mState_8; }
	inline void set_mState_8(int32_t value)
	{
		___mState_8 = value;
	}

	inline static int32_t get_offset_of_mIsDisposed_9() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mIsDisposed_9)); }
	inline bool get_mIsDisposed_9() const { return ___mIsDisposed_9; }
	inline bool* get_address_of_mIsDisposed_9() { return &___mIsDisposed_9; }
	inline void set_mIsDisposed_9(bool value)
	{
		___mIsDisposed_9 = value;
	}

	inline static int32_t get_offset_of_mLocalFrameEvents_10() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mLocalFrameEvents_10)); }
	inline bool get_mLocalFrameEvents_10() const { return ___mLocalFrameEvents_10; }
	inline bool* get_address_of_mLocalFrameEvents_10() { return &___mLocalFrameEvents_10; }
	inline void set_mLocalFrameEvents_10(bool value)
	{
		___mLocalFrameEvents_10 = value;
	}

	inline static int32_t get_offset_of_mServerInactive_11() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mServerInactive_11)); }
	inline bool get_mServerInactive_11() const { return ___mServerInactive_11; }
	inline bool* get_address_of_mServerInactive_11() { return &___mServerInactive_11; }
	inline void set_mServerInactive_11(bool value)
	{
		___mServerInactive_11 = value;
	}

	inline static int32_t get_offset_of_mConnectionIds_12() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mConnectionIds_12)); }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * get_mConnectionIds_12() const { return ___mConnectionIds_12; }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 ** get_address_of_mConnectionIds_12() { return &___mConnectionIds_12; }
	inline void set_mConnectionIds_12(List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * value)
	{
		___mConnectionIds_12 = value;
		Il2CppCodeGenWriteBarrier((&___mConnectionIds_12), value);
	}

	inline static int32_t get_offset_of_mPendingListenCall_13() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mPendingListenCall_13)); }
	inline bool get_mPendingListenCall_13() const { return ___mPendingListenCall_13; }
	inline bool* get_address_of_mPendingListenCall_13() { return &___mPendingListenCall_13; }
	inline void set_mPendingListenCall_13(bool value)
	{
		___mPendingListenCall_13 = value;
	}

	inline static int32_t get_offset_of_mPendingCallCall_14() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mPendingCallCall_14)); }
	inline bool get_mPendingCallCall_14() const { return ___mPendingCallCall_14; }
	inline bool* get_address_of_mPendingCallCall_14() { return &___mPendingCallCall_14; }
	inline void set_mPendingCallCall_14(bool value)
	{
		___mPendingCallCall_14 = value;
	}

	inline static int32_t get_offset_of_mPendingAddress_15() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mPendingAddress_15)); }
	inline String_t* get_mPendingAddress_15() const { return ___mPendingAddress_15; }
	inline String_t** get_address_of_mPendingAddress_15() { return &___mPendingAddress_15; }
	inline void set_mPendingAddress_15(String_t* value)
	{
		___mPendingAddress_15 = value;
		Il2CppCodeGenWriteBarrier((&___mPendingAddress_15), value);
	}
};

struct AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields
{
public:
	// System.String Byn.Awrtc.Base.AWebRtcCall::LOGTAG
	String_t* ___LOGTAG_0;
	// System.Byte Byn.Awrtc.Base.AWebRtcCall::MESSAGE_TYPE_DATA
	uint8_t ___MESSAGE_TYPE_DATA_6;
	// System.Byte Byn.Awrtc.Base.AWebRtcCall::MESSAGE_TYPE_STRING
	uint8_t ___MESSAGE_TYPE_STRING_7;

public:
	inline static int32_t get_offset_of_LOGTAG_0() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields, ___LOGTAG_0)); }
	inline String_t* get_LOGTAG_0() const { return ___LOGTAG_0; }
	inline String_t** get_address_of_LOGTAG_0() { return &___LOGTAG_0; }
	inline void set_LOGTAG_0(String_t* value)
	{
		___LOGTAG_0 = value;
		Il2CppCodeGenWriteBarrier((&___LOGTAG_0), value);
	}

	inline static int32_t get_offset_of_MESSAGE_TYPE_DATA_6() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields, ___MESSAGE_TYPE_DATA_6)); }
	inline uint8_t get_MESSAGE_TYPE_DATA_6() const { return ___MESSAGE_TYPE_DATA_6; }
	inline uint8_t* get_address_of_MESSAGE_TYPE_DATA_6() { return &___MESSAGE_TYPE_DATA_6; }
	inline void set_MESSAGE_TYPE_DATA_6(uint8_t value)
	{
		___MESSAGE_TYPE_DATA_6 = value;
	}

	inline static int32_t get_offset_of_MESSAGE_TYPE_STRING_7() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields, ___MESSAGE_TYPE_STRING_7)); }
	inline uint8_t get_MESSAGE_TYPE_STRING_7() const { return ___MESSAGE_TYPE_STRING_7; }
	inline uint8_t* get_address_of_MESSAGE_TYPE_STRING_7() { return &___MESSAGE_TYPE_STRING_7; }
	inline void set_MESSAGE_TYPE_STRING_7(uint8_t value)
	{
		___MESSAGE_TYPE_STRING_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AWEBRTCCALL_T8643A5C98F146CCA1CACDB911820319270507AD3_H
#ifndef AWEBRTCNETWORK_T03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F_H
#define AWEBRTCNETWORK_T03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.AWebRtcNetwork
struct  AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F  : public RuntimeObject
{
public:
	// System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.Base.IDataPeer> Byn.Awrtc.Base.AWebRtcNetwork::mInSignaling
	Dictionary_2_tDE069D3BDE2BBD3406F01575E28822C09A2F5591 * ___mInSignaling_0;
	// Byn.Awrtc.ConnectionId Byn.Awrtc.Base.AWebRtcNetwork::mNextId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mNextId_1;
	// Byn.Awrtc.Base.SignalingConfig Byn.Awrtc.Base.AWebRtcNetwork::mConfig
	SignalingConfig_tAE908484943C078C7439EB1A31243A983F6904EB * ___mConfig_2;
	// System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent> Byn.Awrtc.Base.AWebRtcNetwork::mEvents
	Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * ___mEvents_3;
	// System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.Base.IDataPeer> Byn.Awrtc.Base.AWebRtcNetwork::mIdToConnection
	Dictionary_2_tDE069D3BDE2BBD3406F01575E28822C09A2F5591 * ___mIdToConnection_4;
	// System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId> Byn.Awrtc.Base.AWebRtcNetwork::mConnectionIds
	List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * ___mConnectionIds_5;
	// Byn.Awrtc.Base.AWebRtcNetwork_WebRtcNetworkServerState Byn.Awrtc.Base.AWebRtcNetwork::mServerState
	int32_t ___mServerState_6;
	// Byn.Awrtc.IceServer[] Byn.Awrtc.Base.AWebRtcNetwork::mIceServers
	IceServerU5BU5D_t77B1ADF58E5BEF879817A80953BA71C121730B4A* ___mIceServers_7;
	// System.Boolean Byn.Awrtc.Base.AWebRtcNetwork::mIsDisposed
	bool ___mIsDisposed_9;

public:
	inline static int32_t get_offset_of_mInSignaling_0() { return static_cast<int32_t>(offsetof(AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F, ___mInSignaling_0)); }
	inline Dictionary_2_tDE069D3BDE2BBD3406F01575E28822C09A2F5591 * get_mInSignaling_0() const { return ___mInSignaling_0; }
	inline Dictionary_2_tDE069D3BDE2BBD3406F01575E28822C09A2F5591 ** get_address_of_mInSignaling_0() { return &___mInSignaling_0; }
	inline void set_mInSignaling_0(Dictionary_2_tDE069D3BDE2BBD3406F01575E28822C09A2F5591 * value)
	{
		___mInSignaling_0 = value;
		Il2CppCodeGenWriteBarrier((&___mInSignaling_0), value);
	}

	inline static int32_t get_offset_of_mNextId_1() { return static_cast<int32_t>(offsetof(AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F, ___mNextId_1)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mNextId_1() const { return ___mNextId_1; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mNextId_1() { return &___mNextId_1; }
	inline void set_mNextId_1(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mNextId_1 = value;
	}

	inline static int32_t get_offset_of_mConfig_2() { return static_cast<int32_t>(offsetof(AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F, ___mConfig_2)); }
	inline SignalingConfig_tAE908484943C078C7439EB1A31243A983F6904EB * get_mConfig_2() const { return ___mConfig_2; }
	inline SignalingConfig_tAE908484943C078C7439EB1A31243A983F6904EB ** get_address_of_mConfig_2() { return &___mConfig_2; }
	inline void set_mConfig_2(SignalingConfig_tAE908484943C078C7439EB1A31243A983F6904EB * value)
	{
		___mConfig_2 = value;
		Il2CppCodeGenWriteBarrier((&___mConfig_2), value);
	}

	inline static int32_t get_offset_of_mEvents_3() { return static_cast<int32_t>(offsetof(AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F, ___mEvents_3)); }
	inline Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * get_mEvents_3() const { return ___mEvents_3; }
	inline Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF ** get_address_of_mEvents_3() { return &___mEvents_3; }
	inline void set_mEvents_3(Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * value)
	{
		___mEvents_3 = value;
		Il2CppCodeGenWriteBarrier((&___mEvents_3), value);
	}

	inline static int32_t get_offset_of_mIdToConnection_4() { return static_cast<int32_t>(offsetof(AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F, ___mIdToConnection_4)); }
	inline Dictionary_2_tDE069D3BDE2BBD3406F01575E28822C09A2F5591 * get_mIdToConnection_4() const { return ___mIdToConnection_4; }
	inline Dictionary_2_tDE069D3BDE2BBD3406F01575E28822C09A2F5591 ** get_address_of_mIdToConnection_4() { return &___mIdToConnection_4; }
	inline void set_mIdToConnection_4(Dictionary_2_tDE069D3BDE2BBD3406F01575E28822C09A2F5591 * value)
	{
		___mIdToConnection_4 = value;
		Il2CppCodeGenWriteBarrier((&___mIdToConnection_4), value);
	}

	inline static int32_t get_offset_of_mConnectionIds_5() { return static_cast<int32_t>(offsetof(AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F, ___mConnectionIds_5)); }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * get_mConnectionIds_5() const { return ___mConnectionIds_5; }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 ** get_address_of_mConnectionIds_5() { return &___mConnectionIds_5; }
	inline void set_mConnectionIds_5(List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * value)
	{
		___mConnectionIds_5 = value;
		Il2CppCodeGenWriteBarrier((&___mConnectionIds_5), value);
	}

	inline static int32_t get_offset_of_mServerState_6() { return static_cast<int32_t>(offsetof(AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F, ___mServerState_6)); }
	inline int32_t get_mServerState_6() const { return ___mServerState_6; }
	inline int32_t* get_address_of_mServerState_6() { return &___mServerState_6; }
	inline void set_mServerState_6(int32_t value)
	{
		___mServerState_6 = value;
	}

	inline static int32_t get_offset_of_mIceServers_7() { return static_cast<int32_t>(offsetof(AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F, ___mIceServers_7)); }
	inline IceServerU5BU5D_t77B1ADF58E5BEF879817A80953BA71C121730B4A* get_mIceServers_7() const { return ___mIceServers_7; }
	inline IceServerU5BU5D_t77B1ADF58E5BEF879817A80953BA71C121730B4A** get_address_of_mIceServers_7() { return &___mIceServers_7; }
	inline void set_mIceServers_7(IceServerU5BU5D_t77B1ADF58E5BEF879817A80953BA71C121730B4A* value)
	{
		___mIceServers_7 = value;
		Il2CppCodeGenWriteBarrier((&___mIceServers_7), value);
	}

	inline static int32_t get_offset_of_mIsDisposed_9() { return static_cast<int32_t>(offsetof(AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F, ___mIsDisposed_9)); }
	inline bool get_mIsDisposed_9() const { return ___mIsDisposed_9; }
	inline bool* get_address_of_mIsDisposed_9() { return &___mIsDisposed_9; }
	inline void set_mIsDisposed_9(bool value)
	{
		___mIsDisposed_9 = value;
	}
};

struct AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F_StaticFields
{
public:
	// System.String Byn.Awrtc.Base.AWebRtcNetwork::LOGTAG
	String_t* ___LOGTAG_8;

public:
	inline static int32_t get_offset_of_LOGTAG_8() { return static_cast<int32_t>(offsetof(AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F_StaticFields, ___LOGTAG_8)); }
	inline String_t* get_LOGTAG_8() const { return ___LOGTAG_8; }
	inline String_t** get_address_of_LOGTAG_8() { return &___LOGTAG_8; }
	inline void set_LOGTAG_8(String_t* value)
	{
		___LOGTAG_8 = value;
		Il2CppCodeGenWriteBarrier((&___LOGTAG_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AWEBRTCNETWORK_T03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F_H
#ifndef AWEBRTCPEER_T8E8BD87060FCBDBD878944A96BE224357503BCEE_H
#define AWEBRTCPEER_T8E8BD87060FCBDBD878944A96BE224357503BCEE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.AWebRtcPeer
struct  AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE  : public RuntimeObject
{
public:
	// System.Int32 Byn.Awrtc.Base.AWebRtcPeer::mLocalId
	int32_t ___mLocalId_5;
	// Byn.Awrtc.ConnectionId Byn.Awrtc.Base.AWebRtcPeer::mConnectionId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mConnectionId_6;
	// Byn.Awrtc.Base.SignalingInfo Byn.Awrtc.Base.AWebRtcPeer::mInfo
	SignalingInfo_t62D1320AC25FE0DB1A8F1DDEA007028162531DB1 * ___mInfo_7;
	// Byn.Awrtc.Base.PeerConnectionState Byn.Awrtc.Base.AWebRtcPeer::mConnectionState
	int32_t ___mConnectionState_8;
	// Byn.Awrtc.Base.PeerSignalingState Byn.Awrtc.Base.AWebRtcPeer::mSignalingState
	int32_t ___mSignalingState_9;
	// System.Boolean Byn.Awrtc.Base.AWebRtcPeer::mRenegotiationRequested
	bool ___mRenegotiationRequested_10;
	// System.Collections.Generic.Queue`1<System.String> Byn.Awrtc.Base.AWebRtcPeer::mOutgoingSignalingQueue
	Queue_1_t234B58D376F3C134441C47D5A9EF7789374EE172 * ___mOutgoingSignalingQueue_11;
	// System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent> Byn.Awrtc.Base.AWebRtcPeer::mEvents
	Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * ___mEvents_12;
	// System.Boolean Byn.Awrtc.Base.AWebRtcPeer::mDidSendRandomNumber
	bool ___mDidSendRandomNumber_13;
	// System.Int32 Byn.Awrtc.Base.AWebRtcPeer::mRandomNumberSent
	int32_t ___mRandomNumberSent_14;
	// System.Boolean Byn.Awrtc.Base.AWebRtcPeer::mIsDisposed
	bool ___mIsDisposed_16;

public:
	inline static int32_t get_offset_of_mLocalId_5() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE, ___mLocalId_5)); }
	inline int32_t get_mLocalId_5() const { return ___mLocalId_5; }
	inline int32_t* get_address_of_mLocalId_5() { return &___mLocalId_5; }
	inline void set_mLocalId_5(int32_t value)
	{
		___mLocalId_5 = value;
	}

	inline static int32_t get_offset_of_mConnectionId_6() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE, ___mConnectionId_6)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mConnectionId_6() const { return ___mConnectionId_6; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mConnectionId_6() { return &___mConnectionId_6; }
	inline void set_mConnectionId_6(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mConnectionId_6 = value;
	}

	inline static int32_t get_offset_of_mInfo_7() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE, ___mInfo_7)); }
	inline SignalingInfo_t62D1320AC25FE0DB1A8F1DDEA007028162531DB1 * get_mInfo_7() const { return ___mInfo_7; }
	inline SignalingInfo_t62D1320AC25FE0DB1A8F1DDEA007028162531DB1 ** get_address_of_mInfo_7() { return &___mInfo_7; }
	inline void set_mInfo_7(SignalingInfo_t62D1320AC25FE0DB1A8F1DDEA007028162531DB1 * value)
	{
		___mInfo_7 = value;
		Il2CppCodeGenWriteBarrier((&___mInfo_7), value);
	}

	inline static int32_t get_offset_of_mConnectionState_8() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE, ___mConnectionState_8)); }
	inline int32_t get_mConnectionState_8() const { return ___mConnectionState_8; }
	inline int32_t* get_address_of_mConnectionState_8() { return &___mConnectionState_8; }
	inline void set_mConnectionState_8(int32_t value)
	{
		___mConnectionState_8 = value;
	}

	inline static int32_t get_offset_of_mSignalingState_9() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE, ___mSignalingState_9)); }
	inline int32_t get_mSignalingState_9() const { return ___mSignalingState_9; }
	inline int32_t* get_address_of_mSignalingState_9() { return &___mSignalingState_9; }
	inline void set_mSignalingState_9(int32_t value)
	{
		___mSignalingState_9 = value;
	}

	inline static int32_t get_offset_of_mRenegotiationRequested_10() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE, ___mRenegotiationRequested_10)); }
	inline bool get_mRenegotiationRequested_10() const { return ___mRenegotiationRequested_10; }
	inline bool* get_address_of_mRenegotiationRequested_10() { return &___mRenegotiationRequested_10; }
	inline void set_mRenegotiationRequested_10(bool value)
	{
		___mRenegotiationRequested_10 = value;
	}

	inline static int32_t get_offset_of_mOutgoingSignalingQueue_11() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE, ___mOutgoingSignalingQueue_11)); }
	inline Queue_1_t234B58D376F3C134441C47D5A9EF7789374EE172 * get_mOutgoingSignalingQueue_11() const { return ___mOutgoingSignalingQueue_11; }
	inline Queue_1_t234B58D376F3C134441C47D5A9EF7789374EE172 ** get_address_of_mOutgoingSignalingQueue_11() { return &___mOutgoingSignalingQueue_11; }
	inline void set_mOutgoingSignalingQueue_11(Queue_1_t234B58D376F3C134441C47D5A9EF7789374EE172 * value)
	{
		___mOutgoingSignalingQueue_11 = value;
		Il2CppCodeGenWriteBarrier((&___mOutgoingSignalingQueue_11), value);
	}

	inline static int32_t get_offset_of_mEvents_12() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE, ___mEvents_12)); }
	inline Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * get_mEvents_12() const { return ___mEvents_12; }
	inline Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF ** get_address_of_mEvents_12() { return &___mEvents_12; }
	inline void set_mEvents_12(Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * value)
	{
		___mEvents_12 = value;
		Il2CppCodeGenWriteBarrier((&___mEvents_12), value);
	}

	inline static int32_t get_offset_of_mDidSendRandomNumber_13() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE, ___mDidSendRandomNumber_13)); }
	inline bool get_mDidSendRandomNumber_13() const { return ___mDidSendRandomNumber_13; }
	inline bool* get_address_of_mDidSendRandomNumber_13() { return &___mDidSendRandomNumber_13; }
	inline void set_mDidSendRandomNumber_13(bool value)
	{
		___mDidSendRandomNumber_13 = value;
	}

	inline static int32_t get_offset_of_mRandomNumberSent_14() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE, ___mRandomNumberSent_14)); }
	inline int32_t get_mRandomNumberSent_14() const { return ___mRandomNumberSent_14; }
	inline int32_t* get_address_of_mRandomNumberSent_14() { return &___mRandomNumberSent_14; }
	inline void set_mRandomNumberSent_14(int32_t value)
	{
		___mRandomNumberSent_14 = value;
	}

	inline static int32_t get_offset_of_mIsDisposed_16() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE, ___mIsDisposed_16)); }
	inline bool get_mIsDisposed_16() const { return ___mIsDisposed_16; }
	inline bool* get_address_of_mIsDisposed_16() { return &___mIsDisposed_16; }
	inline void set_mIsDisposed_16(bool value)
	{
		___mIsDisposed_16 = value;
	}
};

struct AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE_StaticFields
{
public:
	// System.Boolean Byn.Awrtc.Base.AWebRtcPeer::sDebugIgnoreTypHost
	bool ___sDebugIgnoreTypHost_0;
	// System.Boolean Byn.Awrtc.Base.AWebRtcPeer::sDebugIgnoreTypSrflx
	bool ___sDebugIgnoreTypSrflx_1;
	// System.String Byn.Awrtc.Base.AWebRtcPeer::sLabelReliable
	String_t* ___sLabelReliable_2;
	// System.String Byn.Awrtc.Base.AWebRtcPeer::sLabelUnreliable
	String_t* ___sLabelUnreliable_3;
	// System.Int32 Byn.Awrtc.Base.AWebRtcPeer::sNextLocalId
	int32_t ___sNextLocalId_4;
	// System.String Byn.Awrtc.Base.AWebRtcPeer::LOGTAG
	String_t* ___LOGTAG_15;

public:
	inline static int32_t get_offset_of_sDebugIgnoreTypHost_0() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE_StaticFields, ___sDebugIgnoreTypHost_0)); }
	inline bool get_sDebugIgnoreTypHost_0() const { return ___sDebugIgnoreTypHost_0; }
	inline bool* get_address_of_sDebugIgnoreTypHost_0() { return &___sDebugIgnoreTypHost_0; }
	inline void set_sDebugIgnoreTypHost_0(bool value)
	{
		___sDebugIgnoreTypHost_0 = value;
	}

	inline static int32_t get_offset_of_sDebugIgnoreTypSrflx_1() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE_StaticFields, ___sDebugIgnoreTypSrflx_1)); }
	inline bool get_sDebugIgnoreTypSrflx_1() const { return ___sDebugIgnoreTypSrflx_1; }
	inline bool* get_address_of_sDebugIgnoreTypSrflx_1() { return &___sDebugIgnoreTypSrflx_1; }
	inline void set_sDebugIgnoreTypSrflx_1(bool value)
	{
		___sDebugIgnoreTypSrflx_1 = value;
	}

	inline static int32_t get_offset_of_sLabelReliable_2() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE_StaticFields, ___sLabelReliable_2)); }
	inline String_t* get_sLabelReliable_2() const { return ___sLabelReliable_2; }
	inline String_t** get_address_of_sLabelReliable_2() { return &___sLabelReliable_2; }
	inline void set_sLabelReliable_2(String_t* value)
	{
		___sLabelReliable_2 = value;
		Il2CppCodeGenWriteBarrier((&___sLabelReliable_2), value);
	}

	inline static int32_t get_offset_of_sLabelUnreliable_3() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE_StaticFields, ___sLabelUnreliable_3)); }
	inline String_t* get_sLabelUnreliable_3() const { return ___sLabelUnreliable_3; }
	inline String_t** get_address_of_sLabelUnreliable_3() { return &___sLabelUnreliable_3; }
	inline void set_sLabelUnreliable_3(String_t* value)
	{
		___sLabelUnreliable_3 = value;
		Il2CppCodeGenWriteBarrier((&___sLabelUnreliable_3), value);
	}

	inline static int32_t get_offset_of_sNextLocalId_4() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE_StaticFields, ___sNextLocalId_4)); }
	inline int32_t get_sNextLocalId_4() const { return ___sNextLocalId_4; }
	inline int32_t* get_address_of_sNextLocalId_4() { return &___sNextLocalId_4; }
	inline void set_sNextLocalId_4(int32_t value)
	{
		___sNextLocalId_4 = value;
	}

	inline static int32_t get_offset_of_LOGTAG_15() { return static_cast<int32_t>(offsetof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE_StaticFields, ___LOGTAG_15)); }
	inline String_t* get_LOGTAG_15() const { return ___LOGTAG_15; }
	inline String_t** get_address_of_LOGTAG_15() { return &___LOGTAG_15; }
	inline void set_LOGTAG_15(String_t* value)
	{
		___LOGTAG_15 = value;
		Il2CppCodeGenWriteBarrier((&___LOGTAG_15), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AWEBRTCPEER_T8E8BD87060FCBDBD878944A96BE224357503BCEE_H
#ifndef WEBSOCKETNETWORK_TCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F_H
#define WEBSOCKETNETWORK_TCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.WebsocketNetwork
struct  WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F  : public RuntimeObject
{
public:
	// Byn.Awrtc.Base.IWebsocketClient Byn.Awrtc.Base.WebsocketNetwork::mSocket
	RuntimeObject* ___mSocket_1;
	// System.Object Byn.Awrtc.Base.WebsocketNetwork::mLock
	RuntimeObject * ___mLock_2;
	// Byn.Awrtc.Base.WebsocketConnectionStatus Byn.Awrtc.Base.WebsocketNetwork::mStatus
	int32_t ___mStatus_3;
	// System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent> Byn.Awrtc.Base.WebsocketNetwork::mOutgoingQueue
	Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * ___mOutgoingQueue_4;
	// System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent> Byn.Awrtc.Base.WebsocketNetwork::mIncomingQueue
	Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * ___mIncomingQueue_5;
	// Byn.Awrtc.Base.WebsocketServerStatus Byn.Awrtc.Base.WebsocketNetwork::mServerStatus
	int32_t ___mServerStatus_6;
	// System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId> Byn.Awrtc.Base.WebsocketNetwork::mConnecting
	List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * ___mConnecting_7;
	// System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId> Byn.Awrtc.Base.WebsocketNetwork::mConnections
	List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * ___mConnections_8;
	// Byn.Awrtc.ConnectionId Byn.Awrtc.Base.WebsocketNetwork::mNextOutgoingConnectionId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mNextOutgoingConnectionId_9;
	// System.Byte Byn.Awrtc.Base.WebsocketNetwork::mRemoteProtocolVersion
	uint8_t ___mRemoteProtocolVersion_12;
	// System.String Byn.Awrtc.Base.WebsocketNetwork::mUrl
	String_t* ___mUrl_13;
	// Byn.Awrtc.Base.Configuration Byn.Awrtc.Base.WebsocketNetwork::mConfig
	Configuration_tBB4510742434F3421303DD936FD4461242012925 * ___mConfig_14;
	// System.DateTime Byn.Awrtc.Base.WebsocketNetwork::mLastHeartbeat
	DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  ___mLastHeartbeat_15;
	// System.Boolean Byn.Awrtc.Base.WebsocketNetwork::mHeartbeatReceived
	bool ___mHeartbeatReceived_16;
	// System.Boolean Byn.Awrtc.Base.WebsocketNetwork::mIsDisposed
	bool ___mIsDisposed_18;

public:
	inline static int32_t get_offset_of_mSocket_1() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F, ___mSocket_1)); }
	inline RuntimeObject* get_mSocket_1() const { return ___mSocket_1; }
	inline RuntimeObject** get_address_of_mSocket_1() { return &___mSocket_1; }
	inline void set_mSocket_1(RuntimeObject* value)
	{
		___mSocket_1 = value;
		Il2CppCodeGenWriteBarrier((&___mSocket_1), value);
	}

	inline static int32_t get_offset_of_mLock_2() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F, ___mLock_2)); }
	inline RuntimeObject * get_mLock_2() const { return ___mLock_2; }
	inline RuntimeObject ** get_address_of_mLock_2() { return &___mLock_2; }
	inline void set_mLock_2(RuntimeObject * value)
	{
		___mLock_2 = value;
		Il2CppCodeGenWriteBarrier((&___mLock_2), value);
	}

	inline static int32_t get_offset_of_mStatus_3() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F, ___mStatus_3)); }
	inline int32_t get_mStatus_3() const { return ___mStatus_3; }
	inline int32_t* get_address_of_mStatus_3() { return &___mStatus_3; }
	inline void set_mStatus_3(int32_t value)
	{
		___mStatus_3 = value;
	}

	inline static int32_t get_offset_of_mOutgoingQueue_4() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F, ___mOutgoingQueue_4)); }
	inline Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * get_mOutgoingQueue_4() const { return ___mOutgoingQueue_4; }
	inline Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF ** get_address_of_mOutgoingQueue_4() { return &___mOutgoingQueue_4; }
	inline void set_mOutgoingQueue_4(Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * value)
	{
		___mOutgoingQueue_4 = value;
		Il2CppCodeGenWriteBarrier((&___mOutgoingQueue_4), value);
	}

	inline static int32_t get_offset_of_mIncomingQueue_5() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F, ___mIncomingQueue_5)); }
	inline Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * get_mIncomingQueue_5() const { return ___mIncomingQueue_5; }
	inline Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF ** get_address_of_mIncomingQueue_5() { return &___mIncomingQueue_5; }
	inline void set_mIncomingQueue_5(Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * value)
	{
		___mIncomingQueue_5 = value;
		Il2CppCodeGenWriteBarrier((&___mIncomingQueue_5), value);
	}

	inline static int32_t get_offset_of_mServerStatus_6() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F, ___mServerStatus_6)); }
	inline int32_t get_mServerStatus_6() const { return ___mServerStatus_6; }
	inline int32_t* get_address_of_mServerStatus_6() { return &___mServerStatus_6; }
	inline void set_mServerStatus_6(int32_t value)
	{
		___mServerStatus_6 = value;
	}

	inline static int32_t get_offset_of_mConnecting_7() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F, ___mConnecting_7)); }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * get_mConnecting_7() const { return ___mConnecting_7; }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 ** get_address_of_mConnecting_7() { return &___mConnecting_7; }
	inline void set_mConnecting_7(List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * value)
	{
		___mConnecting_7 = value;
		Il2CppCodeGenWriteBarrier((&___mConnecting_7), value);
	}

	inline static int32_t get_offset_of_mConnections_8() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F, ___mConnections_8)); }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * get_mConnections_8() const { return ___mConnections_8; }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 ** get_address_of_mConnections_8() { return &___mConnections_8; }
	inline void set_mConnections_8(List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * value)
	{
		___mConnections_8 = value;
		Il2CppCodeGenWriteBarrier((&___mConnections_8), value);
	}

	inline static int32_t get_offset_of_mNextOutgoingConnectionId_9() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F, ___mNextOutgoingConnectionId_9)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mNextOutgoingConnectionId_9() const { return ___mNextOutgoingConnectionId_9; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mNextOutgoingConnectionId_9() { return &___mNextOutgoingConnectionId_9; }
	inline void set_mNextOutgoingConnectionId_9(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mNextOutgoingConnectionId_9 = value;
	}

	inline static int32_t get_offset_of_mRemoteProtocolVersion_12() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F, ___mRemoteProtocolVersion_12)); }
	inline uint8_t get_mRemoteProtocolVersion_12() const { return ___mRemoteProtocolVersion_12; }
	inline uint8_t* get_address_of_mRemoteProtocolVersion_12() { return &___mRemoteProtocolVersion_12; }
	inline void set_mRemoteProtocolVersion_12(uint8_t value)
	{
		___mRemoteProtocolVersion_12 = value;
	}

	inline static int32_t get_offset_of_mUrl_13() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F, ___mUrl_13)); }
	inline String_t* get_mUrl_13() const { return ___mUrl_13; }
	inline String_t** get_address_of_mUrl_13() { return &___mUrl_13; }
	inline void set_mUrl_13(String_t* value)
	{
		___mUrl_13 = value;
		Il2CppCodeGenWriteBarrier((&___mUrl_13), value);
	}

	inline static int32_t get_offset_of_mConfig_14() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F, ___mConfig_14)); }
	inline Configuration_tBB4510742434F3421303DD936FD4461242012925 * get_mConfig_14() const { return ___mConfig_14; }
	inline Configuration_tBB4510742434F3421303DD936FD4461242012925 ** get_address_of_mConfig_14() { return &___mConfig_14; }
	inline void set_mConfig_14(Configuration_tBB4510742434F3421303DD936FD4461242012925 * value)
	{
		___mConfig_14 = value;
		Il2CppCodeGenWriteBarrier((&___mConfig_14), value);
	}

	inline static int32_t get_offset_of_mLastHeartbeat_15() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F, ___mLastHeartbeat_15)); }
	inline DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  get_mLastHeartbeat_15() const { return ___mLastHeartbeat_15; }
	inline DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132 * get_address_of_mLastHeartbeat_15() { return &___mLastHeartbeat_15; }
	inline void set_mLastHeartbeat_15(DateTime_t349B7449FBAAFF4192636E2B7A07694DA9236132  value)
	{
		___mLastHeartbeat_15 = value;
	}

	inline static int32_t get_offset_of_mHeartbeatReceived_16() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F, ___mHeartbeatReceived_16)); }
	inline bool get_mHeartbeatReceived_16() const { return ___mHeartbeatReceived_16; }
	inline bool* get_address_of_mHeartbeatReceived_16() { return &___mHeartbeatReceived_16; }
	inline void set_mHeartbeatReceived_16(bool value)
	{
		___mHeartbeatReceived_16 = value;
	}

	inline static int32_t get_offset_of_mIsDisposed_18() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F, ___mIsDisposed_18)); }
	inline bool get_mIsDisposed_18() const { return ___mIsDisposed_18; }
	inline bool* get_address_of_mIsDisposed_18() { return &___mIsDisposed_18; }
	inline void set_mIsDisposed_18(bool value)
	{
		___mIsDisposed_18 = value;
	}
};

struct WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F_StaticFields
{
public:
	// System.String Byn.Awrtc.Base.WebsocketNetwork::LOGTAG
	String_t* ___LOGTAG_0;
	// System.Byte Byn.Awrtc.Base.WebsocketNetwork::PROTOCOL_VERSION
	uint8_t ___PROTOCOL_VERSION_10;
	// System.Byte Byn.Awrtc.Base.WebsocketNetwork::PROTOCOL_VERSION_MIN
	uint8_t ___PROTOCOL_VERSION_MIN_11;
	// System.Random Byn.Awrtc.Base.WebsocketNetwork::sRandom
	Random_t18A28484F67EFA289C256F508A5C71D9E6DEE09F * ___sRandom_17;

public:
	inline static int32_t get_offset_of_LOGTAG_0() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F_StaticFields, ___LOGTAG_0)); }
	inline String_t* get_LOGTAG_0() const { return ___LOGTAG_0; }
	inline String_t** get_address_of_LOGTAG_0() { return &___LOGTAG_0; }
	inline void set_LOGTAG_0(String_t* value)
	{
		___LOGTAG_0 = value;
		Il2CppCodeGenWriteBarrier((&___LOGTAG_0), value);
	}

	inline static int32_t get_offset_of_PROTOCOL_VERSION_10() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F_StaticFields, ___PROTOCOL_VERSION_10)); }
	inline uint8_t get_PROTOCOL_VERSION_10() const { return ___PROTOCOL_VERSION_10; }
	inline uint8_t* get_address_of_PROTOCOL_VERSION_10() { return &___PROTOCOL_VERSION_10; }
	inline void set_PROTOCOL_VERSION_10(uint8_t value)
	{
		___PROTOCOL_VERSION_10 = value;
	}

	inline static int32_t get_offset_of_PROTOCOL_VERSION_MIN_11() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F_StaticFields, ___PROTOCOL_VERSION_MIN_11)); }
	inline uint8_t get_PROTOCOL_VERSION_MIN_11() const { return ___PROTOCOL_VERSION_MIN_11; }
	inline uint8_t* get_address_of_PROTOCOL_VERSION_MIN_11() { return &___PROTOCOL_VERSION_MIN_11; }
	inline void set_PROTOCOL_VERSION_MIN_11(uint8_t value)
	{
		___PROTOCOL_VERSION_MIN_11 = value;
	}

	inline static int32_t get_offset_of_sRandom_17() { return static_cast<int32_t>(offsetof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F_StaticFields, ___sRandom_17)); }
	inline Random_t18A28484F67EFA289C256F508A5C71D9E6DEE09F * get_sRandom_17() const { return ___sRandom_17; }
	inline Random_t18A28484F67EFA289C256F508A5C71D9E6DEE09F ** get_address_of_sRandom_17() { return &___sRandom_17; }
	inline void set_sRandom_17(Random_t18A28484F67EFA289C256F508A5C71D9E6DEE09F * value)
	{
		___sRandom_17 = value;
		Il2CppCodeGenWriteBarrier((&___sRandom_17), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WEBSOCKETNETWORK_TCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F_H
#ifndef BUFFEREDFRAME_TAFC3F736E124573A402343AB673AAF8EB53E0028_H
#define BUFFEREDFRAME_TAFC3F736E124573A402343AB673AAF8EB53E0028_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.BufferedFrame
struct  BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028  : public RuntimeObject
{
public:
	// System.Byte[] Byn.Awrtc.BufferedFrame::mBuffer
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___mBuffer_0;
	// System.Int32 Byn.Awrtc.BufferedFrame::mWidth
	int32_t ___mWidth_1;
	// System.Int32 Byn.Awrtc.BufferedFrame::mHeight
	int32_t ___mHeight_2;
	// System.Int32 Byn.Awrtc.BufferedFrame::mRotation
	int32_t ___mRotation_3;
	// System.Boolean Byn.Awrtc.BufferedFrame::mTopRowFirst
	bool ___mTopRowFirst_4;
	// Byn.Awrtc.FramePixelFormat Byn.Awrtc.BufferedFrame::mFormat
	int32_t ___mFormat_5;

public:
	inline static int32_t get_offset_of_mBuffer_0() { return static_cast<int32_t>(offsetof(BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028, ___mBuffer_0)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get_mBuffer_0() const { return ___mBuffer_0; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of_mBuffer_0() { return &___mBuffer_0; }
	inline void set_mBuffer_0(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		___mBuffer_0 = value;
		Il2CppCodeGenWriteBarrier((&___mBuffer_0), value);
	}

	inline static int32_t get_offset_of_mWidth_1() { return static_cast<int32_t>(offsetof(BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028, ___mWidth_1)); }
	inline int32_t get_mWidth_1() const { return ___mWidth_1; }
	inline int32_t* get_address_of_mWidth_1() { return &___mWidth_1; }
	inline void set_mWidth_1(int32_t value)
	{
		___mWidth_1 = value;
	}

	inline static int32_t get_offset_of_mHeight_2() { return static_cast<int32_t>(offsetof(BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028, ___mHeight_2)); }
	inline int32_t get_mHeight_2() const { return ___mHeight_2; }
	inline int32_t* get_address_of_mHeight_2() { return &___mHeight_2; }
	inline void set_mHeight_2(int32_t value)
	{
		___mHeight_2 = value;
	}

	inline static int32_t get_offset_of_mRotation_3() { return static_cast<int32_t>(offsetof(BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028, ___mRotation_3)); }
	inline int32_t get_mRotation_3() const { return ___mRotation_3; }
	inline int32_t* get_address_of_mRotation_3() { return &___mRotation_3; }
	inline void set_mRotation_3(int32_t value)
	{
		___mRotation_3 = value;
	}

	inline static int32_t get_offset_of_mTopRowFirst_4() { return static_cast<int32_t>(offsetof(BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028, ___mTopRowFirst_4)); }
	inline bool get_mTopRowFirst_4() const { return ___mTopRowFirst_4; }
	inline bool* get_address_of_mTopRowFirst_4() { return &___mTopRowFirst_4; }
	inline void set_mTopRowFirst_4(bool value)
	{
		___mTopRowFirst_4 = value;
	}

	inline static int32_t get_offset_of_mFormat_5() { return static_cast<int32_t>(offsetof(BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028, ___mFormat_5)); }
	inline int32_t get_mFormat_5() const { return ___mFormat_5; }
	inline int32_t* get_address_of_mFormat_5() { return &___mFormat_5; }
	inline void set_mFormat_5(int32_t value)
	{
		___mFormat_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BUFFEREDFRAME_TAFC3F736E124573A402343AB673AAF8EB53E0028_H
#ifndef MEDIACONFIG_T27C1D9728366F53BC7E49A1E16B020363B3A304D_H
#define MEDIACONFIG_T27C1D9728366F53BC7E49A1E16B020363B3A304D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.MediaConfig
struct  MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D  : public RuntimeObject
{
public:
	// System.Boolean Byn.Awrtc.MediaConfig::mAudio
	bool ___mAudio_0;
	// System.Boolean Byn.Awrtc.MediaConfig::mVideo
	bool ___mVideo_1;
	// System.String Byn.Awrtc.MediaConfig::mVideoDeviceName
	String_t* ___mVideoDeviceName_2;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMinWidth
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMinWidth_3;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMinHeight
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMinHeight_4;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMaxWidth
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMaxWidth_5;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMaxHeight
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMaxHeight_6;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mIdealWidth
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mIdealWidth_7;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mIdealHeight
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mIdealHeight_8;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mIdealFrameRate
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mIdealFrameRate_9;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMinFrameRate
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMinFrameRate_10;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMaxFrameRate
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMaxFrameRate_11;
	// Byn.Awrtc.FramePixelFormat Byn.Awrtc.MediaConfig::mFormat
	int32_t ___mFormat_12;

public:
	inline static int32_t get_offset_of_mAudio_0() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mAudio_0)); }
	inline bool get_mAudio_0() const { return ___mAudio_0; }
	inline bool* get_address_of_mAudio_0() { return &___mAudio_0; }
	inline void set_mAudio_0(bool value)
	{
		___mAudio_0 = value;
	}

	inline static int32_t get_offset_of_mVideo_1() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mVideo_1)); }
	inline bool get_mVideo_1() const { return ___mVideo_1; }
	inline bool* get_address_of_mVideo_1() { return &___mVideo_1; }
	inline void set_mVideo_1(bool value)
	{
		___mVideo_1 = value;
	}

	inline static int32_t get_offset_of_mVideoDeviceName_2() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mVideoDeviceName_2)); }
	inline String_t* get_mVideoDeviceName_2() const { return ___mVideoDeviceName_2; }
	inline String_t** get_address_of_mVideoDeviceName_2() { return &___mVideoDeviceName_2; }
	inline void set_mVideoDeviceName_2(String_t* value)
	{
		___mVideoDeviceName_2 = value;
		Il2CppCodeGenWriteBarrier((&___mVideoDeviceName_2), value);
	}

	inline static int32_t get_offset_of_mMinWidth_3() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMinWidth_3)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMinWidth_3() const { return ___mMinWidth_3; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMinWidth_3() { return &___mMinWidth_3; }
	inline void set_mMinWidth_3(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMinWidth_3 = value;
	}

	inline static int32_t get_offset_of_mMinHeight_4() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMinHeight_4)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMinHeight_4() const { return ___mMinHeight_4; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMinHeight_4() { return &___mMinHeight_4; }
	inline void set_mMinHeight_4(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMinHeight_4 = value;
	}

	inline static int32_t get_offset_of_mMaxWidth_5() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMaxWidth_5)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMaxWidth_5() const { return ___mMaxWidth_5; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMaxWidth_5() { return &___mMaxWidth_5; }
	inline void set_mMaxWidth_5(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMaxWidth_5 = value;
	}

	inline static int32_t get_offset_of_mMaxHeight_6() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMaxHeight_6)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMaxHeight_6() const { return ___mMaxHeight_6; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMaxHeight_6() { return &___mMaxHeight_6; }
	inline void set_mMaxHeight_6(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMaxHeight_6 = value;
	}

	inline static int32_t get_offset_of_mIdealWidth_7() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mIdealWidth_7)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mIdealWidth_7() const { return ___mIdealWidth_7; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mIdealWidth_7() { return &___mIdealWidth_7; }
	inline void set_mIdealWidth_7(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mIdealWidth_7 = value;
	}

	inline static int32_t get_offset_of_mIdealHeight_8() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mIdealHeight_8)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mIdealHeight_8() const { return ___mIdealHeight_8; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mIdealHeight_8() { return &___mIdealHeight_8; }
	inline void set_mIdealHeight_8(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mIdealHeight_8 = value;
	}

	inline static int32_t get_offset_of_mIdealFrameRate_9() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mIdealFrameRate_9)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mIdealFrameRate_9() const { return ___mIdealFrameRate_9; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mIdealFrameRate_9() { return &___mIdealFrameRate_9; }
	inline void set_mIdealFrameRate_9(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mIdealFrameRate_9 = value;
	}

	inline static int32_t get_offset_of_mMinFrameRate_10() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMinFrameRate_10)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMinFrameRate_10() const { return ___mMinFrameRate_10; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMinFrameRate_10() { return &___mMinFrameRate_10; }
	inline void set_mMinFrameRate_10(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMinFrameRate_10 = value;
	}

	inline static int32_t get_offset_of_mMaxFrameRate_11() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMaxFrameRate_11)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMaxFrameRate_11() const { return ___mMaxFrameRate_11; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMaxFrameRate_11() { return &___mMaxFrameRate_11; }
	inline void set_mMaxFrameRate_11(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMaxFrameRate_11 = value;
	}

	inline static int32_t get_offset_of_mFormat_12() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mFormat_12)); }
	inline int32_t get_mFormat_12() const { return ___mFormat_12; }
	inline int32_t* get_address_of_mFormat_12() { return &___mFormat_12; }
	inline void set_mFormat_12(int32_t value)
	{
		___mFormat_12 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MEDIACONFIG_T27C1D9728366F53BC7E49A1E16B020363B3A304D_H
#ifndef NATIVEAWRTCFACTORY_TC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_H
#define NATIVEAWRTCFACTORY_TC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Native.NativeAwrtcFactory
struct  NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0  : public RuntimeObject
{
public:
	// WebRtcCSharp.RTCPeerConnectionFactoryRef Byn.Awrtc.Native.NativeAwrtcFactory::mFactory
	RTCPeerConnectionFactoryRef_tD457372C81A9E9436643652EBB7351D4E35035DF * ___mFactory_5;
	// System.Collections.Generic.List`1<Byn.Awrtc.Native.NativeWebRtcCall> Byn.Awrtc.Native.NativeAwrtcFactory::mCalls
	List_1_t00993CA2C97E3BE02361D34E70A43B4134EAA9DD * ___mCalls_6;
	// System.Action Byn.Awrtc.Native.NativeAwrtcFactory::LastCallDisposed
	Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * ___LastCallDisposed_7;
	// System.Collections.Generic.List`1<Byn.Awrtc.IBasicNetwork> Byn.Awrtc.Native.NativeAwrtcFactory::mNetworks
	List_1_tA9F4001828A90CEB6EE5E47FF812F909BD858861 * ___mNetworks_8;
	// Byn.Awrtc.Native.NativeVideoInput Byn.Awrtc.Native.NativeAwrtcFactory::mVideoInput
	NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C * ___mVideoInput_9;

public:
	inline static int32_t get_offset_of_mFactory_5() { return static_cast<int32_t>(offsetof(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0, ___mFactory_5)); }
	inline RTCPeerConnectionFactoryRef_tD457372C81A9E9436643652EBB7351D4E35035DF * get_mFactory_5() const { return ___mFactory_5; }
	inline RTCPeerConnectionFactoryRef_tD457372C81A9E9436643652EBB7351D4E35035DF ** get_address_of_mFactory_5() { return &___mFactory_5; }
	inline void set_mFactory_5(RTCPeerConnectionFactoryRef_tD457372C81A9E9436643652EBB7351D4E35035DF * value)
	{
		___mFactory_5 = value;
		Il2CppCodeGenWriteBarrier((&___mFactory_5), value);
	}

	inline static int32_t get_offset_of_mCalls_6() { return static_cast<int32_t>(offsetof(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0, ___mCalls_6)); }
	inline List_1_t00993CA2C97E3BE02361D34E70A43B4134EAA9DD * get_mCalls_6() const { return ___mCalls_6; }
	inline List_1_t00993CA2C97E3BE02361D34E70A43B4134EAA9DD ** get_address_of_mCalls_6() { return &___mCalls_6; }
	inline void set_mCalls_6(List_1_t00993CA2C97E3BE02361D34E70A43B4134EAA9DD * value)
	{
		___mCalls_6 = value;
		Il2CppCodeGenWriteBarrier((&___mCalls_6), value);
	}

	inline static int32_t get_offset_of_LastCallDisposed_7() { return static_cast<int32_t>(offsetof(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0, ___LastCallDisposed_7)); }
	inline Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * get_LastCallDisposed_7() const { return ___LastCallDisposed_7; }
	inline Action_t591D2A86165F896B4B800BB5C25CE18672A55579 ** get_address_of_LastCallDisposed_7() { return &___LastCallDisposed_7; }
	inline void set_LastCallDisposed_7(Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * value)
	{
		___LastCallDisposed_7 = value;
		Il2CppCodeGenWriteBarrier((&___LastCallDisposed_7), value);
	}

	inline static int32_t get_offset_of_mNetworks_8() { return static_cast<int32_t>(offsetof(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0, ___mNetworks_8)); }
	inline List_1_tA9F4001828A90CEB6EE5E47FF812F909BD858861 * get_mNetworks_8() const { return ___mNetworks_8; }
	inline List_1_tA9F4001828A90CEB6EE5E47FF812F909BD858861 ** get_address_of_mNetworks_8() { return &___mNetworks_8; }
	inline void set_mNetworks_8(List_1_tA9F4001828A90CEB6EE5E47FF812F909BD858861 * value)
	{
		___mNetworks_8 = value;
		Il2CppCodeGenWriteBarrier((&___mNetworks_8), value);
	}

	inline static int32_t get_offset_of_mVideoInput_9() { return static_cast<int32_t>(offsetof(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0, ___mVideoInput_9)); }
	inline NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C * get_mVideoInput_9() const { return ___mVideoInput_9; }
	inline NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C ** get_address_of_mVideoInput_9() { return &___mVideoInput_9; }
	inline void set_mVideoInput_9(NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C * value)
	{
		___mVideoInput_9 = value;
		Il2CppCodeGenWriteBarrier((&___mVideoInput_9), value);
	}
};

struct NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_StaticFields
{
public:
	// Byn.Awrtc.Native.NativeAwrtcFactory_StaticInitState Byn.Awrtc.Native.NativeAwrtcFactory::sStaticInitState
	int32_t ___sStaticInitState_0;
	// Byn.Awrtc.Native.NativeAwrtcFactory_ObjInitState Byn.Awrtc.Native.NativeAwrtcFactory::mObjInitState
	int32_t ___mObjInitState_1;
	// WebRtcCSharp.LogCallback Byn.Awrtc.Native.NativeAwrtcFactory::mLogCallback
	LogCallback_t74314F131710C13918F247941A914B2BBA5C2C6D * ___mLogCallback_2;
	// System.String Byn.Awrtc.Native.NativeAwrtcFactory::NATIVE_LOG_TAG
	String_t* ___NATIVE_LOG_TAG_3;
	// System.Int32 Byn.Awrtc.Native.NativeAwrtcFactory::sActiveInstances
	int32_t ___sActiveInstances_4;
	// System.String Byn.Awrtc.Native.NativeAwrtcFactory::LOGTAG
	String_t* ___LOGTAG_10;

public:
	inline static int32_t get_offset_of_sStaticInitState_0() { return static_cast<int32_t>(offsetof(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_StaticFields, ___sStaticInitState_0)); }
	inline int32_t get_sStaticInitState_0() const { return ___sStaticInitState_0; }
	inline int32_t* get_address_of_sStaticInitState_0() { return &___sStaticInitState_0; }
	inline void set_sStaticInitState_0(int32_t value)
	{
		___sStaticInitState_0 = value;
	}

	inline static int32_t get_offset_of_mObjInitState_1() { return static_cast<int32_t>(offsetof(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_StaticFields, ___mObjInitState_1)); }
	inline int32_t get_mObjInitState_1() const { return ___mObjInitState_1; }
	inline int32_t* get_address_of_mObjInitState_1() { return &___mObjInitState_1; }
	inline void set_mObjInitState_1(int32_t value)
	{
		___mObjInitState_1 = value;
	}

	inline static int32_t get_offset_of_mLogCallback_2() { return static_cast<int32_t>(offsetof(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_StaticFields, ___mLogCallback_2)); }
	inline LogCallback_t74314F131710C13918F247941A914B2BBA5C2C6D * get_mLogCallback_2() const { return ___mLogCallback_2; }
	inline LogCallback_t74314F131710C13918F247941A914B2BBA5C2C6D ** get_address_of_mLogCallback_2() { return &___mLogCallback_2; }
	inline void set_mLogCallback_2(LogCallback_t74314F131710C13918F247941A914B2BBA5C2C6D * value)
	{
		___mLogCallback_2 = value;
		Il2CppCodeGenWriteBarrier((&___mLogCallback_2), value);
	}

	inline static int32_t get_offset_of_NATIVE_LOG_TAG_3() { return static_cast<int32_t>(offsetof(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_StaticFields, ___NATIVE_LOG_TAG_3)); }
	inline String_t* get_NATIVE_LOG_TAG_3() const { return ___NATIVE_LOG_TAG_3; }
	inline String_t** get_address_of_NATIVE_LOG_TAG_3() { return &___NATIVE_LOG_TAG_3; }
	inline void set_NATIVE_LOG_TAG_3(String_t* value)
	{
		___NATIVE_LOG_TAG_3 = value;
		Il2CppCodeGenWriteBarrier((&___NATIVE_LOG_TAG_3), value);
	}

	inline static int32_t get_offset_of_sActiveInstances_4() { return static_cast<int32_t>(offsetof(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_StaticFields, ___sActiveInstances_4)); }
	inline int32_t get_sActiveInstances_4() const { return ___sActiveInstances_4; }
	inline int32_t* get_address_of_sActiveInstances_4() { return &___sActiveInstances_4; }
	inline void set_sActiveInstances_4(int32_t value)
	{
		___sActiveInstances_4 = value;
	}

	inline static int32_t get_offset_of_LOGTAG_10() { return static_cast<int32_t>(offsetof(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_StaticFields, ___LOGTAG_10)); }
	inline String_t* get_LOGTAG_10() const { return ___LOGTAG_10; }
	inline String_t** get_address_of_LOGTAG_10() { return &___LOGTAG_10; }
	inline void set_LOGTAG_10(String_t* value)
	{
		___LOGTAG_10 = value;
		Il2CppCodeGenWriteBarrier((&___LOGTAG_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NATIVEAWRTCFACTORY_TC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_H
#ifndef MULTICASTDELEGATE_T_H
#define MULTICASTDELEGATE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MulticastDelegate
struct  MulticastDelegate_t  : public Delegate_t
{
public:
	// System.Delegate[] System.MulticastDelegate::delegates
	DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* ___delegates_11;

public:
	inline static int32_t get_offset_of_delegates_11() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___delegates_11)); }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* get_delegates_11() const { return ___delegates_11; }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86** get_address_of_delegates_11() { return &___delegates_11; }
	inline void set_delegates_11(DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* value)
	{
		___delegates_11 = value;
		Il2CppCodeGenWriteBarrier((&___delegates_11), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_pinvoke : public Delegate_t_marshaled_pinvoke
{
	Delegate_t_marshaled_pinvoke** ___delegates_11;
};
// Native definition for COM marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_com : public Delegate_t_marshaled_com
{
	Delegate_t_marshaled_com** ___delegates_11;
};
#endif // MULTICASTDELEGATE_T_H
#ifndef AUDIOOPTIONS_TD87730FB5EFEB6C7116C2F81B81A0689A7FA1B77_H
#define AUDIOOPTIONS_TD87730FB5EFEB6C7116C2F81B81A0689A7FA1B77_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.AudioOptions
struct  AudioOptions_tD87730FB5EFEB6C7116C2F81B81A0689A7FA1B77  : public RuntimeObject
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.AudioOptions::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_0;
	// System.Boolean WebRtcCSharp.AudioOptions::swigCMemOwn
	bool ___swigCMemOwn_1;

public:
	inline static int32_t get_offset_of_swigCPtr_0() { return static_cast<int32_t>(offsetof(AudioOptions_tD87730FB5EFEB6C7116C2F81B81A0689A7FA1B77, ___swigCPtr_0)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_0() const { return ___swigCPtr_0; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_0() { return &___swigCPtr_0; }
	inline void set_swigCPtr_0(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_0 = value;
	}

	inline static int32_t get_offset_of_swigCMemOwn_1() { return static_cast<int32_t>(offsetof(AudioOptions_tD87730FB5EFEB6C7116C2F81B81A0689A7FA1B77, ___swigCMemOwn_1)); }
	inline bool get_swigCMemOwn_1() const { return ___swigCMemOwn_1; }
	inline bool* get_address_of_swigCMemOwn_1() { return &___swigCMemOwn_1; }
	inline void set_swigCMemOwn_1(bool value)
	{
		___swigCMemOwn_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AUDIOOPTIONS_TD87730FB5EFEB6C7116C2F81B81A0689A7FA1B77_H
#ifndef COPYONWRITEBUFFER_TCA583E29644A766DE80B93D277AC3180A54A8C95_H
#define COPYONWRITEBUFFER_TCA583E29644A766DE80B93D277AC3180A54A8C95_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.CopyOnWriteBuffer
struct  CopyOnWriteBuffer_tCA583E29644A766DE80B93D277AC3180A54A8C95  : public RuntimeObject
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.CopyOnWriteBuffer::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_0;
	// System.Boolean WebRtcCSharp.CopyOnWriteBuffer::swigCMemOwn
	bool ___swigCMemOwn_1;

public:
	inline static int32_t get_offset_of_swigCPtr_0() { return static_cast<int32_t>(offsetof(CopyOnWriteBuffer_tCA583E29644A766DE80B93D277AC3180A54A8C95, ___swigCPtr_0)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_0() const { return ___swigCPtr_0; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_0() { return &___swigCPtr_0; }
	inline void set_swigCPtr_0(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_0 = value;
	}

	inline static int32_t get_offset_of_swigCMemOwn_1() { return static_cast<int32_t>(offsetof(CopyOnWriteBuffer_tCA583E29644A766DE80B93D277AC3180A54A8C95, ___swigCMemOwn_1)); }
	inline bool get_swigCMemOwn_1() const { return ___swigCMemOwn_1; }
	inline bool* get_address_of_swigCMemOwn_1() { return &___swigCMemOwn_1; }
	inline void set_swigCMemOwn_1(bool value)
	{
		___swigCMemOwn_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COPYONWRITEBUFFER_TCA583E29644A766DE80B93D277AC3180A54A8C95_H
#ifndef DATABUFFER_TFC797A5471E13C4C41B0073BE184907F5081285F_H
#define DATABUFFER_TFC797A5471E13C4C41B0073BE184907F5081285F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.DataBuffer
struct  DataBuffer_tFC797A5471E13C4C41B0073BE184907F5081285F  : public RuntimeObject
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.DataBuffer::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_0;
	// System.Boolean WebRtcCSharp.DataBuffer::swigCMemOwn
	bool ___swigCMemOwn_1;

public:
	inline static int32_t get_offset_of_swigCPtr_0() { return static_cast<int32_t>(offsetof(DataBuffer_tFC797A5471E13C4C41B0073BE184907F5081285F, ___swigCPtr_0)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_0() const { return ___swigCPtr_0; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_0() { return &___swigCPtr_0; }
	inline void set_swigCPtr_0(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_0 = value;
	}

	inline static int32_t get_offset_of_swigCMemOwn_1() { return static_cast<int32_t>(offsetof(DataBuffer_tFC797A5471E13C4C41B0073BE184907F5081285F, ___swigCMemOwn_1)); }
	inline bool get_swigCMemOwn_1() const { return ___swigCMemOwn_1; }
	inline bool* get_address_of_swigCMemOwn_1() { return &___swigCMemOwn_1; }
	inline void set_swigCMemOwn_1(bool value)
	{
		___swigCMemOwn_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DATABUFFER_TFC797A5471E13C4C41B0073BE184907F5081285F_H
#ifndef DATACHANNELINIT_T213C7BD6B46F4ACEC6A94F739CA6AD550CF5FBAC_H
#define DATACHANNELINIT_T213C7BD6B46F4ACEC6A94F739CA6AD550CF5FBAC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.DataChannelInit
struct  DataChannelInit_t213C7BD6B46F4ACEC6A94F739CA6AD550CF5FBAC  : public RuntimeObject
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.DataChannelInit::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_0;
	// System.Boolean WebRtcCSharp.DataChannelInit::swigCMemOwn
	bool ___swigCMemOwn_1;

public:
	inline static int32_t get_offset_of_swigCPtr_0() { return static_cast<int32_t>(offsetof(DataChannelInit_t213C7BD6B46F4ACEC6A94F739CA6AD550CF5FBAC, ___swigCPtr_0)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_0() const { return ___swigCPtr_0; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_0() { return &___swigCPtr_0; }
	inline void set_swigCPtr_0(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_0 = value;
	}

	inline static int32_t get_offset_of_swigCMemOwn_1() { return static_cast<int32_t>(offsetof(DataChannelInit_t213C7BD6B46F4ACEC6A94F739CA6AD550CF5FBAC, ___swigCMemOwn_1)); }
	inline bool get_swigCMemOwn_1() const { return ___swigCMemOwn_1; }
	inline bool* get_address_of_swigCMemOwn_1() { return &___swigCMemOwn_1; }
	inline void set_swigCMemOwn_1(bool value)
	{
		___swigCMemOwn_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DATACHANNELINIT_T213C7BD6B46F4ACEC6A94F739CA6AD550CF5FBAC_H
#ifndef ICESERVERS_T731B0B5709F7A24F85388A737619AAD7EC1A73D5_H
#define ICESERVERS_T731B0B5709F7A24F85388A737619AAD7EC1A73D5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.IceServers
struct  IceServers_t731B0B5709F7A24F85388A737619AAD7EC1A73D5  : public RuntimeObject
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.IceServers::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_0;
	// System.Boolean WebRtcCSharp.IceServers::swigCMemOwn
	bool ___swigCMemOwn_1;

public:
	inline static int32_t get_offset_of_swigCPtr_0() { return static_cast<int32_t>(offsetof(IceServers_t731B0B5709F7A24F85388A737619AAD7EC1A73D5, ___swigCPtr_0)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_0() const { return ___swigCPtr_0; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_0() { return &___swigCPtr_0; }
	inline void set_swigCPtr_0(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_0 = value;
	}

	inline static int32_t get_offset_of_swigCMemOwn_1() { return static_cast<int32_t>(offsetof(IceServers_t731B0B5709F7A24F85388A737619AAD7EC1A73D5, ___swigCMemOwn_1)); }
	inline bool get_swigCMemOwn_1() const { return ___swigCMemOwn_1; }
	inline bool* get_address_of_swigCMemOwn_1() { return &___swigCMemOwn_1; }
	inline void set_swigCMemOwn_1(bool value)
	{
		___swigCMemOwn_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ICESERVERS_T731B0B5709F7A24F85388A737619AAD7EC1A73D5_H
#ifndef MEDIACONSTRAINTS_TC547FFFE3A2ADECD0427DBAECD5BD99D560631D4_H
#define MEDIACONSTRAINTS_TC547FFFE3A2ADECD0427DBAECD5BD99D560631D4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.MediaConstraints
struct  MediaConstraints_tC547FFFE3A2ADECD0427DBAECD5BD99D560631D4  : public RuntimeObject
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.MediaConstraints::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_0;
	// System.Boolean WebRtcCSharp.MediaConstraints::swigCMemOwn
	bool ___swigCMemOwn_1;

public:
	inline static int32_t get_offset_of_swigCPtr_0() { return static_cast<int32_t>(offsetof(MediaConstraints_tC547FFFE3A2ADECD0427DBAECD5BD99D560631D4, ___swigCPtr_0)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_0() const { return ___swigCPtr_0; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_0() { return &___swigCPtr_0; }
	inline void set_swigCPtr_0(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_0 = value;
	}

	inline static int32_t get_offset_of_swigCMemOwn_1() { return static_cast<int32_t>(offsetof(MediaConstraints_tC547FFFE3A2ADECD0427DBAECD5BD99D560631D4, ___swigCMemOwn_1)); }
	inline bool get_swigCMemOwn_1() const { return ___swigCMemOwn_1; }
	inline bool* get_address_of_swigCMemOwn_1() { return &___swigCMemOwn_1; }
	inline void set_swigCMemOwn_1(bool value)
	{
		___swigCMemOwn_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MEDIACONSTRAINTS_TC547FFFE3A2ADECD0427DBAECD5BD99D560631D4_H
#ifndef ICESERVER_T6FCF722FAA5CD09E935D721D07CCDFF043767AAD_H
#define ICESERVER_T6FCF722FAA5CD09E935D721D07CCDFF043767AAD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.PeerConnectionInterface_IceServer
struct  IceServer_t6FCF722FAA5CD09E935D721D07CCDFF043767AAD  : public RuntimeObject
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.PeerConnectionInterface_IceServer::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_0;
	// System.Boolean WebRtcCSharp.PeerConnectionInterface_IceServer::swigCMemOwn
	bool ___swigCMemOwn_1;

public:
	inline static int32_t get_offset_of_swigCPtr_0() { return static_cast<int32_t>(offsetof(IceServer_t6FCF722FAA5CD09E935D721D07CCDFF043767AAD, ___swigCPtr_0)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_0() const { return ___swigCPtr_0; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_0() { return &___swigCPtr_0; }
	inline void set_swigCPtr_0(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_0 = value;
	}

	inline static int32_t get_offset_of_swigCMemOwn_1() { return static_cast<int32_t>(offsetof(IceServer_t6FCF722FAA5CD09E935D721D07CCDFF043767AAD, ___swigCMemOwn_1)); }
	inline bool get_swigCMemOwn_1() const { return ___swigCMemOwn_1; }
	inline bool* get_address_of_swigCMemOwn_1() { return &___swigCMemOwn_1; }
	inline void set_swigCMemOwn_1(bool value)
	{
		___swigCMemOwn_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ICESERVER_T6FCF722FAA5CD09E935D721D07CCDFF043767AAD_H
#ifndef RTCCONFIGURATION_T0972A1BF82746EA1D4A457D7B73736A22D9DE40F_H
#define RTCCONFIGURATION_T0972A1BF82746EA1D4A457D7B73736A22D9DE40F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.PeerConnectionInterface_RTCConfiguration
struct  RTCConfiguration_t0972A1BF82746EA1D4A457D7B73736A22D9DE40F  : public RuntimeObject
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.PeerConnectionInterface_RTCConfiguration::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_0;
	// System.Boolean WebRtcCSharp.PeerConnectionInterface_RTCConfiguration::swigCMemOwn
	bool ___swigCMemOwn_1;

public:
	inline static int32_t get_offset_of_swigCPtr_0() { return static_cast<int32_t>(offsetof(RTCConfiguration_t0972A1BF82746EA1D4A457D7B73736A22D9DE40F, ___swigCPtr_0)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_0() const { return ___swigCPtr_0; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_0() { return &___swigCPtr_0; }
	inline void set_swigCPtr_0(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_0 = value;
	}

	inline static int32_t get_offset_of_swigCMemOwn_1() { return static_cast<int32_t>(offsetof(RTCConfiguration_t0972A1BF82746EA1D4A457D7B73736A22D9DE40F, ___swigCMemOwn_1)); }
	inline bool get_swigCMemOwn_1() const { return ___swigCMemOwn_1; }
	inline bool* get_address_of_swigCMemOwn_1() { return &___swigCMemOwn_1; }
	inline void set_swigCMemOwn_1(bool value)
	{
		___swigCMemOwn_1 = value;
	}
};

struct RTCConfiguration_t0972A1BF82746EA1D4A457D7B73736A22D9DE40F_StaticFields
{
public:
	// System.Int32 WebRtcCSharp.PeerConnectionInterface_RTCConfiguration::kUndefined
	int32_t ___kUndefined_2;
	// System.Int32 WebRtcCSharp.PeerConnectionInterface_RTCConfiguration::kAudioJitterBufferMaxPackets
	int32_t ___kAudioJitterBufferMaxPackets_3;
	// System.Int32 WebRtcCSharp.PeerConnectionInterface_RTCConfiguration::kAggressiveIceConnectionReceivingTimeout
	int32_t ___kAggressiveIceConnectionReceivingTimeout_4;

public:
	inline static int32_t get_offset_of_kUndefined_2() { return static_cast<int32_t>(offsetof(RTCConfiguration_t0972A1BF82746EA1D4A457D7B73736A22D9DE40F_StaticFields, ___kUndefined_2)); }
	inline int32_t get_kUndefined_2() const { return ___kUndefined_2; }
	inline int32_t* get_address_of_kUndefined_2() { return &___kUndefined_2; }
	inline void set_kUndefined_2(int32_t value)
	{
		___kUndefined_2 = value;
	}

	inline static int32_t get_offset_of_kAudioJitterBufferMaxPackets_3() { return static_cast<int32_t>(offsetof(RTCConfiguration_t0972A1BF82746EA1D4A457D7B73736A22D9DE40F_StaticFields, ___kAudioJitterBufferMaxPackets_3)); }
	inline int32_t get_kAudioJitterBufferMaxPackets_3() const { return ___kAudioJitterBufferMaxPackets_3; }
	inline int32_t* get_address_of_kAudioJitterBufferMaxPackets_3() { return &___kAudioJitterBufferMaxPackets_3; }
	inline void set_kAudioJitterBufferMaxPackets_3(int32_t value)
	{
		___kAudioJitterBufferMaxPackets_3 = value;
	}

	inline static int32_t get_offset_of_kAggressiveIceConnectionReceivingTimeout_4() { return static_cast<int32_t>(offsetof(RTCConfiguration_t0972A1BF82746EA1D4A457D7B73736A22D9DE40F_StaticFields, ___kAggressiveIceConnectionReceivingTimeout_4)); }
	inline int32_t get_kAggressiveIceConnectionReceivingTimeout_4() const { return ___kAggressiveIceConnectionReceivingTimeout_4; }
	inline int32_t* get_address_of_kAggressiveIceConnectionReceivingTimeout_4() { return &___kAggressiveIceConnectionReceivingTimeout_4; }
	inline void set_kAggressiveIceConnectionReceivingTimeout_4(int32_t value)
	{
		___kAggressiveIceConnectionReceivingTimeout_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RTCCONFIGURATION_T0972A1BF82746EA1D4A457D7B73736A22D9DE40F_H
#ifndef POLLINGMEDIASTREAMREF_T18D181FB11B17D2C311E98F81850263E3BA73798_H
#define POLLINGMEDIASTREAMREF_T18D181FB11B17D2C311E98F81850263E3BA73798_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.PollingMediaStreamRef
struct  PollingMediaStreamRef_t18D181FB11B17D2C311E98F81850263E3BA73798  : public RuntimeObject
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.PollingMediaStreamRef::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_0;
	// System.Boolean WebRtcCSharp.PollingMediaStreamRef::swigCMemOwn
	bool ___swigCMemOwn_1;

public:
	inline static int32_t get_offset_of_swigCPtr_0() { return static_cast<int32_t>(offsetof(PollingMediaStreamRef_t18D181FB11B17D2C311E98F81850263E3BA73798, ___swigCPtr_0)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_0() const { return ___swigCPtr_0; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_0() { return &___swigCPtr_0; }
	inline void set_swigCPtr_0(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_0 = value;
	}

	inline static int32_t get_offset_of_swigCMemOwn_1() { return static_cast<int32_t>(offsetof(PollingMediaStreamRef_t18D181FB11B17D2C311E98F81850263E3BA73798, ___swigCMemOwn_1)); }
	inline bool get_swigCMemOwn_1() const { return ___swigCMemOwn_1; }
	inline bool* get_address_of_swigCMemOwn_1() { return &___swigCMemOwn_1; }
	inline void set_swigCMemOwn_1(bool value)
	{
		___swigCMemOwn_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POLLINGMEDIASTREAMREF_T18D181FB11B17D2C311E98F81850263E3BA73798_H
#ifndef POLLINGPEERREF_T5BD3A5F6E4F213003FB6D6D5648B96F7002DB6A2_H
#define POLLINGPEERREF_T5BD3A5F6E4F213003FB6D6D5648B96F7002DB6A2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.PollingPeerRef
struct  PollingPeerRef_t5BD3A5F6E4F213003FB6D6D5648B96F7002DB6A2  : public RuntimeObject
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.PollingPeerRef::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_0;
	// System.Boolean WebRtcCSharp.PollingPeerRef::swigCMemOwn
	bool ___swigCMemOwn_1;

public:
	inline static int32_t get_offset_of_swigCPtr_0() { return static_cast<int32_t>(offsetof(PollingPeerRef_t5BD3A5F6E4F213003FB6D6D5648B96F7002DB6A2, ___swigCPtr_0)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_0() const { return ___swigCPtr_0; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_0() { return &___swigCPtr_0; }
	inline void set_swigCPtr_0(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_0 = value;
	}

	inline static int32_t get_offset_of_swigCMemOwn_1() { return static_cast<int32_t>(offsetof(PollingPeerRef_t5BD3A5F6E4F213003FB6D6D5648B96F7002DB6A2, ___swigCMemOwn_1)); }
	inline bool get_swigCMemOwn_1() const { return ___swigCMemOwn_1; }
	inline bool* get_address_of_swigCMemOwn_1() { return &___swigCMemOwn_1; }
	inline void set_swigCMemOwn_1(bool value)
	{
		___swigCMemOwn_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POLLINGPEERREF_T5BD3A5F6E4F213003FB6D6D5648B96F7002DB6A2_H
#ifndef RTCPEERCONNECTIONFACTORYREF_TD457372C81A9E9436643652EBB7351D4E35035DF_H
#define RTCPEERCONNECTIONFACTORYREF_TD457372C81A9E9436643652EBB7351D4E35035DF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.RTCPeerConnectionFactoryRef
struct  RTCPeerConnectionFactoryRef_tD457372C81A9E9436643652EBB7351D4E35035DF  : public RuntimeObject
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.RTCPeerConnectionFactoryRef::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_0;
	// System.Boolean WebRtcCSharp.RTCPeerConnectionFactoryRef::swigCMemOwn
	bool ___swigCMemOwn_1;

public:
	inline static int32_t get_offset_of_swigCPtr_0() { return static_cast<int32_t>(offsetof(RTCPeerConnectionFactoryRef_tD457372C81A9E9436643652EBB7351D4E35035DF, ___swigCPtr_0)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_0() const { return ___swigCPtr_0; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_0() { return &___swigCPtr_0; }
	inline void set_swigCPtr_0(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_0 = value;
	}

	inline static int32_t get_offset_of_swigCMemOwn_1() { return static_cast<int32_t>(offsetof(RTCPeerConnectionFactoryRef_tD457372C81A9E9436643652EBB7351D4E35035DF, ___swigCMemOwn_1)); }
	inline bool get_swigCMemOwn_1() const { return ___swigCMemOwn_1; }
	inline bool* get_address_of_swigCMemOwn_1() { return &___swigCMemOwn_1; }
	inline void set_swigCMemOwn_1(bool value)
	{
		___swigCMemOwn_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RTCPEERCONNECTIONFACTORYREF_TD457372C81A9E9436643652EBB7351D4E35035DF_H
#ifndef REFCOUNTINTERFACE_T86B92738167FD7531A66A36C7B5483765B796047_H
#define REFCOUNTINTERFACE_T86B92738167FD7531A66A36C7B5483765B796047_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.RefCountInterface
struct  RefCountInterface_t86B92738167FD7531A66A36C7B5483765B796047  : public RuntimeObject
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.RefCountInterface::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_0;
	// System.Boolean WebRtcCSharp.RefCountInterface::swigCMemOwn
	bool ___swigCMemOwn_1;

public:
	inline static int32_t get_offset_of_swigCPtr_0() { return static_cast<int32_t>(offsetof(RefCountInterface_t86B92738167FD7531A66A36C7B5483765B796047, ___swigCPtr_0)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_0() const { return ___swigCPtr_0; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_0() { return &___swigCPtr_0; }
	inline void set_swigCPtr_0(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_0 = value;
	}

	inline static int32_t get_offset_of_swigCMemOwn_1() { return static_cast<int32_t>(offsetof(RefCountInterface_t86B92738167FD7531A66A36C7B5483765B796047, ___swigCMemOwn_1)); }
	inline bool get_swigCMemOwn_1() const { return ___swigCMemOwn_1; }
	inline bool* get_address_of_swigCMemOwn_1() { return &___swigCMemOwn_1; }
	inline void set_swigCMemOwn_1(bool value)
	{
		___swigCMemOwn_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REFCOUNTINTERFACE_T86B92738167FD7531A66A36C7B5483765B796047_H
#ifndef STRINGVECTOR_T7957DE03AFED56C21E38C8C9CBB09D735C95B00C_H
#define STRINGVECTOR_T7957DE03AFED56C21E38C8C9CBB09D735C95B00C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.StringVector
struct  StringVector_t7957DE03AFED56C21E38C8C9CBB09D735C95B00C  : public RuntimeObject
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.StringVector::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_0;
	// System.Boolean WebRtcCSharp.StringVector::swigCMemOwn
	bool ___swigCMemOwn_1;

public:
	inline static int32_t get_offset_of_swigCPtr_0() { return static_cast<int32_t>(offsetof(StringVector_t7957DE03AFED56C21E38C8C9CBB09D735C95B00C, ___swigCPtr_0)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_0() const { return ___swigCPtr_0; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_0() { return &___swigCPtr_0; }
	inline void set_swigCPtr_0(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_0 = value;
	}

	inline static int32_t get_offset_of_swigCMemOwn_1() { return static_cast<int32_t>(offsetof(StringVector_t7957DE03AFED56C21E38C8C9CBB09D735C95B00C, ___swigCMemOwn_1)); }
	inline bool get_swigCMemOwn_1() const { return ___swigCMemOwn_1; }
	inline bool* get_address_of_swigCMemOwn_1() { return &___swigCMemOwn_1; }
	inline void set_swigCMemOwn_1(bool value)
	{
		___swigCMemOwn_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRINGVECTOR_T7957DE03AFED56C21E38C8C9CBB09D735C95B00C_H
#ifndef VIDEOINPUTREF_T27BF06AD74106BD604BAF613B5FB44934E920732_H
#define VIDEOINPUTREF_T27BF06AD74106BD604BAF613B5FB44934E920732_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.VideoInputRef
struct  VideoInputRef_t27BF06AD74106BD604BAF613B5FB44934E920732  : public RuntimeObject
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.VideoInputRef::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_0;
	// System.Boolean WebRtcCSharp.VideoInputRef::swigCMemOwn
	bool ___swigCMemOwn_1;

public:
	inline static int32_t get_offset_of_swigCPtr_0() { return static_cast<int32_t>(offsetof(VideoInputRef_t27BF06AD74106BD604BAF613B5FB44934E920732, ___swigCPtr_0)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_0() const { return ___swigCPtr_0; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_0() { return &___swigCPtr_0; }
	inline void set_swigCPtr_0(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_0 = value;
	}

	inline static int32_t get_offset_of_swigCMemOwn_1() { return static_cast<int32_t>(offsetof(VideoInputRef_t27BF06AD74106BD604BAF613B5FB44934E920732, ___swigCMemOwn_1)); }
	inline bool get_swigCMemOwn_1() const { return ___swigCMemOwn_1; }
	inline bool* get_address_of_swigCMemOwn_1() { return &___swigCMemOwn_1; }
	inline void set_swigCMemOwn_1(bool value)
	{
		___swigCMemOwn_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEOINPUTREF_T27BF06AD74106BD604BAF613B5FB44934E920732_H
#ifndef WEBRTCWRAP_TD3F71CE4974B8D79A9660F8BB68FEF0DA538B8F6_H
#define WEBRTCWRAP_TD3F71CE4974B8D79A9660F8BB68FEF0DA538B8F6_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.WebRtcWrap
struct  WebRtcWrap_tD3F71CE4974B8D79A9660F8BB68FEF0DA538B8F6  : public RuntimeObject
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.WebRtcWrap::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_0;
	// System.Boolean WebRtcCSharp.WebRtcWrap::swigCMemOwn
	bool ___swigCMemOwn_1;

public:
	inline static int32_t get_offset_of_swigCPtr_0() { return static_cast<int32_t>(offsetof(WebRtcWrap_tD3F71CE4974B8D79A9660F8BB68FEF0DA538B8F6, ___swigCPtr_0)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_0() const { return ___swigCPtr_0; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_0() { return &___swigCPtr_0; }
	inline void set_swigCPtr_0(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_0 = value;
	}

	inline static int32_t get_offset_of_swigCMemOwn_1() { return static_cast<int32_t>(offsetof(WebRtcWrap_tD3F71CE4974B8D79A9660F8BB68FEF0DA538B8F6, ___swigCMemOwn_1)); }
	inline bool get_swigCMemOwn_1() const { return ___swigCMemOwn_1; }
	inline bool* get_address_of_swigCMemOwn_1() { return &___swigCMemOwn_1; }
	inline void set_swigCMemOwn_1(bool value)
	{
		___swigCMemOwn_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WEBRTCWRAP_TD3F71CE4974B8D79A9660F8BB68FEF0DA538B8F6_H
#ifndef AMEDIANETWORK_TACCC85EE35131FFAC9691254A18F2FA4C5DFFCCD_H
#define AMEDIANETWORK_TACCC85EE35131FFAC9691254A18F2FA4C5DFFCCD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.AMediaNetwork
struct  AMediaNetwork_tACCC85EE35131FFAC9691254A18F2FA4C5DFFCCD  : public AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F
{
public:
	// Byn.Awrtc.MediaConfig Byn.Awrtc.Base.AMediaNetwork::mConfig
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___mConfig_10;
	// Byn.Awrtc.Base.IInternalMediaStream Byn.Awrtc.Base.AMediaNetwork::mLocalMediaStream
	RuntimeObject* ___mLocalMediaStream_11;
	// Byn.Awrtc.MediaConfigurationState Byn.Awrtc.Base.AMediaNetwork::mConfigurationState
	uint8_t ___mConfigurationState_12;
	// System.String Byn.Awrtc.Base.AMediaNetwork::mConfigurationError
	String_t* ___mConfigurationError_13;

public:
	inline static int32_t get_offset_of_mConfig_10() { return static_cast<int32_t>(offsetof(AMediaNetwork_tACCC85EE35131FFAC9691254A18F2FA4C5DFFCCD, ___mConfig_10)); }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * get_mConfig_10() const { return ___mConfig_10; }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D ** get_address_of_mConfig_10() { return &___mConfig_10; }
	inline void set_mConfig_10(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * value)
	{
		___mConfig_10 = value;
		Il2CppCodeGenWriteBarrier((&___mConfig_10), value);
	}

	inline static int32_t get_offset_of_mLocalMediaStream_11() { return static_cast<int32_t>(offsetof(AMediaNetwork_tACCC85EE35131FFAC9691254A18F2FA4C5DFFCCD, ___mLocalMediaStream_11)); }
	inline RuntimeObject* get_mLocalMediaStream_11() const { return ___mLocalMediaStream_11; }
	inline RuntimeObject** get_address_of_mLocalMediaStream_11() { return &___mLocalMediaStream_11; }
	inline void set_mLocalMediaStream_11(RuntimeObject* value)
	{
		___mLocalMediaStream_11 = value;
		Il2CppCodeGenWriteBarrier((&___mLocalMediaStream_11), value);
	}

	inline static int32_t get_offset_of_mConfigurationState_12() { return static_cast<int32_t>(offsetof(AMediaNetwork_tACCC85EE35131FFAC9691254A18F2FA4C5DFFCCD, ___mConfigurationState_12)); }
	inline uint8_t get_mConfigurationState_12() const { return ___mConfigurationState_12; }
	inline uint8_t* get_address_of_mConfigurationState_12() { return &___mConfigurationState_12; }
	inline void set_mConfigurationState_12(uint8_t value)
	{
		___mConfigurationState_12 = value;
	}

	inline static int32_t get_offset_of_mConfigurationError_13() { return static_cast<int32_t>(offsetof(AMediaNetwork_tACCC85EE35131FFAC9691254A18F2FA4C5DFFCCD, ___mConfigurationError_13)); }
	inline String_t* get_mConfigurationError_13() const { return ___mConfigurationError_13; }
	inline String_t** get_address_of_mConfigurationError_13() { return &___mConfigurationError_13; }
	inline void set_mConfigurationError_13(String_t* value)
	{
		___mConfigurationError_13 = value;
		Il2CppCodeGenWriteBarrier((&___mConfigurationError_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AMEDIANETWORK_TACCC85EE35131FFAC9691254A18F2FA4C5DFFCCD_H
#ifndef ONCLOSECALLBACK_TC9BAA88B2658E7284177A196926226CABD34885D_H
#define ONCLOSECALLBACK_TC9BAA88B2658E7284177A196926226CABD34885D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.OnCloseCallback
struct  OnCloseCallback_tC9BAA88B2658E7284177A196926226CABD34885D  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ONCLOSECALLBACK_TC9BAA88B2658E7284177A196926226CABD34885D_H
#ifndef ONERRORCALLBACK_T126BEEE105F726876360B83557460438E06F270E_H
#define ONERRORCALLBACK_T126BEEE105F726876360B83557460438E06F270E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.OnErrorCallback
struct  OnErrorCallback_t126BEEE105F726876360B83557460438E06F270E  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ONERRORCALLBACK_T126BEEE105F726876360B83557460438E06F270E_H
#ifndef ONMESSAGECALLBACK_TBF0ED6D1553B81B986CA6D80FB1FBB4F024FF003_H
#define ONMESSAGECALLBACK_TBF0ED6D1553B81B986CA6D80FB1FBB4F024FF003_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.OnMessageCallback
struct  OnMessageCallback_tBF0ED6D1553B81B986CA6D80FB1FBB4F024FF003  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ONMESSAGECALLBACK_TBF0ED6D1553B81B986CA6D80FB1FBB4F024FF003_H
#ifndef ONOPENCALLBACK_T17431A2E44D0FF64FE991828894CDEFDED8849D4_H
#define ONOPENCALLBACK_T17431A2E44D0FF64FE991828894CDEFDED8849D4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.OnOpenCallback
struct  OnOpenCallback_t17431A2E44D0FF64FE991828894CDEFDED8849D4  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ONOPENCALLBACK_T17431A2E44D0FF64FE991828894CDEFDED8849D4_H
#ifndef ONTEXTMESSAGECALLBACK_T77FD7AC1A72DDC0CA237AE373666E1E3755744A1_H
#define ONTEXTMESSAGECALLBACK_T77FD7AC1A72DDC0CA237AE373666E1E3755744A1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.OnTextMessageCallback
struct  OnTextMessageCallback_t77FD7AC1A72DDC0CA237AE373666E1E3755744A1  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ONTEXTMESSAGECALLBACK_T77FD7AC1A72DDC0CA237AE373666E1E3755744A1_H
#ifndef INTERNALDATAPEER_T9F100FC31C326FB0F30F064DCFD63A8D779F7C99_H
#define INTERNALDATAPEER_T9F100FC31C326FB0F30F064DCFD63A8D779F7C99_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Native.InternalDataPeer
struct  InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99  : public AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE
{
public:
	// WebRtcCSharp.PollingPeerRef Byn.Awrtc.Native.InternalDataPeer::mPeer
	PollingPeerRef_t5BD3A5F6E4F213003FB6D6D5648B96F7002DB6A2 * ___mPeer_18;
	// WebRtcCSharp.PollingPeer_ConnectionState Byn.Awrtc.Native.InternalDataPeer::mState
	int32_t ___mState_19;
	// System.Int32 Byn.Awrtc.Native.InternalDataPeer::mUnreliableDc
	int32_t ___mUnreliableDc_20;
	// System.Int32 Byn.Awrtc.Native.InternalDataPeer::mReliableDc
	int32_t ___mReliableDc_21;
	// Byn.Awrtc.Native.NativeAwrtcFactory Byn.Awrtc.Native.InternalDataPeer::mFactory
	NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 * ___mFactory_22;

public:
	inline static int32_t get_offset_of_mPeer_18() { return static_cast<int32_t>(offsetof(InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99, ___mPeer_18)); }
	inline PollingPeerRef_t5BD3A5F6E4F213003FB6D6D5648B96F7002DB6A2 * get_mPeer_18() const { return ___mPeer_18; }
	inline PollingPeerRef_t5BD3A5F6E4F213003FB6D6D5648B96F7002DB6A2 ** get_address_of_mPeer_18() { return &___mPeer_18; }
	inline void set_mPeer_18(PollingPeerRef_t5BD3A5F6E4F213003FB6D6D5648B96F7002DB6A2 * value)
	{
		___mPeer_18 = value;
		Il2CppCodeGenWriteBarrier((&___mPeer_18), value);
	}

	inline static int32_t get_offset_of_mState_19() { return static_cast<int32_t>(offsetof(InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99, ___mState_19)); }
	inline int32_t get_mState_19() const { return ___mState_19; }
	inline int32_t* get_address_of_mState_19() { return &___mState_19; }
	inline void set_mState_19(int32_t value)
	{
		___mState_19 = value;
	}

	inline static int32_t get_offset_of_mUnreliableDc_20() { return static_cast<int32_t>(offsetof(InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99, ___mUnreliableDc_20)); }
	inline int32_t get_mUnreliableDc_20() const { return ___mUnreliableDc_20; }
	inline int32_t* get_address_of_mUnreliableDc_20() { return &___mUnreliableDc_20; }
	inline void set_mUnreliableDc_20(int32_t value)
	{
		___mUnreliableDc_20 = value;
	}

	inline static int32_t get_offset_of_mReliableDc_21() { return static_cast<int32_t>(offsetof(InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99, ___mReliableDc_21)); }
	inline int32_t get_mReliableDc_21() const { return ___mReliableDc_21; }
	inline int32_t* get_address_of_mReliableDc_21() { return &___mReliableDc_21; }
	inline void set_mReliableDc_21(int32_t value)
	{
		___mReliableDc_21 = value;
	}

	inline static int32_t get_offset_of_mFactory_22() { return static_cast<int32_t>(offsetof(InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99, ___mFactory_22)); }
	inline NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 * get_mFactory_22() const { return ___mFactory_22; }
	inline NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 ** get_address_of_mFactory_22() { return &___mFactory_22; }
	inline void set_mFactory_22(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 * value)
	{
		___mFactory_22 = value;
		Il2CppCodeGenWriteBarrier((&___mFactory_22), value);
	}
};

struct InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99_StaticFields
{
public:
	// System.Boolean Byn.Awrtc.Native.InternalDataPeer::sUseUnifiedPlan
	bool ___sUseUnifiedPlan_17;

public:
	inline static int32_t get_offset_of_sUseUnifiedPlan_17() { return static_cast<int32_t>(offsetof(InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99_StaticFields, ___sUseUnifiedPlan_17)); }
	inline bool get_sUseUnifiedPlan_17() const { return ___sUseUnifiedPlan_17; }
	inline bool* get_address_of_sUseUnifiedPlan_17() { return &___sUseUnifiedPlan_17; }
	inline void set_sUseUnifiedPlan_17(bool value)
	{
		___sUseUnifiedPlan_17 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTERNALDATAPEER_T9F100FC31C326FB0F30F064DCFD63A8D779F7C99_H
#ifndef NATIVEMEDIACONFIG_T7A5067A601E07F8015BDD602A7060D07541693B8_H
#define NATIVEMEDIACONFIG_T7A5067A601E07F8015BDD602A7060D07541693B8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Native.NativeMediaConfig
struct  NativeMediaConfig_t7A5067A601E07F8015BDD602A7060D07541693B8  : public MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D
{
public:
	// Byn.Awrtc.Native.NativeAudioOptions Byn.Awrtc.Native.NativeMediaConfig::mOptions
	NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456 * ___mOptions_13;

public:
	inline static int32_t get_offset_of_mOptions_13() { return static_cast<int32_t>(offsetof(NativeMediaConfig_t7A5067A601E07F8015BDD602A7060D07541693B8, ___mOptions_13)); }
	inline NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456 * get_mOptions_13() const { return ___mOptions_13; }
	inline NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456 ** get_address_of_mOptions_13() { return &___mOptions_13; }
	inline void set_mOptions_13(NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456 * value)
	{
		___mOptions_13 = value;
		Il2CppCodeGenWriteBarrier((&___mOptions_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NATIVEMEDIACONFIG_T7A5067A601E07F8015BDD602A7060D07541693B8_H
#ifndef NATIVEWEBRTCCALL_TA431C40909E6A0281177E057BAF5DC00E1FFCB31_H
#define NATIVEWEBRTCCALL_TA431C40909E6A0281177E057BAF5DC00E1FFCB31_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Native.NativeWebRtcCall
struct  NativeWebRtcCall_tA431C40909E6A0281177E057BAF5DC00E1FFCB31  : public AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3
{
public:
	// Byn.Awrtc.Native.NativeAwrtcFactory Byn.Awrtc.Native.NativeWebRtcCall::mFactory
	NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 * ___mFactory_16;

public:
	inline static int32_t get_offset_of_mFactory_16() { return static_cast<int32_t>(offsetof(NativeWebRtcCall_tA431C40909E6A0281177E057BAF5DC00E1FFCB31, ___mFactory_16)); }
	inline NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 * get_mFactory_16() const { return ___mFactory_16; }
	inline NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 ** get_address_of_mFactory_16() { return &___mFactory_16; }
	inline void set_mFactory_16(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 * value)
	{
		___mFactory_16 = value;
		Il2CppCodeGenWriteBarrier((&___mFactory_16), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NATIVEWEBRTCCALL_TA431C40909E6A0281177E057BAF5DC00E1FFCB31_H
#ifndef NATIVEWEBRTCCALLFACTORY_T715F21C459C2AC4DA0A42A7569336D3D5442EB34_H
#define NATIVEWEBRTCCALLFACTORY_T715F21C459C2AC4DA0A42A7569336D3D5442EB34_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Native.NativeWebRtcCallFactory
struct  NativeWebRtcCallFactory_t715F21C459C2AC4DA0A42A7569336D3D5442EB34  : public NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NATIVEWEBRTCCALLFACTORY_T715F21C459C2AC4DA0A42A7569336D3D5442EB34_H
#ifndef NATIVEWEBRTCNETWORK_T3BC2A19D40431D7E6328F6041C53E2D9162B33BA_H
#define NATIVEWEBRTCNETWORK_T3BC2A19D40431D7E6328F6041C53E2D9162B33BA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Native.NativeWebRtcNetwork
struct  NativeWebRtcNetwork_t3BC2A19D40431D7E6328F6041C53E2D9162B33BA  : public AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F
{
public:
	// Byn.Awrtc.Native.NativeAwrtcFactory Byn.Awrtc.Native.NativeWebRtcNetwork::mFactory
	NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 * ___mFactory_10;

public:
	inline static int32_t get_offset_of_mFactory_10() { return static_cast<int32_t>(offsetof(NativeWebRtcNetwork_t3BC2A19D40431D7E6328F6041C53E2D9162B33BA, ___mFactory_10)); }
	inline NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 * get_mFactory_10() const { return ___mFactory_10; }
	inline NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 ** get_address_of_mFactory_10() { return &___mFactory_10; }
	inline void set_mFactory_10(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 * value)
	{
		___mFactory_10 = value;
		Il2CppCodeGenWriteBarrier((&___mFactory_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NATIVEWEBRTCNETWORK_T3BC2A19D40431D7E6328F6041C53E2D9162B33BA_H
#ifndef LOGCALLBACK_T74314F131710C13918F247941A914B2BBA5C2C6D_H
#define LOGCALLBACK_T74314F131710C13918F247941A914B2BBA5C2C6D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.LogCallback
struct  LogCallback_t74314F131710C13918F247941A914B2BBA5C2C6D  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOGCALLBACK_T74314F131710C13918F247941A914B2BBA5C2C6D_H
#ifndef PEERCONNECTIONINTERFACE_TC8DB8DDCCAF073C272C9281E4C67754696A4E2E1_H
#define PEERCONNECTIONINTERFACE_TC8DB8DDCCAF073C272C9281E4C67754696A4E2E1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.PeerConnectionInterface
struct  PeerConnectionInterface_tC8DB8DDCCAF073C272C9281E4C67754696A4E2E1  : public RefCountInterface_t86B92738167FD7531A66A36C7B5483765B796047
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.PeerConnectionInterface::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_2;

public:
	inline static int32_t get_offset_of_swigCPtr_2() { return static_cast<int32_t>(offsetof(PeerConnectionInterface_tC8DB8DDCCAF073C272C9281E4C67754696A4E2E1, ___swigCPtr_2)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_2() const { return ___swigCPtr_2; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_2() { return &___swigCPtr_2; }
	inline void set_swigCPtr_2(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PEERCONNECTIONINTERFACE_TC8DB8DDCCAF073C272C9281E4C67754696A4E2E1_H
#ifndef POLLINGMEDIASTREAM_T786E0830DEA5B37FA91BEBB2E5C950CDDEFC82F3_H
#define POLLINGMEDIASTREAM_T786E0830DEA5B37FA91BEBB2E5C950CDDEFC82F3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.PollingMediaStream
struct  PollingMediaStream_t786E0830DEA5B37FA91BEBB2E5C950CDDEFC82F3  : public RefCountInterface_t86B92738167FD7531A66A36C7B5483765B796047
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.PollingMediaStream::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_2;

public:
	inline static int32_t get_offset_of_swigCPtr_2() { return static_cast<int32_t>(offsetof(PollingMediaStream_t786E0830DEA5B37FA91BEBB2E5C950CDDEFC82F3, ___swigCPtr_2)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_2() const { return ___swigCPtr_2; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_2() { return &___swigCPtr_2; }
	inline void set_swigCPtr_2(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POLLINGMEDIASTREAM_T786E0830DEA5B37FA91BEBB2E5C950CDDEFC82F3_H
#ifndef POLLINGPEER_T3C72C4BC6C538FFE978719CAE21E147BB9598D1F_H
#define POLLINGPEER_T3C72C4BC6C538FFE978719CAE21E147BB9598D1F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.PollingPeer
struct  PollingPeer_t3C72C4BC6C538FFE978719CAE21E147BB9598D1F  : public RefCountInterface_t86B92738167FD7531A66A36C7B5483765B796047
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.PollingPeer::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_2;

public:
	inline static int32_t get_offset_of_swigCPtr_2() { return static_cast<int32_t>(offsetof(PollingPeer_t3C72C4BC6C538FFE978719CAE21E147BB9598D1F, ___swigCPtr_2)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_2() const { return ___swigCPtr_2; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_2() { return &___swigCPtr_2; }
	inline void set_swigCPtr_2(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POLLINGPEER_T3C72C4BC6C538FFE978719CAE21E147BB9598D1F_H
#ifndef RTCPEERCONNECTIONFACTORY_T6C9D3B51805516FFE67FEA94521D3E0FA4D5E50A_H
#define RTCPEERCONNECTIONFACTORY_T6C9D3B51805516FFE67FEA94521D3E0FA4D5E50A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.RTCPeerConnectionFactory
struct  RTCPeerConnectionFactory_t6C9D3B51805516FFE67FEA94521D3E0FA4D5E50A  : public RefCountInterface_t86B92738167FD7531A66A36C7B5483765B796047
{
public:
	// System.Runtime.InteropServices.HandleRef WebRtcCSharp.RTCPeerConnectionFactory::swigCPtr
	HandleRef_t876E76124F400D12395BF61D562162AB6822204A  ___swigCPtr_2;

public:
	inline static int32_t get_offset_of_swigCPtr_2() { return static_cast<int32_t>(offsetof(RTCPeerConnectionFactory_t6C9D3B51805516FFE67FEA94521D3E0FA4D5E50A, ___swigCPtr_2)); }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A  get_swigCPtr_2() const { return ___swigCPtr_2; }
	inline HandleRef_t876E76124F400D12395BF61D562162AB6822204A * get_address_of_swigCPtr_2() { return &___swigCPtr_2; }
	inline void set_swigCPtr_2(HandleRef_t876E76124F400D12395BF61D562162AB6822204A  value)
	{
		___swigCPtr_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RTCPEERCONNECTIONFACTORY_T6C9D3B51805516FFE67FEA94521D3E0FA4D5E50A_H
#ifndef EXCEPTIONARGUMENTDELEGATE_T6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C_H
#define EXCEPTIONARGUMENTDELEGATE_T6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper_ExceptionArgumentDelegate
struct  ExceptionArgumentDelegate_t6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXCEPTIONARGUMENTDELEGATE_T6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C_H
#ifndef EXCEPTIONDELEGATE_TFBAB3130F786224F5897A87B1B321640147B8AA6_H
#define EXCEPTIONDELEGATE_TFBAB3130F786224F5897A87B1B321640147B8AA6_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGExceptionHelper_ExceptionDelegate
struct  ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXCEPTIONDELEGATE_TFBAB3130F786224F5897A87B1B321640147B8AA6_H
#ifndef SWIGSTRINGDELEGATE_T27E7F38AF0AE0B2F586E097415E20C13A0C17EB4_H
#define SWIGSTRINGDELEGATE_T27E7F38AF0AE0B2F586E097415E20C13A0C17EB4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// WebRtcCSharp.WebRtcSwigPINVOKE_SWIGStringHelper_SWIGStringDelegate
struct  SWIGStringDelegate_t27E7F38AF0AE0B2F586E097415E20C13A0C17EB4  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SWIGSTRINGDELEGATE_T27E7F38AF0AE0B2F586E097415E20C13A0C17EB4_H
#ifndef INTERNALMEDIAPEER_T0B2B6EF86903A230B34FC3587CEF5D8BFA57E62A_H
#define INTERNALMEDIAPEER_T0B2B6EF86903A230B34FC3587CEF5D8BFA57E62A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Native.InternalMediaPeer
struct  InternalMediaPeer_t0B2B6EF86903A230B34FC3587CEF5D8BFA57E62A  : public InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99
{
public:
	// Byn.Awrtc.MediaConfig Byn.Awrtc.Native.InternalMediaPeer::mConfig
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___mConfig_23;
	// Byn.Awrtc.Base.IInternalMediaStream Byn.Awrtc.Native.InternalMediaPeer::mRemoteStream
	RuntimeObject* ___mRemoteStream_24;

public:
	inline static int32_t get_offset_of_mConfig_23() { return static_cast<int32_t>(offsetof(InternalMediaPeer_t0B2B6EF86903A230B34FC3587CEF5D8BFA57E62A, ___mConfig_23)); }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * get_mConfig_23() const { return ___mConfig_23; }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D ** get_address_of_mConfig_23() { return &___mConfig_23; }
	inline void set_mConfig_23(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * value)
	{
		___mConfig_23 = value;
		Il2CppCodeGenWriteBarrier((&___mConfig_23), value);
	}

	inline static int32_t get_offset_of_mRemoteStream_24() { return static_cast<int32_t>(offsetof(InternalMediaPeer_t0B2B6EF86903A230B34FC3587CEF5D8BFA57E62A, ___mRemoteStream_24)); }
	inline RuntimeObject* get_mRemoteStream_24() const { return ___mRemoteStream_24; }
	inline RuntimeObject** get_address_of_mRemoteStream_24() { return &___mRemoteStream_24; }
	inline void set_mRemoteStream_24(RuntimeObject* value)
	{
		___mRemoteStream_24 = value;
		Il2CppCodeGenWriteBarrier((&___mRemoteStream_24), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTERNALMEDIAPEER_T0B2B6EF86903A230B34FC3587CEF5D8BFA57E62A_H
#ifndef NATIVEMEDIANETWORK_T61662799F8DCBB805D0D437E30520C21F0C0E381_H
#define NATIVEMEDIANETWORK_T61662799F8DCBB805D0D437E30520C21F0C0E381_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Native.NativeMediaNetwork
struct  NativeMediaNetwork_t61662799F8DCBB805D0D437E30520C21F0C0E381  : public AMediaNetwork_tACCC85EE35131FFAC9691254A18F2FA4C5DFFCCD
{
public:
	// Byn.Awrtc.Native.NativeAwrtcFactory Byn.Awrtc.Native.NativeMediaNetwork::mCallFactory
	NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 * ___mCallFactory_14;

public:
	inline static int32_t get_offset_of_mCallFactory_14() { return static_cast<int32_t>(offsetof(NativeMediaNetwork_t61662799F8DCBB805D0D437E30520C21F0C0E381, ___mCallFactory_14)); }
	inline NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 * get_mCallFactory_14() const { return ___mCallFactory_14; }
	inline NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 ** get_address_of_mCallFactory_14() { return &___mCallFactory_14; }
	inline void set_mCallFactory_14(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0 * value)
	{
		___mCallFactory_14 = value;
		Il2CppCodeGenWriteBarrier((&___mCallFactory_14), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NATIVEMEDIANETWORK_T61662799F8DCBB805D0D437E30520C21F0C0E381_H





#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2900 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2901 = { sizeof (BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2901[6] = 
{
	BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028::get_offset_of_mBuffer_0(),
	BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028::get_offset_of_mWidth_1(),
	BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028::get_offset_of_mHeight_2(),
	BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028::get_offset_of_mRotation_3(),
	BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028::get_offset_of_mTopRowFirst_4(),
	BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028::get_offset_of_mFormat_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2902 = { sizeof (SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0), -1, sizeof(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2902[7] = 
{
	SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields::get_offset_of_TAG_WARNING_0(),
	SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields::get_offset_of_TAG_ERROR_1(),
	SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields::get_offset_of_TAG_EXCEPTION_2(),
	SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields::get_offset_of_TAG_INFO_3(),
	SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields::get_offset_of_TAG_DEBUG_4(),
	SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields::get_offset_of_TAG_VERBOSE_5(),
	SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields::get_offset_of_sLogger_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2903 = { sizeof (U3CPrivateImplementationDetailsU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_t0EF491E7C6CA3D3B0D052D94577A25F2983BB080), -1, sizeof(U3CPrivateImplementationDetailsU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_t0EF491E7C6CA3D3B0D052D94577A25F2983BB080_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2903[1] = 
{
	U3CPrivateImplementationDetailsU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_t0EF491E7C6CA3D3B0D052D94577A25F2983BB080_StaticFields::get_offset_of_U24U24method0x6000054U2D1_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2904 = { sizeof (__StaticArrayInitTypeSizeU3D128_tA1E351C123D4FE21E27968CB84AB3C9993E5ABDE)+ sizeof (RuntimeObject), sizeof(__StaticArrayInitTypeSizeU3D128_tA1E351C123D4FE21E27968CB84AB3C9993E5ABDE ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2905 = { sizeof (U3CModuleU3E_tDE5A299227351E064CF5069210AC8ED1294BD51A), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2906 = { sizeof (U3CModuleU3E_t410187D184BFEA098C57AA90C1EEBB14DCD72176), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2907 = { sizeof (U3CModuleU3E_t56CA3936A9EFABF2ED20401359C40BFE63F85A11), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2908 = { sizeof (U3CModuleU3E_tB308A2384DEB86F8845A4E61970976B8944B5DC4), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2909 = { sizeof (U3CModuleU3E_t9F01D6EDA4850AF0D472900DDB14FF9FEAEB2B05), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2910 = { sizeof (AudioOptions_tD87730FB5EFEB6C7116C2F81B81A0689A7FA1B77), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2910[2] = 
{
	AudioOptions_tD87730FB5EFEB6C7116C2F81B81A0689A7FA1B77::get_offset_of_swigCPtr_0(),
	AudioOptions_tD87730FB5EFEB6C7116C2F81B81A0689A7FA1B77::get_offset_of_swigCMemOwn_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2911 = { sizeof (CopyOnWriteBuffer_tCA583E29644A766DE80B93D277AC3180A54A8C95), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2911[2] = 
{
	CopyOnWriteBuffer_tCA583E29644A766DE80B93D277AC3180A54A8C95::get_offset_of_swigCPtr_0(),
	CopyOnWriteBuffer_tCA583E29644A766DE80B93D277AC3180A54A8C95::get_offset_of_swigCMemOwn_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2912 = { sizeof (DataBuffer_tFC797A5471E13C4C41B0073BE184907F5081285F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2912[2] = 
{
	DataBuffer_tFC797A5471E13C4C41B0073BE184907F5081285F::get_offset_of_swigCPtr_0(),
	DataBuffer_tFC797A5471E13C4C41B0073BE184907F5081285F::get_offset_of_swigCMemOwn_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2913 = { sizeof (DataChannelInit_t213C7BD6B46F4ACEC6A94F739CA6AD550CF5FBAC), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2913[2] = 
{
	DataChannelInit_t213C7BD6B46F4ACEC6A94F739CA6AD550CF5FBAC::get_offset_of_swigCPtr_0(),
	DataChannelInit_t213C7BD6B46F4ACEC6A94F739CA6AD550CF5FBAC::get_offset_of_swigCMemOwn_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2914 = { sizeof (IceServers_t731B0B5709F7A24F85388A737619AAD7EC1A73D5), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2914[2] = 
{
	IceServers_t731B0B5709F7A24F85388A737619AAD7EC1A73D5::get_offset_of_swigCPtr_0(),
	IceServers_t731B0B5709F7A24F85388A737619AAD7EC1A73D5::get_offset_of_swigCMemOwn_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2915 = { sizeof (IceServersEnumerator_tFDB2479A21A7AC100DDAAFAE9E3DB95255D97453), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2915[4] = 
{
	IceServersEnumerator_tFDB2479A21A7AC100DDAAFAE9E3DB95255D97453::get_offset_of_collectionRef_0(),
	IceServersEnumerator_tFDB2479A21A7AC100DDAAFAE9E3DB95255D97453::get_offset_of_currentIndex_1(),
	IceServersEnumerator_tFDB2479A21A7AC100DDAAFAE9E3DB95255D97453::get_offset_of_currentObject_2(),
	IceServersEnumerator_tFDB2479A21A7AC100DDAAFAE9E3DB95255D97453::get_offset_of_currentSize_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2916 = { sizeof (LoggingSeverity_t963167393F6858EBBE523CFF6683524F6297BB94)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2916[10] = 
{
	LoggingSeverity_t963167393F6858EBBE523CFF6683524F6297BB94::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2917 = { sizeof (MediaConstraints_tC547FFFE3A2ADECD0427DBAECD5BD99D560631D4), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2917[2] = 
{
	MediaConstraints_tC547FFFE3A2ADECD0427DBAECD5BD99D560631D4::get_offset_of_swigCPtr_0(),
	MediaConstraints_tC547FFFE3A2ADECD0427DBAECD5BD99D560631D4::get_offset_of_swigCMemOwn_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2918 = { sizeof (PeerConnectionInterface_tC8DB8DDCCAF073C272C9281E4C67754696A4E2E1), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2918[1] = 
{
	PeerConnectionInterface_tC8DB8DDCCAF073C272C9281E4C67754696A4E2E1::get_offset_of_swigCPtr_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2919 = { sizeof (IceServer_t6FCF722FAA5CD09E935D721D07CCDFF043767AAD), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2919[2] = 
{
	IceServer_t6FCF722FAA5CD09E935D721D07CCDFF043767AAD::get_offset_of_swigCPtr_0(),
	IceServer_t6FCF722FAA5CD09E935D721D07CCDFF043767AAD::get_offset_of_swigCMemOwn_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2920 = { sizeof (RTCConfiguration_t0972A1BF82746EA1D4A457D7B73736A22D9DE40F), -1, sizeof(RTCConfiguration_t0972A1BF82746EA1D4A457D7B73736A22D9DE40F_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2920[5] = 
{
	RTCConfiguration_t0972A1BF82746EA1D4A457D7B73736A22D9DE40F::get_offset_of_swigCPtr_0(),
	RTCConfiguration_t0972A1BF82746EA1D4A457D7B73736A22D9DE40F::get_offset_of_swigCMemOwn_1(),
	RTCConfiguration_t0972A1BF82746EA1D4A457D7B73736A22D9DE40F_StaticFields::get_offset_of_kUndefined_2(),
	RTCConfiguration_t0972A1BF82746EA1D4A457D7B73736A22D9DE40F_StaticFields::get_offset_of_kAudioJitterBufferMaxPackets_3(),
	RTCConfiguration_t0972A1BF82746EA1D4A457D7B73736A22D9DE40F_StaticFields::get_offset_of_kAggressiveIceConnectionReceivingTimeout_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2921 = { sizeof (PollingMediaStream_t786E0830DEA5B37FA91BEBB2E5C950CDDEFC82F3), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2921[1] = 
{
	PollingMediaStream_t786E0830DEA5B37FA91BEBB2E5C950CDDEFC82F3::get_offset_of_swigCPtr_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2922 = { sizeof (PollingMediaStreamRef_t18D181FB11B17D2C311E98F81850263E3BA73798), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2922[2] = 
{
	PollingMediaStreamRef_t18D181FB11B17D2C311E98F81850263E3BA73798::get_offset_of_swigCPtr_0(),
	PollingMediaStreamRef_t18D181FB11B17D2C311E98F81850263E3BA73798::get_offset_of_swigCMemOwn_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2923 = { sizeof (PollingPeer_t3C72C4BC6C538FFE978719CAE21E147BB9598D1F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2923[1] = 
{
	PollingPeer_t3C72C4BC6C538FFE978719CAE21E147BB9598D1F::get_offset_of_swigCPtr_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2924 = { sizeof (ConnectionState_t410124846AFCB648B6240C2D9FAC21A1FC663FFF)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2924[9] = 
{
	ConnectionState_t410124846AFCB648B6240C2D9FAC21A1FC663FFF::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2925 = { sizeof (PollingPeerRef_t5BD3A5F6E4F213003FB6D6D5648B96F7002DB6A2), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2925[2] = 
{
	PollingPeerRef_t5BD3A5F6E4F213003FB6D6D5648B96F7002DB6A2::get_offset_of_swigCPtr_0(),
	PollingPeerRef_t5BD3A5F6E4F213003FB6D6D5648B96F7002DB6A2::get_offset_of_swigCMemOwn_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2926 = { sizeof (RTCPeerConnectionFactory_t6C9D3B51805516FFE67FEA94521D3E0FA4D5E50A), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2926[1] = 
{
	RTCPeerConnectionFactory_t6C9D3B51805516FFE67FEA94521D3E0FA4D5E50A::get_offset_of_swigCPtr_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2927 = { sizeof (RTCPeerConnectionFactoryRef_tD457372C81A9E9436643652EBB7351D4E35035DF), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2927[2] = 
{
	RTCPeerConnectionFactoryRef_tD457372C81A9E9436643652EBB7351D4E35035DF::get_offset_of_swigCPtr_0(),
	RTCPeerConnectionFactoryRef_tD457372C81A9E9436643652EBB7351D4E35035DF::get_offset_of_swigCMemOwn_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2928 = { sizeof (RefCountInterface_t86B92738167FD7531A66A36C7B5483765B796047), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2928[2] = 
{
	RefCountInterface_t86B92738167FD7531A66A36C7B5483765B796047::get_offset_of_swigCPtr_0(),
	RefCountInterface_t86B92738167FD7531A66A36C7B5483765B796047::get_offset_of_swigCMemOwn_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2929 = { sizeof (SdpSemantics_tA4B48D14B9F86E2DCA08A853836BA4CF17A8B2D7)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2929[3] = 
{
	SdpSemantics_tA4B48D14B9F86E2DCA08A853836BA4CF17A8B2D7::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2930 = { sizeof (StringVector_t7957DE03AFED56C21E38C8C9CBB09D735C95B00C), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2930[2] = 
{
	StringVector_t7957DE03AFED56C21E38C8C9CBB09D735C95B00C::get_offset_of_swigCPtr_0(),
	StringVector_t7957DE03AFED56C21E38C8C9CBB09D735C95B00C::get_offset_of_swigCMemOwn_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2931 = { sizeof (StringVectorEnumerator_t6639D180BB44143917F8940944CC54662413FBB3), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2931[4] = 
{
	StringVectorEnumerator_t6639D180BB44143917F8940944CC54662413FBB3::get_offset_of_collectionRef_0(),
	StringVectorEnumerator_t6639D180BB44143917F8940944CC54662413FBB3::get_offset_of_currentIndex_1(),
	StringVectorEnumerator_t6639D180BB44143917F8940944CC54662413FBB3::get_offset_of_currentObject_2(),
	StringVectorEnumerator_t6639D180BB44143917F8940944CC54662413FBB3::get_offset_of_currentSize_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2932 = { sizeof (VideoInputRef_t27BF06AD74106BD604BAF613B5FB44934E920732), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2932[2] = 
{
	VideoInputRef_t27BF06AD74106BD604BAF613B5FB44934E920732::get_offset_of_swigCPtr_0(),
	VideoInputRef_t27BF06AD74106BD604BAF613B5FB44934E920732::get_offset_of_swigCMemOwn_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2933 = { sizeof (VideoType_t5267934728C2CAFE0C4C0C6C8CBDFD20C268B9CE)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2933[17] = 
{
	VideoType_t5267934728C2CAFE0C4C0C6C8CBDFD20C268B9CE::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2934 = { sizeof (WebRtcSwigPINVOKE_t921BB9F3105BE7E71866D140294C388567A5FE10), -1, sizeof(WebRtcSwigPINVOKE_t921BB9F3105BE7E71866D140294C388567A5FE10_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2934[2] = 
{
	WebRtcSwigPINVOKE_t921BB9F3105BE7E71866D140294C388567A5FE10_StaticFields::get_offset_of_swigExceptionHelper_0(),
	WebRtcSwigPINVOKE_t921BB9F3105BE7E71866D140294C388567A5FE10_StaticFields::get_offset_of_swigStringHelper_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2935 = { sizeof (SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B), -1, sizeof(SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2935[14] = 
{
	SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields::get_offset_of_applicationDelegate_0(),
	SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields::get_offset_of_arithmeticDelegate_1(),
	SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields::get_offset_of_divideByZeroDelegate_2(),
	SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields::get_offset_of_indexOutOfRangeDelegate_3(),
	SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields::get_offset_of_invalidCastDelegate_4(),
	SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields::get_offset_of_invalidOperationDelegate_5(),
	SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields::get_offset_of_ioDelegate_6(),
	SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields::get_offset_of_nullReferenceDelegate_7(),
	SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields::get_offset_of_outOfMemoryDelegate_8(),
	SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields::get_offset_of_overflowDelegate_9(),
	SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields::get_offset_of_systemDelegate_10(),
	SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields::get_offset_of_argumentDelegate_11(),
	SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields::get_offset_of_argumentNullDelegate_12(),
	SWIGExceptionHelper_tCFF7B8443C864DCF4DB261F77846CFC3EA084A2B_StaticFields::get_offset_of_argumentOutOfRangeDelegate_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2936 = { sizeof (ExceptionDelegate_tFBAB3130F786224F5897A87B1B321640147B8AA6), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2937 = { sizeof (ExceptionArgumentDelegate_t6BE3DF75F2D7FEF5580CABF82D4DFBC608D03C8C), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2938 = { sizeof (SWIGPendingException_t1777B1503C90F4B51470811A9BA0E4B6CA09C366), -1, sizeof(SWIGPendingException_t1777B1503C90F4B51470811A9BA0E4B6CA09C366_StaticFields), sizeof(SWIGPendingException_t1777B1503C90F4B51470811A9BA0E4B6CA09C366_ThreadStaticFields) };
extern const int32_t g_FieldOffsetTable2938[2] = 
{
	SWIGPendingException_t1777B1503C90F4B51470811A9BA0E4B6CA09C366_ThreadStaticFields::get_offset_of_pendingException_0() | THREAD_LOCAL_STATIC_MASK,
	SWIGPendingException_t1777B1503C90F4B51470811A9BA0E4B6CA09C366_StaticFields::get_offset_of_numExceptionsPending_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2939 = { sizeof (SWIGStringHelper_t64516B80BD5B451423C2FF303C67724660167FAE), -1, sizeof(SWIGStringHelper_t64516B80BD5B451423C2FF303C67724660167FAE_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2939[1] = 
{
	SWIGStringHelper_t64516B80BD5B451423C2FF303C67724660167FAE_StaticFields::get_offset_of_stringDelegate_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2940 = { sizeof (SWIGStringDelegate_t27E7F38AF0AE0B2F586E097415E20C13A0C17EB4), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2941 = { sizeof (WebRtcWrap_tD3F71CE4974B8D79A9660F8BB68FEF0DA538B8F6), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2941[2] = 
{
	WebRtcWrap_tD3F71CE4974B8D79A9660F8BB68FEF0DA538B8F6::get_offset_of_swigCPtr_0(),
	WebRtcWrap_tD3F71CE4974B8D79A9660F8BB68FEF0DA538B8F6::get_offset_of_swigCMemOwn_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2942 = { sizeof (LogCallback_t74314F131710C13918F247941A914B2BBA5C2C6D), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2943 = { sizeof (MonoPInvokeCallbackAttribute_tC67C9F6F4A2466F4173DDF27B809EE8F118A3E15), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2943[1] = 
{
	MonoPInvokeCallbackAttribute_tC67C9F6F4A2466F4173DDF27B809EE8F118A3E15::get_offset_of_type_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2944 = { sizeof (U3CModuleU3E_t4CB3A0D321EC260EF057B1B18FF3649D10F25CD0), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2945 = { sizeof (AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F), -1, sizeof(AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2945[10] = 
{
	AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F::get_offset_of_mInSignaling_0(),
	AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F::get_offset_of_mNextId_1(),
	AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F::get_offset_of_mConfig_2(),
	AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F::get_offset_of_mEvents_3(),
	AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F::get_offset_of_mIdToConnection_4(),
	AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F::get_offset_of_mConnectionIds_5(),
	AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F::get_offset_of_mServerState_6(),
	AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F::get_offset_of_mIceServers_7(),
	AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F_StaticFields::get_offset_of_LOGTAG_8(),
	AWebRtcNetwork_t03AF5CC3248FCF8B10E9E67D6CCF008E96E2C38F::get_offset_of_mIsDisposed_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2946 = { sizeof (WebRtcNetworkServerState_tE46275F448A11A2F249BB43F91C89A10AEDB8053)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2946[5] = 
{
	WebRtcNetworkServerState_tE46275F448A11A2F249BB43F91C89A10AEDB8053::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2947 = { sizeof (AMediaNetwork_tACCC85EE35131FFAC9691254A18F2FA4C5DFFCCD), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2947[4] = 
{
	AMediaNetwork_tACCC85EE35131FFAC9691254A18F2FA4C5DFFCCD::get_offset_of_mConfig_10(),
	AMediaNetwork_tACCC85EE35131FFAC9691254A18F2FA4C5DFFCCD::get_offset_of_mLocalMediaStream_11(),
	AMediaNetwork_tACCC85EE35131FFAC9691254A18F2FA4C5DFFCCD::get_offset_of_mConfigurationState_12(),
	AMediaNetwork_tACCC85EE35131FFAC9691254A18F2FA4C5DFFCCD::get_offset_of_mConfigurationError_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2948 = { sizeof (AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE), -1, sizeof(AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2948[17] = 
{
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE_StaticFields::get_offset_of_sDebugIgnoreTypHost_0(),
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE_StaticFields::get_offset_of_sDebugIgnoreTypSrflx_1(),
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE_StaticFields::get_offset_of_sLabelReliable_2(),
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE_StaticFields::get_offset_of_sLabelUnreliable_3(),
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE_StaticFields::get_offset_of_sNextLocalId_4(),
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE::get_offset_of_mLocalId_5(),
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE::get_offset_of_mConnectionId_6(),
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE::get_offset_of_mInfo_7(),
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE::get_offset_of_mConnectionState_8(),
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE::get_offset_of_mSignalingState_9(),
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE::get_offset_of_mRenegotiationRequested_10(),
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE::get_offset_of_mOutgoingSignalingQueue_11(),
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE::get_offset_of_mEvents_12(),
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE::get_offset_of_mDidSendRandomNumber_13(),
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE::get_offset_of_mRandomNumberSent_14(),
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE_StaticFields::get_offset_of_LOGTAG_15(),
	AWebRtcPeer_t8E8BD87060FCBDBD878944A96BE224357503BCEE::get_offset_of_mIsDisposed_16(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2949 = { sizeof (WebsocketCloseStatus_tBD293DB70FBE1059C1963C590268417F875EA0D0), -1, sizeof(WebsocketCloseStatus_tBD293DB70FBE1059C1963C590268417F875EA0D0_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2949[4] = 
{
	WebsocketCloseStatus_tBD293DB70FBE1059C1963C590268417F875EA0D0_StaticFields::get_offset_of_NORMAL_CLOSURE_0(),
	WebsocketCloseStatus_tBD293DB70FBE1059C1963C590268417F875EA0D0_StaticFields::get_offset_of_ABNORMAL_CLOSURE_1(),
	WebsocketCloseStatus_tBD293DB70FBE1059C1963C590268417F875EA0D0_StaticFields::get_offset_of_TLS_HANDSHAKE_2(),
	WebsocketCloseStatus_tBD293DB70FBE1059C1963C590268417F875EA0D0_StaticFields::get_offset_of_UNKNOWN_WEBSOCKET_ERROR_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2950 = { sizeof (AWebsocketFactory_t7E099AA13C364DEC0D3C5702B9E0759390651DCE), -1, sizeof(AWebsocketFactory_t7E099AA13C364DEC0D3C5702B9E0759390651DCE_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2950[2] = 
{
	AWebsocketFactory_t7E099AA13C364DEC0D3C5702B9E0759390651DCE_StaticFields::get_offset_of_sDefaultFactory_0(),
	AWebsocketFactory_t7E099AA13C364DEC0D3C5702B9E0759390651DCE::get_offset_of_disposedValue_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2951 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2952 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2953 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2954 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2955 = { sizeof (OnErrorCallback_t126BEEE105F726876360B83557460438E06F270E), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2956 = { sizeof (OnMessageCallback_tBF0ED6D1553B81B986CA6D80FB1FBB4F024FF003), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2957 = { sizeof (OnTextMessageCallback_t77FD7AC1A72DDC0CA237AE373666E1E3755744A1), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2958 = { sizeof (OnOpenCallback_t17431A2E44D0FF64FE991828894CDEFDED8849D4), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2959 = { sizeof (OnCloseCallback_tC9BAA88B2658E7284177A196926226CABD34885D), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2960 = { sizeof (WebsocketReadyState_t62CE7FF86F3B4F3ACB58822938BE9D5680DF986A)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2960[5] = 
{
	WebsocketReadyState_t62CE7FF86F3B4F3ACB58822938BE9D5680DF986A::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2961 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2962 = { sizeof (PeerConnectionState_tCE73F728B7B0EF108AD4E81A34882E4FD8B8AA4D)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2962[6] = 
{
	PeerConnectionState_tCE73F728B7B0EF108AD4E81A34882E4FD8B8AA4D::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2963 = { sizeof (PeerSignalingState_tAF6FA770361CD53D090BDB684198425CF0C0C268)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2963[5] = 
{
	PeerSignalingState_tAF6FA770361CD53D090BDB684198425CF0C0C268::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2964 = { sizeof (SignalingConfig_tAE908484943C078C7439EB1A31243A983F6904EB), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2964[4] = 
{
	SignalingConfig_tAE908484943C078C7439EB1A31243A983F6904EB::get_offset_of_mInUse_0(),
	SignalingConfig_tAE908484943C078C7439EB1A31243A983F6904EB::get_offset_of_mNetwork_1(),
	SignalingConfig_tAE908484943C078C7439EB1A31243A983F6904EB::get_offset_of_mKeepSignalingAlive_2(),
	SignalingConfig_tAE908484943C078C7439EB1A31243A983F6904EB::get_offset_of_mSignalingTimeout_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2965 = { sizeof (SignalingInfo_t62D1320AC25FE0DB1A8F1DDEA007028162531DB1), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2965[4] = 
{
	SignalingInfo_t62D1320AC25FE0DB1A8F1DDEA007028162531DB1::get_offset_of_mSignalingConnected_0(),
	SignalingInfo_t62D1320AC25FE0DB1A8F1DDEA007028162531DB1::get_offset_of_mConnectionId_1(),
	SignalingInfo_t62D1320AC25FE0DB1A8F1DDEA007028162531DB1::get_offset_of_mIsIncoming_2(),
	SignalingInfo_t62D1320AC25FE0DB1A8F1DDEA007028162531DB1::get_offset_of_mSignalingStartTime_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2966 = { sizeof (WebsocketConnectionStatus_t05C18D61394CDA14C094F6DA8DFFD8086CB44B58)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2966[6] = 
{
	WebsocketConnectionStatus_t05C18D61394CDA14C094F6DA8DFFD8086CB44B58::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2967 = { sizeof (WebsocketServerStatus_t299849ECEF221B16D04813471B5EEC427ED43C00)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2967[5] = 
{
	WebsocketServerStatus_t299849ECEF221B16D04813471B5EEC427ED43C00::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2968 = { sizeof (WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F), -1, sizeof(WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2968[19] = 
{
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F_StaticFields::get_offset_of_LOGTAG_0(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F::get_offset_of_mSocket_1(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F::get_offset_of_mLock_2(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F::get_offset_of_mStatus_3(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F::get_offset_of_mOutgoingQueue_4(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F::get_offset_of_mIncomingQueue_5(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F::get_offset_of_mServerStatus_6(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F::get_offset_of_mConnecting_7(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F::get_offset_of_mConnections_8(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F::get_offset_of_mNextOutgoingConnectionId_9(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F_StaticFields::get_offset_of_PROTOCOL_VERSION_10(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F_StaticFields::get_offset_of_PROTOCOL_VERSION_MIN_11(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F::get_offset_of_mRemoteProtocolVersion_12(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F::get_offset_of_mUrl_13(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F::get_offset_of_mConfig_14(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F::get_offset_of_mLastHeartbeat_15(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F::get_offset_of_mHeartbeatReceived_16(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F_StaticFields::get_offset_of_sRandom_17(),
	WebsocketNetwork_tCAABC065934E12E7F8E8BCE0F1D7BB407B1D5E3F::get_offset_of_mIsDisposed_18(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2969 = { sizeof (Configuration_tBB4510742434F3421303DD936FD4461242012925), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2969[2] = 
{
	Configuration_tBB4510742434F3421303DD936FD4461242012925::get_offset_of_mHeartbeat_0(),
	Configuration_tBB4510742434F3421303DD936FD4461242012925::get_offset_of_mIsLocked_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2970 = { sizeof (DirectMemoryFrame_tB02233733990ED13957B176CEEF1A0389AB7309D), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2970[4] = 
{
	DirectMemoryFrame_tB02233733990ED13957B176CEEF1A0389AB7309D::get_offset_of_mHeight_0(),
	DirectMemoryFrame_tB02233733990ED13957B176CEEF1A0389AB7309D::get_offset_of_mWidth_1(),
	DirectMemoryFrame_tB02233733990ED13957B176CEEF1A0389AB7309D::get_offset_of_mRotation_2(),
	DirectMemoryFrame_tB02233733990ED13957B176CEEF1A0389AB7309D::get_offset_of_mParent_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2971 = { sizeof (InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99), -1, sizeof(InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2971[6] = 
{
	InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99_StaticFields::get_offset_of_sUseUnifiedPlan_17(),
	InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99::get_offset_of_mPeer_18(),
	InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99::get_offset_of_mState_19(),
	InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99::get_offset_of_mUnreliableDc_20(),
	InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99::get_offset_of_mReliableDc_21(),
	InternalDataPeer_t9F100FC31C326FB0F30F064DCFD63A8D779F7C99::get_offset_of_mFactory_22(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2972 = { sizeof (InternalMediaPeer_t0B2B6EF86903A230B34FC3587CEF5D8BFA57E62A), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2972[2] = 
{
	InternalMediaPeer_t0B2B6EF86903A230B34FC3587CEF5D8BFA57E62A::get_offset_of_mConfig_23(),
	InternalMediaPeer_t0B2B6EF86903A230B34FC3587CEF5D8BFA57E62A::get_offset_of_mRemoteStream_24(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2973 = { sizeof (InternalMediaStream_t32927ED6BA0825B6E3496C839448E13C69C9AFE1), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2973[4] = 
{
	InternalMediaStream_t32927ED6BA0825B6E3496C839448E13C69C9AFE1::get_offset_of_mFactory_0(),
	InternalMediaStream_t32927ED6BA0825B6E3496C839448E13C69C9AFE1::get_offset_of_mConfig_1(),
	InternalMediaStream_t32927ED6BA0825B6E3496C839448E13C69C9AFE1::get_offset_of_mStream_2(),
	InternalMediaStream_t32927ED6BA0825B6E3496C839448E13C69C9AFE1::get_offset_of_mBuffer_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2974 = { sizeof (NativeMediaConfig_t7A5067A601E07F8015BDD602A7060D07541693B8), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2974[1] = 
{
	NativeMediaConfig_t7A5067A601E07F8015BDD602A7060D07541693B8::get_offset_of_mOptions_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2975 = { sizeof (NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2975[6] = 
{
	NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456::get_offset_of_rawAudioAccess_0(),
	NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456::get_offset_of_U3Cecho_cancellationU3Ek__BackingField_1(),
	NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456::get_offset_of_U3Cextended_filter_aecU3Ek__BackingField_2(),
	NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456::get_offset_of_U3Cdelay_agnostic_aecU3Ek__BackingField_3(),
	NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456::get_offset_of_U3Cnoise_suppressionU3Ek__BackingField_4(),
	NativeAudioOptions_t726C7EAE8C560178FF83C793652033436FC75456::get_offset_of_U3Cauto_gain_controlU3Ek__BackingField_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2976 = { sizeof (NativeMediaNetwork_t61662799F8DCBB805D0D437E30520C21F0C0E381), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2976[1] = 
{
	NativeMediaNetwork_t61662799F8DCBB805D0D437E30520C21F0C0E381::get_offset_of_mCallFactory_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2977 = { sizeof (NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2977[1] = 
{
	NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C::get_offset_of_mVideoInput_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2978 = { sizeof (NativeWebRtcCall_tA431C40909E6A0281177E057BAF5DC00E1FFCB31), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2978[1] = 
{
	NativeWebRtcCall_tA431C40909E6A0281177E057BAF5DC00E1FFCB31::get_offset_of_mFactory_16(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2979 = { sizeof (NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0), -1, sizeof(NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2979[11] = 
{
	NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_StaticFields::get_offset_of_sStaticInitState_0(),
	NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_StaticFields::get_offset_of_mObjInitState_1(),
	NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_StaticFields::get_offset_of_mLogCallback_2(),
	NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_StaticFields::get_offset_of_NATIVE_LOG_TAG_3(),
	NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_StaticFields::get_offset_of_sActiveInstances_4(),
	NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0::get_offset_of_mFactory_5(),
	NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0::get_offset_of_mCalls_6(),
	NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0::get_offset_of_LastCallDisposed_7(),
	NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0::get_offset_of_mNetworks_8(),
	NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0::get_offset_of_mVideoInput_9(),
	NativeAwrtcFactory_tC63E011B7AD1ED903DA74653F62EC377ECCAD2F0_StaticFields::get_offset_of_LOGTAG_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2980 = { sizeof (StaticInitState_t5577CE5712FF8171B0A94566C59DE07F7E4CA68A)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2980[4] = 
{
	StaticInitState_t5577CE5712FF8171B0A94566C59DE07F7E4CA68A::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2981 = { sizeof (ObjInitState_t56C7A4A78939C731F3817071BB80EF546E79EF67)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2981[5] = 
{
	ObjInitState_t56C7A4A78939C731F3817071BB80EF546E79EF67::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2982 = { sizeof (NativeWebRtcCallFactory_t715F21C459C2AC4DA0A42A7569336D3D5442EB34), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2983 = { sizeof (NativeWebRtcNetwork_t3BC2A19D40431D7E6328F6041C53E2D9162B33BA), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2983[1] = 
{
	NativeWebRtcNetwork_t3BC2A19D40431D7E6328F6041C53E2D9162B33BA::get_offset_of_mFactory_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2984 = { sizeof (WrapperConverter_t85E22D97F43975E960015802134CEC7873374E28), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2985 = { sizeof (ByteOrder_tAB45B8AEC08BC2569F11B6AA5586AF15CF990241)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2985[3] = 
{
	ByteOrder_tAB45B8AEC08BC2569F11B6AA5586AF15CF990241::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2986 = { sizeof (CloseEventArgs_tB42CE0192EA8BBCD8652D0B99DB0410D1BF7D438), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2986[4] = 
{
	CloseEventArgs_tB42CE0192EA8BBCD8652D0B99DB0410D1BF7D438::get_offset_of__clean_1(),
	CloseEventArgs_tB42CE0192EA8BBCD8652D0B99DB0410D1BF7D438::get_offset_of__code_2(),
	CloseEventArgs_tB42CE0192EA8BBCD8652D0B99DB0410D1BF7D438::get_offset_of__payloadData_3(),
	CloseEventArgs_tB42CE0192EA8BBCD8652D0B99DB0410D1BF7D438::get_offset_of__reason_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2987 = { sizeof (CloseStatusCode_t5E07B813259D8C02E749C3E3E498AA8BD2BE0B22)+ sizeof (RuntimeObject), sizeof(uint16_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2987[14] = 
{
	CloseStatusCode_t5E07B813259D8C02E749C3E3E498AA8BD2BE0B22::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2988 = { sizeof (CompressionMethod_t813F9401D7C9910DA414FDE6F6329CB5E931DD20)+ sizeof (RuntimeObject), sizeof(uint8_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2988[3] = 
{
	CompressionMethod_t813F9401D7C9910DA414FDE6F6329CB5E931DD20::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2989 = { sizeof (ErrorEventArgs_t4BAD210F4B2115EE3C212AF622ECE6B81679FA26), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2989[2] = 
{
	ErrorEventArgs_t4BAD210F4B2115EE3C212AF622ECE6B81679FA26::get_offset_of__exception_1(),
	ErrorEventArgs_t4BAD210F4B2115EE3C212AF622ECE6B81679FA26::get_offset_of__message_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2990 = { sizeof (Ext_t756812041453FEF828B4FC514A1A83EC29124E3F), -1, sizeof(Ext_t756812041453FEF828B4FC514A1A83EC29124E3F_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2990[2] = 
{
	Ext_t756812041453FEF828B4FC514A1A83EC29124E3F_StaticFields::get_offset_of__last_0(),
	Ext_t756812041453FEF828B4FC514A1A83EC29124E3F_StaticFields::get_offset_of_CSU24U3CU3E9__CachedAnonymousMethodDelegate1_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2991 = { sizeof (U3CU3Ec__DisplayClass3_tD2AD6483A06BF14044CC5EF480A7D0DE718AF59E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2991[3] = 
{
	U3CU3Ec__DisplayClass3_tD2AD6483A06BF14044CC5EF480A7D0DE718AF59E::get_offset_of_len_0(),
	U3CU3Ec__DisplayClass3_tD2AD6483A06BF14044CC5EF480A7D0DE718AF59E::get_offset_of_contains_1(),
	U3CU3Ec__DisplayClass3_tD2AD6483A06BF14044CC5EF480A7D0DE718AF59E::get_offset_of_values_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2992 = { sizeof (U3CU3Ec__DisplayClass9_t4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2992[7] = 
{
	U3CU3Ec__DisplayClass9_t4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2::get_offset_of_buff_0(),
	U3CU3Ec__DisplayClass9_t4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2::get_offset_of_offset_1(),
	U3CU3Ec__DisplayClass9_t4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2::get_offset_of_callback_2(),
	U3CU3Ec__DisplayClass9_t4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2::get_offset_of_stream_3(),
	U3CU3Ec__DisplayClass9_t4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2::get_offset_of_length_4(),
	U3CU3Ec__DisplayClass9_t4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2::get_offset_of_completed_5(),
	U3CU3Ec__DisplayClass9_t4BE7E2C3DEFD0C0BD4CBF0A312DE1EB927DB7AE2::get_offset_of_error_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2993 = { sizeof (U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2993[7] = 
{
	U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF::get_offset_of_dest_0(),
	U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF::get_offset_of_buff_1(),
	U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF::get_offset_of_read_2(),
	U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF::get_offset_of_stream_3(),
	U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF::get_offset_of_bufferLength_4(),
	U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF::get_offset_of_completed_5(),
	U3CU3Ec__DisplayClassd_tFD96FE44A9970FD916A0B430D0895FF58CDEA7FF::get_offset_of_error_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2994 = { sizeof (U3CU3Ec__DisplayClassf_t820CDEE2E00B3094A0F79408D0A677A3FBFD74D9), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2994[2] = 
{
	U3CU3Ec__DisplayClassf_t820CDEE2E00B3094A0F79408D0A677A3FBFD74D9::get_offset_of_CSU24U3CU3E8__localse_0(),
	U3CU3Ec__DisplayClassf_t820CDEE2E00B3094A0F79408D0A677A3FBFD74D9::get_offset_of_len_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2995 = { sizeof (U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2995[14] = 
{
	U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04::get_offset_of_U3CU3E2__current_0(),
	U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04::get_offset_of_U3CU3E1__state_1(),
	U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04::get_offset_of_U3CU3El__initialThreadId_2(),
	U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04::get_offset_of_value_3(),
	U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04::get_offset_of_U3CU3E3__value_4(),
	U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04::get_offset_of_separators_5(),
	U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04::get_offset_of_U3CU3E3__separators_6(),
	U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04::get_offset_of_U3ClenU3E5__12_7(),
	U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04::get_offset_of_U3CsepsU3E5__13_8(),
	U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04::get_offset_of_U3CbuffU3E5__14_9(),
	U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04::get_offset_of_U3CescapedU3E5__15_10(),
	U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04::get_offset_of_U3CquotedU3E5__16_11(),
	U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04::get_offset_of_U3CiU3E5__17_12(),
	U3CSplitHeaderValueU3Ed__11_t5006EFC54F5DF42AD5462FF9E0D3F9612FC1CD04::get_offset_of_U3CcU3E5__18_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2996 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable2996[3] = 
{
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2997 = { sizeof (Fin_t57E86F17A46BB574BA272A65852BAA5374A62F44)+ sizeof (RuntimeObject), sizeof(uint8_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2997[3] = 
{
	Fin_t57E86F17A46BB574BA272A65852BAA5374A62F44::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2998 = { sizeof (HttpBase_tEAFC723C72301668B9EE251A06C4F3A1389C9827), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2998[3] = 
{
	HttpBase_tEAFC723C72301668B9EE251A06C4F3A1389C9827::get_offset_of__headers_0(),
	HttpBase_tEAFC723C72301668B9EE251A06C4F3A1389C9827::get_offset_of__version_1(),
	HttpBase_tEAFC723C72301668B9EE251A06C4F3A1389C9827::get_offset_of_EntityBodyData_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2999 = { sizeof (U3CU3Ec__DisplayClass1_t53206D4373207FB34286B48742E1C6004AF5AD5A), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2999[2] = 
{
	U3CU3Ec__DisplayClass1_t53206D4373207FB34286B48742E1C6004AF5AD5A::get_offset_of_buff_0(),
	U3CU3Ec__DisplayClass1_t53206D4373207FB34286B48742E1C6004AF5AD5A::get_offset_of_cnt_1(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
