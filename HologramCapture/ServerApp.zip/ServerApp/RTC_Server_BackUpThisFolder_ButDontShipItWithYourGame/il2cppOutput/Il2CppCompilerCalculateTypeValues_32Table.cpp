﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "il2cpp-class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"


// Byn.Awrtc.IAwrtcFactory
struct IAwrtcFactory_t382B630EB79D3C53486E6CE2CCE3D678F862D798;
// Byn.Awrtc.IBasicNetwork
struct IBasicNetwork_t60318DADF4A0AF6F2063D0F7E9CE5611F6CB198D;
// Byn.Awrtc.ICall
struct ICall_t264BF08904DEE5C5D41DC5638FF2BF08066400CD;
// Byn.Awrtc.ICall[]
struct ICallU5BU5D_t88E87BA53231880D2D4272EBF46A2A691ADA8741;
// Byn.Awrtc.IMediaNetwork
struct IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780;
// Byn.Awrtc.MediaConfig
struct MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D;
// Byn.Awrtc.Native.NativeVideoInput
struct NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C;
// Byn.Awrtc.NetworkConfig
struct NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47;
// Byn.Awrtc.Unity.UnityCallFactory
struct UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB;
// Byn.Unity.Examples.OneToMany
struct OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086;
// Byn.Unity.Examples.SimpleCall
struct SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD;
// Byn.Unity.Examples.VideoInputApp
struct VideoInputApp_tBD1B4BA06062C26F8519013F665376060F9FC2CF;
// CallApp
struct CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43;
// CallAppUi
struct CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867;
// MessageList
struct MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC;
// System.Action
struct Action_t591D2A86165F896B4B800BB5C25CE18672A55579;
// System.Action`1<System.String>
struct Action_1_t32A9EECF5D4397CC1B9A7C7079870875411B06D0;
// System.AsyncCallback
struct AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4;
// System.Byte[]
struct ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821;
// System.Char[]
struct CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2;
// System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Unity.Examples.ConferenceApp/VideoData>
struct Dictionary_2_t506AF32D1300A531CEAA46A92593E3079E4692F1;
// System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>
struct List_1_tCB9967EC4C00221A410117D712FF423882EB5832;
// System.Collections.Generic.List`1<Byn.Awrtc.Unity.UnityCallFactory/InitCallbacks>
struct List_1_tA9DD76095D2B3253680DE30E64CB3A486DFBDAF7;
// System.Collections.Generic.List`1<System.Int32>
struct List_1_tE1526161A558A17A39A8B69D8EEF3801393B6226;
// System.Collections.Generic.List`1<UnityEngine.Color32>
struct List_1_t749ADA5233D9B421293A000DCB83608A24C3D5D5;
// System.Collections.Generic.List`1<UnityEngine.RectTransform>
struct List_1_t0CD9761E1DF9817484CF4FB4253C6A626DC2311C;
// System.Collections.Generic.List`1<UnityEngine.Vector2>
struct List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB;
// System.Collections.Generic.List`1<UnityEngine.Vector3>
struct List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5;
// System.Collections.Generic.List`1<UnityEngine.Vector4>
struct List_1_tFF4005B40E5BA433006DA11C56DB086B1E2FC955;
// System.DelegateData
struct DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE;
// System.Delegate[]
struct DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86;
// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single>
struct Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3;
// System.IAsyncResult
struct IAsyncResult_t8E194308510B375B42432981AE5E7488C458D598;
// System.Net.Security.RemoteCertificateValidationCallback
struct RemoteCertificateValidationCallback_t9C6BA19681BAA3CD78E6674293A57FF5DF62831E;
// System.Predicate`1<UnityEngine.Component>
struct Predicate_1_t1A9CE8ADB6E9328794CC409FD5BEAACA86D7D769;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.String
struct String_t;
// System.Void
struct Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017;
// UnityEngine.Camera
struct Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34;
// UnityEngine.Events.UnityAction`1<UnityEngine.Component>
struct UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99;
// UnityEngine.GameObject
struct GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F;
// UnityEngine.RaycastHit2D[]
struct RaycastHit2DU5BU5D_t5F37B944987342C401FA9A231A75AD2991A66165;
// UnityEngine.RaycastHit[]
struct RaycastHitU5BU5D_tE9BB282384F0196211AD1A480477254188211F57;
// UnityEngine.RectOffset
struct RectOffset_tED44B1176E93501050480416699D1F11BAE8C87A;
// UnityEngine.RectTransform
struct RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20;
// UnityEngine.RectTransform/ReapplyDrivenProperties
struct ReapplyDrivenProperties_t431F4FBD9C59AE097FE33C4354CC6251B01B527D;
// UnityEngine.RenderTexture
struct RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6;
// UnityEngine.Texture2D
struct Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C;
// UnityEngine.UI.Button
struct Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B;
// UnityEngine.UI.Dropdown
struct Dropdown_tF6331401084B1213CAB10587A6EC81461501930F;
// UnityEngine.UI.Graphic
struct Graphic_tBA2C3EF11D3DAEBB57F6879AB0BB4F8BD40D00D8;
// UnityEngine.UI.GridLayoutGroup
struct GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8;
// UnityEngine.UI.InputField
struct InputField_t533609195B110760BCFF00B746C87D81969CB005;
// UnityEngine.UI.ObjectPool`1<UnityEngine.UI.LayoutRebuilder>
struct ObjectPool_1_tFA4F33849836CDB27432AE22249BB79D68619541;
// UnityEngine.UI.RawImage
struct RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8;
// UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllCallback
struct GetRayIntersectionAllCallback_t68C2581CCF05E868297EBD3F3361274954845095;
// UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllNonAllocCallback
struct GetRayIntersectionAllNonAllocCallback_tAD7508D45DB6679B6394983579AD18D967CC2AD4;
// UnityEngine.UI.ReflectionMethodsCache/GetRaycastNonAllocCallback
struct GetRaycastNonAllocCallback_tC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D;
// UnityEngine.UI.ReflectionMethodsCache/Raycast2DCallback
struct Raycast2DCallback_tE99ABF9ABC3A380677949E8C05A3E477889B82BE;
// UnityEngine.UI.ReflectionMethodsCache/Raycast3DCallback
struct Raycast3DCallback_t83483916473C9710AEDB316A65CBE62C58935C5F;
// UnityEngine.UI.ReflectionMethodsCache/RaycastAllCallback
struct RaycastAllCallback_t751407A44270E02FAA43D0846A58EE6A8C4AE1CE;
// UnityEngine.UI.Slider
struct Slider_t0654A41304B5CE7074CA86F4E66CB681D0D52C09;
// UnityEngine.UI.Text
struct Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030;
// UnityEngine.UI.Toggle
struct Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106;

struct Delegate_t_marshaled_com;
struct Delegate_t_marshaled_pinvoke;



#ifndef U3CMODULEU3E_TCE4B768174CDE0294B05DD8ED59A7763FF34E99B_H
#define U3CMODULEU3E_TCE4B768174CDE0294B05DD8ED59A7763FF34E99B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_tCE4B768174CDE0294B05DD8ED59A7763FF34E99B 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_TCE4B768174CDE0294B05DD8ED59A7763FF34E99B_H
#ifndef U3CMODULEU3E_T51CA7CF080E6CE0730273E28881393B61A64D06E_H
#define U3CMODULEU3E_T51CA7CF080E6CE0730273E28881393B61A64D06E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t51CA7CF080E6CE0730273E28881393B61A64D06E 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T51CA7CF080E6CE0730273E28881393B61A64D06E_H
#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
#ifndef ANDROIDHELPER_TC0B54CF40032DFE35CD9AB26816E265E12D56969_H
#define ANDROIDHELPER_TC0B54CF40032DFE35CD9AB26816E265E12D56969_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.AndroidHelper
struct  AndroidHelper_tC0B54CF40032DFE35CD9AB26816E265E12D56969  : public RuntimeObject
{
public:

public:
};

struct AndroidHelper_tC0B54CF40032DFE35CD9AB26816E265E12D56969_StaticFields
{
public:
	// System.String Byn.Awrtc.Unity.AndroidHelper::jclass_AndroidVideo
	String_t* ___jclass_AndroidVideo_0;
	// System.String Byn.Awrtc.Unity.AndroidHelper::jclass_PermissionHelper
	String_t* ___jclass_PermissionHelper_1;

public:
	inline static int32_t get_offset_of_jclass_AndroidVideo_0() { return static_cast<int32_t>(offsetof(AndroidHelper_tC0B54CF40032DFE35CD9AB26816E265E12D56969_StaticFields, ___jclass_AndroidVideo_0)); }
	inline String_t* get_jclass_AndroidVideo_0() const { return ___jclass_AndroidVideo_0; }
	inline String_t** get_address_of_jclass_AndroidVideo_0() { return &___jclass_AndroidVideo_0; }
	inline void set_jclass_AndroidVideo_0(String_t* value)
	{
		___jclass_AndroidVideo_0 = value;
		Il2CppCodeGenWriteBarrier((&___jclass_AndroidVideo_0), value);
	}

	inline static int32_t get_offset_of_jclass_PermissionHelper_1() { return static_cast<int32_t>(offsetof(AndroidHelper_tC0B54CF40032DFE35CD9AB26816E265E12D56969_StaticFields, ___jclass_PermissionHelper_1)); }
	inline String_t* get_jclass_PermissionHelper_1() const { return ___jclass_PermissionHelper_1; }
	inline String_t** get_address_of_jclass_PermissionHelper_1() { return &___jclass_PermissionHelper_1; }
	inline void set_jclass_PermissionHelper_1(String_t* value)
	{
		___jclass_PermissionHelper_1 = value;
		Il2CppCodeGenWriteBarrier((&___jclass_PermissionHelper_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ANDROIDHELPER_TC0B54CF40032DFE35CD9AB26816E265E12D56969_H
#ifndef U3CU3EC_T2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_H
#define U3CU3EC_T2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityCallFactory_<>c
struct  U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_StaticFields
{
public:
	// Byn.Awrtc.Unity.UnityCallFactory_<>c Byn.Awrtc.Unity.UnityCallFactory_<>c::<>9
	U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE * ___U3CU3E9_0;
	// System.Net.Security.RemoteCertificateValidationCallback Byn.Awrtc.Unity.UnityCallFactory_<>c::<>9__30_0
	RemoteCertificateValidationCallback_t9C6BA19681BAA3CD78E6674293A57FF5DF62831E * ___U3CU3E9__30_0_1;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9_0), value);
	}

	inline static int32_t get_offset_of_U3CU3E9__30_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_StaticFields, ___U3CU3E9__30_0_1)); }
	inline RemoteCertificateValidationCallback_t9C6BA19681BAA3CD78E6674293A57FF5DF62831E * get_U3CU3E9__30_0_1() const { return ___U3CU3E9__30_0_1; }
	inline RemoteCertificateValidationCallback_t9C6BA19681BAA3CD78E6674293A57FF5DF62831E ** get_address_of_U3CU3E9__30_0_1() { return &___U3CU3E9__30_0_1; }
	inline void set_U3CU3E9__30_0_1(RemoteCertificateValidationCallback_t9C6BA19681BAA3CD78E6674293A57FF5DF62831E * value)
	{
		___U3CU3E9__30_0_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9__30_0_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC_T2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_H
#ifndef U3CCOROUTINEINITASYNCU3ED__28_TA3214622DB8E78242139C65CDFDC288D7A17C3D9_H
#define U3CCOROUTINEINITASYNCU3ED__28_TA3214622DB8E78242139C65CDFDC288D7A17C3D9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityCallFactory_<CoroutineInitAsync>d__28
struct  U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9  : public RuntimeObject
{
public:
	// System.Int32 Byn.Awrtc.Unity.UnityCallFactory_<CoroutineInitAsync>d__28::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Byn.Awrtc.Unity.UnityCallFactory_<CoroutineInitAsync>d__28::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// Byn.Awrtc.Unity.UnityCallFactory Byn.Awrtc.Unity.UnityCallFactory_<CoroutineInitAsync>d__28::<>4__this
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB * ___U3CU3E4__this_2;
	// System.Int32 Byn.Awrtc.Unity.UnityCallFactory_<CoroutineInitAsync>d__28::<waitCounter>5__2
	int32_t ___U3CwaitCounterU3E5__2_3;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9, ___U3CU3E4__this_2)); }
	inline UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E4__this_2), value);
	}

	inline static int32_t get_offset_of_U3CwaitCounterU3E5__2_3() { return static_cast<int32_t>(offsetof(U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9, ___U3CwaitCounterU3E5__2_3)); }
	inline int32_t get_U3CwaitCounterU3E5__2_3() const { return ___U3CwaitCounterU3E5__2_3; }
	inline int32_t* get_address_of_U3CwaitCounterU3E5__2_3() { return &___U3CwaitCounterU3E5__2_3; }
	inline void set_U3CwaitCounterU3E5__2_3(int32_t value)
	{
		___U3CwaitCounterU3E5__2_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CCOROUTINEINITASYNCU3ED__28_TA3214622DB8E78242139C65CDFDC288D7A17C3D9_H
#ifndef INITCALLBACKS_T1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6_H
#define INITCALLBACKS_T1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityCallFactory_InitCallbacks
struct  InitCallbacks_t1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6  : public RuntimeObject
{
public:
	// System.Action Byn.Awrtc.Unity.UnityCallFactory_InitCallbacks::onSuccess
	Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * ___onSuccess_0;
	// System.Action`1<System.String> Byn.Awrtc.Unity.UnityCallFactory_InitCallbacks::onFailure
	Action_1_t32A9EECF5D4397CC1B9A7C7079870875411B06D0 * ___onFailure_1;

public:
	inline static int32_t get_offset_of_onSuccess_0() { return static_cast<int32_t>(offsetof(InitCallbacks_t1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6, ___onSuccess_0)); }
	inline Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * get_onSuccess_0() const { return ___onSuccess_0; }
	inline Action_t591D2A86165F896B4B800BB5C25CE18672A55579 ** get_address_of_onSuccess_0() { return &___onSuccess_0; }
	inline void set_onSuccess_0(Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * value)
	{
		___onSuccess_0 = value;
		Il2CppCodeGenWriteBarrier((&___onSuccess_0), value);
	}

	inline static int32_t get_offset_of_onFailure_1() { return static_cast<int32_t>(offsetof(InitCallbacks_t1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6, ___onFailure_1)); }
	inline Action_1_t32A9EECF5D4397CC1B9A7C7079870875411B06D0 * get_onFailure_1() const { return ___onFailure_1; }
	inline Action_1_t32A9EECF5D4397CC1B9A7C7079870875411B06D0 ** get_address_of_onFailure_1() { return &___onFailure_1; }
	inline void set_onFailure_1(Action_1_t32A9EECF5D4397CC1B9A7C7079870875411B06D0 * value)
	{
		___onFailure_1 = value;
		Il2CppCodeGenWriteBarrier((&___onFailure_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INITCALLBACKS_T1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6_H
#ifndef UNITYHELPER_T8385B1C3D90FCE7C88494C24381E90C932B73841_H
#define UNITYHELPER_T8385B1C3D90FCE7C88494C24381E90C932B73841_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityHelper
struct  UnityHelper_t8385B1C3D90FCE7C88494C24381E90C932B73841  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNITYHELPER_T8385B1C3D90FCE7C88494C24381E90C932B73841_H
#ifndef UNITYMEDIAHELPER_T909B65F549010A7353DC82E5AF7C0E259B42FC00_H
#define UNITYMEDIAHELPER_T909B65F549010A7353DC82E5AF7C0E259B42FC00_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityMediaHelper
struct  UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00  : public RuntimeObject
{
public:

public:
};

struct UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00_StaticFields
{
public:
	// System.String Byn.Awrtc.Unity.UnityMediaHelper::I420_MAT_NAME
	String_t* ___I420_MAT_NAME_0;
	// System.String Byn.Awrtc.Unity.UnityMediaHelper::I420_MAT_UPLANE
	String_t* ___I420_MAT_UPLANE_1;
	// System.String Byn.Awrtc.Unity.UnityMediaHelper::I420_MAT_VPLANE
	String_t* ___I420_MAT_VPLANE_2;

public:
	inline static int32_t get_offset_of_I420_MAT_NAME_0() { return static_cast<int32_t>(offsetof(UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00_StaticFields, ___I420_MAT_NAME_0)); }
	inline String_t* get_I420_MAT_NAME_0() const { return ___I420_MAT_NAME_0; }
	inline String_t** get_address_of_I420_MAT_NAME_0() { return &___I420_MAT_NAME_0; }
	inline void set_I420_MAT_NAME_0(String_t* value)
	{
		___I420_MAT_NAME_0 = value;
		Il2CppCodeGenWriteBarrier((&___I420_MAT_NAME_0), value);
	}

	inline static int32_t get_offset_of_I420_MAT_UPLANE_1() { return static_cast<int32_t>(offsetof(UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00_StaticFields, ___I420_MAT_UPLANE_1)); }
	inline String_t* get_I420_MAT_UPLANE_1() const { return ___I420_MAT_UPLANE_1; }
	inline String_t** get_address_of_I420_MAT_UPLANE_1() { return &___I420_MAT_UPLANE_1; }
	inline void set_I420_MAT_UPLANE_1(String_t* value)
	{
		___I420_MAT_UPLANE_1 = value;
		Il2CppCodeGenWriteBarrier((&___I420_MAT_UPLANE_1), value);
	}

	inline static int32_t get_offset_of_I420_MAT_VPLANE_2() { return static_cast<int32_t>(offsetof(UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00_StaticFields, ___I420_MAT_VPLANE_2)); }
	inline String_t* get_I420_MAT_VPLANE_2() const { return ___I420_MAT_VPLANE_2; }
	inline String_t** get_address_of_I420_MAT_VPLANE_2() { return &___I420_MAT_VPLANE_2; }
	inline void set_I420_MAT_VPLANE_2(String_t* value)
	{
		___I420_MAT_VPLANE_2 = value;
		Il2CppCodeGenWriteBarrier((&___I420_MAT_VPLANE_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNITYMEDIAHELPER_T909B65F549010A7353DC82E5AF7C0E259B42FC00_H
#ifndef VIDEODATA_T9C078487B97498970A01E98DEF8304B622527398_H
#define VIDEODATA_T9C078487B97498970A01E98DEF8304B622527398_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.ConferenceApp_VideoData
struct  VideoData_t9C078487B97498970A01E98DEF8304B622527398  : public RuntimeObject
{
public:
	// UnityEngine.GameObject Byn.Unity.Examples.ConferenceApp_VideoData::uiObject
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___uiObject_0;
	// UnityEngine.Texture2D Byn.Unity.Examples.ConferenceApp_VideoData::texture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___texture_1;
	// UnityEngine.UI.RawImage Byn.Unity.Examples.ConferenceApp_VideoData::image
	RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * ___image_2;

public:
	inline static int32_t get_offset_of_uiObject_0() { return static_cast<int32_t>(offsetof(VideoData_t9C078487B97498970A01E98DEF8304B622527398, ___uiObject_0)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_uiObject_0() const { return ___uiObject_0; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_uiObject_0() { return &___uiObject_0; }
	inline void set_uiObject_0(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___uiObject_0 = value;
		Il2CppCodeGenWriteBarrier((&___uiObject_0), value);
	}

	inline static int32_t get_offset_of_texture_1() { return static_cast<int32_t>(offsetof(VideoData_t9C078487B97498970A01E98DEF8304B622527398, ___texture_1)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_texture_1() const { return ___texture_1; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_texture_1() { return &___texture_1; }
	inline void set_texture_1(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___texture_1 = value;
		Il2CppCodeGenWriteBarrier((&___texture_1), value);
	}

	inline static int32_t get_offset_of_image_2() { return static_cast<int32_t>(offsetof(VideoData_t9C078487B97498970A01E98DEF8304B622527398, ___image_2)); }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * get_image_2() const { return ___image_2; }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 ** get_address_of_image_2() { return &___image_2; }
	inline void set_image_2(RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * value)
	{
		___image_2 = value;
		Il2CppCodeGenWriteBarrier((&___image_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEODATA_T9C078487B97498970A01E98DEF8304B622527398_H
#ifndef EXAMPLEGLOBALS_T56851F8D33D17DD137BD47D6F3F683BE900B236B_H
#define EXAMPLEGLOBALS_T56851F8D33D17DD137BD47D6F3F683BE900B236B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.ExampleGlobals
struct  ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B  : public RuntimeObject
{
public:

public:
};

struct ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields
{
public:
	// System.String Byn.Unity.Examples.ExampleGlobals::StunUrl
	String_t* ___StunUrl_0;
	// System.String Byn.Unity.Examples.ExampleGlobals::TurnUrl
	String_t* ___TurnUrl_1;
	// System.String Byn.Unity.Examples.ExampleGlobals::TurnUser
	String_t* ___TurnUser_2;
	// System.String Byn.Unity.Examples.ExampleGlobals::TurnPass
	String_t* ___TurnPass_3;
	// System.String Byn.Unity.Examples.ExampleGlobals::BackupStunUrl
	String_t* ___BackupStunUrl_4;

public:
	inline static int32_t get_offset_of_StunUrl_0() { return static_cast<int32_t>(offsetof(ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields, ___StunUrl_0)); }
	inline String_t* get_StunUrl_0() const { return ___StunUrl_0; }
	inline String_t** get_address_of_StunUrl_0() { return &___StunUrl_0; }
	inline void set_StunUrl_0(String_t* value)
	{
		___StunUrl_0 = value;
		Il2CppCodeGenWriteBarrier((&___StunUrl_0), value);
	}

	inline static int32_t get_offset_of_TurnUrl_1() { return static_cast<int32_t>(offsetof(ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields, ___TurnUrl_1)); }
	inline String_t* get_TurnUrl_1() const { return ___TurnUrl_1; }
	inline String_t** get_address_of_TurnUrl_1() { return &___TurnUrl_1; }
	inline void set_TurnUrl_1(String_t* value)
	{
		___TurnUrl_1 = value;
		Il2CppCodeGenWriteBarrier((&___TurnUrl_1), value);
	}

	inline static int32_t get_offset_of_TurnUser_2() { return static_cast<int32_t>(offsetof(ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields, ___TurnUser_2)); }
	inline String_t* get_TurnUser_2() const { return ___TurnUser_2; }
	inline String_t** get_address_of_TurnUser_2() { return &___TurnUser_2; }
	inline void set_TurnUser_2(String_t* value)
	{
		___TurnUser_2 = value;
		Il2CppCodeGenWriteBarrier((&___TurnUser_2), value);
	}

	inline static int32_t get_offset_of_TurnPass_3() { return static_cast<int32_t>(offsetof(ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields, ___TurnPass_3)); }
	inline String_t* get_TurnPass_3() const { return ___TurnPass_3; }
	inline String_t** get_address_of_TurnPass_3() { return &___TurnPass_3; }
	inline void set_TurnPass_3(String_t* value)
	{
		___TurnPass_3 = value;
		Il2CppCodeGenWriteBarrier((&___TurnPass_3), value);
	}

	inline static int32_t get_offset_of_BackupStunUrl_4() { return static_cast<int32_t>(offsetof(ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields, ___BackupStunUrl_4)); }
	inline String_t* get_BackupStunUrl_4() const { return ___BackupStunUrl_4; }
	inline String_t** get_address_of_BackupStunUrl_4() { return &___BackupStunUrl_4; }
	inline void set_BackupStunUrl_4(String_t* value)
	{
		___BackupStunUrl_4 = value;
		Il2CppCodeGenWriteBarrier((&___BackupStunUrl_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXAMPLEGLOBALS_T56851F8D33D17DD137BD47D6F3F683BE900B236B_H
#ifndef U3CREQUESTAUDIOPERMISSIONU3ED__17_TCBCB2E5936A36A838919E3777D2B4B3FD140600E_H
#define U3CREQUESTAUDIOPERMISSIONU3ED__17_TCBCB2E5936A36A838919E3777D2B4B3FD140600E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.ExampleGlobals_<RequestAudioPermission>d__17
struct  U3CRequestAudioPermissionU3Ed__17_tCBCB2E5936A36A838919E3777D2B4B3FD140600E  : public RuntimeObject
{
public:
	// System.Int32 Byn.Unity.Examples.ExampleGlobals_<RequestAudioPermission>d__17::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Byn.Unity.Examples.ExampleGlobals_<RequestAudioPermission>d__17::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CRequestAudioPermissionU3Ed__17_tCBCB2E5936A36A838919E3777D2B4B3FD140600E, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CRequestAudioPermissionU3Ed__17_tCBCB2E5936A36A838919E3777D2B4B3FD140600E, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CREQUESTAUDIOPERMISSIONU3ED__17_TCBCB2E5936A36A838919E3777D2B4B3FD140600E_H
#ifndef U3CREQUESTPERMISSIONSU3ED__19_T67EA9769316E4B44407430981C52658E479F9856_H
#define U3CREQUESTPERMISSIONSU3ED__19_T67EA9769316E4B44407430981C52658E479F9856_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.ExampleGlobals_<RequestPermissions>d__19
struct  U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856  : public RuntimeObject
{
public:
	// System.Int32 Byn.Unity.Examples.ExampleGlobals_<RequestPermissions>d__19::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Byn.Unity.Examples.ExampleGlobals_<RequestPermissions>d__19::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// System.Boolean Byn.Unity.Examples.ExampleGlobals_<RequestPermissions>d__19::audio
	bool ___audio_2;
	// System.Boolean Byn.Unity.Examples.ExampleGlobals_<RequestPermissions>d__19::video
	bool ___video_3;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}

	inline static int32_t get_offset_of_audio_2() { return static_cast<int32_t>(offsetof(U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856, ___audio_2)); }
	inline bool get_audio_2() const { return ___audio_2; }
	inline bool* get_address_of_audio_2() { return &___audio_2; }
	inline void set_audio_2(bool value)
	{
		___audio_2 = value;
	}

	inline static int32_t get_offset_of_video_3() { return static_cast<int32_t>(offsetof(U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856, ___video_3)); }
	inline bool get_video_3() const { return ___video_3; }
	inline bool* get_address_of_video_3() { return &___video_3; }
	inline void set_video_3(bool value)
	{
		___video_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CREQUESTPERMISSIONSU3ED__19_T67EA9769316E4B44407430981C52658E479F9856_H
#ifndef U3CREQUESTVIDEOPERMISSIONU3ED__18_T284CC5B8067172F41554DA77F7863C49E75F053E_H
#define U3CREQUESTVIDEOPERMISSIONU3ED__18_T284CC5B8067172F41554DA77F7863C49E75F053E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.ExampleGlobals_<RequestVideoPermission>d__18
struct  U3CRequestVideoPermissionU3Ed__18_t284CC5B8067172F41554DA77F7863C49E75F053E  : public RuntimeObject
{
public:
	// System.Int32 Byn.Unity.Examples.ExampleGlobals_<RequestVideoPermission>d__18::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Byn.Unity.Examples.ExampleGlobals_<RequestVideoPermission>d__18::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CRequestVideoPermissionU3Ed__18_t284CC5B8067172F41554DA77F7863C49E75F053E, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CRequestVideoPermissionU3Ed__18_t284CC5B8067172F41554DA77F7863C49E75F053E, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CREQUESTVIDEOPERMISSIONU3ED__18_T284CC5B8067172F41554DA77F7863C49E75F053E_H
#ifndef U3CSTARTU3ED__11_T55FDB25F620252AE5B728D0548DB05649BD4CAC8_H
#define U3CSTARTU3ED__11_T55FDB25F620252AE5B728D0548DB05649BD4CAC8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.OneToMany_<Start>d__11
struct  U3CStartU3Ed__11_t55FDB25F620252AE5B728D0548DB05649BD4CAC8  : public RuntimeObject
{
public:
	// System.Int32 Byn.Unity.Examples.OneToMany_<Start>d__11::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Byn.Unity.Examples.OneToMany_<Start>d__11::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// Byn.Unity.Examples.OneToMany Byn.Unity.Examples.OneToMany_<Start>d__11::<>4__this
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086 * ___U3CU3E4__this_2;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CStartU3Ed__11_t55FDB25F620252AE5B728D0548DB05649BD4CAC8, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CStartU3Ed__11_t55FDB25F620252AE5B728D0548DB05649BD4CAC8, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CStartU3Ed__11_t55FDB25F620252AE5B728D0548DB05649BD4CAC8, ___U3CU3E4__this_2)); }
	inline OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E4__this_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CSTARTU3ED__11_T55FDB25F620252AE5B728D0548DB05649BD4CAC8_H
#ifndef U3CCONFIGUREDELAYEDU3ED__9_T42904B407A0DCE5F3444308EB9C6E569B1031C68_H
#define U3CCONFIGUREDELAYEDU3ED__9_T42904B407A0DCE5F3444308EB9C6E569B1031C68_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.SimpleCall_<ConfigureDelayed>d__9
struct  U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68  : public RuntimeObject
{
public:
	// System.Int32 Byn.Unity.Examples.SimpleCall_<ConfigureDelayed>d__9::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Byn.Unity.Examples.SimpleCall_<ConfigureDelayed>d__9::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// System.Single Byn.Unity.Examples.SimpleCall_<ConfigureDelayed>d__9::startInSec
	float ___startInSec_2;
	// Byn.Unity.Examples.SimpleCall Byn.Unity.Examples.SimpleCall_<ConfigureDelayed>d__9::<>4__this
	SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD * ___U3CU3E4__this_3;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}

	inline static int32_t get_offset_of_startInSec_2() { return static_cast<int32_t>(offsetof(U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68, ___startInSec_2)); }
	inline float get_startInSec_2() const { return ___startInSec_2; }
	inline float* get_address_of_startInSec_2() { return &___startInSec_2; }
	inline void set_startInSec_2(float value)
	{
		___startInSec_2 = value;
	}

	inline static int32_t get_offset_of_U3CU3E4__this_3() { return static_cast<int32_t>(offsetof(U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68, ___U3CU3E4__this_3)); }
	inline SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD * get_U3CU3E4__this_3() const { return ___U3CU3E4__this_3; }
	inline SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD ** get_address_of_U3CU3E4__this_3() { return &___U3CU3E4__this_3; }
	inline void set_U3CU3E4__this_3(SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD * value)
	{
		___U3CU3E4__this_3 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E4__this_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CCONFIGUREDELAYEDU3ED__9_T42904B407A0DCE5F3444308EB9C6E569B1031C68_H
#ifndef U3CCOROUTINEREFRESHLATERU3ED__1_T9AF1BDEE238458547E50F4B52D8F01FDAC02D18E_H
#define U3CCOROUTINEREFRESHLATERU3ED__1_T9AF1BDEE238458547E50F4B52D8F01FDAC02D18E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.VideoInputApp_<CoroutineRefreshLater>d__1
struct  U3CCoroutineRefreshLaterU3Ed__1_t9AF1BDEE238458547E50F4B52D8F01FDAC02D18E  : public RuntimeObject
{
public:
	// System.Int32 Byn.Unity.Examples.VideoInputApp_<CoroutineRefreshLater>d__1::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Byn.Unity.Examples.VideoInputApp_<CoroutineRefreshLater>d__1::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// Byn.Unity.Examples.VideoInputApp Byn.Unity.Examples.VideoInputApp_<CoroutineRefreshLater>d__1::<>4__this
	VideoInputApp_tBD1B4BA06062C26F8519013F665376060F9FC2CF * ___U3CU3E4__this_2;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CCoroutineRefreshLaterU3Ed__1_t9AF1BDEE238458547E50F4B52D8F01FDAC02D18E, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CCoroutineRefreshLaterU3Ed__1_t9AF1BDEE238458547E50F4B52D8F01FDAC02D18E, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CCoroutineRefreshLaterU3Ed__1_t9AF1BDEE238458547E50F4B52D8F01FDAC02D18E, ___U3CU3E4__this_2)); }
	inline VideoInputApp_tBD1B4BA06062C26F8519013F665376060F9FC2CF * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline VideoInputApp_tBD1B4BA06062C26F8519013F665376060F9FC2CF ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(VideoInputApp_tBD1B4BA06062C26F8519013F665376060F9FC2CF * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E4__this_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CCOROUTINEREFRESHLATERU3ED__1_T9AF1BDEE238458547E50F4B52D8F01FDAC02D18E_H
#ifndef U3CCOROUTINEREJOINU3ED__37_TE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2_H
#define U3CCOROUTINEREJOINU3ED__37_TE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// CallApp_<CoroutineRejoin>d__37
struct  U3CCoroutineRejoinU3Ed__37_tE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2  : public RuntimeObject
{
public:
	// System.Int32 CallApp_<CoroutineRejoin>d__37::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object CallApp_<CoroutineRejoin>d__37::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// CallApp CallApp_<CoroutineRejoin>d__37::<>4__this
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43 * ___U3CU3E4__this_2;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CCoroutineRejoinU3Ed__37_tE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CCoroutineRejoinU3Ed__37_tE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CCoroutineRejoinU3Ed__37_tE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2, ___U3CU3E4__this_2)); }
	inline CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E4__this_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CCOROUTINEREJOINU3ED__37_TE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2_H
#ifndef U3CREQUESTAUDIOPERMISSIONSU3ED__74_TC2964A0B16259642A4238D66EEBFA7C88E47DE18_H
#define U3CREQUESTAUDIOPERMISSIONSU3ED__74_TC2964A0B16259642A4238D66EEBFA7C88E47DE18_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// CallAppUi_<RequestAudioPermissions>d__74
struct  U3CRequestAudioPermissionsU3Ed__74_tC2964A0B16259642A4238D66EEBFA7C88E47DE18  : public RuntimeObject
{
public:
	// System.Int32 CallAppUi_<RequestAudioPermissions>d__74::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object CallAppUi_<RequestAudioPermissions>d__74::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// CallAppUi CallAppUi_<RequestAudioPermissions>d__74::<>4__this
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * ___U3CU3E4__this_2;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CRequestAudioPermissionsU3Ed__74_tC2964A0B16259642A4238D66EEBFA7C88E47DE18, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CRequestAudioPermissionsU3Ed__74_tC2964A0B16259642A4238D66EEBFA7C88E47DE18, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CRequestAudioPermissionsU3Ed__74_tC2964A0B16259642A4238D66EEBFA7C88E47DE18, ___U3CU3E4__this_2)); }
	inline CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E4__this_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CREQUESTAUDIOPERMISSIONSU3ED__74_TC2964A0B16259642A4238D66EEBFA7C88E47DE18_H
#ifndef U3CREQUESTVIDEOPERMISSIONSU3ED__75_T4DF1B5D81BE5CEEFBA0517D525BF46D27F21446F_H
#define U3CREQUESTVIDEOPERMISSIONSU3ED__75_T4DF1B5D81BE5CEEFBA0517D525BF46D27F21446F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// CallAppUi_<RequestVideoPermissions>d__75
struct  U3CRequestVideoPermissionsU3Ed__75_t4DF1B5D81BE5CEEFBA0517D525BF46D27F21446F  : public RuntimeObject
{
public:
	// System.Int32 CallAppUi_<RequestVideoPermissions>d__75::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object CallAppUi_<RequestVideoPermissions>d__75::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// CallAppUi CallAppUi_<RequestVideoPermissions>d__75::<>4__this
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * ___U3CU3E4__this_2;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CRequestVideoPermissionsU3Ed__75_t4DF1B5D81BE5CEEFBA0517D525BF46D27F21446F, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CRequestVideoPermissionsU3Ed__75_t4DF1B5D81BE5CEEFBA0517D525BF46D27F21446F, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CRequestVideoPermissionsU3Ed__75_t4DF1B5D81BE5CEEFBA0517D525BF46D27F21446F, ___U3CU3E4__this_2)); }
	inline CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E4__this_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CREQUESTVIDEOPERMISSIONSU3ED__75_T4DF1B5D81BE5CEEFBA0517D525BF46D27F21446F_H
#ifndef VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#define VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_com
{
};
#endif // VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#ifndef VERTEXHELPEREXTENSION_T593AF80A941B7208D2CC88AE671873CE6E2AA8E3_H
#define VERTEXHELPEREXTENSION_T593AF80A941B7208D2CC88AE671873CE6E2AA8E3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.UI.VertexHelperExtension
struct  VertexHelperExtension_t593AF80A941B7208D2CC88AE671873CE6E2AA8E3  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VERTEXHELPEREXTENSION_T593AF80A941B7208D2CC88AE671873CE6E2AA8E3_H
#ifndef BASEVERTEXEFFECT_T1EF95AB1FC33A027710E7DC86D19F700156C4F6A_H
#define BASEVERTEXEFFECT_T1EF95AB1FC33A027710E7DC86D19F700156C4F6A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.BaseVertexEffect
struct  BaseVertexEffect_t1EF95AB1FC33A027710E7DC86D19F700156C4F6A  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BASEVERTEXEFFECT_T1EF95AB1FC33A027710E7DC86D19F700156C4F6A_H
#ifndef U3CDELAYEDSETDIRTYU3EC__ITERATOR0_TB8BB61C2C033D95240B4E2704971663E4DC08073_H
#define U3CDELAYEDSETDIRTYU3EC__ITERATOR0_TB8BB61C2C033D95240B4E2704971663E4DC08073_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.LayoutGroup_<DelayedSetDirty>c__Iterator0
struct  U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073  : public RuntimeObject
{
public:
	// UnityEngine.RectTransform UnityEngine.UI.LayoutGroup_<DelayedSetDirty>c__Iterator0::rectTransform
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___rectTransform_0;
	// System.Object UnityEngine.UI.LayoutGroup_<DelayedSetDirty>c__Iterator0::U24current
	RuntimeObject * ___U24current_1;
	// System.Boolean UnityEngine.UI.LayoutGroup_<DelayedSetDirty>c__Iterator0::U24disposing
	bool ___U24disposing_2;
	// System.Int32 UnityEngine.UI.LayoutGroup_<DelayedSetDirty>c__Iterator0::U24PC
	int32_t ___U24PC_3;

public:
	inline static int32_t get_offset_of_rectTransform_0() { return static_cast<int32_t>(offsetof(U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073, ___rectTransform_0)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_rectTransform_0() const { return ___rectTransform_0; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_rectTransform_0() { return &___rectTransform_0; }
	inline void set_rectTransform_0(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___rectTransform_0 = value;
		Il2CppCodeGenWriteBarrier((&___rectTransform_0), value);
	}

	inline static int32_t get_offset_of_U24current_1() { return static_cast<int32_t>(offsetof(U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073, ___U24current_1)); }
	inline RuntimeObject * get_U24current_1() const { return ___U24current_1; }
	inline RuntimeObject ** get_address_of_U24current_1() { return &___U24current_1; }
	inline void set_U24current_1(RuntimeObject * value)
	{
		___U24current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_1), value);
	}

	inline static int32_t get_offset_of_U24disposing_2() { return static_cast<int32_t>(offsetof(U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073, ___U24disposing_2)); }
	inline bool get_U24disposing_2() const { return ___U24disposing_2; }
	inline bool* get_address_of_U24disposing_2() { return &___U24disposing_2; }
	inline void set_U24disposing_2(bool value)
	{
		___U24disposing_2 = value;
	}

	inline static int32_t get_offset_of_U24PC_3() { return static_cast<int32_t>(offsetof(U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073, ___U24PC_3)); }
	inline int32_t get_U24PC_3() const { return ___U24PC_3; }
	inline int32_t* get_address_of_U24PC_3() { return &___U24PC_3; }
	inline void set_U24PC_3(int32_t value)
	{
		___U24PC_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CDELAYEDSETDIRTYU3EC__ITERATOR0_TB8BB61C2C033D95240B4E2704971663E4DC08073_H
#ifndef LAYOUTREBUILDER_T8D3501B43B1DE666140E2931FFA732B5B09EA5BD_H
#define LAYOUTREBUILDER_T8D3501B43B1DE666140E2931FFA732B5B09EA5BD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.LayoutRebuilder
struct  LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD  : public RuntimeObject
{
public:
	// UnityEngine.RectTransform UnityEngine.UI.LayoutRebuilder::m_ToRebuild
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___m_ToRebuild_0;
	// System.Int32 UnityEngine.UI.LayoutRebuilder::m_CachedHashFromTransform
	int32_t ___m_CachedHashFromTransform_1;

public:
	inline static int32_t get_offset_of_m_ToRebuild_0() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD, ___m_ToRebuild_0)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_m_ToRebuild_0() const { return ___m_ToRebuild_0; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_m_ToRebuild_0() { return &___m_ToRebuild_0; }
	inline void set_m_ToRebuild_0(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___m_ToRebuild_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_ToRebuild_0), value);
	}

	inline static int32_t get_offset_of_m_CachedHashFromTransform_1() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD, ___m_CachedHashFromTransform_1)); }
	inline int32_t get_m_CachedHashFromTransform_1() const { return ___m_CachedHashFromTransform_1; }
	inline int32_t* get_address_of_m_CachedHashFromTransform_1() { return &___m_CachedHashFromTransform_1; }
	inline void set_m_CachedHashFromTransform_1(int32_t value)
	{
		___m_CachedHashFromTransform_1 = value;
	}
};

struct LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields
{
public:
	// UnityEngine.UI.ObjectPool`1<UnityEngine.UI.LayoutRebuilder> UnityEngine.UI.LayoutRebuilder::s_Rebuilders
	ObjectPool_1_tFA4F33849836CDB27432AE22249BB79D68619541 * ___s_Rebuilders_2;
	// UnityEngine.RectTransform_ReapplyDrivenProperties UnityEngine.UI.LayoutRebuilder::<>f__mgU24cache0
	ReapplyDrivenProperties_t431F4FBD9C59AE097FE33C4354CC6251B01B527D * ___U3CU3Ef__mgU24cache0_3;
	// System.Predicate`1<UnityEngine.Component> UnityEngine.UI.LayoutRebuilder::<>f__amU24cache0
	Predicate_1_t1A9CE8ADB6E9328794CC409FD5BEAACA86D7D769 * ___U3CU3Ef__amU24cache0_4;
	// UnityEngine.Events.UnityAction`1<UnityEngine.Component> UnityEngine.UI.LayoutRebuilder::<>f__amU24cache1
	UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * ___U3CU3Ef__amU24cache1_5;
	// UnityEngine.Events.UnityAction`1<UnityEngine.Component> UnityEngine.UI.LayoutRebuilder::<>f__amU24cache2
	UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * ___U3CU3Ef__amU24cache2_6;
	// UnityEngine.Events.UnityAction`1<UnityEngine.Component> UnityEngine.UI.LayoutRebuilder::<>f__amU24cache3
	UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * ___U3CU3Ef__amU24cache3_7;
	// UnityEngine.Events.UnityAction`1<UnityEngine.Component> UnityEngine.UI.LayoutRebuilder::<>f__amU24cache4
	UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * ___U3CU3Ef__amU24cache4_8;

public:
	inline static int32_t get_offset_of_s_Rebuilders_2() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields, ___s_Rebuilders_2)); }
	inline ObjectPool_1_tFA4F33849836CDB27432AE22249BB79D68619541 * get_s_Rebuilders_2() const { return ___s_Rebuilders_2; }
	inline ObjectPool_1_tFA4F33849836CDB27432AE22249BB79D68619541 ** get_address_of_s_Rebuilders_2() { return &___s_Rebuilders_2; }
	inline void set_s_Rebuilders_2(ObjectPool_1_tFA4F33849836CDB27432AE22249BB79D68619541 * value)
	{
		___s_Rebuilders_2 = value;
		Il2CppCodeGenWriteBarrier((&___s_Rebuilders_2), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__mgU24cache0_3() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields, ___U3CU3Ef__mgU24cache0_3)); }
	inline ReapplyDrivenProperties_t431F4FBD9C59AE097FE33C4354CC6251B01B527D * get_U3CU3Ef__mgU24cache0_3() const { return ___U3CU3Ef__mgU24cache0_3; }
	inline ReapplyDrivenProperties_t431F4FBD9C59AE097FE33C4354CC6251B01B527D ** get_address_of_U3CU3Ef__mgU24cache0_3() { return &___U3CU3Ef__mgU24cache0_3; }
	inline void set_U3CU3Ef__mgU24cache0_3(ReapplyDrivenProperties_t431F4FBD9C59AE097FE33C4354CC6251B01B527D * value)
	{
		___U3CU3Ef__mgU24cache0_3 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__mgU24cache0_3), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache0_4() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields, ___U3CU3Ef__amU24cache0_4)); }
	inline Predicate_1_t1A9CE8ADB6E9328794CC409FD5BEAACA86D7D769 * get_U3CU3Ef__amU24cache0_4() const { return ___U3CU3Ef__amU24cache0_4; }
	inline Predicate_1_t1A9CE8ADB6E9328794CC409FD5BEAACA86D7D769 ** get_address_of_U3CU3Ef__amU24cache0_4() { return &___U3CU3Ef__amU24cache0_4; }
	inline void set_U3CU3Ef__amU24cache0_4(Predicate_1_t1A9CE8ADB6E9328794CC409FD5BEAACA86D7D769 * value)
	{
		___U3CU3Ef__amU24cache0_4 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache0_4), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache1_5() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields, ___U3CU3Ef__amU24cache1_5)); }
	inline UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * get_U3CU3Ef__amU24cache1_5() const { return ___U3CU3Ef__amU24cache1_5; }
	inline UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 ** get_address_of_U3CU3Ef__amU24cache1_5() { return &___U3CU3Ef__amU24cache1_5; }
	inline void set_U3CU3Ef__amU24cache1_5(UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * value)
	{
		___U3CU3Ef__amU24cache1_5 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache1_5), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache2_6() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields, ___U3CU3Ef__amU24cache2_6)); }
	inline UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * get_U3CU3Ef__amU24cache2_6() const { return ___U3CU3Ef__amU24cache2_6; }
	inline UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 ** get_address_of_U3CU3Ef__amU24cache2_6() { return &___U3CU3Ef__amU24cache2_6; }
	inline void set_U3CU3Ef__amU24cache2_6(UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * value)
	{
		___U3CU3Ef__amU24cache2_6 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache2_6), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache3_7() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields, ___U3CU3Ef__amU24cache3_7)); }
	inline UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * get_U3CU3Ef__amU24cache3_7() const { return ___U3CU3Ef__amU24cache3_7; }
	inline UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 ** get_address_of_U3CU3Ef__amU24cache3_7() { return &___U3CU3Ef__amU24cache3_7; }
	inline void set_U3CU3Ef__amU24cache3_7(UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * value)
	{
		___U3CU3Ef__amU24cache3_7 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache3_7), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache4_8() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields, ___U3CU3Ef__amU24cache4_8)); }
	inline UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * get_U3CU3Ef__amU24cache4_8() const { return ___U3CU3Ef__amU24cache4_8; }
	inline UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 ** get_address_of_U3CU3Ef__amU24cache4_8() { return &___U3CU3Ef__amU24cache4_8; }
	inline void set_U3CU3Ef__amU24cache4_8(UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * value)
	{
		___U3CU3Ef__amU24cache4_8 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache4_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LAYOUTREBUILDER_T8D3501B43B1DE666140E2931FFA732B5B09EA5BD_H
#ifndef LAYOUTUTILITY_T3B5074E34900DA384884FC50809EA395CB69E7D5_H
#define LAYOUTUTILITY_T3B5074E34900DA384884FC50809EA395CB69E7D5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.LayoutUtility
struct  LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5  : public RuntimeObject
{
public:

public:
};

struct LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields
{
public:
	// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single> UnityEngine.UI.LayoutUtility::<>f__amU24cache0
	Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * ___U3CU3Ef__amU24cache0_0;
	// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single> UnityEngine.UI.LayoutUtility::<>f__amU24cache1
	Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * ___U3CU3Ef__amU24cache1_1;
	// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single> UnityEngine.UI.LayoutUtility::<>f__amU24cache2
	Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * ___U3CU3Ef__amU24cache2_2;
	// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single> UnityEngine.UI.LayoutUtility::<>f__amU24cache3
	Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * ___U3CU3Ef__amU24cache3_3;
	// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single> UnityEngine.UI.LayoutUtility::<>f__amU24cache4
	Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * ___U3CU3Ef__amU24cache4_4;
	// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single> UnityEngine.UI.LayoutUtility::<>f__amU24cache5
	Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * ___U3CU3Ef__amU24cache5_5;
	// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single> UnityEngine.UI.LayoutUtility::<>f__amU24cache6
	Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * ___U3CU3Ef__amU24cache6_6;
	// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single> UnityEngine.UI.LayoutUtility::<>f__amU24cache7
	Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * ___U3CU3Ef__amU24cache7_7;

public:
	inline static int32_t get_offset_of_U3CU3Ef__amU24cache0_0() { return static_cast<int32_t>(offsetof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields, ___U3CU3Ef__amU24cache0_0)); }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * get_U3CU3Ef__amU24cache0_0() const { return ___U3CU3Ef__amU24cache0_0; }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 ** get_address_of_U3CU3Ef__amU24cache0_0() { return &___U3CU3Ef__amU24cache0_0; }
	inline void set_U3CU3Ef__amU24cache0_0(Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * value)
	{
		___U3CU3Ef__amU24cache0_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache0_0), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache1_1() { return static_cast<int32_t>(offsetof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields, ___U3CU3Ef__amU24cache1_1)); }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * get_U3CU3Ef__amU24cache1_1() const { return ___U3CU3Ef__amU24cache1_1; }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 ** get_address_of_U3CU3Ef__amU24cache1_1() { return &___U3CU3Ef__amU24cache1_1; }
	inline void set_U3CU3Ef__amU24cache1_1(Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * value)
	{
		___U3CU3Ef__amU24cache1_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache1_1), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache2_2() { return static_cast<int32_t>(offsetof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields, ___U3CU3Ef__amU24cache2_2)); }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * get_U3CU3Ef__amU24cache2_2() const { return ___U3CU3Ef__amU24cache2_2; }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 ** get_address_of_U3CU3Ef__amU24cache2_2() { return &___U3CU3Ef__amU24cache2_2; }
	inline void set_U3CU3Ef__amU24cache2_2(Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * value)
	{
		___U3CU3Ef__amU24cache2_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache2_2), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache3_3() { return static_cast<int32_t>(offsetof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields, ___U3CU3Ef__amU24cache3_3)); }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * get_U3CU3Ef__amU24cache3_3() const { return ___U3CU3Ef__amU24cache3_3; }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 ** get_address_of_U3CU3Ef__amU24cache3_3() { return &___U3CU3Ef__amU24cache3_3; }
	inline void set_U3CU3Ef__amU24cache3_3(Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * value)
	{
		___U3CU3Ef__amU24cache3_3 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache3_3), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache4_4() { return static_cast<int32_t>(offsetof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields, ___U3CU3Ef__amU24cache4_4)); }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * get_U3CU3Ef__amU24cache4_4() const { return ___U3CU3Ef__amU24cache4_4; }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 ** get_address_of_U3CU3Ef__amU24cache4_4() { return &___U3CU3Ef__amU24cache4_4; }
	inline void set_U3CU3Ef__amU24cache4_4(Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * value)
	{
		___U3CU3Ef__amU24cache4_4 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache4_4), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache5_5() { return static_cast<int32_t>(offsetof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields, ___U3CU3Ef__amU24cache5_5)); }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * get_U3CU3Ef__amU24cache5_5() const { return ___U3CU3Ef__amU24cache5_5; }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 ** get_address_of_U3CU3Ef__amU24cache5_5() { return &___U3CU3Ef__amU24cache5_5; }
	inline void set_U3CU3Ef__amU24cache5_5(Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * value)
	{
		___U3CU3Ef__amU24cache5_5 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache5_5), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache6_6() { return static_cast<int32_t>(offsetof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields, ___U3CU3Ef__amU24cache6_6)); }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * get_U3CU3Ef__amU24cache6_6() const { return ___U3CU3Ef__amU24cache6_6; }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 ** get_address_of_U3CU3Ef__amU24cache6_6() { return &___U3CU3Ef__amU24cache6_6; }
	inline void set_U3CU3Ef__amU24cache6_6(Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * value)
	{
		___U3CU3Ef__amU24cache6_6 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache6_6), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache7_7() { return static_cast<int32_t>(offsetof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields, ___U3CU3Ef__amU24cache7_7)); }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * get_U3CU3Ef__amU24cache7_7() const { return ___U3CU3Ef__amU24cache7_7; }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 ** get_address_of_U3CU3Ef__amU24cache7_7() { return &___U3CU3Ef__amU24cache7_7; }
	inline void set_U3CU3Ef__amU24cache7_7(Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * value)
	{
		___U3CU3Ef__amU24cache7_7 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache7_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LAYOUTUTILITY_T3B5074E34900DA384884FC50809EA395CB69E7D5_H
#ifndef REFLECTIONMETHODSCACHE_TBDADDC80D50C5F10BD00965217980B9A8D24BE8A_H
#define REFLECTIONMETHODSCACHE_TBDADDC80D50C5F10BD00965217980B9A8D24BE8A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.ReflectionMethodsCache
struct  ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A  : public RuntimeObject
{
public:
	// UnityEngine.UI.ReflectionMethodsCache_Raycast3DCallback UnityEngine.UI.ReflectionMethodsCache::raycast3D
	Raycast3DCallback_t83483916473C9710AEDB316A65CBE62C58935C5F * ___raycast3D_0;
	// UnityEngine.UI.ReflectionMethodsCache_RaycastAllCallback UnityEngine.UI.ReflectionMethodsCache::raycast3DAll
	RaycastAllCallback_t751407A44270E02FAA43D0846A58EE6A8C4AE1CE * ___raycast3DAll_1;
	// UnityEngine.UI.ReflectionMethodsCache_Raycast2DCallback UnityEngine.UI.ReflectionMethodsCache::raycast2D
	Raycast2DCallback_tE99ABF9ABC3A380677949E8C05A3E477889B82BE * ___raycast2D_2;
	// UnityEngine.UI.ReflectionMethodsCache_GetRayIntersectionAllCallback UnityEngine.UI.ReflectionMethodsCache::getRayIntersectionAll
	GetRayIntersectionAllCallback_t68C2581CCF05E868297EBD3F3361274954845095 * ___getRayIntersectionAll_3;
	// UnityEngine.UI.ReflectionMethodsCache_GetRayIntersectionAllNonAllocCallback UnityEngine.UI.ReflectionMethodsCache::getRayIntersectionAllNonAlloc
	GetRayIntersectionAllNonAllocCallback_tAD7508D45DB6679B6394983579AD18D967CC2AD4 * ___getRayIntersectionAllNonAlloc_4;
	// UnityEngine.UI.ReflectionMethodsCache_GetRaycastNonAllocCallback UnityEngine.UI.ReflectionMethodsCache::getRaycastNonAlloc
	GetRaycastNonAllocCallback_tC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D * ___getRaycastNonAlloc_5;

public:
	inline static int32_t get_offset_of_raycast3D_0() { return static_cast<int32_t>(offsetof(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A, ___raycast3D_0)); }
	inline Raycast3DCallback_t83483916473C9710AEDB316A65CBE62C58935C5F * get_raycast3D_0() const { return ___raycast3D_0; }
	inline Raycast3DCallback_t83483916473C9710AEDB316A65CBE62C58935C5F ** get_address_of_raycast3D_0() { return &___raycast3D_0; }
	inline void set_raycast3D_0(Raycast3DCallback_t83483916473C9710AEDB316A65CBE62C58935C5F * value)
	{
		___raycast3D_0 = value;
		Il2CppCodeGenWriteBarrier((&___raycast3D_0), value);
	}

	inline static int32_t get_offset_of_raycast3DAll_1() { return static_cast<int32_t>(offsetof(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A, ___raycast3DAll_1)); }
	inline RaycastAllCallback_t751407A44270E02FAA43D0846A58EE6A8C4AE1CE * get_raycast3DAll_1() const { return ___raycast3DAll_1; }
	inline RaycastAllCallback_t751407A44270E02FAA43D0846A58EE6A8C4AE1CE ** get_address_of_raycast3DAll_1() { return &___raycast3DAll_1; }
	inline void set_raycast3DAll_1(RaycastAllCallback_t751407A44270E02FAA43D0846A58EE6A8C4AE1CE * value)
	{
		___raycast3DAll_1 = value;
		Il2CppCodeGenWriteBarrier((&___raycast3DAll_1), value);
	}

	inline static int32_t get_offset_of_raycast2D_2() { return static_cast<int32_t>(offsetof(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A, ___raycast2D_2)); }
	inline Raycast2DCallback_tE99ABF9ABC3A380677949E8C05A3E477889B82BE * get_raycast2D_2() const { return ___raycast2D_2; }
	inline Raycast2DCallback_tE99ABF9ABC3A380677949E8C05A3E477889B82BE ** get_address_of_raycast2D_2() { return &___raycast2D_2; }
	inline void set_raycast2D_2(Raycast2DCallback_tE99ABF9ABC3A380677949E8C05A3E477889B82BE * value)
	{
		___raycast2D_2 = value;
		Il2CppCodeGenWriteBarrier((&___raycast2D_2), value);
	}

	inline static int32_t get_offset_of_getRayIntersectionAll_3() { return static_cast<int32_t>(offsetof(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A, ___getRayIntersectionAll_3)); }
	inline GetRayIntersectionAllCallback_t68C2581CCF05E868297EBD3F3361274954845095 * get_getRayIntersectionAll_3() const { return ___getRayIntersectionAll_3; }
	inline GetRayIntersectionAllCallback_t68C2581CCF05E868297EBD3F3361274954845095 ** get_address_of_getRayIntersectionAll_3() { return &___getRayIntersectionAll_3; }
	inline void set_getRayIntersectionAll_3(GetRayIntersectionAllCallback_t68C2581CCF05E868297EBD3F3361274954845095 * value)
	{
		___getRayIntersectionAll_3 = value;
		Il2CppCodeGenWriteBarrier((&___getRayIntersectionAll_3), value);
	}

	inline static int32_t get_offset_of_getRayIntersectionAllNonAlloc_4() { return static_cast<int32_t>(offsetof(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A, ___getRayIntersectionAllNonAlloc_4)); }
	inline GetRayIntersectionAllNonAllocCallback_tAD7508D45DB6679B6394983579AD18D967CC2AD4 * get_getRayIntersectionAllNonAlloc_4() const { return ___getRayIntersectionAllNonAlloc_4; }
	inline GetRayIntersectionAllNonAllocCallback_tAD7508D45DB6679B6394983579AD18D967CC2AD4 ** get_address_of_getRayIntersectionAllNonAlloc_4() { return &___getRayIntersectionAllNonAlloc_4; }
	inline void set_getRayIntersectionAllNonAlloc_4(GetRayIntersectionAllNonAllocCallback_tAD7508D45DB6679B6394983579AD18D967CC2AD4 * value)
	{
		___getRayIntersectionAllNonAlloc_4 = value;
		Il2CppCodeGenWriteBarrier((&___getRayIntersectionAllNonAlloc_4), value);
	}

	inline static int32_t get_offset_of_getRaycastNonAlloc_5() { return static_cast<int32_t>(offsetof(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A, ___getRaycastNonAlloc_5)); }
	inline GetRaycastNonAllocCallback_tC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D * get_getRaycastNonAlloc_5() const { return ___getRaycastNonAlloc_5; }
	inline GetRaycastNonAllocCallback_tC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D ** get_address_of_getRaycastNonAlloc_5() { return &___getRaycastNonAlloc_5; }
	inline void set_getRaycastNonAlloc_5(GetRaycastNonAllocCallback_tC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D * value)
	{
		___getRaycastNonAlloc_5 = value;
		Il2CppCodeGenWriteBarrier((&___getRaycastNonAlloc_5), value);
	}
};

struct ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A_StaticFields
{
public:
	// UnityEngine.UI.ReflectionMethodsCache UnityEngine.UI.ReflectionMethodsCache::s_ReflectionMethodsCache
	ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A * ___s_ReflectionMethodsCache_6;

public:
	inline static int32_t get_offset_of_s_ReflectionMethodsCache_6() { return static_cast<int32_t>(offsetof(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A_StaticFields, ___s_ReflectionMethodsCache_6)); }
	inline ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A * get_s_ReflectionMethodsCache_6() const { return ___s_ReflectionMethodsCache_6; }
	inline ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A ** get_address_of_s_ReflectionMethodsCache_6() { return &___s_ReflectionMethodsCache_6; }
	inline void set_s_ReflectionMethodsCache_6(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A * value)
	{
		___s_ReflectionMethodsCache_6 = value;
		Il2CppCodeGenWriteBarrier((&___s_ReflectionMethodsCache_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REFLECTIONMETHODSCACHE_TBDADDC80D50C5F10BD00965217980B9A8D24BE8A_H
#ifndef U24ARRAYTYPEU3D12_T25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199_H
#define U24ARRAYTYPEU3D12_T25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU3D12
#pragma pack(push, tp, 1)
struct  U24ArrayTypeU3D12_t25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199 
{
public:
	union
	{
		struct
		{
		};
		uint8_t U24ArrayTypeU3D12_t25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199__padding[12];
	};

public:
};
#pragma pack(pop, tp)

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU3D12_T25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199_H
#ifndef CONNECTIONID_T47DBB761AF0DB1559EACE774B317DA2B8B67F66D_H
#define CONNECTIONID_T47DBB761AF0DB1559EACE774B317DA2B8B67F66D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.ConnectionId
struct  ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D 
{
public:
	// System.Int16 Byn.Awrtc.ConnectionId::id
	int16_t ___id_1;

public:
	inline static int32_t get_offset_of_id_1() { return static_cast<int32_t>(offsetof(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D, ___id_1)); }
	inline int16_t get_id_1() const { return ___id_1; }
	inline int16_t* get_address_of_id_1() { return &___id_1; }
	inline void set_id_1(int16_t value)
	{
		___id_1 = value;
	}
};

struct ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields
{
public:
	// Byn.Awrtc.ConnectionId Byn.Awrtc.ConnectionId::INVALID
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___INVALID_0;

public:
	inline static int32_t get_offset_of_INVALID_0() { return static_cast<int32_t>(offsetof(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields, ___INVALID_0)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_INVALID_0() const { return ___INVALID_0; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_INVALID_0() { return &___INVALID_0; }
	inline void set_INVALID_0(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___INVALID_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONNECTIONID_T47DBB761AF0DB1559EACE774B317DA2B8B67F66D_H
#ifndef ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#define ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t2AF27C02B8653AE29442467390005ABC74D8F521  : public ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF
{
public:

public:
};

struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((&___enumSeperatorCharArray_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_com
{
};
#endif // ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#ifndef INT32_T585191389E07734F19F3156FF88FB3EF4800D102_H
#define INT32_T585191389E07734F19F3156FF88FB3EF4800D102_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Int32
struct  Int32_t585191389E07734F19F3156FF88FB3EF4800D102 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int32_t585191389E07734F19F3156FF88FB3EF4800D102, ___m_value_0)); }
	inline int32_t get_m_value_0() const { return ___m_value_0; }
	inline int32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int32_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INT32_T585191389E07734F19F3156FF88FB3EF4800D102_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef SINGLE_TDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1_H
#define SINGLE_TDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Single
struct  Single_tDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1 
{
public:
	// System.Single System.Single::m_value
	float ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Single_tDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1, ___m_value_0)); }
	inline float get_m_value_0() const { return ___m_value_0; }
	inline float* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(float value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SINGLE_TDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1_H
#ifndef COLOR_T119BCA590009762C7223FDD3AF9706653AC84ED2_H
#define COLOR_T119BCA590009762C7223FDD3AF9706653AC84ED2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Color
struct  Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 
{
public:
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;

public:
	inline static int32_t get_offset_of_r_0() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___r_0)); }
	inline float get_r_0() const { return ___r_0; }
	inline float* get_address_of_r_0() { return &___r_0; }
	inline void set_r_0(float value)
	{
		___r_0 = value;
	}

	inline static int32_t get_offset_of_g_1() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___g_1)); }
	inline float get_g_1() const { return ___g_1; }
	inline float* get_address_of_g_1() { return &___g_1; }
	inline void set_g_1(float value)
	{
		___g_1 = value;
	}

	inline static int32_t get_offset_of_b_2() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___b_2)); }
	inline float get_b_2() const { return ___b_2; }
	inline float* get_address_of_b_2() { return &___b_2; }
	inline void set_b_2(float value)
	{
		___b_2 = value;
	}

	inline static int32_t get_offset_of_a_3() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___a_3)); }
	inline float get_a_3() const { return ___a_3; }
	inline float* get_address_of_a_3() { return &___a_3; }
	inline void set_a_3(float value)
	{
		___a_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLOR_T119BCA590009762C7223FDD3AF9706653AC84ED2_H
#ifndef DRIVENRECTTRANSFORMTRACKER_TB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03_H
#define DRIVENRECTTRANSFORMTRACKER_TB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.DrivenRectTransformTracker
struct  DrivenRectTransformTracker_tB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03 
{
public:
	union
	{
		struct
		{
		};
		uint8_t DrivenRectTransformTracker_tB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03__padding[1];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DRIVENRECTTRANSFORMTRACKER_TB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03_H
#ifndef VECTOR2_TA85D2DD88578276CA8A8796756458277E72D073D_H
#define VECTOR2_TA85D2DD88578276CA8A8796756458277E72D073D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector2
struct  Vector2_tA85D2DD88578276CA8A8796756458277E72D073D 
{
public:
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}
};

struct Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields
{
public:
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___negativeInfinityVector_9;

public:
	inline static int32_t get_offset_of_zeroVector_2() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___zeroVector_2)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_zeroVector_2() const { return ___zeroVector_2; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_zeroVector_2() { return &___zeroVector_2; }
	inline void set_zeroVector_2(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___zeroVector_2 = value;
	}

	inline static int32_t get_offset_of_oneVector_3() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___oneVector_3)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_oneVector_3() const { return ___oneVector_3; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_oneVector_3() { return &___oneVector_3; }
	inline void set_oneVector_3(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___oneVector_3 = value;
	}

	inline static int32_t get_offset_of_upVector_4() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___upVector_4)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_upVector_4() const { return ___upVector_4; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_upVector_4() { return &___upVector_4; }
	inline void set_upVector_4(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___upVector_4 = value;
	}

	inline static int32_t get_offset_of_downVector_5() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___downVector_5)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_downVector_5() const { return ___downVector_5; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_downVector_5() { return &___downVector_5; }
	inline void set_downVector_5(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___downVector_5 = value;
	}

	inline static int32_t get_offset_of_leftVector_6() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___leftVector_6)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_leftVector_6() const { return ___leftVector_6; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_leftVector_6() { return &___leftVector_6; }
	inline void set_leftVector_6(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___leftVector_6 = value;
	}

	inline static int32_t get_offset_of_rightVector_7() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___rightVector_7)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_rightVector_7() const { return ___rightVector_7; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_rightVector_7() { return &___rightVector_7; }
	inline void set_rightVector_7(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___rightVector_7 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___positiveInfinityVector_8)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_positiveInfinityVector_8() const { return ___positiveInfinityVector_8; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_positiveInfinityVector_8() { return &___positiveInfinityVector_8; }
	inline void set_positiveInfinityVector_8(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___positiveInfinityVector_8 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_9() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___negativeInfinityVector_9)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_negativeInfinityVector_9() const { return ___negativeInfinityVector_9; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_negativeInfinityVector_9() { return &___negativeInfinityVector_9; }
	inline void set_negativeInfinityVector_9(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___negativeInfinityVector_9 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR2_TA85D2DD88578276CA8A8796756458277E72D073D_H
#ifndef VECTOR3_TDCF05E21F632FE2BA260C06E0D10CA81513E6720_H
#define VECTOR3_TDCF05E21F632FE2BA260C06E0D10CA81513E6720_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector3
struct  Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 
{
public:
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;

public:
	inline static int32_t get_offset_of_x_2() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___x_2)); }
	inline float get_x_2() const { return ___x_2; }
	inline float* get_address_of_x_2() { return &___x_2; }
	inline void set_x_2(float value)
	{
		___x_2 = value;
	}

	inline static int32_t get_offset_of_y_3() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___y_3)); }
	inline float get_y_3() const { return ___y_3; }
	inline float* get_address_of_y_3() { return &___y_3; }
	inline void set_y_3(float value)
	{
		___y_3 = value;
	}

	inline static int32_t get_offset_of_z_4() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___z_4)); }
	inline float get_z_4() const { return ___z_4; }
	inline float* get_address_of_z_4() { return &___z_4; }
	inline void set_z_4(float value)
	{
		___z_4 = value;
	}
};

struct Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields
{
public:
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___negativeInfinityVector_14;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___zeroVector_5)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___oneVector_6)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_upVector_7() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___upVector_7)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_upVector_7() const { return ___upVector_7; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_upVector_7() { return &___upVector_7; }
	inline void set_upVector_7(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___upVector_7 = value;
	}

	inline static int32_t get_offset_of_downVector_8() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___downVector_8)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_downVector_8() const { return ___downVector_8; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_downVector_8() { return &___downVector_8; }
	inline void set_downVector_8(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___downVector_8 = value;
	}

	inline static int32_t get_offset_of_leftVector_9() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___leftVector_9)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_leftVector_9() const { return ___leftVector_9; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_leftVector_9() { return &___leftVector_9; }
	inline void set_leftVector_9(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___leftVector_9 = value;
	}

	inline static int32_t get_offset_of_rightVector_10() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___rightVector_10)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_rightVector_10() const { return ___rightVector_10; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_rightVector_10() { return &___rightVector_10; }
	inline void set_rightVector_10(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___rightVector_10 = value;
	}

	inline static int32_t get_offset_of_forwardVector_11() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___forwardVector_11)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_forwardVector_11() const { return ___forwardVector_11; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_forwardVector_11() { return &___forwardVector_11; }
	inline void set_forwardVector_11(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___forwardVector_11 = value;
	}

	inline static int32_t get_offset_of_backVector_12() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___backVector_12)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_backVector_12() const { return ___backVector_12; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_backVector_12() { return &___backVector_12; }
	inline void set_backVector_12(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___backVector_12 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_13() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___positiveInfinityVector_13)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_positiveInfinityVector_13() const { return ___positiveInfinityVector_13; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_positiveInfinityVector_13() { return &___positiveInfinityVector_13; }
	inline void set_positiveInfinityVector_13(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___positiveInfinityVector_13 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_14() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___negativeInfinityVector_14)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_negativeInfinityVector_14() const { return ___negativeInfinityVector_14; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_negativeInfinityVector_14() { return &___negativeInfinityVector_14; }
	inline void set_negativeInfinityVector_14(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___negativeInfinityVector_14 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR3_TDCF05E21F632FE2BA260C06E0D10CA81513E6720_H
#ifndef VECTOR4_TD148D6428C3F8FF6CD998F82090113C2B490B76E_H
#define VECTOR4_TD148D6428C3F8FF6CD998F82090113C2B490B76E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector4
struct  Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E 
{
public:
	// System.Single UnityEngine.Vector4::x
	float ___x_1;
	// System.Single UnityEngine.Vector4::y
	float ___y_2;
	// System.Single UnityEngine.Vector4::z
	float ___z_3;
	// System.Single UnityEngine.Vector4::w
	float ___w_4;

public:
	inline static int32_t get_offset_of_x_1() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E, ___x_1)); }
	inline float get_x_1() const { return ___x_1; }
	inline float* get_address_of_x_1() { return &___x_1; }
	inline void set_x_1(float value)
	{
		___x_1 = value;
	}

	inline static int32_t get_offset_of_y_2() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E, ___y_2)); }
	inline float get_y_2() const { return ___y_2; }
	inline float* get_address_of_y_2() { return &___y_2; }
	inline void set_y_2(float value)
	{
		___y_2 = value;
	}

	inline static int32_t get_offset_of_z_3() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E, ___z_3)); }
	inline float get_z_3() const { return ___z_3; }
	inline float* get_address_of_z_3() { return &___z_3; }
	inline void set_z_3(float value)
	{
		___z_3 = value;
	}

	inline static int32_t get_offset_of_w_4() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E, ___w_4)); }
	inline float get_w_4() const { return ___w_4; }
	inline float* get_address_of_w_4() { return &___w_4; }
	inline void set_w_4(float value)
	{
		___w_4 = value;
	}
};

struct Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields
{
public:
	// UnityEngine.Vector4 UnityEngine.Vector4::zeroVector
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___zeroVector_5;
	// UnityEngine.Vector4 UnityEngine.Vector4::oneVector
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___oneVector_6;
	// UnityEngine.Vector4 UnityEngine.Vector4::positiveInfinityVector
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___positiveInfinityVector_7;
	// UnityEngine.Vector4 UnityEngine.Vector4::negativeInfinityVector
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___negativeInfinityVector_8;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields, ___zeroVector_5)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields, ___oneVector_6)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_7() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields, ___positiveInfinityVector_7)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_positiveInfinityVector_7() const { return ___positiveInfinityVector_7; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_positiveInfinityVector_7() { return &___positiveInfinityVector_7; }
	inline void set_positiveInfinityVector_7(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___positiveInfinityVector_7 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields, ___negativeInfinityVector_8)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_negativeInfinityVector_8() const { return ___negativeInfinityVector_8; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_negativeInfinityVector_8() { return &___negativeInfinityVector_8; }
	inline void set_negativeInfinityVector_8(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___negativeInfinityVector_8 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR4_TD148D6428C3F8FF6CD998F82090113C2B490B76E_H
#ifndef U3CPRIVATEIMPLEMENTATIONDETAILSU3E_TC8332394FBFEEB4B73459A35E182942340DA3537_H
#define U3CPRIVATEIMPLEMENTATIONDETAILSU3E_TC8332394FBFEEB4B73459A35E182942340DA3537_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>
struct  U3CPrivateImplementationDetailsU3E_tC8332394FBFEEB4B73459A35E182942340DA3537  : public RuntimeObject
{
public:

public:
};

struct U3CPrivateImplementationDetailsU3E_tC8332394FBFEEB4B73459A35E182942340DA3537_StaticFields
{
public:
	// <PrivateImplementationDetails>_U24ArrayTypeU3D12 <PrivateImplementationDetails>::U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46
	U24ArrayTypeU3D12_t25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199  ___U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0;

public:
	inline static int32_t get_offset_of_U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tC8332394FBFEEB4B73459A35E182942340DA3537_StaticFields, ___U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0)); }
	inline U24ArrayTypeU3D12_t25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199  get_U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0() const { return ___U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0; }
	inline U24ArrayTypeU3D12_t25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199 * get_address_of_U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0() { return &___U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0; }
	inline void set_U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0(U24ArrayTypeU3D12_t25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199  value)
	{
		___U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CPRIVATEIMPLEMENTATIONDETAILSU3E_TC8332394FBFEEB4B73459A35E182942340DA3537_H
#ifndef FRAMEPIXELFORMAT_TDCE4288D3AD386370E428FCC0668229B6994D9BB_H
#define FRAMEPIXELFORMAT_TDCE4288D3AD386370E428FCC0668229B6994D9BB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.FramePixelFormat
struct  FramePixelFormat_tDCE4288D3AD386370E428FCC0668229B6994D9BB 
{
public:
	// System.Int32 Byn.Awrtc.FramePixelFormat::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(FramePixelFormat_tDCE4288D3AD386370E428FCC0668229B6994D9BB, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FRAMEPIXELFORMAT_TDCE4288D3AD386370E428FCC0668229B6994D9BB_H
#ifndef INITSTATE_TF0A3A2CE215643EDF5BC6E278CE7E7578E38A18C_H
#define INITSTATE_TF0A3A2CE215643EDF5BC6E278CE7E7578E38A18C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityCallFactory_InitState
struct  InitState_tF0A3A2CE215643EDF5BC6E278CE7E7578E38A18C 
{
public:
	// System.Int32 Byn.Awrtc.Unity.UnityCallFactory_InitState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(InitState_tF0A3A2CE215643EDF5BC6E278CE7E7578E38A18C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INITSTATE_TF0A3A2CE215643EDF5BC6E278CE7E7578E38A18C_H
#ifndef INITSTATUSUPDATE_T9CB7C4BBAF73AE515E423C78CBDE4AB3C0ED96AF_H
#define INITSTATUSUPDATE_T9CB7C4BBAF73AE515E423C78CBDE4AB3C0ED96AF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityCallFactory_InitStatusUpdate
struct  InitStatusUpdate_t9CB7C4BBAF73AE515E423C78CBDE4AB3C0ED96AF 
{
public:
	// System.Int32 Byn.Awrtc.Unity.UnityCallFactory_InitStatusUpdate::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(InitStatusUpdate_t9CB7C4BBAF73AE515E423C78CBDE4AB3C0ED96AF, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INITSTATUSUPDATE_T9CB7C4BBAF73AE515E423C78CBDE4AB3C0ED96AF_H
#ifndef LOGLEVEL_TEBEAF97CA6FC143AAFFCBF123E970D39D79AE144_H
#define LOGLEVEL_TEBEAF97CA6FC143AAFFCBF123E970D39D79AE144_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityCallFactory_LogLevel
struct  LogLevel_tEBEAF97CA6FC143AAFFCBF123E970D39D79AE144 
{
public:
	// System.Int32 Byn.Awrtc.Unity.UnityCallFactory_LogLevel::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(LogLevel_tEBEAF97CA6FC143AAFFCBF123E970D39D79AE144, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOGLEVEL_TEBEAF97CA6FC143AAFFCBF123E970D39D79AE144_H
#ifndef SIMPLECALLSTATE_T57C23CDEB50ACA1A8FEE6905D5B0B3DBEBA5493A_H
#define SIMPLECALLSTATE_T57C23CDEB50ACA1A8FEE6905D5B0B3DBEBA5493A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.SimpleCall_SimpleCallState
struct  SimpleCallState_t57C23CDEB50ACA1A8FEE6905D5B0B3DBEBA5493A 
{
public:
	// System.Int32 Byn.Unity.Examples.SimpleCall_SimpleCallState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(SimpleCallState_t57C23CDEB50ACA1A8FEE6905D5B0B3DBEBA5493A, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SIMPLECALLSTATE_T57C23CDEB50ACA1A8FEE6905D5B0B3DBEBA5493A_H
#ifndef DELEGATE_T_H
#define DELEGATE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Delegate
struct  Delegate_t  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::extra_arg
	intptr_t ___extra_arg_5;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_6;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_7;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_8;
	// System.DelegateData System.Delegate::data
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	// System.Boolean System.Delegate::method_is_virtual
	bool ___method_is_virtual_10;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t, ___invoke_impl_1)); }
	inline intptr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline intptr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(intptr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_target_2), value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_3)); }
	inline intptr_t get_method_3() const { return ___method_3; }
	inline intptr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(intptr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t, ___delegate_trampoline_4)); }
	inline intptr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline intptr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(intptr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_extra_arg_5() { return static_cast<int32_t>(offsetof(Delegate_t, ___extra_arg_5)); }
	inline intptr_t get_extra_arg_5() const { return ___extra_arg_5; }
	inline intptr_t* get_address_of_extra_arg_5() { return &___extra_arg_5; }
	inline void set_extra_arg_5(intptr_t value)
	{
		___extra_arg_5 = value;
	}

	inline static int32_t get_offset_of_method_code_6() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_code_6)); }
	inline intptr_t get_method_code_6() const { return ___method_code_6; }
	inline intptr_t* get_address_of_method_code_6() { return &___method_code_6; }
	inline void set_method_code_6(intptr_t value)
	{
		___method_code_6 = value;
	}

	inline static int32_t get_offset_of_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_info_7)); }
	inline MethodInfo_t * get_method_info_7() const { return ___method_info_7; }
	inline MethodInfo_t ** get_address_of_method_info_7() { return &___method_info_7; }
	inline void set_method_info_7(MethodInfo_t * value)
	{
		___method_info_7 = value;
		Il2CppCodeGenWriteBarrier((&___method_info_7), value);
	}

	inline static int32_t get_offset_of_original_method_info_8() { return static_cast<int32_t>(offsetof(Delegate_t, ___original_method_info_8)); }
	inline MethodInfo_t * get_original_method_info_8() const { return ___original_method_info_8; }
	inline MethodInfo_t ** get_address_of_original_method_info_8() { return &___original_method_info_8; }
	inline void set_original_method_info_8(MethodInfo_t * value)
	{
		___original_method_info_8 = value;
		Il2CppCodeGenWriteBarrier((&___original_method_info_8), value);
	}

	inline static int32_t get_offset_of_data_9() { return static_cast<int32_t>(offsetof(Delegate_t, ___data_9)); }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * get_data_9() const { return ___data_9; }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE ** get_address_of_data_9() { return &___data_9; }
	inline void set_data_9(DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * value)
	{
		___data_9 = value;
		Il2CppCodeGenWriteBarrier((&___data_9), value);
	}

	inline static int32_t get_offset_of_method_is_virtual_10() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_is_virtual_10)); }
	inline bool get_method_is_virtual_10() const { return ___method_is_virtual_10; }
	inline bool* get_address_of_method_is_virtual_10() { return &___method_is_virtual_10; }
	inline void set_method_is_virtual_10(bool value)
	{
		___method_is_virtual_10 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Delegate
struct Delegate_t_marshaled_pinvoke
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};
// Native definition for COM marshalling of System.Delegate
struct Delegate_t_marshaled_com
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};
#endif // DELEGATE_T_H
#ifndef OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#define OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Object
struct  Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};
#endif // OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#ifndef RAY_TE2163D4CB3E6B267E29F8ABE41684490E4A614B2_H
#define RAY_TE2163D4CB3E6B267E29F8ABE41684490E4A614B2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Ray
struct  Ray_tE2163D4CB3E6B267E29F8ABE41684490E4A614B2 
{
public:
	// UnityEngine.Vector3 UnityEngine.Ray::m_Origin
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___m_Origin_0;
	// UnityEngine.Vector3 UnityEngine.Ray::m_Direction
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___m_Direction_1;

public:
	inline static int32_t get_offset_of_m_Origin_0() { return static_cast<int32_t>(offsetof(Ray_tE2163D4CB3E6B267E29F8ABE41684490E4A614B2, ___m_Origin_0)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_m_Origin_0() const { return ___m_Origin_0; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_m_Origin_0() { return &___m_Origin_0; }
	inline void set_m_Origin_0(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___m_Origin_0 = value;
	}

	inline static int32_t get_offset_of_m_Direction_1() { return static_cast<int32_t>(offsetof(Ray_tE2163D4CB3E6B267E29F8ABE41684490E4A614B2, ___m_Direction_1)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_m_Direction_1() const { return ___m_Direction_1; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_m_Direction_1() { return &___m_Direction_1; }
	inline void set_m_Direction_1(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___m_Direction_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RAY_TE2163D4CB3E6B267E29F8ABE41684490E4A614B2_H
#ifndef RAYCASTHIT_T19695F18F9265FE5425062BBA6A4D330480538C3_H
#define RAYCASTHIT_T19695F18F9265FE5425062BBA6A4D330480538C3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RaycastHit
struct  RaycastHit_t19695F18F9265FE5425062BBA6A4D330480538C3 
{
public:
	// UnityEngine.Vector3 UnityEngine.RaycastHit::m_Point
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___m_Point_0;
	// UnityEngine.Vector3 UnityEngine.RaycastHit::m_Normal
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___m_Normal_1;
	// System.UInt32 UnityEngine.RaycastHit::m_FaceID
	uint32_t ___m_FaceID_2;
	// System.Single UnityEngine.RaycastHit::m_Distance
	float ___m_Distance_3;
	// UnityEngine.Vector2 UnityEngine.RaycastHit::m_UV
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_UV_4;
	// System.Int32 UnityEngine.RaycastHit::m_Collider
	int32_t ___m_Collider_5;

public:
	inline static int32_t get_offset_of_m_Point_0() { return static_cast<int32_t>(offsetof(RaycastHit_t19695F18F9265FE5425062BBA6A4D330480538C3, ___m_Point_0)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_m_Point_0() const { return ___m_Point_0; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_m_Point_0() { return &___m_Point_0; }
	inline void set_m_Point_0(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___m_Point_0 = value;
	}

	inline static int32_t get_offset_of_m_Normal_1() { return static_cast<int32_t>(offsetof(RaycastHit_t19695F18F9265FE5425062BBA6A4D330480538C3, ___m_Normal_1)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_m_Normal_1() const { return ___m_Normal_1; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_m_Normal_1() { return &___m_Normal_1; }
	inline void set_m_Normal_1(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___m_Normal_1 = value;
	}

	inline static int32_t get_offset_of_m_FaceID_2() { return static_cast<int32_t>(offsetof(RaycastHit_t19695F18F9265FE5425062BBA6A4D330480538C3, ___m_FaceID_2)); }
	inline uint32_t get_m_FaceID_2() const { return ___m_FaceID_2; }
	inline uint32_t* get_address_of_m_FaceID_2() { return &___m_FaceID_2; }
	inline void set_m_FaceID_2(uint32_t value)
	{
		___m_FaceID_2 = value;
	}

	inline static int32_t get_offset_of_m_Distance_3() { return static_cast<int32_t>(offsetof(RaycastHit_t19695F18F9265FE5425062BBA6A4D330480538C3, ___m_Distance_3)); }
	inline float get_m_Distance_3() const { return ___m_Distance_3; }
	inline float* get_address_of_m_Distance_3() { return &___m_Distance_3; }
	inline void set_m_Distance_3(float value)
	{
		___m_Distance_3 = value;
	}

	inline static int32_t get_offset_of_m_UV_4() { return static_cast<int32_t>(offsetof(RaycastHit_t19695F18F9265FE5425062BBA6A4D330480538C3, ___m_UV_4)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_UV_4() const { return ___m_UV_4; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_UV_4() { return &___m_UV_4; }
	inline void set_m_UV_4(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_UV_4 = value;
	}

	inline static int32_t get_offset_of_m_Collider_5() { return static_cast<int32_t>(offsetof(RaycastHit_t19695F18F9265FE5425062BBA6A4D330480538C3, ___m_Collider_5)); }
	inline int32_t get_m_Collider_5() const { return ___m_Collider_5; }
	inline int32_t* get_address_of_m_Collider_5() { return &___m_Collider_5; }
	inline void set_m_Collider_5(int32_t value)
	{
		___m_Collider_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RAYCASTHIT_T19695F18F9265FE5425062BBA6A4D330480538C3_H
#ifndef RAYCASTHIT2D_T5E8A7F96317BAF2033362FC780F4D72DC72764BE_H
#define RAYCASTHIT2D_T5E8A7F96317BAF2033362FC780F4D72DC72764BE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RaycastHit2D
struct  RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE 
{
public:
	// UnityEngine.Vector2 UnityEngine.RaycastHit2D::m_Centroid
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_Centroid_0;
	// UnityEngine.Vector2 UnityEngine.RaycastHit2D::m_Point
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_Point_1;
	// UnityEngine.Vector2 UnityEngine.RaycastHit2D::m_Normal
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_Normal_2;
	// System.Single UnityEngine.RaycastHit2D::m_Distance
	float ___m_Distance_3;
	// System.Single UnityEngine.RaycastHit2D::m_Fraction
	float ___m_Fraction_4;
	// System.Int32 UnityEngine.RaycastHit2D::m_Collider
	int32_t ___m_Collider_5;

public:
	inline static int32_t get_offset_of_m_Centroid_0() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Centroid_0)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_Centroid_0() const { return ___m_Centroid_0; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_Centroid_0() { return &___m_Centroid_0; }
	inline void set_m_Centroid_0(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_Centroid_0 = value;
	}

	inline static int32_t get_offset_of_m_Point_1() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Point_1)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_Point_1() const { return ___m_Point_1; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_Point_1() { return &___m_Point_1; }
	inline void set_m_Point_1(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_Point_1 = value;
	}

	inline static int32_t get_offset_of_m_Normal_2() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Normal_2)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_Normal_2() const { return ___m_Normal_2; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_Normal_2() { return &___m_Normal_2; }
	inline void set_m_Normal_2(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_Normal_2 = value;
	}

	inline static int32_t get_offset_of_m_Distance_3() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Distance_3)); }
	inline float get_m_Distance_3() const { return ___m_Distance_3; }
	inline float* get_address_of_m_Distance_3() { return &___m_Distance_3; }
	inline void set_m_Distance_3(float value)
	{
		___m_Distance_3 = value;
	}

	inline static int32_t get_offset_of_m_Fraction_4() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Fraction_4)); }
	inline float get_m_Fraction_4() const { return ___m_Fraction_4; }
	inline float* get_address_of_m_Fraction_4() { return &___m_Fraction_4; }
	inline void set_m_Fraction_4(float value)
	{
		___m_Fraction_4 = value;
	}

	inline static int32_t get_offset_of_m_Collider_5() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Collider_5)); }
	inline int32_t get_m_Collider_5() const { return ___m_Collider_5; }
	inline int32_t* get_address_of_m_Collider_5() { return &___m_Collider_5; }
	inline void set_m_Collider_5(int32_t value)
	{
		___m_Collider_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RAYCASTHIT2D_T5E8A7F96317BAF2033362FC780F4D72DC72764BE_H
#ifndef TEXTANCHOR_TEC19034D476659A5E05366C63564F34DD30E7C57_H
#define TEXTANCHOR_TEC19034D476659A5E05366C63564F34DD30E7C57_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.TextAnchor
struct  TextAnchor_tEC19034D476659A5E05366C63564F34DD30E7C57 
{
public:
	// System.Int32 UnityEngine.TextAnchor::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(TextAnchor_tEC19034D476659A5E05366C63564F34DD30E7C57, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TEXTANCHOR_TEC19034D476659A5E05366C63564F34DD30E7C57_H
#ifndef FITMODE_TBF783E77415F7063B468C18E758F738D83D60A08_H
#define FITMODE_TBF783E77415F7063B468C18E758F738D83D60A08_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.ContentSizeFitter_FitMode
struct  FitMode_tBF783E77415F7063B468C18E758F738D83D60A08 
{
public:
	// System.Int32 UnityEngine.UI.ContentSizeFitter_FitMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(FitMode_tBF783E77415F7063B468C18E758F738D83D60A08, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FITMODE_TBF783E77415F7063B468C18E758F738D83D60A08_H
#ifndef AXIS_TD4645F3B274E7AE7793C038A2BA2E68C6F0F02F0_H
#define AXIS_TD4645F3B274E7AE7793C038A2BA2E68C6F0F02F0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.GridLayoutGroup_Axis
struct  Axis_tD4645F3B274E7AE7793C038A2BA2E68C6F0F02F0 
{
public:
	// System.Int32 UnityEngine.UI.GridLayoutGroup_Axis::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Axis_tD4645F3B274E7AE7793C038A2BA2E68C6F0F02F0, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AXIS_TD4645F3B274E7AE7793C038A2BA2E68C6F0F02F0_H
#ifndef CONSTRAINT_TF471E55525B89D1E7C938CC0AF7515709494C59D_H
#define CONSTRAINT_TF471E55525B89D1E7C938CC0AF7515709494C59D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.GridLayoutGroup_Constraint
struct  Constraint_tF471E55525B89D1E7C938CC0AF7515709494C59D 
{
public:
	// System.Int32 UnityEngine.UI.GridLayoutGroup_Constraint::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Constraint_tF471E55525B89D1E7C938CC0AF7515709494C59D, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONSTRAINT_TF471E55525B89D1E7C938CC0AF7515709494C59D_H
#ifndef CORNER_TD61F36EC56D401A65DA06BE1A21689319201D18E_H
#define CORNER_TD61F36EC56D401A65DA06BE1A21689319201D18E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.GridLayoutGroup_Corner
struct  Corner_tD61F36EC56D401A65DA06BE1A21689319201D18E 
{
public:
	// System.Int32 UnityEngine.UI.GridLayoutGroup_Corner::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Corner_tD61F36EC56D401A65DA06BE1A21689319201D18E, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CORNER_TD61F36EC56D401A65DA06BE1A21689319201D18E_H
#ifndef VERTEXHELPER_T27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_H
#define VERTEXHELPER_T27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.VertexHelper
struct  VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F  : public RuntimeObject
{
public:
	// System.Collections.Generic.List`1<UnityEngine.Vector3> UnityEngine.UI.VertexHelper::m_Positions
	List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5 * ___m_Positions_0;
	// System.Collections.Generic.List`1<UnityEngine.Color32> UnityEngine.UI.VertexHelper::m_Colors
	List_1_t749ADA5233D9B421293A000DCB83608A24C3D5D5 * ___m_Colors_1;
	// System.Collections.Generic.List`1<UnityEngine.Vector2> UnityEngine.UI.VertexHelper::m_Uv0S
	List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * ___m_Uv0S_2;
	// System.Collections.Generic.List`1<UnityEngine.Vector2> UnityEngine.UI.VertexHelper::m_Uv1S
	List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * ___m_Uv1S_3;
	// System.Collections.Generic.List`1<UnityEngine.Vector2> UnityEngine.UI.VertexHelper::m_Uv2S
	List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * ___m_Uv2S_4;
	// System.Collections.Generic.List`1<UnityEngine.Vector2> UnityEngine.UI.VertexHelper::m_Uv3S
	List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * ___m_Uv3S_5;
	// System.Collections.Generic.List`1<UnityEngine.Vector3> UnityEngine.UI.VertexHelper::m_Normals
	List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5 * ___m_Normals_6;
	// System.Collections.Generic.List`1<UnityEngine.Vector4> UnityEngine.UI.VertexHelper::m_Tangents
	List_1_tFF4005B40E5BA433006DA11C56DB086B1E2FC955 * ___m_Tangents_7;
	// System.Collections.Generic.List`1<System.Int32> UnityEngine.UI.VertexHelper::m_Indices
	List_1_tE1526161A558A17A39A8B69D8EEF3801393B6226 * ___m_Indices_8;
	// System.Boolean UnityEngine.UI.VertexHelper::m_ListsInitalized
	bool ___m_ListsInitalized_11;

public:
	inline static int32_t get_offset_of_m_Positions_0() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Positions_0)); }
	inline List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5 * get_m_Positions_0() const { return ___m_Positions_0; }
	inline List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5 ** get_address_of_m_Positions_0() { return &___m_Positions_0; }
	inline void set_m_Positions_0(List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5 * value)
	{
		___m_Positions_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_Positions_0), value);
	}

	inline static int32_t get_offset_of_m_Colors_1() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Colors_1)); }
	inline List_1_t749ADA5233D9B421293A000DCB83608A24C3D5D5 * get_m_Colors_1() const { return ___m_Colors_1; }
	inline List_1_t749ADA5233D9B421293A000DCB83608A24C3D5D5 ** get_address_of_m_Colors_1() { return &___m_Colors_1; }
	inline void set_m_Colors_1(List_1_t749ADA5233D9B421293A000DCB83608A24C3D5D5 * value)
	{
		___m_Colors_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_Colors_1), value);
	}

	inline static int32_t get_offset_of_m_Uv0S_2() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Uv0S_2)); }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * get_m_Uv0S_2() const { return ___m_Uv0S_2; }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB ** get_address_of_m_Uv0S_2() { return &___m_Uv0S_2; }
	inline void set_m_Uv0S_2(List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * value)
	{
		___m_Uv0S_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_Uv0S_2), value);
	}

	inline static int32_t get_offset_of_m_Uv1S_3() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Uv1S_3)); }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * get_m_Uv1S_3() const { return ___m_Uv1S_3; }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB ** get_address_of_m_Uv1S_3() { return &___m_Uv1S_3; }
	inline void set_m_Uv1S_3(List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * value)
	{
		___m_Uv1S_3 = value;
		Il2CppCodeGenWriteBarrier((&___m_Uv1S_3), value);
	}

	inline static int32_t get_offset_of_m_Uv2S_4() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Uv2S_4)); }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * get_m_Uv2S_4() const { return ___m_Uv2S_4; }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB ** get_address_of_m_Uv2S_4() { return &___m_Uv2S_4; }
	inline void set_m_Uv2S_4(List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * value)
	{
		___m_Uv2S_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_Uv2S_4), value);
	}

	inline static int32_t get_offset_of_m_Uv3S_5() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Uv3S_5)); }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * get_m_Uv3S_5() const { return ___m_Uv3S_5; }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB ** get_address_of_m_Uv3S_5() { return &___m_Uv3S_5; }
	inline void set_m_Uv3S_5(List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * value)
	{
		___m_Uv3S_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_Uv3S_5), value);
	}

	inline static int32_t get_offset_of_m_Normals_6() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Normals_6)); }
	inline List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5 * get_m_Normals_6() const { return ___m_Normals_6; }
	inline List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5 ** get_address_of_m_Normals_6() { return &___m_Normals_6; }
	inline void set_m_Normals_6(List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5 * value)
	{
		___m_Normals_6 = value;
		Il2CppCodeGenWriteBarrier((&___m_Normals_6), value);
	}

	inline static int32_t get_offset_of_m_Tangents_7() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Tangents_7)); }
	inline List_1_tFF4005B40E5BA433006DA11C56DB086B1E2FC955 * get_m_Tangents_7() const { return ___m_Tangents_7; }
	inline List_1_tFF4005B40E5BA433006DA11C56DB086B1E2FC955 ** get_address_of_m_Tangents_7() { return &___m_Tangents_7; }
	inline void set_m_Tangents_7(List_1_tFF4005B40E5BA433006DA11C56DB086B1E2FC955 * value)
	{
		___m_Tangents_7 = value;
		Il2CppCodeGenWriteBarrier((&___m_Tangents_7), value);
	}

	inline static int32_t get_offset_of_m_Indices_8() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Indices_8)); }
	inline List_1_tE1526161A558A17A39A8B69D8EEF3801393B6226 * get_m_Indices_8() const { return ___m_Indices_8; }
	inline List_1_tE1526161A558A17A39A8B69D8EEF3801393B6226 ** get_address_of_m_Indices_8() { return &___m_Indices_8; }
	inline void set_m_Indices_8(List_1_tE1526161A558A17A39A8B69D8EEF3801393B6226 * value)
	{
		___m_Indices_8 = value;
		Il2CppCodeGenWriteBarrier((&___m_Indices_8), value);
	}

	inline static int32_t get_offset_of_m_ListsInitalized_11() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_ListsInitalized_11)); }
	inline bool get_m_ListsInitalized_11() const { return ___m_ListsInitalized_11; }
	inline bool* get_address_of_m_ListsInitalized_11() { return &___m_ListsInitalized_11; }
	inline void set_m_ListsInitalized_11(bool value)
	{
		___m_ListsInitalized_11 = value;
	}
};

struct VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_StaticFields
{
public:
	// UnityEngine.Vector4 UnityEngine.UI.VertexHelper::s_DefaultTangent
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___s_DefaultTangent_9;
	// UnityEngine.Vector3 UnityEngine.UI.VertexHelper::s_DefaultNormal
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___s_DefaultNormal_10;

public:
	inline static int32_t get_offset_of_s_DefaultTangent_9() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_StaticFields, ___s_DefaultTangent_9)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_s_DefaultTangent_9() const { return ___s_DefaultTangent_9; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_s_DefaultTangent_9() { return &___s_DefaultTangent_9; }
	inline void set_s_DefaultTangent_9(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___s_DefaultTangent_9 = value;
	}

	inline static int32_t get_offset_of_s_DefaultNormal_10() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_StaticFields, ___s_DefaultNormal_10)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_s_DefaultNormal_10() const { return ___s_DefaultNormal_10; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_s_DefaultNormal_10() { return &___s_DefaultNormal_10; }
	inline void set_s_DefaultNormal_10(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___s_DefaultNormal_10 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VERTEXHELPER_T27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_H
#ifndef MULTICASTDELEGATE_T_H
#define MULTICASTDELEGATE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MulticastDelegate
struct  MulticastDelegate_t  : public Delegate_t
{
public:
	// System.Delegate[] System.MulticastDelegate::delegates
	DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* ___delegates_11;

public:
	inline static int32_t get_offset_of_delegates_11() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___delegates_11)); }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* get_delegates_11() const { return ___delegates_11; }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86** get_address_of_delegates_11() { return &___delegates_11; }
	inline void set_delegates_11(DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* value)
	{
		___delegates_11 = value;
		Il2CppCodeGenWriteBarrier((&___delegates_11), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_pinvoke : public Delegate_t_marshaled_pinvoke
{
	Delegate_t_marshaled_pinvoke** ___delegates_11;
};
// Native definition for COM marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_com : public Delegate_t_marshaled_com
{
	Delegate_t_marshaled_com** ___delegates_11;
};
#endif // MULTICASTDELEGATE_T_H
#ifndef COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#define COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Component
struct  Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#ifndef BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#define BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Behaviour
struct  Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8  : public Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#ifndef GETRAYINTERSECTIONALLCALLBACK_T68C2581CCF05E868297EBD3F3361274954845095_H
#define GETRAYINTERSECTIONALLCALLBACK_T68C2581CCF05E868297EBD3F3361274954845095_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.ReflectionMethodsCache_GetRayIntersectionAllCallback
struct  GetRayIntersectionAllCallback_t68C2581CCF05E868297EBD3F3361274954845095  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GETRAYINTERSECTIONALLCALLBACK_T68C2581CCF05E868297EBD3F3361274954845095_H
#ifndef GETRAYINTERSECTIONALLNONALLOCCALLBACK_TAD7508D45DB6679B6394983579AD18D967CC2AD4_H
#define GETRAYINTERSECTIONALLNONALLOCCALLBACK_TAD7508D45DB6679B6394983579AD18D967CC2AD4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.ReflectionMethodsCache_GetRayIntersectionAllNonAllocCallback
struct  GetRayIntersectionAllNonAllocCallback_tAD7508D45DB6679B6394983579AD18D967CC2AD4  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GETRAYINTERSECTIONALLNONALLOCCALLBACK_TAD7508D45DB6679B6394983579AD18D967CC2AD4_H
#ifndef GETRAYCASTNONALLOCCALLBACK_TC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D_H
#define GETRAYCASTNONALLOCCALLBACK_TC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.ReflectionMethodsCache_GetRaycastNonAllocCallback
struct  GetRaycastNonAllocCallback_tC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GETRAYCASTNONALLOCCALLBACK_TC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D_H
#ifndef RAYCAST2DCALLBACK_TE99ABF9ABC3A380677949E8C05A3E477889B82BE_H
#define RAYCAST2DCALLBACK_TE99ABF9ABC3A380677949E8C05A3E477889B82BE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.ReflectionMethodsCache_Raycast2DCallback
struct  Raycast2DCallback_tE99ABF9ABC3A380677949E8C05A3E477889B82BE  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RAYCAST2DCALLBACK_TE99ABF9ABC3A380677949E8C05A3E477889B82BE_H
#ifndef RAYCAST3DCALLBACK_T83483916473C9710AEDB316A65CBE62C58935C5F_H
#define RAYCAST3DCALLBACK_T83483916473C9710AEDB316A65CBE62C58935C5F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.ReflectionMethodsCache_Raycast3DCallback
struct  Raycast3DCallback_t83483916473C9710AEDB316A65CBE62C58935C5F  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RAYCAST3DCALLBACK_T83483916473C9710AEDB316A65CBE62C58935C5F_H
#ifndef RAYCASTALLCALLBACK_T751407A44270E02FAA43D0846A58EE6A8C4AE1CE_H
#define RAYCASTALLCALLBACK_T751407A44270E02FAA43D0846A58EE6A8C4AE1CE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.ReflectionMethodsCache_RaycastAllCallback
struct  RaycastAllCallback_t751407A44270E02FAA43D0846A58EE6A8C4AE1CE  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RAYCASTALLCALLBACK_T751407A44270E02FAA43D0846A58EE6A8C4AE1CE_H
#ifndef MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#define MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.MonoBehaviour
struct  MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429  : public Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#ifndef UNITYCALLFACTORY_T8EDDA82C4443ADF36445011BE4CCD732000E06AB_H
#define UNITYCALLFACTORY_T8EDDA82C4443ADF36445011BE4CCD732000E06AB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityCallFactory
struct  UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Int32 Byn.Awrtc.Unity.UnityCallFactory::mAndroidPreviousAudioMode
	int32_t ___mAndroidPreviousAudioMode_10;
	// System.Int32 Byn.Awrtc.Unity.UnityCallFactory::mSleepTimeoutBackup
	int32_t ___mSleepTimeoutBackup_11;
	// System.Boolean Byn.Awrtc.Unity.UnityCallFactory::mHasActiveCall
	bool ___mHasActiveCall_12;
	// Byn.Awrtc.IAwrtcFactory Byn.Awrtc.Unity.UnityCallFactory::mFactory
	RuntimeObject* ___mFactory_19;

public:
	inline static int32_t get_offset_of_mAndroidPreviousAudioMode_10() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB, ___mAndroidPreviousAudioMode_10)); }
	inline int32_t get_mAndroidPreviousAudioMode_10() const { return ___mAndroidPreviousAudioMode_10; }
	inline int32_t* get_address_of_mAndroidPreviousAudioMode_10() { return &___mAndroidPreviousAudioMode_10; }
	inline void set_mAndroidPreviousAudioMode_10(int32_t value)
	{
		___mAndroidPreviousAudioMode_10 = value;
	}

	inline static int32_t get_offset_of_mSleepTimeoutBackup_11() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB, ___mSleepTimeoutBackup_11)); }
	inline int32_t get_mSleepTimeoutBackup_11() const { return ___mSleepTimeoutBackup_11; }
	inline int32_t* get_address_of_mSleepTimeoutBackup_11() { return &___mSleepTimeoutBackup_11; }
	inline void set_mSleepTimeoutBackup_11(int32_t value)
	{
		___mSleepTimeoutBackup_11 = value;
	}

	inline static int32_t get_offset_of_mHasActiveCall_12() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB, ___mHasActiveCall_12)); }
	inline bool get_mHasActiveCall_12() const { return ___mHasActiveCall_12; }
	inline bool* get_address_of_mHasActiveCall_12() { return &___mHasActiveCall_12; }
	inline void set_mHasActiveCall_12(bool value)
	{
		___mHasActiveCall_12 = value;
	}

	inline static int32_t get_offset_of_mFactory_19() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB, ___mFactory_19)); }
	inline RuntimeObject* get_mFactory_19() const { return ___mFactory_19; }
	inline RuntimeObject** get_address_of_mFactory_19() { return &___mFactory_19; }
	inline void set_mFactory_19(RuntimeObject* value)
	{
		___mFactory_19 = value;
		Il2CppCodeGenWriteBarrier((&___mFactory_19), value);
	}
};

struct UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields
{
public:
	// System.Boolean Byn.Awrtc.Unity.UnityCallFactory::ALLOW_SYNCHRONOUS_INIT
	bool ___ALLOW_SYNCHRONOUS_INIT_4;
	// System.Boolean Byn.Awrtc.Unity.UnityCallFactory::ANDROID_SET_COMMUNICATION_MODE
	bool ___ANDROID_SET_COMMUNICATION_MODE_5;
	// System.Boolean Byn.Awrtc.Unity.UnityCallFactory::ALLOW_UNCHECKED_REMOTE_CERTIFICATE
	bool ___ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6;
	// System.Boolean Byn.Awrtc.Unity.UnityCallFactory::KEEP_AWAKE
	bool ___KEEP_AWAKE_7;
	// Byn.Awrtc.Unity.UnityCallFactory_LogLevel Byn.Awrtc.Unity.UnityCallFactory::DEFAULT_LOG_LEVEL
	int32_t ___DEFAULT_LOG_LEVEL_8;
	// System.Boolean Byn.Awrtc.Unity.UnityCallFactory::NATIVE_VERBOSE_LOG
	bool ___NATIVE_VERBOSE_LOG_9;
	// Byn.Awrtc.Unity.UnityCallFactory_InitState Byn.Awrtc.Unity.UnityCallFactory::sInitState
	int32_t ___sInitState_13;
	// System.Collections.Generic.List`1<Byn.Awrtc.Unity.UnityCallFactory_InitCallbacks> Byn.Awrtc.Unity.UnityCallFactory::sInitCallbacks
	List_1_tA9DD76095D2B3253680DE30E64CB3A486DFBDAF7 * ___sInitCallbacks_14;
	// System.String Byn.Awrtc.Unity.UnityCallFactory::sInitFailedMessage
	String_t* ___sInitFailedMessage_15;
	// Byn.Awrtc.Unity.UnityCallFactory_LogLevel Byn.Awrtc.Unity.UnityCallFactory::sActiveLogLevel
	int32_t ___sActiveLogLevel_16;
	// System.String Byn.Awrtc.Unity.UnityCallFactory::LOG_PREFIX
	String_t* ___LOG_PREFIX_17;
	// Byn.Awrtc.Unity.UnityCallFactory Byn.Awrtc.Unity.UnityCallFactory::sInstance
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB * ___sInstance_18;

public:
	inline static int32_t get_offset_of_ALLOW_SYNCHRONOUS_INIT_4() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___ALLOW_SYNCHRONOUS_INIT_4)); }
	inline bool get_ALLOW_SYNCHRONOUS_INIT_4() const { return ___ALLOW_SYNCHRONOUS_INIT_4; }
	inline bool* get_address_of_ALLOW_SYNCHRONOUS_INIT_4() { return &___ALLOW_SYNCHRONOUS_INIT_4; }
	inline void set_ALLOW_SYNCHRONOUS_INIT_4(bool value)
	{
		___ALLOW_SYNCHRONOUS_INIT_4 = value;
	}

	inline static int32_t get_offset_of_ANDROID_SET_COMMUNICATION_MODE_5() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___ANDROID_SET_COMMUNICATION_MODE_5)); }
	inline bool get_ANDROID_SET_COMMUNICATION_MODE_5() const { return ___ANDROID_SET_COMMUNICATION_MODE_5; }
	inline bool* get_address_of_ANDROID_SET_COMMUNICATION_MODE_5() { return &___ANDROID_SET_COMMUNICATION_MODE_5; }
	inline void set_ANDROID_SET_COMMUNICATION_MODE_5(bool value)
	{
		___ANDROID_SET_COMMUNICATION_MODE_5 = value;
	}

	inline static int32_t get_offset_of_ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6)); }
	inline bool get_ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6() const { return ___ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6; }
	inline bool* get_address_of_ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6() { return &___ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6; }
	inline void set_ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6(bool value)
	{
		___ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6 = value;
	}

	inline static int32_t get_offset_of_KEEP_AWAKE_7() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___KEEP_AWAKE_7)); }
	inline bool get_KEEP_AWAKE_7() const { return ___KEEP_AWAKE_7; }
	inline bool* get_address_of_KEEP_AWAKE_7() { return &___KEEP_AWAKE_7; }
	inline void set_KEEP_AWAKE_7(bool value)
	{
		___KEEP_AWAKE_7 = value;
	}

	inline static int32_t get_offset_of_DEFAULT_LOG_LEVEL_8() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___DEFAULT_LOG_LEVEL_8)); }
	inline int32_t get_DEFAULT_LOG_LEVEL_8() const { return ___DEFAULT_LOG_LEVEL_8; }
	inline int32_t* get_address_of_DEFAULT_LOG_LEVEL_8() { return &___DEFAULT_LOG_LEVEL_8; }
	inline void set_DEFAULT_LOG_LEVEL_8(int32_t value)
	{
		___DEFAULT_LOG_LEVEL_8 = value;
	}

	inline static int32_t get_offset_of_NATIVE_VERBOSE_LOG_9() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___NATIVE_VERBOSE_LOG_9)); }
	inline bool get_NATIVE_VERBOSE_LOG_9() const { return ___NATIVE_VERBOSE_LOG_9; }
	inline bool* get_address_of_NATIVE_VERBOSE_LOG_9() { return &___NATIVE_VERBOSE_LOG_9; }
	inline void set_NATIVE_VERBOSE_LOG_9(bool value)
	{
		___NATIVE_VERBOSE_LOG_9 = value;
	}

	inline static int32_t get_offset_of_sInitState_13() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___sInitState_13)); }
	inline int32_t get_sInitState_13() const { return ___sInitState_13; }
	inline int32_t* get_address_of_sInitState_13() { return &___sInitState_13; }
	inline void set_sInitState_13(int32_t value)
	{
		___sInitState_13 = value;
	}

	inline static int32_t get_offset_of_sInitCallbacks_14() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___sInitCallbacks_14)); }
	inline List_1_tA9DD76095D2B3253680DE30E64CB3A486DFBDAF7 * get_sInitCallbacks_14() const { return ___sInitCallbacks_14; }
	inline List_1_tA9DD76095D2B3253680DE30E64CB3A486DFBDAF7 ** get_address_of_sInitCallbacks_14() { return &___sInitCallbacks_14; }
	inline void set_sInitCallbacks_14(List_1_tA9DD76095D2B3253680DE30E64CB3A486DFBDAF7 * value)
	{
		___sInitCallbacks_14 = value;
		Il2CppCodeGenWriteBarrier((&___sInitCallbacks_14), value);
	}

	inline static int32_t get_offset_of_sInitFailedMessage_15() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___sInitFailedMessage_15)); }
	inline String_t* get_sInitFailedMessage_15() const { return ___sInitFailedMessage_15; }
	inline String_t** get_address_of_sInitFailedMessage_15() { return &___sInitFailedMessage_15; }
	inline void set_sInitFailedMessage_15(String_t* value)
	{
		___sInitFailedMessage_15 = value;
		Il2CppCodeGenWriteBarrier((&___sInitFailedMessage_15), value);
	}

	inline static int32_t get_offset_of_sActiveLogLevel_16() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___sActiveLogLevel_16)); }
	inline int32_t get_sActiveLogLevel_16() const { return ___sActiveLogLevel_16; }
	inline int32_t* get_address_of_sActiveLogLevel_16() { return &___sActiveLogLevel_16; }
	inline void set_sActiveLogLevel_16(int32_t value)
	{
		___sActiveLogLevel_16 = value;
	}

	inline static int32_t get_offset_of_LOG_PREFIX_17() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___LOG_PREFIX_17)); }
	inline String_t* get_LOG_PREFIX_17() const { return ___LOG_PREFIX_17; }
	inline String_t** get_address_of_LOG_PREFIX_17() { return &___LOG_PREFIX_17; }
	inline void set_LOG_PREFIX_17(String_t* value)
	{
		___LOG_PREFIX_17 = value;
		Il2CppCodeGenWriteBarrier((&___LOG_PREFIX_17), value);
	}

	inline static int32_t get_offset_of_sInstance_18() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___sInstance_18)); }
	inline UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB * get_sInstance_18() const { return ___sInstance_18; }
	inline UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB ** get_address_of_sInstance_18() { return &___sInstance_18; }
	inline void set_sInstance_18(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB * value)
	{
		___sInstance_18 = value;
		Il2CppCodeGenWriteBarrier((&___sInstance_18), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNITYCALLFACTORY_T8EDDA82C4443ADF36445011BE4CCD732000E06AB_H
#ifndef CONFERENCEAPP_T0EFD286CF629E11657DF84B2F40D842EA3F74EBE_H
#define CONFERENCEAPP_T0EFD286CF629E11657DF84B2F40D842EA3F74EBE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.ConferenceApp
struct  ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.UI.InputField Byn.Unity.Examples.ConferenceApp::uRoomName
	InputField_t533609195B110760BCFF00B746C87D81969CB005 * ___uRoomName_5;
	// UnityEngine.UI.InputField Byn.Unity.Examples.ConferenceApp::uMessageField
	InputField_t533609195B110760BCFF00B746C87D81969CB005 * ___uMessageField_6;
	// MessageList Byn.Unity.Examples.ConferenceApp::uOutput
	MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC * ___uOutput_7;
	// UnityEngine.UI.Button Byn.Unity.Examples.ConferenceApp::uJoin
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uJoin_8;
	// UnityEngine.UI.Button Byn.Unity.Examples.ConferenceApp::uSend
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uSend_9;
	// UnityEngine.UI.Button Byn.Unity.Examples.ConferenceApp::uShutdown
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uShutdown_10;
	// UnityEngine.GameObject Byn.Unity.Examples.ConferenceApp::uSetupPanel
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___uSetupPanel_11;
	// UnityEngine.GameObject Byn.Unity.Examples.ConferenceApp::uVideoLayout
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___uVideoLayout_12;
	// UnityEngine.GameObject Byn.Unity.Examples.ConferenceApp::uVideoPrefab
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___uVideoPrefab_13;
	// UnityEngine.Texture2D Byn.Unity.Examples.ConferenceApp::uNoImgTexture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___uNoImgTexture_14;
	// Byn.Awrtc.ICall Byn.Unity.Examples.ConferenceApp::mCall
	RuntimeObject* ___mCall_15;
	// Byn.Awrtc.MediaConfig Byn.Unity.Examples.ConferenceApp::config
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___config_16;
	// System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Unity.Examples.ConferenceApp_VideoData> Byn.Unity.Examples.ConferenceApp::mVideoUiElements
	Dictionary_2_t506AF32D1300A531CEAA46A92593E3079E4692F1 * ___mVideoUiElements_17;

public:
	inline static int32_t get_offset_of_uRoomName_5() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uRoomName_5)); }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 * get_uRoomName_5() const { return ___uRoomName_5; }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 ** get_address_of_uRoomName_5() { return &___uRoomName_5; }
	inline void set_uRoomName_5(InputField_t533609195B110760BCFF00B746C87D81969CB005 * value)
	{
		___uRoomName_5 = value;
		Il2CppCodeGenWriteBarrier((&___uRoomName_5), value);
	}

	inline static int32_t get_offset_of_uMessageField_6() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uMessageField_6)); }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 * get_uMessageField_6() const { return ___uMessageField_6; }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 ** get_address_of_uMessageField_6() { return &___uMessageField_6; }
	inline void set_uMessageField_6(InputField_t533609195B110760BCFF00B746C87D81969CB005 * value)
	{
		___uMessageField_6 = value;
		Il2CppCodeGenWriteBarrier((&___uMessageField_6), value);
	}

	inline static int32_t get_offset_of_uOutput_7() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uOutput_7)); }
	inline MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC * get_uOutput_7() const { return ___uOutput_7; }
	inline MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC ** get_address_of_uOutput_7() { return &___uOutput_7; }
	inline void set_uOutput_7(MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC * value)
	{
		___uOutput_7 = value;
		Il2CppCodeGenWriteBarrier((&___uOutput_7), value);
	}

	inline static int32_t get_offset_of_uJoin_8() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uJoin_8)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uJoin_8() const { return ___uJoin_8; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uJoin_8() { return &___uJoin_8; }
	inline void set_uJoin_8(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uJoin_8 = value;
		Il2CppCodeGenWriteBarrier((&___uJoin_8), value);
	}

	inline static int32_t get_offset_of_uSend_9() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uSend_9)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uSend_9() const { return ___uSend_9; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uSend_9() { return &___uSend_9; }
	inline void set_uSend_9(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uSend_9 = value;
		Il2CppCodeGenWriteBarrier((&___uSend_9), value);
	}

	inline static int32_t get_offset_of_uShutdown_10() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uShutdown_10)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uShutdown_10() const { return ___uShutdown_10; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uShutdown_10() { return &___uShutdown_10; }
	inline void set_uShutdown_10(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uShutdown_10 = value;
		Il2CppCodeGenWriteBarrier((&___uShutdown_10), value);
	}

	inline static int32_t get_offset_of_uSetupPanel_11() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uSetupPanel_11)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_uSetupPanel_11() const { return ___uSetupPanel_11; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_uSetupPanel_11() { return &___uSetupPanel_11; }
	inline void set_uSetupPanel_11(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___uSetupPanel_11 = value;
		Il2CppCodeGenWriteBarrier((&___uSetupPanel_11), value);
	}

	inline static int32_t get_offset_of_uVideoLayout_12() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uVideoLayout_12)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_uVideoLayout_12() const { return ___uVideoLayout_12; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_uVideoLayout_12() { return &___uVideoLayout_12; }
	inline void set_uVideoLayout_12(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___uVideoLayout_12 = value;
		Il2CppCodeGenWriteBarrier((&___uVideoLayout_12), value);
	}

	inline static int32_t get_offset_of_uVideoPrefab_13() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uVideoPrefab_13)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_uVideoPrefab_13() const { return ___uVideoPrefab_13; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_uVideoPrefab_13() { return &___uVideoPrefab_13; }
	inline void set_uVideoPrefab_13(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___uVideoPrefab_13 = value;
		Il2CppCodeGenWriteBarrier((&___uVideoPrefab_13), value);
	}

	inline static int32_t get_offset_of_uNoImgTexture_14() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uNoImgTexture_14)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_uNoImgTexture_14() const { return ___uNoImgTexture_14; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_uNoImgTexture_14() { return &___uNoImgTexture_14; }
	inline void set_uNoImgTexture_14(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___uNoImgTexture_14 = value;
		Il2CppCodeGenWriteBarrier((&___uNoImgTexture_14), value);
	}

	inline static int32_t get_offset_of_mCall_15() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___mCall_15)); }
	inline RuntimeObject* get_mCall_15() const { return ___mCall_15; }
	inline RuntimeObject** get_address_of_mCall_15() { return &___mCall_15; }
	inline void set_mCall_15(RuntimeObject* value)
	{
		___mCall_15 = value;
		Il2CppCodeGenWriteBarrier((&___mCall_15), value);
	}

	inline static int32_t get_offset_of_config_16() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___config_16)); }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * get_config_16() const { return ___config_16; }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D ** get_address_of_config_16() { return &___config_16; }
	inline void set_config_16(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * value)
	{
		___config_16 = value;
		Il2CppCodeGenWriteBarrier((&___config_16), value);
	}

	inline static int32_t get_offset_of_mVideoUiElements_17() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___mVideoUiElements_17)); }
	inline Dictionary_2_t506AF32D1300A531CEAA46A92593E3079E4692F1 * get_mVideoUiElements_17() const { return ___mVideoUiElements_17; }
	inline Dictionary_2_t506AF32D1300A531CEAA46A92593E3079E4692F1 ** get_address_of_mVideoUiElements_17() { return &___mVideoUiElements_17; }
	inline void set_mVideoUiElements_17(Dictionary_2_t506AF32D1300A531CEAA46A92593E3079E4692F1 * value)
	{
		___mVideoUiElements_17 = value;
		Il2CppCodeGenWriteBarrier((&___mVideoUiElements_17), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONFERENCEAPP_T0EFD286CF629E11657DF84B2F40D842EA3F74EBE_H
#ifndef MINIMALCALL_T1A616F4059C1AC885A34A5636B57E1687B1E9E73_H
#define MINIMALCALL_T1A616F4059C1AC885A34A5636B57E1687B1E9E73_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.MinimalCall
struct  MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// Byn.Awrtc.ICall Byn.Unity.Examples.MinimalCall::sender
	RuntimeObject* ___sender_4;
	// Byn.Awrtc.ICall Byn.Unity.Examples.MinimalCall::receiver
	RuntimeObject* ___receiver_5;
	// Byn.Awrtc.NetworkConfig Byn.Unity.Examples.MinimalCall::netConf
	NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * ___netConf_6;
	// System.String Byn.Unity.Examples.MinimalCall::address
	String_t* ___address_7;

public:
	inline static int32_t get_offset_of_sender_4() { return static_cast<int32_t>(offsetof(MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73, ___sender_4)); }
	inline RuntimeObject* get_sender_4() const { return ___sender_4; }
	inline RuntimeObject** get_address_of_sender_4() { return &___sender_4; }
	inline void set_sender_4(RuntimeObject* value)
	{
		___sender_4 = value;
		Il2CppCodeGenWriteBarrier((&___sender_4), value);
	}

	inline static int32_t get_offset_of_receiver_5() { return static_cast<int32_t>(offsetof(MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73, ___receiver_5)); }
	inline RuntimeObject* get_receiver_5() const { return ___receiver_5; }
	inline RuntimeObject** get_address_of_receiver_5() { return &___receiver_5; }
	inline void set_receiver_5(RuntimeObject* value)
	{
		___receiver_5 = value;
		Il2CppCodeGenWriteBarrier((&___receiver_5), value);
	}

	inline static int32_t get_offset_of_netConf_6() { return static_cast<int32_t>(offsetof(MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73, ___netConf_6)); }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * get_netConf_6() const { return ___netConf_6; }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 ** get_address_of_netConf_6() { return &___netConf_6; }
	inline void set_netConf_6(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * value)
	{
		___netConf_6 = value;
		Il2CppCodeGenWriteBarrier((&___netConf_6), value);
	}

	inline static int32_t get_offset_of_address_7() { return static_cast<int32_t>(offsetof(MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73, ___address_7)); }
	inline String_t* get_address_7() const { return ___address_7; }
	inline String_t** get_address_of_address_7() { return &___address_7; }
	inline void set_address_7(String_t* value)
	{
		___address_7 = value;
		Il2CppCodeGenWriteBarrier((&___address_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MINIMALCALL_T1A616F4059C1AC885A34A5636B57E1687B1E9E73_H
#ifndef MINIMALCONFERENCE_T9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3_H
#define MINIMALCONFERENCE_T9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.MinimalConference
struct  MinimalConference_t9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// Byn.Awrtc.ICall[] Byn.Unity.Examples.MinimalConference::calls
	ICallU5BU5D_t88E87BA53231880D2D4272EBF46A2A691ADA8741* ___calls_4;
	// Byn.Awrtc.NetworkConfig Byn.Unity.Examples.MinimalConference::netConf
	NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * ___netConf_5;
	// System.String Byn.Unity.Examples.MinimalConference::address
	String_t* ___address_6;

public:
	inline static int32_t get_offset_of_calls_4() { return static_cast<int32_t>(offsetof(MinimalConference_t9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3, ___calls_4)); }
	inline ICallU5BU5D_t88E87BA53231880D2D4272EBF46A2A691ADA8741* get_calls_4() const { return ___calls_4; }
	inline ICallU5BU5D_t88E87BA53231880D2D4272EBF46A2A691ADA8741** get_address_of_calls_4() { return &___calls_4; }
	inline void set_calls_4(ICallU5BU5D_t88E87BA53231880D2D4272EBF46A2A691ADA8741* value)
	{
		___calls_4 = value;
		Il2CppCodeGenWriteBarrier((&___calls_4), value);
	}

	inline static int32_t get_offset_of_netConf_5() { return static_cast<int32_t>(offsetof(MinimalConference_t9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3, ___netConf_5)); }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * get_netConf_5() const { return ___netConf_5; }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 ** get_address_of_netConf_5() { return &___netConf_5; }
	inline void set_netConf_5(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * value)
	{
		___netConf_5 = value;
		Il2CppCodeGenWriteBarrier((&___netConf_5), value);
	}

	inline static int32_t get_offset_of_address_6() { return static_cast<int32_t>(offsetof(MinimalConference_t9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3, ___address_6)); }
	inline String_t* get_address_6() const { return ___address_6; }
	inline String_t** get_address_of_address_6() { return &___address_6; }
	inline void set_address_6(String_t* value)
	{
		___address_6 = value;
		Il2CppCodeGenWriteBarrier((&___address_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MINIMALCONFERENCE_T9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3_H
#ifndef MINIMALMEDIANETWORK_T99B14410205FF74DEFEF6E056C1A045777B89FFF_H
#define MINIMALMEDIANETWORK_T99B14410205FF74DEFEF6E056C1A045777B89FFF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.MinimalMediaNetwork
struct  MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// Byn.Awrtc.IMediaNetwork Byn.Unity.Examples.MinimalMediaNetwork::sender
	RuntimeObject* ___sender_4;
	// System.Boolean Byn.Unity.Examples.MinimalMediaNetwork::mSenderConfigured
	bool ___mSenderConfigured_5;
	// Byn.Awrtc.IMediaNetwork Byn.Unity.Examples.MinimalMediaNetwork::receiver
	RuntimeObject* ___receiver_6;
	// System.Boolean Byn.Unity.Examples.MinimalMediaNetwork::mReceiverConfigured
	bool ___mReceiverConfigured_7;
	// Byn.Awrtc.NetworkConfig Byn.Unity.Examples.MinimalMediaNetwork::netConf
	NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * ___netConf_8;
	// System.String Byn.Unity.Examples.MinimalMediaNetwork::address
	String_t* ___address_9;

public:
	inline static int32_t get_offset_of_sender_4() { return static_cast<int32_t>(offsetof(MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF, ___sender_4)); }
	inline RuntimeObject* get_sender_4() const { return ___sender_4; }
	inline RuntimeObject** get_address_of_sender_4() { return &___sender_4; }
	inline void set_sender_4(RuntimeObject* value)
	{
		___sender_4 = value;
		Il2CppCodeGenWriteBarrier((&___sender_4), value);
	}

	inline static int32_t get_offset_of_mSenderConfigured_5() { return static_cast<int32_t>(offsetof(MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF, ___mSenderConfigured_5)); }
	inline bool get_mSenderConfigured_5() const { return ___mSenderConfigured_5; }
	inline bool* get_address_of_mSenderConfigured_5() { return &___mSenderConfigured_5; }
	inline void set_mSenderConfigured_5(bool value)
	{
		___mSenderConfigured_5 = value;
	}

	inline static int32_t get_offset_of_receiver_6() { return static_cast<int32_t>(offsetof(MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF, ___receiver_6)); }
	inline RuntimeObject* get_receiver_6() const { return ___receiver_6; }
	inline RuntimeObject** get_address_of_receiver_6() { return &___receiver_6; }
	inline void set_receiver_6(RuntimeObject* value)
	{
		___receiver_6 = value;
		Il2CppCodeGenWriteBarrier((&___receiver_6), value);
	}

	inline static int32_t get_offset_of_mReceiverConfigured_7() { return static_cast<int32_t>(offsetof(MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF, ___mReceiverConfigured_7)); }
	inline bool get_mReceiverConfigured_7() const { return ___mReceiverConfigured_7; }
	inline bool* get_address_of_mReceiverConfigured_7() { return &___mReceiverConfigured_7; }
	inline void set_mReceiverConfigured_7(bool value)
	{
		___mReceiverConfigured_7 = value;
	}

	inline static int32_t get_offset_of_netConf_8() { return static_cast<int32_t>(offsetof(MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF, ___netConf_8)); }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * get_netConf_8() const { return ___netConf_8; }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 ** get_address_of_netConf_8() { return &___netConf_8; }
	inline void set_netConf_8(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * value)
	{
		___netConf_8 = value;
		Il2CppCodeGenWriteBarrier((&___netConf_8), value);
	}

	inline static int32_t get_offset_of_address_9() { return static_cast<int32_t>(offsetof(MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF, ___address_9)); }
	inline String_t* get_address_9() const { return ___address_9; }
	inline String_t** get_address_of_address_9() { return &___address_9; }
	inline void set_address_9(String_t* value)
	{
		___address_9 = value;
		Il2CppCodeGenWriteBarrier((&___address_9), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MINIMALMEDIANETWORK_T99B14410205FF74DEFEF6E056C1A045777B89FFF_H
#ifndef ONETOMANY_TD2FD726816556B1F8CD9045B5FE9F44C4E00C086_H
#define ONETOMANY_TD2FD726816556B1F8CD9045B5FE9F44C4E00C086_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.OneToMany
struct  OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.String Byn.Unity.Examples.OneToMany::mSignalingServer
	String_t* ___mSignalingServer_4;
	// System.String Byn.Unity.Examples.OneToMany::mStunServer
	String_t* ___mStunServer_5;
	// Byn.Awrtc.IMediaNetwork Byn.Unity.Examples.OneToMany::mMediaNetwork
	RuntimeObject* ___mMediaNetwork_6;
	// Byn.Awrtc.MediaConfig Byn.Unity.Examples.OneToMany::mMediaConfig
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___mMediaConfig_7;
	// System.Int32 Byn.Unity.Examples.OneToMany::mIndex
	int32_t ___mIndex_9;
	// System.Boolean Byn.Unity.Examples.OneToMany::uSender
	bool ___uSender_10;
	// UnityEngine.UI.RawImage Byn.Unity.Examples.OneToMany::uVideoOutput
	RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * ___uVideoOutput_11;
	// UnityEngine.Texture2D Byn.Unity.Examples.OneToMany::mVideoTexture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___mVideoTexture_12;
	// System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId> Byn.Unity.Examples.OneToMany::mConnectionIds
	List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * ___mConnectionIds_14;

public:
	inline static int32_t get_offset_of_mSignalingServer_4() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___mSignalingServer_4)); }
	inline String_t* get_mSignalingServer_4() const { return ___mSignalingServer_4; }
	inline String_t** get_address_of_mSignalingServer_4() { return &___mSignalingServer_4; }
	inline void set_mSignalingServer_4(String_t* value)
	{
		___mSignalingServer_4 = value;
		Il2CppCodeGenWriteBarrier((&___mSignalingServer_4), value);
	}

	inline static int32_t get_offset_of_mStunServer_5() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___mStunServer_5)); }
	inline String_t* get_mStunServer_5() const { return ___mStunServer_5; }
	inline String_t** get_address_of_mStunServer_5() { return &___mStunServer_5; }
	inline void set_mStunServer_5(String_t* value)
	{
		___mStunServer_5 = value;
		Il2CppCodeGenWriteBarrier((&___mStunServer_5), value);
	}

	inline static int32_t get_offset_of_mMediaNetwork_6() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___mMediaNetwork_6)); }
	inline RuntimeObject* get_mMediaNetwork_6() const { return ___mMediaNetwork_6; }
	inline RuntimeObject** get_address_of_mMediaNetwork_6() { return &___mMediaNetwork_6; }
	inline void set_mMediaNetwork_6(RuntimeObject* value)
	{
		___mMediaNetwork_6 = value;
		Il2CppCodeGenWriteBarrier((&___mMediaNetwork_6), value);
	}

	inline static int32_t get_offset_of_mMediaConfig_7() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___mMediaConfig_7)); }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * get_mMediaConfig_7() const { return ___mMediaConfig_7; }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D ** get_address_of_mMediaConfig_7() { return &___mMediaConfig_7; }
	inline void set_mMediaConfig_7(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * value)
	{
		___mMediaConfig_7 = value;
		Il2CppCodeGenWriteBarrier((&___mMediaConfig_7), value);
	}

	inline static int32_t get_offset_of_mIndex_9() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___mIndex_9)); }
	inline int32_t get_mIndex_9() const { return ___mIndex_9; }
	inline int32_t* get_address_of_mIndex_9() { return &___mIndex_9; }
	inline void set_mIndex_9(int32_t value)
	{
		___mIndex_9 = value;
	}

	inline static int32_t get_offset_of_uSender_10() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___uSender_10)); }
	inline bool get_uSender_10() const { return ___uSender_10; }
	inline bool* get_address_of_uSender_10() { return &___uSender_10; }
	inline void set_uSender_10(bool value)
	{
		___uSender_10 = value;
	}

	inline static int32_t get_offset_of_uVideoOutput_11() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___uVideoOutput_11)); }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * get_uVideoOutput_11() const { return ___uVideoOutput_11; }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 ** get_address_of_uVideoOutput_11() { return &___uVideoOutput_11; }
	inline void set_uVideoOutput_11(RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * value)
	{
		___uVideoOutput_11 = value;
		Il2CppCodeGenWriteBarrier((&___uVideoOutput_11), value);
	}

	inline static int32_t get_offset_of_mVideoTexture_12() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___mVideoTexture_12)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_mVideoTexture_12() const { return ___mVideoTexture_12; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_mVideoTexture_12() { return &___mVideoTexture_12; }
	inline void set_mVideoTexture_12(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___mVideoTexture_12 = value;
		Il2CppCodeGenWriteBarrier((&___mVideoTexture_12), value);
	}

	inline static int32_t get_offset_of_mConnectionIds_14() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___mConnectionIds_14)); }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * get_mConnectionIds_14() const { return ___mConnectionIds_14; }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 ** get_address_of_mConnectionIds_14() { return &___mConnectionIds_14; }
	inline void set_mConnectionIds_14(List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * value)
	{
		___mConnectionIds_14 = value;
		Il2CppCodeGenWriteBarrier((&___mConnectionIds_14), value);
	}
};

struct OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086_StaticFields
{
public:
	// System.Int32 Byn.Unity.Examples.OneToMany::sInstances
	int32_t ___sInstances_8;
	// System.String Byn.Unity.Examples.OneToMany::sAddress
	String_t* ___sAddress_13;

public:
	inline static int32_t get_offset_of_sInstances_8() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086_StaticFields, ___sInstances_8)); }
	inline int32_t get_sInstances_8() const { return ___sInstances_8; }
	inline int32_t* get_address_of_sInstances_8() { return &___sInstances_8; }
	inline void set_sInstances_8(int32_t value)
	{
		___sInstances_8 = value;
	}

	inline static int32_t get_offset_of_sAddress_13() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086_StaticFields, ___sAddress_13)); }
	inline String_t* get_sAddress_13() const { return ___sAddress_13; }
	inline String_t** get_address_of_sAddress_13() { return &___sAddress_13; }
	inline void set_sAddress_13(String_t* value)
	{
		___sAddress_13 = value;
		Il2CppCodeGenWriteBarrier((&___sAddress_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ONETOMANY_TD2FD726816556B1F8CD9045B5FE9F44C4E00C086_H
#ifndef SIMPLECALL_TAC3DAAD0B3C5CACD29E70007F210F6E373A179AD_H
#define SIMPLECALL_TAC3DAAD0B3C5CACD29E70007F210F6E373A179AD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.SimpleCall
struct  SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Boolean Byn.Unity.Examples.SimpleCall::_Sender
	bool ____Sender_4;
	// UnityEngine.UI.RawImage Byn.Unity.Examples.SimpleCall::_LocalImage
	RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * ____LocalImage_5;
	// UnityEngine.UI.RawImage Byn.Unity.Examples.SimpleCall::_RemoteImage
	RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * ____RemoteImage_6;
	// System.Boolean Byn.Unity.Examples.SimpleCall::_TryI420
	bool ____TryI420_7;
	// Byn.Unity.Examples.SimpleCall_SimpleCallState Byn.Unity.Examples.SimpleCall::mState
	int32_t ___mState_8;
	// Byn.Awrtc.ICall Byn.Unity.Examples.SimpleCall::mCall
	RuntimeObject* ___mCall_9;

public:
	inline static int32_t get_offset_of__Sender_4() { return static_cast<int32_t>(offsetof(SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD, ____Sender_4)); }
	inline bool get__Sender_4() const { return ____Sender_4; }
	inline bool* get_address_of__Sender_4() { return &____Sender_4; }
	inline void set__Sender_4(bool value)
	{
		____Sender_4 = value;
	}

	inline static int32_t get_offset_of__LocalImage_5() { return static_cast<int32_t>(offsetof(SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD, ____LocalImage_5)); }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * get__LocalImage_5() const { return ____LocalImage_5; }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 ** get_address_of__LocalImage_5() { return &____LocalImage_5; }
	inline void set__LocalImage_5(RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * value)
	{
		____LocalImage_5 = value;
		Il2CppCodeGenWriteBarrier((&____LocalImage_5), value);
	}

	inline static int32_t get_offset_of__RemoteImage_6() { return static_cast<int32_t>(offsetof(SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD, ____RemoteImage_6)); }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * get__RemoteImage_6() const { return ____RemoteImage_6; }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 ** get_address_of__RemoteImage_6() { return &____RemoteImage_6; }
	inline void set__RemoteImage_6(RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * value)
	{
		____RemoteImage_6 = value;
		Il2CppCodeGenWriteBarrier((&____RemoteImage_6), value);
	}

	inline static int32_t get_offset_of__TryI420_7() { return static_cast<int32_t>(offsetof(SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD, ____TryI420_7)); }
	inline bool get__TryI420_7() const { return ____TryI420_7; }
	inline bool* get_address_of__TryI420_7() { return &____TryI420_7; }
	inline void set__TryI420_7(bool value)
	{
		____TryI420_7 = value;
	}

	inline static int32_t get_offset_of_mState_8() { return static_cast<int32_t>(offsetof(SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD, ___mState_8)); }
	inline int32_t get_mState_8() const { return ___mState_8; }
	inline int32_t* get_address_of_mState_8() { return &___mState_8; }
	inline void set_mState_8(int32_t value)
	{
		___mState_8 = value;
	}

	inline static int32_t get_offset_of_mCall_9() { return static_cast<int32_t>(offsetof(SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD, ___mCall_9)); }
	inline RuntimeObject* get_mCall_9() const { return ___mCall_9; }
	inline RuntimeObject** get_address_of_mCall_9() { return &___mCall_9; }
	inline void set_mCall_9(RuntimeObject* value)
	{
		___mCall_9 = value;
		Il2CppCodeGenWriteBarrier((&___mCall_9), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SIMPLECALL_TAC3DAAD0B3C5CACD29E70007F210F6E373A179AD_H
#ifndef VIRTUALCAMERA_T3480DEF62386D17D6EC2771DED373229F30D4175_H
#define VIRTUALCAMERA_T3480DEF62386D17D6EC2771DED373229F30D4175_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.VirtualCamera
struct  VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Camera Byn.Unity.Examples.VirtualCamera::_Camera
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ____Camera_4;
	// System.Single Byn.Unity.Examples.VirtualCamera::mLastSample
	float ___mLastSample_5;
	// UnityEngine.Texture2D Byn.Unity.Examples.VirtualCamera::mTexture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___mTexture_6;
	// UnityEngine.RenderTexture Byn.Unity.Examples.VirtualCamera::mRtBuffer
	RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * ___mRtBuffer_7;
	// UnityEngine.UI.RawImage Byn.Unity.Examples.VirtualCamera::_DebugTarget
	RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * ____DebugTarget_8;
	// System.String Byn.Unity.Examples.VirtualCamera::_DeviceName
	String_t* ____DeviceName_9;
	// System.Int32 Byn.Unity.Examples.VirtualCamera::_Fps
	int32_t ____Fps_10;
	// System.Int32 Byn.Unity.Examples.VirtualCamera::_Width
	int32_t ____Width_11;
	// System.Int32 Byn.Unity.Examples.VirtualCamera::_Height
	int32_t ____Height_12;
	// System.String Byn.Unity.Examples.VirtualCamera::mUsedDeviceName
	String_t* ___mUsedDeviceName_13;
	// System.Byte[] Byn.Unity.Examples.VirtualCamera::mByteBuffer
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___mByteBuffer_14;
	// Byn.Awrtc.Native.NativeVideoInput Byn.Unity.Examples.VirtualCamera::mVideoInput
	NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C * ___mVideoInput_15;

public:
	inline static int32_t get_offset_of__Camera_4() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ____Camera_4)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get__Camera_4() const { return ____Camera_4; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of__Camera_4() { return &____Camera_4; }
	inline void set__Camera_4(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		____Camera_4 = value;
		Il2CppCodeGenWriteBarrier((&____Camera_4), value);
	}

	inline static int32_t get_offset_of_mLastSample_5() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ___mLastSample_5)); }
	inline float get_mLastSample_5() const { return ___mLastSample_5; }
	inline float* get_address_of_mLastSample_5() { return &___mLastSample_5; }
	inline void set_mLastSample_5(float value)
	{
		___mLastSample_5 = value;
	}

	inline static int32_t get_offset_of_mTexture_6() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ___mTexture_6)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_mTexture_6() const { return ___mTexture_6; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_mTexture_6() { return &___mTexture_6; }
	inline void set_mTexture_6(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___mTexture_6 = value;
		Il2CppCodeGenWriteBarrier((&___mTexture_6), value);
	}

	inline static int32_t get_offset_of_mRtBuffer_7() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ___mRtBuffer_7)); }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * get_mRtBuffer_7() const { return ___mRtBuffer_7; }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 ** get_address_of_mRtBuffer_7() { return &___mRtBuffer_7; }
	inline void set_mRtBuffer_7(RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * value)
	{
		___mRtBuffer_7 = value;
		Il2CppCodeGenWriteBarrier((&___mRtBuffer_7), value);
	}

	inline static int32_t get_offset_of__DebugTarget_8() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ____DebugTarget_8)); }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * get__DebugTarget_8() const { return ____DebugTarget_8; }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 ** get_address_of__DebugTarget_8() { return &____DebugTarget_8; }
	inline void set__DebugTarget_8(RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * value)
	{
		____DebugTarget_8 = value;
		Il2CppCodeGenWriteBarrier((&____DebugTarget_8), value);
	}

	inline static int32_t get_offset_of__DeviceName_9() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ____DeviceName_9)); }
	inline String_t* get__DeviceName_9() const { return ____DeviceName_9; }
	inline String_t** get_address_of__DeviceName_9() { return &____DeviceName_9; }
	inline void set__DeviceName_9(String_t* value)
	{
		____DeviceName_9 = value;
		Il2CppCodeGenWriteBarrier((&____DeviceName_9), value);
	}

	inline static int32_t get_offset_of__Fps_10() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ____Fps_10)); }
	inline int32_t get__Fps_10() const { return ____Fps_10; }
	inline int32_t* get_address_of__Fps_10() { return &____Fps_10; }
	inline void set__Fps_10(int32_t value)
	{
		____Fps_10 = value;
	}

	inline static int32_t get_offset_of__Width_11() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ____Width_11)); }
	inline int32_t get__Width_11() const { return ____Width_11; }
	inline int32_t* get_address_of__Width_11() { return &____Width_11; }
	inline void set__Width_11(int32_t value)
	{
		____Width_11 = value;
	}

	inline static int32_t get_offset_of__Height_12() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ____Height_12)); }
	inline int32_t get__Height_12() const { return ____Height_12; }
	inline int32_t* get_address_of__Height_12() { return &____Height_12; }
	inline void set__Height_12(int32_t value)
	{
		____Height_12 = value;
	}

	inline static int32_t get_offset_of_mUsedDeviceName_13() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ___mUsedDeviceName_13)); }
	inline String_t* get_mUsedDeviceName_13() const { return ___mUsedDeviceName_13; }
	inline String_t** get_address_of_mUsedDeviceName_13() { return &___mUsedDeviceName_13; }
	inline void set_mUsedDeviceName_13(String_t* value)
	{
		___mUsedDeviceName_13 = value;
		Il2CppCodeGenWriteBarrier((&___mUsedDeviceName_13), value);
	}

	inline static int32_t get_offset_of_mByteBuffer_14() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ___mByteBuffer_14)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get_mByteBuffer_14() const { return ___mByteBuffer_14; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of_mByteBuffer_14() { return &___mByteBuffer_14; }
	inline void set_mByteBuffer_14(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		___mByteBuffer_14 = value;
		Il2CppCodeGenWriteBarrier((&___mByteBuffer_14), value);
	}

	inline static int32_t get_offset_of_mVideoInput_15() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ___mVideoInput_15)); }
	inline NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C * get_mVideoInput_15() const { return ___mVideoInput_15; }
	inline NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C ** get_address_of_mVideoInput_15() { return &___mVideoInput_15; }
	inline void set_mVideoInput_15(NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C * value)
	{
		___mVideoInput_15 = value;
		Il2CppCodeGenWriteBarrier((&___mVideoInput_15), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIRTUALCAMERA_T3480DEF62386D17D6EC2771DED373229F30D4175_H
#ifndef CALLAPP_T4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43_H
#define CALLAPP_T4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// CallApp
struct  CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.String CallApp::uSignalingUrl
	String_t* ___uSignalingUrl_4;
	// System.String CallApp::uSecureSignalingUrl
	String_t* ___uSecureSignalingUrl_5;
	// System.Boolean CallApp::uForceSecureSignaling
	bool ___uForceSecureSignaling_6;
	// System.String CallApp::uIceServer
	String_t* ___uIceServer_7;
	// System.String CallApp::uIceServerUser
	String_t* ___uIceServerUser_8;
	// System.String CallApp::uIceServerPassword
	String_t* ___uIceServerPassword_9;
	// System.String CallApp::uIceServer2
	String_t* ___uIceServer2_10;
	// Byn.Awrtc.ICall CallApp::mCall
	RuntimeObject* ___mCall_12;
	// CallAppUi CallApp::mUi
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * ___mUi_13;
	// Byn.Awrtc.MediaConfig CallApp::mMediaConfig
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___mMediaConfig_14;
	// System.Boolean CallApp::mCallActive
	bool ___mCallActive_15;
	// System.String CallApp::mUseAddress
	String_t* ___mUseAddress_16;
	// Byn.Awrtc.MediaConfig CallApp::mMediaConfigInUse
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___mMediaConfigInUse_17;
	// Byn.Awrtc.ConnectionId CallApp::mRemoteUserId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mRemoteUserId_18;
	// System.Boolean CallApp::mAutoRejoin
	bool ___mAutoRejoin_19;
	// System.Single CallApp::mRejoinTime
	float ___mRejoinTime_20;
	// System.Boolean CallApp::mLocalFrameEvents
	bool ___mLocalFrameEvents_21;

public:
	inline static int32_t get_offset_of_uSignalingUrl_4() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___uSignalingUrl_4)); }
	inline String_t* get_uSignalingUrl_4() const { return ___uSignalingUrl_4; }
	inline String_t** get_address_of_uSignalingUrl_4() { return &___uSignalingUrl_4; }
	inline void set_uSignalingUrl_4(String_t* value)
	{
		___uSignalingUrl_4 = value;
		Il2CppCodeGenWriteBarrier((&___uSignalingUrl_4), value);
	}

	inline static int32_t get_offset_of_uSecureSignalingUrl_5() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___uSecureSignalingUrl_5)); }
	inline String_t* get_uSecureSignalingUrl_5() const { return ___uSecureSignalingUrl_5; }
	inline String_t** get_address_of_uSecureSignalingUrl_5() { return &___uSecureSignalingUrl_5; }
	inline void set_uSecureSignalingUrl_5(String_t* value)
	{
		___uSecureSignalingUrl_5 = value;
		Il2CppCodeGenWriteBarrier((&___uSecureSignalingUrl_5), value);
	}

	inline static int32_t get_offset_of_uForceSecureSignaling_6() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___uForceSecureSignaling_6)); }
	inline bool get_uForceSecureSignaling_6() const { return ___uForceSecureSignaling_6; }
	inline bool* get_address_of_uForceSecureSignaling_6() { return &___uForceSecureSignaling_6; }
	inline void set_uForceSecureSignaling_6(bool value)
	{
		___uForceSecureSignaling_6 = value;
	}

	inline static int32_t get_offset_of_uIceServer_7() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___uIceServer_7)); }
	inline String_t* get_uIceServer_7() const { return ___uIceServer_7; }
	inline String_t** get_address_of_uIceServer_7() { return &___uIceServer_7; }
	inline void set_uIceServer_7(String_t* value)
	{
		___uIceServer_7 = value;
		Il2CppCodeGenWriteBarrier((&___uIceServer_7), value);
	}

	inline static int32_t get_offset_of_uIceServerUser_8() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___uIceServerUser_8)); }
	inline String_t* get_uIceServerUser_8() const { return ___uIceServerUser_8; }
	inline String_t** get_address_of_uIceServerUser_8() { return &___uIceServerUser_8; }
	inline void set_uIceServerUser_8(String_t* value)
	{
		___uIceServerUser_8 = value;
		Il2CppCodeGenWriteBarrier((&___uIceServerUser_8), value);
	}

	inline static int32_t get_offset_of_uIceServerPassword_9() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___uIceServerPassword_9)); }
	inline String_t* get_uIceServerPassword_9() const { return ___uIceServerPassword_9; }
	inline String_t** get_address_of_uIceServerPassword_9() { return &___uIceServerPassword_9; }
	inline void set_uIceServerPassword_9(String_t* value)
	{
		___uIceServerPassword_9 = value;
		Il2CppCodeGenWriteBarrier((&___uIceServerPassword_9), value);
	}

	inline static int32_t get_offset_of_uIceServer2_10() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___uIceServer2_10)); }
	inline String_t* get_uIceServer2_10() const { return ___uIceServer2_10; }
	inline String_t** get_address_of_uIceServer2_10() { return &___uIceServer2_10; }
	inline void set_uIceServer2_10(String_t* value)
	{
		___uIceServer2_10 = value;
		Il2CppCodeGenWriteBarrier((&___uIceServer2_10), value);
	}

	inline static int32_t get_offset_of_mCall_12() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mCall_12)); }
	inline RuntimeObject* get_mCall_12() const { return ___mCall_12; }
	inline RuntimeObject** get_address_of_mCall_12() { return &___mCall_12; }
	inline void set_mCall_12(RuntimeObject* value)
	{
		___mCall_12 = value;
		Il2CppCodeGenWriteBarrier((&___mCall_12), value);
	}

	inline static int32_t get_offset_of_mUi_13() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mUi_13)); }
	inline CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * get_mUi_13() const { return ___mUi_13; }
	inline CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 ** get_address_of_mUi_13() { return &___mUi_13; }
	inline void set_mUi_13(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * value)
	{
		___mUi_13 = value;
		Il2CppCodeGenWriteBarrier((&___mUi_13), value);
	}

	inline static int32_t get_offset_of_mMediaConfig_14() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mMediaConfig_14)); }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * get_mMediaConfig_14() const { return ___mMediaConfig_14; }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D ** get_address_of_mMediaConfig_14() { return &___mMediaConfig_14; }
	inline void set_mMediaConfig_14(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * value)
	{
		___mMediaConfig_14 = value;
		Il2CppCodeGenWriteBarrier((&___mMediaConfig_14), value);
	}

	inline static int32_t get_offset_of_mCallActive_15() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mCallActive_15)); }
	inline bool get_mCallActive_15() const { return ___mCallActive_15; }
	inline bool* get_address_of_mCallActive_15() { return &___mCallActive_15; }
	inline void set_mCallActive_15(bool value)
	{
		___mCallActive_15 = value;
	}

	inline static int32_t get_offset_of_mUseAddress_16() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mUseAddress_16)); }
	inline String_t* get_mUseAddress_16() const { return ___mUseAddress_16; }
	inline String_t** get_address_of_mUseAddress_16() { return &___mUseAddress_16; }
	inline void set_mUseAddress_16(String_t* value)
	{
		___mUseAddress_16 = value;
		Il2CppCodeGenWriteBarrier((&___mUseAddress_16), value);
	}

	inline static int32_t get_offset_of_mMediaConfigInUse_17() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mMediaConfigInUse_17)); }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * get_mMediaConfigInUse_17() const { return ___mMediaConfigInUse_17; }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D ** get_address_of_mMediaConfigInUse_17() { return &___mMediaConfigInUse_17; }
	inline void set_mMediaConfigInUse_17(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * value)
	{
		___mMediaConfigInUse_17 = value;
		Il2CppCodeGenWriteBarrier((&___mMediaConfigInUse_17), value);
	}

	inline static int32_t get_offset_of_mRemoteUserId_18() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mRemoteUserId_18)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mRemoteUserId_18() const { return ___mRemoteUserId_18; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mRemoteUserId_18() { return &___mRemoteUserId_18; }
	inline void set_mRemoteUserId_18(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mRemoteUserId_18 = value;
	}

	inline static int32_t get_offset_of_mAutoRejoin_19() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mAutoRejoin_19)); }
	inline bool get_mAutoRejoin_19() const { return ___mAutoRejoin_19; }
	inline bool* get_address_of_mAutoRejoin_19() { return &___mAutoRejoin_19; }
	inline void set_mAutoRejoin_19(bool value)
	{
		___mAutoRejoin_19 = value;
	}

	inline static int32_t get_offset_of_mRejoinTime_20() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mRejoinTime_20)); }
	inline float get_mRejoinTime_20() const { return ___mRejoinTime_20; }
	inline float* get_address_of_mRejoinTime_20() { return &___mRejoinTime_20; }
	inline void set_mRejoinTime_20(float value)
	{
		___mRejoinTime_20 = value;
	}

	inline static int32_t get_offset_of_mLocalFrameEvents_21() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mLocalFrameEvents_21)); }
	inline bool get_mLocalFrameEvents_21() const { return ___mLocalFrameEvents_21; }
	inline bool* get_address_of_mLocalFrameEvents_21() { return &___mLocalFrameEvents_21; }
	inline void set_mLocalFrameEvents_21(bool value)
	{
		___mLocalFrameEvents_21 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLAPP_T4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43_H
#ifndef CALLAPPUI_TACD06D4561F5F727B12FC86E8F703D58DC811867_H
#define CALLAPPUI_TACD06D4561F5F727B12FC86E8F703D58DC811867_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// CallAppUi
struct  CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Texture2D CallAppUi::mLocalVideoTexture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___mLocalVideoTexture_4;
	// UnityEngine.Texture2D CallAppUi::mRemoteVideoTexture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___mRemoteVideoTexture_5;
	// UnityEngine.RectTransform CallAppUi::uSetupPanel
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___uSetupPanel_6;
	// UnityEngine.RectTransform CallAppUi::uMainSetupPanel
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___uMainSetupPanel_7;
	// UnityEngine.UI.InputField CallAppUi::uRoomNameInputField
	InputField_t533609195B110760BCFF00B746C87D81969CB005 * ___uRoomNameInputField_8;
	// UnityEngine.UI.Button CallAppUi::uJoinButton
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uJoinButton_9;
	// UnityEngine.UI.Toggle CallAppUi::uAudioToggle
	Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * ___uAudioToggle_10;
	// UnityEngine.UI.Toggle CallAppUi::uVideoToggle
	Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * ___uVideoToggle_11;
	// UnityEngine.UI.Dropdown CallAppUi::uVideoDropdown
	Dropdown_tF6331401084B1213CAB10587A6EC81461501930F * ___uVideoDropdown_12;
	// UnityEngine.RectTransform CallAppUi::uSettingsPanel
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___uSettingsPanel_13;
	// UnityEngine.UI.InputField CallAppUi::uIdealWidth
	InputField_t533609195B110760BCFF00B746C87D81969CB005 * ___uIdealWidth_14;
	// UnityEngine.UI.InputField CallAppUi::uIdealHeight
	InputField_t533609195B110760BCFF00B746C87D81969CB005 * ___uIdealHeight_15;
	// UnityEngine.UI.InputField CallAppUi::uIdealFps
	InputField_t533609195B110760BCFF00B746C87D81969CB005 * ___uIdealFps_16;
	// UnityEngine.UI.Toggle CallAppUi::uRejoinToggle
	Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * ___uRejoinToggle_17;
	// UnityEngine.UI.Toggle CallAppUi::uLocalVideoToggle
	Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * ___uLocalVideoToggle_18;
	// UnityEngine.RectTransform CallAppUi::uInCallBase
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___uInCallBase_19;
	// UnityEngine.RectTransform CallAppUi::uVideoPanel
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___uVideoPanel_20;
	// UnityEngine.RectTransform CallAppUi::uChatPanel
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___uChatPanel_21;
	// UnityEngine.RectTransform CallAppUi::uVideoOverlay
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___uVideoOverlay_22;
	// UnityEngine.RectTransform CallAppUi::uVideoBase
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___uVideoBase_23;
	// UnityEngine.RectTransform CallAppUi::uChatBase
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___uChatBase_24;
	// UnityEngine.RectTransform CallAppUi::uFullscreenPanel
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___uFullscreenPanel_25;
	// UnityEngine.RectTransform CallAppUi::uVideoBaseFullscreen
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___uVideoBaseFullscreen_26;
	// UnityEngine.RectTransform CallAppUi::uChatBaseFullscreen
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___uChatBaseFullscreen_27;
	// UnityEngine.UI.InputField CallAppUi::uMessageInputField
	InputField_t533609195B110760BCFF00B746C87D81969CB005 * ___uMessageInputField_28;
	// MessageList CallAppUi::uMessageOutput
	MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC * ___uMessageOutput_29;
	// UnityEngine.UI.Button CallAppUi::uSendMessageButton
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uSendMessageButton_30;
	// UnityEngine.UI.Button CallAppUi::uShutdownButton
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uShutdownButton_31;
	// UnityEngine.UI.Toggle CallAppUi::uMuteToggle
	Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * ___uMuteToggle_32;
	// UnityEngine.UI.Toggle CallAppUi::uLoudspeakerToggle
	Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * ___uLoudspeakerToggle_33;
	// UnityEngine.UI.Slider CallAppUi::uVolumeSlider
	Slider_t0654A41304B5CE7074CA86F4E66CB681D0D52C09 * ___uVolumeSlider_34;
	// UnityEngine.UI.Text CallAppUi::uOverlayInfo
	Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * ___uOverlayInfo_35;
	// UnityEngine.UI.RawImage CallAppUi::uLocalVideoImage
	RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * ___uLocalVideoImage_36;
	// UnityEngine.UI.RawImage CallAppUi::uRemoteVideoImage
	RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * ___uRemoteVideoImage_37;
	// UnityEngine.Texture2D CallAppUi::uNoCameraTexture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___uNoCameraTexture_38;
	// System.Boolean CallAppUi::mFullscreen
	bool ___mFullscreen_39;
	// CallApp CallAppUi::mApp
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43 * ___mApp_40;
	// System.Single CallAppUi::mVideoOverlayTimeout
	float ___mVideoOverlayTimeout_41;
	// System.Boolean CallAppUi::mHasLocalVideo
	bool ___mHasLocalVideo_43;
	// System.Int32 CallAppUi::mLocalVideoWidth
	int32_t ___mLocalVideoWidth_44;
	// System.Int32 CallAppUi::mLocalVideoHeight
	int32_t ___mLocalVideoHeight_45;
	// System.Int32 CallAppUi::mLocalFps
	int32_t ___mLocalFps_46;
	// System.Int32 CallAppUi::mLocalFrameCounter
	int32_t ___mLocalFrameCounter_47;
	// System.Int32 CallAppUi::mLocalRotation
	int32_t ___mLocalRotation_48;
	// Byn.Awrtc.FramePixelFormat CallAppUi::mLocalVideoFormat
	int32_t ___mLocalVideoFormat_49;
	// System.Boolean CallAppUi::mHasRemoteVideo
	bool ___mHasRemoteVideo_50;
	// System.Int32 CallAppUi::mRemoteVideoWidth
	int32_t ___mRemoteVideoWidth_51;
	// System.Int32 CallAppUi::mRemoteVideoHeight
	int32_t ___mRemoteVideoHeight_52;
	// System.Int32 CallAppUi::mRemoteFps
	int32_t ___mRemoteFps_53;
	// System.Int32 CallAppUi::mRemoteRotation
	int32_t ___mRemoteRotation_54;
	// System.Int32 CallAppUi::mRemoteFrameCounter
	int32_t ___mRemoteFrameCounter_55;
	// Byn.Awrtc.FramePixelFormat CallAppUi::mRemoteVideoFormat
	int32_t ___mRemoteVideoFormat_56;
	// System.Single CallAppUi::mFpsTimer
	float ___mFpsTimer_57;
	// System.String CallAppUi::mPrefix
	String_t* ___mPrefix_58;
	// System.Boolean CallAppUi::uLoadSettings
	bool ___uLoadSettings_68;
	// System.String CallAppUi::mStoredVideoDevice
	String_t* ___mStoredVideoDevice_69;

public:
	inline static int32_t get_offset_of_mLocalVideoTexture_4() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mLocalVideoTexture_4)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_mLocalVideoTexture_4() const { return ___mLocalVideoTexture_4; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_mLocalVideoTexture_4() { return &___mLocalVideoTexture_4; }
	inline void set_mLocalVideoTexture_4(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___mLocalVideoTexture_4 = value;
		Il2CppCodeGenWriteBarrier((&___mLocalVideoTexture_4), value);
	}

	inline static int32_t get_offset_of_mRemoteVideoTexture_5() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mRemoteVideoTexture_5)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_mRemoteVideoTexture_5() const { return ___mRemoteVideoTexture_5; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_mRemoteVideoTexture_5() { return &___mRemoteVideoTexture_5; }
	inline void set_mRemoteVideoTexture_5(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___mRemoteVideoTexture_5 = value;
		Il2CppCodeGenWriteBarrier((&___mRemoteVideoTexture_5), value);
	}

	inline static int32_t get_offset_of_uSetupPanel_6() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uSetupPanel_6)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_uSetupPanel_6() const { return ___uSetupPanel_6; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_uSetupPanel_6() { return &___uSetupPanel_6; }
	inline void set_uSetupPanel_6(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___uSetupPanel_6 = value;
		Il2CppCodeGenWriteBarrier((&___uSetupPanel_6), value);
	}

	inline static int32_t get_offset_of_uMainSetupPanel_7() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uMainSetupPanel_7)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_uMainSetupPanel_7() const { return ___uMainSetupPanel_7; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_uMainSetupPanel_7() { return &___uMainSetupPanel_7; }
	inline void set_uMainSetupPanel_7(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___uMainSetupPanel_7 = value;
		Il2CppCodeGenWriteBarrier((&___uMainSetupPanel_7), value);
	}

	inline static int32_t get_offset_of_uRoomNameInputField_8() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uRoomNameInputField_8)); }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 * get_uRoomNameInputField_8() const { return ___uRoomNameInputField_8; }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 ** get_address_of_uRoomNameInputField_8() { return &___uRoomNameInputField_8; }
	inline void set_uRoomNameInputField_8(InputField_t533609195B110760BCFF00B746C87D81969CB005 * value)
	{
		___uRoomNameInputField_8 = value;
		Il2CppCodeGenWriteBarrier((&___uRoomNameInputField_8), value);
	}

	inline static int32_t get_offset_of_uJoinButton_9() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uJoinButton_9)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uJoinButton_9() const { return ___uJoinButton_9; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uJoinButton_9() { return &___uJoinButton_9; }
	inline void set_uJoinButton_9(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uJoinButton_9 = value;
		Il2CppCodeGenWriteBarrier((&___uJoinButton_9), value);
	}

	inline static int32_t get_offset_of_uAudioToggle_10() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uAudioToggle_10)); }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * get_uAudioToggle_10() const { return ___uAudioToggle_10; }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 ** get_address_of_uAudioToggle_10() { return &___uAudioToggle_10; }
	inline void set_uAudioToggle_10(Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * value)
	{
		___uAudioToggle_10 = value;
		Il2CppCodeGenWriteBarrier((&___uAudioToggle_10), value);
	}

	inline static int32_t get_offset_of_uVideoToggle_11() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uVideoToggle_11)); }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * get_uVideoToggle_11() const { return ___uVideoToggle_11; }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 ** get_address_of_uVideoToggle_11() { return &___uVideoToggle_11; }
	inline void set_uVideoToggle_11(Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * value)
	{
		___uVideoToggle_11 = value;
		Il2CppCodeGenWriteBarrier((&___uVideoToggle_11), value);
	}

	inline static int32_t get_offset_of_uVideoDropdown_12() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uVideoDropdown_12)); }
	inline Dropdown_tF6331401084B1213CAB10587A6EC81461501930F * get_uVideoDropdown_12() const { return ___uVideoDropdown_12; }
	inline Dropdown_tF6331401084B1213CAB10587A6EC81461501930F ** get_address_of_uVideoDropdown_12() { return &___uVideoDropdown_12; }
	inline void set_uVideoDropdown_12(Dropdown_tF6331401084B1213CAB10587A6EC81461501930F * value)
	{
		___uVideoDropdown_12 = value;
		Il2CppCodeGenWriteBarrier((&___uVideoDropdown_12), value);
	}

	inline static int32_t get_offset_of_uSettingsPanel_13() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uSettingsPanel_13)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_uSettingsPanel_13() const { return ___uSettingsPanel_13; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_uSettingsPanel_13() { return &___uSettingsPanel_13; }
	inline void set_uSettingsPanel_13(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___uSettingsPanel_13 = value;
		Il2CppCodeGenWriteBarrier((&___uSettingsPanel_13), value);
	}

	inline static int32_t get_offset_of_uIdealWidth_14() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uIdealWidth_14)); }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 * get_uIdealWidth_14() const { return ___uIdealWidth_14; }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 ** get_address_of_uIdealWidth_14() { return &___uIdealWidth_14; }
	inline void set_uIdealWidth_14(InputField_t533609195B110760BCFF00B746C87D81969CB005 * value)
	{
		___uIdealWidth_14 = value;
		Il2CppCodeGenWriteBarrier((&___uIdealWidth_14), value);
	}

	inline static int32_t get_offset_of_uIdealHeight_15() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uIdealHeight_15)); }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 * get_uIdealHeight_15() const { return ___uIdealHeight_15; }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 ** get_address_of_uIdealHeight_15() { return &___uIdealHeight_15; }
	inline void set_uIdealHeight_15(InputField_t533609195B110760BCFF00B746C87D81969CB005 * value)
	{
		___uIdealHeight_15 = value;
		Il2CppCodeGenWriteBarrier((&___uIdealHeight_15), value);
	}

	inline static int32_t get_offset_of_uIdealFps_16() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uIdealFps_16)); }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 * get_uIdealFps_16() const { return ___uIdealFps_16; }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 ** get_address_of_uIdealFps_16() { return &___uIdealFps_16; }
	inline void set_uIdealFps_16(InputField_t533609195B110760BCFF00B746C87D81969CB005 * value)
	{
		___uIdealFps_16 = value;
		Il2CppCodeGenWriteBarrier((&___uIdealFps_16), value);
	}

	inline static int32_t get_offset_of_uRejoinToggle_17() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uRejoinToggle_17)); }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * get_uRejoinToggle_17() const { return ___uRejoinToggle_17; }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 ** get_address_of_uRejoinToggle_17() { return &___uRejoinToggle_17; }
	inline void set_uRejoinToggle_17(Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * value)
	{
		___uRejoinToggle_17 = value;
		Il2CppCodeGenWriteBarrier((&___uRejoinToggle_17), value);
	}

	inline static int32_t get_offset_of_uLocalVideoToggle_18() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uLocalVideoToggle_18)); }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * get_uLocalVideoToggle_18() const { return ___uLocalVideoToggle_18; }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 ** get_address_of_uLocalVideoToggle_18() { return &___uLocalVideoToggle_18; }
	inline void set_uLocalVideoToggle_18(Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * value)
	{
		___uLocalVideoToggle_18 = value;
		Il2CppCodeGenWriteBarrier((&___uLocalVideoToggle_18), value);
	}

	inline static int32_t get_offset_of_uInCallBase_19() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uInCallBase_19)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_uInCallBase_19() const { return ___uInCallBase_19; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_uInCallBase_19() { return &___uInCallBase_19; }
	inline void set_uInCallBase_19(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___uInCallBase_19 = value;
		Il2CppCodeGenWriteBarrier((&___uInCallBase_19), value);
	}

	inline static int32_t get_offset_of_uVideoPanel_20() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uVideoPanel_20)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_uVideoPanel_20() const { return ___uVideoPanel_20; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_uVideoPanel_20() { return &___uVideoPanel_20; }
	inline void set_uVideoPanel_20(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___uVideoPanel_20 = value;
		Il2CppCodeGenWriteBarrier((&___uVideoPanel_20), value);
	}

	inline static int32_t get_offset_of_uChatPanel_21() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uChatPanel_21)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_uChatPanel_21() const { return ___uChatPanel_21; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_uChatPanel_21() { return &___uChatPanel_21; }
	inline void set_uChatPanel_21(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___uChatPanel_21 = value;
		Il2CppCodeGenWriteBarrier((&___uChatPanel_21), value);
	}

	inline static int32_t get_offset_of_uVideoOverlay_22() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uVideoOverlay_22)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_uVideoOverlay_22() const { return ___uVideoOverlay_22; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_uVideoOverlay_22() { return &___uVideoOverlay_22; }
	inline void set_uVideoOverlay_22(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___uVideoOverlay_22 = value;
		Il2CppCodeGenWriteBarrier((&___uVideoOverlay_22), value);
	}

	inline static int32_t get_offset_of_uVideoBase_23() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uVideoBase_23)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_uVideoBase_23() const { return ___uVideoBase_23; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_uVideoBase_23() { return &___uVideoBase_23; }
	inline void set_uVideoBase_23(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___uVideoBase_23 = value;
		Il2CppCodeGenWriteBarrier((&___uVideoBase_23), value);
	}

	inline static int32_t get_offset_of_uChatBase_24() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uChatBase_24)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_uChatBase_24() const { return ___uChatBase_24; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_uChatBase_24() { return &___uChatBase_24; }
	inline void set_uChatBase_24(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___uChatBase_24 = value;
		Il2CppCodeGenWriteBarrier((&___uChatBase_24), value);
	}

	inline static int32_t get_offset_of_uFullscreenPanel_25() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uFullscreenPanel_25)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_uFullscreenPanel_25() const { return ___uFullscreenPanel_25; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_uFullscreenPanel_25() { return &___uFullscreenPanel_25; }
	inline void set_uFullscreenPanel_25(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___uFullscreenPanel_25 = value;
		Il2CppCodeGenWriteBarrier((&___uFullscreenPanel_25), value);
	}

	inline static int32_t get_offset_of_uVideoBaseFullscreen_26() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uVideoBaseFullscreen_26)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_uVideoBaseFullscreen_26() const { return ___uVideoBaseFullscreen_26; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_uVideoBaseFullscreen_26() { return &___uVideoBaseFullscreen_26; }
	inline void set_uVideoBaseFullscreen_26(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___uVideoBaseFullscreen_26 = value;
		Il2CppCodeGenWriteBarrier((&___uVideoBaseFullscreen_26), value);
	}

	inline static int32_t get_offset_of_uChatBaseFullscreen_27() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uChatBaseFullscreen_27)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_uChatBaseFullscreen_27() const { return ___uChatBaseFullscreen_27; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_uChatBaseFullscreen_27() { return &___uChatBaseFullscreen_27; }
	inline void set_uChatBaseFullscreen_27(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___uChatBaseFullscreen_27 = value;
		Il2CppCodeGenWriteBarrier((&___uChatBaseFullscreen_27), value);
	}

	inline static int32_t get_offset_of_uMessageInputField_28() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uMessageInputField_28)); }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 * get_uMessageInputField_28() const { return ___uMessageInputField_28; }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 ** get_address_of_uMessageInputField_28() { return &___uMessageInputField_28; }
	inline void set_uMessageInputField_28(InputField_t533609195B110760BCFF00B746C87D81969CB005 * value)
	{
		___uMessageInputField_28 = value;
		Il2CppCodeGenWriteBarrier((&___uMessageInputField_28), value);
	}

	inline static int32_t get_offset_of_uMessageOutput_29() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uMessageOutput_29)); }
	inline MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC * get_uMessageOutput_29() const { return ___uMessageOutput_29; }
	inline MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC ** get_address_of_uMessageOutput_29() { return &___uMessageOutput_29; }
	inline void set_uMessageOutput_29(MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC * value)
	{
		___uMessageOutput_29 = value;
		Il2CppCodeGenWriteBarrier((&___uMessageOutput_29), value);
	}

	inline static int32_t get_offset_of_uSendMessageButton_30() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uSendMessageButton_30)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uSendMessageButton_30() const { return ___uSendMessageButton_30; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uSendMessageButton_30() { return &___uSendMessageButton_30; }
	inline void set_uSendMessageButton_30(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uSendMessageButton_30 = value;
		Il2CppCodeGenWriteBarrier((&___uSendMessageButton_30), value);
	}

	inline static int32_t get_offset_of_uShutdownButton_31() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uShutdownButton_31)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uShutdownButton_31() const { return ___uShutdownButton_31; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uShutdownButton_31() { return &___uShutdownButton_31; }
	inline void set_uShutdownButton_31(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uShutdownButton_31 = value;
		Il2CppCodeGenWriteBarrier((&___uShutdownButton_31), value);
	}

	inline static int32_t get_offset_of_uMuteToggle_32() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uMuteToggle_32)); }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * get_uMuteToggle_32() const { return ___uMuteToggle_32; }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 ** get_address_of_uMuteToggle_32() { return &___uMuteToggle_32; }
	inline void set_uMuteToggle_32(Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * value)
	{
		___uMuteToggle_32 = value;
		Il2CppCodeGenWriteBarrier((&___uMuteToggle_32), value);
	}

	inline static int32_t get_offset_of_uLoudspeakerToggle_33() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uLoudspeakerToggle_33)); }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * get_uLoudspeakerToggle_33() const { return ___uLoudspeakerToggle_33; }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 ** get_address_of_uLoudspeakerToggle_33() { return &___uLoudspeakerToggle_33; }
	inline void set_uLoudspeakerToggle_33(Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * value)
	{
		___uLoudspeakerToggle_33 = value;
		Il2CppCodeGenWriteBarrier((&___uLoudspeakerToggle_33), value);
	}

	inline static int32_t get_offset_of_uVolumeSlider_34() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uVolumeSlider_34)); }
	inline Slider_t0654A41304B5CE7074CA86F4E66CB681D0D52C09 * get_uVolumeSlider_34() const { return ___uVolumeSlider_34; }
	inline Slider_t0654A41304B5CE7074CA86F4E66CB681D0D52C09 ** get_address_of_uVolumeSlider_34() { return &___uVolumeSlider_34; }
	inline void set_uVolumeSlider_34(Slider_t0654A41304B5CE7074CA86F4E66CB681D0D52C09 * value)
	{
		___uVolumeSlider_34 = value;
		Il2CppCodeGenWriteBarrier((&___uVolumeSlider_34), value);
	}

	inline static int32_t get_offset_of_uOverlayInfo_35() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uOverlayInfo_35)); }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * get_uOverlayInfo_35() const { return ___uOverlayInfo_35; }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 ** get_address_of_uOverlayInfo_35() { return &___uOverlayInfo_35; }
	inline void set_uOverlayInfo_35(Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * value)
	{
		___uOverlayInfo_35 = value;
		Il2CppCodeGenWriteBarrier((&___uOverlayInfo_35), value);
	}

	inline static int32_t get_offset_of_uLocalVideoImage_36() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uLocalVideoImage_36)); }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * get_uLocalVideoImage_36() const { return ___uLocalVideoImage_36; }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 ** get_address_of_uLocalVideoImage_36() { return &___uLocalVideoImage_36; }
	inline void set_uLocalVideoImage_36(RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * value)
	{
		___uLocalVideoImage_36 = value;
		Il2CppCodeGenWriteBarrier((&___uLocalVideoImage_36), value);
	}

	inline static int32_t get_offset_of_uRemoteVideoImage_37() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uRemoteVideoImage_37)); }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * get_uRemoteVideoImage_37() const { return ___uRemoteVideoImage_37; }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 ** get_address_of_uRemoteVideoImage_37() { return &___uRemoteVideoImage_37; }
	inline void set_uRemoteVideoImage_37(RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * value)
	{
		___uRemoteVideoImage_37 = value;
		Il2CppCodeGenWriteBarrier((&___uRemoteVideoImage_37), value);
	}

	inline static int32_t get_offset_of_uNoCameraTexture_38() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uNoCameraTexture_38)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_uNoCameraTexture_38() const { return ___uNoCameraTexture_38; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_uNoCameraTexture_38() { return &___uNoCameraTexture_38; }
	inline void set_uNoCameraTexture_38(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___uNoCameraTexture_38 = value;
		Il2CppCodeGenWriteBarrier((&___uNoCameraTexture_38), value);
	}

	inline static int32_t get_offset_of_mFullscreen_39() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mFullscreen_39)); }
	inline bool get_mFullscreen_39() const { return ___mFullscreen_39; }
	inline bool* get_address_of_mFullscreen_39() { return &___mFullscreen_39; }
	inline void set_mFullscreen_39(bool value)
	{
		___mFullscreen_39 = value;
	}

	inline static int32_t get_offset_of_mApp_40() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mApp_40)); }
	inline CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43 * get_mApp_40() const { return ___mApp_40; }
	inline CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43 ** get_address_of_mApp_40() { return &___mApp_40; }
	inline void set_mApp_40(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43 * value)
	{
		___mApp_40 = value;
		Il2CppCodeGenWriteBarrier((&___mApp_40), value);
	}

	inline static int32_t get_offset_of_mVideoOverlayTimeout_41() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mVideoOverlayTimeout_41)); }
	inline float get_mVideoOverlayTimeout_41() const { return ___mVideoOverlayTimeout_41; }
	inline float* get_address_of_mVideoOverlayTimeout_41() { return &___mVideoOverlayTimeout_41; }
	inline void set_mVideoOverlayTimeout_41(float value)
	{
		___mVideoOverlayTimeout_41 = value;
	}

	inline static int32_t get_offset_of_mHasLocalVideo_43() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mHasLocalVideo_43)); }
	inline bool get_mHasLocalVideo_43() const { return ___mHasLocalVideo_43; }
	inline bool* get_address_of_mHasLocalVideo_43() { return &___mHasLocalVideo_43; }
	inline void set_mHasLocalVideo_43(bool value)
	{
		___mHasLocalVideo_43 = value;
	}

	inline static int32_t get_offset_of_mLocalVideoWidth_44() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mLocalVideoWidth_44)); }
	inline int32_t get_mLocalVideoWidth_44() const { return ___mLocalVideoWidth_44; }
	inline int32_t* get_address_of_mLocalVideoWidth_44() { return &___mLocalVideoWidth_44; }
	inline void set_mLocalVideoWidth_44(int32_t value)
	{
		___mLocalVideoWidth_44 = value;
	}

	inline static int32_t get_offset_of_mLocalVideoHeight_45() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mLocalVideoHeight_45)); }
	inline int32_t get_mLocalVideoHeight_45() const { return ___mLocalVideoHeight_45; }
	inline int32_t* get_address_of_mLocalVideoHeight_45() { return &___mLocalVideoHeight_45; }
	inline void set_mLocalVideoHeight_45(int32_t value)
	{
		___mLocalVideoHeight_45 = value;
	}

	inline static int32_t get_offset_of_mLocalFps_46() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mLocalFps_46)); }
	inline int32_t get_mLocalFps_46() const { return ___mLocalFps_46; }
	inline int32_t* get_address_of_mLocalFps_46() { return &___mLocalFps_46; }
	inline void set_mLocalFps_46(int32_t value)
	{
		___mLocalFps_46 = value;
	}

	inline static int32_t get_offset_of_mLocalFrameCounter_47() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mLocalFrameCounter_47)); }
	inline int32_t get_mLocalFrameCounter_47() const { return ___mLocalFrameCounter_47; }
	inline int32_t* get_address_of_mLocalFrameCounter_47() { return &___mLocalFrameCounter_47; }
	inline void set_mLocalFrameCounter_47(int32_t value)
	{
		___mLocalFrameCounter_47 = value;
	}

	inline static int32_t get_offset_of_mLocalRotation_48() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mLocalRotation_48)); }
	inline int32_t get_mLocalRotation_48() const { return ___mLocalRotation_48; }
	inline int32_t* get_address_of_mLocalRotation_48() { return &___mLocalRotation_48; }
	inline void set_mLocalRotation_48(int32_t value)
	{
		___mLocalRotation_48 = value;
	}

	inline static int32_t get_offset_of_mLocalVideoFormat_49() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mLocalVideoFormat_49)); }
	inline int32_t get_mLocalVideoFormat_49() const { return ___mLocalVideoFormat_49; }
	inline int32_t* get_address_of_mLocalVideoFormat_49() { return &___mLocalVideoFormat_49; }
	inline void set_mLocalVideoFormat_49(int32_t value)
	{
		___mLocalVideoFormat_49 = value;
	}

	inline static int32_t get_offset_of_mHasRemoteVideo_50() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mHasRemoteVideo_50)); }
	inline bool get_mHasRemoteVideo_50() const { return ___mHasRemoteVideo_50; }
	inline bool* get_address_of_mHasRemoteVideo_50() { return &___mHasRemoteVideo_50; }
	inline void set_mHasRemoteVideo_50(bool value)
	{
		___mHasRemoteVideo_50 = value;
	}

	inline static int32_t get_offset_of_mRemoteVideoWidth_51() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mRemoteVideoWidth_51)); }
	inline int32_t get_mRemoteVideoWidth_51() const { return ___mRemoteVideoWidth_51; }
	inline int32_t* get_address_of_mRemoteVideoWidth_51() { return &___mRemoteVideoWidth_51; }
	inline void set_mRemoteVideoWidth_51(int32_t value)
	{
		___mRemoteVideoWidth_51 = value;
	}

	inline static int32_t get_offset_of_mRemoteVideoHeight_52() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mRemoteVideoHeight_52)); }
	inline int32_t get_mRemoteVideoHeight_52() const { return ___mRemoteVideoHeight_52; }
	inline int32_t* get_address_of_mRemoteVideoHeight_52() { return &___mRemoteVideoHeight_52; }
	inline void set_mRemoteVideoHeight_52(int32_t value)
	{
		___mRemoteVideoHeight_52 = value;
	}

	inline static int32_t get_offset_of_mRemoteFps_53() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mRemoteFps_53)); }
	inline int32_t get_mRemoteFps_53() const { return ___mRemoteFps_53; }
	inline int32_t* get_address_of_mRemoteFps_53() { return &___mRemoteFps_53; }
	inline void set_mRemoteFps_53(int32_t value)
	{
		___mRemoteFps_53 = value;
	}

	inline static int32_t get_offset_of_mRemoteRotation_54() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mRemoteRotation_54)); }
	inline int32_t get_mRemoteRotation_54() const { return ___mRemoteRotation_54; }
	inline int32_t* get_address_of_mRemoteRotation_54() { return &___mRemoteRotation_54; }
	inline void set_mRemoteRotation_54(int32_t value)
	{
		___mRemoteRotation_54 = value;
	}

	inline static int32_t get_offset_of_mRemoteFrameCounter_55() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mRemoteFrameCounter_55)); }
	inline int32_t get_mRemoteFrameCounter_55() const { return ___mRemoteFrameCounter_55; }
	inline int32_t* get_address_of_mRemoteFrameCounter_55() { return &___mRemoteFrameCounter_55; }
	inline void set_mRemoteFrameCounter_55(int32_t value)
	{
		___mRemoteFrameCounter_55 = value;
	}

	inline static int32_t get_offset_of_mRemoteVideoFormat_56() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mRemoteVideoFormat_56)); }
	inline int32_t get_mRemoteVideoFormat_56() const { return ___mRemoteVideoFormat_56; }
	inline int32_t* get_address_of_mRemoteVideoFormat_56() { return &___mRemoteVideoFormat_56; }
	inline void set_mRemoteVideoFormat_56(int32_t value)
	{
		___mRemoteVideoFormat_56 = value;
	}

	inline static int32_t get_offset_of_mFpsTimer_57() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mFpsTimer_57)); }
	inline float get_mFpsTimer_57() const { return ___mFpsTimer_57; }
	inline float* get_address_of_mFpsTimer_57() { return &___mFpsTimer_57; }
	inline void set_mFpsTimer_57(float value)
	{
		___mFpsTimer_57 = value;
	}

	inline static int32_t get_offset_of_mPrefix_58() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mPrefix_58)); }
	inline String_t* get_mPrefix_58() const { return ___mPrefix_58; }
	inline String_t** get_address_of_mPrefix_58() { return &___mPrefix_58; }
	inline void set_mPrefix_58(String_t* value)
	{
		___mPrefix_58 = value;
		Il2CppCodeGenWriteBarrier((&___mPrefix_58), value);
	}

	inline static int32_t get_offset_of_uLoadSettings_68() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uLoadSettings_68)); }
	inline bool get_uLoadSettings_68() const { return ___uLoadSettings_68; }
	inline bool* get_address_of_uLoadSettings_68() { return &___uLoadSettings_68; }
	inline void set_uLoadSettings_68(bool value)
	{
		___uLoadSettings_68 = value;
	}

	inline static int32_t get_offset_of_mStoredVideoDevice_69() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mStoredVideoDevice_69)); }
	inline String_t* get_mStoredVideoDevice_69() const { return ___mStoredVideoDevice_69; }
	inline String_t** get_address_of_mStoredVideoDevice_69() { return &___mStoredVideoDevice_69; }
	inline void set_mStoredVideoDevice_69(String_t* value)
	{
		___mStoredVideoDevice_69 = value;
		Il2CppCodeGenWriteBarrier((&___mStoredVideoDevice_69), value);
	}
};

struct CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields
{
public:
	// System.Single CallAppUi::sDefaultOverlayTimeout
	float ___sDefaultOverlayTimeout_42;
	// System.String CallAppUi::PREF_AUDIO
	String_t* ___PREF_AUDIO_59;
	// System.String CallAppUi::PREF_VIDEO
	String_t* ___PREF_VIDEO_60;
	// System.String CallAppUi::PREF_VIDEODEVICE
	String_t* ___PREF_VIDEODEVICE_61;
	// System.String CallAppUi::PREF_ROOMNAME
	String_t* ___PREF_ROOMNAME_62;
	// System.String CallAppUi::PREF_IDEALWIDTH
	String_t* ___PREF_IDEALWIDTH_63;
	// System.String CallAppUi::PREF_IDEALHEIGHT
	String_t* ___PREF_IDEALHEIGHT_64;
	// System.String CallAppUi::PREF_IDEALFPS
	String_t* ___PREF_IDEALFPS_65;
	// System.String CallAppUi::PREF_REJOIN
	String_t* ___PREF_REJOIN_66;
	// System.String CallAppUi::PREF_LOCALVIDEO
	String_t* ___PREF_LOCALVIDEO_67;

public:
	inline static int32_t get_offset_of_sDefaultOverlayTimeout_42() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields, ___sDefaultOverlayTimeout_42)); }
	inline float get_sDefaultOverlayTimeout_42() const { return ___sDefaultOverlayTimeout_42; }
	inline float* get_address_of_sDefaultOverlayTimeout_42() { return &___sDefaultOverlayTimeout_42; }
	inline void set_sDefaultOverlayTimeout_42(float value)
	{
		___sDefaultOverlayTimeout_42 = value;
	}

	inline static int32_t get_offset_of_PREF_AUDIO_59() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields, ___PREF_AUDIO_59)); }
	inline String_t* get_PREF_AUDIO_59() const { return ___PREF_AUDIO_59; }
	inline String_t** get_address_of_PREF_AUDIO_59() { return &___PREF_AUDIO_59; }
	inline void set_PREF_AUDIO_59(String_t* value)
	{
		___PREF_AUDIO_59 = value;
		Il2CppCodeGenWriteBarrier((&___PREF_AUDIO_59), value);
	}

	inline static int32_t get_offset_of_PREF_VIDEO_60() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields, ___PREF_VIDEO_60)); }
	inline String_t* get_PREF_VIDEO_60() const { return ___PREF_VIDEO_60; }
	inline String_t** get_address_of_PREF_VIDEO_60() { return &___PREF_VIDEO_60; }
	inline void set_PREF_VIDEO_60(String_t* value)
	{
		___PREF_VIDEO_60 = value;
		Il2CppCodeGenWriteBarrier((&___PREF_VIDEO_60), value);
	}

	inline static int32_t get_offset_of_PREF_VIDEODEVICE_61() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields, ___PREF_VIDEODEVICE_61)); }
	inline String_t* get_PREF_VIDEODEVICE_61() const { return ___PREF_VIDEODEVICE_61; }
	inline String_t** get_address_of_PREF_VIDEODEVICE_61() { return &___PREF_VIDEODEVICE_61; }
	inline void set_PREF_VIDEODEVICE_61(String_t* value)
	{
		___PREF_VIDEODEVICE_61 = value;
		Il2CppCodeGenWriteBarrier((&___PREF_VIDEODEVICE_61), value);
	}

	inline static int32_t get_offset_of_PREF_ROOMNAME_62() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields, ___PREF_ROOMNAME_62)); }
	inline String_t* get_PREF_ROOMNAME_62() const { return ___PREF_ROOMNAME_62; }
	inline String_t** get_address_of_PREF_ROOMNAME_62() { return &___PREF_ROOMNAME_62; }
	inline void set_PREF_ROOMNAME_62(String_t* value)
	{
		___PREF_ROOMNAME_62 = value;
		Il2CppCodeGenWriteBarrier((&___PREF_ROOMNAME_62), value);
	}

	inline static int32_t get_offset_of_PREF_IDEALWIDTH_63() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields, ___PREF_IDEALWIDTH_63)); }
	inline String_t* get_PREF_IDEALWIDTH_63() const { return ___PREF_IDEALWIDTH_63; }
	inline String_t** get_address_of_PREF_IDEALWIDTH_63() { return &___PREF_IDEALWIDTH_63; }
	inline void set_PREF_IDEALWIDTH_63(String_t* value)
	{
		___PREF_IDEALWIDTH_63 = value;
		Il2CppCodeGenWriteBarrier((&___PREF_IDEALWIDTH_63), value);
	}

	inline static int32_t get_offset_of_PREF_IDEALHEIGHT_64() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields, ___PREF_IDEALHEIGHT_64)); }
	inline String_t* get_PREF_IDEALHEIGHT_64() const { return ___PREF_IDEALHEIGHT_64; }
	inline String_t** get_address_of_PREF_IDEALHEIGHT_64() { return &___PREF_IDEALHEIGHT_64; }
	inline void set_PREF_IDEALHEIGHT_64(String_t* value)
	{
		___PREF_IDEALHEIGHT_64 = value;
		Il2CppCodeGenWriteBarrier((&___PREF_IDEALHEIGHT_64), value);
	}

	inline static int32_t get_offset_of_PREF_IDEALFPS_65() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields, ___PREF_IDEALFPS_65)); }
	inline String_t* get_PREF_IDEALFPS_65() const { return ___PREF_IDEALFPS_65; }
	inline String_t** get_address_of_PREF_IDEALFPS_65() { return &___PREF_IDEALFPS_65; }
	inline void set_PREF_IDEALFPS_65(String_t* value)
	{
		___PREF_IDEALFPS_65 = value;
		Il2CppCodeGenWriteBarrier((&___PREF_IDEALFPS_65), value);
	}

	inline static int32_t get_offset_of_PREF_REJOIN_66() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields, ___PREF_REJOIN_66)); }
	inline String_t* get_PREF_REJOIN_66() const { return ___PREF_REJOIN_66; }
	inline String_t** get_address_of_PREF_REJOIN_66() { return &___PREF_REJOIN_66; }
	inline void set_PREF_REJOIN_66(String_t* value)
	{
		___PREF_REJOIN_66 = value;
		Il2CppCodeGenWriteBarrier((&___PREF_REJOIN_66), value);
	}

	inline static int32_t get_offset_of_PREF_LOCALVIDEO_67() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields, ___PREF_LOCALVIDEO_67)); }
	inline String_t* get_PREF_LOCALVIDEO_67() const { return ___PREF_LOCALVIDEO_67; }
	inline String_t** get_address_of_PREF_LOCALVIDEO_67() { return &___PREF_LOCALVIDEO_67; }
	inline void set_PREF_LOCALVIDEO_67(String_t* value)
	{
		___PREF_LOCALVIDEO_67 = value;
		Il2CppCodeGenWriteBarrier((&___PREF_LOCALVIDEO_67), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLAPPUI_TACD06D4561F5F727B12FC86E8F703D58DC811867_H
#ifndef CHATAPP_T0290B0B9E87598552A8CB2A528FC37BB576DD5A7_H
#define CHATAPP_T0290B0B9E87598552A8CB2A528FC37BB576DD5A7_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// ChatApp
struct  ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.String ChatApp::uSignalingUrl
	String_t* ___uSignalingUrl_4;
	// System.String ChatApp::uSecureSignalingUrl
	String_t* ___uSecureSignalingUrl_5;
	// System.Boolean ChatApp::uForceSecureSignaling
	bool ___uForceSecureSignaling_6;
	// System.String ChatApp::uIceServer
	String_t* ___uIceServer_7;
	// System.String ChatApp::uIceServerUser
	String_t* ___uIceServerUser_8;
	// System.String ChatApp::uIceServerPassword
	String_t* ___uIceServerPassword_9;
	// System.String ChatApp::uIceServer2
	String_t* ___uIceServer2_10;
	// UnityEngine.UI.InputField ChatApp::uRoomName
	InputField_t533609195B110760BCFF00B746C87D81969CB005 * ___uRoomName_11;
	// UnityEngine.UI.InputField ChatApp::uMessageInput
	InputField_t533609195B110760BCFF00B746C87D81969CB005 * ___uMessageInput_12;
	// MessageList ChatApp::uOutput
	MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC * ___uOutput_13;
	// UnityEngine.UI.Button ChatApp::uJoin
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uJoin_14;
	// UnityEngine.UI.Button ChatApp::uSend
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uSend_15;
	// UnityEngine.UI.Button ChatApp::uOpenRoom
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uOpenRoom_16;
	// UnityEngine.UI.Button ChatApp::uLeave
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uLeave_17;
	// Byn.Awrtc.IBasicNetwork ChatApp::mNetwork
	RuntimeObject* ___mNetwork_18;
	// System.Boolean ChatApp::mIsServer
	bool ___mIsServer_19;
	// System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId> ChatApp::mConnections
	List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * ___mConnections_20;

public:
	inline static int32_t get_offset_of_uSignalingUrl_4() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uSignalingUrl_4)); }
	inline String_t* get_uSignalingUrl_4() const { return ___uSignalingUrl_4; }
	inline String_t** get_address_of_uSignalingUrl_4() { return &___uSignalingUrl_4; }
	inline void set_uSignalingUrl_4(String_t* value)
	{
		___uSignalingUrl_4 = value;
		Il2CppCodeGenWriteBarrier((&___uSignalingUrl_4), value);
	}

	inline static int32_t get_offset_of_uSecureSignalingUrl_5() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uSecureSignalingUrl_5)); }
	inline String_t* get_uSecureSignalingUrl_5() const { return ___uSecureSignalingUrl_5; }
	inline String_t** get_address_of_uSecureSignalingUrl_5() { return &___uSecureSignalingUrl_5; }
	inline void set_uSecureSignalingUrl_5(String_t* value)
	{
		___uSecureSignalingUrl_5 = value;
		Il2CppCodeGenWriteBarrier((&___uSecureSignalingUrl_5), value);
	}

	inline static int32_t get_offset_of_uForceSecureSignaling_6() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uForceSecureSignaling_6)); }
	inline bool get_uForceSecureSignaling_6() const { return ___uForceSecureSignaling_6; }
	inline bool* get_address_of_uForceSecureSignaling_6() { return &___uForceSecureSignaling_6; }
	inline void set_uForceSecureSignaling_6(bool value)
	{
		___uForceSecureSignaling_6 = value;
	}

	inline static int32_t get_offset_of_uIceServer_7() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uIceServer_7)); }
	inline String_t* get_uIceServer_7() const { return ___uIceServer_7; }
	inline String_t** get_address_of_uIceServer_7() { return &___uIceServer_7; }
	inline void set_uIceServer_7(String_t* value)
	{
		___uIceServer_7 = value;
		Il2CppCodeGenWriteBarrier((&___uIceServer_7), value);
	}

	inline static int32_t get_offset_of_uIceServerUser_8() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uIceServerUser_8)); }
	inline String_t* get_uIceServerUser_8() const { return ___uIceServerUser_8; }
	inline String_t** get_address_of_uIceServerUser_8() { return &___uIceServerUser_8; }
	inline void set_uIceServerUser_8(String_t* value)
	{
		___uIceServerUser_8 = value;
		Il2CppCodeGenWriteBarrier((&___uIceServerUser_8), value);
	}

	inline static int32_t get_offset_of_uIceServerPassword_9() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uIceServerPassword_9)); }
	inline String_t* get_uIceServerPassword_9() const { return ___uIceServerPassword_9; }
	inline String_t** get_address_of_uIceServerPassword_9() { return &___uIceServerPassword_9; }
	inline void set_uIceServerPassword_9(String_t* value)
	{
		___uIceServerPassword_9 = value;
		Il2CppCodeGenWriteBarrier((&___uIceServerPassword_9), value);
	}

	inline static int32_t get_offset_of_uIceServer2_10() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uIceServer2_10)); }
	inline String_t* get_uIceServer2_10() const { return ___uIceServer2_10; }
	inline String_t** get_address_of_uIceServer2_10() { return &___uIceServer2_10; }
	inline void set_uIceServer2_10(String_t* value)
	{
		___uIceServer2_10 = value;
		Il2CppCodeGenWriteBarrier((&___uIceServer2_10), value);
	}

	inline static int32_t get_offset_of_uRoomName_11() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uRoomName_11)); }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 * get_uRoomName_11() const { return ___uRoomName_11; }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 ** get_address_of_uRoomName_11() { return &___uRoomName_11; }
	inline void set_uRoomName_11(InputField_t533609195B110760BCFF00B746C87D81969CB005 * value)
	{
		___uRoomName_11 = value;
		Il2CppCodeGenWriteBarrier((&___uRoomName_11), value);
	}

	inline static int32_t get_offset_of_uMessageInput_12() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uMessageInput_12)); }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 * get_uMessageInput_12() const { return ___uMessageInput_12; }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 ** get_address_of_uMessageInput_12() { return &___uMessageInput_12; }
	inline void set_uMessageInput_12(InputField_t533609195B110760BCFF00B746C87D81969CB005 * value)
	{
		___uMessageInput_12 = value;
		Il2CppCodeGenWriteBarrier((&___uMessageInput_12), value);
	}

	inline static int32_t get_offset_of_uOutput_13() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uOutput_13)); }
	inline MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC * get_uOutput_13() const { return ___uOutput_13; }
	inline MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC ** get_address_of_uOutput_13() { return &___uOutput_13; }
	inline void set_uOutput_13(MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC * value)
	{
		___uOutput_13 = value;
		Il2CppCodeGenWriteBarrier((&___uOutput_13), value);
	}

	inline static int32_t get_offset_of_uJoin_14() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uJoin_14)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uJoin_14() const { return ___uJoin_14; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uJoin_14() { return &___uJoin_14; }
	inline void set_uJoin_14(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uJoin_14 = value;
		Il2CppCodeGenWriteBarrier((&___uJoin_14), value);
	}

	inline static int32_t get_offset_of_uSend_15() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uSend_15)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uSend_15() const { return ___uSend_15; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uSend_15() { return &___uSend_15; }
	inline void set_uSend_15(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uSend_15 = value;
		Il2CppCodeGenWriteBarrier((&___uSend_15), value);
	}

	inline static int32_t get_offset_of_uOpenRoom_16() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uOpenRoom_16)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uOpenRoom_16() const { return ___uOpenRoom_16; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uOpenRoom_16() { return &___uOpenRoom_16; }
	inline void set_uOpenRoom_16(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uOpenRoom_16 = value;
		Il2CppCodeGenWriteBarrier((&___uOpenRoom_16), value);
	}

	inline static int32_t get_offset_of_uLeave_17() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uLeave_17)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uLeave_17() const { return ___uLeave_17; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uLeave_17() { return &___uLeave_17; }
	inline void set_uLeave_17(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uLeave_17 = value;
		Il2CppCodeGenWriteBarrier((&___uLeave_17), value);
	}

	inline static int32_t get_offset_of_mNetwork_18() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___mNetwork_18)); }
	inline RuntimeObject* get_mNetwork_18() const { return ___mNetwork_18; }
	inline RuntimeObject** get_address_of_mNetwork_18() { return &___mNetwork_18; }
	inline void set_mNetwork_18(RuntimeObject* value)
	{
		___mNetwork_18 = value;
		Il2CppCodeGenWriteBarrier((&___mNetwork_18), value);
	}

	inline static int32_t get_offset_of_mIsServer_19() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___mIsServer_19)); }
	inline bool get_mIsServer_19() const { return ___mIsServer_19; }
	inline bool* get_address_of_mIsServer_19() { return &___mIsServer_19; }
	inline void set_mIsServer_19(bool value)
	{
		___mIsServer_19 = value;
	}

	inline static int32_t get_offset_of_mConnections_20() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___mConnections_20)); }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * get_mConnections_20() const { return ___mConnections_20; }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 ** get_address_of_mConnections_20() { return &___mConnections_20; }
	inline void set_mConnections_20(List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * value)
	{
		___mConnections_20 = value;
		Il2CppCodeGenWriteBarrier((&___mConnections_20), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CHATAPP_T0290B0B9E87598552A8CB2A528FC37BB576DD5A7_H
#ifndef GRIDMANAGER_T05748D877516CE2E0F9FBFACCF8AF0F6A21D4804_H
#define GRIDMANAGER_T05748D877516CE2E0F9FBFACCF8AF0F6A21D4804_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// GridManager
struct  GridManager_t05748D877516CE2E0F9FBFACCF8AF0F6A21D4804  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Int32 GridManager::mKnownItems
	int32_t ___mKnownItems_4;
	// UnityEngine.UI.GridLayoutGroup GridManager::mGrid
	GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8 * ___mGrid_5;
	// UnityEngine.RectTransform GridManager::mTransform
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___mTransform_6;

public:
	inline static int32_t get_offset_of_mKnownItems_4() { return static_cast<int32_t>(offsetof(GridManager_t05748D877516CE2E0F9FBFACCF8AF0F6A21D4804, ___mKnownItems_4)); }
	inline int32_t get_mKnownItems_4() const { return ___mKnownItems_4; }
	inline int32_t* get_address_of_mKnownItems_4() { return &___mKnownItems_4; }
	inline void set_mKnownItems_4(int32_t value)
	{
		___mKnownItems_4 = value;
	}

	inline static int32_t get_offset_of_mGrid_5() { return static_cast<int32_t>(offsetof(GridManager_t05748D877516CE2E0F9FBFACCF8AF0F6A21D4804, ___mGrid_5)); }
	inline GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8 * get_mGrid_5() const { return ___mGrid_5; }
	inline GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8 ** get_address_of_mGrid_5() { return &___mGrid_5; }
	inline void set_mGrid_5(GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8 * value)
	{
		___mGrid_5 = value;
		Il2CppCodeGenWriteBarrier((&___mGrid_5), value);
	}

	inline static int32_t get_offset_of_mTransform_6() { return static_cast<int32_t>(offsetof(GridManager_t05748D877516CE2E0F9FBFACCF8AF0F6A21D4804, ___mTransform_6)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_mTransform_6() const { return ___mTransform_6; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_mTransform_6() { return &___mTransform_6; }
	inline void set_mTransform_6(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___mTransform_6 = value;
		Il2CppCodeGenWriteBarrier((&___mTransform_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GRIDMANAGER_T05748D877516CE2E0F9FBFACCF8AF0F6A21D4804_H
#ifndef IMGFITTER_T8C2D5035D612E3A0EA1E2F51DFD3870672984F40_H
#define IMGFITTER_T8C2D5035D612E3A0EA1E2F51DFD3870672984F40_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// ImgFitter
struct  ImgFitter_t8C2D5035D612E3A0EA1E2F51DFD3870672984F40  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // IMGFITTER_T8C2D5035D612E3A0EA1E2F51DFD3870672984F40_H
#ifndef MENUSCRIPT_T9CD076A38B78730719E72CE473E966D0194B7B66_H
#define MENUSCRIPT_T9CD076A38B78730719E72CE473E966D0194B7B66_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// MenuScript
struct  MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.RectTransform MenuScript::_StartMenu
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ____StartMenu_5;
	// UnityEngine.UI.Button MenuScript::_ButtonMenu
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ____ButtonMenu_6;

public:
	inline static int32_t get_offset_of__StartMenu_5() { return static_cast<int32_t>(offsetof(MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66, ____StartMenu_5)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get__StartMenu_5() const { return ____StartMenu_5; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of__StartMenu_5() { return &____StartMenu_5; }
	inline void set__StartMenu_5(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		____StartMenu_5 = value;
		Il2CppCodeGenWriteBarrier((&____StartMenu_5), value);
	}

	inline static int32_t get_offset_of__ButtonMenu_6() { return static_cast<int32_t>(offsetof(MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66, ____ButtonMenu_6)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get__ButtonMenu_6() const { return ____ButtonMenu_6; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of__ButtonMenu_6() { return &____ButtonMenu_6; }
	inline void set__ButtonMenu_6(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		____ButtonMenu_6 = value;
		Il2CppCodeGenWriteBarrier((&____ButtonMenu_6), value);
	}
};

struct MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66_StaticFields
{
public:
	// System.Boolean MenuScript::sCreated
	bool ___sCreated_4;

public:
	inline static int32_t get_offset_of_sCreated_4() { return static_cast<int32_t>(offsetof(MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66_StaticFields, ___sCreated_4)); }
	inline bool get_sCreated_4() const { return ___sCreated_4; }
	inline bool* get_address_of_sCreated_4() { return &___sCreated_4; }
	inline void set_sCreated_4(bool value)
	{
		___sCreated_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MENUSCRIPT_T9CD076A38B78730719E72CE473E966D0194B7B66_H
#ifndef MESSAGELIST_TD66AFF3FCD283ACC670373072314E87D442C19DC_H
#define MESSAGELIST_TD66AFF3FCD283ACC670373072314E87D442C19DC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// MessageList
struct  MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject MessageList::uEntryPrefab
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___uEntryPrefab_4;
	// UnityEngine.RectTransform MessageList::mOwnTransform
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___mOwnTransform_5;
	// System.Int32 MessageList::mMaxMessages
	int32_t ___mMaxMessages_6;
	// System.Int32 MessageList::mCounter
	int32_t ___mCounter_7;

public:
	inline static int32_t get_offset_of_uEntryPrefab_4() { return static_cast<int32_t>(offsetof(MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC, ___uEntryPrefab_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_uEntryPrefab_4() const { return ___uEntryPrefab_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_uEntryPrefab_4() { return &___uEntryPrefab_4; }
	inline void set_uEntryPrefab_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___uEntryPrefab_4 = value;
		Il2CppCodeGenWriteBarrier((&___uEntryPrefab_4), value);
	}

	inline static int32_t get_offset_of_mOwnTransform_5() { return static_cast<int32_t>(offsetof(MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC, ___mOwnTransform_5)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_mOwnTransform_5() const { return ___mOwnTransform_5; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_mOwnTransform_5() { return &___mOwnTransform_5; }
	inline void set_mOwnTransform_5(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___mOwnTransform_5 = value;
		Il2CppCodeGenWriteBarrier((&___mOwnTransform_5), value);
	}

	inline static int32_t get_offset_of_mMaxMessages_6() { return static_cast<int32_t>(offsetof(MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC, ___mMaxMessages_6)); }
	inline int32_t get_mMaxMessages_6() const { return ___mMaxMessages_6; }
	inline int32_t* get_address_of_mMaxMessages_6() { return &___mMaxMessages_6; }
	inline void set_mMaxMessages_6(int32_t value)
	{
		___mMaxMessages_6 = value;
	}

	inline static int32_t get_offset_of_mCounter_7() { return static_cast<int32_t>(offsetof(MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC, ___mCounter_7)); }
	inline int32_t get_mCounter_7() const { return ___mCounter_7; }
	inline int32_t* get_address_of_mCounter_7() { return &___mCounter_7; }
	inline void set_mCounter_7(int32_t value)
	{
		___mCounter_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MESSAGELIST_TD66AFF3FCD283ACC670373072314E87D442C19DC_H
#ifndef UIBEHAVIOUR_T3C3C339CD5677BA7FC27C352FED8B78052A3FE70_H
#define UIBEHAVIOUR_T3C3C339CD5677BA7FC27C352FED8B78052A3FE70_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.EventSystems.UIBehaviour
struct  UIBehaviour_t3C3C339CD5677BA7FC27C352FED8B78052A3FE70  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UIBEHAVIOUR_T3C3C339CD5677BA7FC27C352FED8B78052A3FE70_H
#ifndef VIDEOPANELEVENTHANDLER_T3541E619FE0500181F23443D1B6C8FD05DC18802_H
#define VIDEOPANELEVENTHANDLER_T3541E619FE0500181F23443D1B6C8FD05DC18802_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// VideoPanelEventHandler
struct  VideoPanelEventHandler_t3541E619FE0500181F23443D1B6C8FD05DC18802  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// CallAppUi VideoPanelEventHandler::mParent
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * ___mParent_4;
	// System.Single VideoPanelEventHandler::mLastClick
	float ___mLastClick_5;

public:
	inline static int32_t get_offset_of_mParent_4() { return static_cast<int32_t>(offsetof(VideoPanelEventHandler_t3541E619FE0500181F23443D1B6C8FD05DC18802, ___mParent_4)); }
	inline CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * get_mParent_4() const { return ___mParent_4; }
	inline CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 ** get_address_of_mParent_4() { return &___mParent_4; }
	inline void set_mParent_4(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * value)
	{
		___mParent_4 = value;
		Il2CppCodeGenWriteBarrier((&___mParent_4), value);
	}

	inline static int32_t get_offset_of_mLastClick_5() { return static_cast<int32_t>(offsetof(VideoPanelEventHandler_t3541E619FE0500181F23443D1B6C8FD05DC18802, ___mLastClick_5)); }
	inline float get_mLastClick_5() const { return ___mLastClick_5; }
	inline float* get_address_of_mLastClick_5() { return &___mLastClick_5; }
	inline void set_mLastClick_5(float value)
	{
		___mLastClick_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEOPANELEVENTHANDLER_T3541E619FE0500181F23443D1B6C8FD05DC18802_H
#ifndef VIDEOINPUTAPP_TBD1B4BA06062C26F8519013F665376060F9FC2CF_H
#define VIDEOINPUTAPP_TBD1B4BA06062C26F8519013F665376060F9FC2CF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.VideoInputApp
struct  VideoInputApp_tBD1B4BA06062C26F8519013F665376060F9FC2CF  : public CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEOINPUTAPP_TBD1B4BA06062C26F8519013F665376060F9FC2CF_H
#ifndef BASEMESHEFFECT_T72759F31F9D204D7EFB6B45097873809D4524BA5_H
#define BASEMESHEFFECT_T72759F31F9D204D7EFB6B45097873809D4524BA5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.BaseMeshEffect
struct  BaseMeshEffect_t72759F31F9D204D7EFB6B45097873809D4524BA5  : public UIBehaviour_t3C3C339CD5677BA7FC27C352FED8B78052A3FE70
{
public:
	// UnityEngine.UI.Graphic UnityEngine.UI.BaseMeshEffect::m_Graphic
	Graphic_tBA2C3EF11D3DAEBB57F6879AB0BB4F8BD40D00D8 * ___m_Graphic_4;

public:
	inline static int32_t get_offset_of_m_Graphic_4() { return static_cast<int32_t>(offsetof(BaseMeshEffect_t72759F31F9D204D7EFB6B45097873809D4524BA5, ___m_Graphic_4)); }
	inline Graphic_tBA2C3EF11D3DAEBB57F6879AB0BB4F8BD40D00D8 * get_m_Graphic_4() const { return ___m_Graphic_4; }
	inline Graphic_tBA2C3EF11D3DAEBB57F6879AB0BB4F8BD40D00D8 ** get_address_of_m_Graphic_4() { return &___m_Graphic_4; }
	inline void set_m_Graphic_4(Graphic_tBA2C3EF11D3DAEBB57F6879AB0BB4F8BD40D00D8 * value)
	{
		___m_Graphic_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_Graphic_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BASEMESHEFFECT_T72759F31F9D204D7EFB6B45097873809D4524BA5_H
#ifndef LAYOUTELEMENT_TD503826DB41B6EA85AC689292F8B2661B3C1048B_H
#define LAYOUTELEMENT_TD503826DB41B6EA85AC689292F8B2661B3C1048B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.LayoutElement
struct  LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B  : public UIBehaviour_t3C3C339CD5677BA7FC27C352FED8B78052A3FE70
{
public:
	// System.Boolean UnityEngine.UI.LayoutElement::m_IgnoreLayout
	bool ___m_IgnoreLayout_4;
	// System.Single UnityEngine.UI.LayoutElement::m_MinWidth
	float ___m_MinWidth_5;
	// System.Single UnityEngine.UI.LayoutElement::m_MinHeight
	float ___m_MinHeight_6;
	// System.Single UnityEngine.UI.LayoutElement::m_PreferredWidth
	float ___m_PreferredWidth_7;
	// System.Single UnityEngine.UI.LayoutElement::m_PreferredHeight
	float ___m_PreferredHeight_8;
	// System.Single UnityEngine.UI.LayoutElement::m_FlexibleWidth
	float ___m_FlexibleWidth_9;
	// System.Single UnityEngine.UI.LayoutElement::m_FlexibleHeight
	float ___m_FlexibleHeight_10;
	// System.Int32 UnityEngine.UI.LayoutElement::m_LayoutPriority
	int32_t ___m_LayoutPriority_11;

public:
	inline static int32_t get_offset_of_m_IgnoreLayout_4() { return static_cast<int32_t>(offsetof(LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B, ___m_IgnoreLayout_4)); }
	inline bool get_m_IgnoreLayout_4() const { return ___m_IgnoreLayout_4; }
	inline bool* get_address_of_m_IgnoreLayout_4() { return &___m_IgnoreLayout_4; }
	inline void set_m_IgnoreLayout_4(bool value)
	{
		___m_IgnoreLayout_4 = value;
	}

	inline static int32_t get_offset_of_m_MinWidth_5() { return static_cast<int32_t>(offsetof(LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B, ___m_MinWidth_5)); }
	inline float get_m_MinWidth_5() const { return ___m_MinWidth_5; }
	inline float* get_address_of_m_MinWidth_5() { return &___m_MinWidth_5; }
	inline void set_m_MinWidth_5(float value)
	{
		___m_MinWidth_5 = value;
	}

	inline static int32_t get_offset_of_m_MinHeight_6() { return static_cast<int32_t>(offsetof(LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B, ___m_MinHeight_6)); }
	inline float get_m_MinHeight_6() const { return ___m_MinHeight_6; }
	inline float* get_address_of_m_MinHeight_6() { return &___m_MinHeight_6; }
	inline void set_m_MinHeight_6(float value)
	{
		___m_MinHeight_6 = value;
	}

	inline static int32_t get_offset_of_m_PreferredWidth_7() { return static_cast<int32_t>(offsetof(LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B, ___m_PreferredWidth_7)); }
	inline float get_m_PreferredWidth_7() const { return ___m_PreferredWidth_7; }
	inline float* get_address_of_m_PreferredWidth_7() { return &___m_PreferredWidth_7; }
	inline void set_m_PreferredWidth_7(float value)
	{
		___m_PreferredWidth_7 = value;
	}

	inline static int32_t get_offset_of_m_PreferredHeight_8() { return static_cast<int32_t>(offsetof(LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B, ___m_PreferredHeight_8)); }
	inline float get_m_PreferredHeight_8() const { return ___m_PreferredHeight_8; }
	inline float* get_address_of_m_PreferredHeight_8() { return &___m_PreferredHeight_8; }
	inline void set_m_PreferredHeight_8(float value)
	{
		___m_PreferredHeight_8 = value;
	}

	inline static int32_t get_offset_of_m_FlexibleWidth_9() { return static_cast<int32_t>(offsetof(LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B, ___m_FlexibleWidth_9)); }
	inline float get_m_FlexibleWidth_9() const { return ___m_FlexibleWidth_9; }
	inline float* get_address_of_m_FlexibleWidth_9() { return &___m_FlexibleWidth_9; }
	inline void set_m_FlexibleWidth_9(float value)
	{
		___m_FlexibleWidth_9 = value;
	}

	inline static int32_t get_offset_of_m_FlexibleHeight_10() { return static_cast<int32_t>(offsetof(LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B, ___m_FlexibleHeight_10)); }
	inline float get_m_FlexibleHeight_10() const { return ___m_FlexibleHeight_10; }
	inline float* get_address_of_m_FlexibleHeight_10() { return &___m_FlexibleHeight_10; }
	inline void set_m_FlexibleHeight_10(float value)
	{
		___m_FlexibleHeight_10 = value;
	}

	inline static int32_t get_offset_of_m_LayoutPriority_11() { return static_cast<int32_t>(offsetof(LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B, ___m_LayoutPriority_11)); }
	inline int32_t get_m_LayoutPriority_11() const { return ___m_LayoutPriority_11; }
	inline int32_t* get_address_of_m_LayoutPriority_11() { return &___m_LayoutPriority_11; }
	inline void set_m_LayoutPriority_11(int32_t value)
	{
		___m_LayoutPriority_11 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LAYOUTELEMENT_TD503826DB41B6EA85AC689292F8B2661B3C1048B_H
#ifndef LAYOUTGROUP_T9E072B95DA6476C487C0B07A815291249025C0E4_H
#define LAYOUTGROUP_T9E072B95DA6476C487C0B07A815291249025C0E4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.LayoutGroup
struct  LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4  : public UIBehaviour_t3C3C339CD5677BA7FC27C352FED8B78052A3FE70
{
public:
	// UnityEngine.RectOffset UnityEngine.UI.LayoutGroup::m_Padding
	RectOffset_tED44B1176E93501050480416699D1F11BAE8C87A * ___m_Padding_4;
	// UnityEngine.TextAnchor UnityEngine.UI.LayoutGroup::m_ChildAlignment
	int32_t ___m_ChildAlignment_5;
	// UnityEngine.RectTransform UnityEngine.UI.LayoutGroup::m_Rect
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___m_Rect_6;
	// UnityEngine.DrivenRectTransformTracker UnityEngine.UI.LayoutGroup::m_Tracker
	DrivenRectTransformTracker_tB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03  ___m_Tracker_7;
	// UnityEngine.Vector2 UnityEngine.UI.LayoutGroup::m_TotalMinSize
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_TotalMinSize_8;
	// UnityEngine.Vector2 UnityEngine.UI.LayoutGroup::m_TotalPreferredSize
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_TotalPreferredSize_9;
	// UnityEngine.Vector2 UnityEngine.UI.LayoutGroup::m_TotalFlexibleSize
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_TotalFlexibleSize_10;
	// System.Collections.Generic.List`1<UnityEngine.RectTransform> UnityEngine.UI.LayoutGroup::m_RectChildren
	List_1_t0CD9761E1DF9817484CF4FB4253C6A626DC2311C * ___m_RectChildren_11;

public:
	inline static int32_t get_offset_of_m_Padding_4() { return static_cast<int32_t>(offsetof(LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4, ___m_Padding_4)); }
	inline RectOffset_tED44B1176E93501050480416699D1F11BAE8C87A * get_m_Padding_4() const { return ___m_Padding_4; }
	inline RectOffset_tED44B1176E93501050480416699D1F11BAE8C87A ** get_address_of_m_Padding_4() { return &___m_Padding_4; }
	inline void set_m_Padding_4(RectOffset_tED44B1176E93501050480416699D1F11BAE8C87A * value)
	{
		___m_Padding_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_Padding_4), value);
	}

	inline static int32_t get_offset_of_m_ChildAlignment_5() { return static_cast<int32_t>(offsetof(LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4, ___m_ChildAlignment_5)); }
	inline int32_t get_m_ChildAlignment_5() const { return ___m_ChildAlignment_5; }
	inline int32_t* get_address_of_m_ChildAlignment_5() { return &___m_ChildAlignment_5; }
	inline void set_m_ChildAlignment_5(int32_t value)
	{
		___m_ChildAlignment_5 = value;
	}

	inline static int32_t get_offset_of_m_Rect_6() { return static_cast<int32_t>(offsetof(LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4, ___m_Rect_6)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_m_Rect_6() const { return ___m_Rect_6; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_m_Rect_6() { return &___m_Rect_6; }
	inline void set_m_Rect_6(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___m_Rect_6 = value;
		Il2CppCodeGenWriteBarrier((&___m_Rect_6), value);
	}

	inline static int32_t get_offset_of_m_Tracker_7() { return static_cast<int32_t>(offsetof(LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4, ___m_Tracker_7)); }
	inline DrivenRectTransformTracker_tB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03  get_m_Tracker_7() const { return ___m_Tracker_7; }
	inline DrivenRectTransformTracker_tB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03 * get_address_of_m_Tracker_7() { return &___m_Tracker_7; }
	inline void set_m_Tracker_7(DrivenRectTransformTracker_tB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03  value)
	{
		___m_Tracker_7 = value;
	}

	inline static int32_t get_offset_of_m_TotalMinSize_8() { return static_cast<int32_t>(offsetof(LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4, ___m_TotalMinSize_8)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_TotalMinSize_8() const { return ___m_TotalMinSize_8; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_TotalMinSize_8() { return &___m_TotalMinSize_8; }
	inline void set_m_TotalMinSize_8(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_TotalMinSize_8 = value;
	}

	inline static int32_t get_offset_of_m_TotalPreferredSize_9() { return static_cast<int32_t>(offsetof(LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4, ___m_TotalPreferredSize_9)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_TotalPreferredSize_9() const { return ___m_TotalPreferredSize_9; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_TotalPreferredSize_9() { return &___m_TotalPreferredSize_9; }
	inline void set_m_TotalPreferredSize_9(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_TotalPreferredSize_9 = value;
	}

	inline static int32_t get_offset_of_m_TotalFlexibleSize_10() { return static_cast<int32_t>(offsetof(LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4, ___m_TotalFlexibleSize_10)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_TotalFlexibleSize_10() const { return ___m_TotalFlexibleSize_10; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_TotalFlexibleSize_10() { return &___m_TotalFlexibleSize_10; }
	inline void set_m_TotalFlexibleSize_10(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_TotalFlexibleSize_10 = value;
	}

	inline static int32_t get_offset_of_m_RectChildren_11() { return static_cast<int32_t>(offsetof(LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4, ___m_RectChildren_11)); }
	inline List_1_t0CD9761E1DF9817484CF4FB4253C6A626DC2311C * get_m_RectChildren_11() const { return ___m_RectChildren_11; }
	inline List_1_t0CD9761E1DF9817484CF4FB4253C6A626DC2311C ** get_address_of_m_RectChildren_11() { return &___m_RectChildren_11; }
	inline void set_m_RectChildren_11(List_1_t0CD9761E1DF9817484CF4FB4253C6A626DC2311C * value)
	{
		___m_RectChildren_11 = value;
		Il2CppCodeGenWriteBarrier((&___m_RectChildren_11), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LAYOUTGROUP_T9E072B95DA6476C487C0B07A815291249025C0E4_H
#ifndef GRIDLAYOUTGROUP_T1C70294BD2567FD584672222A8BFD5A0DF1CA2A8_H
#define GRIDLAYOUTGROUP_T1C70294BD2567FD584672222A8BFD5A0DF1CA2A8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.GridLayoutGroup
struct  GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8  : public LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4
{
public:
	// UnityEngine.UI.GridLayoutGroup_Corner UnityEngine.UI.GridLayoutGroup::m_StartCorner
	int32_t ___m_StartCorner_12;
	// UnityEngine.UI.GridLayoutGroup_Axis UnityEngine.UI.GridLayoutGroup::m_StartAxis
	int32_t ___m_StartAxis_13;
	// UnityEngine.Vector2 UnityEngine.UI.GridLayoutGroup::m_CellSize
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_CellSize_14;
	// UnityEngine.Vector2 UnityEngine.UI.GridLayoutGroup::m_Spacing
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_Spacing_15;
	// UnityEngine.UI.GridLayoutGroup_Constraint UnityEngine.UI.GridLayoutGroup::m_Constraint
	int32_t ___m_Constraint_16;
	// System.Int32 UnityEngine.UI.GridLayoutGroup::m_ConstraintCount
	int32_t ___m_ConstraintCount_17;

public:
	inline static int32_t get_offset_of_m_StartCorner_12() { return static_cast<int32_t>(offsetof(GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8, ___m_StartCorner_12)); }
	inline int32_t get_m_StartCorner_12() const { return ___m_StartCorner_12; }
	inline int32_t* get_address_of_m_StartCorner_12() { return &___m_StartCorner_12; }
	inline void set_m_StartCorner_12(int32_t value)
	{
		___m_StartCorner_12 = value;
	}

	inline static int32_t get_offset_of_m_StartAxis_13() { return static_cast<int32_t>(offsetof(GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8, ___m_StartAxis_13)); }
	inline int32_t get_m_StartAxis_13() const { return ___m_StartAxis_13; }
	inline int32_t* get_address_of_m_StartAxis_13() { return &___m_StartAxis_13; }
	inline void set_m_StartAxis_13(int32_t value)
	{
		___m_StartAxis_13 = value;
	}

	inline static int32_t get_offset_of_m_CellSize_14() { return static_cast<int32_t>(offsetof(GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8, ___m_CellSize_14)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_CellSize_14() const { return ___m_CellSize_14; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_CellSize_14() { return &___m_CellSize_14; }
	inline void set_m_CellSize_14(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_CellSize_14 = value;
	}

	inline static int32_t get_offset_of_m_Spacing_15() { return static_cast<int32_t>(offsetof(GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8, ___m_Spacing_15)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_Spacing_15() const { return ___m_Spacing_15; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_Spacing_15() { return &___m_Spacing_15; }
	inline void set_m_Spacing_15(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_Spacing_15 = value;
	}

	inline static int32_t get_offset_of_m_Constraint_16() { return static_cast<int32_t>(offsetof(GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8, ___m_Constraint_16)); }
	inline int32_t get_m_Constraint_16() const { return ___m_Constraint_16; }
	inline int32_t* get_address_of_m_Constraint_16() { return &___m_Constraint_16; }
	inline void set_m_Constraint_16(int32_t value)
	{
		___m_Constraint_16 = value;
	}

	inline static int32_t get_offset_of_m_ConstraintCount_17() { return static_cast<int32_t>(offsetof(GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8, ___m_ConstraintCount_17)); }
	inline int32_t get_m_ConstraintCount_17() const { return ___m_ConstraintCount_17; }
	inline int32_t* get_address_of_m_ConstraintCount_17() { return &___m_ConstraintCount_17; }
	inline void set_m_ConstraintCount_17(int32_t value)
	{
		___m_ConstraintCount_17 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GRIDLAYOUTGROUP_T1C70294BD2567FD584672222A8BFD5A0DF1CA2A8_H
#ifndef HORIZONTALORVERTICALLAYOUTGROUP_TFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB_H
#define HORIZONTALORVERTICALLAYOUTGROUP_TFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.HorizontalOrVerticalLayoutGroup
struct  HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB  : public LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4
{
public:
	// System.Single UnityEngine.UI.HorizontalOrVerticalLayoutGroup::m_Spacing
	float ___m_Spacing_12;
	// System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::m_ChildForceExpandWidth
	bool ___m_ChildForceExpandWidth_13;
	// System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::m_ChildForceExpandHeight
	bool ___m_ChildForceExpandHeight_14;
	// System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::m_ChildControlWidth
	bool ___m_ChildControlWidth_15;
	// System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::m_ChildControlHeight
	bool ___m_ChildControlHeight_16;

public:
	inline static int32_t get_offset_of_m_Spacing_12() { return static_cast<int32_t>(offsetof(HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB, ___m_Spacing_12)); }
	inline float get_m_Spacing_12() const { return ___m_Spacing_12; }
	inline float* get_address_of_m_Spacing_12() { return &___m_Spacing_12; }
	inline void set_m_Spacing_12(float value)
	{
		___m_Spacing_12 = value;
	}

	inline static int32_t get_offset_of_m_ChildForceExpandWidth_13() { return static_cast<int32_t>(offsetof(HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB, ___m_ChildForceExpandWidth_13)); }
	inline bool get_m_ChildForceExpandWidth_13() const { return ___m_ChildForceExpandWidth_13; }
	inline bool* get_address_of_m_ChildForceExpandWidth_13() { return &___m_ChildForceExpandWidth_13; }
	inline void set_m_ChildForceExpandWidth_13(bool value)
	{
		___m_ChildForceExpandWidth_13 = value;
	}

	inline static int32_t get_offset_of_m_ChildForceExpandHeight_14() { return static_cast<int32_t>(offsetof(HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB, ___m_ChildForceExpandHeight_14)); }
	inline bool get_m_ChildForceExpandHeight_14() const { return ___m_ChildForceExpandHeight_14; }
	inline bool* get_address_of_m_ChildForceExpandHeight_14() { return &___m_ChildForceExpandHeight_14; }
	inline void set_m_ChildForceExpandHeight_14(bool value)
	{
		___m_ChildForceExpandHeight_14 = value;
	}

	inline static int32_t get_offset_of_m_ChildControlWidth_15() { return static_cast<int32_t>(offsetof(HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB, ___m_ChildControlWidth_15)); }
	inline bool get_m_ChildControlWidth_15() const { return ___m_ChildControlWidth_15; }
	inline bool* get_address_of_m_ChildControlWidth_15() { return &___m_ChildControlWidth_15; }
	inline void set_m_ChildControlWidth_15(bool value)
	{
		___m_ChildControlWidth_15 = value;
	}

	inline static int32_t get_offset_of_m_ChildControlHeight_16() { return static_cast<int32_t>(offsetof(HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB, ___m_ChildControlHeight_16)); }
	inline bool get_m_ChildControlHeight_16() const { return ___m_ChildControlHeight_16; }
	inline bool* get_address_of_m_ChildControlHeight_16() { return &___m_ChildControlHeight_16; }
	inline void set_m_ChildControlHeight_16(bool value)
	{
		___m_ChildControlHeight_16 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HORIZONTALORVERTICALLAYOUTGROUP_TFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB_H
#ifndef POSITIONASUV1_T26F06E879E7B8DD2F93B8B3643053534D82F684A_H
#define POSITIONASUV1_T26F06E879E7B8DD2F93B8B3643053534D82F684A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.PositionAsUV1
struct  PositionAsUV1_t26F06E879E7B8DD2F93B8B3643053534D82F684A  : public BaseMeshEffect_t72759F31F9D204D7EFB6B45097873809D4524BA5
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSITIONASUV1_T26F06E879E7B8DD2F93B8B3643053534D82F684A_H
#ifndef SHADOW_TA03D2493843CDF8E64569F985AEB3FEEEEB412E1_H
#define SHADOW_TA03D2493843CDF8E64569F985AEB3FEEEEB412E1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.Shadow
struct  Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1  : public BaseMeshEffect_t72759F31F9D204D7EFB6B45097873809D4524BA5
{
public:
	// UnityEngine.Color UnityEngine.UI.Shadow::m_EffectColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___m_EffectColor_5;
	// UnityEngine.Vector2 UnityEngine.UI.Shadow::m_EffectDistance
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_EffectDistance_6;
	// System.Boolean UnityEngine.UI.Shadow::m_UseGraphicAlpha
	bool ___m_UseGraphicAlpha_7;

public:
	inline static int32_t get_offset_of_m_EffectColor_5() { return static_cast<int32_t>(offsetof(Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1, ___m_EffectColor_5)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_m_EffectColor_5() const { return ___m_EffectColor_5; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_m_EffectColor_5() { return &___m_EffectColor_5; }
	inline void set_m_EffectColor_5(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___m_EffectColor_5 = value;
	}

	inline static int32_t get_offset_of_m_EffectDistance_6() { return static_cast<int32_t>(offsetof(Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1, ___m_EffectDistance_6)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_EffectDistance_6() const { return ___m_EffectDistance_6; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_EffectDistance_6() { return &___m_EffectDistance_6; }
	inline void set_m_EffectDistance_6(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_EffectDistance_6 = value;
	}

	inline static int32_t get_offset_of_m_UseGraphicAlpha_7() { return static_cast<int32_t>(offsetof(Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1, ___m_UseGraphicAlpha_7)); }
	inline bool get_m_UseGraphicAlpha_7() const { return ___m_UseGraphicAlpha_7; }
	inline bool* get_address_of_m_UseGraphicAlpha_7() { return &___m_UseGraphicAlpha_7; }
	inline void set_m_UseGraphicAlpha_7(bool value)
	{
		___m_UseGraphicAlpha_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SHADOW_TA03D2493843CDF8E64569F985AEB3FEEEEB412E1_H
#ifndef HORIZONTALLAYOUTGROUP_TEFAFA0DDCCE4FC89CC2C0BE96E7C025D243CFE37_H
#define HORIZONTALLAYOUTGROUP_TEFAFA0DDCCE4FC89CC2C0BE96E7C025D243CFE37_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.HorizontalLayoutGroup
struct  HorizontalLayoutGroup_tEFAFA0DDCCE4FC89CC2C0BE96E7C025D243CFE37  : public HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HORIZONTALLAYOUTGROUP_TEFAFA0DDCCE4FC89CC2C0BE96E7C025D243CFE37_H
#ifndef OUTLINE_TB750E496976B072E79142D51C0A991AC20183095_H
#define OUTLINE_TB750E496976B072E79142D51C0A991AC20183095_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.Outline
struct  Outline_tB750E496976B072E79142D51C0A991AC20183095  : public Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OUTLINE_TB750E496976B072E79142D51C0A991AC20183095_H
#ifndef VERTICALLAYOUTGROUP_TAAEE0BAA82E9A110591DEC9A3FFC25A01C2FFA11_H
#define VERTICALLAYOUTGROUP_TAAEE0BAA82E9A110591DEC9A3FFC25A01C2FFA11_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.VerticalLayoutGroup
struct  VerticalLayoutGroup_tAAEE0BAA82E9A110591DEC9A3FFC25A01C2FFA11  : public HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VERTICALLAYOUTGROUP_TAAEE0BAA82E9A110591DEC9A3FFC25A01C2FFA11_H





#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3200 = { sizeof (FitMode_tBF783E77415F7063B468C18E758F738D83D60A08)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3200[4] = 
{
	FitMode_tBF783E77415F7063B468C18E758F738D83D60A08::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3201 = { sizeof (GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3201[6] = 
{
	GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8::get_offset_of_m_StartCorner_12(),
	GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8::get_offset_of_m_StartAxis_13(),
	GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8::get_offset_of_m_CellSize_14(),
	GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8::get_offset_of_m_Spacing_15(),
	GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8::get_offset_of_m_Constraint_16(),
	GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8::get_offset_of_m_ConstraintCount_17(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3202 = { sizeof (Corner_tD61F36EC56D401A65DA06BE1A21689319201D18E)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3202[5] = 
{
	Corner_tD61F36EC56D401A65DA06BE1A21689319201D18E::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3203 = { sizeof (Axis_tD4645F3B274E7AE7793C038A2BA2E68C6F0F02F0)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3203[3] = 
{
	Axis_tD4645F3B274E7AE7793C038A2BA2E68C6F0F02F0::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3204 = { sizeof (Constraint_tF471E55525B89D1E7C938CC0AF7515709494C59D)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3204[4] = 
{
	Constraint_tF471E55525B89D1E7C938CC0AF7515709494C59D::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3205 = { sizeof (HorizontalLayoutGroup_tEFAFA0DDCCE4FC89CC2C0BE96E7C025D243CFE37), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3206 = { sizeof (HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3206[5] = 
{
	HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB::get_offset_of_m_Spacing_12(),
	HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB::get_offset_of_m_ChildForceExpandWidth_13(),
	HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB::get_offset_of_m_ChildForceExpandHeight_14(),
	HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB::get_offset_of_m_ChildControlWidth_15(),
	HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB::get_offset_of_m_ChildControlHeight_16(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3207 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3208 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3209 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3210 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3211 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3212 = { sizeof (LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3212[8] = 
{
	LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B::get_offset_of_m_IgnoreLayout_4(),
	LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B::get_offset_of_m_MinWidth_5(),
	LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B::get_offset_of_m_MinHeight_6(),
	LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B::get_offset_of_m_PreferredWidth_7(),
	LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B::get_offset_of_m_PreferredHeight_8(),
	LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B::get_offset_of_m_FlexibleWidth_9(),
	LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B::get_offset_of_m_FlexibleHeight_10(),
	LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B::get_offset_of_m_LayoutPriority_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3213 = { sizeof (LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3213[8] = 
{
	LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4::get_offset_of_m_Padding_4(),
	LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4::get_offset_of_m_ChildAlignment_5(),
	LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4::get_offset_of_m_Rect_6(),
	LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4::get_offset_of_m_Tracker_7(),
	LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4::get_offset_of_m_TotalMinSize_8(),
	LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4::get_offset_of_m_TotalPreferredSize_9(),
	LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4::get_offset_of_m_TotalFlexibleSize_10(),
	LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4::get_offset_of_m_RectChildren_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3214 = { sizeof (U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3214[4] = 
{
	U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073::get_offset_of_rectTransform_0(),
	U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073::get_offset_of_U24current_1(),
	U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073::get_offset_of_U24disposing_2(),
	U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073::get_offset_of_U24PC_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3215 = { sizeof (LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD), -1, sizeof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3215[9] = 
{
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD::get_offset_of_m_ToRebuild_0(),
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD::get_offset_of_m_CachedHashFromTransform_1(),
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields::get_offset_of_s_Rebuilders_2(),
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields::get_offset_of_U3CU3Ef__mgU24cache0_3(),
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields::get_offset_of_U3CU3Ef__amU24cache0_4(),
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields::get_offset_of_U3CU3Ef__amU24cache1_5(),
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields::get_offset_of_U3CU3Ef__amU24cache2_6(),
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields::get_offset_of_U3CU3Ef__amU24cache3_7(),
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields::get_offset_of_U3CU3Ef__amU24cache4_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3216 = { sizeof (LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5), -1, sizeof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3216[8] = 
{
	LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields::get_offset_of_U3CU3Ef__amU24cache0_0(),
	LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields::get_offset_of_U3CU3Ef__amU24cache1_1(),
	LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields::get_offset_of_U3CU3Ef__amU24cache2_2(),
	LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields::get_offset_of_U3CU3Ef__amU24cache3_3(),
	LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields::get_offset_of_U3CU3Ef__amU24cache4_4(),
	LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields::get_offset_of_U3CU3Ef__amU24cache5_5(),
	LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields::get_offset_of_U3CU3Ef__amU24cache6_6(),
	LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields::get_offset_of_U3CU3Ef__amU24cache7_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3217 = { sizeof (VerticalLayoutGroup_tAAEE0BAA82E9A110591DEC9A3FFC25A01C2FFA11), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3218 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3219 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable3219[2] = 
{
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3220 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable3220[2] = 
{
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3221 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable3221[4] = 
{
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3222 = { sizeof (ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A), -1, sizeof(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3222[7] = 
{
	ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A::get_offset_of_raycast3D_0(),
	ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A::get_offset_of_raycast3DAll_1(),
	ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A::get_offset_of_raycast2D_2(),
	ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A::get_offset_of_getRayIntersectionAll_3(),
	ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A::get_offset_of_getRayIntersectionAllNonAlloc_4(),
	ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A::get_offset_of_getRaycastNonAlloc_5(),
	ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A_StaticFields::get_offset_of_s_ReflectionMethodsCache_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3223 = { sizeof (Raycast3DCallback_t83483916473C9710AEDB316A65CBE62C58935C5F), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3224 = { sizeof (Raycast2DCallback_tE99ABF9ABC3A380677949E8C05A3E477889B82BE), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3225 = { sizeof (RaycastAllCallback_t751407A44270E02FAA43D0846A58EE6A8C4AE1CE), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3226 = { sizeof (GetRayIntersectionAllCallback_t68C2581CCF05E868297EBD3F3361274954845095), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3227 = { sizeof (GetRayIntersectionAllNonAllocCallback_tAD7508D45DB6679B6394983579AD18D967CC2AD4), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3228 = { sizeof (GetRaycastNonAllocCallback_tC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3229 = { sizeof (VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F), -1, sizeof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3229[12] = 
{
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Positions_0(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Colors_1(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Uv0S_2(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Uv1S_3(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Uv2S_4(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Uv3S_5(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Normals_6(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Tangents_7(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Indices_8(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_StaticFields::get_offset_of_s_DefaultTangent_9(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_StaticFields::get_offset_of_s_DefaultNormal_10(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_ListsInitalized_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3230 = { sizeof (VertexHelperExtension_t593AF80A941B7208D2CC88AE671873CE6E2AA8E3), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3231 = { sizeof (BaseVertexEffect_t1EF95AB1FC33A027710E7DC86D19F700156C4F6A), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3232 = { sizeof (BaseMeshEffect_t72759F31F9D204D7EFB6B45097873809D4524BA5), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3232[1] = 
{
	BaseMeshEffect_t72759F31F9D204D7EFB6B45097873809D4524BA5::get_offset_of_m_Graphic_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3233 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3234 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3235 = { sizeof (Outline_tB750E496976B072E79142D51C0A991AC20183095), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3236 = { sizeof (PositionAsUV1_t26F06E879E7B8DD2F93B8B3643053534D82F684A), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3237 = { sizeof (Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3237[4] = 
{
	Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1::get_offset_of_m_EffectColor_5(),
	Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1::get_offset_of_m_EffectDistance_6(),
	Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1::get_offset_of_m_UseGraphicAlpha_7(),
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3238 = { sizeof (U3CPrivateImplementationDetailsU3E_tC8332394FBFEEB4B73459A35E182942340DA3537), -1, sizeof(U3CPrivateImplementationDetailsU3E_tC8332394FBFEEB4B73459A35E182942340DA3537_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3238[1] = 
{
	U3CPrivateImplementationDetailsU3E_tC8332394FBFEEB4B73459A35E182942340DA3537_StaticFields::get_offset_of_U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3239 = { sizeof (U24ArrayTypeU3D12_t25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU3D12_t25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3240 = { sizeof (U3CModuleU3E_tCE4B768174CDE0294B05DD8ED59A7763FF34E99B), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3241 = { sizeof (U3CModuleU3E_t51CA7CF080E6CE0730273E28881393B61A64D06E), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3242 = { sizeof (CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3242[18] = 
{
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_uSignalingUrl_4(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_uSecureSignalingUrl_5(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_uForceSecureSignaling_6(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_uIceServer_7(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_uIceServerUser_8(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_uIceServerPassword_9(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_uIceServer2_10(),
	0,
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mCall_12(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mUi_13(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mMediaConfig_14(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mCallActive_15(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mUseAddress_16(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mMediaConfigInUse_17(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mRemoteUserId_18(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mAutoRejoin_19(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mRejoinTime_20(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mLocalFrameEvents_21(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3243 = { sizeof (U3CCoroutineRejoinU3Ed__37_tE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3243[3] = 
{
	U3CCoroutineRejoinU3Ed__37_tE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2::get_offset_of_U3CU3E1__state_0(),
	U3CCoroutineRejoinU3Ed__37_tE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2::get_offset_of_U3CU3E2__current_1(),
	U3CCoroutineRejoinU3Ed__37_tE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2::get_offset_of_U3CU3E4__this_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3244 = { sizeof (CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867), -1, sizeof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3244[66] = 
{
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mLocalVideoTexture_4(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mRemoteVideoTexture_5(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uSetupPanel_6(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uMainSetupPanel_7(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uRoomNameInputField_8(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uJoinButton_9(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uAudioToggle_10(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uVideoToggle_11(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uVideoDropdown_12(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uSettingsPanel_13(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uIdealWidth_14(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uIdealHeight_15(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uIdealFps_16(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uRejoinToggle_17(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uLocalVideoToggle_18(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uInCallBase_19(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uVideoPanel_20(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uChatPanel_21(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uVideoOverlay_22(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uVideoBase_23(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uChatBase_24(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uFullscreenPanel_25(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uVideoBaseFullscreen_26(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uChatBaseFullscreen_27(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uMessageInputField_28(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uMessageOutput_29(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uSendMessageButton_30(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uShutdownButton_31(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uMuteToggle_32(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uLoudspeakerToggle_33(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uVolumeSlider_34(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uOverlayInfo_35(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uLocalVideoImage_36(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uRemoteVideoImage_37(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uNoCameraTexture_38(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mFullscreen_39(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mApp_40(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mVideoOverlayTimeout_41(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields::get_offset_of_sDefaultOverlayTimeout_42(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mHasLocalVideo_43(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mLocalVideoWidth_44(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mLocalVideoHeight_45(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mLocalFps_46(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mLocalFrameCounter_47(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mLocalRotation_48(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mLocalVideoFormat_49(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mHasRemoteVideo_50(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mRemoteVideoWidth_51(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mRemoteVideoHeight_52(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mRemoteFps_53(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mRemoteRotation_54(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mRemoteFrameCounter_55(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mRemoteVideoFormat_56(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mFpsTimer_57(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mPrefix_58(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields::get_offset_of_PREF_AUDIO_59(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields::get_offset_of_PREF_VIDEO_60(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields::get_offset_of_PREF_VIDEODEVICE_61(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields::get_offset_of_PREF_ROOMNAME_62(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields::get_offset_of_PREF_IDEALWIDTH_63(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields::get_offset_of_PREF_IDEALHEIGHT_64(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields::get_offset_of_PREF_IDEALFPS_65(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields::get_offset_of_PREF_REJOIN_66(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields::get_offset_of_PREF_LOCALVIDEO_67(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uLoadSettings_68(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mStoredVideoDevice_69(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3245 = { sizeof (U3CRequestAudioPermissionsU3Ed__74_tC2964A0B16259642A4238D66EEBFA7C88E47DE18), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3245[3] = 
{
	U3CRequestAudioPermissionsU3Ed__74_tC2964A0B16259642A4238D66EEBFA7C88E47DE18::get_offset_of_U3CU3E1__state_0(),
	U3CRequestAudioPermissionsU3Ed__74_tC2964A0B16259642A4238D66EEBFA7C88E47DE18::get_offset_of_U3CU3E2__current_1(),
	U3CRequestAudioPermissionsU3Ed__74_tC2964A0B16259642A4238D66EEBFA7C88E47DE18::get_offset_of_U3CU3E4__this_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3246 = { sizeof (U3CRequestVideoPermissionsU3Ed__75_t4DF1B5D81BE5CEEFBA0517D525BF46D27F21446F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3246[3] = 
{
	U3CRequestVideoPermissionsU3Ed__75_t4DF1B5D81BE5CEEFBA0517D525BF46D27F21446F::get_offset_of_U3CU3E1__state_0(),
	U3CRequestVideoPermissionsU3Ed__75_t4DF1B5D81BE5CEEFBA0517D525BF46D27F21446F::get_offset_of_U3CU3E2__current_1(),
	U3CRequestVideoPermissionsU3Ed__75_t4DF1B5D81BE5CEEFBA0517D525BF46D27F21446F::get_offset_of_U3CU3E4__this_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3247 = { sizeof (ImgFitter_t8C2D5035D612E3A0EA1E2F51DFD3870672984F40), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3248 = { sizeof (VideoPanelEventHandler_t3541E619FE0500181F23443D1B6C8FD05DC18802), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3248[2] = 
{
	VideoPanelEventHandler_t3541E619FE0500181F23443D1B6C8FD05DC18802::get_offset_of_mParent_4(),
	VideoPanelEventHandler_t3541E619FE0500181F23443D1B6C8FD05DC18802::get_offset_of_mLastClick_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3249 = { sizeof (ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3249[18] = 
{
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uSignalingUrl_4(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uSecureSignalingUrl_5(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uForceSecureSignaling_6(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uIceServer_7(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uIceServerUser_8(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uIceServerPassword_9(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uIceServer2_10(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uRoomName_11(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uMessageInput_12(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uOutput_13(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uJoin_14(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uSend_15(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uOpenRoom_16(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uLeave_17(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_mNetwork_18(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_mIsServer_19(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_mConnections_20(),
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3250 = { sizeof (MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3250[4] = 
{
	MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC::get_offset_of_uEntryPrefab_4(),
	MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC::get_offset_of_mOwnTransform_5(),
	MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC::get_offset_of_mMaxMessages_6(),
	MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC::get_offset_of_mCounter_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3251 = { sizeof (GridManager_t05748D877516CE2E0F9FBFACCF8AF0F6A21D4804), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3251[3] = 
{
	GridManager_t05748D877516CE2E0F9FBFACCF8AF0F6A21D4804::get_offset_of_mKnownItems_4(),
	GridManager_t05748D877516CE2E0F9FBFACCF8AF0F6A21D4804::get_offset_of_mGrid_5(),
	GridManager_t05748D877516CE2E0F9FBFACCF8AF0F6A21D4804::get_offset_of_mTransform_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3252 = { sizeof (MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66), -1, sizeof(MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3252[3] = 
{
	MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66_StaticFields::get_offset_of_sCreated_4(),
	MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66::get_offset_of__StartMenu_5(),
	MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66::get_offset_of__ButtonMenu_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3253 = { sizeof (AndroidHelper_tC0B54CF40032DFE35CD9AB26816E265E12D56969), -1, sizeof(AndroidHelper_tC0B54CF40032DFE35CD9AB26816E265E12D56969_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3253[2] = 
{
	AndroidHelper_tC0B54CF40032DFE35CD9AB26816E265E12D56969_StaticFields::get_offset_of_jclass_AndroidVideo_0(),
	AndroidHelper_tC0B54CF40032DFE35CD9AB26816E265E12D56969_StaticFields::get_offset_of_jclass_PermissionHelper_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3254 = { sizeof (UnityHelper_t8385B1C3D90FCE7C88494C24381E90C932B73841), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3255 = { sizeof (UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB), -1, sizeof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3255[16] = 
{
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_ALLOW_SYNCHRONOUS_INIT_4(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_ANDROID_SET_COMMUNICATION_MODE_5(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_KEEP_AWAKE_7(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_DEFAULT_LOG_LEVEL_8(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_NATIVE_VERBOSE_LOG_9(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB::get_offset_of_mAndroidPreviousAudioMode_10(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB::get_offset_of_mSleepTimeoutBackup_11(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB::get_offset_of_mHasActiveCall_12(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_sInitState_13(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_sInitCallbacks_14(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_sInitFailedMessage_15(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_sActiveLogLevel_16(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_LOG_PREFIX_17(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_sInstance_18(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB::get_offset_of_mFactory_19(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3256 = { sizeof (InitState_tF0A3A2CE215643EDF5BC6E278CE7E7578E38A18C)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3256[7] = 
{
	InitState_tF0A3A2CE215643EDF5BC6E278CE7E7578E38A18C::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3257 = { sizeof (InitCallbacks_t1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3257[2] = 
{
	InitCallbacks_t1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6::get_offset_of_onSuccess_0(),
	InitCallbacks_t1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6::get_offset_of_onFailure_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3258 = { sizeof (InitStatusUpdate_t9CB7C4BBAF73AE515E423C78CBDE4AB3C0ED96AF)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3258[4] = 
{
	InitStatusUpdate_t9CB7C4BBAF73AE515E423C78CBDE4AB3C0ED96AF::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3259 = { sizeof (LogLevel_tEBEAF97CA6FC143AAFFCBF123E970D39D79AE144)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3259[5] = 
{
	LogLevel_tEBEAF97CA6FC143AAFFCBF123E970D39D79AE144::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3260 = { sizeof (U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3260[4] = 
{
	U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9::get_offset_of_U3CU3E1__state_0(),
	U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9::get_offset_of_U3CU3E2__current_1(),
	U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9::get_offset_of_U3CU3E4__this_2(),
	U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9::get_offset_of_U3CwaitCounterU3E5__2_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3261 = { sizeof (U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE), -1, sizeof(U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3261[2] = 
{
	U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_StaticFields::get_offset_of_U3CU3E9_0(),
	U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_StaticFields::get_offset_of_U3CU3E9__30_0_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3262 = { sizeof (UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00), -1, sizeof(UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3262[3] = 
{
	UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00_StaticFields::get_offset_of_I420_MAT_NAME_0(),
	UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00_StaticFields::get_offset_of_I420_MAT_UPLANE_1(),
	UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00_StaticFields::get_offset_of_I420_MAT_VPLANE_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3263 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable3263[3] = 
{
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3264 = { sizeof (ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B), -1, sizeof(ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3264[5] = 
{
	ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields::get_offset_of_StunUrl_0(),
	ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields::get_offset_of_TurnUrl_1(),
	ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields::get_offset_of_TurnUser_2(),
	ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields::get_offset_of_TurnPass_3(),
	ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields::get_offset_of_BackupStunUrl_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3265 = { sizeof (U3CRequestAudioPermissionU3Ed__17_tCBCB2E5936A36A838919E3777D2B4B3FD140600E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3265[2] = 
{
	U3CRequestAudioPermissionU3Ed__17_tCBCB2E5936A36A838919E3777D2B4B3FD140600E::get_offset_of_U3CU3E1__state_0(),
	U3CRequestAudioPermissionU3Ed__17_tCBCB2E5936A36A838919E3777D2B4B3FD140600E::get_offset_of_U3CU3E2__current_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3266 = { sizeof (U3CRequestVideoPermissionU3Ed__18_t284CC5B8067172F41554DA77F7863C49E75F053E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3266[2] = 
{
	U3CRequestVideoPermissionU3Ed__18_t284CC5B8067172F41554DA77F7863C49E75F053E::get_offset_of_U3CU3E1__state_0(),
	U3CRequestVideoPermissionU3Ed__18_t284CC5B8067172F41554DA77F7863C49E75F053E::get_offset_of_U3CU3E2__current_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3267 = { sizeof (U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3267[4] = 
{
	U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856::get_offset_of_U3CU3E1__state_0(),
	U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856::get_offset_of_U3CU3E2__current_1(),
	U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856::get_offset_of_audio_2(),
	U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856::get_offset_of_video_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3268 = { sizeof (MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3268[4] = 
{
	MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73::get_offset_of_sender_4(),
	MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73::get_offset_of_receiver_5(),
	MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73::get_offset_of_netConf_6(),
	MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73::get_offset_of_address_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3269 = { sizeof (MinimalConference_t9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3269[3] = 
{
	MinimalConference_t9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3::get_offset_of_calls_4(),
	MinimalConference_t9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3::get_offset_of_netConf_5(),
	MinimalConference_t9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3::get_offset_of_address_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3270 = { sizeof (MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3270[6] = 
{
	MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF::get_offset_of_sender_4(),
	MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF::get_offset_of_mSenderConfigured_5(),
	MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF::get_offset_of_receiver_6(),
	MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF::get_offset_of_mReceiverConfigured_7(),
	MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF::get_offset_of_netConf_8(),
	MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF::get_offset_of_address_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3271 = { sizeof (SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3271[6] = 
{
	SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD::get_offset_of__Sender_4(),
	SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD::get_offset_of__LocalImage_5(),
	SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD::get_offset_of__RemoteImage_6(),
	SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD::get_offset_of__TryI420_7(),
	SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD::get_offset_of_mState_8(),
	SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD::get_offset_of_mCall_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3272 = { sizeof (SimpleCallState_t57C23CDEB50ACA1A8FEE6905D5B0B3DBEBA5493A)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3272[7] = 
{
	SimpleCallState_t57C23CDEB50ACA1A8FEE6905D5B0B3DBEBA5493A::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3273 = { sizeof (U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3273[4] = 
{
	U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68::get_offset_of_U3CU3E1__state_0(),
	U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68::get_offset_of_U3CU3E2__current_1(),
	U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68::get_offset_of_startInSec_2(),
	U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68::get_offset_of_U3CU3E4__this_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3274 = { sizeof (OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086), -1, sizeof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3274[11] = 
{
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_mSignalingServer_4(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_mStunServer_5(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_mMediaNetwork_6(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_mMediaConfig_7(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086_StaticFields::get_offset_of_sInstances_8(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_mIndex_9(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_uSender_10(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_uVideoOutput_11(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_mVideoTexture_12(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086_StaticFields::get_offset_of_sAddress_13(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_mConnectionIds_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3275 = { sizeof (U3CStartU3Ed__11_t55FDB25F620252AE5B728D0548DB05649BD4CAC8), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3275[3] = 
{
	U3CStartU3Ed__11_t55FDB25F620252AE5B728D0548DB05649BD4CAC8::get_offset_of_U3CU3E1__state_0(),
	U3CStartU3Ed__11_t55FDB25F620252AE5B728D0548DB05649BD4CAC8::get_offset_of_U3CU3E2__current_1(),
	U3CStartU3Ed__11_t55FDB25F620252AE5B728D0548DB05649BD4CAC8::get_offset_of_U3CU3E4__this_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3276 = { sizeof (ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3276[14] = 
{
	0,
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uRoomName_5(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uMessageField_6(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uOutput_7(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uJoin_8(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uSend_9(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uShutdown_10(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uSetupPanel_11(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uVideoLayout_12(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uVideoPrefab_13(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uNoImgTexture_14(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_mCall_15(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_config_16(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_mVideoUiElements_17(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3277 = { sizeof (VideoData_t9C078487B97498970A01E98DEF8304B622527398), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3277[3] = 
{
	VideoData_t9C078487B97498970A01E98DEF8304B622527398::get_offset_of_uiObject_0(),
	VideoData_t9C078487B97498970A01E98DEF8304B622527398::get_offset_of_texture_1(),
	VideoData_t9C078487B97498970A01E98DEF8304B622527398::get_offset_of_image_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3278 = { sizeof (VideoInputApp_tBD1B4BA06062C26F8519013F665376060F9FC2CF), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3279 = { sizeof (U3CCoroutineRefreshLaterU3Ed__1_t9AF1BDEE238458547E50F4B52D8F01FDAC02D18E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3279[3] = 
{
	U3CCoroutineRefreshLaterU3Ed__1_t9AF1BDEE238458547E50F4B52D8F01FDAC02D18E::get_offset_of_U3CU3E1__state_0(),
	U3CCoroutineRefreshLaterU3Ed__1_t9AF1BDEE238458547E50F4B52D8F01FDAC02D18E::get_offset_of_U3CU3E2__current_1(),
	U3CCoroutineRefreshLaterU3Ed__1_t9AF1BDEE238458547E50F4B52D8F01FDAC02D18E::get_offset_of_U3CU3E4__this_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3280 = { sizeof (VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3280[12] = 
{
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of__Camera_4(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of_mLastSample_5(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of_mTexture_6(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of_mRtBuffer_7(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of__DebugTarget_8(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of__DeviceName_9(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of__Fps_10(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of__Width_11(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of__Height_12(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of_mUsedDeviceName_13(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of_mByteBuffer_14(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of_mVideoInput_15(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
