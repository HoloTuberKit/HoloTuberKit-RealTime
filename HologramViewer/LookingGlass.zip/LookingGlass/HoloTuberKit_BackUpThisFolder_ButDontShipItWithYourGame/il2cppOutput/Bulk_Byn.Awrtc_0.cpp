﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "il2cpp-class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"

template <typename R, typename T1>
struct VirtFuncInvoker1
{
	typedef R (*Func)(void*, T1, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
template <typename R, typename T1, typename T2, typename T3, typename T4, typename T5>
struct VirtFuncInvoker5
{
	typedef R (*Func)(void*, T1, T2, T3, T4, T5, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1, T2 p2, T3 p3, T4 p4, T5 p5)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, p3, p4, p5, invokeData.method);
	}
};
template <typename R, typename T1, typename T2, typename T3>
struct VirtFuncInvoker3
{
	typedef R (*Func)(void*, T1, T2, T3, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1, T2 p2, T3 p3)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, p3, invokeData.method);
	}
};
template <typename T1>
struct VirtActionInvoker1
{
	typedef void (*Action)(void*, T1, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		((Action)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
struct VirtActionInvoker0
{
	typedef void (*Action)(void*, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		((Action)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename T1, typename T2>
struct VirtActionInvoker2
{
	typedef void (*Action)(void*, T1, T2, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeObject* obj, T1 p1, T2 p2)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		((Action)invokeData.methodPtr)(obj, p1, p2, invokeData.method);
	}
};
template <typename R>
struct VirtFuncInvoker0
{
	typedef R (*Func)(void*, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_virtual_invoke_data(slot, obj);
		return ((Func)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename T1>
struct GenericVirtActionInvoker1
{
	typedef void (*Action)(void*, T1, const RuntimeMethod*);

	static inline void Invoke (const RuntimeMethod* method, RuntimeObject* obj, T1 p1)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_virtual_invoke_data(method, obj, &invokeData);
		((Action)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
template <typename T1, typename T2>
struct GenericVirtActionInvoker2
{
	typedef void (*Action)(void*, T1, T2, const RuntimeMethod*);

	static inline void Invoke (const RuntimeMethod* method, RuntimeObject* obj, T1 p1, T2 p2)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_virtual_invoke_data(method, obj, &invokeData);
		((Action)invokeData.methodPtr)(obj, p1, p2, invokeData.method);
	}
};
template <typename T1>
struct InterfaceActionInvoker1
{
	typedef void (*Action)(void*, T1, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj, T1 p1)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		((Action)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
template <typename R, typename T1, typename T2, typename T3, typename T4, typename T5>
struct InterfaceFuncInvoker5
{
	typedef R (*Func)(void*, T1, T2, T3, T4, T5, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj, T1 p1, T2 p2, T3 p3, T4 p4, T5 p5)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		return ((Func)invokeData.methodPtr)(obj, p1, p2, p3, p4, p5, invokeData.method);
	}
};
struct InterfaceActionInvoker0
{
	typedef void (*Action)(void*, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		((Action)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename R>
struct InterfaceFuncInvoker0
{
	typedef R (*Func)(void*, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		return ((Func)invokeData.methodPtr)(obj, invokeData.method);
	}
};
template <typename R, typename T1>
struct InterfaceFuncInvoker1
{
	typedef R (*Func)(void*, T1, const RuntimeMethod*);

	static inline R Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj, T1 p1)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		return ((Func)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
template <typename T1, typename T2>
struct InterfaceActionInvoker2
{
	typedef void (*Action)(void*, T1, T2, const RuntimeMethod*);

	static inline void Invoke (Il2CppMethodSlot slot, RuntimeClass* declaringInterface, RuntimeObject* obj, T1 p1, T2 p2)
	{
		const VirtualInvokeData& invokeData = il2cpp_codegen_get_interface_invoke_data(slot, obj, declaringInterface);
		((Action)invokeData.methodPtr)(obj, p1, p2, invokeData.method);
	}
};
template <typename T1>
struct GenericInterfaceActionInvoker1
{
	typedef void (*Action)(void*, T1, const RuntimeMethod*);

	static inline void Invoke (const RuntimeMethod* method, RuntimeObject* obj, T1 p1)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_interface_invoke_data(method, obj, &invokeData);
		((Action)invokeData.methodPtr)(obj, p1, invokeData.method);
	}
};
template <typename T1, typename T2>
struct GenericInterfaceActionInvoker2
{
	typedef void (*Action)(void*, T1, T2, const RuntimeMethod*);

	static inline void Invoke (const RuntimeMethod* method, RuntimeObject* obj, T1 p1, T2 p2)
	{
		VirtualInvokeData invokeData;
		il2cpp_codegen_get_generic_interface_invoke_data(method, obj, &invokeData);
		((Action)invokeData.methodPtr)(obj, p1, p2, invokeData.method);
	}
};

// Byn.Awrtc.Base.AWebRtcCall
struct AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3;
// Byn.Awrtc.BufferedFrame
struct BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028;
// Byn.Awrtc.ByteArrayBuffer
struct ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B;
// Byn.Awrtc.ByteArrayBuffer[]
struct ByteArrayBufferU5BU5D_tC32F3D7B0B29CCF15D73904436B2C68139358EBD;
// Byn.Awrtc.CallAcceptedEventArgs
struct CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA;
// Byn.Awrtc.CallEndedEventArgs
struct CallEndedEventArgs_tE3A3B50FDE883A4D052920EB6073028ACFF81128;
// Byn.Awrtc.CallEventArgs
struct CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0;
// Byn.Awrtc.CallEventHandler
struct CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F;
// Byn.Awrtc.ConnectionId[]
struct ConnectionIdU5BU5D_t7B8CFD2BA9E73DEBAE908EE9BA8B3B81A8640294;
// Byn.Awrtc.DataMessageEventArgs
struct DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37;
// Byn.Awrtc.ErrorEventArgs
struct ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246;
// Byn.Awrtc.ErrorInfo
struct ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167;
// Byn.Awrtc.FrameUpdateEventArgs
struct FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C;
// Byn.Awrtc.IFrame
struct IFrame_t2FE867CC6939ADD4973D8276E9AEFD826F88DF29;
// Byn.Awrtc.IMediaNetwork
struct IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780;
// Byn.Awrtc.IceServer
struct IceServer_t423A5044DD3B2346555973AF68F71585262E07FA;
// Byn.Awrtc.IceServer[]
struct IceServerU5BU5D_t77B1ADF58E5BEF879817A80953BA71C121730B4A;
// Byn.Awrtc.LocalNetwork
struct LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562;
// Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>
struct WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4;
// Byn.Awrtc.LocalNetwork/WeakRef`1<System.Object>
struct WeakRef_1_tB639BA5FF05FD4ED10233CC43A667DD2FC343F09;
// Byn.Awrtc.MediaConfig
struct MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D;
// Byn.Awrtc.MessageDataBuffer
struct MessageDataBuffer_t4A531F1D6D5F8E87A1BBB8C1D88A497911547498;
// Byn.Awrtc.MessageEventArgs
struct MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899;
// Byn.Awrtc.NetworkConfig
struct NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47;
// Byn.Awrtc.NetworkEvent[]
struct NetworkEventU5BU5D_tFA57E65F46AEB90C286C05581A6779F52D0D3EB7;
// Byn.Awrtc.WaitForIncomingCallEventArgs
struct WaitForIncomingCallEventArgs_tD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86;
// System.Action`2<System.Object,System.Object>
struct Action_2_t0DB6FD6F515527EAB552B690A291778C6F00D48C;
// System.Action`2<System.Object,System.String[]>
struct Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944;
// System.ArgumentException
struct ArgumentException_tEDCD16F20A09ECE461C3DA766C16EDA8864057D1;
// System.ArgumentNullException
struct ArgumentNullException_t581DF992B1F3E0EC6EFB30CC5DC43519A79B27AD;
// System.AsyncCallback
struct AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4;
// System.Byte[]
struct ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821;
// System.Char[]
struct CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2;
// System.Collections.Generic.Dictionary`2/Entry<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>[]
struct EntryU5BU5D_tA4B673A05D77A5FCA37E40F6370339CAA5C4F365;
// System.Collections.Generic.Dictionary`2/Entry<System.String,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>[]
struct EntryU5BU5D_t2ACD1753663539A43B6379B927005ADFCC7515E4;
// System.Collections.Generic.Dictionary`2/KeyCollection<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>
struct KeyCollection_t22184C5C648B98E1130AB2CB15D732A497552019;
// System.Collections.Generic.Dictionary`2/KeyCollection<Byn.Awrtc.ConnectionId,System.Object>
struct KeyCollection_tC2B692E517123E3B3A679254DD7F6C108A3D378F;
// System.Collections.Generic.Dictionary`2/KeyCollection<System.String,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>
struct KeyCollection_tBF5A3A379C2FAEE27B40772C452E5AE4593478D8;
// System.Collections.Generic.Dictionary`2/ValueCollection<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>
struct ValueCollection_t85AAC7C15DB90E887637FDBA486CB308EFD4F22A;
// System.Collections.Generic.Dictionary`2/ValueCollection<System.String,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>
struct ValueCollection_t271CAD233177D02D832E2497CF966741D6EDCE05;
// System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>
struct Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB;
// System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,System.Object>
struct Dictionary_2_t93B36C589E8EDDC45BBAB60515EA59C54EAEE5B0;
// System.Collections.Generic.Dictionary`2<System.Object,System.Object>
struct Dictionary_2_t32F25F093828AA9F93CB11C2A2B4648FD62A09BA;
// System.Collections.Generic.Dictionary`2<System.String,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>
struct Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2;
// System.Collections.Generic.IEnumerable`1<Byn.Awrtc.ConnectionId>
struct IEnumerable_1_t38212E4DAAA48AEFB47C5154E1C16643B9C51FFA;
// System.Collections.Generic.IEnumerable`1<System.Object>
struct IEnumerable_1_t2F75FCBEC68AFE08982DA43985F9D04056E2BE73;
// System.Collections.Generic.IEnumerable`1<System.String>
struct IEnumerable_1_t31EF1520A3A805598500BB6033C14ABDA7116D5E;
// System.Collections.Generic.IEqualityComparer`1<Byn.Awrtc.ConnectionId>
struct IEqualityComparer_1_tC8A617F989ECE3D96188A14E138E3A10CF9D60C1;
// System.Collections.Generic.IEqualityComparer`1<System.String>
struct IEqualityComparer_1_t1F07EAC22CC1D4F279164B144240E4718BD7E7A9;
// System.Collections.Generic.List`1<Byn.Awrtc.ByteArrayBuffer>
struct List_1_t43B2D37CF48E04673A48558029581722DDF26F4E;
// System.Collections.Generic.List`1<Byn.Awrtc.ByteArrayBuffer>[]
struct List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592;
// System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>
struct List_1_tCB9967EC4C00221A410117D712FF423882EB5832;
// System.Collections.Generic.List`1<Byn.Awrtc.IceServer>
struct List_1_t071E9AF889461644CC5513065D8B09A62D4EE708;
// System.Collections.Generic.List`1<System.Object>
struct List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D;
// System.Collections.Generic.List`1<System.String>
struct List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3;
// System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent>
struct Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF;
// System.Collections.Hashtable
struct Hashtable_t978F65B8006C8F5504B286526AEC6608FF983FC9;
// System.Collections.IDictionary
struct IDictionary_t1BD5C1546718A374EA8122FBD6C6EE45331E8CE7;
// System.Delegate
struct Delegate_t;
// System.DelegateData
struct DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE;
// System.Delegate[]
struct DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86;
// System.Diagnostics.StackTrace[]
struct StackTraceU5BU5D_t855F09649EA34DEE7C1B6F088E0538E3CCC3F196;
// System.Globalization.CodePageDataItem
struct CodePageDataItem_t6E34BEE9CCCBB35C88D714664633AF6E5F5671FB;
// System.IAsyncResult
struct IAsyncResult_t8E194308510B375B42432981AE5E7488C458D598;
// System.Int32[]
struct Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83;
// System.IntPtr[]
struct IntPtrU5BU5D_t4DC01DCB9A6DF6C9792A6513595D7A11E637DCDD;
// System.InvalidOperationException
struct InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1;
// System.Object[]
struct ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.Runtime.Serialization.SafeSerializationManager
struct SafeSerializationManager_t4A754D86B0F784B18CBC36C073BA564BED109770;
// System.String
struct String_t;
// System.String[]
struct StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E;
// System.Text.DecoderFallback
struct DecoderFallback_t128445EB7676870485230893338EF044F6B72F60;
// System.Text.EncoderFallback
struct EncoderFallback_tDE342346D01608628F1BCEBB652D31009852CF63;
// System.Text.Encoding
struct Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4;
// System.Text.StringBuilder
struct StringBuilder_t;
// System.Void
struct Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017;
// System.WeakReference
struct WeakReference_t0495CC81CD6403E662B7700B802443F6F730E39D;

extern RuntimeClass* AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var;
extern RuntimeClass* ArgumentException_tEDCD16F20A09ECE461C3DA766C16EDA8864057D1_il2cpp_TypeInfo_var;
extern RuntimeClass* ArgumentNullException_t581DF992B1F3E0EC6EFB30CC5DC43519A79B27AD_il2cpp_TypeInfo_var;
extern RuntimeClass* BitConverter_tD5DF1CB5C5A5CB087D90BD881C8E75A332E546EE_il2cpp_TypeInfo_var;
extern RuntimeClass* ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var;
extern RuntimeClass* ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821_il2cpp_TypeInfo_var;
extern RuntimeClass* Byte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_il2cpp_TypeInfo_var;
extern RuntimeClass* CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA_il2cpp_TypeInfo_var;
extern RuntimeClass* CallEndedEventArgs_tE3A3B50FDE883A4D052920EB6073028ACFF81128_il2cpp_TypeInfo_var;
extern RuntimeClass* CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0_il2cpp_TypeInfo_var;
extern RuntimeClass* CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F_il2cpp_TypeInfo_var;
extern RuntimeClass* CallState_t4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_il2cpp_TypeInfo_var;
extern RuntimeClass* ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var;
extern RuntimeClass* DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37_il2cpp_TypeInfo_var;
extern RuntimeClass* DefaultValues_tFB168B56BA06FD7096D0B3A6454AD6873A4104CA_il2cpp_TypeInfo_var;
extern RuntimeClass* Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2_il2cpp_TypeInfo_var;
extern RuntimeClass* Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB_il2cpp_TypeInfo_var;
extern RuntimeClass* ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246_il2cpp_TypeInfo_var;
extern RuntimeClass* ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var;
extern RuntimeClass* FramePixelFormat_tDCE4288D3AD386370E428FCC0668229B6994D9BB_il2cpp_TypeInfo_var;
extern RuntimeClass* FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C_il2cpp_TypeInfo_var;
extern RuntimeClass* IBasicNetwork_t60318DADF4A0AF6F2063D0F7E9CE5611F6CB198D_il2cpp_TypeInfo_var;
extern RuntimeClass* IDisposable_t7218B22548186B208D65EA5B7870503810A2D15A_il2cpp_TypeInfo_var;
extern RuntimeClass* IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780_il2cpp_TypeInfo_var;
extern RuntimeClass* INetwork_t2BC558248C74706BEF2D050A9084AB9FB14697F2_il2cpp_TypeInfo_var;
extern RuntimeClass* Il2CppComObject_il2cpp_TypeInfo_var;
extern RuntimeClass* Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83_il2cpp_TypeInfo_var;
extern RuntimeClass* Int32_t585191389E07734F19F3156FF88FB3EF4800D102_il2cpp_TypeInfo_var;
extern RuntimeClass* InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1_il2cpp_TypeInfo_var;
extern RuntimeClass* List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592_il2cpp_TypeInfo_var;
extern RuntimeClass* List_1_t071E9AF889461644CC5513065D8B09A62D4EE708_il2cpp_TypeInfo_var;
extern RuntimeClass* List_1_t43B2D37CF48E04673A48558029581722DDF26F4E_il2cpp_TypeInfo_var;
extern RuntimeClass* List_1_tCB9967EC4C00221A410117D712FF423882EB5832_il2cpp_TypeInfo_var;
extern RuntimeClass* List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3_il2cpp_TypeInfo_var;
extern RuntimeClass* LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var;
extern RuntimeClass* MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D_il2cpp_TypeInfo_var;
extern RuntimeClass* MessageDataBuffer_t4A531F1D6D5F8E87A1BBB8C1D88A497911547498_il2cpp_TypeInfo_var;
extern RuntimeClass* MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899_il2cpp_TypeInfo_var;
extern RuntimeClass* NetEventType_tD5213CE1DD8CDE1161395E0973FC1F8E5FB7B0A8_il2cpp_TypeInfo_var;
extern RuntimeClass* NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47_il2cpp_TypeInfo_var;
extern RuntimeClass* Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_il2cpp_TypeInfo_var;
extern RuntimeClass* Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF_il2cpp_TypeInfo_var;
extern RuntimeClass* SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var;
extern RuntimeClass* StringBuilder_t_il2cpp_TypeInfo_var;
extern RuntimeClass* StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var;
extern RuntimeClass* String_t_il2cpp_TypeInfo_var;
extern RuntimeClass* WaitForIncomingCallEventArgs_tD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86_il2cpp_TypeInfo_var;
extern RuntimeClass* WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4_il2cpp_TypeInfo_var;
extern RuntimeField* U3CPrivateImplementationDetailsU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_t0EF491E7C6CA3D3B0D052D94577A25F2983BB080____U24U24method0x6000054U2D1_0_FieldInfo_var;
extern String_t* _stringLiteral00BA3C9A92109B36A8FFDBA4A8323A8E89412FCC;
extern String_t* _stringLiteral09A4151F14096C2A7408B4149DE022F1D966AEA8;
extern String_t* _stringLiteral0A2B0546FA1894D166AFC9DBBA2D981CBBC0D3AB;
extern String_t* _stringLiteral0A9602F009430E7B9AB88CAE301B9EDE3D4C606E;
extern String_t* _stringLiteral0B99CEBE565822C64AC5D84AECB00FE40E59CBD3;
extern String_t* _stringLiteral0BEC5A2BEF18B46CACEFC216CF20B85002919CB0;
extern String_t* _stringLiteral10F8A517AC4EB3CB8D93AA1A33C9C5F706B3F896;
extern String_t* _stringLiteral155ED2E1623BE36604E1FC855CB6975C8D4F65E8;
extern String_t* _stringLiteral15B8795405497E337C7EA8AE5F558C94E45E5F5C;
extern String_t* _stringLiteral27743FF867B90795547A94A6879B23455154D7CB;
extern String_t* _stringLiteral29713B181926E55DFCC9942DED648CB51605607D;
extern String_t* _stringLiteral2D4B2D61A9CC07F09AEC3507C0EEBDDFE12AD53C;
extern String_t* _stringLiteral31698239127E4EAC1142CFD64FAAE6593723B903;
extern String_t* _stringLiteral329ECD1B790864B732235061FB2A9F6BCFAF8A92;
extern String_t* _stringLiteral3716D64264F900396F1AF7FC16D7B86FDF992A50;
extern String_t* _stringLiteral39821B36332CB979269AACCAF1482F406B96CAB9;
extern String_t* _stringLiteral3A2336C7F3F6FE012EA560BAE437CD6848893503;
extern String_t* _stringLiteral3E81FC48A25FE5E253313F0757301CB954D9343C;
extern String_t* _stringLiteral3F67E8F4EECF241B91F4CC8C976A487ADE34D09D;
extern String_t* _stringLiteral436BCD6F201AF8D6436297C9014927BC8E346692;
extern String_t* _stringLiteral4B8425C313ECC40E5F2A30B13A056344376E4FD9;
extern String_t* _stringLiteral4C4E1AF40C023378252CB1E58AA124872F84B2AB;
extern String_t* _stringLiteral4E23A32827B8C9A20FB5A8553A8233548D1DF248;
extern String_t* _stringLiteral4FF447B8EF42CA51FA6FB287BED8D40F49BE58F1;
extern String_t* _stringLiteral577C74D4CC7F1E0145B12836205C46B679541C11;
extern String_t* _stringLiteral587B648C037DD2A8DF4F910CEA10C5F1645EF052;
extern String_t* _stringLiteral5B16BDBC5F99BD61B95D7D712F8F8CAE8AE1F036;
extern String_t* _stringLiteral5B8E7680AFA692243CBC67CBBF5C4A5B11CD144A;
extern String_t* _stringLiteral5C10B5B2CD673A0616D529AA5234B12EE7153808;
extern String_t* _stringLiteral60BA4B2DAA4ED4D070FEC06687E249E0E6F9EE45;
extern String_t* _stringLiteral645C18B68EF4227E273294B86C37A5E293ED2EAF;
extern String_t* _stringLiteral6B7F2BF79AADF0550CF3C31FA77DC122F0C35E56;
extern String_t* _stringLiteral7279BBEB8F30C2D351F23C21DA72A80940E69428;
extern String_t* _stringLiteral7C1991541B07E44CFE14A3786817A99E02646866;
extern String_t* _stringLiteral836DF255926302A2BED5CFD9869346BFB8BE6B7A;
extern String_t* _stringLiteral8585EF1239EC3A7825E5ACA3E5BB3BF44A44F792;
extern String_t* _stringLiteral8F1AA36AEDBD3E481D3236E3E4A8739EA0C14409;
extern String_t* _stringLiteral96E7E1D2A7678CA34E5FC0D0081CAAE74A18C363;
extern String_t* _stringLiteral9C9CF999829193894067BBD9E1484756AB736AC0;
extern String_t* _stringLiteral9D5DBE197A12DFB5E663F3779A1CEB136F2EEBA2;
extern String_t* _stringLiteralA0362F9D229E59514AF33D56FA8DC257B140B594;
extern String_t* _stringLiteralA1FEF0B42008F225256B6F991B25DDFFCFD238D7;
extern String_t* _stringLiteralA43C17788074B67365E30B18FF2C121BAA8FF253;
extern String_t* _stringLiteralA57963B8CBDC1274C9D2245EAB3570D076944944;
extern String_t* _stringLiteralA95558ADD3F80F61A7E7875E0C263324890E3782;
extern String_t* _stringLiteralAC6BE8502DAC9F9A3BCC544E72CEF0813C14EEBC;
extern String_t* _stringLiteralAD50C3BEAA126E3D524ABD3F15A336D933F6CDF1;
extern String_t* _stringLiteralAEEEE4762A134C720F75C41D126D0C6991B514AC;
extern String_t* _stringLiteralAFC1B662AA96F0A75E199326CB377CE0820597E3;
extern String_t* _stringLiteralB2CCBB7A7A9B6CB96A9B2513B508C1C56C569857;
extern String_t* _stringLiteralB51CBAA564000A2843B51CB636A2694EB74893D6;
extern String_t* _stringLiteralB7DC874978F66EBD04EDD88C5EF98788890F4068;
extern String_t* _stringLiteralBAED7BA5AEC6413E08748868412B7DC0CA626552;
extern String_t* _stringLiteralC2B7DF6201FDD3362399091F0A29550DF3505B6A;
extern String_t* _stringLiteralCE01E985552B87A2A43F9E63A696458D55DFA4E6;
extern String_t* _stringLiteralCF25C07F0472FA7268D2ACC313033D48FAED9821;
extern String_t* _stringLiteralD24A4420AE0C6330E6C72788294F1978C40BC5AB;
extern String_t* _stringLiteralD6160886EE4A4BC933529D59B510F8DAE55E981C;
extern String_t* _stringLiteralD61D3DAF249E2436C0AD63896FF6E5C0EE13F9AC;
extern String_t* _stringLiteralD838C49EC4C8CE20DC29CCB60C2789B5F0E47998;
extern String_t* _stringLiteralD8927A1FEADE42C87E0F653443C952EBE59AA0C6;
extern String_t* _stringLiteralDA39A3EE5E6B4B0D3255BFEF95601890AFD80709;
extern String_t* _stringLiteralDAE75A5B63A16B78EF40E2A6B8F852114C259234;
extern String_t* _stringLiteralDE4548A66DA089BE5B4BAA57D06B095DD67044D3;
extern String_t* _stringLiteralDF70FFC90A8389D569FB4969E8234AE261FDFB10;
extern String_t* _stringLiteralE76519C94CB56A5F865FF3FEBBE6DEC1B1A984CC;
extern String_t* _stringLiteralEDEA56933012F1F90F89A742C42A3C78EDC92A5D;
extern String_t* _stringLiteralF0DE57BC2779E3EA699DF1CEEF10793EFA55525E;
extern String_t* _stringLiteralF4C897B2DB3977E54492B9D5DC0FDFF516A4DF8A;
extern String_t* _stringLiteralF871D3987850781C13A3676A6FA22AE6FC2C6BDD;
extern String_t* _stringLiteralF8AA003D2600245E6F801C7DC7450EEC623397E9;
extern String_t* _stringLiteralFD3EDC641024A335A508FDACEFB5F51DED5905CC;
extern const RuntimeMethod* AWebRtcCall_Call_m02C9FCBC750B159F8C8DEF3EC869AEA673F45B11_RuntimeMethod_var;
extern const RuntimeMethod* AWebRtcCall_CheckDisposed_mD7EE6F33F9906A26C6CB83B0D103F50D9542F90B_RuntimeMethod_var;
extern const RuntimeMethod* AWebRtcCall_Configure_m8A0BB04F8590D2DCC55BA94B71E88ECC4526EFDB_RuntimeMethod_var;
extern const RuntimeMethod* AWebRtcCall_Listen_m130E1DF8EA39AE89D2B8C21C04454CCF3A0539C9_RuntimeMethod_var;
extern const RuntimeMethod* AWebRtcCall_UnpackStringMsg_mF8138BBBD07AC8F11499A0CAEF32B842F658B804_RuntimeMethod_var;
extern const RuntimeMethod* Action_2_Invoke_m81A2607B01BDBA54F7C5575704E3B52B9063A079_RuntimeMethod_var;
extern const RuntimeMethod* Array_Resize_TisString_t_m2F4F7DA2A10041FA80DD5A60977304E4803AAC17_RuntimeMethod_var;
extern const RuntimeMethod* ByteArrayBuffer_Dispose_mEEBA9EE7B80671DB5228061B31B43ED8F577CDF3_RuntimeMethod_var;
extern const RuntimeMethod* ByteArrayBuffer_get_Buffer_mEA87A81D37582411E6A368A0E111DF7BF394433F_RuntimeMethod_var;
extern const RuntimeMethod* ByteArrayBuffer_get_ContentLength_m7F0CA8BE74E0EE3AEDE7B8BBF797F8709E1307EF_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_Clear_m2E85D7A98838E7A8D9EFCF534596F39DFA0AA211_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_ContainsKey_m421F3F245DD820A5F1189EDFDE3364AA2811EFE3_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_ContainsKey_m7BFA24B1A05E327F5909B68AF1566C84BEFA6431_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_GetEnumerator_mE62B21D25025E42B5C035C8843139621A467EA22_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_Remove_m7985E72DCEF57B284CCA7633890A1FAC9F5169CA_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_Remove_mA480C3AD301A4030ED16BD4432EB7AEF76A7B4C4_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_TryGetValue_m42A4CC885EBDCFDC472F9F49D8683A6AAC23F9B9_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2__ctor_m218A1B086C18400F1C4C49B88A47AE87D133AF19_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2__ctor_mBE3AA4ECD11E0C6081829CED3F9A71E82C905F2A_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_get_Item_m1701F17231AAD3E30A9EACC44EBC78404D336E3D_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_get_Item_mED59F647D10601AFE6764BB277AC05B4673F158C_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_get_Keys_mEFE37E13A4EF1325942D50D41D88AA4EC71B76D7_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_set_Item_m9E06F377398DEEF5E6E39D45249196F434BC21C8_RuntimeMethod_var;
extern const RuntimeMethod* Dictionary_2_set_Item_mAA053E88F5E5469750D0D6CE2A7A36521BB7BF52_RuntimeMethod_var;
extern const RuntimeMethod* Enumerable_ToList_TisConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_m993BAFA400E4493769271824E19E78B7023A85C5_RuntimeMethod_var;
extern const RuntimeMethod* Enumerator_Dispose_m555891B16D47D7D2E19E328764F6E8AEB9BBE073_RuntimeMethod_var;
extern const RuntimeMethod* Enumerator_Dispose_m62E14E84F0EFE2CD8FC246C3779797583ED04D49_RuntimeMethod_var;
extern const RuntimeMethod* Enumerator_MoveNext_m50BD3D91B026FC120054CB6B187B49A57689E4E7_RuntimeMethod_var;
extern const RuntimeMethod* Enumerator_MoveNext_mADC221420F19A87B6C2DE5C2EE1C2796D03FA138_RuntimeMethod_var;
extern const RuntimeMethod* Enumerator_get_Current_m003120CE0D40F915FB399DE3CB7FD3DB8F5663DA_RuntimeMethod_var;
extern const RuntimeMethod* Enumerator_get_Current_m0203034B79126F512CC77691D03434942FE5EE6C_RuntimeMethod_var;
extern const RuntimeMethod* KeyValuePair_2_get_Key_mF0E7E961867D8DF96DBB3A101E204AFFF4BE8570_RuntimeMethod_var;
extern const RuntimeMethod* KeyValuePair_2_get_Value_mD5E7F1EC28FEF494AFD05F853C4B120549642FC1_RuntimeMethod_var;
extern const RuntimeMethod* List_1_Add_m8FC2727372ADD2DF6382E5687F43987CAEF0C19B_RuntimeMethod_var;
extern const RuntimeMethod* List_1_Add_mA348FA1140766465189459D25B01EB179001DE83_RuntimeMethod_var;
extern const RuntimeMethod* List_1_Add_mABE9CD5133D0735C8ECB22FAC67B02137BDCD6EA_RuntimeMethod_var;
extern const RuntimeMethod* List_1_Contains_m337011847BDC37E80915E17BAFEB39C2F5FBD448_RuntimeMethod_var;
extern const RuntimeMethod* List_1_GetEnumerator_m72711B857C13554E60D06AE2C418B4FA59870E65_RuntimeMethod_var;
extern const RuntimeMethod* List_1_RemoveAt_mEFDCEF7205CBAAE8676FB4BF94B91B5F7DF29113_RuntimeMethod_var;
extern const RuntimeMethod* List_1_Remove_mEB90299243C7D65EFFEC681D18CA1492DBA9A3A2_RuntimeMethod_var;
extern const RuntimeMethod* List_1__ctor_m348481CF5AD96E81E9F71B9B4052944396A6BB67_RuntimeMethod_var;
extern const RuntimeMethod* List_1__ctor_mC195748161C754C648AB7B1E192547FCFAAE5793_RuntimeMethod_var;
extern const RuntimeMethod* List_1__ctor_mDA22758D73530683C950C5CCF39BDB4E7E1F3F06_RuntimeMethod_var;
extern const RuntimeMethod* List_1__ctor_mE30432DD9DBAB30B7710521567A284CCF1B2E64F_RuntimeMethod_var;
extern const RuntimeMethod* List_1__ctor_mE9FDDA3E872C3CB2DBDC8562E9ABA76CA3124599_RuntimeMethod_var;
extern const RuntimeMethod* List_1_get_Count_m185E91DB90246AA3DA769184ADCC7B79E8F8E101_RuntimeMethod_var;
extern const RuntimeMethod* List_1_get_Count_m230B26A74F4411232759D13CD642C9B4FE621AD5_RuntimeMethod_var;
extern const RuntimeMethod* List_1_get_Count_m4151A68BD4CB1D737213E7595F574987F8C812B4_RuntimeMethod_var;
extern const RuntimeMethod* List_1_get_Count_mD6BCE7AA51AD2DF7D510F44A83CC847762DCBCFF_RuntimeMethod_var;
extern const RuntimeMethod* List_1_get_Item_mA5D732CCE04960301F17718BCCB163F63F83AE02_RuntimeMethod_var;
extern const RuntimeMethod* List_1_get_Item_mB739B0066E5F7EBDBA9978F24A73D26D4FAE5BED_RuntimeMethod_var;
extern const RuntimeMethod* List_1_get_Item_mE1FEED1E5EED436AB33E8CE49D4FF88CBBF502F4_RuntimeMethod_var;
extern const RuntimeMethod* LocalNetwork_ConnectClient_m2DA894173389D07ABAEECDA48F14DCBE6DD5D92D_RuntimeMethod_var;
extern const RuntimeMethod* NetworkEvent_FromByteArray_m31466305C7DB5DFC36469055EB90ECD536E165FC_RuntimeMethod_var;
extern const RuntimeMethod* NetworkEvent__ctor_mF53983C4264CD0231654304A49965EC5B9D94C9E_RuntimeMethod_var;
extern const RuntimeMethod* Nullable_1__ctor_m11F9C228CFDF836DDFCD7880C09CB4098AB9D7F2_RuntimeMethod_var;
extern const RuntimeMethod* Queue_1_Dequeue_m2D5C4E39A011B35CD6218B0FA62B5CB0D962F535_RuntimeMethod_var;
extern const RuntimeMethod* Queue_1_Enqueue_m4EABC517D5EF21AD49565B814AEBA980EEC805DB_RuntimeMethod_var;
extern const RuntimeMethod* Queue_1__ctor_m207784283861C71375B6A150AA6E6CD3CE6E1ECE_RuntimeMethod_var;
extern const RuntimeMethod* Queue_1_get_Count_mB49A946DB72811EC8C21C704B0973456642963CB_RuntimeMethod_var;
extern const RuntimeMethod* WeakRef_1_Get_m7326E507F345D748A6AD3E9BA422CFE3275BC7D8_RuntimeMethod_var;
extern const RuntimeMethod* WeakRef_1__ctor_mC13774F5C531EC799D4800F075E8FEE759322DC4_RuntimeMethod_var;
extern const uint32_t AWebRtcCall_Call_m02C9FCBC750B159F8C8DEF3EC869AEA673F45B11_MetadataUsageId;
extern const uint32_t AWebRtcCall_CheckDisposed_mD7EE6F33F9906A26C6CB83B0D103F50D9542F90B_MetadataUsageId;
extern const uint32_t AWebRtcCall_Configure_m8A0BB04F8590D2DCC55BA94B71E88ECC4526EFDB_MetadataUsageId;
extern const uint32_t AWebRtcCall_EnsureConfiguration_mAE816DED202FC4344ECF0EFE83E886024340C82C_MetadataUsageId;
extern const uint32_t AWebRtcCall_HandleMediaEvents_m841524A2FE667C7D2A272C5DF04365D1B8108B6B_MetadataUsageId;
extern const uint32_t AWebRtcCall_HandleNetworkEvent_m6E1AC4BC273D0574A85039E7CEF3798E704D3ECF_MetadataUsageId;
extern const uint32_t AWebRtcCall_HasAudioTrack_m6FF8B27547640444A150CBC4CD1563F8B485FEDF_MetadataUsageId;
extern const uint32_t AWebRtcCall_HasVideoTrack_m612410BE7D65CADC97140DADD188D51EDC5C74A5_MetadataUsageId;
extern const uint32_t AWebRtcCall_IsDataMsg_m91B5AB76EFE79A24690D9B83E5FCBBCB57C1E860_MetadataUsageId;
extern const uint32_t AWebRtcCall_IsMute_m82735D1F5EBE8EA88E0B20B1C15BFD057E1799AC_MetadataUsageId;
extern const uint32_t AWebRtcCall_IsStringMsg_m7F45CD2616184B9739365F17F027461489F20882_MetadataUsageId;
extern const uint32_t AWebRtcCall_Listen_m130E1DF8EA39AE89D2B8C21C04454CCF3A0539C9_MetadataUsageId;
extern const uint32_t AWebRtcCall_OnConfigurationComplete_mF6BED2C9B6EEF93AE305B540A32234F734B8016E_MetadataUsageId;
extern const uint32_t AWebRtcCall_OnConfigurationFailed_mCF1E7B2727703A3A0232C3528F5E3C1B766F0E8D_MetadataUsageId;
extern const uint32_t AWebRtcCall_PackStringMsg_m80338D0EE5DE8E91F2D4510DC604A3652B4A5663_MetadataUsageId;
extern const uint32_t AWebRtcCall_ProcessCall_mB92C63DDC4A918A067FBC9B8AF077513BCE9D422_MetadataUsageId;
extern const uint32_t AWebRtcCall_ProcessListen_m753AF5E46F70C7EC3F1E425CA13C514A77A3954B_MetadataUsageId;
extern const uint32_t AWebRtcCall_Send_mD6438A63F1C799D469A9822AD033768311D9EBA9_MetadataUsageId;
extern const uint32_t AWebRtcCall_SetMute_mC804CF0F1CBC2F7599A84B9063541D50B0A57A15_MetadataUsageId;
extern const uint32_t AWebRtcCall_SetVolume_m0DC6CA614675820CC0E3CA770ABB01D6E7314E06_MetadataUsageId;
extern const uint32_t AWebRtcCall_UnpackDataMsg_m86BF873565BFBC1B6E93DDF3BDB91994DA5BAFC7_MetadataUsageId;
extern const uint32_t AWebRtcCall_UnpackStringMsg_mF8138BBBD07AC8F11499A0CAEF32B842F658B804_MetadataUsageId;
extern const uint32_t AWebRtcCall_Update_m549A46BEA47F858AB137C76F856410223F150902_MetadataUsageId;
extern const uint32_t AWebRtcCall__cctor_m2451B853A8F1A96A5CA5A77F1BCD706ECB94DF1D_MetadataUsageId;
extern const uint32_t AWebRtcCall__ctor_mC4846A890AF3EC294C04F2BD4593F3721DF36A3C_MetadataUsageId;
extern const uint32_t AWebRtcCall_add_CallEvent_m09270F23CE78B01FADF2B457CAA8E6D278ACEB6F_MetadataUsageId;
extern const uint32_t AWebRtcCall_remove_CallEvent_mF8A454D1587D3A01AA7A516185D67C7650D572FC_MetadataUsageId;
extern const uint32_t ByteArrayBuffer_Dispose_mEEBA9EE7B80671DB5228061B31B43ED8F577CDF3_MetadataUsageId;
extern const uint32_t ByteArrayBuffer_Finalize_m330A155A6CCCBB66AE776C1A73E29870250A58FC_MetadataUsageId;
extern const uint32_t ByteArrayBuffer_GetPower_m16CF6A82A1F8D26A5882179C21617A3960CA7F82_MetadataUsageId;
extern const uint32_t ByteArrayBuffer_Get_m1CA04F719970DD2C4E61B152A14D1A8528641CC0_MetadataUsageId;
extern const uint32_t ByteArrayBuffer__cctor_m57B126CF5D1E4BAD8FE7382DD4F86F94A8616C7E_MetadataUsageId;
extern const uint32_t ByteArrayBuffer__ctor_mCE37F5382D4D067550B5BBB53DB62B4C98EE3B09_MetadataUsageId;
extern const uint32_t ByteArrayBuffer_get_Buffer_mEA87A81D37582411E6A368A0E111DF7BF394433F_MetadataUsageId;
extern const uint32_t ByteArrayBuffer_get_ContentLength_m7F0CA8BE74E0EE3AEDE7B8BBF797F8709E1307EF_MetadataUsageId;
extern const uint32_t ConnectionId_Equals_m3319070F68965CAA3729089E1A7700B71527ADB6_MetadataUsageId;
extern const uint32_t ConnectionId__cctor_m7FBEAF5033170D16F7B20CBC1B5465410DD4B651_MetadataUsageId;
extern const uint32_t ConnectionId_op_Inequality_m4D5E6C47FF0450F312BA489473E9FF71D339CBC0_MetadataUsageId;
extern const uint32_t DataMessageEventArgs__ctor_m0696EC373C208888C4E333D1FB9B99D52224A03A_MetadataUsageId;
extern const uint32_t DefaultValues_get_AuthenticateAsClientBugWorkaround_m9760747B06464A0A858D9D415F2B7F62569EA792_MetadataUsageId;
extern const uint32_t ErrorEventArgs_GuessError_m6A6732680478E119C59FA45A2CB9129290265497_MetadataUsageId;
extern const uint32_t ErrorEventArgs__ctor_m8BEABC103A358B03A2FF9F9D546B443FF579F366_MetadataUsageId;
extern const uint32_t ErrorInfo__cctor_m16E68031F48D4019AB86A46DE9F26588B1B72C75_MetadataUsageId;
extern const uint32_t FrameUpdateEventArgs__ctor_mA0D47D896195E97BBE9FEB1BF9EE2CAABC8F53E4_MetadataUsageId;
extern const uint32_t FrameUpdateEventArgs_get_IsRemote_m2754AE629569A1DD3D909BDBE8BD9A620AEC69FA_MetadataUsageId;
extern const uint32_t IceServer_ToString_mD92D1EC60C32C0AF7E7546296C4D10DD59097DBF_MetadataUsageId;
extern const uint32_t IceServer__ctor_m9B4C7129BE2E61E4B73E186A7810035AA0ED8AF7_MetadataUsageId;
extern const uint32_t IceServer_get_Urls_mD3E85B113CB05451E02FD54D7770B2A7E3909B8A_MetadataUsageId;
extern const uint32_t LocalNetwork_CleanupWreakReferences_m1337A34E6D7A17810C73FFB7A2BDDDCDC02C6AD6_MetadataUsageId;
extern const uint32_t LocalNetwork_ConnectClient_m2DA894173389D07ABAEECDA48F14DCBE6DD5D92D_MetadataUsageId;
extern const uint32_t LocalNetwork_Connect_m59F1B0EE1678E54EFC67222D45DFC0F33F05AC57_MetadataUsageId;
extern const uint32_t LocalNetwork_Dequeue_m6338D7028DEF3B984552DD7EC6686C9B794CC8AE_MetadataUsageId;
extern const uint32_t LocalNetwork_Disconnect_m3F8609F3C16315A6962AED155F2EE0E6371477D7_MetadataUsageId;
extern const uint32_t LocalNetwork_Enqueue_m9D20B54FF730F80913DB2B65C28636DA3BCA14E1_MetadataUsageId;
extern const uint32_t LocalNetwork_FindConnectionId_m9A3BD72C12EC7D9809CDB08C37B15B043BB2014D_MetadataUsageId;
extern const uint32_t LocalNetwork_InternalDisconnect_mEF513BD39E3796C3C0744D5AE51EC9F2F8853C72_MetadataUsageId;
extern const uint32_t LocalNetwork_IsAddressInUse_mFBB6B273F779EAB3093BF356EF57475856DE60A4_MetadataUsageId;
extern const uint32_t LocalNetwork_ReceiveData_mB8112F374B300211274D8C38432A155CFEE9D31B_MetadataUsageId;
extern const uint32_t LocalNetwork_SendData_m2A244BFD191B788AD8A96EBE7D285D514BB12F98_MetadataUsageId;
extern const uint32_t LocalNetwork_Shutdown_m0C1D588250811D685CEE21E92FC2B079179AF461_MetadataUsageId;
extern const uint32_t LocalNetwork_StartServer_m6FF3B6576EC1BA7BFD808D8BC358209FFC518420_MetadataUsageId;
extern const uint32_t LocalNetwork_StopServer_m4ED0D3C401EF3C16E1EB7B64672ACDF02A1D7C45_MetadataUsageId;
extern const uint32_t LocalNetwork__cctor_m4D0C07B2709CDC5DAAD363D51554369A8107D377_MetadataUsageId;
extern const uint32_t LocalNetwork__ctor_mEBFB0CF251BEF4406BF3F74DFF4B659EDFE231B5_MetadataUsageId;
extern const uint32_t MediaConfig_DeepClone_m6700A00DAD34DACF1BA7266DD35A793AE6DCAC9F_MetadataUsageId;
extern const uint32_t MediaConfig_ToString_m63DACCF2CFA322BA1BE5597B28E7FD5B5D90CFA9_MetadataUsageId;
extern const uint32_t MediaConfig__ctor_m8DD3603B96D321F06BDC020E2341355B83584967_MetadataUsageId;
extern const uint32_t MediaConfig__ctor_m9F57DF2DA5B07EAEA3FD116B734412547CF95C50_MetadataUsageId;
extern const uint32_t MessageDataBufferExt_AsStringUnicode_m2B5AC83632488AE41F7BA5C2272A089F61B8FCED_MetadataUsageId;
extern const uint32_t MessageDataBufferExt_Copy_mA35B174D17F81FB2AB25399BDD5325CA8326E210_MetadataUsageId;
extern const uint32_t MessageEventArgs__ctor_m3F3C0FE07EDBD02D58DE442EA60D74FBA9FBC1B8_MetadataUsageId;
extern const uint32_t NetworkConfig_ToString_m6C2BDF22F5AFE8B70F6444BB3F20E7167DC2D305_MetadataUsageId;
extern const uint32_t NetworkConfig__ctor_m602D7088B4491C0C9438A2316195FAA7F1C0E5F4_MetadataUsageId;
extern const uint32_t NetworkEvent_FromByteArray_m31466305C7DB5DFC36469055EB90ECD536E165FC_MetadataUsageId;
extern const uint32_t NetworkEvent_ToByteArray_m2C19FC5A5C98D7795FACBFC34CA65C40EDFB6785_MetadataUsageId;
extern const uint32_t NetworkEvent_ToString_m4B700DB0C7D27B2855D19F7ABF80FB5112ED2105_MetadataUsageId;
extern const uint32_t NetworkEvent__ctor_mF53983C4264CD0231654304A49965EC5B9D94C9E_MetadataUsageId;
extern const uint32_t NetworkEvent_get_ErrorInfo_m8AEF4E79F149ACDE34B56754A88ADA709AAD8D95_MetadataUsageId;
extern const uint32_t NetworkEvent_get_Info_mA98458FF9FA0B252D18705DD6B1A3B17D9503E16_MetadataUsageId;
extern const uint32_t NetworkEvent_get_MessageData_m4E9F1B0D89F50E350EF0262187C7DE74ADCEED26_MetadataUsageId;
extern const uint32_t NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_com_FromNativeMethodDefinition_MetadataUsageId;
extern const uint32_t NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_pinvoke_FromNativeMethodDefinition_MetadataUsageId;
extern const uint32_t SLog_LE_m4B26380D8909353763D54ED1E2E1217292226234_MetadataUsageId;
extern const uint32_t SLog_LW_m4C1FD9091E37D07F12DFBDCE665962B60B7F2DE5_MetadataUsageId;
extern const uint32_t SLog_L_m2B84D1BE41D8BA16E73F6E952C5C17D7D2B686A1_MetadataUsageId;
extern const uint32_t SLog_LogArray_mAD74446C19CFC07B879694644E4C675F3F30508E_MetadataUsageId;
extern const uint32_t SLog_LogException_m36D2B19FEACBC5A8799BFC23E8B2DB1A183E88B0_MetadataUsageId;
extern const uint32_t SLog_MergeTags_mFF2513B04A32F652F6FDA529489D942C805803AA_MetadataUsageId;
extern const uint32_t SLog_SetLogger_m5D3E7F714E0AC197E10DB6FCDB06D1209D463F91_MetadataUsageId;
extern const uint32_t SLog__cctor_mC00C1300F50AA43CB5BFCFABC5C6FC5BD20DADC6_MetadataUsageId;
struct Delegate_t_marshaled_com;
struct Delegate_t_marshaled_pinvoke;
struct Exception_t_marshaled_com;
struct Exception_t_marshaled_pinvoke;

struct ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821;
struct List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592;
struct DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86;
struct Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83;
struct StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E;


#ifndef U3CMODULEU3E_T5E9BCCF782B7911AFF113E864B4B636EFE0B6BF0_H
#define U3CMODULEU3E_T5E9BCCF782B7911AFF113E864B4B636EFE0B6BF0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t5E9BCCF782B7911AFF113E864B4B636EFE0B6BF0 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T5E9BCCF782B7911AFF113E864B4B636EFE0B6BF0_H
#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
#ifndef BYTEARRAYBUFFER_T39C5A4320D8C9053876A3C5A596EF95EB40E257B_H
#define BYTEARRAYBUFFER_T39C5A4320D8C9053876A3C5A596EF95EB40E257B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.ByteArrayBuffer
struct  ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B  : public RuntimeObject
{
public:
	// System.Byte[] Byn.Awrtc.ByteArrayBuffer::array
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___array_2;
	// System.Int32 Byn.Awrtc.ByteArrayBuffer::positionWrite
	int32_t ___positionWrite_3;
	// System.Int32 Byn.Awrtc.ByteArrayBuffer::positionRead
	int32_t ___positionRead_4;
	// System.Int32 Byn.Awrtc.ByteArrayBuffer::offset
	int32_t ___offset_5;
	// System.Boolean Byn.Awrtc.ByteArrayBuffer::mFromPool
	bool ___mFromPool_6;
	// System.Boolean Byn.Awrtc.ByteArrayBuffer::mDisposed
	bool ___mDisposed_7;

public:
	inline static int32_t get_offset_of_array_2() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B, ___array_2)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get_array_2() const { return ___array_2; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of_array_2() { return &___array_2; }
	inline void set_array_2(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		___array_2 = value;
		Il2CppCodeGenWriteBarrier((&___array_2), value);
	}

	inline static int32_t get_offset_of_positionWrite_3() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B, ___positionWrite_3)); }
	inline int32_t get_positionWrite_3() const { return ___positionWrite_3; }
	inline int32_t* get_address_of_positionWrite_3() { return &___positionWrite_3; }
	inline void set_positionWrite_3(int32_t value)
	{
		___positionWrite_3 = value;
	}

	inline static int32_t get_offset_of_positionRead_4() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B, ___positionRead_4)); }
	inline int32_t get_positionRead_4() const { return ___positionRead_4; }
	inline int32_t* get_address_of_positionRead_4() { return &___positionRead_4; }
	inline void set_positionRead_4(int32_t value)
	{
		___positionRead_4 = value;
	}

	inline static int32_t get_offset_of_offset_5() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B, ___offset_5)); }
	inline int32_t get_offset_5() const { return ___offset_5; }
	inline int32_t* get_address_of_offset_5() { return &___offset_5; }
	inline void set_offset_5(int32_t value)
	{
		___offset_5 = value;
	}

	inline static int32_t get_offset_of_mFromPool_6() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B, ___mFromPool_6)); }
	inline bool get_mFromPool_6() const { return ___mFromPool_6; }
	inline bool* get_address_of_mFromPool_6() { return &___mFromPool_6; }
	inline void set_mFromPool_6(bool value)
	{
		___mFromPool_6 = value;
	}

	inline static int32_t get_offset_of_mDisposed_7() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B, ___mDisposed_7)); }
	inline bool get_mDisposed_7() const { return ___mDisposed_7; }
	inline bool* get_address_of_mDisposed_7() { return &___mDisposed_7; }
	inline void set_mDisposed_7(bool value)
	{
		___mDisposed_7 = value;
	}
};

struct ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields
{
public:
	// System.Collections.Generic.List`1<Byn.Awrtc.ByteArrayBuffer>[] Byn.Awrtc.ByteArrayBuffer::sPool
	List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* ___sPool_0;
	// System.Boolean Byn.Awrtc.ByteArrayBuffer::LOG_GC_CALLS
	bool ___LOG_GC_CALLS_1;
	// System.Int32[] Byn.Awrtc.ByteArrayBuffer::MultiplyDeBruijnBitPosition
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___MultiplyDeBruijnBitPosition_8;

public:
	inline static int32_t get_offset_of_sPool_0() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields, ___sPool_0)); }
	inline List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* get_sPool_0() const { return ___sPool_0; }
	inline List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592** get_address_of_sPool_0() { return &___sPool_0; }
	inline void set_sPool_0(List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* value)
	{
		___sPool_0 = value;
		Il2CppCodeGenWriteBarrier((&___sPool_0), value);
	}

	inline static int32_t get_offset_of_LOG_GC_CALLS_1() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields, ___LOG_GC_CALLS_1)); }
	inline bool get_LOG_GC_CALLS_1() const { return ___LOG_GC_CALLS_1; }
	inline bool* get_address_of_LOG_GC_CALLS_1() { return &___LOG_GC_CALLS_1; }
	inline void set_LOG_GC_CALLS_1(bool value)
	{
		___LOG_GC_CALLS_1 = value;
	}

	inline static int32_t get_offset_of_MultiplyDeBruijnBitPosition_8() { return static_cast<int32_t>(offsetof(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields, ___MultiplyDeBruijnBitPosition_8)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_MultiplyDeBruijnBitPosition_8() const { return ___MultiplyDeBruijnBitPosition_8; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_MultiplyDeBruijnBitPosition_8() { return &___MultiplyDeBruijnBitPosition_8; }
	inline void set_MultiplyDeBruijnBitPosition_8(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___MultiplyDeBruijnBitPosition_8 = value;
		Il2CppCodeGenWriteBarrier((&___MultiplyDeBruijnBitPosition_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BYTEARRAYBUFFER_T39C5A4320D8C9053876A3C5A596EF95EB40E257B_H
#ifndef DEFAULTVALUES_TFB168B56BA06FD7096D0B3A6454AD6873A4104CA_H
#define DEFAULTVALUES_TFB168B56BA06FD7096D0B3A6454AD6873A4104CA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.DefaultValues
struct  DefaultValues_tFB168B56BA06FD7096D0B3A6454AD6873A4104CA  : public RuntimeObject
{
public:

public:
};

struct DefaultValues_tFB168B56BA06FD7096D0B3A6454AD6873A4104CA_StaticFields
{
public:
	// System.Boolean Byn.Awrtc.DefaultValues::sAuthenticateAsClientBugWorkaround
	bool ___sAuthenticateAsClientBugWorkaround_0;

public:
	inline static int32_t get_offset_of_sAuthenticateAsClientBugWorkaround_0() { return static_cast<int32_t>(offsetof(DefaultValues_tFB168B56BA06FD7096D0B3A6454AD6873A4104CA_StaticFields, ___sAuthenticateAsClientBugWorkaround_0)); }
	inline bool get_sAuthenticateAsClientBugWorkaround_0() const { return ___sAuthenticateAsClientBugWorkaround_0; }
	inline bool* get_address_of_sAuthenticateAsClientBugWorkaround_0() { return &___sAuthenticateAsClientBugWorkaround_0; }
	inline void set_sAuthenticateAsClientBugWorkaround_0(bool value)
	{
		___sAuthenticateAsClientBugWorkaround_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEFAULTVALUES_TFB168B56BA06FD7096D0B3A6454AD6873A4104CA_H
#ifndef ERRORINFO_T7BF4629517FDF63B912A4B6AE78C4B2BD9207167_H
#define ERRORINFO_T7BF4629517FDF63B912A4B6AE78C4B2BD9207167_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.ErrorInfo
struct  ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167  : public RuntimeObject
{
public:
	// System.String Byn.Awrtc.ErrorInfo::mErrorMessage
	String_t* ___mErrorMessage_10;

public:
	inline static int32_t get_offset_of_mErrorMessage_10() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167, ___mErrorMessage_10)); }
	inline String_t* get_mErrorMessage_10() const { return ___mErrorMessage_10; }
	inline String_t** get_address_of_mErrorMessage_10() { return &___mErrorMessage_10; }
	inline void set_mErrorMessage_10(String_t* value)
	{
		___mErrorMessage_10 = value;
		Il2CppCodeGenWriteBarrier((&___mErrorMessage_10), value);
	}
};

struct ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields
{
public:
	// System.String Byn.Awrtc.ErrorInfo::SERVER_INIT_FAILED_ADDRESS_IN_USE
	String_t* ___SERVER_INIT_FAILED_ADDRESS_IN_USE_0;
	// System.String Byn.Awrtc.ErrorInfo::CONNECTION_FAILED_ADDRESS_UNKNOWN
	String_t* ___CONNECTION_FAILED_ADDRESS_UNKNOWN_1;
	// System.String Byn.Awrtc.ErrorInfo::SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE
	String_t* ___SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2;
	// System.String Byn.Awrtc.ErrorInfo::CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE
	String_t* ___CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3;
	// System.String Byn.Awrtc.ErrorInfo::DISCONNECTED_REQURED_CONNECTION_OFFLINE
	String_t* ___DISCONNECTED_REQURED_CONNECTION_OFFLINE_4;
	// System.String Byn.Awrtc.ErrorInfo::SERVER_CLOSED_REQURED_CONNECTION_OFFLINE
	String_t* ___SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5;
	// System.String Byn.Awrtc.ErrorInfo::CONNECTION_FAILED_TO_CONNECT_DIRECTLY
	String_t* ___CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6;
	// System.String Byn.Awrtc.ErrorInfo::INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY
	String_t* ___INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7;
	// System.String Byn.Awrtc.ErrorInfo::DISCONNECTED_DUE_TO_TIMEOUT
	String_t* ___DISCONNECTED_DUE_TO_TIMEOUT_8;
	// System.String Byn.Awrtc.ErrorInfo::CONFIGURATION_FAILED
	String_t* ___CONFIGURATION_FAILED_9;

public:
	inline static int32_t get_offset_of_SERVER_INIT_FAILED_ADDRESS_IN_USE_0() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___SERVER_INIT_FAILED_ADDRESS_IN_USE_0)); }
	inline String_t* get_SERVER_INIT_FAILED_ADDRESS_IN_USE_0() const { return ___SERVER_INIT_FAILED_ADDRESS_IN_USE_0; }
	inline String_t** get_address_of_SERVER_INIT_FAILED_ADDRESS_IN_USE_0() { return &___SERVER_INIT_FAILED_ADDRESS_IN_USE_0; }
	inline void set_SERVER_INIT_FAILED_ADDRESS_IN_USE_0(String_t* value)
	{
		___SERVER_INIT_FAILED_ADDRESS_IN_USE_0 = value;
		Il2CppCodeGenWriteBarrier((&___SERVER_INIT_FAILED_ADDRESS_IN_USE_0), value);
	}

	inline static int32_t get_offset_of_CONNECTION_FAILED_ADDRESS_UNKNOWN_1() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___CONNECTION_FAILED_ADDRESS_UNKNOWN_1)); }
	inline String_t* get_CONNECTION_FAILED_ADDRESS_UNKNOWN_1() const { return ___CONNECTION_FAILED_ADDRESS_UNKNOWN_1; }
	inline String_t** get_address_of_CONNECTION_FAILED_ADDRESS_UNKNOWN_1() { return &___CONNECTION_FAILED_ADDRESS_UNKNOWN_1; }
	inline void set_CONNECTION_FAILED_ADDRESS_UNKNOWN_1(String_t* value)
	{
		___CONNECTION_FAILED_ADDRESS_UNKNOWN_1 = value;
		Il2CppCodeGenWriteBarrier((&___CONNECTION_FAILED_ADDRESS_UNKNOWN_1), value);
	}

	inline static int32_t get_offset_of_SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2)); }
	inline String_t* get_SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2() const { return ___SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2; }
	inline String_t** get_address_of_SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2() { return &___SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2; }
	inline void set_SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2(String_t* value)
	{
		___SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2 = value;
		Il2CppCodeGenWriteBarrier((&___SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2), value);
	}

	inline static int32_t get_offset_of_CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3)); }
	inline String_t* get_CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3() const { return ___CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3; }
	inline String_t** get_address_of_CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3() { return &___CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3; }
	inline void set_CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3(String_t* value)
	{
		___CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3 = value;
		Il2CppCodeGenWriteBarrier((&___CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3), value);
	}

	inline static int32_t get_offset_of_DISCONNECTED_REQURED_CONNECTION_OFFLINE_4() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___DISCONNECTED_REQURED_CONNECTION_OFFLINE_4)); }
	inline String_t* get_DISCONNECTED_REQURED_CONNECTION_OFFLINE_4() const { return ___DISCONNECTED_REQURED_CONNECTION_OFFLINE_4; }
	inline String_t** get_address_of_DISCONNECTED_REQURED_CONNECTION_OFFLINE_4() { return &___DISCONNECTED_REQURED_CONNECTION_OFFLINE_4; }
	inline void set_DISCONNECTED_REQURED_CONNECTION_OFFLINE_4(String_t* value)
	{
		___DISCONNECTED_REQURED_CONNECTION_OFFLINE_4 = value;
		Il2CppCodeGenWriteBarrier((&___DISCONNECTED_REQURED_CONNECTION_OFFLINE_4), value);
	}

	inline static int32_t get_offset_of_SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5)); }
	inline String_t* get_SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5() const { return ___SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5; }
	inline String_t** get_address_of_SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5() { return &___SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5; }
	inline void set_SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5(String_t* value)
	{
		___SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5 = value;
		Il2CppCodeGenWriteBarrier((&___SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5), value);
	}

	inline static int32_t get_offset_of_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6)); }
	inline String_t* get_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6() const { return ___CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6; }
	inline String_t** get_address_of_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6() { return &___CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6; }
	inline void set_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6(String_t* value)
	{
		___CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6 = value;
		Il2CppCodeGenWriteBarrier((&___CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6), value);
	}

	inline static int32_t get_offset_of_INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7)); }
	inline String_t* get_INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7() const { return ___INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7; }
	inline String_t** get_address_of_INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7() { return &___INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7; }
	inline void set_INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7(String_t* value)
	{
		___INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7 = value;
		Il2CppCodeGenWriteBarrier((&___INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7), value);
	}

	inline static int32_t get_offset_of_DISCONNECTED_DUE_TO_TIMEOUT_8() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___DISCONNECTED_DUE_TO_TIMEOUT_8)); }
	inline String_t* get_DISCONNECTED_DUE_TO_TIMEOUT_8() const { return ___DISCONNECTED_DUE_TO_TIMEOUT_8; }
	inline String_t** get_address_of_DISCONNECTED_DUE_TO_TIMEOUT_8() { return &___DISCONNECTED_DUE_TO_TIMEOUT_8; }
	inline void set_DISCONNECTED_DUE_TO_TIMEOUT_8(String_t* value)
	{
		___DISCONNECTED_DUE_TO_TIMEOUT_8 = value;
		Il2CppCodeGenWriteBarrier((&___DISCONNECTED_DUE_TO_TIMEOUT_8), value);
	}

	inline static int32_t get_offset_of_CONFIGURATION_FAILED_9() { return static_cast<int32_t>(offsetof(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields, ___CONFIGURATION_FAILED_9)); }
	inline String_t* get_CONFIGURATION_FAILED_9() const { return ___CONFIGURATION_FAILED_9; }
	inline String_t** get_address_of_CONFIGURATION_FAILED_9() { return &___CONFIGURATION_FAILED_9; }
	inline void set_CONFIGURATION_FAILED_9(String_t* value)
	{
		___CONFIGURATION_FAILED_9 = value;
		Il2CppCodeGenWriteBarrier((&___CONFIGURATION_FAILED_9), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ERRORINFO_T7BF4629517FDF63B912A4B6AE78C4B2BD9207167_H
#ifndef ICESERVER_T423A5044DD3B2346555973AF68F71585262E07FA_H
#define ICESERVER_T423A5044DD3B2346555973AF68F71585262E07FA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.IceServer
struct  IceServer_t423A5044DD3B2346555973AF68F71585262E07FA  : public RuntimeObject
{
public:
	// System.Collections.Generic.List`1<System.String> Byn.Awrtc.IceServer::mUrls
	List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * ___mUrls_0;
	// System.String Byn.Awrtc.IceServer::mUsername
	String_t* ___mUsername_1;
	// System.String Byn.Awrtc.IceServer::mCredential
	String_t* ___mCredential_2;

public:
	inline static int32_t get_offset_of_mUrls_0() { return static_cast<int32_t>(offsetof(IceServer_t423A5044DD3B2346555973AF68F71585262E07FA, ___mUrls_0)); }
	inline List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * get_mUrls_0() const { return ___mUrls_0; }
	inline List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 ** get_address_of_mUrls_0() { return &___mUrls_0; }
	inline void set_mUrls_0(List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * value)
	{
		___mUrls_0 = value;
		Il2CppCodeGenWriteBarrier((&___mUrls_0), value);
	}

	inline static int32_t get_offset_of_mUsername_1() { return static_cast<int32_t>(offsetof(IceServer_t423A5044DD3B2346555973AF68F71585262E07FA, ___mUsername_1)); }
	inline String_t* get_mUsername_1() const { return ___mUsername_1; }
	inline String_t** get_address_of_mUsername_1() { return &___mUsername_1; }
	inline void set_mUsername_1(String_t* value)
	{
		___mUsername_1 = value;
		Il2CppCodeGenWriteBarrier((&___mUsername_1), value);
	}

	inline static int32_t get_offset_of_mCredential_2() { return static_cast<int32_t>(offsetof(IceServer_t423A5044DD3B2346555973AF68F71585262E07FA, ___mCredential_2)); }
	inline String_t* get_mCredential_2() const { return ___mCredential_2; }
	inline String_t** get_address_of_mCredential_2() { return &___mCredential_2; }
	inline void set_mCredential_2(String_t* value)
	{
		___mCredential_2 = value;
		Il2CppCodeGenWriteBarrier((&___mCredential_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ICESERVER_T423A5044DD3B2346555973AF68F71585262E07FA_H
#ifndef WEAKREF_1_T52AD80447FEB9076E42A22CED25E3B181B1177F4_H
#define WEAKREF_1_T52AD80447FEB9076E42A22CED25E3B181B1177F4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.LocalNetwork_WeakRef`1<Byn.Awrtc.LocalNetwork>
struct  WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4  : public RuntimeObject
{
public:
	// System.WeakReference Byn.Awrtc.LocalNetwork_WeakRef`1::mRef
	WeakReference_t0495CC81CD6403E662B7700B802443F6F730E39D * ___mRef_0;

public:
	inline static int32_t get_offset_of_mRef_0() { return static_cast<int32_t>(offsetof(WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4, ___mRef_0)); }
	inline WeakReference_t0495CC81CD6403E662B7700B802443F6F730E39D * get_mRef_0() const { return ___mRef_0; }
	inline WeakReference_t0495CC81CD6403E662B7700B802443F6F730E39D ** get_address_of_mRef_0() { return &___mRef_0; }
	inline void set_mRef_0(WeakReference_t0495CC81CD6403E662B7700B802443F6F730E39D * value)
	{
		___mRef_0 = value;
		Il2CppCodeGenWriteBarrier((&___mRef_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WEAKREF_1_T52AD80447FEB9076E42A22CED25E3B181B1177F4_H
#ifndef MESSAGEDATABUFFEREXT_T97D4A96C74CBA57E4A36C43BC6C79FBDDFA9DA4F_H
#define MESSAGEDATABUFFEREXT_T97D4A96C74CBA57E4A36C43BC6C79FBDDFA9DA4F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.MessageDataBufferExt
struct  MessageDataBufferExt_t97D4A96C74CBA57E4A36C43BC6C79FBDDFA9DA4F  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MESSAGEDATABUFFEREXT_T97D4A96C74CBA57E4A36C43BC6C79FBDDFA9DA4F_H
#ifndef NETWORKCONFIG_T91786901660F3E2FB39AA6F01F3F9295D0751A47_H
#define NETWORKCONFIG_T91786901660F3E2FB39AA6F01F3F9295D0751A47_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.NetworkConfig
struct  NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47  : public RuntimeObject
{
public:
	// System.Collections.Generic.List`1<Byn.Awrtc.IceServer> Byn.Awrtc.NetworkConfig::mIceServers
	List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 * ___mIceServers_0;
	// System.String Byn.Awrtc.NetworkConfig::mSignalingUrl
	String_t* ___mSignalingUrl_1;
	// System.Boolean Byn.Awrtc.NetworkConfig::mAllowRenegotiation
	bool ___mAllowRenegotiation_2;
	// System.Boolean Byn.Awrtc.NetworkConfig::mIsConference
	bool ___mIsConference_3;

public:
	inline static int32_t get_offset_of_mIceServers_0() { return static_cast<int32_t>(offsetof(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47, ___mIceServers_0)); }
	inline List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 * get_mIceServers_0() const { return ___mIceServers_0; }
	inline List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 ** get_address_of_mIceServers_0() { return &___mIceServers_0; }
	inline void set_mIceServers_0(List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 * value)
	{
		___mIceServers_0 = value;
		Il2CppCodeGenWriteBarrier((&___mIceServers_0), value);
	}

	inline static int32_t get_offset_of_mSignalingUrl_1() { return static_cast<int32_t>(offsetof(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47, ___mSignalingUrl_1)); }
	inline String_t* get_mSignalingUrl_1() const { return ___mSignalingUrl_1; }
	inline String_t** get_address_of_mSignalingUrl_1() { return &___mSignalingUrl_1; }
	inline void set_mSignalingUrl_1(String_t* value)
	{
		___mSignalingUrl_1 = value;
		Il2CppCodeGenWriteBarrier((&___mSignalingUrl_1), value);
	}

	inline static int32_t get_offset_of_mAllowRenegotiation_2() { return static_cast<int32_t>(offsetof(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47, ___mAllowRenegotiation_2)); }
	inline bool get_mAllowRenegotiation_2() const { return ___mAllowRenegotiation_2; }
	inline bool* get_address_of_mAllowRenegotiation_2() { return &___mAllowRenegotiation_2; }
	inline void set_mAllowRenegotiation_2(bool value)
	{
		___mAllowRenegotiation_2 = value;
	}

	inline static int32_t get_offset_of_mIsConference_3() { return static_cast<int32_t>(offsetof(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47, ___mIsConference_3)); }
	inline bool get_mIsConference_3() const { return ___mIsConference_3; }
	inline bool* get_address_of_mIsConference_3() { return &___mIsConference_3; }
	inline void set_mIsConference_3(bool value)
	{
		___mIsConference_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NETWORKCONFIG_T91786901660F3E2FB39AA6F01F3F9295D0751A47_H
#ifndef SLOG_T859DA99D2A0A51C719F956D188DCA86775781CE0_H
#define SLOG_T859DA99D2A0A51C719F956D188DCA86775781CE0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.SLog
struct  SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0  : public RuntimeObject
{
public:

public:
};

struct SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields
{
public:
	// System.String Byn.Awrtc.SLog::TAG_WARNING
	String_t* ___TAG_WARNING_0;
	// System.String Byn.Awrtc.SLog::TAG_ERROR
	String_t* ___TAG_ERROR_1;
	// System.String Byn.Awrtc.SLog::TAG_EXCEPTION
	String_t* ___TAG_EXCEPTION_2;
	// System.String Byn.Awrtc.SLog::TAG_INFO
	String_t* ___TAG_INFO_3;
	// System.String Byn.Awrtc.SLog::TAG_DEBUG
	String_t* ___TAG_DEBUG_4;
	// System.String Byn.Awrtc.SLog::TAG_VERBOSE
	String_t* ___TAG_VERBOSE_5;
	// System.Action`2<System.Object,System.String[]> Byn.Awrtc.SLog::sLogger
	Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 * ___sLogger_6;

public:
	inline static int32_t get_offset_of_TAG_WARNING_0() { return static_cast<int32_t>(offsetof(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields, ___TAG_WARNING_0)); }
	inline String_t* get_TAG_WARNING_0() const { return ___TAG_WARNING_0; }
	inline String_t** get_address_of_TAG_WARNING_0() { return &___TAG_WARNING_0; }
	inline void set_TAG_WARNING_0(String_t* value)
	{
		___TAG_WARNING_0 = value;
		Il2CppCodeGenWriteBarrier((&___TAG_WARNING_0), value);
	}

	inline static int32_t get_offset_of_TAG_ERROR_1() { return static_cast<int32_t>(offsetof(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields, ___TAG_ERROR_1)); }
	inline String_t* get_TAG_ERROR_1() const { return ___TAG_ERROR_1; }
	inline String_t** get_address_of_TAG_ERROR_1() { return &___TAG_ERROR_1; }
	inline void set_TAG_ERROR_1(String_t* value)
	{
		___TAG_ERROR_1 = value;
		Il2CppCodeGenWriteBarrier((&___TAG_ERROR_1), value);
	}

	inline static int32_t get_offset_of_TAG_EXCEPTION_2() { return static_cast<int32_t>(offsetof(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields, ___TAG_EXCEPTION_2)); }
	inline String_t* get_TAG_EXCEPTION_2() const { return ___TAG_EXCEPTION_2; }
	inline String_t** get_address_of_TAG_EXCEPTION_2() { return &___TAG_EXCEPTION_2; }
	inline void set_TAG_EXCEPTION_2(String_t* value)
	{
		___TAG_EXCEPTION_2 = value;
		Il2CppCodeGenWriteBarrier((&___TAG_EXCEPTION_2), value);
	}

	inline static int32_t get_offset_of_TAG_INFO_3() { return static_cast<int32_t>(offsetof(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields, ___TAG_INFO_3)); }
	inline String_t* get_TAG_INFO_3() const { return ___TAG_INFO_3; }
	inline String_t** get_address_of_TAG_INFO_3() { return &___TAG_INFO_3; }
	inline void set_TAG_INFO_3(String_t* value)
	{
		___TAG_INFO_3 = value;
		Il2CppCodeGenWriteBarrier((&___TAG_INFO_3), value);
	}

	inline static int32_t get_offset_of_TAG_DEBUG_4() { return static_cast<int32_t>(offsetof(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields, ___TAG_DEBUG_4)); }
	inline String_t* get_TAG_DEBUG_4() const { return ___TAG_DEBUG_4; }
	inline String_t** get_address_of_TAG_DEBUG_4() { return &___TAG_DEBUG_4; }
	inline void set_TAG_DEBUG_4(String_t* value)
	{
		___TAG_DEBUG_4 = value;
		Il2CppCodeGenWriteBarrier((&___TAG_DEBUG_4), value);
	}

	inline static int32_t get_offset_of_TAG_VERBOSE_5() { return static_cast<int32_t>(offsetof(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields, ___TAG_VERBOSE_5)); }
	inline String_t* get_TAG_VERBOSE_5() const { return ___TAG_VERBOSE_5; }
	inline String_t** get_address_of_TAG_VERBOSE_5() { return &___TAG_VERBOSE_5; }
	inline void set_TAG_VERBOSE_5(String_t* value)
	{
		___TAG_VERBOSE_5 = value;
		Il2CppCodeGenWriteBarrier((&___TAG_VERBOSE_5), value);
	}

	inline static int32_t get_offset_of_sLogger_6() { return static_cast<int32_t>(offsetof(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields, ___sLogger_6)); }
	inline Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 * get_sLogger_6() const { return ___sLogger_6; }
	inline Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 ** get_address_of_sLogger_6() { return &___sLogger_6; }
	inline void set_sLogger_6(Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 * value)
	{
		___sLogger_6 = value;
		Il2CppCodeGenWriteBarrier((&___sLogger_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SLOG_T859DA99D2A0A51C719F956D188DCA86775781CE0_H
struct Il2CppArrayBounds;
#ifndef RUNTIMEARRAY_H
#define RUNTIMEARRAY_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Array

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEARRAY_H
#ifndef KEYCOLLECTION_T22184C5C648B98E1130AB2CB15D732A497552019_H
#define KEYCOLLECTION_T22184C5C648B98E1130AB2CB15D732A497552019_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2_KeyCollection<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork_WeakRef`1<Byn.Awrtc.LocalNetwork>>
struct  KeyCollection_t22184C5C648B98E1130AB2CB15D732A497552019  : public RuntimeObject
{
public:
	// System.Collections.Generic.Dictionary`2<TKey,TValue> System.Collections.Generic.Dictionary`2_KeyCollection::dictionary
	Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * ___dictionary_0;

public:
	inline static int32_t get_offset_of_dictionary_0() { return static_cast<int32_t>(offsetof(KeyCollection_t22184C5C648B98E1130AB2CB15D732A497552019, ___dictionary_0)); }
	inline Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * get_dictionary_0() const { return ___dictionary_0; }
	inline Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB ** get_address_of_dictionary_0() { return &___dictionary_0; }
	inline void set_dictionary_0(Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * value)
	{
		___dictionary_0 = value;
		Il2CppCodeGenWriteBarrier((&___dictionary_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // KEYCOLLECTION_T22184C5C648B98E1130AB2CB15D732A497552019_H
#ifndef DICTIONARY_2_T4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB_H
#define DICTIONARY_2_T4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork_WeakRef`1<Byn.Awrtc.LocalNetwork>>
struct  Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB  : public RuntimeObject
{
public:
	// System.Int32[] System.Collections.Generic.Dictionary`2::buckets
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___buckets_0;
	// System.Collections.Generic.Dictionary`2_Entry<TKey,TValue>[] System.Collections.Generic.Dictionary`2::entries
	EntryU5BU5D_tA4B673A05D77A5FCA37E40F6370339CAA5C4F365* ___entries_1;
	// System.Int32 System.Collections.Generic.Dictionary`2::count
	int32_t ___count_2;
	// System.Int32 System.Collections.Generic.Dictionary`2::version
	int32_t ___version_3;
	// System.Int32 System.Collections.Generic.Dictionary`2::freeList
	int32_t ___freeList_4;
	// System.Int32 System.Collections.Generic.Dictionary`2::freeCount
	int32_t ___freeCount_5;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::comparer
	RuntimeObject* ___comparer_6;
	// System.Collections.Generic.Dictionary`2_KeyCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::keys
	KeyCollection_t22184C5C648B98E1130AB2CB15D732A497552019 * ___keys_7;
	// System.Collections.Generic.Dictionary`2_ValueCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::values
	ValueCollection_t85AAC7C15DB90E887637FDBA486CB308EFD4F22A * ___values_8;
	// System.Object System.Collections.Generic.Dictionary`2::_syncRoot
	RuntimeObject * ____syncRoot_9;

public:
	inline static int32_t get_offset_of_buckets_0() { return static_cast<int32_t>(offsetof(Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB, ___buckets_0)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_buckets_0() const { return ___buckets_0; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_buckets_0() { return &___buckets_0; }
	inline void set_buckets_0(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___buckets_0 = value;
		Il2CppCodeGenWriteBarrier((&___buckets_0), value);
	}

	inline static int32_t get_offset_of_entries_1() { return static_cast<int32_t>(offsetof(Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB, ___entries_1)); }
	inline EntryU5BU5D_tA4B673A05D77A5FCA37E40F6370339CAA5C4F365* get_entries_1() const { return ___entries_1; }
	inline EntryU5BU5D_tA4B673A05D77A5FCA37E40F6370339CAA5C4F365** get_address_of_entries_1() { return &___entries_1; }
	inline void set_entries_1(EntryU5BU5D_tA4B673A05D77A5FCA37E40F6370339CAA5C4F365* value)
	{
		___entries_1 = value;
		Il2CppCodeGenWriteBarrier((&___entries_1), value);
	}

	inline static int32_t get_offset_of_count_2() { return static_cast<int32_t>(offsetof(Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB, ___count_2)); }
	inline int32_t get_count_2() const { return ___count_2; }
	inline int32_t* get_address_of_count_2() { return &___count_2; }
	inline void set_count_2(int32_t value)
	{
		___count_2 = value;
	}

	inline static int32_t get_offset_of_version_3() { return static_cast<int32_t>(offsetof(Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB, ___version_3)); }
	inline int32_t get_version_3() const { return ___version_3; }
	inline int32_t* get_address_of_version_3() { return &___version_3; }
	inline void set_version_3(int32_t value)
	{
		___version_3 = value;
	}

	inline static int32_t get_offset_of_freeList_4() { return static_cast<int32_t>(offsetof(Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB, ___freeList_4)); }
	inline int32_t get_freeList_4() const { return ___freeList_4; }
	inline int32_t* get_address_of_freeList_4() { return &___freeList_4; }
	inline void set_freeList_4(int32_t value)
	{
		___freeList_4 = value;
	}

	inline static int32_t get_offset_of_freeCount_5() { return static_cast<int32_t>(offsetof(Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB, ___freeCount_5)); }
	inline int32_t get_freeCount_5() const { return ___freeCount_5; }
	inline int32_t* get_address_of_freeCount_5() { return &___freeCount_5; }
	inline void set_freeCount_5(int32_t value)
	{
		___freeCount_5 = value;
	}

	inline static int32_t get_offset_of_comparer_6() { return static_cast<int32_t>(offsetof(Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB, ___comparer_6)); }
	inline RuntimeObject* get_comparer_6() const { return ___comparer_6; }
	inline RuntimeObject** get_address_of_comparer_6() { return &___comparer_6; }
	inline void set_comparer_6(RuntimeObject* value)
	{
		___comparer_6 = value;
		Il2CppCodeGenWriteBarrier((&___comparer_6), value);
	}

	inline static int32_t get_offset_of_keys_7() { return static_cast<int32_t>(offsetof(Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB, ___keys_7)); }
	inline KeyCollection_t22184C5C648B98E1130AB2CB15D732A497552019 * get_keys_7() const { return ___keys_7; }
	inline KeyCollection_t22184C5C648B98E1130AB2CB15D732A497552019 ** get_address_of_keys_7() { return &___keys_7; }
	inline void set_keys_7(KeyCollection_t22184C5C648B98E1130AB2CB15D732A497552019 * value)
	{
		___keys_7 = value;
		Il2CppCodeGenWriteBarrier((&___keys_7), value);
	}

	inline static int32_t get_offset_of_values_8() { return static_cast<int32_t>(offsetof(Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB, ___values_8)); }
	inline ValueCollection_t85AAC7C15DB90E887637FDBA486CB308EFD4F22A * get_values_8() const { return ___values_8; }
	inline ValueCollection_t85AAC7C15DB90E887637FDBA486CB308EFD4F22A ** get_address_of_values_8() { return &___values_8; }
	inline void set_values_8(ValueCollection_t85AAC7C15DB90E887637FDBA486CB308EFD4F22A * value)
	{
		___values_8 = value;
		Il2CppCodeGenWriteBarrier((&___values_8), value);
	}

	inline static int32_t get_offset_of__syncRoot_9() { return static_cast<int32_t>(offsetof(Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB, ____syncRoot_9)); }
	inline RuntimeObject * get__syncRoot_9() const { return ____syncRoot_9; }
	inline RuntimeObject ** get_address_of__syncRoot_9() { return &____syncRoot_9; }
	inline void set__syncRoot_9(RuntimeObject * value)
	{
		____syncRoot_9 = value;
		Il2CppCodeGenWriteBarrier((&____syncRoot_9), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DICTIONARY_2_T4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB_H
#ifndef DICTIONARY_2_T3D83C47A25C154C47BE0619594AB0435F23CA7C2_H
#define DICTIONARY_2_T3D83C47A25C154C47BE0619594AB0435F23CA7C2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2<System.String,Byn.Awrtc.LocalNetwork_WeakRef`1<Byn.Awrtc.LocalNetwork>>
struct  Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2  : public RuntimeObject
{
public:
	// System.Int32[] System.Collections.Generic.Dictionary`2::buckets
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___buckets_0;
	// System.Collections.Generic.Dictionary`2_Entry<TKey,TValue>[] System.Collections.Generic.Dictionary`2::entries
	EntryU5BU5D_t2ACD1753663539A43B6379B927005ADFCC7515E4* ___entries_1;
	// System.Int32 System.Collections.Generic.Dictionary`2::count
	int32_t ___count_2;
	// System.Int32 System.Collections.Generic.Dictionary`2::version
	int32_t ___version_3;
	// System.Int32 System.Collections.Generic.Dictionary`2::freeList
	int32_t ___freeList_4;
	// System.Int32 System.Collections.Generic.Dictionary`2::freeCount
	int32_t ___freeCount_5;
	// System.Collections.Generic.IEqualityComparer`1<TKey> System.Collections.Generic.Dictionary`2::comparer
	RuntimeObject* ___comparer_6;
	// System.Collections.Generic.Dictionary`2_KeyCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::keys
	KeyCollection_tBF5A3A379C2FAEE27B40772C452E5AE4593478D8 * ___keys_7;
	// System.Collections.Generic.Dictionary`2_ValueCollection<TKey,TValue> System.Collections.Generic.Dictionary`2::values
	ValueCollection_t271CAD233177D02D832E2497CF966741D6EDCE05 * ___values_8;
	// System.Object System.Collections.Generic.Dictionary`2::_syncRoot
	RuntimeObject * ____syncRoot_9;

public:
	inline static int32_t get_offset_of_buckets_0() { return static_cast<int32_t>(offsetof(Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2, ___buckets_0)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_buckets_0() const { return ___buckets_0; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_buckets_0() { return &___buckets_0; }
	inline void set_buckets_0(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___buckets_0 = value;
		Il2CppCodeGenWriteBarrier((&___buckets_0), value);
	}

	inline static int32_t get_offset_of_entries_1() { return static_cast<int32_t>(offsetof(Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2, ___entries_1)); }
	inline EntryU5BU5D_t2ACD1753663539A43B6379B927005ADFCC7515E4* get_entries_1() const { return ___entries_1; }
	inline EntryU5BU5D_t2ACD1753663539A43B6379B927005ADFCC7515E4** get_address_of_entries_1() { return &___entries_1; }
	inline void set_entries_1(EntryU5BU5D_t2ACD1753663539A43B6379B927005ADFCC7515E4* value)
	{
		___entries_1 = value;
		Il2CppCodeGenWriteBarrier((&___entries_1), value);
	}

	inline static int32_t get_offset_of_count_2() { return static_cast<int32_t>(offsetof(Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2, ___count_2)); }
	inline int32_t get_count_2() const { return ___count_2; }
	inline int32_t* get_address_of_count_2() { return &___count_2; }
	inline void set_count_2(int32_t value)
	{
		___count_2 = value;
	}

	inline static int32_t get_offset_of_version_3() { return static_cast<int32_t>(offsetof(Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2, ___version_3)); }
	inline int32_t get_version_3() const { return ___version_3; }
	inline int32_t* get_address_of_version_3() { return &___version_3; }
	inline void set_version_3(int32_t value)
	{
		___version_3 = value;
	}

	inline static int32_t get_offset_of_freeList_4() { return static_cast<int32_t>(offsetof(Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2, ___freeList_4)); }
	inline int32_t get_freeList_4() const { return ___freeList_4; }
	inline int32_t* get_address_of_freeList_4() { return &___freeList_4; }
	inline void set_freeList_4(int32_t value)
	{
		___freeList_4 = value;
	}

	inline static int32_t get_offset_of_freeCount_5() { return static_cast<int32_t>(offsetof(Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2, ___freeCount_5)); }
	inline int32_t get_freeCount_5() const { return ___freeCount_5; }
	inline int32_t* get_address_of_freeCount_5() { return &___freeCount_5; }
	inline void set_freeCount_5(int32_t value)
	{
		___freeCount_5 = value;
	}

	inline static int32_t get_offset_of_comparer_6() { return static_cast<int32_t>(offsetof(Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2, ___comparer_6)); }
	inline RuntimeObject* get_comparer_6() const { return ___comparer_6; }
	inline RuntimeObject** get_address_of_comparer_6() { return &___comparer_6; }
	inline void set_comparer_6(RuntimeObject* value)
	{
		___comparer_6 = value;
		Il2CppCodeGenWriteBarrier((&___comparer_6), value);
	}

	inline static int32_t get_offset_of_keys_7() { return static_cast<int32_t>(offsetof(Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2, ___keys_7)); }
	inline KeyCollection_tBF5A3A379C2FAEE27B40772C452E5AE4593478D8 * get_keys_7() const { return ___keys_7; }
	inline KeyCollection_tBF5A3A379C2FAEE27B40772C452E5AE4593478D8 ** get_address_of_keys_7() { return &___keys_7; }
	inline void set_keys_7(KeyCollection_tBF5A3A379C2FAEE27B40772C452E5AE4593478D8 * value)
	{
		___keys_7 = value;
		Il2CppCodeGenWriteBarrier((&___keys_7), value);
	}

	inline static int32_t get_offset_of_values_8() { return static_cast<int32_t>(offsetof(Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2, ___values_8)); }
	inline ValueCollection_t271CAD233177D02D832E2497CF966741D6EDCE05 * get_values_8() const { return ___values_8; }
	inline ValueCollection_t271CAD233177D02D832E2497CF966741D6EDCE05 ** get_address_of_values_8() { return &___values_8; }
	inline void set_values_8(ValueCollection_t271CAD233177D02D832E2497CF966741D6EDCE05 * value)
	{
		___values_8 = value;
		Il2CppCodeGenWriteBarrier((&___values_8), value);
	}

	inline static int32_t get_offset_of__syncRoot_9() { return static_cast<int32_t>(offsetof(Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2, ____syncRoot_9)); }
	inline RuntimeObject * get__syncRoot_9() const { return ____syncRoot_9; }
	inline RuntimeObject ** get_address_of__syncRoot_9() { return &____syncRoot_9; }
	inline void set__syncRoot_9(RuntimeObject * value)
	{
		____syncRoot_9 = value;
		Il2CppCodeGenWriteBarrier((&____syncRoot_9), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DICTIONARY_2_T3D83C47A25C154C47BE0619594AB0435F23CA7C2_H
#ifndef LIST_1_T43B2D37CF48E04673A48558029581722DDF26F4E_H
#define LIST_1_T43B2D37CF48E04673A48558029581722DDF26F4E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1<Byn.Awrtc.ByteArrayBuffer>
struct  List_1_t43B2D37CF48E04673A48558029581722DDF26F4E  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	ByteArrayBufferU5BU5D_tC32F3D7B0B29CCF15D73904436B2C68139358EBD* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t43B2D37CF48E04673A48558029581722DDF26F4E, ____items_1)); }
	inline ByteArrayBufferU5BU5D_tC32F3D7B0B29CCF15D73904436B2C68139358EBD* get__items_1() const { return ____items_1; }
	inline ByteArrayBufferU5BU5D_tC32F3D7B0B29CCF15D73904436B2C68139358EBD** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(ByteArrayBufferU5BU5D_tC32F3D7B0B29CCF15D73904436B2C68139358EBD* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((&____items_1), value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t43B2D37CF48E04673A48558029581722DDF26F4E, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t43B2D37CF48E04673A48558029581722DDF26F4E, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_t43B2D37CF48E04673A48558029581722DDF26F4E, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((&____syncRoot_4), value);
	}
};

struct List_1_t43B2D37CF48E04673A48558029581722DDF26F4E_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	ByteArrayBufferU5BU5D_tC32F3D7B0B29CCF15D73904436B2C68139358EBD* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_t43B2D37CF48E04673A48558029581722DDF26F4E_StaticFields, ____emptyArray_5)); }
	inline ByteArrayBufferU5BU5D_tC32F3D7B0B29CCF15D73904436B2C68139358EBD* get__emptyArray_5() const { return ____emptyArray_5; }
	inline ByteArrayBufferU5BU5D_tC32F3D7B0B29CCF15D73904436B2C68139358EBD** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(ByteArrayBufferU5BU5D_tC32F3D7B0B29CCF15D73904436B2C68139358EBD* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((&____emptyArray_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIST_1_T43B2D37CF48E04673A48558029581722DDF26F4E_H
#ifndef LIST_1_TCB9967EC4C00221A410117D712FF423882EB5832_H
#define LIST_1_TCB9967EC4C00221A410117D712FF423882EB5832_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>
struct  List_1_tCB9967EC4C00221A410117D712FF423882EB5832  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	ConnectionIdU5BU5D_t7B8CFD2BA9E73DEBAE908EE9BA8B3B81A8640294* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_tCB9967EC4C00221A410117D712FF423882EB5832, ____items_1)); }
	inline ConnectionIdU5BU5D_t7B8CFD2BA9E73DEBAE908EE9BA8B3B81A8640294* get__items_1() const { return ____items_1; }
	inline ConnectionIdU5BU5D_t7B8CFD2BA9E73DEBAE908EE9BA8B3B81A8640294** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(ConnectionIdU5BU5D_t7B8CFD2BA9E73DEBAE908EE9BA8B3B81A8640294* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((&____items_1), value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_tCB9967EC4C00221A410117D712FF423882EB5832, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_tCB9967EC4C00221A410117D712FF423882EB5832, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_tCB9967EC4C00221A410117D712FF423882EB5832, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((&____syncRoot_4), value);
	}
};

struct List_1_tCB9967EC4C00221A410117D712FF423882EB5832_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	ConnectionIdU5BU5D_t7B8CFD2BA9E73DEBAE908EE9BA8B3B81A8640294* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_tCB9967EC4C00221A410117D712FF423882EB5832_StaticFields, ____emptyArray_5)); }
	inline ConnectionIdU5BU5D_t7B8CFD2BA9E73DEBAE908EE9BA8B3B81A8640294* get__emptyArray_5() const { return ____emptyArray_5; }
	inline ConnectionIdU5BU5D_t7B8CFD2BA9E73DEBAE908EE9BA8B3B81A8640294** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(ConnectionIdU5BU5D_t7B8CFD2BA9E73DEBAE908EE9BA8B3B81A8640294* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((&____emptyArray_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIST_1_TCB9967EC4C00221A410117D712FF423882EB5832_H
#ifndef LIST_1_T071E9AF889461644CC5513065D8B09A62D4EE708_H
#define LIST_1_T071E9AF889461644CC5513065D8B09A62D4EE708_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1<Byn.Awrtc.IceServer>
struct  List_1_t071E9AF889461644CC5513065D8B09A62D4EE708  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	IceServerU5BU5D_t77B1ADF58E5BEF879817A80953BA71C121730B4A* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_t071E9AF889461644CC5513065D8B09A62D4EE708, ____items_1)); }
	inline IceServerU5BU5D_t77B1ADF58E5BEF879817A80953BA71C121730B4A* get__items_1() const { return ____items_1; }
	inline IceServerU5BU5D_t77B1ADF58E5BEF879817A80953BA71C121730B4A** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(IceServerU5BU5D_t77B1ADF58E5BEF879817A80953BA71C121730B4A* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((&____items_1), value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_t071E9AF889461644CC5513065D8B09A62D4EE708, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_t071E9AF889461644CC5513065D8B09A62D4EE708, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_t071E9AF889461644CC5513065D8B09A62D4EE708, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((&____syncRoot_4), value);
	}
};

struct List_1_t071E9AF889461644CC5513065D8B09A62D4EE708_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	IceServerU5BU5D_t77B1ADF58E5BEF879817A80953BA71C121730B4A* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_t071E9AF889461644CC5513065D8B09A62D4EE708_StaticFields, ____emptyArray_5)); }
	inline IceServerU5BU5D_t77B1ADF58E5BEF879817A80953BA71C121730B4A* get__emptyArray_5() const { return ____emptyArray_5; }
	inline IceServerU5BU5D_t77B1ADF58E5BEF879817A80953BA71C121730B4A** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(IceServerU5BU5D_t77B1ADF58E5BEF879817A80953BA71C121730B4A* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((&____emptyArray_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIST_1_T071E9AF889461644CC5513065D8B09A62D4EE708_H
#ifndef LIST_1_TE8032E48C661C350FF9550E9063D595C0AB25CD3_H
#define LIST_1_TE8032E48C661C350FF9550E9063D595C0AB25CD3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1<System.String>
struct  List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.List`1::_items
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ____items_1;
	// System.Int32 System.Collections.Generic.List`1::_size
	int32_t ____size_2;
	// System.Int32 System.Collections.Generic.List`1::_version
	int32_t ____version_3;
	// System.Object System.Collections.Generic.List`1::_syncRoot
	RuntimeObject * ____syncRoot_4;

public:
	inline static int32_t get_offset_of__items_1() { return static_cast<int32_t>(offsetof(List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3, ____items_1)); }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* get__items_1() const { return ____items_1; }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E** get_address_of__items_1() { return &____items_1; }
	inline void set__items_1(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* value)
	{
		____items_1 = value;
		Il2CppCodeGenWriteBarrier((&____items_1), value);
	}

	inline static int32_t get_offset_of__size_2() { return static_cast<int32_t>(offsetof(List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3, ____size_2)); }
	inline int32_t get__size_2() const { return ____size_2; }
	inline int32_t* get_address_of__size_2() { return &____size_2; }
	inline void set__size_2(int32_t value)
	{
		____size_2 = value;
	}

	inline static int32_t get_offset_of__version_3() { return static_cast<int32_t>(offsetof(List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3, ____version_3)); }
	inline int32_t get__version_3() const { return ____version_3; }
	inline int32_t* get_address_of__version_3() { return &____version_3; }
	inline void set__version_3(int32_t value)
	{
		____version_3 = value;
	}

	inline static int32_t get_offset_of__syncRoot_4() { return static_cast<int32_t>(offsetof(List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3, ____syncRoot_4)); }
	inline RuntimeObject * get__syncRoot_4() const { return ____syncRoot_4; }
	inline RuntimeObject ** get_address_of__syncRoot_4() { return &____syncRoot_4; }
	inline void set__syncRoot_4(RuntimeObject * value)
	{
		____syncRoot_4 = value;
		Il2CppCodeGenWriteBarrier((&____syncRoot_4), value);
	}
};

struct List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3_StaticFields
{
public:
	// T[] System.Collections.Generic.List`1::_emptyArray
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ____emptyArray_5;

public:
	inline static int32_t get_offset_of__emptyArray_5() { return static_cast<int32_t>(offsetof(List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3_StaticFields, ____emptyArray_5)); }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* get__emptyArray_5() const { return ____emptyArray_5; }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E** get_address_of__emptyArray_5() { return &____emptyArray_5; }
	inline void set__emptyArray_5(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* value)
	{
		____emptyArray_5 = value;
		Il2CppCodeGenWriteBarrier((&____emptyArray_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIST_1_TE8032E48C661C350FF9550E9063D595C0AB25CD3_H
#ifndef QUEUE_1_T9466208D536BE6F2841E0F91579602EAEB5162BF_H
#define QUEUE_1_T9466208D536BE6F2841E0F91579602EAEB5162BF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent>
struct  Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF  : public RuntimeObject
{
public:
	// T[] System.Collections.Generic.Queue`1::_array
	NetworkEventU5BU5D_tFA57E65F46AEB90C286C05581A6779F52D0D3EB7* ____array_0;
	// System.Int32 System.Collections.Generic.Queue`1::_head
	int32_t ____head_1;
	// System.Int32 System.Collections.Generic.Queue`1::_tail
	int32_t ____tail_2;
	// System.Int32 System.Collections.Generic.Queue`1::_size
	int32_t ____size_3;
	// System.Int32 System.Collections.Generic.Queue`1::_version
	int32_t ____version_4;
	// System.Object System.Collections.Generic.Queue`1::_syncRoot
	RuntimeObject * ____syncRoot_5;

public:
	inline static int32_t get_offset_of__array_0() { return static_cast<int32_t>(offsetof(Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF, ____array_0)); }
	inline NetworkEventU5BU5D_tFA57E65F46AEB90C286C05581A6779F52D0D3EB7* get__array_0() const { return ____array_0; }
	inline NetworkEventU5BU5D_tFA57E65F46AEB90C286C05581A6779F52D0D3EB7** get_address_of__array_0() { return &____array_0; }
	inline void set__array_0(NetworkEventU5BU5D_tFA57E65F46AEB90C286C05581A6779F52D0D3EB7* value)
	{
		____array_0 = value;
		Il2CppCodeGenWriteBarrier((&____array_0), value);
	}

	inline static int32_t get_offset_of__head_1() { return static_cast<int32_t>(offsetof(Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF, ____head_1)); }
	inline int32_t get__head_1() const { return ____head_1; }
	inline int32_t* get_address_of__head_1() { return &____head_1; }
	inline void set__head_1(int32_t value)
	{
		____head_1 = value;
	}

	inline static int32_t get_offset_of__tail_2() { return static_cast<int32_t>(offsetof(Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF, ____tail_2)); }
	inline int32_t get__tail_2() const { return ____tail_2; }
	inline int32_t* get_address_of__tail_2() { return &____tail_2; }
	inline void set__tail_2(int32_t value)
	{
		____tail_2 = value;
	}

	inline static int32_t get_offset_of__size_3() { return static_cast<int32_t>(offsetof(Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF, ____size_3)); }
	inline int32_t get__size_3() const { return ____size_3; }
	inline int32_t* get_address_of__size_3() { return &____size_3; }
	inline void set__size_3(int32_t value)
	{
		____size_3 = value;
	}

	inline static int32_t get_offset_of__version_4() { return static_cast<int32_t>(offsetof(Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF, ____version_4)); }
	inline int32_t get__version_4() const { return ____version_4; }
	inline int32_t* get_address_of__version_4() { return &____version_4; }
	inline void set__version_4(int32_t value)
	{
		____version_4 = value;
	}

	inline static int32_t get_offset_of__syncRoot_5() { return static_cast<int32_t>(offsetof(Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF, ____syncRoot_5)); }
	inline RuntimeObject * get__syncRoot_5() const { return ____syncRoot_5; }
	inline RuntimeObject ** get_address_of__syncRoot_5() { return &____syncRoot_5; }
	inline void set__syncRoot_5(RuntimeObject * value)
	{
		____syncRoot_5 = value;
		Il2CppCodeGenWriteBarrier((&____syncRoot_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // QUEUE_1_T9466208D536BE6F2841E0F91579602EAEB5162BF_H
#ifndef EXCEPTION_T_H
#define EXCEPTION_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Exception
struct  Exception_t  : public RuntimeObject
{
public:
	// System.String System.Exception::_className
	String_t* ____className_1;
	// System.String System.Exception::_message
	String_t* ____message_2;
	// System.Collections.IDictionary System.Exception::_data
	RuntimeObject* ____data_3;
	// System.Exception System.Exception::_innerException
	Exception_t * ____innerException_4;
	// System.String System.Exception::_helpURL
	String_t* ____helpURL_5;
	// System.Object System.Exception::_stackTrace
	RuntimeObject * ____stackTrace_6;
	// System.String System.Exception::_stackTraceString
	String_t* ____stackTraceString_7;
	// System.String System.Exception::_remoteStackTraceString
	String_t* ____remoteStackTraceString_8;
	// System.Int32 System.Exception::_remoteStackIndex
	int32_t ____remoteStackIndex_9;
	// System.Object System.Exception::_dynamicMethods
	RuntimeObject * ____dynamicMethods_10;
	// System.Int32 System.Exception::_HResult
	int32_t ____HResult_11;
	// System.String System.Exception::_source
	String_t* ____source_12;
	// System.Runtime.Serialization.SafeSerializationManager System.Exception::_safeSerializationManager
	SafeSerializationManager_t4A754D86B0F784B18CBC36C073BA564BED109770 * ____safeSerializationManager_13;
	// System.Diagnostics.StackTrace[] System.Exception::captured_traces
	StackTraceU5BU5D_t855F09649EA34DEE7C1B6F088E0538E3CCC3F196* ___captured_traces_14;
	// System.IntPtr[] System.Exception::native_trace_ips
	IntPtrU5BU5D_t4DC01DCB9A6DF6C9792A6513595D7A11E637DCDD* ___native_trace_ips_15;

public:
	inline static int32_t get_offset_of__className_1() { return static_cast<int32_t>(offsetof(Exception_t, ____className_1)); }
	inline String_t* get__className_1() const { return ____className_1; }
	inline String_t** get_address_of__className_1() { return &____className_1; }
	inline void set__className_1(String_t* value)
	{
		____className_1 = value;
		Il2CppCodeGenWriteBarrier((&____className_1), value);
	}

	inline static int32_t get_offset_of__message_2() { return static_cast<int32_t>(offsetof(Exception_t, ____message_2)); }
	inline String_t* get__message_2() const { return ____message_2; }
	inline String_t** get_address_of__message_2() { return &____message_2; }
	inline void set__message_2(String_t* value)
	{
		____message_2 = value;
		Il2CppCodeGenWriteBarrier((&____message_2), value);
	}

	inline static int32_t get_offset_of__data_3() { return static_cast<int32_t>(offsetof(Exception_t, ____data_3)); }
	inline RuntimeObject* get__data_3() const { return ____data_3; }
	inline RuntimeObject** get_address_of__data_3() { return &____data_3; }
	inline void set__data_3(RuntimeObject* value)
	{
		____data_3 = value;
		Il2CppCodeGenWriteBarrier((&____data_3), value);
	}

	inline static int32_t get_offset_of__innerException_4() { return static_cast<int32_t>(offsetof(Exception_t, ____innerException_4)); }
	inline Exception_t * get__innerException_4() const { return ____innerException_4; }
	inline Exception_t ** get_address_of__innerException_4() { return &____innerException_4; }
	inline void set__innerException_4(Exception_t * value)
	{
		____innerException_4 = value;
		Il2CppCodeGenWriteBarrier((&____innerException_4), value);
	}

	inline static int32_t get_offset_of__helpURL_5() { return static_cast<int32_t>(offsetof(Exception_t, ____helpURL_5)); }
	inline String_t* get__helpURL_5() const { return ____helpURL_5; }
	inline String_t** get_address_of__helpURL_5() { return &____helpURL_5; }
	inline void set__helpURL_5(String_t* value)
	{
		____helpURL_5 = value;
		Il2CppCodeGenWriteBarrier((&____helpURL_5), value);
	}

	inline static int32_t get_offset_of__stackTrace_6() { return static_cast<int32_t>(offsetof(Exception_t, ____stackTrace_6)); }
	inline RuntimeObject * get__stackTrace_6() const { return ____stackTrace_6; }
	inline RuntimeObject ** get_address_of__stackTrace_6() { return &____stackTrace_6; }
	inline void set__stackTrace_6(RuntimeObject * value)
	{
		____stackTrace_6 = value;
		Il2CppCodeGenWriteBarrier((&____stackTrace_6), value);
	}

	inline static int32_t get_offset_of__stackTraceString_7() { return static_cast<int32_t>(offsetof(Exception_t, ____stackTraceString_7)); }
	inline String_t* get__stackTraceString_7() const { return ____stackTraceString_7; }
	inline String_t** get_address_of__stackTraceString_7() { return &____stackTraceString_7; }
	inline void set__stackTraceString_7(String_t* value)
	{
		____stackTraceString_7 = value;
		Il2CppCodeGenWriteBarrier((&____stackTraceString_7), value);
	}

	inline static int32_t get_offset_of__remoteStackTraceString_8() { return static_cast<int32_t>(offsetof(Exception_t, ____remoteStackTraceString_8)); }
	inline String_t* get__remoteStackTraceString_8() const { return ____remoteStackTraceString_8; }
	inline String_t** get_address_of__remoteStackTraceString_8() { return &____remoteStackTraceString_8; }
	inline void set__remoteStackTraceString_8(String_t* value)
	{
		____remoteStackTraceString_8 = value;
		Il2CppCodeGenWriteBarrier((&____remoteStackTraceString_8), value);
	}

	inline static int32_t get_offset_of__remoteStackIndex_9() { return static_cast<int32_t>(offsetof(Exception_t, ____remoteStackIndex_9)); }
	inline int32_t get__remoteStackIndex_9() const { return ____remoteStackIndex_9; }
	inline int32_t* get_address_of__remoteStackIndex_9() { return &____remoteStackIndex_9; }
	inline void set__remoteStackIndex_9(int32_t value)
	{
		____remoteStackIndex_9 = value;
	}

	inline static int32_t get_offset_of__dynamicMethods_10() { return static_cast<int32_t>(offsetof(Exception_t, ____dynamicMethods_10)); }
	inline RuntimeObject * get__dynamicMethods_10() const { return ____dynamicMethods_10; }
	inline RuntimeObject ** get_address_of__dynamicMethods_10() { return &____dynamicMethods_10; }
	inline void set__dynamicMethods_10(RuntimeObject * value)
	{
		____dynamicMethods_10 = value;
		Il2CppCodeGenWriteBarrier((&____dynamicMethods_10), value);
	}

	inline static int32_t get_offset_of__HResult_11() { return static_cast<int32_t>(offsetof(Exception_t, ____HResult_11)); }
	inline int32_t get__HResult_11() const { return ____HResult_11; }
	inline int32_t* get_address_of__HResult_11() { return &____HResult_11; }
	inline void set__HResult_11(int32_t value)
	{
		____HResult_11 = value;
	}

	inline static int32_t get_offset_of__source_12() { return static_cast<int32_t>(offsetof(Exception_t, ____source_12)); }
	inline String_t* get__source_12() const { return ____source_12; }
	inline String_t** get_address_of__source_12() { return &____source_12; }
	inline void set__source_12(String_t* value)
	{
		____source_12 = value;
		Il2CppCodeGenWriteBarrier((&____source_12), value);
	}

	inline static int32_t get_offset_of__safeSerializationManager_13() { return static_cast<int32_t>(offsetof(Exception_t, ____safeSerializationManager_13)); }
	inline SafeSerializationManager_t4A754D86B0F784B18CBC36C073BA564BED109770 * get__safeSerializationManager_13() const { return ____safeSerializationManager_13; }
	inline SafeSerializationManager_t4A754D86B0F784B18CBC36C073BA564BED109770 ** get_address_of__safeSerializationManager_13() { return &____safeSerializationManager_13; }
	inline void set__safeSerializationManager_13(SafeSerializationManager_t4A754D86B0F784B18CBC36C073BA564BED109770 * value)
	{
		____safeSerializationManager_13 = value;
		Il2CppCodeGenWriteBarrier((&____safeSerializationManager_13), value);
	}

	inline static int32_t get_offset_of_captured_traces_14() { return static_cast<int32_t>(offsetof(Exception_t, ___captured_traces_14)); }
	inline StackTraceU5BU5D_t855F09649EA34DEE7C1B6F088E0538E3CCC3F196* get_captured_traces_14() const { return ___captured_traces_14; }
	inline StackTraceU5BU5D_t855F09649EA34DEE7C1B6F088E0538E3CCC3F196** get_address_of_captured_traces_14() { return &___captured_traces_14; }
	inline void set_captured_traces_14(StackTraceU5BU5D_t855F09649EA34DEE7C1B6F088E0538E3CCC3F196* value)
	{
		___captured_traces_14 = value;
		Il2CppCodeGenWriteBarrier((&___captured_traces_14), value);
	}

	inline static int32_t get_offset_of_native_trace_ips_15() { return static_cast<int32_t>(offsetof(Exception_t, ___native_trace_ips_15)); }
	inline IntPtrU5BU5D_t4DC01DCB9A6DF6C9792A6513595D7A11E637DCDD* get_native_trace_ips_15() const { return ___native_trace_ips_15; }
	inline IntPtrU5BU5D_t4DC01DCB9A6DF6C9792A6513595D7A11E637DCDD** get_address_of_native_trace_ips_15() { return &___native_trace_ips_15; }
	inline void set_native_trace_ips_15(IntPtrU5BU5D_t4DC01DCB9A6DF6C9792A6513595D7A11E637DCDD* value)
	{
		___native_trace_ips_15 = value;
		Il2CppCodeGenWriteBarrier((&___native_trace_ips_15), value);
	}
};

struct Exception_t_StaticFields
{
public:
	// System.Object System.Exception::s_EDILock
	RuntimeObject * ___s_EDILock_0;

public:
	inline static int32_t get_offset_of_s_EDILock_0() { return static_cast<int32_t>(offsetof(Exception_t_StaticFields, ___s_EDILock_0)); }
	inline RuntimeObject * get_s_EDILock_0() const { return ___s_EDILock_0; }
	inline RuntimeObject ** get_address_of_s_EDILock_0() { return &___s_EDILock_0; }
	inline void set_s_EDILock_0(RuntimeObject * value)
	{
		___s_EDILock_0 = value;
		Il2CppCodeGenWriteBarrier((&___s_EDILock_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Exception
struct Exception_t_marshaled_pinvoke
{
	char* ____className_1;
	char* ____message_2;
	RuntimeObject* ____data_3;
	Exception_t_marshaled_pinvoke* ____innerException_4;
	char* ____helpURL_5;
	Il2CppIUnknown* ____stackTrace_6;
	char* ____stackTraceString_7;
	char* ____remoteStackTraceString_8;
	int32_t ____remoteStackIndex_9;
	Il2CppIUnknown* ____dynamicMethods_10;
	int32_t ____HResult_11;
	char* ____source_12;
	SafeSerializationManager_t4A754D86B0F784B18CBC36C073BA564BED109770 * ____safeSerializationManager_13;
	StackTraceU5BU5D_t855F09649EA34DEE7C1B6F088E0538E3CCC3F196* ___captured_traces_14;
	intptr_t* ___native_trace_ips_15;
};
// Native definition for COM marshalling of System.Exception
struct Exception_t_marshaled_com
{
	Il2CppChar* ____className_1;
	Il2CppChar* ____message_2;
	RuntimeObject* ____data_3;
	Exception_t_marshaled_com* ____innerException_4;
	Il2CppChar* ____helpURL_5;
	Il2CppIUnknown* ____stackTrace_6;
	Il2CppChar* ____stackTraceString_7;
	Il2CppChar* ____remoteStackTraceString_8;
	int32_t ____remoteStackIndex_9;
	Il2CppIUnknown* ____dynamicMethods_10;
	int32_t ____HResult_11;
	Il2CppChar* ____source_12;
	SafeSerializationManager_t4A754D86B0F784B18CBC36C073BA564BED109770 * ____safeSerializationManager_13;
	StackTraceU5BU5D_t855F09649EA34DEE7C1B6F088E0538E3CCC3F196* ___captured_traces_14;
	intptr_t* ___native_trace_ips_15;
};
#endif // EXCEPTION_T_H
#ifndef STRING_T_H
#define STRING_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.String
struct  String_t  : public RuntimeObject
{
public:
	// System.Int32 System.String::m_stringLength
	int32_t ___m_stringLength_0;
	// System.Char System.String::m_firstChar
	Il2CppChar ___m_firstChar_1;

public:
	inline static int32_t get_offset_of_m_stringLength_0() { return static_cast<int32_t>(offsetof(String_t, ___m_stringLength_0)); }
	inline int32_t get_m_stringLength_0() const { return ___m_stringLength_0; }
	inline int32_t* get_address_of_m_stringLength_0() { return &___m_stringLength_0; }
	inline void set_m_stringLength_0(int32_t value)
	{
		___m_stringLength_0 = value;
	}

	inline static int32_t get_offset_of_m_firstChar_1() { return static_cast<int32_t>(offsetof(String_t, ___m_firstChar_1)); }
	inline Il2CppChar get_m_firstChar_1() const { return ___m_firstChar_1; }
	inline Il2CppChar* get_address_of_m_firstChar_1() { return &___m_firstChar_1; }
	inline void set_m_firstChar_1(Il2CppChar value)
	{
		___m_firstChar_1 = value;
	}
};

struct String_t_StaticFields
{
public:
	// System.String System.String::Empty
	String_t* ___Empty_5;

public:
	inline static int32_t get_offset_of_Empty_5() { return static_cast<int32_t>(offsetof(String_t_StaticFields, ___Empty_5)); }
	inline String_t* get_Empty_5() const { return ___Empty_5; }
	inline String_t** get_address_of_Empty_5() { return &___Empty_5; }
	inline void set_Empty_5(String_t* value)
	{
		___Empty_5 = value;
		Il2CppCodeGenWriteBarrier((&___Empty_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRING_T_H
#ifndef ENCODING_T7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_H
#define ENCODING_T7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Text.Encoding
struct  Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4  : public RuntimeObject
{
public:
	// System.Int32 System.Text.Encoding::m_codePage
	int32_t ___m_codePage_55;
	// System.Globalization.CodePageDataItem System.Text.Encoding::dataItem
	CodePageDataItem_t6E34BEE9CCCBB35C88D714664633AF6E5F5671FB * ___dataItem_56;
	// System.Boolean System.Text.Encoding::m_deserializedFromEverett
	bool ___m_deserializedFromEverett_57;
	// System.Boolean System.Text.Encoding::m_isReadOnly
	bool ___m_isReadOnly_58;
	// System.Text.EncoderFallback System.Text.Encoding::encoderFallback
	EncoderFallback_tDE342346D01608628F1BCEBB652D31009852CF63 * ___encoderFallback_59;
	// System.Text.DecoderFallback System.Text.Encoding::decoderFallback
	DecoderFallback_t128445EB7676870485230893338EF044F6B72F60 * ___decoderFallback_60;

public:
	inline static int32_t get_offset_of_m_codePage_55() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4, ___m_codePage_55)); }
	inline int32_t get_m_codePage_55() const { return ___m_codePage_55; }
	inline int32_t* get_address_of_m_codePage_55() { return &___m_codePage_55; }
	inline void set_m_codePage_55(int32_t value)
	{
		___m_codePage_55 = value;
	}

	inline static int32_t get_offset_of_dataItem_56() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4, ___dataItem_56)); }
	inline CodePageDataItem_t6E34BEE9CCCBB35C88D714664633AF6E5F5671FB * get_dataItem_56() const { return ___dataItem_56; }
	inline CodePageDataItem_t6E34BEE9CCCBB35C88D714664633AF6E5F5671FB ** get_address_of_dataItem_56() { return &___dataItem_56; }
	inline void set_dataItem_56(CodePageDataItem_t6E34BEE9CCCBB35C88D714664633AF6E5F5671FB * value)
	{
		___dataItem_56 = value;
		Il2CppCodeGenWriteBarrier((&___dataItem_56), value);
	}

	inline static int32_t get_offset_of_m_deserializedFromEverett_57() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4, ___m_deserializedFromEverett_57)); }
	inline bool get_m_deserializedFromEverett_57() const { return ___m_deserializedFromEverett_57; }
	inline bool* get_address_of_m_deserializedFromEverett_57() { return &___m_deserializedFromEverett_57; }
	inline void set_m_deserializedFromEverett_57(bool value)
	{
		___m_deserializedFromEverett_57 = value;
	}

	inline static int32_t get_offset_of_m_isReadOnly_58() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4, ___m_isReadOnly_58)); }
	inline bool get_m_isReadOnly_58() const { return ___m_isReadOnly_58; }
	inline bool* get_address_of_m_isReadOnly_58() { return &___m_isReadOnly_58; }
	inline void set_m_isReadOnly_58(bool value)
	{
		___m_isReadOnly_58 = value;
	}

	inline static int32_t get_offset_of_encoderFallback_59() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4, ___encoderFallback_59)); }
	inline EncoderFallback_tDE342346D01608628F1BCEBB652D31009852CF63 * get_encoderFallback_59() const { return ___encoderFallback_59; }
	inline EncoderFallback_tDE342346D01608628F1BCEBB652D31009852CF63 ** get_address_of_encoderFallback_59() { return &___encoderFallback_59; }
	inline void set_encoderFallback_59(EncoderFallback_tDE342346D01608628F1BCEBB652D31009852CF63 * value)
	{
		___encoderFallback_59 = value;
		Il2CppCodeGenWriteBarrier((&___encoderFallback_59), value);
	}

	inline static int32_t get_offset_of_decoderFallback_60() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4, ___decoderFallback_60)); }
	inline DecoderFallback_t128445EB7676870485230893338EF044F6B72F60 * get_decoderFallback_60() const { return ___decoderFallback_60; }
	inline DecoderFallback_t128445EB7676870485230893338EF044F6B72F60 ** get_address_of_decoderFallback_60() { return &___decoderFallback_60; }
	inline void set_decoderFallback_60(DecoderFallback_t128445EB7676870485230893338EF044F6B72F60 * value)
	{
		___decoderFallback_60 = value;
		Il2CppCodeGenWriteBarrier((&___decoderFallback_60), value);
	}
};

struct Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields
{
public:
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::defaultEncoding
	Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * ___defaultEncoding_0;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::unicodeEncoding
	Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * ___unicodeEncoding_1;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::bigEndianUnicode
	Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * ___bigEndianUnicode_2;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::utf7Encoding
	Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * ___utf7Encoding_3;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::utf8Encoding
	Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * ___utf8Encoding_4;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::utf32Encoding
	Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * ___utf32Encoding_5;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::asciiEncoding
	Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * ___asciiEncoding_6;
	// System.Text.Encoding modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::latin1Encoding
	Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * ___latin1Encoding_7;
	// System.Collections.Hashtable modreq(System.Runtime.CompilerServices.IsVolatile) System.Text.Encoding::encodings
	Hashtable_t978F65B8006C8F5504B286526AEC6608FF983FC9 * ___encodings_8;
	// System.Object System.Text.Encoding::s_InternalSyncObject
	RuntimeObject * ___s_InternalSyncObject_61;

public:
	inline static int32_t get_offset_of_defaultEncoding_0() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___defaultEncoding_0)); }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * get_defaultEncoding_0() const { return ___defaultEncoding_0; }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 ** get_address_of_defaultEncoding_0() { return &___defaultEncoding_0; }
	inline void set_defaultEncoding_0(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * value)
	{
		___defaultEncoding_0 = value;
		Il2CppCodeGenWriteBarrier((&___defaultEncoding_0), value);
	}

	inline static int32_t get_offset_of_unicodeEncoding_1() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___unicodeEncoding_1)); }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * get_unicodeEncoding_1() const { return ___unicodeEncoding_1; }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 ** get_address_of_unicodeEncoding_1() { return &___unicodeEncoding_1; }
	inline void set_unicodeEncoding_1(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * value)
	{
		___unicodeEncoding_1 = value;
		Il2CppCodeGenWriteBarrier((&___unicodeEncoding_1), value);
	}

	inline static int32_t get_offset_of_bigEndianUnicode_2() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___bigEndianUnicode_2)); }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * get_bigEndianUnicode_2() const { return ___bigEndianUnicode_2; }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 ** get_address_of_bigEndianUnicode_2() { return &___bigEndianUnicode_2; }
	inline void set_bigEndianUnicode_2(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * value)
	{
		___bigEndianUnicode_2 = value;
		Il2CppCodeGenWriteBarrier((&___bigEndianUnicode_2), value);
	}

	inline static int32_t get_offset_of_utf7Encoding_3() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___utf7Encoding_3)); }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * get_utf7Encoding_3() const { return ___utf7Encoding_3; }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 ** get_address_of_utf7Encoding_3() { return &___utf7Encoding_3; }
	inline void set_utf7Encoding_3(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * value)
	{
		___utf7Encoding_3 = value;
		Il2CppCodeGenWriteBarrier((&___utf7Encoding_3), value);
	}

	inline static int32_t get_offset_of_utf8Encoding_4() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___utf8Encoding_4)); }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * get_utf8Encoding_4() const { return ___utf8Encoding_4; }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 ** get_address_of_utf8Encoding_4() { return &___utf8Encoding_4; }
	inline void set_utf8Encoding_4(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * value)
	{
		___utf8Encoding_4 = value;
		Il2CppCodeGenWriteBarrier((&___utf8Encoding_4), value);
	}

	inline static int32_t get_offset_of_utf32Encoding_5() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___utf32Encoding_5)); }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * get_utf32Encoding_5() const { return ___utf32Encoding_5; }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 ** get_address_of_utf32Encoding_5() { return &___utf32Encoding_5; }
	inline void set_utf32Encoding_5(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * value)
	{
		___utf32Encoding_5 = value;
		Il2CppCodeGenWriteBarrier((&___utf32Encoding_5), value);
	}

	inline static int32_t get_offset_of_asciiEncoding_6() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___asciiEncoding_6)); }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * get_asciiEncoding_6() const { return ___asciiEncoding_6; }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 ** get_address_of_asciiEncoding_6() { return &___asciiEncoding_6; }
	inline void set_asciiEncoding_6(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * value)
	{
		___asciiEncoding_6 = value;
		Il2CppCodeGenWriteBarrier((&___asciiEncoding_6), value);
	}

	inline static int32_t get_offset_of_latin1Encoding_7() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___latin1Encoding_7)); }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * get_latin1Encoding_7() const { return ___latin1Encoding_7; }
	inline Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 ** get_address_of_latin1Encoding_7() { return &___latin1Encoding_7; }
	inline void set_latin1Encoding_7(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * value)
	{
		___latin1Encoding_7 = value;
		Il2CppCodeGenWriteBarrier((&___latin1Encoding_7), value);
	}

	inline static int32_t get_offset_of_encodings_8() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___encodings_8)); }
	inline Hashtable_t978F65B8006C8F5504B286526AEC6608FF983FC9 * get_encodings_8() const { return ___encodings_8; }
	inline Hashtable_t978F65B8006C8F5504B286526AEC6608FF983FC9 ** get_address_of_encodings_8() { return &___encodings_8; }
	inline void set_encodings_8(Hashtable_t978F65B8006C8F5504B286526AEC6608FF983FC9 * value)
	{
		___encodings_8 = value;
		Il2CppCodeGenWriteBarrier((&___encodings_8), value);
	}

	inline static int32_t get_offset_of_s_InternalSyncObject_61() { return static_cast<int32_t>(offsetof(Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_StaticFields, ___s_InternalSyncObject_61)); }
	inline RuntimeObject * get_s_InternalSyncObject_61() const { return ___s_InternalSyncObject_61; }
	inline RuntimeObject ** get_address_of_s_InternalSyncObject_61() { return &___s_InternalSyncObject_61; }
	inline void set_s_InternalSyncObject_61(RuntimeObject * value)
	{
		___s_InternalSyncObject_61 = value;
		Il2CppCodeGenWriteBarrier((&___s_InternalSyncObject_61), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENCODING_T7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4_H
#ifndef STRINGBUILDER_T_H
#define STRINGBUILDER_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Text.StringBuilder
struct  StringBuilder_t  : public RuntimeObject
{
public:
	// System.Char[] System.Text.StringBuilder::m_ChunkChars
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___m_ChunkChars_0;
	// System.Text.StringBuilder System.Text.StringBuilder::m_ChunkPrevious
	StringBuilder_t * ___m_ChunkPrevious_1;
	// System.Int32 System.Text.StringBuilder::m_ChunkLength
	int32_t ___m_ChunkLength_2;
	// System.Int32 System.Text.StringBuilder::m_ChunkOffset
	int32_t ___m_ChunkOffset_3;
	// System.Int32 System.Text.StringBuilder::m_MaxCapacity
	int32_t ___m_MaxCapacity_4;

public:
	inline static int32_t get_offset_of_m_ChunkChars_0() { return static_cast<int32_t>(offsetof(StringBuilder_t, ___m_ChunkChars_0)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_m_ChunkChars_0() const { return ___m_ChunkChars_0; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_m_ChunkChars_0() { return &___m_ChunkChars_0; }
	inline void set_m_ChunkChars_0(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___m_ChunkChars_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_ChunkChars_0), value);
	}

	inline static int32_t get_offset_of_m_ChunkPrevious_1() { return static_cast<int32_t>(offsetof(StringBuilder_t, ___m_ChunkPrevious_1)); }
	inline StringBuilder_t * get_m_ChunkPrevious_1() const { return ___m_ChunkPrevious_1; }
	inline StringBuilder_t ** get_address_of_m_ChunkPrevious_1() { return &___m_ChunkPrevious_1; }
	inline void set_m_ChunkPrevious_1(StringBuilder_t * value)
	{
		___m_ChunkPrevious_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_ChunkPrevious_1), value);
	}

	inline static int32_t get_offset_of_m_ChunkLength_2() { return static_cast<int32_t>(offsetof(StringBuilder_t, ___m_ChunkLength_2)); }
	inline int32_t get_m_ChunkLength_2() const { return ___m_ChunkLength_2; }
	inline int32_t* get_address_of_m_ChunkLength_2() { return &___m_ChunkLength_2; }
	inline void set_m_ChunkLength_2(int32_t value)
	{
		___m_ChunkLength_2 = value;
	}

	inline static int32_t get_offset_of_m_ChunkOffset_3() { return static_cast<int32_t>(offsetof(StringBuilder_t, ___m_ChunkOffset_3)); }
	inline int32_t get_m_ChunkOffset_3() const { return ___m_ChunkOffset_3; }
	inline int32_t* get_address_of_m_ChunkOffset_3() { return &___m_ChunkOffset_3; }
	inline void set_m_ChunkOffset_3(int32_t value)
	{
		___m_ChunkOffset_3 = value;
	}

	inline static int32_t get_offset_of_m_MaxCapacity_4() { return static_cast<int32_t>(offsetof(StringBuilder_t, ___m_MaxCapacity_4)); }
	inline int32_t get_m_MaxCapacity_4() const { return ___m_MaxCapacity_4; }
	inline int32_t* get_address_of_m_MaxCapacity_4() { return &___m_MaxCapacity_4; }
	inline void set_m_MaxCapacity_4(int32_t value)
	{
		___m_MaxCapacity_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STRINGBUILDER_T_H
#ifndef VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#define VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_com
{
};
#endif // VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#ifndef __STATICARRAYINITTYPESIZEU3D128_TA1E351C123D4FE21E27968CB84AB3C9993E5ABDE_H
#define __STATICARRAYINITTYPESIZEU3D128_TA1E351C123D4FE21E27968CB84AB3C9993E5ABDE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>U7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D___StaticArrayInitTypeSizeU3D128
struct  __StaticArrayInitTypeSizeU3D128_tA1E351C123D4FE21E27968CB84AB3C9993E5ABDE 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D128_tA1E351C123D4FE21E27968CB84AB3C9993E5ABDE__padding[128];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // __STATICARRAYINITTYPESIZEU3D128_TA1E351C123D4FE21E27968CB84AB3C9993E5ABDE_H
#ifndef CONNECTIONID_T47DBB761AF0DB1559EACE774B317DA2B8B67F66D_H
#define CONNECTIONID_T47DBB761AF0DB1559EACE774B317DA2B8B67F66D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.ConnectionId
struct  ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D 
{
public:
	// System.Int16 Byn.Awrtc.ConnectionId::id
	int16_t ___id_1;

public:
	inline static int32_t get_offset_of_id_1() { return static_cast<int32_t>(offsetof(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D, ___id_1)); }
	inline int16_t get_id_1() const { return ___id_1; }
	inline int16_t* get_address_of_id_1() { return &___id_1; }
	inline void set_id_1(int16_t value)
	{
		___id_1 = value;
	}
};

struct ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields
{
public:
	// Byn.Awrtc.ConnectionId Byn.Awrtc.ConnectionId::INVALID
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___INVALID_0;

public:
	inline static int32_t get_offset_of_INVALID_0() { return static_cast<int32_t>(offsetof(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields, ___INVALID_0)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_INVALID_0() const { return ___INVALID_0; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_INVALID_0() { return &___INVALID_0; }
	inline void set_INVALID_0(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___INVALID_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONNECTIONID_T47DBB761AF0DB1559EACE774B317DA2B8B67F66D_H
#ifndef BOOLEAN_TB53F6830F670160873277339AA58F15CAED4399C_H
#define BOOLEAN_TB53F6830F670160873277339AA58F15CAED4399C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Boolean
struct  Boolean_tB53F6830F670160873277339AA58F15CAED4399C 
{
public:
	// System.Boolean System.Boolean::m_value
	bool ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C, ___m_value_0)); }
	inline bool get_m_value_0() const { return ___m_value_0; }
	inline bool* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(bool value)
	{
		___m_value_0 = value;
	}
};

struct Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields
{
public:
	// System.String System.Boolean::TrueString
	String_t* ___TrueString_5;
	// System.String System.Boolean::FalseString
	String_t* ___FalseString_6;

public:
	inline static int32_t get_offset_of_TrueString_5() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields, ___TrueString_5)); }
	inline String_t* get_TrueString_5() const { return ___TrueString_5; }
	inline String_t** get_address_of_TrueString_5() { return &___TrueString_5; }
	inline void set_TrueString_5(String_t* value)
	{
		___TrueString_5 = value;
		Il2CppCodeGenWriteBarrier((&___TrueString_5), value);
	}

	inline static int32_t get_offset_of_FalseString_6() { return static_cast<int32_t>(offsetof(Boolean_tB53F6830F670160873277339AA58F15CAED4399C_StaticFields, ___FalseString_6)); }
	inline String_t* get_FalseString_6() const { return ___FalseString_6; }
	inline String_t** get_address_of_FalseString_6() { return &___FalseString_6; }
	inline void set_FalseString_6(String_t* value)
	{
		___FalseString_6 = value;
		Il2CppCodeGenWriteBarrier((&___FalseString_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BOOLEAN_TB53F6830F670160873277339AA58F15CAED4399C_H
#ifndef BYTE_TF87C579059BD4633E6840EBBBEEF899C6E33EF07_H
#define BYTE_TF87C579059BD4633E6840EBBBEEF899C6E33EF07_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Byte
struct  Byte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07 
{
public:
	// System.Byte System.Byte::m_value
	uint8_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Byte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07, ___m_value_0)); }
	inline uint8_t get_m_value_0() const { return ___m_value_0; }
	inline uint8_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint8_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BYTE_TF87C579059BD4633E6840EBBBEEF899C6E33EF07_H
#ifndef CHAR_TBF22D9FC341BE970735250BB6FF1A4A92BBA58B9_H
#define CHAR_TBF22D9FC341BE970735250BB6FF1A4A92BBA58B9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Char
struct  Char_tBF22D9FC341BE970735250BB6FF1A4A92BBA58B9 
{
public:
	// System.Char System.Char::m_value
	Il2CppChar ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Char_tBF22D9FC341BE970735250BB6FF1A4A92BBA58B9, ___m_value_0)); }
	inline Il2CppChar get_m_value_0() const { return ___m_value_0; }
	inline Il2CppChar* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(Il2CppChar value)
	{
		___m_value_0 = value;
	}
};

struct Char_tBF22D9FC341BE970735250BB6FF1A4A92BBA58B9_StaticFields
{
public:
	// System.Byte[] System.Char::categoryForLatin1
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___categoryForLatin1_3;

public:
	inline static int32_t get_offset_of_categoryForLatin1_3() { return static_cast<int32_t>(offsetof(Char_tBF22D9FC341BE970735250BB6FF1A4A92BBA58B9_StaticFields, ___categoryForLatin1_3)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get_categoryForLatin1_3() const { return ___categoryForLatin1_3; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of_categoryForLatin1_3() { return &___categoryForLatin1_3; }
	inline void set_categoryForLatin1_3(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		___categoryForLatin1_3 = value;
		Il2CppCodeGenWriteBarrier((&___categoryForLatin1_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CHAR_TBF22D9FC341BE970735250BB6FF1A4A92BBA58B9_H
#ifndef DOUBLE_T358B8F23BDC52A5DD700E727E204F9F7CDE12409_H
#define DOUBLE_T358B8F23BDC52A5DD700E727E204F9F7CDE12409_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Double
struct  Double_t358B8F23BDC52A5DD700E727E204F9F7CDE12409 
{
public:
	// System.Double System.Double::m_value
	double ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Double_t358B8F23BDC52A5DD700E727E204F9F7CDE12409, ___m_value_0)); }
	inline double get_m_value_0() const { return ___m_value_0; }
	inline double* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(double value)
	{
		___m_value_0 = value;
	}
};

struct Double_t358B8F23BDC52A5DD700E727E204F9F7CDE12409_StaticFields
{
public:
	// System.Double System.Double::NegativeZero
	double ___NegativeZero_7;

public:
	inline static int32_t get_offset_of_NegativeZero_7() { return static_cast<int32_t>(offsetof(Double_t358B8F23BDC52A5DD700E727E204F9F7CDE12409_StaticFields, ___NegativeZero_7)); }
	inline double get_NegativeZero_7() const { return ___NegativeZero_7; }
	inline double* get_address_of_NegativeZero_7() { return &___NegativeZero_7; }
	inline void set_NegativeZero_7(double value)
	{
		___NegativeZero_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DOUBLE_T358B8F23BDC52A5DD700E727E204F9F7CDE12409_H
#ifndef ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#define ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t2AF27C02B8653AE29442467390005ABC74D8F521  : public ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF
{
public:

public:
};

struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((&___enumSeperatorCharArray_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_com
{
};
#endif // ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#ifndef INT16_T823A20635DAF5A3D93A1E01CFBF3CBA27CF00B4D_H
#define INT16_T823A20635DAF5A3D93A1E01CFBF3CBA27CF00B4D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Int16
struct  Int16_t823A20635DAF5A3D93A1E01CFBF3CBA27CF00B4D 
{
public:
	// System.Int16 System.Int16::m_value
	int16_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int16_t823A20635DAF5A3D93A1E01CFBF3CBA27CF00B4D, ___m_value_0)); }
	inline int16_t get_m_value_0() const { return ___m_value_0; }
	inline int16_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int16_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INT16_T823A20635DAF5A3D93A1E01CFBF3CBA27CF00B4D_H
#ifndef INT32_T585191389E07734F19F3156FF88FB3EF4800D102_H
#define INT32_T585191389E07734F19F3156FF88FB3EF4800D102_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Int32
struct  Int32_t585191389E07734F19F3156FF88FB3EF4800D102 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int32_t585191389E07734F19F3156FF88FB3EF4800D102, ___m_value_0)); }
	inline int32_t get_m_value_0() const { return ___m_value_0; }
	inline int32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int32_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INT32_T585191389E07734F19F3156FF88FB3EF4800D102_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef NULLABLE_1_T0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_H
#define NULLABLE_1_T0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Nullable`1<System.Int32>
struct  Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB 
{
public:
	// T System.Nullable`1::value
	int32_t ___value_0;
	// System.Boolean System.Nullable`1::has_value
	bool ___has_value_1;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB, ___value_0)); }
	inline int32_t get_value_0() const { return ___value_0; }
	inline int32_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(int32_t value)
	{
		___value_0 = value;
	}

	inline static int32_t get_offset_of_has_value_1() { return static_cast<int32_t>(offsetof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB, ___has_value_1)); }
	inline bool get_has_value_1() const { return ___has_value_1; }
	inline bool* get_address_of_has_value_1() { return &___has_value_1; }
	inline void set_has_value_1(bool value)
	{
		___has_value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NULLABLE_1_T0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_H
#ifndef SYSTEMEXCEPTION_T5380468142AA850BE4A341D7AF3EAB9C78746782_H
#define SYSTEMEXCEPTION_T5380468142AA850BE4A341D7AF3EAB9C78746782_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.SystemException
struct  SystemException_t5380468142AA850BE4A341D7AF3EAB9C78746782  : public Exception_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SYSTEMEXCEPTION_T5380468142AA850BE4A341D7AF3EAB9C78746782_H
#ifndef UINT16_TAE45CEF73BF720100519F6867F32145D075F928E_H
#define UINT16_TAE45CEF73BF720100519F6867F32145D075F928E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UInt16
struct  UInt16_tAE45CEF73BF720100519F6867F32145D075F928E 
{
public:
	// System.UInt16 System.UInt16::m_value
	uint16_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(UInt16_tAE45CEF73BF720100519F6867F32145D075F928E, ___m_value_0)); }
	inline uint16_t get_m_value_0() const { return ___m_value_0; }
	inline uint16_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint16_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UINT16_TAE45CEF73BF720100519F6867F32145D075F928E_H
#ifndef UINT32_T4980FA09003AFAAB5A6E361BA2748EA9A005709B_H
#define UINT32_T4980FA09003AFAAB5A6E361BA2748EA9A005709B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.UInt32
struct  UInt32_t4980FA09003AFAAB5A6E361BA2748EA9A005709B 
{
public:
	// System.UInt32 System.UInt32::m_value
	uint32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(UInt32_t4980FA09003AFAAB5A6E361BA2748EA9A005709B, ___m_value_0)); }
	inline uint32_t get_m_value_0() const { return ___m_value_0; }
	inline uint32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(uint32_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UINT32_T4980FA09003AFAAB5A6E361BA2748EA9A005709B_H
#ifndef VOID_T22962CB4C05B1D89B55A6E1139F0E87A90987017_H
#define VOID_T22962CB4C05B1D89B55A6E1139F0E87A90987017_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Void
struct  Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017__padding[1];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VOID_T22962CB4C05B1D89B55A6E1139F0E87A90987017_H
#ifndef U3CPRIVATEIMPLEMENTATIONDETAILSU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_T0EF491E7C6CA3D3B0D052D94577A25F2983BB080_H
#define U3CPRIVATEIMPLEMENTATIONDETAILSU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_T0EF491E7C6CA3D3B0D052D94577A25F2983BB080_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>U7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D
struct  U3CPrivateImplementationDetailsU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_t0EF491E7C6CA3D3B0D052D94577A25F2983BB080  : public RuntimeObject
{
public:

public:
};

struct U3CPrivateImplementationDetailsU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_t0EF491E7C6CA3D3B0D052D94577A25F2983BB080_StaticFields
{
public:
	// <PrivateImplementationDetails>U7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D___StaticArrayInitTypeSizeU3D128 <PrivateImplementationDetails>U7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D::U24U24method0x6000054U2D1
	__StaticArrayInitTypeSizeU3D128_tA1E351C123D4FE21E27968CB84AB3C9993E5ABDE  ___U24U24method0x6000054U2D1_0;

public:
	inline static int32_t get_offset_of_U24U24method0x6000054U2D1_0() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_t0EF491E7C6CA3D3B0D052D94577A25F2983BB080_StaticFields, ___U24U24method0x6000054U2D1_0)); }
	inline __StaticArrayInitTypeSizeU3D128_tA1E351C123D4FE21E27968CB84AB3C9993E5ABDE  get_U24U24method0x6000054U2D1_0() const { return ___U24U24method0x6000054U2D1_0; }
	inline __StaticArrayInitTypeSizeU3D128_tA1E351C123D4FE21E27968CB84AB3C9993E5ABDE * get_address_of_U24U24method0x6000054U2D1_0() { return &___U24U24method0x6000054U2D1_0; }
	inline void set_U24U24method0x6000054U2D1_0(__StaticArrayInitTypeSizeU3D128_tA1E351C123D4FE21E27968CB84AB3C9993E5ABDE  value)
	{
		___U24U24method0x6000054U2D1_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CPRIVATEIMPLEMENTATIONDETAILSU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_T0EF491E7C6CA3D3B0D052D94577A25F2983BB080_H
#ifndef CALLSTATE_T4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_H
#define CALLSTATE_T4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.AWebRtcCall_CallState
struct  CallState_t4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC 
{
public:
	// System.Int32 Byn.Awrtc.Base.AWebRtcCall_CallState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(CallState_t4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLSTATE_T4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_H
#ifndef CALLEVENTTYPE_T83E9DB342D0F2580C5FB1EC4C26A3C3C035AD62B_H
#define CALLEVENTTYPE_T83E9DB342D0F2580C5FB1EC4C26A3C3C035AD62B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.CallEventType
struct  CallEventType_t83E9DB342D0F2580C5FB1EC4C26A3C3C035AD62B 
{
public:
	// System.Int32 Byn.Awrtc.CallEventType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(CallEventType_t83E9DB342D0F2580C5FB1EC4C26A3C3C035AD62B, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLEVENTTYPE_T83E9DB342D0F2580C5FB1EC4C26A3C3C035AD62B_H
#ifndef FRAMEPIXELFORMAT_TDCE4288D3AD386370E428FCC0668229B6994D9BB_H
#define FRAMEPIXELFORMAT_TDCE4288D3AD386370E428FCC0668229B6994D9BB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.FramePixelFormat
struct  FramePixelFormat_tDCE4288D3AD386370E428FCC0668229B6994D9BB 
{
public:
	// System.Int32 Byn.Awrtc.FramePixelFormat::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(FramePixelFormat_tDCE4288D3AD386370E428FCC0668229B6994D9BB, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FRAMEPIXELFORMAT_TDCE4288D3AD386370E428FCC0668229B6994D9BB_H
#ifndef LOCALNETWORK_T6CC9C9ABD435AA34E75B28DA1079343D30AEA562_H
#define LOCALNETWORK_T6CC9C9ABD435AA34E75B28DA1079343D30AEA562_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.LocalNetwork
struct  LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562  : public RuntimeObject
{
public:
	// System.Int32 Byn.Awrtc.LocalNetwork::mId
	int32_t ___mId_3;
	// Byn.Awrtc.ConnectionId Byn.Awrtc.LocalNetwork::mNextNetworkId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mNextNetworkId_4;
	// System.String Byn.Awrtc.LocalNetwork::mServerAddress
	String_t* ___mServerAddress_5;
	// System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent> Byn.Awrtc.LocalNetwork::mEvents
	Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * ___mEvents_6;
	// System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork_WeakRef`1<Byn.Awrtc.LocalNetwork>> Byn.Awrtc.LocalNetwork::mConnectionNetwork
	Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * ___mConnectionNetwork_7;
	// System.Boolean Byn.Awrtc.LocalNetwork::disposedValue
	bool ___disposedValue_8;

public:
	inline static int32_t get_offset_of_mId_3() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562, ___mId_3)); }
	inline int32_t get_mId_3() const { return ___mId_3; }
	inline int32_t* get_address_of_mId_3() { return &___mId_3; }
	inline void set_mId_3(int32_t value)
	{
		___mId_3 = value;
	}

	inline static int32_t get_offset_of_mNextNetworkId_4() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562, ___mNextNetworkId_4)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mNextNetworkId_4() const { return ___mNextNetworkId_4; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mNextNetworkId_4() { return &___mNextNetworkId_4; }
	inline void set_mNextNetworkId_4(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mNextNetworkId_4 = value;
	}

	inline static int32_t get_offset_of_mServerAddress_5() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562, ___mServerAddress_5)); }
	inline String_t* get_mServerAddress_5() const { return ___mServerAddress_5; }
	inline String_t** get_address_of_mServerAddress_5() { return &___mServerAddress_5; }
	inline void set_mServerAddress_5(String_t* value)
	{
		___mServerAddress_5 = value;
		Il2CppCodeGenWriteBarrier((&___mServerAddress_5), value);
	}

	inline static int32_t get_offset_of_mEvents_6() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562, ___mEvents_6)); }
	inline Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * get_mEvents_6() const { return ___mEvents_6; }
	inline Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF ** get_address_of_mEvents_6() { return &___mEvents_6; }
	inline void set_mEvents_6(Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * value)
	{
		___mEvents_6 = value;
		Il2CppCodeGenWriteBarrier((&___mEvents_6), value);
	}

	inline static int32_t get_offset_of_mConnectionNetwork_7() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562, ___mConnectionNetwork_7)); }
	inline Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * get_mConnectionNetwork_7() const { return ___mConnectionNetwork_7; }
	inline Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB ** get_address_of_mConnectionNetwork_7() { return &___mConnectionNetwork_7; }
	inline void set_mConnectionNetwork_7(Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * value)
	{
		___mConnectionNetwork_7 = value;
		Il2CppCodeGenWriteBarrier((&___mConnectionNetwork_7), value);
	}

	inline static int32_t get_offset_of_disposedValue_8() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562, ___disposedValue_8)); }
	inline bool get_disposedValue_8() const { return ___disposedValue_8; }
	inline bool* get_address_of_disposedValue_8() { return &___disposedValue_8; }
	inline void set_disposedValue_8(bool value)
	{
		___disposedValue_8 = value;
	}
};

struct LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields
{
public:
	// System.String Byn.Awrtc.LocalNetwork::LOCK_ADDRESS
	String_t* ___LOCK_ADDRESS_0;
	// System.Int32 Byn.Awrtc.LocalNetwork::sNextId
	int32_t ___sNextId_1;
	// System.Collections.Generic.Dictionary`2<System.String,Byn.Awrtc.LocalNetwork_WeakRef`1<Byn.Awrtc.LocalNetwork>> Byn.Awrtc.LocalNetwork::mServers
	Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * ___mServers_2;

public:
	inline static int32_t get_offset_of_LOCK_ADDRESS_0() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields, ___LOCK_ADDRESS_0)); }
	inline String_t* get_LOCK_ADDRESS_0() const { return ___LOCK_ADDRESS_0; }
	inline String_t** get_address_of_LOCK_ADDRESS_0() { return &___LOCK_ADDRESS_0; }
	inline void set_LOCK_ADDRESS_0(String_t* value)
	{
		___LOCK_ADDRESS_0 = value;
		Il2CppCodeGenWriteBarrier((&___LOCK_ADDRESS_0), value);
	}

	inline static int32_t get_offset_of_sNextId_1() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields, ___sNextId_1)); }
	inline int32_t get_sNextId_1() const { return ___sNextId_1; }
	inline int32_t* get_address_of_sNextId_1() { return &___sNextId_1; }
	inline void set_sNextId_1(int32_t value)
	{
		___sNextId_1 = value;
	}

	inline static int32_t get_offset_of_mServers_2() { return static_cast<int32_t>(offsetof(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields, ___mServers_2)); }
	inline Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * get_mServers_2() const { return ___mServers_2; }
	inline Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 ** get_address_of_mServers_2() { return &___mServers_2; }
	inline void set_mServers_2(Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * value)
	{
		___mServers_2 = value;
		Il2CppCodeGenWriteBarrier((&___mServers_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOCALNETWORK_T6CC9C9ABD435AA34E75B28DA1079343D30AEA562_H
#ifndef MEDIACONFIGURATIONSTATE_TD278B71006BEF0BB2F003EB306E41EB133453629_H
#define MEDIACONFIGURATIONSTATE_TD278B71006BEF0BB2F003EB306E41EB133453629_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.MediaConfigurationState
struct  MediaConfigurationState_tD278B71006BEF0BB2F003EB306E41EB133453629 
{
public:
	// System.Byte Byn.Awrtc.MediaConfigurationState::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(MediaConfigurationState_tD278B71006BEF0BB2F003EB306E41EB133453629, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MEDIACONFIGURATIONSTATE_TD278B71006BEF0BB2F003EB306E41EB133453629_H
#ifndef NETEVENTDATATYPE_T1C43B214D57FA8D91EC846A2FB89918433D613C6_H
#define NETEVENTDATATYPE_T1C43B214D57FA8D91EC846A2FB89918433D613C6_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.NetEventDataType
struct  NetEventDataType_t1C43B214D57FA8D91EC846A2FB89918433D613C6 
{
public:
	// System.Byte Byn.Awrtc.NetEventDataType::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(NetEventDataType_t1C43B214D57FA8D91EC846A2FB89918433D613C6, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NETEVENTDATATYPE_T1C43B214D57FA8D91EC846A2FB89918433D613C6_H
#ifndef NETEVENTTYPE_TD5213CE1DD8CDE1161395E0973FC1F8E5FB7B0A8_H
#define NETEVENTTYPE_TD5213CE1DD8CDE1161395E0973FC1F8E5FB7B0A8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.NetEventType
struct  NetEventType_tD5213CE1DD8CDE1161395E0973FC1F8E5FB7B0A8 
{
public:
	// System.Byte Byn.Awrtc.NetEventType::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(NetEventType_tD5213CE1DD8CDE1161395E0973FC1F8E5FB7B0A8, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // NETEVENTTYPE_TD5213CE1DD8CDE1161395E0973FC1F8E5FB7B0A8_H
#ifndef ARGUMENTEXCEPTION_TEDCD16F20A09ECE461C3DA766C16EDA8864057D1_H
#define ARGUMENTEXCEPTION_TEDCD16F20A09ECE461C3DA766C16EDA8864057D1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ArgumentException
struct  ArgumentException_tEDCD16F20A09ECE461C3DA766C16EDA8864057D1  : public SystemException_t5380468142AA850BE4A341D7AF3EAB9C78746782
{
public:
	// System.String System.ArgumentException::m_paramName
	String_t* ___m_paramName_17;

public:
	inline static int32_t get_offset_of_m_paramName_17() { return static_cast<int32_t>(offsetof(ArgumentException_tEDCD16F20A09ECE461C3DA766C16EDA8864057D1, ___m_paramName_17)); }
	inline String_t* get_m_paramName_17() const { return ___m_paramName_17; }
	inline String_t** get_address_of_m_paramName_17() { return &___m_paramName_17; }
	inline void set_m_paramName_17(String_t* value)
	{
		___m_paramName_17 = value;
		Il2CppCodeGenWriteBarrier((&___m_paramName_17), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ARGUMENTEXCEPTION_TEDCD16F20A09ECE461C3DA766C16EDA8864057D1_H
#ifndef KEYVALUEPAIR_2_T285938DD1E0EAC06C49621A86B042A11EE26877F_H
#define KEYVALUEPAIR_2_T285938DD1E0EAC06C49621A86B042A11EE26877F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.KeyValuePair`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork_WeakRef`1<Byn.Awrtc.LocalNetwork>>
struct  KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F 
{
public:
	// TKey System.Collections.Generic.KeyValuePair`2::key
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___key_0;
	// TValue System.Collections.Generic.KeyValuePair`2::value
	WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * ___value_1;

public:
	inline static int32_t get_offset_of_key_0() { return static_cast<int32_t>(offsetof(KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F, ___key_0)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_key_0() const { return ___key_0; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_key_0() { return &___key_0; }
	inline void set_key_0(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___key_0 = value;
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F, ___value_1)); }
	inline WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * get_value_1() const { return ___value_1; }
	inline WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 ** get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((&___value_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // KEYVALUEPAIR_2_T285938DD1E0EAC06C49621A86B042A11EE26877F_H
#ifndef KEYVALUEPAIR_2_T6ABB429F8FE6365218E1917CCEB1A5D558DB765C_H
#define KEYVALUEPAIR_2_T6ABB429F8FE6365218E1917CCEB1A5D558DB765C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.KeyValuePair`2<Byn.Awrtc.ConnectionId,System.Object>
struct  KeyValuePair_2_t6ABB429F8FE6365218E1917CCEB1A5D558DB765C 
{
public:
	// TKey System.Collections.Generic.KeyValuePair`2::key
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___key_0;
	// TValue System.Collections.Generic.KeyValuePair`2::value
	RuntimeObject * ___value_1;

public:
	inline static int32_t get_offset_of_key_0() { return static_cast<int32_t>(offsetof(KeyValuePair_2_t6ABB429F8FE6365218E1917CCEB1A5D558DB765C, ___key_0)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_key_0() const { return ___key_0; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_key_0() { return &___key_0; }
	inline void set_key_0(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___key_0 = value;
	}

	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(KeyValuePair_2_t6ABB429F8FE6365218E1917CCEB1A5D558DB765C, ___value_1)); }
	inline RuntimeObject * get_value_1() const { return ___value_1; }
	inline RuntimeObject ** get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(RuntimeObject * value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((&___value_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // KEYVALUEPAIR_2_T6ABB429F8FE6365218E1917CCEB1A5D558DB765C_H
#ifndef ENUMERATOR_TF0CB7A53A76C5C79B395257361774995129CAD17_H
#define ENUMERATOR_TF0CB7A53A76C5C79B395257361774995129CAD17_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.List`1_Enumerator<Byn.Awrtc.ConnectionId>
struct  Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 
{
public:
	// System.Collections.Generic.List`1<T> System.Collections.Generic.List`1_Enumerator::list
	List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * ___list_0;
	// System.Int32 System.Collections.Generic.List`1_Enumerator::index
	int32_t ___index_1;
	// System.Int32 System.Collections.Generic.List`1_Enumerator::version
	int32_t ___version_2;
	// T System.Collections.Generic.List`1_Enumerator::current
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___current_3;

public:
	inline static int32_t get_offset_of_list_0() { return static_cast<int32_t>(offsetof(Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17, ___list_0)); }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * get_list_0() const { return ___list_0; }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 ** get_address_of_list_0() { return &___list_0; }
	inline void set_list_0(List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * value)
	{
		___list_0 = value;
		Il2CppCodeGenWriteBarrier((&___list_0), value);
	}

	inline static int32_t get_offset_of_index_1() { return static_cast<int32_t>(offsetof(Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17, ___index_1)); }
	inline int32_t get_index_1() const { return ___index_1; }
	inline int32_t* get_address_of_index_1() { return &___index_1; }
	inline void set_index_1(int32_t value)
	{
		___index_1 = value;
	}

	inline static int32_t get_offset_of_version_2() { return static_cast<int32_t>(offsetof(Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17, ___version_2)); }
	inline int32_t get_version_2() const { return ___version_2; }
	inline int32_t* get_address_of_version_2() { return &___version_2; }
	inline void set_version_2(int32_t value)
	{
		___version_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17, ___current_3)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_current_3() const { return ___current_3; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___current_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_TF0CB7A53A76C5C79B395257361774995129CAD17_H
#ifndef DELEGATE_T_H
#define DELEGATE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Delegate
struct  Delegate_t  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::extra_arg
	intptr_t ___extra_arg_5;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_6;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_7;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_8;
	// System.DelegateData System.Delegate::data
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	// System.Boolean System.Delegate::method_is_virtual
	bool ___method_is_virtual_10;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t, ___invoke_impl_1)); }
	inline intptr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline intptr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(intptr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_target_2), value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_3)); }
	inline intptr_t get_method_3() const { return ___method_3; }
	inline intptr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(intptr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t, ___delegate_trampoline_4)); }
	inline intptr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline intptr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(intptr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_extra_arg_5() { return static_cast<int32_t>(offsetof(Delegate_t, ___extra_arg_5)); }
	inline intptr_t get_extra_arg_5() const { return ___extra_arg_5; }
	inline intptr_t* get_address_of_extra_arg_5() { return &___extra_arg_5; }
	inline void set_extra_arg_5(intptr_t value)
	{
		___extra_arg_5 = value;
	}

	inline static int32_t get_offset_of_method_code_6() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_code_6)); }
	inline intptr_t get_method_code_6() const { return ___method_code_6; }
	inline intptr_t* get_address_of_method_code_6() { return &___method_code_6; }
	inline void set_method_code_6(intptr_t value)
	{
		___method_code_6 = value;
	}

	inline static int32_t get_offset_of_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_info_7)); }
	inline MethodInfo_t * get_method_info_7() const { return ___method_info_7; }
	inline MethodInfo_t ** get_address_of_method_info_7() { return &___method_info_7; }
	inline void set_method_info_7(MethodInfo_t * value)
	{
		___method_info_7 = value;
		Il2CppCodeGenWriteBarrier((&___method_info_7), value);
	}

	inline static int32_t get_offset_of_original_method_info_8() { return static_cast<int32_t>(offsetof(Delegate_t, ___original_method_info_8)); }
	inline MethodInfo_t * get_original_method_info_8() const { return ___original_method_info_8; }
	inline MethodInfo_t ** get_address_of_original_method_info_8() { return &___original_method_info_8; }
	inline void set_original_method_info_8(MethodInfo_t * value)
	{
		___original_method_info_8 = value;
		Il2CppCodeGenWriteBarrier((&___original_method_info_8), value);
	}

	inline static int32_t get_offset_of_data_9() { return static_cast<int32_t>(offsetof(Delegate_t, ___data_9)); }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * get_data_9() const { return ___data_9; }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE ** get_address_of_data_9() { return &___data_9; }
	inline void set_data_9(DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * value)
	{
		___data_9 = value;
		Il2CppCodeGenWriteBarrier((&___data_9), value);
	}

	inline static int32_t get_offset_of_method_is_virtual_10() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_is_virtual_10)); }
	inline bool get_method_is_virtual_10() const { return ___method_is_virtual_10; }
	inline bool* get_address_of_method_is_virtual_10() { return &___method_is_virtual_10; }
	inline void set_method_is_virtual_10(bool value)
	{
		___method_is_virtual_10 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Delegate
struct Delegate_t_marshaled_pinvoke
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};
// Native definition for COM marshalling of System.Delegate
struct Delegate_t_marshaled_com
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};
#endif // DELEGATE_T_H
#ifndef INVALIDOPERATIONEXCEPTION_T0530E734D823F78310CAFAFA424CA5164D93A1F1_H
#define INVALIDOPERATIONEXCEPTION_T0530E734D823F78310CAFAFA424CA5164D93A1F1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.InvalidOperationException
struct  InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1  : public SystemException_t5380468142AA850BE4A341D7AF3EAB9C78746782
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INVALIDOPERATIONEXCEPTION_T0530E734D823F78310CAFAFA424CA5164D93A1F1_H
#ifndef RUNTIMEFIELDHANDLE_T844BDF00E8E6FE69D9AEAA7657F09018B864F4EF_H
#define RUNTIMEFIELDHANDLE_T844BDF00E8E6FE69D9AEAA7657F09018B864F4EF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.RuntimeFieldHandle
struct  RuntimeFieldHandle_t844BDF00E8E6FE69D9AEAA7657F09018B864F4EF 
{
public:
	// System.IntPtr System.RuntimeFieldHandle::value
	intptr_t ___value_0;

public:
	inline static int32_t get_offset_of_value_0() { return static_cast<int32_t>(offsetof(RuntimeFieldHandle_t844BDF00E8E6FE69D9AEAA7657F09018B864F4EF, ___value_0)); }
	inline intptr_t get_value_0() const { return ___value_0; }
	inline intptr_t* get_address_of_value_0() { return &___value_0; }
	inline void set_value_0(intptr_t value)
	{
		___value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEFIELDHANDLE_T844BDF00E8E6FE69D9AEAA7657F09018B864F4EF_H
#ifndef AWEBRTCCALL_T8643A5C98F146CCA1CACDB911820319270507AD3_H
#define AWEBRTCCALL_T8643A5C98F146CCA1CACDB911820319270507AD3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Base.AWebRtcCall
struct  AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3  : public RuntimeObject
{
public:
	// Byn.Awrtc.NetworkConfig Byn.Awrtc.Base.AWebRtcCall::mNetworkConfig
	NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * ___mNetworkConfig_1;
	// Byn.Awrtc.MediaConfig Byn.Awrtc.Base.AWebRtcCall::mMediaConfig
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___mMediaConfig_2;
	// Byn.Awrtc.CallEventHandler Byn.Awrtc.Base.AWebRtcCall::CallEvent
	CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * ___CallEvent_3;
	// Byn.Awrtc.IMediaNetwork Byn.Awrtc.Base.AWebRtcCall::mNetwork
	RuntimeObject* ___mNetwork_4;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mConferenceMode
	bool ___mConferenceMode_5;
	// Byn.Awrtc.Base.AWebRtcCall_CallState Byn.Awrtc.Base.AWebRtcCall::mState
	int32_t ___mState_8;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mIsDisposed
	bool ___mIsDisposed_9;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mLocalFrameEvents
	bool ___mLocalFrameEvents_10;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mServerInactive
	bool ___mServerInactive_11;
	// System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId> Byn.Awrtc.Base.AWebRtcCall::mConnectionIds
	List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * ___mConnectionIds_12;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mPendingListenCall
	bool ___mPendingListenCall_13;
	// System.Boolean Byn.Awrtc.Base.AWebRtcCall::mPendingCallCall
	bool ___mPendingCallCall_14;
	// System.String Byn.Awrtc.Base.AWebRtcCall::mPendingAddress
	String_t* ___mPendingAddress_15;

public:
	inline static int32_t get_offset_of_mNetworkConfig_1() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mNetworkConfig_1)); }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * get_mNetworkConfig_1() const { return ___mNetworkConfig_1; }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 ** get_address_of_mNetworkConfig_1() { return &___mNetworkConfig_1; }
	inline void set_mNetworkConfig_1(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * value)
	{
		___mNetworkConfig_1 = value;
		Il2CppCodeGenWriteBarrier((&___mNetworkConfig_1), value);
	}

	inline static int32_t get_offset_of_mMediaConfig_2() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mMediaConfig_2)); }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * get_mMediaConfig_2() const { return ___mMediaConfig_2; }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D ** get_address_of_mMediaConfig_2() { return &___mMediaConfig_2; }
	inline void set_mMediaConfig_2(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * value)
	{
		___mMediaConfig_2 = value;
		Il2CppCodeGenWriteBarrier((&___mMediaConfig_2), value);
	}

	inline static int32_t get_offset_of_CallEvent_3() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___CallEvent_3)); }
	inline CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * get_CallEvent_3() const { return ___CallEvent_3; }
	inline CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F ** get_address_of_CallEvent_3() { return &___CallEvent_3; }
	inline void set_CallEvent_3(CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * value)
	{
		___CallEvent_3 = value;
		Il2CppCodeGenWriteBarrier((&___CallEvent_3), value);
	}

	inline static int32_t get_offset_of_mNetwork_4() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mNetwork_4)); }
	inline RuntimeObject* get_mNetwork_4() const { return ___mNetwork_4; }
	inline RuntimeObject** get_address_of_mNetwork_4() { return &___mNetwork_4; }
	inline void set_mNetwork_4(RuntimeObject* value)
	{
		___mNetwork_4 = value;
		Il2CppCodeGenWriteBarrier((&___mNetwork_4), value);
	}

	inline static int32_t get_offset_of_mConferenceMode_5() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mConferenceMode_5)); }
	inline bool get_mConferenceMode_5() const { return ___mConferenceMode_5; }
	inline bool* get_address_of_mConferenceMode_5() { return &___mConferenceMode_5; }
	inline void set_mConferenceMode_5(bool value)
	{
		___mConferenceMode_5 = value;
	}

	inline static int32_t get_offset_of_mState_8() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mState_8)); }
	inline int32_t get_mState_8() const { return ___mState_8; }
	inline int32_t* get_address_of_mState_8() { return &___mState_8; }
	inline void set_mState_8(int32_t value)
	{
		___mState_8 = value;
	}

	inline static int32_t get_offset_of_mIsDisposed_9() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mIsDisposed_9)); }
	inline bool get_mIsDisposed_9() const { return ___mIsDisposed_9; }
	inline bool* get_address_of_mIsDisposed_9() { return &___mIsDisposed_9; }
	inline void set_mIsDisposed_9(bool value)
	{
		___mIsDisposed_9 = value;
	}

	inline static int32_t get_offset_of_mLocalFrameEvents_10() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mLocalFrameEvents_10)); }
	inline bool get_mLocalFrameEvents_10() const { return ___mLocalFrameEvents_10; }
	inline bool* get_address_of_mLocalFrameEvents_10() { return &___mLocalFrameEvents_10; }
	inline void set_mLocalFrameEvents_10(bool value)
	{
		___mLocalFrameEvents_10 = value;
	}

	inline static int32_t get_offset_of_mServerInactive_11() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mServerInactive_11)); }
	inline bool get_mServerInactive_11() const { return ___mServerInactive_11; }
	inline bool* get_address_of_mServerInactive_11() { return &___mServerInactive_11; }
	inline void set_mServerInactive_11(bool value)
	{
		___mServerInactive_11 = value;
	}

	inline static int32_t get_offset_of_mConnectionIds_12() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mConnectionIds_12)); }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * get_mConnectionIds_12() const { return ___mConnectionIds_12; }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 ** get_address_of_mConnectionIds_12() { return &___mConnectionIds_12; }
	inline void set_mConnectionIds_12(List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * value)
	{
		___mConnectionIds_12 = value;
		Il2CppCodeGenWriteBarrier((&___mConnectionIds_12), value);
	}

	inline static int32_t get_offset_of_mPendingListenCall_13() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mPendingListenCall_13)); }
	inline bool get_mPendingListenCall_13() const { return ___mPendingListenCall_13; }
	inline bool* get_address_of_mPendingListenCall_13() { return &___mPendingListenCall_13; }
	inline void set_mPendingListenCall_13(bool value)
	{
		___mPendingListenCall_13 = value;
	}

	inline static int32_t get_offset_of_mPendingCallCall_14() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mPendingCallCall_14)); }
	inline bool get_mPendingCallCall_14() const { return ___mPendingCallCall_14; }
	inline bool* get_address_of_mPendingCallCall_14() { return &___mPendingCallCall_14; }
	inline void set_mPendingCallCall_14(bool value)
	{
		___mPendingCallCall_14 = value;
	}

	inline static int32_t get_offset_of_mPendingAddress_15() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3, ___mPendingAddress_15)); }
	inline String_t* get_mPendingAddress_15() const { return ___mPendingAddress_15; }
	inline String_t** get_address_of_mPendingAddress_15() { return &___mPendingAddress_15; }
	inline void set_mPendingAddress_15(String_t* value)
	{
		___mPendingAddress_15 = value;
		Il2CppCodeGenWriteBarrier((&___mPendingAddress_15), value);
	}
};

struct AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields
{
public:
	// System.String Byn.Awrtc.Base.AWebRtcCall::LOGTAG
	String_t* ___LOGTAG_0;
	// System.Byte Byn.Awrtc.Base.AWebRtcCall::MESSAGE_TYPE_DATA
	uint8_t ___MESSAGE_TYPE_DATA_6;
	// System.Byte Byn.Awrtc.Base.AWebRtcCall::MESSAGE_TYPE_STRING
	uint8_t ___MESSAGE_TYPE_STRING_7;

public:
	inline static int32_t get_offset_of_LOGTAG_0() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields, ___LOGTAG_0)); }
	inline String_t* get_LOGTAG_0() const { return ___LOGTAG_0; }
	inline String_t** get_address_of_LOGTAG_0() { return &___LOGTAG_0; }
	inline void set_LOGTAG_0(String_t* value)
	{
		___LOGTAG_0 = value;
		Il2CppCodeGenWriteBarrier((&___LOGTAG_0), value);
	}

	inline static int32_t get_offset_of_MESSAGE_TYPE_DATA_6() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields, ___MESSAGE_TYPE_DATA_6)); }
	inline uint8_t get_MESSAGE_TYPE_DATA_6() const { return ___MESSAGE_TYPE_DATA_6; }
	inline uint8_t* get_address_of_MESSAGE_TYPE_DATA_6() { return &___MESSAGE_TYPE_DATA_6; }
	inline void set_MESSAGE_TYPE_DATA_6(uint8_t value)
	{
		___MESSAGE_TYPE_DATA_6 = value;
	}

	inline static int32_t get_offset_of_MESSAGE_TYPE_STRING_7() { return static_cast<int32_t>(offsetof(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields, ___MESSAGE_TYPE_STRING_7)); }
	inline uint8_t get_MESSAGE_TYPE_STRING_7() const { return ___MESSAGE_TYPE_STRING_7; }
	inline uint8_t* get_address_of_MESSAGE_TYPE_STRING_7() { return &___MESSAGE_TYPE_STRING_7; }
	inline void set_MESSAGE_TYPE_STRING_7(uint8_t value)
	{
		___MESSAGE_TYPE_STRING_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AWEBRTCCALL_T8643A5C98F146CCA1CACDB911820319270507AD3_H
#ifndef BUFFEREDFRAME_TAFC3F736E124573A402343AB673AAF8EB53E0028_H
#define BUFFEREDFRAME_TAFC3F736E124573A402343AB673AAF8EB53E0028_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.BufferedFrame
struct  BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028  : public RuntimeObject
{
public:
	// System.Byte[] Byn.Awrtc.BufferedFrame::mBuffer
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___mBuffer_0;
	// System.Int32 Byn.Awrtc.BufferedFrame::mWidth
	int32_t ___mWidth_1;
	// System.Int32 Byn.Awrtc.BufferedFrame::mHeight
	int32_t ___mHeight_2;
	// System.Int32 Byn.Awrtc.BufferedFrame::mRotation
	int32_t ___mRotation_3;
	// System.Boolean Byn.Awrtc.BufferedFrame::mTopRowFirst
	bool ___mTopRowFirst_4;
	// Byn.Awrtc.FramePixelFormat Byn.Awrtc.BufferedFrame::mFormat
	int32_t ___mFormat_5;

public:
	inline static int32_t get_offset_of_mBuffer_0() { return static_cast<int32_t>(offsetof(BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028, ___mBuffer_0)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get_mBuffer_0() const { return ___mBuffer_0; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of_mBuffer_0() { return &___mBuffer_0; }
	inline void set_mBuffer_0(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		___mBuffer_0 = value;
		Il2CppCodeGenWriteBarrier((&___mBuffer_0), value);
	}

	inline static int32_t get_offset_of_mWidth_1() { return static_cast<int32_t>(offsetof(BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028, ___mWidth_1)); }
	inline int32_t get_mWidth_1() const { return ___mWidth_1; }
	inline int32_t* get_address_of_mWidth_1() { return &___mWidth_1; }
	inline void set_mWidth_1(int32_t value)
	{
		___mWidth_1 = value;
	}

	inline static int32_t get_offset_of_mHeight_2() { return static_cast<int32_t>(offsetof(BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028, ___mHeight_2)); }
	inline int32_t get_mHeight_2() const { return ___mHeight_2; }
	inline int32_t* get_address_of_mHeight_2() { return &___mHeight_2; }
	inline void set_mHeight_2(int32_t value)
	{
		___mHeight_2 = value;
	}

	inline static int32_t get_offset_of_mRotation_3() { return static_cast<int32_t>(offsetof(BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028, ___mRotation_3)); }
	inline int32_t get_mRotation_3() const { return ___mRotation_3; }
	inline int32_t* get_address_of_mRotation_3() { return &___mRotation_3; }
	inline void set_mRotation_3(int32_t value)
	{
		___mRotation_3 = value;
	}

	inline static int32_t get_offset_of_mTopRowFirst_4() { return static_cast<int32_t>(offsetof(BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028, ___mTopRowFirst_4)); }
	inline bool get_mTopRowFirst_4() const { return ___mTopRowFirst_4; }
	inline bool* get_address_of_mTopRowFirst_4() { return &___mTopRowFirst_4; }
	inline void set_mTopRowFirst_4(bool value)
	{
		___mTopRowFirst_4 = value;
	}

	inline static int32_t get_offset_of_mFormat_5() { return static_cast<int32_t>(offsetof(BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028, ___mFormat_5)); }
	inline int32_t get_mFormat_5() const { return ___mFormat_5; }
	inline int32_t* get_address_of_mFormat_5() { return &___mFormat_5; }
	inline void set_mFormat_5(int32_t value)
	{
		___mFormat_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BUFFEREDFRAME_TAFC3F736E124573A402343AB673AAF8EB53E0028_H
#ifndef CALLEVENTARGS_T818567BF1A3D4FFC096A4A4018C229D78D8ECFC0_H
#define CALLEVENTARGS_T818567BF1A3D4FFC096A4A4018C229D78D8ECFC0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.CallEventArgs
struct  CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0  : public RuntimeObject
{
public:
	// Byn.Awrtc.CallEventType Byn.Awrtc.CallEventArgs::mType
	int32_t ___mType_0;

public:
	inline static int32_t get_offset_of_mType_0() { return static_cast<int32_t>(offsetof(CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0, ___mType_0)); }
	inline int32_t get_mType_0() const { return ___mType_0; }
	inline int32_t* get_address_of_mType_0() { return &___mType_0; }
	inline void set_mType_0(int32_t value)
	{
		___mType_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLEVENTARGS_T818567BF1A3D4FFC096A4A4018C229D78D8ECFC0_H
#ifndef MEDIACONFIG_T27C1D9728366F53BC7E49A1E16B020363B3A304D_H
#define MEDIACONFIG_T27C1D9728366F53BC7E49A1E16B020363B3A304D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.MediaConfig
struct  MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D  : public RuntimeObject
{
public:
	// System.Boolean Byn.Awrtc.MediaConfig::mAudio
	bool ___mAudio_0;
	// System.Boolean Byn.Awrtc.MediaConfig::mVideo
	bool ___mVideo_1;
	// System.String Byn.Awrtc.MediaConfig::mVideoDeviceName
	String_t* ___mVideoDeviceName_2;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMinWidth
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMinWidth_3;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMinHeight
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMinHeight_4;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMaxWidth
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMaxWidth_5;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMaxHeight
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMaxHeight_6;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mIdealWidth
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mIdealWidth_7;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mIdealHeight
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mIdealHeight_8;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mIdealFrameRate
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mIdealFrameRate_9;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMinFrameRate
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMinFrameRate_10;
	// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::mMaxFrameRate
	Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___mMaxFrameRate_11;
	// Byn.Awrtc.FramePixelFormat Byn.Awrtc.MediaConfig::mFormat
	int32_t ___mFormat_12;

public:
	inline static int32_t get_offset_of_mAudio_0() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mAudio_0)); }
	inline bool get_mAudio_0() const { return ___mAudio_0; }
	inline bool* get_address_of_mAudio_0() { return &___mAudio_0; }
	inline void set_mAudio_0(bool value)
	{
		___mAudio_0 = value;
	}

	inline static int32_t get_offset_of_mVideo_1() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mVideo_1)); }
	inline bool get_mVideo_1() const { return ___mVideo_1; }
	inline bool* get_address_of_mVideo_1() { return &___mVideo_1; }
	inline void set_mVideo_1(bool value)
	{
		___mVideo_1 = value;
	}

	inline static int32_t get_offset_of_mVideoDeviceName_2() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mVideoDeviceName_2)); }
	inline String_t* get_mVideoDeviceName_2() const { return ___mVideoDeviceName_2; }
	inline String_t** get_address_of_mVideoDeviceName_2() { return &___mVideoDeviceName_2; }
	inline void set_mVideoDeviceName_2(String_t* value)
	{
		___mVideoDeviceName_2 = value;
		Il2CppCodeGenWriteBarrier((&___mVideoDeviceName_2), value);
	}

	inline static int32_t get_offset_of_mMinWidth_3() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMinWidth_3)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMinWidth_3() const { return ___mMinWidth_3; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMinWidth_3() { return &___mMinWidth_3; }
	inline void set_mMinWidth_3(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMinWidth_3 = value;
	}

	inline static int32_t get_offset_of_mMinHeight_4() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMinHeight_4)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMinHeight_4() const { return ___mMinHeight_4; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMinHeight_4() { return &___mMinHeight_4; }
	inline void set_mMinHeight_4(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMinHeight_4 = value;
	}

	inline static int32_t get_offset_of_mMaxWidth_5() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMaxWidth_5)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMaxWidth_5() const { return ___mMaxWidth_5; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMaxWidth_5() { return &___mMaxWidth_5; }
	inline void set_mMaxWidth_5(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMaxWidth_5 = value;
	}

	inline static int32_t get_offset_of_mMaxHeight_6() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMaxHeight_6)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMaxHeight_6() const { return ___mMaxHeight_6; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMaxHeight_6() { return &___mMaxHeight_6; }
	inline void set_mMaxHeight_6(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMaxHeight_6 = value;
	}

	inline static int32_t get_offset_of_mIdealWidth_7() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mIdealWidth_7)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mIdealWidth_7() const { return ___mIdealWidth_7; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mIdealWidth_7() { return &___mIdealWidth_7; }
	inline void set_mIdealWidth_7(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mIdealWidth_7 = value;
	}

	inline static int32_t get_offset_of_mIdealHeight_8() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mIdealHeight_8)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mIdealHeight_8() const { return ___mIdealHeight_8; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mIdealHeight_8() { return &___mIdealHeight_8; }
	inline void set_mIdealHeight_8(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mIdealHeight_8 = value;
	}

	inline static int32_t get_offset_of_mIdealFrameRate_9() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mIdealFrameRate_9)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mIdealFrameRate_9() const { return ___mIdealFrameRate_9; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mIdealFrameRate_9() { return &___mIdealFrameRate_9; }
	inline void set_mIdealFrameRate_9(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mIdealFrameRate_9 = value;
	}

	inline static int32_t get_offset_of_mMinFrameRate_10() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMinFrameRate_10)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMinFrameRate_10() const { return ___mMinFrameRate_10; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMinFrameRate_10() { return &___mMinFrameRate_10; }
	inline void set_mMinFrameRate_10(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMinFrameRate_10 = value;
	}

	inline static int32_t get_offset_of_mMaxFrameRate_11() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mMaxFrameRate_11)); }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  get_mMaxFrameRate_11() const { return ___mMaxFrameRate_11; }
	inline Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * get_address_of_mMaxFrameRate_11() { return &___mMaxFrameRate_11; }
	inline void set_mMaxFrameRate_11(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  value)
	{
		___mMaxFrameRate_11 = value;
	}

	inline static int32_t get_offset_of_mFormat_12() { return static_cast<int32_t>(offsetof(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D, ___mFormat_12)); }
	inline int32_t get_mFormat_12() const { return ___mFormat_12; }
	inline int32_t* get_address_of_mFormat_12() { return &___mFormat_12; }
	inline void set_mFormat_12(int32_t value)
	{
		___mFormat_12 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MEDIACONFIG_T27C1D9728366F53BC7E49A1E16B020363B3A304D_H
#ifndef NETWORKEVENT_T4DD89489B65D724D8D201A81F4243CF3CF96827C_H
#define NETWORKEVENT_T4DD89489B65D724D8D201A81F4243CF3CF96827C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.NetworkEvent
struct  NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C 
{
public:
	// Byn.Awrtc.NetEventType Byn.Awrtc.NetworkEvent::type
	uint8_t ___type_0;
	// Byn.Awrtc.ConnectionId Byn.Awrtc.NetworkEvent::connectionId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___connectionId_1;
	// System.Object Byn.Awrtc.NetworkEvent::data
	RuntimeObject * ___data_2;

public:
	inline static int32_t get_offset_of_type_0() { return static_cast<int32_t>(offsetof(NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C, ___type_0)); }
	inline uint8_t get_type_0() const { return ___type_0; }
	inline uint8_t* get_address_of_type_0() { return &___type_0; }
	inline void set_type_0(uint8_t value)
	{
		___type_0 = value;
	}

	inline static int32_t get_offset_of_connectionId_1() { return static_cast<int32_t>(offsetof(NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C, ___connectionId_1)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_connectionId_1() const { return ___connectionId_1; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_connectionId_1() { return &___connectionId_1; }
	inline void set_connectionId_1(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___connectionId_1 = value;
	}

	inline static int32_t get_offset_of_data_2() { return static_cast<int32_t>(offsetof(NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C, ___data_2)); }
	inline RuntimeObject * get_data_2() const { return ___data_2; }
	inline RuntimeObject ** get_address_of_data_2() { return &___data_2; }
	inline void set_data_2(RuntimeObject * value)
	{
		___data_2 = value;
		Il2CppCodeGenWriteBarrier((&___data_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of Byn.Awrtc.NetworkEvent
struct NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshaled_pinvoke
{
	uint8_t ___type_0;
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___connectionId_1;
	Il2CppIUnknown* ___data_2;
};
// Native definition for COM marshalling of Byn.Awrtc.NetworkEvent
struct NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshaled_com
{
	uint8_t ___type_0;
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___connectionId_1;
	Il2CppIUnknown* ___data_2;
};
#endif // NETWORKEVENT_T4DD89489B65D724D8D201A81F4243CF3CF96827C_H
#ifndef ARGUMENTNULLEXCEPTION_T581DF992B1F3E0EC6EFB30CC5DC43519A79B27AD_H
#define ARGUMENTNULLEXCEPTION_T581DF992B1F3E0EC6EFB30CC5DC43519A79B27AD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ArgumentNullException
struct  ArgumentNullException_t581DF992B1F3E0EC6EFB30CC5DC43519A79B27AD  : public ArgumentException_tEDCD16F20A09ECE461C3DA766C16EDA8864057D1
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ARGUMENTNULLEXCEPTION_T581DF992B1F3E0EC6EFB30CC5DC43519A79B27AD_H
#ifndef ENUMERATOR_T0A3DDFBD2093944DC075E7C3F127251B540B3F08_H
#define ENUMERATOR_T0A3DDFBD2093944DC075E7C3F127251B540B3F08_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2_Enumerator<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork_WeakRef`1<Byn.Awrtc.LocalNetwork>>
struct  Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08 
{
public:
	// System.Collections.Generic.Dictionary`2<TKey,TValue> System.Collections.Generic.Dictionary`2_Enumerator::dictionary
	Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * ___dictionary_0;
	// System.Int32 System.Collections.Generic.Dictionary`2_Enumerator::version
	int32_t ___version_1;
	// System.Int32 System.Collections.Generic.Dictionary`2_Enumerator::index
	int32_t ___index_2;
	// System.Collections.Generic.KeyValuePair`2<TKey,TValue> System.Collections.Generic.Dictionary`2_Enumerator::current
	KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F  ___current_3;
	// System.Int32 System.Collections.Generic.Dictionary`2_Enumerator::getEnumeratorRetType
	int32_t ___getEnumeratorRetType_4;

public:
	inline static int32_t get_offset_of_dictionary_0() { return static_cast<int32_t>(offsetof(Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08, ___dictionary_0)); }
	inline Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * get_dictionary_0() const { return ___dictionary_0; }
	inline Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB ** get_address_of_dictionary_0() { return &___dictionary_0; }
	inline void set_dictionary_0(Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * value)
	{
		___dictionary_0 = value;
		Il2CppCodeGenWriteBarrier((&___dictionary_0), value);
	}

	inline static int32_t get_offset_of_version_1() { return static_cast<int32_t>(offsetof(Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08, ___version_1)); }
	inline int32_t get_version_1() const { return ___version_1; }
	inline int32_t* get_address_of_version_1() { return &___version_1; }
	inline void set_version_1(int32_t value)
	{
		___version_1 = value;
	}

	inline static int32_t get_offset_of_index_2() { return static_cast<int32_t>(offsetof(Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08, ___index_2)); }
	inline int32_t get_index_2() const { return ___index_2; }
	inline int32_t* get_address_of_index_2() { return &___index_2; }
	inline void set_index_2(int32_t value)
	{
		___index_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08, ___current_3)); }
	inline KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F  get_current_3() const { return ___current_3; }
	inline KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F  value)
	{
		___current_3 = value;
	}

	inline static int32_t get_offset_of_getEnumeratorRetType_4() { return static_cast<int32_t>(offsetof(Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08, ___getEnumeratorRetType_4)); }
	inline int32_t get_getEnumeratorRetType_4() const { return ___getEnumeratorRetType_4; }
	inline int32_t* get_address_of_getEnumeratorRetType_4() { return &___getEnumeratorRetType_4; }
	inline void set_getEnumeratorRetType_4(int32_t value)
	{
		___getEnumeratorRetType_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T0A3DDFBD2093944DC075E7C3F127251B540B3F08_H
#ifndef ENUMERATOR_T309113AB812173528AD84CA0D400763D753ED3DC_H
#define ENUMERATOR_T309113AB812173528AD84CA0D400763D753ED3DC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Collections.Generic.Dictionary`2_Enumerator<Byn.Awrtc.ConnectionId,System.Object>
struct  Enumerator_t309113AB812173528AD84CA0D400763D753ED3DC 
{
public:
	// System.Collections.Generic.Dictionary`2<TKey,TValue> System.Collections.Generic.Dictionary`2_Enumerator::dictionary
	Dictionary_2_t93B36C589E8EDDC45BBAB60515EA59C54EAEE5B0 * ___dictionary_0;
	// System.Int32 System.Collections.Generic.Dictionary`2_Enumerator::version
	int32_t ___version_1;
	// System.Int32 System.Collections.Generic.Dictionary`2_Enumerator::index
	int32_t ___index_2;
	// System.Collections.Generic.KeyValuePair`2<TKey,TValue> System.Collections.Generic.Dictionary`2_Enumerator::current
	KeyValuePair_2_t6ABB429F8FE6365218E1917CCEB1A5D558DB765C  ___current_3;
	// System.Int32 System.Collections.Generic.Dictionary`2_Enumerator::getEnumeratorRetType
	int32_t ___getEnumeratorRetType_4;

public:
	inline static int32_t get_offset_of_dictionary_0() { return static_cast<int32_t>(offsetof(Enumerator_t309113AB812173528AD84CA0D400763D753ED3DC, ___dictionary_0)); }
	inline Dictionary_2_t93B36C589E8EDDC45BBAB60515EA59C54EAEE5B0 * get_dictionary_0() const { return ___dictionary_0; }
	inline Dictionary_2_t93B36C589E8EDDC45BBAB60515EA59C54EAEE5B0 ** get_address_of_dictionary_0() { return &___dictionary_0; }
	inline void set_dictionary_0(Dictionary_2_t93B36C589E8EDDC45BBAB60515EA59C54EAEE5B0 * value)
	{
		___dictionary_0 = value;
		Il2CppCodeGenWriteBarrier((&___dictionary_0), value);
	}

	inline static int32_t get_offset_of_version_1() { return static_cast<int32_t>(offsetof(Enumerator_t309113AB812173528AD84CA0D400763D753ED3DC, ___version_1)); }
	inline int32_t get_version_1() const { return ___version_1; }
	inline int32_t* get_address_of_version_1() { return &___version_1; }
	inline void set_version_1(int32_t value)
	{
		___version_1 = value;
	}

	inline static int32_t get_offset_of_index_2() { return static_cast<int32_t>(offsetof(Enumerator_t309113AB812173528AD84CA0D400763D753ED3DC, ___index_2)); }
	inline int32_t get_index_2() const { return ___index_2; }
	inline int32_t* get_address_of_index_2() { return &___index_2; }
	inline void set_index_2(int32_t value)
	{
		___index_2 = value;
	}

	inline static int32_t get_offset_of_current_3() { return static_cast<int32_t>(offsetof(Enumerator_t309113AB812173528AD84CA0D400763D753ED3DC, ___current_3)); }
	inline KeyValuePair_2_t6ABB429F8FE6365218E1917CCEB1A5D558DB765C  get_current_3() const { return ___current_3; }
	inline KeyValuePair_2_t6ABB429F8FE6365218E1917CCEB1A5D558DB765C * get_address_of_current_3() { return &___current_3; }
	inline void set_current_3(KeyValuePair_2_t6ABB429F8FE6365218E1917CCEB1A5D558DB765C  value)
	{
		___current_3 = value;
	}

	inline static int32_t get_offset_of_getEnumeratorRetType_4() { return static_cast<int32_t>(offsetof(Enumerator_t309113AB812173528AD84CA0D400763D753ED3DC, ___getEnumeratorRetType_4)); }
	inline int32_t get_getEnumeratorRetType_4() const { return ___getEnumeratorRetType_4; }
	inline int32_t* get_address_of_getEnumeratorRetType_4() { return &___getEnumeratorRetType_4; }
	inline void set_getEnumeratorRetType_4(int32_t value)
	{
		___getEnumeratorRetType_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ENUMERATOR_T309113AB812173528AD84CA0D400763D753ED3DC_H
#ifndef MULTICASTDELEGATE_T_H
#define MULTICASTDELEGATE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MulticastDelegate
struct  MulticastDelegate_t  : public Delegate_t
{
public:
	// System.Delegate[] System.MulticastDelegate::delegates
	DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* ___delegates_11;

public:
	inline static int32_t get_offset_of_delegates_11() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___delegates_11)); }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* get_delegates_11() const { return ___delegates_11; }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86** get_address_of_delegates_11() { return &___delegates_11; }
	inline void set_delegates_11(DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* value)
	{
		___delegates_11 = value;
		Il2CppCodeGenWriteBarrier((&___delegates_11), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_pinvoke : public Delegate_t_marshaled_pinvoke
{
	Delegate_t_marshaled_pinvoke** ___delegates_11;
};
// Native definition for COM marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_com : public Delegate_t_marshaled_com
{
	Delegate_t_marshaled_com** ___delegates_11;
};
#endif // MULTICASTDELEGATE_T_H
#ifndef CALLACCEPTEDEVENTARGS_T66A1A51D65180197BBA42227E68BF517AC6503DA_H
#define CALLACCEPTEDEVENTARGS_T66A1A51D65180197BBA42227E68BF517AC6503DA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.CallAcceptedEventArgs
struct  CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA  : public CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0
{
public:
	// Byn.Awrtc.ConnectionId Byn.Awrtc.CallAcceptedEventArgs::mConnectionId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mConnectionId_1;

public:
	inline static int32_t get_offset_of_mConnectionId_1() { return static_cast<int32_t>(offsetof(CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA, ___mConnectionId_1)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mConnectionId_1() const { return ___mConnectionId_1; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mConnectionId_1() { return &___mConnectionId_1; }
	inline void set_mConnectionId_1(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mConnectionId_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLACCEPTEDEVENTARGS_T66A1A51D65180197BBA42227E68BF517AC6503DA_H
#ifndef CALLENDEDEVENTARGS_TE3A3B50FDE883A4D052920EB6073028ACFF81128_H
#define CALLENDEDEVENTARGS_TE3A3B50FDE883A4D052920EB6073028ACFF81128_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.CallEndedEventArgs
struct  CallEndedEventArgs_tE3A3B50FDE883A4D052920EB6073028ACFF81128  : public CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0
{
public:
	// Byn.Awrtc.ConnectionId Byn.Awrtc.CallEndedEventArgs::mConnectionId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mConnectionId_1;

public:
	inline static int32_t get_offset_of_mConnectionId_1() { return static_cast<int32_t>(offsetof(CallEndedEventArgs_tE3A3B50FDE883A4D052920EB6073028ACFF81128, ___mConnectionId_1)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mConnectionId_1() const { return ___mConnectionId_1; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mConnectionId_1() { return &___mConnectionId_1; }
	inline void set_mConnectionId_1(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mConnectionId_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLENDEDEVENTARGS_TE3A3B50FDE883A4D052920EB6073028ACFF81128_H
#ifndef CALLEVENTHANDLER_TC9D919E3867CEBE6B3D26923028AB6E2A713387F_H
#define CALLEVENTHANDLER_TC9D919E3867CEBE6B3D26923028AB6E2A713387F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.CallEventHandler
struct  CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLEVENTHANDLER_TC9D919E3867CEBE6B3D26923028AB6E2A713387F_H
#ifndef DATAMESSAGEEVENTARGS_TB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37_H
#define DATAMESSAGEEVENTARGS_TB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.DataMessageEventArgs
struct  DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37  : public CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0
{
public:
	// Byn.Awrtc.ConnectionId Byn.Awrtc.DataMessageEventArgs::mConnectionId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mConnectionId_1;
	// System.Byte[] Byn.Awrtc.DataMessageEventArgs::mContent
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___mContent_2;
	// System.Boolean Byn.Awrtc.DataMessageEventArgs::mReliable
	bool ___mReliable_3;

public:
	inline static int32_t get_offset_of_mConnectionId_1() { return static_cast<int32_t>(offsetof(DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37, ___mConnectionId_1)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mConnectionId_1() const { return ___mConnectionId_1; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mConnectionId_1() { return &___mConnectionId_1; }
	inline void set_mConnectionId_1(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mConnectionId_1 = value;
	}

	inline static int32_t get_offset_of_mContent_2() { return static_cast<int32_t>(offsetof(DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37, ___mContent_2)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get_mContent_2() const { return ___mContent_2; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of_mContent_2() { return &___mContent_2; }
	inline void set_mContent_2(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		___mContent_2 = value;
		Il2CppCodeGenWriteBarrier((&___mContent_2), value);
	}

	inline static int32_t get_offset_of_mReliable_3() { return static_cast<int32_t>(offsetof(DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37, ___mReliable_3)); }
	inline bool get_mReliable_3() const { return ___mReliable_3; }
	inline bool* get_address_of_mReliable_3() { return &___mReliable_3; }
	inline void set_mReliable_3(bool value)
	{
		___mReliable_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DATAMESSAGEEVENTARGS_TB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37_H
#ifndef ERROREVENTARGS_T5A287854C72ED85A9C48B9F18F88C56475C02246_H
#define ERROREVENTARGS_T5A287854C72ED85A9C48B9F18F88C56475C02246_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.ErrorEventArgs
struct  ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246  : public CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0
{
public:
	// Byn.Awrtc.ErrorInfo Byn.Awrtc.ErrorEventArgs::mErrorInfo
	ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * ___mErrorInfo_1;

public:
	inline static int32_t get_offset_of_mErrorInfo_1() { return static_cast<int32_t>(offsetof(ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246, ___mErrorInfo_1)); }
	inline ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * get_mErrorInfo_1() const { return ___mErrorInfo_1; }
	inline ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 ** get_address_of_mErrorInfo_1() { return &___mErrorInfo_1; }
	inline void set_mErrorInfo_1(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * value)
	{
		___mErrorInfo_1 = value;
		Il2CppCodeGenWriteBarrier((&___mErrorInfo_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ERROREVENTARGS_T5A287854C72ED85A9C48B9F18F88C56475C02246_H
#ifndef FRAMEUPDATEEVENTARGS_T634A4325664A8B135DEB37E87967686C9690DE6C_H
#define FRAMEUPDATEEVENTARGS_T634A4325664A8B135DEB37E87967686C9690DE6C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.FrameUpdateEventArgs
struct  FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C  : public CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0
{
public:
	// Byn.Awrtc.FramePixelFormat Byn.Awrtc.FrameUpdateEventArgs::mFormat
	int32_t ___mFormat_1;
	// Byn.Awrtc.ConnectionId Byn.Awrtc.FrameUpdateEventArgs::mConnectionId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mConnectionId_2;
	// Byn.Awrtc.IFrame Byn.Awrtc.FrameUpdateEventArgs::mFrame
	RuntimeObject* ___mFrame_3;

public:
	inline static int32_t get_offset_of_mFormat_1() { return static_cast<int32_t>(offsetof(FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C, ___mFormat_1)); }
	inline int32_t get_mFormat_1() const { return ___mFormat_1; }
	inline int32_t* get_address_of_mFormat_1() { return &___mFormat_1; }
	inline void set_mFormat_1(int32_t value)
	{
		___mFormat_1 = value;
	}

	inline static int32_t get_offset_of_mConnectionId_2() { return static_cast<int32_t>(offsetof(FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C, ___mConnectionId_2)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mConnectionId_2() const { return ___mConnectionId_2; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mConnectionId_2() { return &___mConnectionId_2; }
	inline void set_mConnectionId_2(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mConnectionId_2 = value;
	}

	inline static int32_t get_offset_of_mFrame_3() { return static_cast<int32_t>(offsetof(FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C, ___mFrame_3)); }
	inline RuntimeObject* get_mFrame_3() const { return ___mFrame_3; }
	inline RuntimeObject** get_address_of_mFrame_3() { return &___mFrame_3; }
	inline void set_mFrame_3(RuntimeObject* value)
	{
		___mFrame_3 = value;
		Il2CppCodeGenWriteBarrier((&___mFrame_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FRAMEUPDATEEVENTARGS_T634A4325664A8B135DEB37E87967686C9690DE6C_H
#ifndef MESSAGEEVENTARGS_TB3C1E5D169AD3A3A277DADD79A5F098F53040899_H
#define MESSAGEEVENTARGS_TB3C1E5D169AD3A3A277DADD79A5F098F53040899_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.MessageEventArgs
struct  MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899  : public CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0
{
public:
	// Byn.Awrtc.ConnectionId Byn.Awrtc.MessageEventArgs::mConnectionId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mConnectionId_1;
	// System.Boolean Byn.Awrtc.MessageEventArgs::mReliable
	bool ___mReliable_2;
	// System.String Byn.Awrtc.MessageEventArgs::mContent
	String_t* ___mContent_3;

public:
	inline static int32_t get_offset_of_mConnectionId_1() { return static_cast<int32_t>(offsetof(MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899, ___mConnectionId_1)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mConnectionId_1() const { return ___mConnectionId_1; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mConnectionId_1() { return &___mConnectionId_1; }
	inline void set_mConnectionId_1(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mConnectionId_1 = value;
	}

	inline static int32_t get_offset_of_mReliable_2() { return static_cast<int32_t>(offsetof(MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899, ___mReliable_2)); }
	inline bool get_mReliable_2() const { return ___mReliable_2; }
	inline bool* get_address_of_mReliable_2() { return &___mReliable_2; }
	inline void set_mReliable_2(bool value)
	{
		___mReliable_2 = value;
	}

	inline static int32_t get_offset_of_mContent_3() { return static_cast<int32_t>(offsetof(MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899, ___mContent_3)); }
	inline String_t* get_mContent_3() const { return ___mContent_3; }
	inline String_t** get_address_of_mContent_3() { return &___mContent_3; }
	inline void set_mContent_3(String_t* value)
	{
		___mContent_3 = value;
		Il2CppCodeGenWriteBarrier((&___mContent_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MESSAGEEVENTARGS_TB3C1E5D169AD3A3A277DADD79A5F098F53040899_H
#ifndef WAITFORINCOMINGCALLEVENTARGS_TD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86_H
#define WAITFORINCOMINGCALLEVENTARGS_TD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.WaitForIncomingCallEventArgs
struct  WaitForIncomingCallEventArgs_tD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86  : public CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0
{
public:
	// System.String Byn.Awrtc.WaitForIncomingCallEventArgs::mAddress
	String_t* ___mAddress_1;

public:
	inline static int32_t get_offset_of_mAddress_1() { return static_cast<int32_t>(offsetof(WaitForIncomingCallEventArgs_tD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86, ___mAddress_1)); }
	inline String_t* get_mAddress_1() const { return ___mAddress_1; }
	inline String_t** get_address_of_mAddress_1() { return &___mAddress_1; }
	inline void set_mAddress_1(String_t* value)
	{
		___mAddress_1 = value;
		Il2CppCodeGenWriteBarrier((&___mAddress_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WAITFORINCOMINGCALLEVENTARGS_TD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86_H
#ifndef ACTION_2_TB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944_H
#define ACTION_2_TB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Action`2<System.Object,System.String[]>
struct  Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ACTION_2_TB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944_H
#ifndef ASYNCCALLBACK_T3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4_H
#define ASYNCCALLBACK_T3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.AsyncCallback
struct  AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ASYNCCALLBACK_T3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4_H
// System.String[]
struct StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) String_t* m_Items[1];

public:
	inline String_t* GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline String_t** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, String_t* value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
	inline String_t* GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline String_t** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, String_t* value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
};
// System.Byte[]
struct ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) uint8_t m_Items[1];

public:
	inline uint8_t GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline uint8_t* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, uint8_t value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline uint8_t GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline uint8_t* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, uint8_t value)
	{
		m_Items[index] = value;
	}
};
// System.Collections.Generic.List`1<Byn.Awrtc.ByteArrayBuffer>[]
struct List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * m_Items[1];

public:
	inline List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline List_1_t43B2D37CF48E04673A48558029581722DDF26F4E ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
	inline List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline List_1_t43B2D37CF48E04673A48558029581722DDF26F4E ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
};
// System.Int32[]
struct Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) int32_t m_Items[1];

public:
	inline int32_t GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline int32_t* GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, int32_t value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
	}
	inline int32_t GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline int32_t* GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, int32_t value)
	{
		m_Items[index] = value;
	}
};
// System.Delegate[]
struct DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86  : public RuntimeArray
{
public:
	ALIGN_FIELD (8) Delegate_t * m_Items[1];

public:
	inline Delegate_t * GetAt(il2cpp_array_size_t index) const
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items[index];
	}
	inline Delegate_t ** GetAddressAt(il2cpp_array_size_t index)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		return m_Items + index;
	}
	inline void SetAt(il2cpp_array_size_t index, Delegate_t * value)
	{
		IL2CPP_ARRAY_BOUNDS_CHECK(index, (uint32_t)(this)->max_length);
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
	inline Delegate_t * GetAtUnchecked(il2cpp_array_size_t index) const
	{
		return m_Items[index];
	}
	inline Delegate_t ** GetAddressAtUnchecked(il2cpp_array_size_t index)
	{
		return m_Items + index;
	}
	inline void SetAtUnchecked(il2cpp_array_size_t index, Delegate_t * value)
	{
		m_Items[index] = value;
		Il2CppCodeGenWriteBarrier(m_Items + index, value);
	}
};


// System.Void System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>::.ctor()
extern "C" IL2CPP_METHOD_ATTR void List_1__ctor_m348481CF5AD96E81E9F71B9B4052944396A6BB67_gshared (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * __this, const RuntimeMethod* method);
// System.Collections.Generic.List`1/Enumerator<!0> System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>::GetEnumerator()
extern "C" IL2CPP_METHOD_ATTR Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17  List_1_GetEnumerator_m72711B857C13554E60D06AE2C418B4FA59870E65_gshared (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1/Enumerator<Byn.Awrtc.ConnectionId>::get_Current()
extern "C" IL2CPP_METHOD_ATTR ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  Enumerator_get_Current_m0203034B79126F512CC77691D03434942FE5EE6C_gshared (Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.List`1/Enumerator<Byn.Awrtc.ConnectionId>::MoveNext()
extern "C" IL2CPP_METHOD_ATTR bool Enumerator_MoveNext_m50BD3D91B026FC120054CB6B187B49A57689E4E7_gshared (Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1/Enumerator<Byn.Awrtc.ConnectionId>::Dispose()
extern "C" IL2CPP_METHOD_ATTR void Enumerator_Dispose_m62E14E84F0EFE2CD8FC246C3779797583ED04D49_gshared (Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>::Add(!0)
extern "C" IL2CPP_METHOD_ATTR void List_1_Add_mABE9CD5133D0735C8ECB22FAC67B02137BDCD6EA_gshared (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  p0, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>::Contains(!0)
extern "C" IL2CPP_METHOD_ATTR bool List_1_Contains_m337011847BDC37E80915E17BAFEB39C2F5FBD448_gshared (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  p0, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>::Remove(!0)
extern "C" IL2CPP_METHOD_ATTR bool List_1_Remove_mEB90299243C7D65EFFEC681D18CA1492DBA9A3A2_gshared (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  p0, const RuntimeMethod* method);
// System.Int32 System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>::get_Count()
extern "C" IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m230B26A74F4411232759D13CD642C9B4FE621AD5_gshared (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Object>::.ctor()
extern "C" IL2CPP_METHOD_ATTR void List_1__ctor_mC832F1AC0F814BAEB19175F5D7972A7507508BC3_gshared (List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D * __this, const RuntimeMethod* method);
// System.Int32 System.Collections.Generic.List`1<System.Object>::get_Count()
extern "C" IL2CPP_METHOD_ATTR int32_t List_1_get_Count_m507C9149FF7F83AAC72C29091E745D557DA47D22_gshared (List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1<System.Object>::get_Item(System.Int32)
extern "C" IL2CPP_METHOD_ATTR RuntimeObject * List_1_get_Item_mFDB8AD680C600072736579BBF5F38F7416396588_gshared (List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D * __this, int32_t p0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Object>::RemoveAt(System.Int32)
extern "C" IL2CPP_METHOD_ATTR void List_1_RemoveAt_m1EC5117AD814B97460F8F95D49A428032FE37CBF_gshared (List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D * __this, int32_t p0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Object>::Add(!0)
extern "C" IL2CPP_METHOD_ATTR void List_1_Add_m6930161974C7504C80F52EC379EF012387D43138_gshared (List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D * __this, RuntimeObject * p0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.Object>::.ctor(System.Collections.Generic.IEnumerable`1<!0>)
extern "C" IL2CPP_METHOD_ATTR void List_1__ctor_m6E336459937EBBC514F001464CC3771240EEBB87_gshared (List_1_t05CC3C859AB5E6024394EF9A42E3E696628CA02D * __this, RuntimeObject* p0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent>::.ctor()
extern "C" IL2CPP_METHOD_ATTR void Queue_1__ctor_m207784283861C71375B6A150AA6E6CD3CE6E1ECE_gshared (Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,System.Object>::.ctor()
extern "C" IL2CPP_METHOD_ATTR void Dictionary_2__ctor_m01B5E2D22EAEFF051DC823DAEFE8BB7A7BF42B66_gshared (Dictionary_2_t93B36C589E8EDDC45BBAB60515EA59C54EAEE5B0 * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.Dictionary`2<System.Object,System.Object>::ContainsKey(!0)
extern "C" IL2CPP_METHOD_ATTR bool Dictionary_2_ContainsKey_m4EBC00E16E83DA33851A551757D2B7332D5756B9_gshared (Dictionary_2_t32F25F093828AA9F93CB11C2A2B4648FD62A09BA * __this, RuntimeObject * p0, const RuntimeMethod* method);
// !1 System.Collections.Generic.Dictionary`2<System.Object,System.Object>::get_Item(!0)
extern "C" IL2CPP_METHOD_ATTR RuntimeObject * Dictionary_2_get_Item_m6625C3BA931A6EE5D6DB46B9E743B40AAA30010B_gshared (Dictionary_2_t32F25F093828AA9F93CB11C2A2B4648FD62A09BA * __this, RuntimeObject * p0, const RuntimeMethod* method);
// T Byn.Awrtc.LocalNetwork/WeakRef`1<System.Object>::Get()
extern "C" IL2CPP_METHOD_ATTR RuntimeObject * WeakRef_1_Get_m738D2DAA1C1006A6D26BB0681E111854DC430F13_gshared (WeakRef_1_tB639BA5FF05FD4ED10233CC43A667DD2FC343F09 * __this, const RuntimeMethod* method);
// System.Void Byn.Awrtc.LocalNetwork/WeakRef`1<System.Object>::.ctor(T)
extern "C" IL2CPP_METHOD_ATTR void WeakRef_1__ctor_m762796C00E88972EA95467285E97DC0BAA7BEE70_gshared (WeakRef_1_tB639BA5FF05FD4ED10233CC43A667DD2FC343F09 * __this, RuntimeObject * p0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.Object,System.Object>::set_Item(!0,!1)
extern "C" IL2CPP_METHOD_ATTR void Dictionary_2_set_Item_m466D001F105E25DEB5C9BCB17837EE92A27FDE93_gshared (Dictionary_2_t32F25F093828AA9F93CB11C2A2B4648FD62A09BA * __this, RuntimeObject * p0, RuntimeObject * p1, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.Dictionary`2<System.Object,System.Object>::Remove(!0)
extern "C" IL2CPP_METHOD_ATTR bool Dictionary_2_Remove_m0FCCD33CE2C6A7589E52A2AB0872FE361BF5EF60_gshared (Dictionary_2_t32F25F093828AA9F93CB11C2A2B4648FD62A09BA * __this, RuntimeObject * p0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,System.Object>::set_Item(!0,!1)
extern "C" IL2CPP_METHOD_ATTR void Dictionary_2_set_Item_m136374B622A2C65387A3BBCC12E056FF2AECCCE9_gshared (Dictionary_2_t93B36C589E8EDDC45BBAB60515EA59C54EAEE5B0 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  p0, RuntimeObject * p1, const RuntimeMethod* method);
// System.Collections.Generic.Dictionary`2/KeyCollection<!0,!1> System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,System.Object>::get_Keys()
extern "C" IL2CPP_METHOD_ATTR KeyCollection_tC2B692E517123E3B3A679254DD7F6C108A3D378F * Dictionary_2_get_Keys_m2555A4127C8B5405BE9781504D955F569B35A145_gshared (Dictionary_2_t93B36C589E8EDDC45BBAB60515EA59C54EAEE5B0 * __this, const RuntimeMethod* method);
// System.Collections.Generic.List`1<!!0> System.Linq.Enumerable::ToList<Byn.Awrtc.ConnectionId>(System.Collections.Generic.IEnumerable`1<!!0>)
extern "C" IL2CPP_METHOD_ATTR List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * Enumerable_ToList_TisConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_m993BAFA400E4493769271824E19E78B7023A85C5_gshared (RuntimeObject* p0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,System.Object>::Clear()
extern "C" IL2CPP_METHOD_ATTR void Dictionary_2_Clear_mD4048B3B9DFFD0C42A38E8B581B61E9032DB2CBA_gshared (Dictionary_2_t93B36C589E8EDDC45BBAB60515EA59C54EAEE5B0 * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,System.Object>::TryGetValue(!0,!1&)
extern "C" IL2CPP_METHOD_ATTR bool Dictionary_2_TryGetValue_m309A5E421E73F52CE143DFC5A8D229794B64FEE8_gshared (Dictionary_2_t93B36C589E8EDDC45BBAB60515EA59C54EAEE5B0 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  p0, RuntimeObject ** p1, const RuntimeMethod* method);
// !1 System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,System.Object>::get_Item(!0)
extern "C" IL2CPP_METHOD_ATTR RuntimeObject * Dictionary_2_get_Item_mFB8D7880A02C63F93A48BC0EE33E97BBAE5909BC_gshared (Dictionary_2_t93B36C589E8EDDC45BBAB60515EA59C54EAEE5B0 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  p0, const RuntimeMethod* method);
// System.Int32 System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent>::get_Count()
extern "C" IL2CPP_METHOD_ATTR int32_t Queue_1_get_Count_mB49A946DB72811EC8C21C704B0973456642963CB_gshared (Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent>::Dequeue()
extern "C" IL2CPP_METHOD_ATTR NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  Queue_1_Dequeue_m2D5C4E39A011B35CD6218B0FA62B5CB0D962F535_gshared (Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,System.Object>::ContainsKey(!0)
extern "C" IL2CPP_METHOD_ATTR bool Dictionary_2_ContainsKey_m9EC8F6E9702BBE5A8E89D550CF8604D8DB3B6CAE_gshared (Dictionary_2_t93B36C589E8EDDC45BBAB60515EA59C54EAEE5B0 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  p0, const RuntimeMethod* method);
// System.Collections.Generic.Dictionary`2/Enumerator<!0,!1> System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,System.Object>::GetEnumerator()
extern "C" IL2CPP_METHOD_ATTR Enumerator_t309113AB812173528AD84CA0D400763D753ED3DC  Dictionary_2_GetEnumerator_m31B30ACC437E612A3217BC362A1445E066298B36_gshared (Dictionary_2_t93B36C589E8EDDC45BBAB60515EA59C54EAEE5B0 * __this, const RuntimeMethod* method);
// System.Collections.Generic.KeyValuePair`2<!0,!1> System.Collections.Generic.Dictionary`2/Enumerator<Byn.Awrtc.ConnectionId,System.Object>::get_Current()
extern "C" IL2CPP_METHOD_ATTR KeyValuePair_2_t6ABB429F8FE6365218E1917CCEB1A5D558DB765C  Enumerator_get_Current_mF4B56BBD84EE5ACB740F1C20A701CF564CA3CFC5_gshared (Enumerator_t309113AB812173528AD84CA0D400763D753ED3DC * __this, const RuntimeMethod* method);
// !1 System.Collections.Generic.KeyValuePair`2<Byn.Awrtc.ConnectionId,System.Object>::get_Value()
extern "C" IL2CPP_METHOD_ATTR RuntimeObject * KeyValuePair_2_get_Value_mC7CC4041D9D3597380113C401DD96D6B707A5F4C_gshared (KeyValuePair_2_t6ABB429F8FE6365218E1917CCEB1A5D558DB765C * __this, const RuntimeMethod* method);
// !0 System.Collections.Generic.KeyValuePair`2<Byn.Awrtc.ConnectionId,System.Object>::get_Key()
extern "C" IL2CPP_METHOD_ATTR ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  KeyValuePair_2_get_Key_m6CB23A7ECB174417B465910AFF36CC3EDE0E390D_gshared (KeyValuePair_2_t6ABB429F8FE6365218E1917CCEB1A5D558DB765C * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.Dictionary`2/Enumerator<Byn.Awrtc.ConnectionId,System.Object>::MoveNext()
extern "C" IL2CPP_METHOD_ATTR bool Enumerator_MoveNext_m81EB8EB6A17F38BD4B47EA76A0045CEDFB6BA487_gshared (Enumerator_t309113AB812173528AD84CA0D400763D753ED3DC * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2/Enumerator<Byn.Awrtc.ConnectionId,System.Object>::Dispose()
extern "C" IL2CPP_METHOD_ATTR void Enumerator_Dispose_mF9014EC4B020E606DEE69E250A684AA25494AA8B_gshared (Enumerator_t309113AB812173528AD84CA0D400763D753ED3DC * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent>::Enqueue(!0)
extern "C" IL2CPP_METHOD_ATTR void Queue_1_Enqueue_m4EABC517D5EF21AD49565B814AEBA980EEC805DB_gshared (Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * __this, NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  p0, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,System.Object>::Remove(!0)
extern "C" IL2CPP_METHOD_ATTR bool Dictionary_2_Remove_m684CF8258FAC4B76A293397A5561D28402E51F33_gshared (Dictionary_2_t93B36C589E8EDDC45BBAB60515EA59C54EAEE5B0 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  p0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.Object,System.Object>::.ctor()
extern "C" IL2CPP_METHOD_ATTR void Dictionary_2__ctor_m2C7E51568033239B506E15E7804A0B8658246498_gshared (Dictionary_2_t32F25F093828AA9F93CB11C2A2B4648FD62A09BA * __this, const RuntimeMethod* method);
// System.Void System.Nullable`1<System.Int32>::.ctor(!0)
extern "C" IL2CPP_METHOD_ATTR void Nullable_1__ctor_m11F9C228CFDF836DDFCD7880C09CB4098AB9D7F2_gshared (Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * __this, int32_t p0, const RuntimeMethod* method);
// System.Void System.Array::Resize<System.Object>(!!0[]&,System.Int32)
extern "C" IL2CPP_METHOD_ATTR void Array_Resize_TisRuntimeObject_m867A1BD65D179315E1C238CBD162DD91D0F362CC_gshared (ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A** p0, int32_t p1, const RuntimeMethod* method);
// System.Void System.Action`2<System.Object,System.Object>::Invoke(!0,!1)
extern "C" IL2CPP_METHOD_ATTR void Action_2_Invoke_m1738FFAE74BE5E599FD42520FA2BEF69D1AC4709_gshared (Action_2_t0DB6FD6F515527EAB552B690A291778C6F00D48C * __this, RuntimeObject * p0, RuntimeObject * p1, const RuntimeMethod* method);

// System.Delegate System.Delegate::Combine(System.Delegate,System.Delegate)
extern "C" IL2CPP_METHOD_ATTR Delegate_t * Delegate_Combine_mC25D2F7DECAFBA6D9A2F9EBA8A77063F0658ECF1 (Delegate_t * p0, Delegate_t * p1, const RuntimeMethod* method);
// System.Delegate System.Delegate::Remove(System.Delegate,System.Delegate)
extern "C" IL2CPP_METHOD_ATTR Delegate_t * Delegate_Remove_m0B0DB7D1B3AF96B71AFAA72BA0EFE32FBBC2932D (Delegate_t * p0, Delegate_t * p1, const RuntimeMethod* method);
// System.Void Byn.Awrtc.NetworkConfig::.ctor()
extern "C" IL2CPP_METHOD_ATTR void NetworkConfig__ctor_m602D7088B4491C0C9438A2316195FAA7F1C0E5F4 (NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>::.ctor()
inline void List_1__ctor_m348481CF5AD96E81E9F71B9B4052944396A6BB67 (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 *, const RuntimeMethod*))List_1__ctor_m348481CF5AD96E81E9F71B9B4052944396A6BB67_gshared)(__this, method);
}
// System.Void System.Object::.ctor()
extern "C" IL2CPP_METHOD_ATTR void Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0 (RuntimeObject * __this, const RuntimeMethod* method);
// System.Boolean Byn.Awrtc.NetworkConfig::get_IsConference()
extern "C" IL2CPP_METHOD_ATTR bool NetworkConfig_get_IsConference_mFACBDD257AE18F00F8BED9B4325AF4956FA857D4 (NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * __this, const RuntimeMethod* method);
// System.Boolean Byn.Awrtc.NetworkConfig::get_AllowRenegotiation()
extern "C" IL2CPP_METHOD_ATTR bool NetworkConfig_get_AllowRenegotiation_m053139CFE0705A02E35D62A572F3ED7A5807E94E (NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * __this, const RuntimeMethod* method);
// System.Void Byn.Awrtc.SLog::LW(System.Object,System.String[])
extern "C" IL2CPP_METHOD_ATTR void SLog_LW_m4C1FD9091E37D07F12DFBDCE665962B60B7F2DE5 (RuntimeObject * ___msg0, StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___tags1, const RuntimeMethod* method);
// System.Void System.ArgumentNullException::.ctor(System.String)
extern "C" IL2CPP_METHOD_ATTR void ArgumentNullException__ctor_mEE0C0D6FCB2D08CD7967DBB1329A0854BBED49ED (ArgumentNullException_t581DF992B1F3E0EC6EFB30CC5DC43519A79B27AD * __this, String_t* p0, const RuntimeMethod* method);
// System.Void Byn.Awrtc.Base.AWebRtcCall::CheckDisposed()
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_CheckDisposed_mD7EE6F33F9906A26C6CB83B0D103F50D9542F90B (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, const RuntimeMethod* method);
// System.String System.String::Concat(System.Object,System.Object)
extern "C" IL2CPP_METHOD_ATTR String_t* String_Concat_mBB19C73816BDD1C3519F248E1ADC8E11A6FDB495 (RuntimeObject * p0, RuntimeObject * p1, const RuntimeMethod* method);
// System.Void System.InvalidOperationException::.ctor(System.String)
extern "C" IL2CPP_METHOD_ATTR void InvalidOperationException__ctor_m72027D5F1D513C25C05137E203EEED8FD8297706 (InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 * __this, String_t* p0, const RuntimeMethod* method);
// System.Void Byn.Awrtc.SLog::L(System.Object,System.String[])
extern "C" IL2CPP_METHOD_ATTR void SLog_L_m2B84D1BE41D8BA16E73F6E952C5C17D7D2B686A1 (RuntimeObject * ___msg0, StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___tags1, const RuntimeMethod* method);
// System.String System.String::Concat(System.String,System.String)
extern "C" IL2CPP_METHOD_ATTR String_t* String_Concat_mB78D0094592718DA6D5DB6C712A9C225631666BE (String_t* p0, String_t* p1, const RuntimeMethod* method);
// System.Void Byn.Awrtc.Base.AWebRtcCall::EnsureConfiguration()
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_EnsureConfiguration_mAE816DED202FC4344ECF0EFE83E886024340C82C (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, const RuntimeMethod* method);
// System.Void Byn.Awrtc.Base.AWebRtcCall::ProcessCall(System.String)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_ProcessCall_mB92C63DDC4A918A067FBC9B8AF077513BCE9D422 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, String_t* ___address0, const RuntimeMethod* method);
// System.Void Byn.Awrtc.Base.AWebRtcCall::PendingCall(System.String)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_PendingCall_mEBF56D08C2A943272DB3DC82DEC2EFC06A628EE0 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, String_t* ___address0, const RuntimeMethod* method);
// System.String System.String::Concat(System.Object,System.Object,System.Object)
extern "C" IL2CPP_METHOD_ATTR String_t* String_Concat_m2E1F71C491D2429CC80A28745488FEA947BB7AAC (RuntimeObject * p0, RuntimeObject * p1, RuntimeObject * p2, const RuntimeMethod* method);
// System.Void Byn.Awrtc.Base.AWebRtcCall::ProcessListen(System.String)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_ProcessListen_m753AF5E46F70C7EC3F1E425CA13C514A77A3954B (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, String_t* ___address0, const RuntimeMethod* method);
// System.Void Byn.Awrtc.Base.AWebRtcCall::PendingListen(System.String)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_PendingListen_m9CDA2D2ACE32708C21229DD92B30A0F98A35EF40 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, String_t* ___address0, const RuntimeMethod* method);
// System.Void Byn.Awrtc.Base.AWebRtcCall::Send(System.String,System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_Send_mD6438A63F1C799D469A9822AD033768311D9EBA9 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, String_t* ___message0, bool ___reliable1, const RuntimeMethod* method);
// System.Byte[] Byn.Awrtc.Base.AWebRtcCall::PackStringMsg(System.String)
extern "C" IL2CPP_METHOD_ATTR ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* AWebRtcCall_PackStringMsg_m80338D0EE5DE8E91F2D4510DC604A3652B4A5663 (String_t* ___message0, const RuntimeMethod* method);
// System.Collections.Generic.List`1/Enumerator<!0> System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>::GetEnumerator()
inline Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17  List_1_GetEnumerator_m72711B857C13554E60D06AE2C418B4FA59870E65 (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * __this, const RuntimeMethod* method)
{
	return ((  Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17  (*) (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 *, const RuntimeMethod*))List_1_GetEnumerator_m72711B857C13554E60D06AE2C418B4FA59870E65_gshared)(__this, method);
}
// !0 System.Collections.Generic.List`1/Enumerator<Byn.Awrtc.ConnectionId>::get_Current()
inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  Enumerator_get_Current_m0203034B79126F512CC77691D03434942FE5EE6C (Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 * __this, const RuntimeMethod* method)
{
	return ((  ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  (*) (Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 *, const RuntimeMethod*))Enumerator_get_Current_m0203034B79126F512CC77691D03434942FE5EE6C_gshared)(__this, method);
}
// System.Boolean System.Collections.Generic.List`1/Enumerator<Byn.Awrtc.ConnectionId>::MoveNext()
inline bool Enumerator_MoveNext_m50BD3D91B026FC120054CB6B187B49A57689E4E7 (Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 *, const RuntimeMethod*))Enumerator_MoveNext_m50BD3D91B026FC120054CB6B187B49A57689E4E7_gshared)(__this, method);
}
// System.Void System.Collections.Generic.List`1/Enumerator<Byn.Awrtc.ConnectionId>::Dispose()
inline void Enumerator_Dispose_m62E14E84F0EFE2CD8FC246C3779797583ED04D49 (Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 * __this, const RuntimeMethod* method)
{
	((  void (*) (Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 *, const RuntimeMethod*))Enumerator_Dispose_m62E14E84F0EFE2CD8FC246C3779797583ED04D49_gshared)(__this, method);
}
// System.Text.Encoding System.Text.Encoding::get_Unicode()
extern "C" IL2CPP_METHOD_ATTR Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * Encoding_get_Unicode_m86CC470F70F9BB52DDB26721F0C0D6EDAFC318AA (const RuntimeMethod* method);
// System.Int32 System.String::get_Length()
extern "C" IL2CPP_METHOD_ATTR int32_t String_get_Length_mD48C8A16A5CF1914F330DCE82D9BE15C3BEDD018 (String_t* __this, const RuntimeMethod* method);
// System.Boolean Byn.Awrtc.Base.AWebRtcCall::IsStringMsg(System.Byte[])
extern "C" IL2CPP_METHOD_ATTR bool AWebRtcCall_IsStringMsg_m7F45CD2616184B9739365F17F027461489F20882 (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___data0, const RuntimeMethod* method);
// System.Void System.ArgumentException::.ctor(System.String)
extern "C" IL2CPP_METHOD_ATTR void ArgumentException__ctor_m9A85EF7FEFEC21DDD525A67E831D77278E5165B7 (ArgumentException_tEDCD16F20A09ECE461C3DA766C16EDA8864057D1 * __this, String_t* p0, const RuntimeMethod* method);
// System.Void Byn.Awrtc.Base.AWebRtcCall::OnConfigurationFailed(System.String)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_OnConfigurationFailed_mCF1E7B2727703A3A0232C3528F5E3C1B766F0E8D (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, String_t* ___error0, const RuntimeMethod* method);
// System.Void Byn.Awrtc.Base.AWebRtcCall::OnConfigurationComplete()
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_OnConfigurationComplete_mF6BED2C9B6EEF93AE305B540A32234F734B8016E (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, const RuntimeMethod* method);
// System.Void Byn.Awrtc.FrameUpdateEventArgs::.ctor(Byn.Awrtc.ConnectionId,Byn.Awrtc.IFrame)
extern "C" IL2CPP_METHOD_ATTR void FrameUpdateEventArgs__ctor_mA0D47D896195E97BBE9FEB1BF9EE2CAABC8F53E4 (FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___conId0, RuntimeObject* ___frame1, const RuntimeMethod* method);
// System.Void Byn.Awrtc.Base.AWebRtcCall::TriggerCallEvent(Byn.Awrtc.CallEventArgs)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * ___args0, const RuntimeMethod* method);
// Byn.Awrtc.NetEventType Byn.Awrtc.NetworkEvent::get_Type()
extern "C" IL2CPP_METHOD_ATTR uint8_t NetworkEvent_get_Type_m90AD2D28598E4CB47CC71E363D104C8AC7A705C5 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, const RuntimeMethod* method);
// Byn.Awrtc.ConnectionId Byn.Awrtc.NetworkEvent::get_ConnectionId()
extern "C" IL2CPP_METHOD_ATTR ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  NetworkEvent_get_ConnectionId_m63ED1FC3B26ED68918F1395BA9D0EAF1306F2524 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>::Add(!0)
inline void List_1_Add_mABE9CD5133D0735C8ECB22FAC67B02137BDCD6EA (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  p0, const RuntimeMethod* method)
{
	((  void (*) (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 *, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D , const RuntimeMethod*))List_1_Add_mABE9CD5133D0735C8ECB22FAC67B02137BDCD6EA_gshared)(__this, p0, method);
}
// System.Void Byn.Awrtc.CallAcceptedEventArgs::.ctor(Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR void CallAcceptedEventArgs__ctor_m313593CBB34D49EC5E4A3F90FB0EB0069E4C1C9A (CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___connectionId0, const RuntimeMethod* method);
// Byn.Awrtc.ErrorInfo Byn.Awrtc.NetworkEvent::get_ErrorInfo()
extern "C" IL2CPP_METHOD_ATTR ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * NetworkEvent_get_ErrorInfo_m8AEF4E79F149ACDE34B56754A88ADA709AAD8D95 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, const RuntimeMethod* method);
// System.Void Byn.Awrtc.ErrorEventArgs::.ctor(Byn.Awrtc.CallEventType,Byn.Awrtc.ErrorInfo)
extern "C" IL2CPP_METHOD_ATTR void ErrorEventArgs__ctor_m8BEABC103A358B03A2FF9F9D546B443FF579F366 (ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246 * __this, int32_t ___eventType0, ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * ___errorInfo1, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>::Contains(!0)
inline bool List_1_Contains_m337011847BDC37E80915E17BAFEB39C2F5FBD448 (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  p0, const RuntimeMethod* method)
{
	return ((  bool (*) (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 *, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D , const RuntimeMethod*))List_1_Contains_m337011847BDC37E80915E17BAFEB39C2F5FBD448_gshared)(__this, p0, method);
}
// System.Boolean System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>::Remove(!0)
inline bool List_1_Remove_mEB90299243C7D65EFFEC681D18CA1492DBA9A3A2 (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  p0, const RuntimeMethod* method)
{
	return ((  bool (*) (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 *, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D , const RuntimeMethod*))List_1_Remove_mEB90299243C7D65EFFEC681D18CA1492DBA9A3A2_gshared)(__this, p0, method);
}
// System.Int32 System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>::get_Count()
inline int32_t List_1_get_Count_m230B26A74F4411232759D13CD642C9B4FE621AD5 (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 *, const RuntimeMethod*))List_1_get_Count_m230B26A74F4411232759D13CD642C9B4FE621AD5_gshared)(__this, method);
}
// System.Void Byn.Awrtc.CallEndedEventArgs::.ctor(Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR void CallEndedEventArgs__ctor_m5C66FFEB0C34E59EB177FBDF82759A1F235ABE74 (CallEndedEventArgs_tE3A3B50FDE883A4D052920EB6073028ACFF81128 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___connectionId0, const RuntimeMethod* method);
// System.String Byn.Awrtc.NetworkEvent::get_Info()
extern "C" IL2CPP_METHOD_ATTR String_t* NetworkEvent_get_Info_mA98458FF9FA0B252D18705DD6B1A3B17D9503E16 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, const RuntimeMethod* method);
// System.Void Byn.Awrtc.WaitForIncomingCallEventArgs::.ctor(System.String)
extern "C" IL2CPP_METHOD_ATTR void WaitForIncomingCallEventArgs__ctor_m8A615252C226AD8065E43B233EA90820188AEE22 (WaitForIncomingCallEventArgs_tD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86 * __this, String_t* ___address0, const RuntimeMethod* method);
// Byn.Awrtc.MessageDataBuffer Byn.Awrtc.NetworkEvent::get_MessageData()
extern "C" IL2CPP_METHOD_ATTR RuntimeObject* NetworkEvent_get_MessageData_m4E9F1B0D89F50E350EF0262187C7DE74ADCEED26 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, const RuntimeMethod* method);
// System.Byte[] Byn.Awrtc.MessageDataBufferExt::Copy(Byn.Awrtc.MessageDataBuffer)
extern "C" IL2CPP_METHOD_ATTR ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* MessageDataBufferExt_Copy_mA35B174D17F81FB2AB25399BDD5325CA8326E210 (RuntimeObject* ___buffer0, const RuntimeMethod* method);
// System.String Byn.Awrtc.Base.AWebRtcCall::UnpackStringMsg(System.Byte[])
extern "C" IL2CPP_METHOD_ATTR String_t* AWebRtcCall_UnpackStringMsg_mF8138BBBD07AC8F11499A0CAEF32B842F658B804 (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___data0, const RuntimeMethod* method);
// System.Void Byn.Awrtc.MessageEventArgs::.ctor(Byn.Awrtc.ConnectionId,System.String,System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void MessageEventArgs__ctor_m3F3C0FE07EDBD02D58DE442EA60D74FBA9FBC1B8 (MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___id0, String_t* ___message1, bool ___reliable2, const RuntimeMethod* method);
// System.Boolean Byn.Awrtc.Base.AWebRtcCall::IsDataMsg(System.Byte[])
extern "C" IL2CPP_METHOD_ATTR bool AWebRtcCall_IsDataMsg_m91B5AB76EFE79A24690D9B83E5FCBBCB57C1E860 (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___data0, const RuntimeMethod* method);
// System.Byte[] Byn.Awrtc.Base.AWebRtcCall::UnpackDataMsg(System.Byte[])
extern "C" IL2CPP_METHOD_ATTR ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* AWebRtcCall_UnpackDataMsg_m86BF873565BFBC1B6E93DDF3BDB91994DA5BAFC7 (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___msg0, const RuntimeMethod* method);
// System.Void Byn.Awrtc.DataMessageEventArgs::.ctor(Byn.Awrtc.ConnectionId,System.Byte[],System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void DataMessageEventArgs__ctor_m0696EC373C208888C4E333D1FB9B99D52224A03A (DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___id0, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___data1, bool ___reliable2, const RuntimeMethod* method);
// System.Void Byn.Awrtc.Base.AWebRtcCall::ClearPending()
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_ClearPending_m9C48C1D3A5968688756647EFBAF7A598FBF9A005 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, const RuntimeMethod* method);
// System.Void Byn.Awrtc.MediaConfig::.ctor()
extern "C" IL2CPP_METHOD_ATTR void MediaConfig__ctor_m9F57DF2DA5B07EAEA3FD116B734412547CF95C50 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method);
// System.Void Byn.Awrtc.CallEventHandler::Invoke(System.Object,Byn.Awrtc.CallEventArgs)
extern "C" IL2CPP_METHOD_ATTR void CallEventHandler_Invoke_m4E24EBFA859C707089DF4C71DD8359DC0635B6B1 (CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * __this, RuntimeObject * ___sender0, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * ___args1, const RuntimeMethod* method);
// System.Void Byn.Awrtc.CallEventArgs::.ctor(Byn.Awrtc.CallEventType)
extern "C" IL2CPP_METHOD_ATTR void CallEventArgs__ctor_m4ED27A352EC2D4A66D78EEE46EE96B30F119ACCD (CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * __this, int32_t ___type0, const RuntimeMethod* method);
// System.Void Byn.Awrtc.Base.AWebRtcCall::DoPending()
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_DoPending_m91D500C5AFC6D6BF2B222DC22F842AA0BC5BBE50 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, const RuntimeMethod* method);
// System.Void Byn.Awrtc.ErrorInfo::.ctor(System.String)
extern "C" IL2CPP_METHOD_ATTR void ErrorInfo__ctor_m48716C55A898B5D004BF029D7246647CD5B4B23D (ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * __this, String_t* ___error0, const RuntimeMethod* method);
// System.Void System.Object::Finalize()
extern "C" IL2CPP_METHOD_ATTR void Object_Finalize_m4015B7D3A44DE125C5FE34D7276CD4697C06F380 (RuntimeObject * __this, const RuntimeMethod* method);
// System.Void System.Buffer::BlockCopy(System.Array,System.Int32,System.Array,System.Int32,System.Int32)
extern "C" IL2CPP_METHOD_ATTR void Buffer_BlockCopy_m1F882D595976063718AF6E405664FC761924D353 (RuntimeArray * p0, int32_t p1, RuntimeArray * p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
// System.Void System.Runtime.CompilerServices.RuntimeHelpers::InitializeArray(System.Array,System.RuntimeFieldHandle)
extern "C" IL2CPP_METHOD_ATTR void RuntimeHelpers_InitializeArray_m29F50CDFEEE0AB868200291366253DD4737BC76A (RuntimeArray * p0, RuntimeFieldHandle_t844BDF00E8E6FE69D9AEAA7657F09018B864F4EF  p1, const RuntimeMethod* method);
// System.Void System.Threading.Monitor::Enter(System.Object)
extern "C" IL2CPP_METHOD_ATTR void Monitor_Enter_m903755FCC479745619842CCDBF5E6355319FA102 (RuntimeObject * p0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<Byn.Awrtc.ByteArrayBuffer>::.ctor()
inline void List_1__ctor_mC195748161C754C648AB7B1E192547FCFAAE5793 (List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_t43B2D37CF48E04673A48558029581722DDF26F4E *, const RuntimeMethod*))List_1__ctor_mC832F1AC0F814BAEB19175F5D7972A7507508BC3_gshared)(__this, method);
}
// System.Void System.Threading.Monitor::Exit(System.Object)
extern "C" IL2CPP_METHOD_ATTR void Monitor_Exit_m49A1E5356D984D0B934BB97A305E2E5E207225C2 (RuntimeObject * p0, const RuntimeMethod* method);
// System.UInt32 Byn.Awrtc.ByteArrayBuffer::NextPowerOfTwo(System.UInt32)
extern "C" IL2CPP_METHOD_ATTR uint32_t ByteArrayBuffer_NextPowerOfTwo_m799FA4F6BC6E6ADE97AC651BE4BF457EF7A150DA (uint32_t ___v0, const RuntimeMethod* method);
// System.Int32 Byn.Awrtc.ByteArrayBuffer::GetPower(System.UInt32)
extern "C" IL2CPP_METHOD_ATTR int32_t ByteArrayBuffer_GetPower_m16CF6A82A1F8D26A5882179C21617A3960CA7F82 (uint32_t ___anyPowerOfTwo0, const RuntimeMethod* method);
// System.Int32 System.Collections.Generic.List`1<Byn.Awrtc.ByteArrayBuffer>::get_Count()
inline int32_t List_1_get_Count_m185E91DB90246AA3DA769184ADCC7B79E8F8E101 (List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_t43B2D37CF48E04673A48558029581722DDF26F4E *, const RuntimeMethod*))List_1_get_Count_m507C9149FF7F83AAC72C29091E745D557DA47D22_gshared)(__this, method);
}
// System.Void Byn.Awrtc.ByteArrayBuffer::.ctor(System.Int32)
extern "C" IL2CPP_METHOD_ATTR void ByteArrayBuffer__ctor_mCE37F5382D4D067550B5BBB53DB62B4C98EE3B09 (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, int32_t ___size0, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1<Byn.Awrtc.ByteArrayBuffer>::get_Item(System.Int32)
inline ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * List_1_get_Item_mA5D732CCE04960301F17718BCCB163F63F83AE02 (List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * __this, int32_t p0, const RuntimeMethod* method)
{
	return ((  ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * (*) (List_1_t43B2D37CF48E04673A48558029581722DDF26F4E *, int32_t, const RuntimeMethod*))List_1_get_Item_mFDB8AD680C600072736579BBF5F38F7416396588_gshared)(__this, p0, method);
}
// System.Void System.Collections.Generic.List`1<Byn.Awrtc.ByteArrayBuffer>::RemoveAt(System.Int32)
inline void List_1_RemoveAt_mEFDCEF7205CBAAE8676FB4BF94B91B5F7DF29113 (List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * __this, int32_t p0, const RuntimeMethod* method)
{
	((  void (*) (List_1_t43B2D37CF48E04673A48558029581722DDF26F4E *, int32_t, const RuntimeMethod*))List_1_RemoveAt_m1EC5117AD814B97460F8F95D49A428032FE37CBF_gshared)(__this, p0, method);
}
// System.Void Byn.Awrtc.ByteArrayBuffer::Reset()
extern "C" IL2CPP_METHOD_ATTR void ByteArrayBuffer_Reset_m375E1E454C447037210ACFEC6D1C5C769DD54448 (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<Byn.Awrtc.ByteArrayBuffer>::Add(!0)
inline void List_1_Add_m8FC2727372ADD2DF6382E5687F43987CAEF0C19B (List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * __this, ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * p0, const RuntimeMethod* method)
{
	((  void (*) (List_1_t43B2D37CF48E04673A48558029581722DDF26F4E *, ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B *, const RuntimeMethod*))List_1_Add_m6930161974C7504C80F52EC379EF012387D43138_gshared)(__this, p0, method);
}
// System.Void Byn.Awrtc.ConnectionId::.ctor(System.Int16)
extern "C" IL2CPP_METHOD_ATTR void ConnectionId__ctor_m1B23DF8F185ADBFE90CF43E74F2A84983E6C5382 (ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * __this, int16_t ___lId0, const RuntimeMethod* method);
// System.Boolean Byn.Awrtc.ConnectionId::op_Equality(Byn.Awrtc.ConnectionId,Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR bool ConnectionId_op_Equality_m59535C3744B394D8EC43CCE6A2C0521BBDDA6A15 (ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___i10, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___i21, const RuntimeMethod* method);
// System.Boolean Byn.Awrtc.ConnectionId::Equals(System.Object)
extern "C" IL2CPP_METHOD_ATTR bool ConnectionId_Equals_m3319070F68965CAA3729089E1A7700B71527ADB6 (ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * __this, RuntimeObject * ___obj0, const RuntimeMethod* method);
// System.Int32 System.Int16::GetHashCode()
extern "C" IL2CPP_METHOD_ATTR int32_t Int16_GetHashCode_m5DE8889F965D31CFDE23E2CD58650C85259FD798 (int16_t* __this, const RuntimeMethod* method);
// System.Int32 Byn.Awrtc.ConnectionId::GetHashCode()
extern "C" IL2CPP_METHOD_ATTR int32_t ConnectionId_GetHashCode_mF80556358DA5A32ECEA07264C5F8138393804388 (ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * __this, const RuntimeMethod* method);
// System.String System.Int16::ToString()
extern "C" IL2CPP_METHOD_ATTR String_t* Int16_ToString_m9945F0E2E7E6BE9E91203BFFA7125ABFC6843BA5 (int16_t* __this, const RuntimeMethod* method);
// System.String Byn.Awrtc.ConnectionId::ToString()
extern "C" IL2CPP_METHOD_ATTR String_t* ConnectionId_ToString_m1F79176854ABAA347F6F91FA287BFC30B3BF4C27 (ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * __this, const RuntimeMethod* method);
// System.String Byn.Awrtc.ErrorEventArgs::GuessError()
extern "C" IL2CPP_METHOD_ATTR String_t* ErrorEventArgs_GuessError_m6A6732680478E119C59FA45A2CB9129290265497 (ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246 * __this, const RuntimeMethod* method);
// Byn.Awrtc.CallEventType Byn.Awrtc.CallEventArgs::get_Type()
extern "C" IL2CPP_METHOD_ATTR int32_t CallEventArgs_get_Type_m0BF7426058DBFB74B027F71703D096F557ADA077 (CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * __this, const RuntimeMethod* method);
// System.Boolean Byn.Awrtc.ConnectionId::op_Inequality(Byn.Awrtc.ConnectionId,Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR bool ConnectionId_op_Inequality_m4D5E6C47FF0450F312BA489473E9FF71D339CBC0 (ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___i10, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___i21, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<System.String>::.ctor(System.Collections.Generic.IEnumerable`1<!0>)
inline void List_1__ctor_mE9FDDA3E872C3CB2DBDC8562E9ABA76CA3124599 (List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * __this, RuntimeObject* p0, const RuntimeMethod* method)
{
	((  void (*) (List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 *, RuntimeObject*, const RuntimeMethod*))List_1__ctor_m6E336459937EBBC514F001464CC3771240EEBB87_gshared)(__this, p0, method);
}
// System.Void System.Collections.Generic.List`1<System.String>::.ctor()
inline void List_1__ctor_mDA22758D73530683C950C5CCF39BDB4E7E1F3F06 (List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 *, const RuntimeMethod*))List_1__ctor_mC832F1AC0F814BAEB19175F5D7972A7507508BC3_gshared)(__this, method);
}
// System.Void System.Collections.Generic.List`1<System.String>::Add(!0)
inline void List_1_Add_mA348FA1140766465189459D25B01EB179001DE83 (List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * __this, String_t* p0, const RuntimeMethod* method)
{
	((  void (*) (List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 *, String_t*, const RuntimeMethod*))List_1_Add_m6930161974C7504C80F52EC379EF012387D43138_gshared)(__this, p0, method);
}
// System.Void System.Text.StringBuilder::.ctor()
extern "C" IL2CPP_METHOD_ATTR void StringBuilder__ctor_mF928376F82E8C8FF3C11842C562DB8CF28B2735E (StringBuilder_t * __this, const RuntimeMethod* method);
// System.Text.StringBuilder System.Text.StringBuilder::Append(System.String)
extern "C" IL2CPP_METHOD_ATTR StringBuilder_t * StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260 (StringBuilder_t * __this, String_t* p0, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1<System.String>::get_Item(System.Int32)
inline String_t* List_1_get_Item_mB739B0066E5F7EBDBA9978F24A73D26D4FAE5BED (List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * __this, int32_t p0, const RuntimeMethod* method)
{
	return ((  String_t* (*) (List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 *, int32_t, const RuntimeMethod*))List_1_get_Item_mFDB8AD680C600072736579BBF5F38F7416396588_gshared)(__this, p0, method);
}
// System.Int32 System.Collections.Generic.List`1<System.String>::get_Count()
inline int32_t List_1_get_Count_m4151A68BD4CB1D737213E7595F574987F8C812B4 (List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 *, const RuntimeMethod*))List_1_get_Count_m507C9149FF7F83AAC72C29091E745D557DA47D22_gshared)(__this, method);
}
// System.String Byn.Awrtc.IceServer::get_Username()
extern "C" IL2CPP_METHOD_ATTR String_t* IceServer_get_Username_m388B0012517F44C8895EBC05EF2A982D54C575FE (IceServer_t423A5044DD3B2346555973AF68F71585262E07FA * __this, const RuntimeMethod* method);
// System.String Byn.Awrtc.IceServer::get_Credential()
extern "C" IL2CPP_METHOD_ATTR String_t* IceServer_get_Credential_mAD235B95FCC8AA0EF58E9E5C9084323EA6B29049 (IceServer_t423A5044DD3B2346555973AF68F71585262E07FA * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent>::.ctor()
inline void Queue_1__ctor_m207784283861C71375B6A150AA6E6CD3CE6E1ECE (Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * __this, const RuntimeMethod* method)
{
	((  void (*) (Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF *, const RuntimeMethod*))Queue_1__ctor_m207784283861C71375B6A150AA6E6CD3CE6E1ECE_gshared)(__this, method);
}
// System.Void System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::.ctor()
inline void Dictionary_2__ctor_m218A1B086C18400F1C4C49B88A47AE87D133AF19 (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * __this, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB *, const RuntimeMethod*))Dictionary_2__ctor_m01B5E2D22EAEFF051DC823DAEFE8BB7A7BF42B66_gshared)(__this, method);
}
// System.Boolean System.Collections.Generic.Dictionary`2<System.String,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::ContainsKey(!0)
inline bool Dictionary_2_ContainsKey_m7BFA24B1A05E327F5909B68AF1566C84BEFA6431 (Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * __this, String_t* p0, const RuntimeMethod* method)
{
	return ((  bool (*) (Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 *, String_t*, const RuntimeMethod*))Dictionary_2_ContainsKey_m4EBC00E16E83DA33851A551757D2B7332D5756B9_gshared)(__this, p0, method);
}
// !1 System.Collections.Generic.Dictionary`2<System.String,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::get_Item(!0)
inline WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * Dictionary_2_get_Item_mED59F647D10601AFE6764BB277AC05B4673F158C (Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * __this, String_t* p0, const RuntimeMethod* method)
{
	return ((  WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * (*) (Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 *, String_t*, const RuntimeMethod*))Dictionary_2_get_Item_m6625C3BA931A6EE5D6DB46B9E743B40AAA30010B_gshared)(__this, p0, method);
}
// T Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>::Get()
inline LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * WeakRef_1_Get_m7326E507F345D748A6AD3E9BA422CFE3275BC7D8 (WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * __this, const RuntimeMethod* method)
{
	return ((  LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * (*) (WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 *, const RuntimeMethod*))WeakRef_1_Get_m738D2DAA1C1006A6D26BB0681E111854DC430F13_gshared)(__this, method);
}
// System.Boolean System.String::op_Equality(System.String,System.String)
extern "C" IL2CPP_METHOD_ATTR bool String_op_Equality_m139F0E4195AE2F856019E63B241F36F016997FCE (String_t* p0, String_t* p1, const RuntimeMethod* method);
// System.String System.String::Concat(System.Object)
extern "C" IL2CPP_METHOD_ATTR String_t* String_Concat_m798542DE19B3F02DC4F4B777BB2E73169F129DE1 (RuntimeObject * p0, const RuntimeMethod* method);
// System.Boolean Byn.Awrtc.LocalNetwork::IsAddressInUse(System.String)
extern "C" IL2CPP_METHOD_ATTR bool LocalNetwork_IsAddressInUse_mFBB6B273F779EAB3093BF356EF57475856DE60A4 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, String_t* ___serverAddress0, const RuntimeMethod* method);
// System.Void Byn.Awrtc.LocalNetwork::Enqueue(Byn.Awrtc.NetEventType,Byn.Awrtc.ConnectionId,Byn.Awrtc.ErrorInfo)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_Enqueue_m6586F0D0E759C97E13F274594A787292C16FD85C (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, uint8_t ___type0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___id1, ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * ___error2, const RuntimeMethod* method);
// System.Void Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>::.ctor(T)
inline void WeakRef_1__ctor_mC13774F5C531EC799D4800F075E8FEE759322DC4 (WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * __this, LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * p0, const RuntimeMethod* method)
{
	((  void (*) (WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 *, LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 *, const RuntimeMethod*))WeakRef_1__ctor_m762796C00E88972EA95467285E97DC0BAA7BEE70_gshared)(__this, p0, method);
}
// System.Void System.Collections.Generic.Dictionary`2<System.String,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::set_Item(!0,!1)
inline void Dictionary_2_set_Item_mAA053E88F5E5469750D0D6CE2A7A36521BB7BF52 (Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * __this, String_t* p0, WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * p1, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 *, String_t*, WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 *, const RuntimeMethod*))Dictionary_2_set_Item_m466D001F105E25DEB5C9BCB17837EE92A27FDE93_gshared)(__this, p0, p1, method);
}
// System.Void Byn.Awrtc.NetworkEvent::.ctor(Byn.Awrtc.NetEventType,Byn.Awrtc.ConnectionId,System.String)
extern "C" IL2CPP_METHOD_ATTR void NetworkEvent__ctor_mA7EF6BADF8188FC05D529262AC7801F91609C857 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, uint8_t ___t0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___conId1, String_t* ___address2, const RuntimeMethod* method);
// System.Void Byn.Awrtc.LocalNetwork::Enqueue(Byn.Awrtc.NetworkEvent)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_Enqueue_m9D20B54FF730F80913DB2B65C28636DA3BCA14E1 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  ___ev0, const RuntimeMethod* method);
// System.Boolean Byn.Awrtc.LocalNetwork::get_IsServer()
extern "C" IL2CPP_METHOD_ATTR bool LocalNetwork_get_IsServer_m4553266982BFDDB8D6B3A7C8E90CA0F97F7AB852 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, const RuntimeMethod* method);
// System.Void Byn.Awrtc.LocalNetwork::Enqueue(Byn.Awrtc.NetEventType,Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_Enqueue_mCDC62798381553BB3D9B5E660D18C6E328B1FB59 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, uint8_t ___type0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___id1, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.Dictionary`2<System.String,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::Remove(!0)
inline bool Dictionary_2_Remove_mA480C3AD301A4030ED16BD4432EB7AEF76A7B4C4 (Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * __this, String_t* p0, const RuntimeMethod* method)
{
	return ((  bool (*) (Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 *, String_t*, const RuntimeMethod*))Dictionary_2_Remove_m0FCCD33CE2C6A7589E52A2AB0872FE361BF5EF60_gshared)(__this, p0, method);
}
// Byn.Awrtc.ConnectionId Byn.Awrtc.LocalNetwork::NextConnectionId()
extern "C" IL2CPP_METHOD_ATTR ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  LocalNetwork_NextConnectionId_m52D7F7F6AFFC8C040EEC8A25BA57E8EA556489E1 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, const RuntimeMethod* method);
// System.Void Byn.Awrtc.LocalNetwork::ConnectClient(Byn.Awrtc.LocalNetwork)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_ConnectClient_m2DA894173389D07ABAEECDA48F14DCBE6DD5D92D (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * ___client0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::set_Item(!0,!1)
inline void Dictionary_2_set_Item_m9E06F377398DEEF5E6E39D45249196F434BC21C8 (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  p0, WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * p1, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB *, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D , WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 *, const RuntimeMethod*))Dictionary_2_set_Item_m136374B622A2C65387A3BBCC12E056FF2AECCCE9_gshared)(__this, p0, p1, method);
}
// System.Collections.Generic.Dictionary`2/KeyCollection<!0,!1> System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::get_Keys()
inline KeyCollection_t22184C5C648B98E1130AB2CB15D732A497552019 * Dictionary_2_get_Keys_mEFE37E13A4EF1325942D50D41D88AA4EC71B76D7 (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * __this, const RuntimeMethod* method)
{
	return ((  KeyCollection_t22184C5C648B98E1130AB2CB15D732A497552019 * (*) (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB *, const RuntimeMethod*))Dictionary_2_get_Keys_m2555A4127C8B5405BE9781504D955F569B35A145_gshared)(__this, method);
}
// System.Collections.Generic.List`1<!!0> System.Linq.Enumerable::ToList<Byn.Awrtc.ConnectionId>(System.Collections.Generic.IEnumerable`1<!!0>)
inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * Enumerable_ToList_TisConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_m993BAFA400E4493769271824E19E78B7023A85C5 (RuntimeObject* p0, const RuntimeMethod* method)
{
	return ((  List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * (*) (RuntimeObject*, const RuntimeMethod*))Enumerable_ToList_TisConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_m993BAFA400E4493769271824E19E78B7023A85C5_gshared)(p0, method);
}
// System.Void Byn.Awrtc.LocalNetwork::Disconnect(Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_Disconnect_m3F8609F3C16315A6962AED155F2EE0E6371477D7 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___id0, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::Clear()
inline void Dictionary_2_Clear_m2E85D7A98838E7A8D9EFCF534596F39DFA0AA211 (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * __this, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB *, const RuntimeMethod*))Dictionary_2_Clear_mD4048B3B9DFFD0C42A38E8B581B61E9032DB2CBA_gshared)(__this, method);
}
// System.Void Byn.Awrtc.LocalNetwork::StopServer()
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_StopServer_m4ED0D3C401EF3C16E1EB7B64672ACDF02A1D7C45 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::TryGetValue(!0,!1&)
inline bool Dictionary_2_TryGetValue_m42A4CC885EBDCFDC472F9F49D8683A6AAC23F9B9 (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  p0, WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 ** p1, const RuntimeMethod* method)
{
	return ((  bool (*) (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB *, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D , WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 **, const RuntimeMethod*))Dictionary_2_TryGetValue_m309A5E421E73F52CE143DFC5A8D229794B64FEE8_gshared)(__this, p0, p1, method);
}
// !1 System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::get_Item(!0)
inline WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * Dictionary_2_get_Item_m1701F17231AAD3E30A9EACC44EBC78404D336E3D (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  p0, const RuntimeMethod* method)
{
	return ((  WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * (*) (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB *, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D , const RuntimeMethod*))Dictionary_2_get_Item_mFB8D7880A02C63F93A48BC0EE33E97BBAE5909BC_gshared)(__this, p0, method);
}
// System.Void Byn.Awrtc.LocalNetwork::ReceiveData(Byn.Awrtc.LocalNetwork,System.Byte[],System.Int32,System.Int32,System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_ReceiveData_mB8112F374B300211274D8C38432A155CFEE9D31B (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * ___network0, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___data1, int32_t ___offset2, int32_t ___length3, bool ___reliable4, const RuntimeMethod* method);
// System.Void Byn.Awrtc.LocalNetwork::CleanupWreakReferences()
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_CleanupWreakReferences_m1337A34E6D7A17810C73FFB7A2BDDDCDC02C6AD6 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, const RuntimeMethod* method);
// System.Int32 System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent>::get_Count()
inline int32_t Queue_1_get_Count_mB49A946DB72811EC8C21C704B0973456642963CB (Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF *, const RuntimeMethod*))Queue_1_get_Count_mB49A946DB72811EC8C21C704B0973456642963CB_gshared)(__this, method);
}
// !0 System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent>::Dequeue()
inline NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  Queue_1_Dequeue_m2D5C4E39A011B35CD6218B0FA62B5CB0D962F535 (Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * __this, const RuntimeMethod* method)
{
	return ((  NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  (*) (Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF *, const RuntimeMethod*))Queue_1_Dequeue_m2D5C4E39A011B35CD6218B0FA62B5CB0D962F535_gshared)(__this, method);
}
// System.Boolean System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::ContainsKey(!0)
inline bool Dictionary_2_ContainsKey_m421F3F245DD820A5F1189EDFDE3364AA2811EFE3 (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  p0, const RuntimeMethod* method)
{
	return ((  bool (*) (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB *, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D , const RuntimeMethod*))Dictionary_2_ContainsKey_m9EC8F6E9702BBE5A8E89D550CF8604D8DB3B6CAE_gshared)(__this, p0, method);
}
// System.Void Byn.Awrtc.LocalNetwork::InternalDisconnect(Byn.Awrtc.LocalNetwork)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_InternalDisconnect_mD5774B0D59C47658D08C882017A481640DD0A386 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * ___ln0, const RuntimeMethod* method);
// System.Void Byn.Awrtc.LocalNetwork::InternalDisconnect(Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_InternalDisconnect_mEF513BD39E3796C3C0744D5AE51EC9F2F8853C72 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___id0, const RuntimeMethod* method);
// System.Collections.Generic.Dictionary`2/Enumerator<!0,!1> System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::GetEnumerator()
inline Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08  Dictionary_2_GetEnumerator_mE62B21D25025E42B5C035C8843139621A467EA22 (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * __this, const RuntimeMethod* method)
{
	return ((  Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08  (*) (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB *, const RuntimeMethod*))Dictionary_2_GetEnumerator_m31B30ACC437E612A3217BC362A1445E066298B36_gshared)(__this, method);
}
// System.Collections.Generic.KeyValuePair`2<!0,!1> System.Collections.Generic.Dictionary`2/Enumerator<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::get_Current()
inline KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F  Enumerator_get_Current_m003120CE0D40F915FB399DE3CB7FD3DB8F5663DA (Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08 * __this, const RuntimeMethod* method)
{
	return ((  KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F  (*) (Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08 *, const RuntimeMethod*))Enumerator_get_Current_mF4B56BBD84EE5ACB740F1C20A701CF564CA3CFC5_gshared)(__this, method);
}
// !1 System.Collections.Generic.KeyValuePair`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::get_Value()
inline WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * KeyValuePair_2_get_Value_mD5E7F1EC28FEF494AFD05F853C4B120549642FC1 (KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F * __this, const RuntimeMethod* method)
{
	return ((  WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * (*) (KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F *, const RuntimeMethod*))KeyValuePair_2_get_Value_mC7CC4041D9D3597380113C401DD96D6B707A5F4C_gshared)(__this, method);
}
// !0 System.Collections.Generic.KeyValuePair`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::get_Key()
inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  KeyValuePair_2_get_Key_mF0E7E961867D8DF96DBB3A101E204AFFF4BE8570 (KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F * __this, const RuntimeMethod* method)
{
	return ((  ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  (*) (KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F *, const RuntimeMethod*))KeyValuePair_2_get_Key_m6CB23A7ECB174417B465910AFF36CC3EDE0E390D_gshared)(__this, method);
}
// System.Boolean System.Collections.Generic.Dictionary`2/Enumerator<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::MoveNext()
inline bool Enumerator_MoveNext_mADC221420F19A87B6C2DE5C2EE1C2796D03FA138 (Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08 * __this, const RuntimeMethod* method)
{
	return ((  bool (*) (Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08 *, const RuntimeMethod*))Enumerator_MoveNext_m81EB8EB6A17F38BD4B47EA76A0045CEDFB6BA487_gshared)(__this, method);
}
// System.Void System.Collections.Generic.Dictionary`2/Enumerator<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::Dispose()
inline void Enumerator_Dispose_m555891B16D47D7D2E19E328764F6E8AEB9BBE073 (Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08 * __this, const RuntimeMethod* method)
{
	((  void (*) (Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08 *, const RuntimeMethod*))Enumerator_Dispose_mF9014EC4B020E606DEE69E250A684AA25494AA8B_gshared)(__this, method);
}
// System.Void System.InvalidOperationException::.ctor()
extern "C" IL2CPP_METHOD_ATTR void InvalidOperationException__ctor_m1F94EA1226068BD1B7EAA1B836A59C99979F579E (InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 * __this, const RuntimeMethod* method);
// System.Void Byn.Awrtc.NetworkEvent::.ctor(Byn.Awrtc.NetEventType,Byn.Awrtc.ConnectionId,Byn.Awrtc.MessageDataBuffer)
extern "C" IL2CPP_METHOD_ATTR void NetworkEvent__ctor_mF53983C4264CD0231654304A49965EC5B9D94C9E (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, uint8_t ___t0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___conId1, RuntimeObject* ___dt2, const RuntimeMethod* method);
// System.Void Byn.Awrtc.NetworkEvent::.ctor(Byn.Awrtc.NetEventType,Byn.Awrtc.ConnectionId,Byn.Awrtc.ErrorInfo)
extern "C" IL2CPP_METHOD_ATTR void NetworkEvent__ctor_mB80AF54D4891D78B87014B9855C68EE206381C89 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, uint8_t ___t0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___conId1, ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * ___errorInfo2, const RuntimeMethod* method);
// System.Void Byn.Awrtc.NetworkEvent::.ctor(Byn.Awrtc.NetEventType,Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR void NetworkEvent__ctor_m331245C2DC884EF629C1B1103876AD951A650585 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, uint8_t ___t0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___conId1, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Queue`1<Byn.Awrtc.NetworkEvent>::Enqueue(!0)
inline void Queue_1_Enqueue_m4EABC517D5EF21AD49565B814AEBA980EEC805DB (Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * __this, NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  p0, const RuntimeMethod* method)
{
	((  void (*) (Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF *, NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C , const RuntimeMethod*))Queue_1_Enqueue_m4EABC517D5EF21AD49565B814AEBA980EEC805DB_gshared)(__this, p0, method);
}
// Byn.Awrtc.ConnectionId Byn.Awrtc.LocalNetwork::FindConnectionId(Byn.Awrtc.LocalNetwork)
extern "C" IL2CPP_METHOD_ATTR ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  LocalNetwork_FindConnectionId_m9A3BD72C12EC7D9809CDB08C37B15B043BB2014D (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * ___network0, const RuntimeMethod* method);
// Byn.Awrtc.ByteArrayBuffer Byn.Awrtc.ByteArrayBuffer::Get(System.Int32,System.Boolean)
extern "C" IL2CPP_METHOD_ATTR ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * ByteArrayBuffer_Get_m1CA04F719970DD2C4E61B152A14D1A8528641CC0 (int32_t ___size0, bool ___enforceZeroOffset1, const RuntimeMethod* method);
// System.Void Byn.Awrtc.ByteArrayBuffer::CopyFrom(System.Byte[],System.Int32,System.Int32)
extern "C" IL2CPP_METHOD_ATTR void ByteArrayBuffer_CopyFrom_mEF2A576FF26FA7A4FD0A4EEB865770FC72DEDD94 (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___arr0, int32_t ___srcOffset1, int32_t ___len2, const RuntimeMethod* method);
// System.Int32 Byn.Awrtc.ByteArrayBuffer::get_PositionReadRelative()
extern "C" IL2CPP_METHOD_ATTR int32_t ByteArrayBuffer_get_PositionReadRelative_m0E958B7F3E5C4BA2A813CC0B243B1441FDE7B044 (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, const RuntimeMethod* method);
// System.Void Byn.Awrtc.SLog::LE(System.Object,System.String[])
extern "C" IL2CPP_METHOD_ATTR void SLog_LE_m4B26380D8909353763D54ED1E2E1217292226234 (RuntimeObject * ___msg0, StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___tags1, const RuntimeMethod* method);
// System.Int32 Byn.Awrtc.ByteArrayBuffer::get_PositionWriteRelative()
extern "C" IL2CPP_METHOD_ATTR int32_t ByteArrayBuffer_get_PositionWriteRelative_m5BA1493019330918106D5CB819DEAD7FCC62B987 (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, const RuntimeMethod* method);
// System.Void Byn.Awrtc.LocalNetwork::Enqueue(Byn.Awrtc.NetEventType,Byn.Awrtc.ConnectionId,Byn.Awrtc.ByteArrayBuffer)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_Enqueue_m3364B7754275AC65776D6AD3AFB86F0FB59122C6 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, uint8_t ___type0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___id1, ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * ___data2, const RuntimeMethod* method);
// System.Boolean System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::Remove(!0)
inline bool Dictionary_2_Remove_m7985E72DCEF57B284CCA7633890A1FAC9F5169CA (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  p0, const RuntimeMethod* method)
{
	return ((  bool (*) (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB *, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D , const RuntimeMethod*))Dictionary_2_Remove_m684CF8258FAC4B76A293397A5561D28402E51F33_gshared)(__this, p0, method);
}
// System.Void Byn.Awrtc.LocalNetwork::Shutdown()
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_Shutdown_m0C1D588250811D685CEE21E92FC2B079179AF461 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.Dictionary`2<System.String,Byn.Awrtc.LocalNetwork/WeakRef`1<Byn.Awrtc.LocalNetwork>>::.ctor()
inline void Dictionary_2__ctor_mBE3AA4ECD11E0C6081829CED3F9A71E82C905F2A (Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * __this, const RuntimeMethod* method)
{
	((  void (*) (Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 *, const RuntimeMethod*))Dictionary_2__ctor_m2C7E51568033239B506E15E7804A0B8658246498_gshared)(__this, method);
}
// System.Void System.Nullable`1<System.Int32>::.ctor(!0)
inline void Nullable_1__ctor_m11F9C228CFDF836DDFCD7880C09CB4098AB9D7F2 (Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * __this, int32_t p0, const RuntimeMethod* method)
{
	((  void (*) (Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB *, int32_t, const RuntimeMethod*))Nullable_1__ctor_m11F9C228CFDF836DDFCD7880C09CB4098AB9D7F2_gshared)(__this, p0, method);
}
// System.Void Byn.Awrtc.MediaConfig::.ctor(Byn.Awrtc.MediaConfig)
extern "C" IL2CPP_METHOD_ATTR void MediaConfig__ctor_m8DD3603B96D321F06BDC020E2341355B83584967 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___other0, const RuntimeMethod* method);
// System.Text.StringBuilder System.Text.StringBuilder::Append(System.Boolean)
extern "C" IL2CPP_METHOD_ATTR StringBuilder_t * StringBuilder_Append_mF2E955F0669F464B89C29B8783A3E898D7E22281 (StringBuilder_t * __this, bool p0, const RuntimeMethod* method);
// System.Text.StringBuilder System.Text.StringBuilder::Append(System.Object)
extern "C" IL2CPP_METHOD_ATTR StringBuilder_t * StringBuilder_Append_mA1A063A1388A21C8EA011DBA7FC98C24C3EE3D65 (StringBuilder_t * __this, RuntimeObject * p0, const RuntimeMethod* method);
// System.Void System.Array::Copy(System.Array,System.Int32,System.Array,System.Int32,System.Int32)
extern "C" IL2CPP_METHOD_ATTR void Array_Copy_mA10D079DD8D9700CA44721A219A934A2397653F6 (RuntimeArray * p0, int32_t p1, RuntimeArray * p2, int32_t p3, int32_t p4, const RuntimeMethod* method);
// !0 System.Collections.Generic.List`1<Byn.Awrtc.IceServer>::get_Item(System.Int32)
inline IceServer_t423A5044DD3B2346555973AF68F71585262E07FA * List_1_get_Item_mE1FEED1E5EED436AB33E8CE49D4FF88CBBF502F4 (List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 * __this, int32_t p0, const RuntimeMethod* method)
{
	return ((  IceServer_t423A5044DD3B2346555973AF68F71585262E07FA * (*) (List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 *, int32_t, const RuntimeMethod*))List_1_get_Item_mFDB8AD680C600072736579BBF5F38F7416396588_gshared)(__this, p0, method);
}
// System.Int32 System.Collections.Generic.List`1<Byn.Awrtc.IceServer>::get_Count()
inline int32_t List_1_get_Count_mD6BCE7AA51AD2DF7D510F44A83CC847762DCBCFF (List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 * __this, const RuntimeMethod* method)
{
	return ((  int32_t (*) (List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 *, const RuntimeMethod*))List_1_get_Count_m507C9149FF7F83AAC72C29091E745D557DA47D22_gshared)(__this, method);
}
// System.String Byn.Awrtc.NetworkConfig::get_SignalingUrl()
extern "C" IL2CPP_METHOD_ATTR String_t* NetworkConfig_get_SignalingUrl_m23E0B3DF7D3A55FDCA43AB1FDC6CD17B3D6692E4 (NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * __this, const RuntimeMethod* method);
// System.Void System.Collections.Generic.List`1<Byn.Awrtc.IceServer>::.ctor()
inline void List_1__ctor_mE30432DD9DBAB30B7710521567A284CCF1B2E64F (List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 * __this, const RuntimeMethod* method)
{
	((  void (*) (List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 *, const RuntimeMethod*))List_1__ctor_mC832F1AC0F814BAEB19175F5D7972A7507508BC3_gshared)(__this, method);
}
// System.Int32 Byn.Awrtc.ByteArrayBuffer::get_Offset()
extern "C" IL2CPP_METHOD_ATTR int32_t ByteArrayBuffer_get_Offset_m8DD0FD9586C6A3D4B70A82EF5E3B5AF9AF0A59A3 (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, const RuntimeMethod* method);
// System.Int32 Byn.Awrtc.ByteArrayBuffer::get_PositionWriteAbsolute()
extern "C" IL2CPP_METHOD_ATTR int32_t ByteArrayBuffer_get_PositionWriteAbsolute_m1E594C7A0C8E7051D4EB302510851064471D4D9D (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, const RuntimeMethod* method);
// System.String System.BitConverter::ToString(System.Byte[],System.Int32,System.Int32)
extern "C" IL2CPP_METHOD_ATTR String_t* BitConverter_ToString_mE205625C9473E721CCB9D53D113874A4C0E31211 (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* p0, int32_t p1, int32_t p2, const RuntimeMethod* method);
// System.String Byn.Awrtc.NetworkEvent::ToString()
extern "C" IL2CPP_METHOD_ATTR String_t* NetworkEvent_ToString_m4B700DB0C7D27B2855D19F7ABF80FB5112ED2105 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, const RuntimeMethod* method);
// System.Int16 System.BitConverter::ToInt16(System.Byte[],System.Int32)
extern "C" IL2CPP_METHOD_ATTR int16_t BitConverter_ToInt16_mBFC7B476188DF611E2B21C89693258F6A4969CEA (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* p0, int32_t p1, const RuntimeMethod* method);
// System.UInt32 System.BitConverter::ToUInt32(System.Byte[],System.Int32)
extern "C" IL2CPP_METHOD_ATTR uint32_t BitConverter_ToUInt32_mD6A3C2F4BA020691B99FABF863F6FFF6A456FF59 (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* p0, int32_t p1, const RuntimeMethod* method);
// System.Byte[] Byn.Awrtc.ByteArrayBuffer::get_Buffer()
extern "C" IL2CPP_METHOD_ATTR ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ByteArrayBuffer_get_Buffer_mEA87A81D37582411E6A368A0E111DF7BF394433F (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, const RuntimeMethod* method);
// System.Void Byn.Awrtc.ByteArrayBuffer::set_PositionWriteRelative(System.Int32)
extern "C" IL2CPP_METHOD_ATTR void ByteArrayBuffer_set_PositionWriteRelative_m934AA17DAF8473055C81A696C548D40EB8573C4D (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, int32_t ___value0, const RuntimeMethod* method);
// System.Byte[] System.BitConverter::GetBytes(System.Int16)
extern "C" IL2CPP_METHOD_ATTR ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* BitConverter_GetBytes_mB7DFC7C4705F916C40527A87C9AA6D0EABC23512 (int16_t p0, const RuntimeMethod* method);
// System.Byte[] System.BitConverter::GetBytes(System.Int32)
extern "C" IL2CPP_METHOD_ATTR ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* BitConverter_GetBytes_mB5BCBAAFE3AE14F2AF1731187C7155A236DF38EA (int32_t p0, const RuntimeMethod* method);
// System.Char System.String::get_Chars(System.Int32)
extern "C" IL2CPP_METHOD_ATTR Il2CppChar String_get_Chars_m14308AC3B95F8C1D9F1D1055B116B37D595F1D96 (String_t* __this, int32_t p0, const RuntimeMethod* method);
// System.Void Byn.Awrtc.NetworkEvent::AttachError(Byn.Awrtc.ErrorInfo)
extern "C" IL2CPP_METHOD_ATTR void NetworkEvent_AttachError_m04E5757641BF4A66B8CDD83705378B4147F3EC15 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * ___error0, const RuntimeMethod* method);
// System.String[] Byn.Awrtc.SLog::MergeTags(System.String[],System.String[])
extern "C" IL2CPP_METHOD_ATTR StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* SLog_MergeTags_mFF2513B04A32F652F6FDA529489D942C805803AA (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___tags0, StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___newTags1, const RuntimeMethod* method);
// System.Void Byn.Awrtc.SLog::LogArray(System.Object,System.String[])
extern "C" IL2CPP_METHOD_ATTR void SLog_LogArray_mAD74446C19CFC07B879694644E4C675F3F30508E (RuntimeObject * ___obj0, StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___tags1, const RuntimeMethod* method);
// System.Void System.Array::Resize<System.String>(!!0[]&,System.Int32)
inline void Array_Resize_TisString_t_m2F4F7DA2A10041FA80DD5A60977304E4803AAC17 (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E** p0, int32_t p1, const RuntimeMethod* method)
{
	((  void (*) (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E**, int32_t, const RuntimeMethod*))Array_Resize_TisRuntimeObject_m867A1BD65D179315E1C238CBD162DD91D0F362CC_gshared)(p0, p1, method);
}
// System.Void System.Action`2<System.Object,System.String[]>::Invoke(!0,!1)
inline void Action_2_Invoke_m81A2607B01BDBA54F7C5575704E3B52B9063A079 (Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 * __this, RuntimeObject * p0, StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* p1, const RuntimeMethod* method)
{
	((  void (*) (Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 *, RuntimeObject *, StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*, const RuntimeMethod*))Action_2_Invoke_m1738FFAE74BE5E599FD42520FA2BEF69D1AC4709_gshared)(__this, p0, p1, method);
}
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Byn.Awrtc.Base.AWebRtcCall::add_CallEvent(Byn.Awrtc.CallEventHandler)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_add_CallEvent_m09270F23CE78B01FADF2B457CAA8E6D278ACEB6F (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_add_CallEvent_m09270F23CE78B01FADF2B457CAA8E6D278ACEB6F_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * V_0 = NULL;
	CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * V_1 = NULL;
	CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * V_2 = NULL;
	{
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_0 = __this->get_CallEvent_3();
		V_0 = L_0;
	}

IL_0007:
	{
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_1 = V_0;
		V_1 = L_1;
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_2 = V_1;
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_3 = ___value0;
		Delegate_t * L_4 = Delegate_Combine_mC25D2F7DECAFBA6D9A2F9EBA8A77063F0658ECF1(L_2, L_3, /*hidden argument*/NULL);
		V_2 = ((CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F *)CastclassSealed((RuntimeObject*)L_4, CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F_il2cpp_TypeInfo_var));
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F ** L_5 = __this->get_address_of_CallEvent_3();
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_6 = V_2;
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_7 = V_1;
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_8 = InterlockedCompareExchangeImpl<CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F *>((CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F **)L_5, L_6, L_7);
		V_0 = L_8;
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_9 = V_0;
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_10 = V_1;
		if ((!(((RuntimeObject*)(CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F *)L_9) == ((RuntimeObject*)(CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F *)L_10))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::remove_CallEvent(Byn.Awrtc.CallEventHandler)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_remove_CallEvent_mF8A454D1587D3A01AA7A516185D67C7650D572FC (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * ___value0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_remove_CallEvent_mF8A454D1587D3A01AA7A516185D67C7650D572FC_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * V_0 = NULL;
	CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * V_1 = NULL;
	CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * V_2 = NULL;
	{
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_0 = __this->get_CallEvent_3();
		V_0 = L_0;
	}

IL_0007:
	{
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_1 = V_0;
		V_1 = L_1;
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_2 = V_1;
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_3 = ___value0;
		Delegate_t * L_4 = Delegate_Remove_m0B0DB7D1B3AF96B71AFAA72BA0EFE32FBBC2932D(L_2, L_3, /*hidden argument*/NULL);
		V_2 = ((CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F *)CastclassSealed((RuntimeObject*)L_4, CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F_il2cpp_TypeInfo_var));
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F ** L_5 = __this->get_address_of_CallEvent_3();
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_6 = V_2;
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_7 = V_1;
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_8 = InterlockedCompareExchangeImpl<CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F *>((CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F **)L_5, L_6, L_7);
		V_0 = L_8;
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_9 = V_0;
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_10 = V_1;
		if ((!(((RuntimeObject*)(CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F *)L_9) == ((RuntimeObject*)(CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F *)L_10))))
		{
			goto IL_0007;
		}
	}
	{
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::set_LocalFrameEvents(System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_set_LocalFrameEvents_m87C68176A272EC6304EE2D328FE10BFC8B64ACAE (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		bool L_0 = ___value0;
		__this->set_mLocalFrameEvents_10(L_0);
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::.ctor(Byn.Awrtc.NetworkConfig)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall__ctor_mC4846A890AF3EC294C04F2BD4593F3721DF36A3C (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * ___config0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall__ctor_mC4846A890AF3EC294C04F2BD4593F3721DF36A3C_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* V_0 = NULL;
	{
		NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * L_0 = (NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 *)il2cpp_codegen_object_new(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47_il2cpp_TypeInfo_var);
		NetworkConfig__ctor_m602D7088B4491C0C9438A2316195FAA7F1C0E5F4(L_0, /*hidden argument*/NULL);
		__this->set_mNetworkConfig_1(L_0);
		__this->set_mLocalFrameEvents_10((bool)1);
		__this->set_mServerInactive_11((bool)1);
		List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * L_1 = (List_1_tCB9967EC4C00221A410117D712FF423882EB5832 *)il2cpp_codegen_object_new(List_1_tCB9967EC4C00221A410117D712FF423882EB5832_il2cpp_TypeInfo_var);
		List_1__ctor_m348481CF5AD96E81E9F71B9B4052944396A6BB67(L_1, /*hidden argument*/List_1__ctor_m348481CF5AD96E81E9F71B9B4052944396A6BB67_RuntimeMethod_var);
		__this->set_mConnectionIds_12(L_1);
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * L_2 = ___config0;
		if (!L_2)
		{
			goto IL_0067;
		}
	}
	{
		NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * L_3 = ___config0;
		__this->set_mNetworkConfig_1(L_3);
		NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * L_4 = ___config0;
		NullCheck(L_4);
		bool L_5 = NetworkConfig_get_IsConference_mFACBDD257AE18F00F8BED9B4325AF4956FA857D4(L_4, /*hidden argument*/NULL);
		__this->set_mConferenceMode_5(L_5);
		NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * L_6 = __this->get_mNetworkConfig_1();
		NullCheck(L_6);
		bool L_7 = NetworkConfig_get_AllowRenegotiation_m053139CFE0705A02E35D62A572F3ED7A5807E94E(L_6, /*hidden argument*/NULL);
		if (!L_7)
		{
			goto IL_0067;
		}
	}
	{
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_8 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)1);
		V_0 = L_8;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_9 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		String_t* L_10 = ((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->get_LOGTAG_0();
		NullCheck(L_9);
		ArrayElementTypeCheck (L_9, L_10);
		(L_9)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_10);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_11 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		SLog_LW_m4C1FD9091E37D07F12DFBDCE665962B60B7F2DE5(_stringLiteral0A2B0546FA1894D166AFC9DBBA2D981CBBC0D3AB, L_11, /*hidden argument*/NULL);
	}

IL_0067:
	{
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::Initialize(Byn.Awrtc.IMediaNetwork)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_Initialize_m83E52F1519AF93FA065C52AFB177CFCE44A54847 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, RuntimeObject* ___network0, const RuntimeMethod* method)
{
	{
		RuntimeObject* L_0 = ___network0;
		__this->set_mNetwork_4(L_0);
		__this->set_mState_8(1);
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::Configure(Byn.Awrtc.MediaConfig)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_Configure_m8A0BB04F8590D2DCC55BA94B71E88ECC4526EFDB (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___config0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_Configure_m8A0BB04F8590D2DCC55BA94B71E88ECC4526EFDB_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* V_0 = NULL;
	{
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_0 = ___config0;
		if (L_0)
		{
			goto IL_000e;
		}
	}
	{
		ArgumentNullException_t581DF992B1F3E0EC6EFB30CC5DC43519A79B27AD * L_1 = (ArgumentNullException_t581DF992B1F3E0EC6EFB30CC5DC43519A79B27AD *)il2cpp_codegen_object_new(ArgumentNullException_t581DF992B1F3E0EC6EFB30CC5DC43519A79B27AD_il2cpp_TypeInfo_var);
		ArgumentNullException__ctor_mEE0C0D6FCB2D08CD7967DBB1329A0854BBED49ED(L_1, _stringLiteral3A2336C7F3F6FE012EA560BAE437CD6848893503, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, AWebRtcCall_Configure_m8A0BB04F8590D2DCC55BA94B71E88ECC4526EFDB_RuntimeMethod_var);
	}

IL_000e:
	{
		AWebRtcCall_CheckDisposed_mD7EE6F33F9906A26C6CB83B0D103F50D9542F90B(__this, /*hidden argument*/NULL);
		int32_t L_2 = __this->get_mState_8();
		if ((((int32_t)L_2) == ((int32_t)1)))
		{
			goto IL_0045;
		}
	}
	{
		NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * L_3 = __this->get_mNetworkConfig_1();
		NullCheck(L_3);
		bool L_4 = NetworkConfig_get_AllowRenegotiation_m053139CFE0705A02E35D62A572F3ED7A5807E94E(L_3, /*hidden argument*/NULL);
		if (L_4)
		{
			goto IL_0045;
		}
	}
	{
		int32_t L_5 = __this->get_mState_8();
		int32_t L_6 = L_5;
		RuntimeObject * L_7 = Box(CallState_t4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_il2cpp_TypeInfo_var, &L_6);
		String_t* L_8 = String_Concat_mBB19C73816BDD1C3519F248E1ADC8E11A6FDB495(_stringLiteralA43C17788074B67365E30B18FF2C121BAA8FF253, L_7, /*hidden argument*/NULL);
		InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 * L_9 = (InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 *)il2cpp_codegen_object_new(InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m72027D5F1D513C25C05137E203EEED8FD8297706(L_9, L_8, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_9, NULL, AWebRtcCall_Configure_m8A0BB04F8590D2DCC55BA94B71E88ECC4526EFDB_RuntimeMethod_var);
	}

IL_0045:
	{
		int32_t L_10 = __this->get_mState_8();
		if ((!(((uint32_t)L_10) == ((uint32_t)1))))
		{
			goto IL_0088;
		}
	}
	{
		__this->set_mState_8(2);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_11 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)1);
		V_0 = L_11;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_12 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		String_t* L_13 = ((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->get_LOGTAG_0();
		NullCheck(L_12);
		ArrayElementTypeCheck (L_12, L_13);
		(L_12)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_13);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_14 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		SLog_L_m2B84D1BE41D8BA16E73F6E952C5C17D7D2B686A1(_stringLiteral329ECD1B790864B732235061FB2A9F6BCFAF8A92, L_14, /*hidden argument*/NULL);
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_15 = ___config0;
		__this->set_mMediaConfig_2(L_15);
		RuntimeObject* L_16 = __this->get_mNetwork_4();
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_17 = __this->get_mMediaConfig_2();
		NullCheck(L_16);
		InterfaceActionInvoker1< MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * >::Invoke(0 /* System.Void Byn.Awrtc.IMediaNetwork::Configure(Byn.Awrtc.MediaConfig) */, IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780_il2cpp_TypeInfo_var, L_16, L_17);
		return;
	}

IL_0088:
	{
		int32_t L_18 = __this->get_mState_8();
		if ((!(((uint32_t)L_18) == ((uint32_t)7))))
		{
			goto IL_00b7;
		}
	}
	{
		NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * L_19 = __this->get_mNetworkConfig_1();
		NullCheck(L_19);
		bool L_20 = NetworkConfig_get_AllowRenegotiation_m053139CFE0705A02E35D62A572F3ED7A5807E94E(L_19, /*hidden argument*/NULL);
		if (!L_20)
		{
			goto IL_00b7;
		}
	}
	{
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_21 = ___config0;
		__this->set_mMediaConfig_2(L_21);
		RuntimeObject* L_22 = __this->get_mNetwork_4();
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_23 = __this->get_mMediaConfig_2();
		NullCheck(L_22);
		InterfaceActionInvoker1< MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * >::Invoke(0 /* System.Void Byn.Awrtc.IMediaNetwork::Configure(Byn.Awrtc.MediaConfig) */, IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780_il2cpp_TypeInfo_var, L_22, L_23);
		return;
	}

IL_00b7:
	{
		int32_t L_24 = __this->get_mState_8();
		if ((!(((uint32_t)L_24) == ((uint32_t)3))))
		{
			goto IL_00d9;
		}
	}
	{
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_25 = ___config0;
		__this->set_mMediaConfig_2(L_25);
		RuntimeObject* L_26 = __this->get_mNetwork_4();
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_27 = __this->get_mMediaConfig_2();
		NullCheck(L_26);
		InterfaceActionInvoker1< MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * >::Invoke(0 /* System.Void Byn.Awrtc.IMediaNetwork::Configure(Byn.Awrtc.MediaConfig) */, IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780_il2cpp_TypeInfo_var, L_26, L_27);
		return;
	}

IL_00d9:
	{
		int32_t L_28 = __this->get_mState_8();
		int32_t L_29 = L_28;
		RuntimeObject * L_30 = Box(CallState_t4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_il2cpp_TypeInfo_var, &L_29);
		String_t* L_31 = String_Concat_mBB19C73816BDD1C3519F248E1ADC8E11A6FDB495(_stringLiteralA43C17788074B67365E30B18FF2C121BAA8FF253, L_30, /*hidden argument*/NULL);
		InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 * L_32 = (InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 *)il2cpp_codegen_object_new(InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m72027D5F1D513C25C05137E203EEED8FD8297706(L_32, L_31, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_32, NULL, AWebRtcCall_Configure_m8A0BB04F8590D2DCC55BA94B71E88ECC4526EFDB_RuntimeMethod_var);
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::Call(System.String)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_Call_m02C9FCBC750B159F8C8DEF3EC869AEA673F45B11 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, String_t* ___address0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_Call_m02C9FCBC750B159F8C8DEF3EC869AEA673F45B11_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* V_0 = NULL;
	{
		AWebRtcCall_CheckDisposed_mD7EE6F33F9906A26C6CB83B0D103F50D9542F90B(__this, /*hidden argument*/NULL);
		int32_t L_0 = __this->get_mState_8();
		if ((((int32_t)L_0) == ((int32_t)1)))
		{
			goto IL_003c;
		}
	}
	{
		int32_t L_1 = __this->get_mState_8();
		if ((((int32_t)L_1) == ((int32_t)2)))
		{
			goto IL_003c;
		}
	}
	{
		int32_t L_2 = __this->get_mState_8();
		if ((((int32_t)L_2) == ((int32_t)3)))
		{
			goto IL_003c;
		}
	}
	{
		int32_t L_3 = __this->get_mState_8();
		int32_t L_4 = L_3;
		RuntimeObject * L_5 = Box(CallState_t4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_il2cpp_TypeInfo_var, &L_4);
		String_t* L_6 = String_Concat_mBB19C73816BDD1C3519F248E1ADC8E11A6FDB495(_stringLiteralA43C17788074B67365E30B18FF2C121BAA8FF253, L_5, /*hidden argument*/NULL);
		InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 * L_7 = (InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 *)il2cpp_codegen_object_new(InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m72027D5F1D513C25C05137E203EEED8FD8297706(L_7, L_6, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_7, NULL, AWebRtcCall_Call_m02C9FCBC750B159F8C8DEF3EC869AEA673F45B11_RuntimeMethod_var);
	}

IL_003c:
	{
		bool L_8 = __this->get_mConferenceMode_5();
		if (!L_8)
		{
			goto IL_004f;
		}
	}
	{
		InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 * L_9 = (InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 *)il2cpp_codegen_object_new(InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m72027D5F1D513C25C05137E203EEED8FD8297706(L_9, _stringLiteralDE4548A66DA089BE5B4BAA57D06B095DD67044D3, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_9, NULL, AWebRtcCall_Call_m02C9FCBC750B159F8C8DEF3EC869AEA673F45B11_RuntimeMethod_var);
	}

IL_004f:
	{
		String_t* L_10 = ___address0;
		String_t* L_11 = String_Concat_mB78D0094592718DA6D5DB6C712A9C225631666BE(_stringLiteralB7DC874978F66EBD04EDD88C5EF98788890F4068, L_10, /*hidden argument*/NULL);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_12 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)1);
		V_0 = L_12;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_13 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		String_t* L_14 = ((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->get_LOGTAG_0();
		NullCheck(L_13);
		ArrayElementTypeCheck (L_13, L_14);
		(L_13)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_14);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_15 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		SLog_L_m2B84D1BE41D8BA16E73F6E952C5C17D7D2B686A1(L_11, L_15, /*hidden argument*/NULL);
		AWebRtcCall_EnsureConfiguration_mAE816DED202FC4344ECF0EFE83E886024340C82C(__this, /*hidden argument*/NULL);
		int32_t L_16 = __this->get_mState_8();
		if ((!(((uint32_t)L_16) == ((uint32_t)3))))
		{
			goto IL_0086;
		}
	}
	{
		String_t* L_17 = ___address0;
		AWebRtcCall_ProcessCall_mB92C63DDC4A918A067FBC9B8AF077513BCE9D422(__this, L_17, /*hidden argument*/NULL);
		return;
	}

IL_0086:
	{
		String_t* L_18 = ___address0;
		AWebRtcCall_PendingCall_mEBF56D08C2A943272DB3DC82DEC2EFC06A628EE0(__this, L_18, /*hidden argument*/NULL);
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::Listen(System.String)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_Listen_m130E1DF8EA39AE89D2B8C21C04454CCF3A0539C9 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, String_t* ___address0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_Listen_m130E1DF8EA39AE89D2B8C21C04454CCF3A0539C9_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		AWebRtcCall_CheckDisposed_mD7EE6F33F9906A26C6CB83B0D103F50D9542F90B(__this, /*hidden argument*/NULL);
		int32_t L_0 = __this->get_mState_8();
		if ((((int32_t)L_0) == ((int32_t)1)))
		{
			goto IL_003c;
		}
	}
	{
		int32_t L_1 = __this->get_mState_8();
		if ((((int32_t)L_1) == ((int32_t)2)))
		{
			goto IL_003c;
		}
	}
	{
		int32_t L_2 = __this->get_mState_8();
		if ((((int32_t)L_2) == ((int32_t)3)))
		{
			goto IL_003c;
		}
	}
	{
		int32_t L_3 = __this->get_mState_8();
		int32_t L_4 = L_3;
		RuntimeObject * L_5 = Box(CallState_t4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_il2cpp_TypeInfo_var, &L_4);
		String_t* L_6 = String_Concat_mBB19C73816BDD1C3519F248E1ADC8E11A6FDB495(_stringLiteralA43C17788074B67365E30B18FF2C121BAA8FF253, L_5, /*hidden argument*/NULL);
		InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 * L_7 = (InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 *)il2cpp_codegen_object_new(InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m72027D5F1D513C25C05137E203EEED8FD8297706(L_7, L_6, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_7, NULL, AWebRtcCall_Listen_m130E1DF8EA39AE89D2B8C21C04454CCF3A0539C9_RuntimeMethod_var);
	}

IL_003c:
	{
		bool L_8 = __this->get_mServerInactive_11();
		if (L_8)
		{
			goto IL_0064;
		}
	}
	{
		int32_t L_9 = __this->get_mState_8();
		int32_t L_10 = L_9;
		RuntimeObject * L_11 = Box(CallState_t4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_il2cpp_TypeInfo_var, &L_10);
		String_t* L_12 = String_Concat_m2E1F71C491D2429CC80A28745488FEA947BB7AAC(_stringLiteralA43C17788074B67365E30B18FF2C121BAA8FF253, L_11, _stringLiteralD61D3DAF249E2436C0AD63896FF6E5C0EE13F9AC, /*hidden argument*/NULL);
		InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 * L_13 = (InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 *)il2cpp_codegen_object_new(InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m72027D5F1D513C25C05137E203EEED8FD8297706(L_13, L_12, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_13, NULL, AWebRtcCall_Listen_m130E1DF8EA39AE89D2B8C21C04454CCF3A0539C9_RuntimeMethod_var);
	}

IL_0064:
	{
		AWebRtcCall_EnsureConfiguration_mAE816DED202FC4344ECF0EFE83E886024340C82C(__this, /*hidden argument*/NULL);
		int32_t L_14 = __this->get_mState_8();
		if ((!(((uint32_t)L_14) == ((uint32_t)3))))
		{
			goto IL_007b;
		}
	}
	{
		String_t* L_15 = ___address0;
		AWebRtcCall_ProcessListen_m753AF5E46F70C7EC3F1E425CA13C514A77A3954B(__this, L_15, /*hidden argument*/NULL);
		return;
	}

IL_007b:
	{
		String_t* L_16 = ___address0;
		AWebRtcCall_PendingListen_m9CDA2D2ACE32708C21229DD92B30A0F98A35EF40(__this, L_16, /*hidden argument*/NULL);
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::Send(System.String)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_Send_m23E89B21AE68294EE90FFFF42EAA84A95C40B65C (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, String_t* ___message0, const RuntimeMethod* method)
{
	{
		String_t* L_0 = ___message0;
		AWebRtcCall_Send_mD6438A63F1C799D469A9822AD033768311D9EBA9(__this, L_0, (bool)1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::Send(System.String,System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_Send_mD6438A63F1C799D469A9822AD033768311D9EBA9 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, String_t* ___message0, bool ___reliable1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_Send_mD6438A63F1C799D469A9822AD033768311D9EBA9_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* V_0 = NULL;
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  V_1;
	memset(&V_1, 0, sizeof(V_1));
	Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17  V_2;
	memset(&V_2, 0, sizeof(V_2));
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 1);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		AWebRtcCall_CheckDisposed_mD7EE6F33F9906A26C6CB83B0D103F50D9542F90B(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___message0;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_1 = AWebRtcCall_PackStringMsg_m80338D0EE5DE8E91F2D4510DC604A3652B4A5663(L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * L_2 = __this->get_mConnectionIds_12();
		NullCheck(L_2);
		Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17  L_3 = List_1_GetEnumerator_m72711B857C13554E60D06AE2C418B4FA59870E65(L_2, /*hidden argument*/List_1_GetEnumerator_m72711B857C13554E60D06AE2C418B4FA59870E65_RuntimeMethod_var);
		V_2 = L_3;
	}

IL_0019:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0036;
		}

IL_001b:
		{
			ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_4 = Enumerator_get_Current_m0203034B79126F512CC77691D03434942FE5EE6C((Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 *)(&V_2), /*hidden argument*/Enumerator_get_Current_m0203034B79126F512CC77691D03434942FE5EE6C_RuntimeMethod_var);
			V_1 = L_4;
			RuntimeObject* L_5 = __this->get_mNetwork_4();
			ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_6 = V_1;
			ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_7 = V_0;
			ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_8 = V_0;
			NullCheck(L_8);
			bool L_9 = ___reliable1;
			NullCheck(L_5);
			InterfaceFuncInvoker5< bool, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D , ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*, int32_t, int32_t, bool >::Invoke(2 /* System.Boolean Byn.Awrtc.INetwork::SendData(Byn.Awrtc.ConnectionId,System.Byte[],System.Int32,System.Int32,System.Boolean) */, INetwork_t2BC558248C74706BEF2D050A9084AB9FB14697F2_il2cpp_TypeInfo_var, L_5, L_6, L_7, 0, (((int32_t)((int32_t)(((RuntimeArray *)L_8)->max_length)))), L_9);
		}

IL_0036:
		{
			bool L_10 = Enumerator_MoveNext_m50BD3D91B026FC120054CB6B187B49A57689E4E7((Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 *)(&V_2), /*hidden argument*/Enumerator_MoveNext_m50BD3D91B026FC120054CB6B187B49A57689E4E7_RuntimeMethod_var);
			if (L_10)
			{
				goto IL_001b;
			}
		}

IL_003f:
		{
			IL2CPP_LEAVE(0x4F, FINALLY_0041);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_0041;
	}

FINALLY_0041:
	{ // begin finally (depth: 1)
		Enumerator_Dispose_m62E14E84F0EFE2CD8FC246C3779797583ED04D49((Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 *)(&V_2), /*hidden argument*/Enumerator_Dispose_m62E14E84F0EFE2CD8FC246C3779797583ED04D49_RuntimeMethod_var);
		IL2CPP_END_FINALLY(65)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(65)
	{
		IL2CPP_JUMP_TBL(0x4F, IL_004f)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
	}

IL_004f:
	{
		return;
	}
}
// System.Boolean Byn.Awrtc.Base.AWebRtcCall::IsStringMsg(System.Byte[])
extern "C" IL2CPP_METHOD_ATTR bool AWebRtcCall_IsStringMsg_m7F45CD2616184B9739365F17F027461489F20882 (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___data0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_IsStringMsg_m7F45CD2616184B9739365F17F027461489F20882_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_0 = ___data0;
		if (!L_0)
		{
			goto IL_0015;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_1 = ___data0;
		NullCheck(L_1);
		if ((((int32_t)(((int32_t)((int32_t)(((RuntimeArray *)L_1)->max_length))))) <= ((int32_t)0)))
		{
			goto IL_0015;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_2 = ___data0;
		NullCheck(L_2);
		int32_t L_3 = 0;
		uint8_t L_4 = (L_2)->GetAt(static_cast<il2cpp_array_size_t>(L_3));
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		uint8_t L_5 = ((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->get_MESSAGE_TYPE_STRING_7();
		if ((!(((uint32_t)L_4) == ((uint32_t)L_5))))
		{
			goto IL_0015;
		}
	}
	{
		return (bool)1;
	}

IL_0015:
	{
		return (bool)0;
	}
}
// System.Byte[] Byn.Awrtc.Base.AWebRtcCall::PackStringMsg(System.String)
extern "C" IL2CPP_METHOD_ATTR ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* AWebRtcCall_PackStringMsg_m80338D0EE5DE8E91F2D4510DC604A3652B4A5663 (String_t* ___message0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_PackStringMsg_m80338D0EE5DE8E91F2D4510DC604A3652B4A5663_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	int32_t V_1 = 0;
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* V_2 = NULL;
	{
		Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * L_0 = Encoding_get_Unicode_m86CC470F70F9BB52DDB26721F0C0D6EDAFC318AA(/*hidden argument*/NULL);
		String_t* L_1 = ___message0;
		NullCheck(L_0);
		int32_t L_2 = VirtFuncInvoker1< int32_t, String_t* >::Invoke(9 /* System.Int32 System.Text.Encoding::GetByteCount(System.String) */, L_0, L_1);
		V_0 = L_2;
		int32_t L_3 = V_0;
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_3, (int32_t)1));
		int32_t L_4 = V_1;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_5 = (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*)SZArrayNew(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821_il2cpp_TypeInfo_var, (uint32_t)L_4);
		V_2 = L_5;
		Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * L_6 = Encoding_get_Unicode_m86CC470F70F9BB52DDB26721F0C0D6EDAFC318AA(/*hidden argument*/NULL);
		String_t* L_7 = ___message0;
		String_t* L_8 = ___message0;
		NullCheck(L_8);
		int32_t L_9 = String_get_Length_mD48C8A16A5CF1914F330DCE82D9BE15C3BEDD018(L_8, /*hidden argument*/NULL);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_10 = V_2;
		NullCheck(L_6);
		VirtFuncInvoker5< int32_t, String_t*, int32_t, int32_t, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*, int32_t >::Invoke(17 /* System.Int32 System.Text.Encoding::GetBytes(System.String,System.Int32,System.Int32,System.Byte[],System.Int32) */, L_6, L_7, 0, L_9, L_10, 1);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_11 = V_2;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		uint8_t L_12 = ((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->get_MESSAGE_TYPE_STRING_7();
		NullCheck(L_11);
		(L_11)->SetAt(static_cast<il2cpp_array_size_t>(0), (uint8_t)L_12);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_13 = V_2;
		return L_13;
	}
}
// System.String Byn.Awrtc.Base.AWebRtcCall::UnpackStringMsg(System.Byte[])
extern "C" IL2CPP_METHOD_ATTR String_t* AWebRtcCall_UnpackStringMsg_mF8138BBBD07AC8F11499A0CAEF32B842F658B804 (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___data0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_UnpackStringMsg_mF8138BBBD07AC8F11499A0CAEF32B842F658B804_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_0 = ___data0;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		bool L_1 = AWebRtcCall_IsStringMsg_m7F45CD2616184B9739365F17F027461489F20882(L_0, /*hidden argument*/NULL);
		if (L_1)
		{
			goto IL_0013;
		}
	}
	{
		ArgumentException_tEDCD16F20A09ECE461C3DA766C16EDA8864057D1 * L_2 = (ArgumentException_tEDCD16F20A09ECE461C3DA766C16EDA8864057D1 *)il2cpp_codegen_object_new(ArgumentException_tEDCD16F20A09ECE461C3DA766C16EDA8864057D1_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m9A85EF7FEFEC21DDD525A67E831D77278E5165B7(L_2, _stringLiteralCE01E985552B87A2A43F9E63A696458D55DFA4E6, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_2, NULL, AWebRtcCall_UnpackStringMsg_mF8138BBBD07AC8F11499A0CAEF32B842F658B804_RuntimeMethod_var);
	}

IL_0013:
	{
		Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * L_3 = Encoding_get_Unicode_m86CC470F70F9BB52DDB26721F0C0D6EDAFC318AA(/*hidden argument*/NULL);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_4 = ___data0;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_5 = ___data0;
		NullCheck(L_5);
		NullCheck(L_3);
		String_t* L_6 = VirtFuncInvoker3< String_t*, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*, int32_t, int32_t >::Invoke(33 /* System.String System.Text.Encoding::GetString(System.Byte[],System.Int32,System.Int32) */, L_3, L_4, 1, ((int32_t)il2cpp_codegen_subtract((int32_t)(((int32_t)((int32_t)(((RuntimeArray *)L_5)->max_length)))), (int32_t)1)));
		return L_6;
	}
}
// System.Boolean Byn.Awrtc.Base.AWebRtcCall::IsDataMsg(System.Byte[])
extern "C" IL2CPP_METHOD_ATTR bool AWebRtcCall_IsDataMsg_m91B5AB76EFE79A24690D9B83E5FCBBCB57C1E860 (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___data0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_IsDataMsg_m91B5AB76EFE79A24690D9B83E5FCBBCB57C1E860_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_0 = ___data0;
		if (!L_0)
		{
			goto IL_0015;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_1 = ___data0;
		NullCheck(L_1);
		if ((((int32_t)(((int32_t)((int32_t)(((RuntimeArray *)L_1)->max_length))))) <= ((int32_t)0)))
		{
			goto IL_0015;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_2 = ___data0;
		NullCheck(L_2);
		int32_t L_3 = 0;
		uint8_t L_4 = (L_2)->GetAt(static_cast<il2cpp_array_size_t>(L_3));
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		uint8_t L_5 = ((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->get_MESSAGE_TYPE_DATA_6();
		if ((!(((uint32_t)L_4) == ((uint32_t)L_5))))
		{
			goto IL_0015;
		}
	}
	{
		return (bool)1;
	}

IL_0015:
	{
		return (bool)0;
	}
}
// System.Byte[] Byn.Awrtc.Base.AWebRtcCall::UnpackDataMsg(System.Byte[])
extern "C" IL2CPP_METHOD_ATTR ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* AWebRtcCall_UnpackDataMsg_m86BF873565BFBC1B6E93DDF3BDB91994DA5BAFC7 (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___msg0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_UnpackDataMsg_m86BF873565BFBC1B6E93DDF3BDB91994DA5BAFC7_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* V_0 = NULL;
	int32_t V_1 = 0;
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_0 = ___msg0;
		NullCheck(L_0);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_1 = (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*)SZArrayNew(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821_il2cpp_TypeInfo_var, (uint32_t)((int32_t)il2cpp_codegen_subtract((int32_t)(((int32_t)((int32_t)(((RuntimeArray *)L_0)->max_length)))), (int32_t)1)));
		V_0 = L_1;
		V_1 = 0;
		goto IL_001b;
	}

IL_000f:
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_2 = V_0;
		int32_t L_3 = V_1;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_4 = ___msg0;
		int32_t L_5 = V_1;
		NullCheck(L_4);
		int32_t L_6 = ((int32_t)il2cpp_codegen_add((int32_t)L_5, (int32_t)1));
		uint8_t L_7 = (L_4)->GetAt(static_cast<il2cpp_array_size_t>(L_6));
		NullCheck(L_2);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(L_3), (uint8_t)L_7);
		int32_t L_8 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_8, (int32_t)1));
	}

IL_001b:
	{
		int32_t L_9 = V_1;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_10 = V_0;
		NullCheck(L_10);
		if ((((int32_t)L_9) < ((int32_t)(((int32_t)((int32_t)(((RuntimeArray *)L_10)->max_length)))))))
		{
			goto IL_000f;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_11 = V_0;
		return L_11;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::Update()
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_Update_m549A46BEA47F858AB137C76F856410223F150902 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_Update_m549A46BEA47F858AB137C76F856410223F150902_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	uint8_t V_0 = 0;
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  V_1;
	memset(&V_1, 0, sizeof(V_1));
	{
		bool L_0 = __this->get_mIsDisposed_9();
		if (!L_0)
		{
			goto IL_0009;
		}
	}
	{
		return;
	}

IL_0009:
	{
		RuntimeObject* L_1 = __this->get_mNetwork_4();
		if (L_1)
		{
			goto IL_0012;
		}
	}
	{
		return;
	}

IL_0012:
	{
		RuntimeObject* L_2 = __this->get_mNetwork_4();
		NullCheck(L_2);
		InterfaceActionInvoker0::Invoke(5 /* System.Void Byn.Awrtc.INetwork::Update() */, INetwork_t2BC558248C74706BEF2D050A9084AB9FB14697F2_il2cpp_TypeInfo_var, L_2);
		int32_t L_3 = __this->get_mState_8();
		if ((!(((uint32_t)L_3) == ((uint32_t)2))))
		{
			goto IL_007f;
		}
	}
	{
		RuntimeObject* L_4 = __this->get_mNetwork_4();
		NullCheck(L_4);
		uint8_t L_5 = InterfaceFuncInvoker0< uint8_t >::Invoke(1 /* Byn.Awrtc.MediaConfigurationState Byn.Awrtc.IMediaNetwork::GetConfigurationState() */, IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780_il2cpp_TypeInfo_var, L_4);
		V_0 = L_5;
		uint8_t L_6 = V_0;
		if ((!(((uint32_t)L_6) == ((uint32_t)4))))
		{
			goto IL_0065;
		}
	}
	{
		RuntimeObject* L_7 = __this->get_mNetwork_4();
		NullCheck(L_7);
		String_t* L_8 = InterfaceFuncInvoker0< String_t* >::Invoke(2 /* System.String Byn.Awrtc.IMediaNetwork::GetConfigurationError() */, IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780_il2cpp_TypeInfo_var, L_7);
		AWebRtcCall_OnConfigurationFailed_mCF1E7B2727703A3A0232C3528F5E3C1B766F0E8D(__this, L_8, /*hidden argument*/NULL);
		bool L_9 = __this->get_mIsDisposed_9();
		if (!L_9)
		{
			goto IL_0050;
		}
	}
	{
		return;
	}

IL_0050:
	{
		RuntimeObject* L_10 = __this->get_mNetwork_4();
		if (!L_10)
		{
			goto IL_007f;
		}
	}
	{
		RuntimeObject* L_11 = __this->get_mNetwork_4();
		NullCheck(L_11);
		InterfaceActionInvoker0::Invoke(3 /* System.Void Byn.Awrtc.IMediaNetwork::ResetConfiguration() */, IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780_il2cpp_TypeInfo_var, L_11);
		goto IL_007f;
	}

IL_0065:
	{
		uint8_t L_12 = V_0;
		if ((!(((uint32_t)L_12) == ((uint32_t)3))))
		{
			goto IL_007f;
		}
	}
	{
		AWebRtcCall_OnConfigurationComplete_mF6BED2C9B6EEF93AE305B540A32234F734B8016E(__this, /*hidden argument*/NULL);
		bool L_13 = __this->get_mIsDisposed_9();
		if (!L_13)
		{
			goto IL_007f;
		}
	}
	{
		return;
	}

IL_0078:
	{
		NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  L_14 = V_1;
		VirtActionInvoker1< NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  >::Invoke(24 /* System.Void Byn.Awrtc.Base.AWebRtcCall::HandleNetworkEvent(Byn.Awrtc.NetworkEvent) */, __this, L_14);
	}

IL_007f:
	{
		RuntimeObject* L_15 = __this->get_mNetwork_4();
		if (!L_15)
		{
			goto IL_0096;
		}
	}
	{
		RuntimeObject* L_16 = __this->get_mNetwork_4();
		NullCheck(L_16);
		bool L_17 = InterfaceFuncInvoker1< bool, NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * >::Invoke(0 /* System.Boolean Byn.Awrtc.INetwork::Dequeue(Byn.Awrtc.NetworkEvent&) */, INetwork_t2BC558248C74706BEF2D050A9084AB9FB14697F2_il2cpp_TypeInfo_var, L_16, (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&V_1));
		if (L_17)
		{
			goto IL_0078;
		}
	}

IL_0096:
	{
		VirtActionInvoker0::Invoke(23 /* System.Void Byn.Awrtc.Base.AWebRtcCall::HandleMediaEvents() */, __this);
		RuntimeObject* L_18 = __this->get_mNetwork_4();
		if (!L_18)
		{
			goto IL_00af;
		}
	}
	{
		RuntimeObject* L_19 = __this->get_mNetwork_4();
		NullCheck(L_19);
		InterfaceActionInvoker0::Invoke(1 /* System.Void Byn.Awrtc.INetwork::Flush() */, INetwork_t2BC558248C74706BEF2D050A9084AB9FB14697F2_il2cpp_TypeInfo_var, L_19);
	}

IL_00af:
	{
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::HandleMediaEvents()
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_HandleMediaEvents_m841524A2FE667C7D2A272C5DF04365D1B8108B6B (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_HandleMediaEvents_m841524A2FE667C7D2A272C5DF04365D1B8108B6B_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	RuntimeObject* V_1 = NULL;
	CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * V_2 = NULL;
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  V_3;
	memset(&V_3, 0, sizeof(V_3));
	RuntimeObject* V_4 = NULL;
	CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * V_5 = NULL;
	Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17  V_6;
	memset(&V_6, 0, sizeof(V_6));
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 2);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		V_0 = (bool)1;
		RuntimeObject* L_0 = __this->get_mNetwork_4();
		if (!L_0)
		{
			goto IL_0042;
		}
	}
	{
		bool L_1 = __this->get_mLocalFrameEvents_10();
		if (!L_1)
		{
			goto IL_0042;
		}
	}
	{
		RuntimeObject* L_2 = __this->get_mNetwork_4();
		IL2CPP_RUNTIME_CLASS_INIT(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_3 = ((ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields*)il2cpp_codegen_static_fields_for(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var))->get_INVALID_0();
		NullCheck(L_2);
		RuntimeObject* L_4 = InterfaceFuncInvoker1< RuntimeObject*, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  >::Invoke(4 /* Byn.Awrtc.IFrame Byn.Awrtc.IMediaNetwork::TryGetFrame(Byn.Awrtc.ConnectionId) */, IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780_il2cpp_TypeInfo_var, L_2, L_3);
		V_1 = L_4;
		RuntimeObject* L_5 = V_1;
		if (!L_5)
		{
			goto IL_0042;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_6 = ((ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields*)il2cpp_codegen_static_fields_for(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var))->get_INVALID_0();
		RuntimeObject* L_7 = V_1;
		FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C * L_8 = (FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C *)il2cpp_codegen_object_new(FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C_il2cpp_TypeInfo_var);
		FrameUpdateEventArgs__ctor_mA0D47D896195E97BBE9FEB1BF9EE2CAABC8F53E4(L_8, L_6, L_7, /*hidden argument*/NULL);
		V_2 = L_8;
		CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * L_9 = V_2;
		AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC(__this, L_9, /*hidden argument*/NULL);
		bool L_10 = __this->get_mIsDisposed_9();
		if (!L_10)
		{
			goto IL_0042;
		}
	}
	{
		return;
	}

IL_0042:
	{
		RuntimeObject* L_11 = __this->get_mNetwork_4();
		if (!L_11)
		{
			goto IL_00b3;
		}
	}
	{
		bool L_12 = V_0;
		if (!L_12)
		{
			goto IL_00b3;
		}
	}
	{
		List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * L_13 = __this->get_mConnectionIds_12();
		NullCheck(L_13);
		Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17  L_14 = List_1_GetEnumerator_m72711B857C13554E60D06AE2C418B4FA59870E65(L_13, /*hidden argument*/List_1_GetEnumerator_m72711B857C13554E60D06AE2C418B4FA59870E65_RuntimeMethod_var);
		V_6 = L_14;
	}

IL_005a:
	try
	{ // begin try (depth: 1)
		{
			goto IL_009a;
		}

IL_005c:
		{
			ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_15 = Enumerator_get_Current_m0203034B79126F512CC77691D03434942FE5EE6C((Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 *)(&V_6), /*hidden argument*/Enumerator_get_Current_m0203034B79126F512CC77691D03434942FE5EE6C_RuntimeMethod_var);
			V_3 = L_15;
			RuntimeObject* L_16 = __this->get_mNetwork_4();
			if (!L_16)
			{
				goto IL_009a;
			}
		}

IL_006c:
		{
			RuntimeObject* L_17 = __this->get_mNetwork_4();
			ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_18 = V_3;
			NullCheck(L_17);
			RuntimeObject* L_19 = InterfaceFuncInvoker1< RuntimeObject*, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  >::Invoke(4 /* Byn.Awrtc.IFrame Byn.Awrtc.IMediaNetwork::TryGetFrame(Byn.Awrtc.ConnectionId) */, IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780_il2cpp_TypeInfo_var, L_17, L_18);
			V_4 = L_19;
			RuntimeObject* L_20 = V_4;
			if (!L_20)
			{
				goto IL_009a;
			}
		}

IL_007e:
		{
			ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_21 = V_3;
			RuntimeObject* L_22 = V_4;
			FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C * L_23 = (FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C *)il2cpp_codegen_object_new(FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C_il2cpp_TypeInfo_var);
			FrameUpdateEventArgs__ctor_mA0D47D896195E97BBE9FEB1BF9EE2CAABC8F53E4(L_23, L_21, L_22, /*hidden argument*/NULL);
			V_5 = L_23;
			CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * L_24 = V_5;
			AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC(__this, L_24, /*hidden argument*/NULL);
			bool L_25 = __this->get_mIsDisposed_9();
			if (!L_25)
			{
				goto IL_009a;
			}
		}

IL_0098:
		{
			IL2CPP_LEAVE(0xB3, FINALLY_00a5);
		}

IL_009a:
		{
			bool L_26 = Enumerator_MoveNext_m50BD3D91B026FC120054CB6B187B49A57689E4E7((Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 *)(&V_6), /*hidden argument*/Enumerator_MoveNext_m50BD3D91B026FC120054CB6B187B49A57689E4E7_RuntimeMethod_var);
			if (L_26)
			{
				goto IL_005c;
			}
		}

IL_00a3:
		{
			IL2CPP_LEAVE(0xB3, FINALLY_00a5);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_00a5;
	}

FINALLY_00a5:
	{ // begin finally (depth: 1)
		Enumerator_Dispose_m62E14E84F0EFE2CD8FC246C3779797583ED04D49((Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 *)(&V_6), /*hidden argument*/Enumerator_Dispose_m62E14E84F0EFE2CD8FC246C3779797583ED04D49_RuntimeMethod_var);
		IL2CPP_END_FINALLY(165)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(165)
	{
		IL2CPP_JUMP_TBL(0xB3, IL_00b3)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
	}

IL_00b3:
	{
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::HandleNetworkEvent(Byn.Awrtc.NetworkEvent)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_HandleNetworkEvent_m6E1AC4BC273D0574A85039E7CEF3798E704D3ECF (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  ___evt0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_HandleNetworkEvent_m6E1AC4BC273D0574A85039E7CEF3798E704D3ECF_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* V_0 = NULL;
	String_t* V_1 = NULL;
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* V_2 = NULL;
	uint8_t V_3 = 0x0;
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* V_4 = NULL;
	String_t* V_5 = NULL;
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* V_6 = NULL;
	uint8_t V_7 = 0x0;
	uint8_t V_8 = 0;
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* V_9 = NULL;
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* V_10 = NULL;
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* V_11 = NULL;
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* V_12 = NULL;
	{
		uint8_t L_0 = NetworkEvent_get_Type_m90AD2D28598E4CB47CC71E363D104C8AC7A705C5((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		V_8 = L_0;
		uint8_t L_1 = V_8;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_1, (int32_t)1)))
		{
			case 0:
			{
				goto IL_030e;
			}
			case 1:
			{
				goto IL_0264;
			}
			case 2:
			{
				goto IL_01c9;
			}
			case 3:
			{
				goto IL_01f5;
			}
			case 4:
			{
				goto IL_0222;
			}
			case 5:
			{
				goto IL_0033;
			}
			case 6:
			{
				goto IL_0105;
			}
			case 7:
			{
				goto IL_0165;
			}
		}
	}
	{
		return;
	}

IL_0033:
	{
		int32_t L_2 = __this->get_mState_8();
		if ((((int32_t)L_2) == ((int32_t)5)))
		{
			goto IL_004d;
		}
	}
	{
		bool L_3 = __this->get_mConferenceMode_5();
		if (!L_3)
		{
			goto IL_0097;
		}
	}
	{
		int32_t L_4 = __this->get_mState_8();
		if ((!(((uint32_t)L_4) == ((uint32_t)7))))
		{
			goto IL_0097;
		}
	}

IL_004d:
	{
		bool L_5 = __this->get_mConferenceMode_5();
		if (L_5)
		{
			goto IL_0060;
		}
	}
	{
		RuntimeObject* L_6 = __this->get_mNetwork_4();
		NullCheck(L_6);
		InterfaceActionInvoker0::Invoke(1 /* System.Void Byn.Awrtc.IBasicNetwork::StopServer() */, IBasicNetwork_t60318DADF4A0AF6F2063D0F7E9CE5611F6CB198D_il2cpp_TypeInfo_var, L_6);
	}

IL_0060:
	{
		__this->set_mState_8(7);
		List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * L_7 = __this->get_mConnectionIds_12();
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_8 = NetworkEvent_get_ConnectionId_m63ED1FC3B26ED68918F1395BA9D0EAF1306F2524((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		NullCheck(L_7);
		List_1_Add_mABE9CD5133D0735C8ECB22FAC67B02137BDCD6EA(L_7, L_8, /*hidden argument*/List_1_Add_mABE9CD5133D0735C8ECB22FAC67B02137BDCD6EA_RuntimeMethod_var);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_9 = NetworkEvent_get_ConnectionId_m63ED1FC3B26ED68918F1395BA9D0EAF1306F2524((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA * L_10 = (CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA *)il2cpp_codegen_object_new(CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA_il2cpp_TypeInfo_var);
		CallAcceptedEventArgs__ctor_m313593CBB34D49EC5E4A3F90FB0EB0069E4C1C9A(L_10, L_9, /*hidden argument*/NULL);
		AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC(__this, L_10, /*hidden argument*/NULL);
		bool L_11 = __this->get_mIsDisposed_9();
		if (!L_11)
		{
			goto IL_03c2;
		}
	}
	{
		return;
	}

IL_0097:
	{
		int32_t L_12 = __this->get_mState_8();
		if ((!(((uint32_t)L_12) == ((uint32_t)6))))
		{
			goto IL_00d7;
		}
	}
	{
		List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * L_13 = __this->get_mConnectionIds_12();
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_14 = NetworkEvent_get_ConnectionId_m63ED1FC3B26ED68918F1395BA9D0EAF1306F2524((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		NullCheck(L_13);
		List_1_Add_mABE9CD5133D0735C8ECB22FAC67B02137BDCD6EA(L_13, L_14, /*hidden argument*/List_1_Add_mABE9CD5133D0735C8ECB22FAC67B02137BDCD6EA_RuntimeMethod_var);
		__this->set_mState_8(7);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_15 = NetworkEvent_get_ConnectionId_m63ED1FC3B26ED68918F1395BA9D0EAF1306F2524((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA * L_16 = (CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA *)il2cpp_codegen_object_new(CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA_il2cpp_TypeInfo_var);
		CallAcceptedEventArgs__ctor_m313593CBB34D49EC5E4A3F90FB0EB0069E4C1C9A(L_16, L_15, /*hidden argument*/NULL);
		AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC(__this, L_16, /*hidden argument*/NULL);
		bool L_17 = __this->get_mIsDisposed_9();
		if (!L_17)
		{
			goto IL_03c2;
		}
	}
	{
		return;
	}

IL_00d7:
	{
		int32_t L_18 = __this->get_mState_8();
		int32_t L_19 = L_18;
		RuntimeObject * L_20 = Box(CallState_t4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_il2cpp_TypeInfo_var, &L_19);
		String_t* L_21 = String_Concat_mBB19C73816BDD1C3519F248E1ADC8E11A6FDB495(_stringLiteralF0DE57BC2779E3EA699DF1CEEF10793EFA55525E, L_20, /*hidden argument*/NULL);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_22 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)1);
		V_9 = L_22;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_23 = V_9;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		String_t* L_24 = ((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->get_LOGTAG_0();
		NullCheck(L_23);
		ArrayElementTypeCheck (L_23, L_24);
		(L_23)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_24);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_25 = V_9;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		SLog_LW_m4C1FD9091E37D07F12DFBDCE665962B60B7F2DE5(L_21, L_25, /*hidden argument*/NULL);
		return;
	}

IL_0105:
	{
		int32_t L_26 = __this->get_mState_8();
		if ((!(((uint32_t)L_26) == ((uint32_t)6))))
		{
			goto IL_0132;
		}
	}
	{
		ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * L_27 = NetworkEvent_get_ErrorInfo_m8AEF4E79F149ACDE34B56754A88ADA709AAD8D95((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246 * L_28 = (ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246 *)il2cpp_codegen_object_new(ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246_il2cpp_TypeInfo_var);
		ErrorEventArgs__ctor_m8BEABC103A358B03A2FF9F9D546B443FF579F366(L_28, 6, L_27, /*hidden argument*/NULL);
		AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC(__this, L_28, /*hidden argument*/NULL);
		bool L_29 = __this->get_mIsDisposed_9();
		if (!L_29)
		{
			goto IL_012a;
		}
	}
	{
		return;
	}

IL_012a:
	{
		__this->set_mState_8(3);
		return;
	}

IL_0132:
	{
		int32_t L_30 = __this->get_mState_8();
		int32_t L_31 = L_30;
		RuntimeObject * L_32 = Box(CallState_t4B78AF69D25385ECFDCCB906E80FDA2CFFF6D6CC_il2cpp_TypeInfo_var, &L_31);
		String_t* L_33 = String_Concat_m2E1F71C491D2429CC80A28745488FEA947BB7AAC(_stringLiteralA57963B8CBDC1274C9D2245EAB3570D076944944, L_32, _stringLiteral577C74D4CC7F1E0145B12836205C46B679541C11, /*hidden argument*/NULL);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_34 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)1);
		V_10 = L_34;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_35 = V_10;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		String_t* L_36 = ((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->get_LOGTAG_0();
		NullCheck(L_35);
		ArrayElementTypeCheck (L_35, L_36);
		(L_35)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_36);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_37 = V_10;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		SLog_LW_m4C1FD9091E37D07F12DFBDCE665962B60B7F2DE5(L_33, L_37, /*hidden argument*/NULL);
		return;
	}

IL_0165:
	{
		List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * L_38 = __this->get_mConnectionIds_12();
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_39 = NetworkEvent_get_ConnectionId_m63ED1FC3B26ED68918F1395BA9D0EAF1306F2524((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		NullCheck(L_38);
		bool L_40 = List_1_Contains_m337011847BDC37E80915E17BAFEB39C2F5FBD448(L_38, L_39, /*hidden argument*/List_1_Contains_m337011847BDC37E80915E17BAFEB39C2F5FBD448_RuntimeMethod_var);
		if (!L_40)
		{
			goto IL_03c2;
		}
	}
	{
		List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * L_41 = __this->get_mConnectionIds_12();
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_42 = NetworkEvent_get_ConnectionId_m63ED1FC3B26ED68918F1395BA9D0EAF1306F2524((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		NullCheck(L_41);
		List_1_Remove_mEB90299243C7D65EFFEC681D18CA1492DBA9A3A2(L_41, L_42, /*hidden argument*/List_1_Remove_mEB90299243C7D65EFFEC681D18CA1492DBA9A3A2_RuntimeMethod_var);
		bool L_43 = __this->get_mConferenceMode_5();
		if (L_43)
		{
			goto IL_01ab;
		}
	}
	{
		List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * L_44 = __this->get_mConnectionIds_12();
		NullCheck(L_44);
		int32_t L_45 = List_1_get_Count_m230B26A74F4411232759D13CD642C9B4FE621AD5(L_44, /*hidden argument*/List_1_get_Count_m230B26A74F4411232759D13CD642C9B4FE621AD5_RuntimeMethod_var);
		if (L_45)
		{
			goto IL_01ab;
		}
	}
	{
		__this->set_mState_8(8);
	}

IL_01ab:
	{
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_46 = NetworkEvent_get_ConnectionId_m63ED1FC3B26ED68918F1395BA9D0EAF1306F2524((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		CallEndedEventArgs_tE3A3B50FDE883A4D052920EB6073028ACFF81128 * L_47 = (CallEndedEventArgs_tE3A3B50FDE883A4D052920EB6073028ACFF81128 *)il2cpp_codegen_object_new(CallEndedEventArgs_tE3A3B50FDE883A4D052920EB6073028ACFF81128_il2cpp_TypeInfo_var);
		CallEndedEventArgs__ctor_m5C66FFEB0C34E59EB177FBDF82759A1F235ABE74(L_47, L_46, /*hidden argument*/NULL);
		AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC(__this, L_47, /*hidden argument*/NULL);
		bool L_48 = __this->get_mIsDisposed_9();
		if (!L_48)
		{
			goto IL_03c2;
		}
	}
	{
		return;
	}

IL_01c9:
	{
		__this->set_mServerInactive_11((bool)0);
		__this->set_mState_8(5);
		String_t* L_49 = NetworkEvent_get_Info_mA98458FF9FA0B252D18705DD6B1A3B17D9503E16((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		WaitForIncomingCallEventArgs_tD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86 * L_50 = (WaitForIncomingCallEventArgs_tD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86 *)il2cpp_codegen_object_new(WaitForIncomingCallEventArgs_tD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86_il2cpp_TypeInfo_var);
		WaitForIncomingCallEventArgs__ctor_m8A615252C226AD8065E43B233EA90820188AEE22(L_50, L_49, /*hidden argument*/NULL);
		AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC(__this, L_50, /*hidden argument*/NULL);
		bool L_51 = __this->get_mIsDisposed_9();
		if (!L_51)
		{
			goto IL_03c2;
		}
	}
	{
		return;
	}

IL_01f5:
	{
		__this->set_mServerInactive_11((bool)1);
		__this->set_mState_8(3);
		ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * L_52 = NetworkEvent_get_ErrorInfo_m8AEF4E79F149ACDE34B56754A88ADA709AAD8D95((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246 * L_53 = (ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246 *)il2cpp_codegen_object_new(ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246_il2cpp_TypeInfo_var);
		ErrorEventArgs__ctor_m8BEABC103A358B03A2FF9F9D546B443FF579F366(L_53, 7, L_52, /*hidden argument*/NULL);
		AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC(__this, L_53, /*hidden argument*/NULL);
		bool L_54 = __this->get_mIsDisposed_9();
		if (!L_54)
		{
			goto IL_03c2;
		}
	}
	{
		return;
	}

IL_0222:
	{
		__this->set_mServerInactive_11((bool)1);
		int32_t L_55 = __this->get_mState_8();
		if ((((int32_t)L_55) == ((int32_t)5)))
		{
			goto IL_023e;
		}
	}
	{
		int32_t L_56 = __this->get_mState_8();
		if ((!(((uint32_t)L_56) == ((uint32_t)4))))
		{
			goto IL_03c2;
		}
	}

IL_023e:
	{
		__this->set_mState_8(3);
		ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * L_57 = NetworkEvent_get_ErrorInfo_m8AEF4E79F149ACDE34B56754A88ADA709AAD8D95((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246 * L_58 = (ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246 *)il2cpp_codegen_object_new(ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246_il2cpp_TypeInfo_var);
		ErrorEventArgs__ctor_m8BEABC103A358B03A2FF9F9D546B443FF579F366(L_58, 7, L_57, /*hidden argument*/NULL);
		AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC(__this, L_58, /*hidden argument*/NULL);
		bool L_59 = __this->get_mIsDisposed_9();
		if (!L_59)
		{
			goto IL_03c2;
		}
	}
	{
		return;
	}

IL_0264:
	{
		RuntimeObject* L_60 = NetworkEvent_get_MessageData_m4E9F1B0D89F50E350EF0262187C7DE74ADCEED26((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_61 = MessageDataBufferExt_Copy_mA35B174D17F81FB2AB25399BDD5325CA8326E210(L_60, /*hidden argument*/NULL);
		V_0 = L_61;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_62 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		bool L_63 = AWebRtcCall_IsStringMsg_m7F45CD2616184B9739365F17F027461489F20882(L_62, /*hidden argument*/NULL);
		if (!L_63)
		{
			goto IL_0296;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_64 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		String_t* L_65 = AWebRtcCall_UnpackStringMsg_mF8138BBBD07AC8F11499A0CAEF32B842F658B804(L_64, /*hidden argument*/NULL);
		V_1 = L_65;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_66 = NetworkEvent_get_ConnectionId_m63ED1FC3B26ED68918F1395BA9D0EAF1306F2524((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		String_t* L_67 = V_1;
		MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899 * L_68 = (MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899 *)il2cpp_codegen_object_new(MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899_il2cpp_TypeInfo_var);
		MessageEventArgs__ctor_m3F3C0FE07EDBD02D58DE442EA60D74FBA9FBC1B8(L_68, L_66, L_67, (bool)1, /*hidden argument*/NULL);
		AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC(__this, L_68, /*hidden argument*/NULL);
		goto IL_02f6;
	}

IL_0296:
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_69 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		bool L_70 = AWebRtcCall_IsDataMsg_m91B5AB76EFE79A24690D9B83E5FCBBCB57C1E860(L_69, /*hidden argument*/NULL);
		if (!L_70)
		{
			goto IL_02bb;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_71 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_72 = AWebRtcCall_UnpackDataMsg_m86BF873565BFBC1B6E93DDF3BDB91994DA5BAFC7(L_71, /*hidden argument*/NULL);
		V_2 = L_72;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_73 = NetworkEvent_get_ConnectionId_m63ED1FC3B26ED68918F1395BA9D0EAF1306F2524((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_74 = V_2;
		DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37 * L_75 = (DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37 *)il2cpp_codegen_object_new(DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37_il2cpp_TypeInfo_var);
		DataMessageEventArgs__ctor_m0696EC373C208888C4E333D1FB9B99D52224A03A(L_75, L_73, L_74, (bool)1, /*hidden argument*/NULL);
		AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC(__this, L_75, /*hidden argument*/NULL);
		goto IL_02f6;
	}

IL_02bb:
	{
		V_3 = (uint8_t)((int32_t)255);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_76 = V_0;
		if (!L_76)
		{
			goto IL_02ce;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_77 = V_0;
		NullCheck(L_77);
		if ((((int32_t)(((int32_t)((int32_t)(((RuntimeArray *)L_77)->max_length))))) >= ((int32_t)0)))
		{
			goto IL_02ce;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_78 = V_0;
		NullCheck(L_78);
		int32_t L_79 = 0;
		uint8_t L_80 = (L_78)->GetAt(static_cast<il2cpp_array_size_t>(L_79));
		V_3 = L_80;
	}

IL_02ce:
	{
		uint8_t L_81 = V_3;
		uint8_t L_82 = L_81;
		RuntimeObject * L_83 = Box(Byte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_il2cpp_TypeInfo_var, &L_82);
		String_t* L_84 = String_Concat_mBB19C73816BDD1C3519F248E1ADC8E11A6FDB495(_stringLiteral3E81FC48A25FE5E253313F0757301CB954D9343C, L_83, /*hidden argument*/NULL);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_85 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)1);
		V_11 = L_85;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_86 = V_11;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		String_t* L_87 = ((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->get_LOGTAG_0();
		NullCheck(L_86);
		ArrayElementTypeCheck (L_86, L_87);
		(L_86)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_87);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_88 = V_11;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		SLog_LW_m4C1FD9091E37D07F12DFBDCE665962B60B7F2DE5(L_84, L_88, /*hidden argument*/NULL);
	}

IL_02f6:
	{
		RuntimeObject* L_89 = NetworkEvent_get_MessageData_m4E9F1B0D89F50E350EF0262187C7DE74ADCEED26((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		NullCheck(L_89);
		InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t7218B22548186B208D65EA5B7870503810A2D15A_il2cpp_TypeInfo_var, L_89);
		bool L_90 = __this->get_mIsDisposed_9();
		if (!L_90)
		{
			goto IL_03c2;
		}
	}
	{
		return;
	}

IL_030e:
	{
		RuntimeObject* L_91 = NetworkEvent_get_MessageData_m4E9F1B0D89F50E350EF0262187C7DE74ADCEED26((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_92 = MessageDataBufferExt_Copy_mA35B174D17F81FB2AB25399BDD5325CA8326E210(L_91, /*hidden argument*/NULL);
		V_4 = L_92;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_93 = V_4;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		bool L_94 = AWebRtcCall_IsStringMsg_m7F45CD2616184B9739365F17F027461489F20882(L_93, /*hidden argument*/NULL);
		if (!L_94)
		{
			goto IL_0345;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_95 = V_4;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		String_t* L_96 = AWebRtcCall_UnpackStringMsg_mF8138BBBD07AC8F11499A0CAEF32B842F658B804(L_95, /*hidden argument*/NULL);
		V_5 = L_96;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_97 = NetworkEvent_get_ConnectionId_m63ED1FC3B26ED68918F1395BA9D0EAF1306F2524((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		String_t* L_98 = V_5;
		MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899 * L_99 = (MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899 *)il2cpp_codegen_object_new(MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899_il2cpp_TypeInfo_var);
		MessageEventArgs__ctor_m3F3C0FE07EDBD02D58DE442EA60D74FBA9FBC1B8(L_99, L_97, L_98, (bool)0, /*hidden argument*/NULL);
		AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC(__this, L_99, /*hidden argument*/NULL);
		goto IL_03af;
	}

IL_0345:
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_100 = V_4;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		bool L_101 = AWebRtcCall_IsDataMsg_m91B5AB76EFE79A24690D9B83E5FCBBCB57C1E860(L_100, /*hidden argument*/NULL);
		if (!L_101)
		{
			goto IL_036e;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_102 = V_4;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_103 = AWebRtcCall_UnpackDataMsg_m86BF873565BFBC1B6E93DDF3BDB91994DA5BAFC7(L_102, /*hidden argument*/NULL);
		V_6 = L_103;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_104 = NetworkEvent_get_ConnectionId_m63ED1FC3B26ED68918F1395BA9D0EAF1306F2524((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_105 = V_6;
		DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37 * L_106 = (DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37 *)il2cpp_codegen_object_new(DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37_il2cpp_TypeInfo_var);
		DataMessageEventArgs__ctor_m0696EC373C208888C4E333D1FB9B99D52224A03A(L_106, L_104, L_105, (bool)0, /*hidden argument*/NULL);
		AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC(__this, L_106, /*hidden argument*/NULL);
		goto IL_03af;
	}

IL_036e:
	{
		V_7 = (uint8_t)((int32_t)255);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_107 = V_4;
		if (!L_107)
		{
			goto IL_0386;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_108 = V_4;
		NullCheck(L_108);
		if ((((int32_t)(((int32_t)((int32_t)(((RuntimeArray *)L_108)->max_length))))) >= ((int32_t)0)))
		{
			goto IL_0386;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_109 = V_4;
		NullCheck(L_109);
		int32_t L_110 = 0;
		uint8_t L_111 = (L_109)->GetAt(static_cast<il2cpp_array_size_t>(L_110));
		V_7 = L_111;
	}

IL_0386:
	{
		uint8_t L_112 = V_7;
		uint8_t L_113 = L_112;
		RuntimeObject * L_114 = Box(Byte_tF87C579059BD4633E6840EBBBEEF899C6E33EF07_il2cpp_TypeInfo_var, &L_113);
		String_t* L_115 = String_Concat_mBB19C73816BDD1C3519F248E1ADC8E11A6FDB495(_stringLiteral3E81FC48A25FE5E253313F0757301CB954D9343C, L_114, /*hidden argument*/NULL);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_116 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)1);
		V_12 = L_116;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_117 = V_12;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		String_t* L_118 = ((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->get_LOGTAG_0();
		NullCheck(L_117);
		ArrayElementTypeCheck (L_117, L_118);
		(L_117)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_118);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_119 = V_12;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		SLog_LW_m4C1FD9091E37D07F12DFBDCE665962B60B7F2DE5(L_115, L_119, /*hidden argument*/NULL);
	}

IL_03af:
	{
		RuntimeObject* L_120 = NetworkEvent_get_MessageData_m4E9F1B0D89F50E350EF0262187C7DE74ADCEED26((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		NullCheck(L_120);
		InterfaceActionInvoker0::Invoke(0 /* System.Void System.IDisposable::Dispose() */, IDisposable_t7218B22548186B208D65EA5B7870503810A2D15A_il2cpp_TypeInfo_var, L_120);
		bool L_121 = __this->get_mIsDisposed_9();
	}

IL_03c2:
	{
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::PendingCall(System.String)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_PendingCall_mEBF56D08C2A943272DB3DC82DEC2EFC06A628EE0 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, String_t* ___address0, const RuntimeMethod* method)
{
	{
		String_t* L_0 = ___address0;
		__this->set_mPendingAddress_15(L_0);
		__this->set_mPendingCallCall_14((bool)1);
		__this->set_mPendingListenCall_13((bool)0);
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::ProcessCall(System.String)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_ProcessCall_mB92C63DDC4A918A067FBC9B8AF077513BCE9D422 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, String_t* ___address0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_ProcessCall_mB92C63DDC4A918A067FBC9B8AF077513BCE9D422_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		__this->set_mState_8(6);
		RuntimeObject* L_0 = __this->get_mNetwork_4();
		String_t* L_1 = ___address0;
		NullCheck(L_0);
		InterfaceFuncInvoker1< ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D , String_t* >::Invoke(2 /* Byn.Awrtc.ConnectionId Byn.Awrtc.IBasicNetwork::Connect(System.String) */, IBasicNetwork_t60318DADF4A0AF6F2063D0F7E9CE5611F6CB198D_il2cpp_TypeInfo_var, L_0, L_1);
		AWebRtcCall_ClearPending_m9C48C1D3A5968688756647EFBAF7A598FBF9A005(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::PendingListen(System.String)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_PendingListen_m9CDA2D2ACE32708C21229DD92B30A0F98A35EF40 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, String_t* ___address0, const RuntimeMethod* method)
{
	{
		String_t* L_0 = ___address0;
		__this->set_mPendingAddress_15(L_0);
		__this->set_mPendingCallCall_14((bool)0);
		__this->set_mPendingListenCall_13((bool)1);
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::ProcessListen(System.String)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_ProcessListen_m753AF5E46F70C7EC3F1E425CA13C514A77A3954B (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, String_t* ___address0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_ProcessListen_m753AF5E46F70C7EC3F1E425CA13C514A77A3954B_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* V_0 = NULL;
	{
		String_t* L_0 = ___address0;
		String_t* L_1 = String_Concat_mB78D0094592718DA6D5DB6C712A9C225631666BE(_stringLiteral39821B36332CB979269AACCAF1482F406B96CAB9, L_0, /*hidden argument*/NULL);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_2 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)1);
		V_0 = L_2;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_3 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		String_t* L_4 = ((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->get_LOGTAG_0();
		NullCheck(L_3);
		ArrayElementTypeCheck (L_3, L_4);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_4);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_5 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		SLog_L_m2B84D1BE41D8BA16E73F6E952C5C17D7D2B686A1(L_1, L_5, /*hidden argument*/NULL);
		__this->set_mServerInactive_11((bool)0);
		__this->set_mState_8(4);
		RuntimeObject* L_6 = __this->get_mNetwork_4();
		String_t* L_7 = ___address0;
		NullCheck(L_6);
		InterfaceActionInvoker1< String_t* >::Invoke(0 /* System.Void Byn.Awrtc.IBasicNetwork::StartServer(System.String) */, IBasicNetwork_t60318DADF4A0AF6F2063D0F7E9CE5611F6CB198D_il2cpp_TypeInfo_var, L_6, L_7);
		AWebRtcCall_ClearPending_m9C48C1D3A5968688756647EFBAF7A598FBF9A005(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::DoPending()
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_DoPending_m91D500C5AFC6D6BF2B222DC22F842AA0BC5BBE50 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, const RuntimeMethod* method)
{
	{
		bool L_0 = __this->get_mPendingCallCall_14();
		if (!L_0)
		{
			goto IL_0016;
		}
	}
	{
		String_t* L_1 = __this->get_mPendingAddress_15();
		AWebRtcCall_ProcessCall_mB92C63DDC4A918A067FBC9B8AF077513BCE9D422(__this, L_1, /*hidden argument*/NULL);
		goto IL_002a;
	}

IL_0016:
	{
		bool L_2 = __this->get_mPendingListenCall_13();
		if (!L_2)
		{
			goto IL_002a;
		}
	}
	{
		String_t* L_3 = __this->get_mPendingAddress_15();
		AWebRtcCall_ProcessListen_m753AF5E46F70C7EC3F1E425CA13C514A77A3954B(__this, L_3, /*hidden argument*/NULL);
	}

IL_002a:
	{
		AWebRtcCall_ClearPending_m9C48C1D3A5968688756647EFBAF7A598FBF9A005(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::ClearPending()
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_ClearPending_m9C48C1D3A5968688756647EFBAF7A598FBF9A005 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, const RuntimeMethod* method)
{
	{
		__this->set_mPendingAddress_15((String_t*)NULL);
		__this->set_mPendingCallCall_14((bool)0);
		__this->set_mPendingListenCall_13((bool)0);
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::CheckDisposed()
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_CheckDisposed_mD7EE6F33F9906A26C6CB83B0D103F50D9542F90B (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_CheckDisposed_mD7EE6F33F9906A26C6CB83B0D103F50D9542F90B_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0 = __this->get_mIsDisposed_9();
		if (!L_0)
		{
			goto IL_0013;
		}
	}
	{
		InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 * L_1 = (InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 *)il2cpp_codegen_object_new(InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m72027D5F1D513C25C05137E203EEED8FD8297706(L_1, _stringLiteral5B16BDBC5F99BD61B95D7D712F8F8CAE8AE1F036, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, AWebRtcCall_CheckDisposed_mD7EE6F33F9906A26C6CB83B0D103F50D9542F90B_RuntimeMethod_var);
	}

IL_0013:
	{
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::EnsureConfiguration()
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_EnsureConfiguration_mAE816DED202FC4344ECF0EFE83E886024340C82C (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_EnsureConfiguration_mAE816DED202FC4344ECF0EFE83E886024340C82C_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* V_0 = NULL;
	{
		int32_t L_0 = __this->get_mState_8();
		if ((!(((uint32_t)L_0) == ((uint32_t)1))))
		{
			goto IL_002e;
		}
	}
	{
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_1 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)1);
		V_0 = L_1;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_2 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		String_t* L_3 = ((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->get_LOGTAG_0();
		NullCheck(L_2);
		ArrayElementTypeCheck (L_2, L_3);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_3);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_4 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		SLog_LW_m4C1FD9091E37D07F12DFBDCE665962B60B7F2DE5(_stringLiteralD6160886EE4A4BC933529D59B510F8DAE55E981C, L_4, /*hidden argument*/NULL);
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_5 = (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D *)il2cpp_codegen_object_new(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D_il2cpp_TypeInfo_var);
		MediaConfig__ctor_m9F57DF2DA5B07EAEA3FD116B734412547CF95C50(L_5, /*hidden argument*/NULL);
		VirtActionInvoker1< MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * >::Invoke(18 /* System.Void Byn.Awrtc.Base.AWebRtcCall::Configure(Byn.Awrtc.MediaConfig) */, __this, L_5);
	}

IL_002e:
	{
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::TriggerCallEvent(Byn.Awrtc.CallEventArgs)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * ___args0, const RuntimeMethod* method)
{
	{
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_0 = __this->get_CallEvent_3();
		if (!L_0)
		{
			goto IL_0015;
		}
	}
	{
		CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * L_1 = __this->get_CallEvent_3();
		CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * L_2 = ___args0;
		NullCheck(L_1);
		CallEventHandler_Invoke_m4E24EBFA859C707089DF4C71DD8359DC0635B6B1(L_1, __this, L_2, /*hidden argument*/NULL);
	}

IL_0015:
	{
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::OnConfigurationComplete()
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_OnConfigurationComplete_mF6BED2C9B6EEF93AE305B540A32234F734B8016E (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_OnConfigurationComplete_mF6BED2C9B6EEF93AE305B540A32234F734B8016E_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* V_0 = NULL;
	{
		bool L_0 = __this->get_mIsDisposed_9();
		if (!L_0)
		{
			goto IL_0009;
		}
	}
	{
		return;
	}

IL_0009:
	{
		__this->set_mState_8(3);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_1 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)1);
		V_0 = L_1;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_2 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		String_t* L_3 = ((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->get_LOGTAG_0();
		NullCheck(L_2);
		ArrayElementTypeCheck (L_2, L_3);
		(L_2)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_3);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_4 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		SLog_L_m2B84D1BE41D8BA16E73F6E952C5C17D7D2B686A1(_stringLiteral4C4E1AF40C023378252CB1E58AA124872F84B2AB, L_4, /*hidden argument*/NULL);
		CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * L_5 = (CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 *)il2cpp_codegen_object_new(CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0_il2cpp_TypeInfo_var);
		CallEventArgs__ctor_m4ED27A352EC2D4A66D78EEE46EE96B30F119ACCD(L_5, 8, /*hidden argument*/NULL);
		AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC(__this, L_5, /*hidden argument*/NULL);
		bool L_6 = __this->get_mIsDisposed_9();
		if (L_6)
		{
			goto IL_0044;
		}
	}
	{
		AWebRtcCall_DoPending_m91D500C5AFC6D6BF2B222DC22F842AA0BC5BBE50(__this, /*hidden argument*/NULL);
	}

IL_0044:
	{
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::OnConfigurationFailed(System.String)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_OnConfigurationFailed_mCF1E7B2727703A3A0232C3528F5E3C1B766F0E8D (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, String_t* ___error0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_OnConfigurationFailed_mCF1E7B2727703A3A0232C3528F5E3C1B766F0E8D_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* V_0 = NULL;
	{
		String_t* L_0 = ___error0;
		String_t* L_1 = String_Concat_mB78D0094592718DA6D5DB6C712A9C225631666BE(_stringLiteralF8AA003D2600245E6F801C7DC7450EEC623397E9, L_0, /*hidden argument*/NULL);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_2 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)1);
		V_0 = L_2;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_3 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		String_t* L_4 = ((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->get_LOGTAG_0();
		NullCheck(L_3);
		ArrayElementTypeCheck (L_3, L_4);
		(L_3)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_4);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_5 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		SLog_LW_m4C1FD9091E37D07F12DFBDCE665962B60B7F2DE5(L_1, L_5, /*hidden argument*/NULL);
		bool L_6 = __this->get_mIsDisposed_9();
		if (!L_6)
		{
			goto IL_0029;
		}
	}
	{
		return;
	}

IL_0029:
	{
		__this->set_mState_8(1);
		String_t* L_7 = ___error0;
		ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * L_8 = (ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 *)il2cpp_codegen_object_new(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var);
		ErrorInfo__ctor_m48716C55A898B5D004BF029D7246647CD5B4B23D(L_8, L_7, /*hidden argument*/NULL);
		ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246 * L_9 = (ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246 *)il2cpp_codegen_object_new(ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246_il2cpp_TypeInfo_var);
		ErrorEventArgs__ctor_m8BEABC103A358B03A2FF9F9D546B443FF579F366(L_9, ((int32_t)9), L_8, /*hidden argument*/NULL);
		AWebRtcCall_TriggerCallEvent_m1A63253FC3511CC77126B3ADE31C7A6F025F37BC(__this, L_9, /*hidden argument*/NULL);
		bool L_10 = __this->get_mIsDisposed_9();
		if (L_10)
		{
			goto IL_0051;
		}
	}
	{
		AWebRtcCall_ClearPending_m9C48C1D3A5968688756647EFBAF7A598FBF9A005(__this, /*hidden argument*/NULL);
	}

IL_0051:
	{
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::Dispose(System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_Dispose_m57B176D546CC11CD3C081E36DB47F0C9DDBAF853 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, bool ___disposing0, const RuntimeMethod* method)
{
	{
		bool L_0 = __this->get_mIsDisposed_9();
		if (L_0)
		{
			goto IL_0011;
		}
	}
	{
		bool L_1 = ___disposing0;
		__this->set_mIsDisposed_9((bool)1);
	}

IL_0011:
	{
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::Dispose()
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_Dispose_m3A2F7F4EE8A114A06BACAF11D876254C06B22A94 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, const RuntimeMethod* method)
{
	{
		VirtActionInvoker1< bool >::Invoke(25 /* System.Void Byn.Awrtc.Base.AWebRtcCall::Dispose(System.Boolean) */, __this, (bool)1);
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::SetVolume(System.Double,Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_SetVolume_m0DC6CA614675820CC0E3CA770ABB01D6E7314E06 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, double ___volume0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___remoteUserId1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_SetVolume_m0DC6CA614675820CC0E3CA770ABB01D6E7314E06_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* V_0 = NULL;
	{
		RuntimeObject* L_0 = __this->get_mNetwork_4();
		if (!L_0)
		{
			goto IL_0016;
		}
	}
	{
		RuntimeObject* L_1 = __this->get_mNetwork_4();
		double L_2 = ___volume0;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_3 = ___remoteUserId1;
		NullCheck(L_1);
		InterfaceActionInvoker2< double, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  >::Invoke(5 /* System.Void Byn.Awrtc.IMediaNetwork::SetVolume(System.Double,Byn.Awrtc.ConnectionId) */, IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780_il2cpp_TypeInfo_var, L_1, L_2, L_3);
		return;
	}

IL_0016:
	{
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_4 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)1);
		V_0 = L_4;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_5 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var);
		String_t* L_6 = ((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->get_LOGTAG_0();
		NullCheck(L_5);
		ArrayElementTypeCheck (L_5, L_6);
		(L_5)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_6);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_7 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		SLog_LW_m4C1FD9091E37D07F12DFBDCE665962B60B7F2DE5(_stringLiteral0A9602F009430E7B9AB88CAE301B9EDE3D4C606E, L_7, /*hidden argument*/NULL);
		return;
	}
}
// System.Boolean Byn.Awrtc.Base.AWebRtcCall::HasAudioTrack(Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR bool AWebRtcCall_HasAudioTrack_m6FF8B27547640444A150CBC4CD1563F8B485FEDF (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___remoteUserId0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_HasAudioTrack_m6FF8B27547640444A150CBC4CD1563F8B485FEDF_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject* L_0 = __this->get_mNetwork_4();
		if (!L_0)
		{
			goto IL_0015;
		}
	}
	{
		RuntimeObject* L_1 = __this->get_mNetwork_4();
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_2 = ___remoteUserId0;
		NullCheck(L_1);
		bool L_3 = InterfaceFuncInvoker1< bool, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  >::Invoke(6 /* System.Boolean Byn.Awrtc.IMediaNetwork::HasAudioTrack(Byn.Awrtc.ConnectionId) */, IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780_il2cpp_TypeInfo_var, L_1, L_2);
		return L_3;
	}

IL_0015:
	{
		return (bool)0;
	}
}
// System.Boolean Byn.Awrtc.Base.AWebRtcCall::HasVideoTrack(Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR bool AWebRtcCall_HasVideoTrack_m612410BE7D65CADC97140DADD188D51EDC5C74A5 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___remoteUserId0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_HasVideoTrack_m612410BE7D65CADC97140DADD188D51EDC5C74A5_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject* L_0 = __this->get_mNetwork_4();
		if (!L_0)
		{
			goto IL_0015;
		}
	}
	{
		RuntimeObject* L_1 = __this->get_mNetwork_4();
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_2 = ___remoteUserId0;
		NullCheck(L_1);
		bool L_3 = InterfaceFuncInvoker1< bool, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  >::Invoke(7 /* System.Boolean Byn.Awrtc.IMediaNetwork::HasVideoTrack(Byn.Awrtc.ConnectionId) */, IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780_il2cpp_TypeInfo_var, L_1, L_2);
		return L_3;
	}

IL_0015:
	{
		return (bool)0;
	}
}
// System.Boolean Byn.Awrtc.Base.AWebRtcCall::IsMute()
extern "C" IL2CPP_METHOD_ATTR bool AWebRtcCall_IsMute_m82735D1F5EBE8EA88E0B20B1C15BFD057E1799AC (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_IsMute_m82735D1F5EBE8EA88E0B20B1C15BFD057E1799AC_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject* L_0 = __this->get_mNetwork_4();
		if (!L_0)
		{
			goto IL_0014;
		}
	}
	{
		RuntimeObject* L_1 = __this->get_mNetwork_4();
		NullCheck(L_1);
		bool L_2 = InterfaceFuncInvoker0< bool >::Invoke(8 /* System.Boolean Byn.Awrtc.IMediaNetwork::IsMute() */, IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780_il2cpp_TypeInfo_var, L_1);
		return L_2;
	}

IL_0014:
	{
		return (bool)1;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::SetMute(System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall_SetMute_mC804CF0F1CBC2F7599A84B9063541D50B0A57A15 (AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3 * __this, bool ___val0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall_SetMute_mC804CF0F1CBC2F7599A84B9063541D50B0A57A15_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject* L_0 = __this->get_mNetwork_4();
		if (!L_0)
		{
			goto IL_0014;
		}
	}
	{
		RuntimeObject* L_1 = __this->get_mNetwork_4();
		bool L_2 = ___val0;
		NullCheck(L_1);
		InterfaceActionInvoker1< bool >::Invoke(9 /* System.Void Byn.Awrtc.IMediaNetwork::SetMute(System.Boolean) */, IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780_il2cpp_TypeInfo_var, L_1, L_2);
	}

IL_0014:
	{
		return;
	}
}
// System.Void Byn.Awrtc.Base.AWebRtcCall::.cctor()
extern "C" IL2CPP_METHOD_ATTR void AWebRtcCall__cctor_m2451B853A8F1A96A5CA5A77F1BCD706ECB94DF1D (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AWebRtcCall__cctor_m2451B853A8F1A96A5CA5A77F1BCD706ECB94DF1D_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->set_LOGTAG_0(_stringLiteral9D5DBE197A12DFB5E663F3779A1CEB136F2EEBA2);
		((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->set_MESSAGE_TYPE_DATA_6((uint8_t)1);
		((AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_StaticFields*)il2cpp_codegen_static_fields_for(AWebRtcCall_t8643A5C98F146CCA1CACDB911820319270507AD3_il2cpp_TypeInfo_var))->set_MESSAGE_TYPE_STRING_7((uint8_t)2);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Byte[] Byn.Awrtc.BufferedFrame::get_Buffer()
extern "C" IL2CPP_METHOD_ATTR ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* BufferedFrame_get_Buffer_mAE0ABEE3EEB522AA01F1F340AF5BA298C1A8FB6C (BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028 * __this, const RuntimeMethod* method)
{
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_0 = __this->get_mBuffer_0();
		return L_0;
	}
}
// System.Int32 Byn.Awrtc.BufferedFrame::get_Width()
extern "C" IL2CPP_METHOD_ATTR int32_t BufferedFrame_get_Width_m72C73F4EA72CAEB75935EE8AC5D2DABED85CF715 (BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_mWidth_1();
		return L_0;
	}
}
// System.Int32 Byn.Awrtc.BufferedFrame::get_Height()
extern "C" IL2CPP_METHOD_ATTR int32_t BufferedFrame_get_Height_m998CD32662B7B6C6E843E19464D1F47CDE9B8590 (BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_mHeight_2();
		return L_0;
	}
}
// System.Int32 Byn.Awrtc.BufferedFrame::get_Rotation()
extern "C" IL2CPP_METHOD_ATTR int32_t BufferedFrame_get_Rotation_m7C3C0038C644484BB517B4C63A441AEF18C2C947 (BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_mRotation_3();
		return L_0;
	}
}
// System.Void Byn.Awrtc.BufferedFrame::set_Rotation(System.Int32)
extern "C" IL2CPP_METHOD_ATTR void BufferedFrame_set_Rotation_m0E114C8C8ABC472DF03C47233D39F4978D5C7E50 (BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028 * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___value0;
		__this->set_mRotation_3(L_0);
		return;
	}
}
// Byn.Awrtc.FramePixelFormat Byn.Awrtc.BufferedFrame::get_Format()
extern "C" IL2CPP_METHOD_ATTR int32_t BufferedFrame_get_Format_m816E89BAEDCF11F2EC5C8A5BA850DA4FD2B7C2D9 (BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_mFormat_5();
		return L_0;
	}
}
// System.Void Byn.Awrtc.BufferedFrame::.ctor(System.Byte[],System.Int32,System.Int32,Byn.Awrtc.FramePixelFormat,System.Int32,System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void BufferedFrame__ctor_m887D4B7F3371309EBFCAF5CD7FFF85459F223071 (BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028 * __this, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___buffer0, int32_t ___width1, int32_t ___height2, int32_t ___format3, int32_t ___rotation4, bool ___isTopRowFirst5, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_0 = ___buffer0;
		__this->set_mBuffer_0(L_0);
		int32_t L_1 = ___width1;
		__this->set_mWidth_1(L_1);
		int32_t L_2 = ___height2;
		__this->set_mHeight_2(L_2);
		int32_t L_3 = ___rotation4;
		__this->set_mRotation_3(L_3);
		int32_t L_4 = ___format3;
		__this->set_mFormat_5(L_4);
		bool L_5 = ___isTopRowFirst5;
		__this->set_mTopRowFirst_4(L_5);
		return;
	}
}
// System.Void Byn.Awrtc.BufferedFrame::Dispose()
extern "C" IL2CPP_METHOD_ATTR void BufferedFrame_Dispose_m60511244D7ABFC342044E26E69CA6C9E239075C6 (BufferedFrame_tAFC3F736E124573A402343AB673AAF8EB53E0028 * __this, const RuntimeMethod* method)
{
	{
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Int32 Byn.Awrtc.ByteArrayBuffer::get_PositionWriteRelative()
extern "C" IL2CPP_METHOD_ATTR int32_t ByteArrayBuffer_get_PositionWriteRelative_m5BA1493019330918106D5CB819DEAD7FCC62B987 (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_positionWrite_3();
		return L_0;
	}
}
// System.Void Byn.Awrtc.ByteArrayBuffer::set_PositionWriteRelative(System.Int32)
extern "C" IL2CPP_METHOD_ATTR void ByteArrayBuffer_set_PositionWriteRelative_m934AA17DAF8473055C81A696C548D40EB8573C4D (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___value0;
		__this->set_positionWrite_3(L_0);
		return;
	}
}
// System.Int32 Byn.Awrtc.ByteArrayBuffer::get_PositionWriteAbsolute()
extern "C" IL2CPP_METHOD_ATTR int32_t ByteArrayBuffer_get_PositionWriteAbsolute_m1E594C7A0C8E7051D4EB302510851064471D4D9D (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_positionWrite_3();
		int32_t L_1 = __this->get_offset_5();
		return ((int32_t)il2cpp_codegen_add((int32_t)L_0, (int32_t)L_1));
	}
}
// System.Int32 Byn.Awrtc.ByteArrayBuffer::get_PositionReadRelative()
extern "C" IL2CPP_METHOD_ATTR int32_t ByteArrayBuffer_get_PositionReadRelative_m0E958B7F3E5C4BA2A813CC0B243B1441FDE7B044 (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_positionRead_4();
		return L_0;
	}
}
// System.Int32 Byn.Awrtc.ByteArrayBuffer::get_Offset()
extern "C" IL2CPP_METHOD_ATTR int32_t ByteArrayBuffer_get_Offset_m8DD0FD9586C6A3D4B70A82EF5E3B5AF9AF0A59A3 (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_offset_5();
		return L_0;
	}
}
// System.Byte[] Byn.Awrtc.ByteArrayBuffer::get_Buffer()
extern "C" IL2CPP_METHOD_ATTR ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ByteArrayBuffer_get_Buffer_mEA87A81D37582411E6A368A0E111DF7BF394433F (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ByteArrayBuffer_get_Buffer_mEA87A81D37582411E6A368A0E111DF7BF394433F_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0 = __this->get_mDisposed_7();
		if (!L_0)
		{
			goto IL_0013;
		}
	}
	{
		InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 * L_1 = (InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 *)il2cpp_codegen_object_new(InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m72027D5F1D513C25C05137E203EEED8FD8297706(L_1, _stringLiteral00BA3C9A92109B36A8FFDBA4A8323A8E89412FCC, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, ByteArrayBuffer_get_Buffer_mEA87A81D37582411E6A368A0E111DF7BF394433F_RuntimeMethod_var);
	}

IL_0013:
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_2 = __this->get_array_2();
		return L_2;
	}
}
// System.Int32 Byn.Awrtc.ByteArrayBuffer::get_ContentLength()
extern "C" IL2CPP_METHOD_ATTR int32_t ByteArrayBuffer_get_ContentLength_m7F0CA8BE74E0EE3AEDE7B8BBF797F8709E1307EF (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ByteArrayBuffer_get_ContentLength_m7F0CA8BE74E0EE3AEDE7B8BBF797F8709E1307EF_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0 = __this->get_mDisposed_7();
		if (!L_0)
		{
			goto IL_0013;
		}
	}
	{
		InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 * L_1 = (InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 *)il2cpp_codegen_object_new(InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m72027D5F1D513C25C05137E203EEED8FD8297706(L_1, _stringLiteral00BA3C9A92109B36A8FFDBA4A8323A8E89412FCC, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, ByteArrayBuffer_get_ContentLength_m7F0CA8BE74E0EE3AEDE7B8BBF797F8709E1307EF_RuntimeMethod_var);
	}

IL_0013:
	{
		int32_t L_2 = __this->get_positionWrite_3();
		return L_2;
	}
}
// System.Void Byn.Awrtc.ByteArrayBuffer::set_ContentLength(System.Int32)
extern "C" IL2CPP_METHOD_ATTR void ByteArrayBuffer_set_ContentLength_m42A5853389EB22773CDC672D262EFAE690CC1762 (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___value0;
		__this->set_positionWrite_3(L_0);
		return;
	}
}
// System.Void Byn.Awrtc.ByteArrayBuffer::.ctor(System.Int32)
extern "C" IL2CPP_METHOD_ATTR void ByteArrayBuffer__ctor_mCE37F5382D4D067550B5BBB53DB62B4C98EE3B09 (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, int32_t ___size0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ByteArrayBuffer__ctor_mCE37F5382D4D067550B5BBB53DB62B4C98EE3B09_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		__this->set_mFromPool_6((bool)1);
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		__this->set_mFromPool_6((bool)1);
		int32_t L_0 = ___size0;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_1 = (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*)SZArrayNew(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821_il2cpp_TypeInfo_var, (uint32_t)L_0);
		__this->set_array_2(L_1);
		__this->set_offset_5(0);
		__this->set_positionWrite_3(0);
		__this->set_positionRead_4(0);
		return;
	}
}
// System.Void Byn.Awrtc.ByteArrayBuffer::.ctor(System.Byte[],System.Int32,System.Int32)
extern "C" IL2CPP_METHOD_ATTR void ByteArrayBuffer__ctor_mE319DCE9AD7531B26B329588DB84CD61A4E8D562 (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___arr0, int32_t ___offset1, int32_t ___length2, const RuntimeMethod* method)
{
	{
		__this->set_mFromPool_6((bool)1);
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		__this->set_mFromPool_6((bool)0);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_0 = ___arr0;
		__this->set_array_2(L_0);
		int32_t L_1 = ___offset1;
		__this->set_offset_5(L_1);
		__this->set_positionRead_4(0);
		int32_t L_2 = ___length2;
		__this->set_positionWrite_3(L_2);
		return;
	}
}
// System.Void Byn.Awrtc.ByteArrayBuffer::Reset()
extern "C" IL2CPP_METHOD_ATTR void ByteArrayBuffer_Reset_m375E1E454C447037210ACFEC6D1C5C769DD54448 (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, const RuntimeMethod* method)
{
	{
		__this->set_mDisposed_7((bool)0);
		__this->set_positionRead_4(0);
		__this->set_positionWrite_3(0);
		return;
	}
}
// System.Void Byn.Awrtc.ByteArrayBuffer::Finalize()
extern "C" IL2CPP_METHOD_ATTR void ByteArrayBuffer_Finalize_m330A155A6CCCBB66AE776C1A73E29870250A58FC (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ByteArrayBuffer_Finalize_m330A155A6CCCBB66AE776C1A73E29870250A58FC_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 1);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);

IL_0000:
	try
	{ // begin try (depth: 1)
		{
			bool L_0 = __this->get_mDisposed_7();
			if (L_0)
			{
				goto IL_0027;
			}
		}

IL_0008:
		{
			bool L_1 = __this->get_mFromPool_6();
			if (!L_1)
			{
				goto IL_0027;
			}
		}

IL_0010:
		{
			IL2CPP_RUNTIME_CLASS_INIT(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var);
			bool L_2 = ((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields*)il2cpp_codegen_static_fields_for(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var))->get_LOG_GC_CALLS_1();
			if (!L_2)
			{
				goto IL_0027;
			}
		}

IL_0017:
		{
			StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_3 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)0);
			IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
			SLog_LW_m4C1FD9091E37D07F12DFBDCE665962B60B7F2DE5(_stringLiteral96E7E1D2A7678CA34E5FC0D0081CAAE74A18C363, L_3, /*hidden argument*/NULL);
		}

IL_0027:
		{
			IL2CPP_LEAVE(0x30, FINALLY_0029);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_0029;
	}

FINALLY_0029:
	{ // begin finally (depth: 1)
		Object_Finalize_m4015B7D3A44DE125C5FE34D7276CD4697C06F380(__this, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(41)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(41)
	{
		IL2CPP_JUMP_TBL(0x30, IL_0030)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
	}

IL_0030:
	{
		return;
	}
}
// System.Void Byn.Awrtc.ByteArrayBuffer::CopyFrom(System.Byte[],System.Int32,System.Int32)
extern "C" IL2CPP_METHOD_ATTR void ByteArrayBuffer_CopyFrom_mEF2A576FF26FA7A4FD0A4EEB865770FC72DEDD94 (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___arr0, int32_t ___srcOffset1, int32_t ___len2, const RuntimeMethod* method)
{
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_0 = ___arr0;
		int32_t L_1 = ___srcOffset1;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_2 = __this->get_array_2();
		int32_t L_3 = __this->get_offset_5();
		int32_t L_4 = ___len2;
		Buffer_BlockCopy_m1F882D595976063718AF6E405664FC761924D353((RuntimeArray *)(RuntimeArray *)L_0, L_1, (RuntimeArray *)(RuntimeArray *)L_2, L_3, L_4, /*hidden argument*/NULL);
		int32_t L_5 = ___len2;
		__this->set_positionWrite_3(L_5);
		return;
	}
}
// System.Void Byn.Awrtc.ByteArrayBuffer::.cctor()
extern "C" IL2CPP_METHOD_ATTR void ByteArrayBuffer__cctor_m57B126CF5D1E4BAD8FE7382DD4F86F94A8616C7E (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ByteArrayBuffer__cctor_m57B126CF5D1E4BAD8FE7382DD4F86F94A8616C7E_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* V_1 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 1);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* L_0 = (List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592*)SZArrayNew(List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592_il2cpp_TypeInfo_var, (uint32_t)((int32_t)32));
		((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields*)il2cpp_codegen_static_fields_for(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var))->set_sPool_0(L_0);
		((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields*)il2cpp_codegen_static_fields_for(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var))->set_LOG_GC_CALLS_1((bool)0);
		Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* L_1 = (Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83*)SZArrayNew(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83_il2cpp_TypeInfo_var, (uint32_t)((int32_t)32));
		Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* L_2 = L_1;
		RuntimeFieldHandle_t844BDF00E8E6FE69D9AEAA7657F09018B864F4EF  L_3 = { reinterpret_cast<intptr_t> (U3CPrivateImplementationDetailsU3EU7B3ED22892U2D411BU2D4C87U2DAEEBU2D15266737E930U7D_t0EF491E7C6CA3D3B0D052D94577A25F2983BB080____U24U24method0x6000054U2D1_0_FieldInfo_var) };
		RuntimeHelpers_InitializeArray_m29F50CDFEEE0AB868200291366253DD4737BC76A((RuntimeArray *)(RuntimeArray *)L_2, L_3, /*hidden argument*/NULL);
		((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields*)il2cpp_codegen_static_fields_for(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var))->set_MultiplyDeBruijnBitPosition_8(L_2);
		List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* L_4 = ((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields*)il2cpp_codegen_static_fields_for(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var))->get_sPool_0();
		List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* L_5 = L_4;
		V_1 = L_5;
		Monitor_Enter_m903755FCC479745619842CCDBF5E6355319FA102((RuntimeObject *)(RuntimeObject *)L_5, /*hidden argument*/NULL);
	}

IL_0035:
	try
	{ // begin try (depth: 1)
		{
			V_0 = 0;
			goto IL_0049;
		}

IL_0039:
		{
			List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* L_6 = ((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields*)il2cpp_codegen_static_fields_for(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var))->get_sPool_0();
			int32_t L_7 = V_0;
			List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * L_8 = (List_1_t43B2D37CF48E04673A48558029581722DDF26F4E *)il2cpp_codegen_object_new(List_1_t43B2D37CF48E04673A48558029581722DDF26F4E_il2cpp_TypeInfo_var);
			List_1__ctor_mC195748161C754C648AB7B1E192547FCFAAE5793(L_8, /*hidden argument*/List_1__ctor_mC195748161C754C648AB7B1E192547FCFAAE5793_RuntimeMethod_var);
			NullCheck(L_6);
			ArrayElementTypeCheck (L_6, L_8);
			(L_6)->SetAt(static_cast<il2cpp_array_size_t>(L_7), (List_1_t43B2D37CF48E04673A48558029581722DDF26F4E *)L_8);
			int32_t L_9 = V_0;
			V_0 = ((int32_t)il2cpp_codegen_add((int32_t)L_9, (int32_t)1));
		}

IL_0049:
		{
			int32_t L_10 = V_0;
			List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* L_11 = ((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields*)il2cpp_codegen_static_fields_for(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var))->get_sPool_0();
			NullCheck(L_11);
			if ((((int32_t)L_10) < ((int32_t)(((int32_t)((int32_t)(((RuntimeArray *)L_11)->max_length)))))))
			{
				goto IL_0039;
			}
		}

IL_0053:
		{
			IL2CPP_LEAVE(0x5C, FINALLY_0055);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_0055;
	}

FINALLY_0055:
	{ // begin finally (depth: 1)
		List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* L_12 = V_1;
		Monitor_Exit_m49A1E5356D984D0B934BB97A305E2E5E207225C2((RuntimeObject *)(RuntimeObject *)L_12, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(85)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(85)
	{
		IL2CPP_JUMP_TBL(0x5C, IL_005c)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
	}

IL_005c:
	{
		return;
	}
}
// System.Int32 Byn.Awrtc.ByteArrayBuffer::GetPower(System.UInt32)
extern "C" IL2CPP_METHOD_ATTR int32_t ByteArrayBuffer_GetPower_m16CF6A82A1F8D26A5882179C21617A3960CA7F82 (uint32_t ___anyPowerOfTwo0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ByteArrayBuffer_GetPower_m16CF6A82A1F8D26A5882179C21617A3960CA7F82_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	uint32_t V_0 = 0;
	{
		uint32_t L_0 = ___anyPowerOfTwo0;
		V_0 = ((int32_t)((uint32_t)((int32_t)il2cpp_codegen_multiply((int32_t)L_0, (int32_t)((int32_t)125613361)))>>((int32_t)27)));
		IL2CPP_RUNTIME_CLASS_INIT(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var);
		Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* L_1 = ((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields*)il2cpp_codegen_static_fields_for(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var))->get_MultiplyDeBruijnBitPosition_8();
		uint32_t L_2 = V_0;
		NullCheck(L_1);
		uint32_t L_3 = L_2;
		int32_t L_4 = (L_1)->GetAt(static_cast<il2cpp_array_size_t>(L_3));
		return L_4;
	}
}
// System.UInt32 Byn.Awrtc.ByteArrayBuffer::NextPowerOfTwo(System.UInt32)
extern "C" IL2CPP_METHOD_ATTR uint32_t ByteArrayBuffer_NextPowerOfTwo_m799FA4F6BC6E6ADE97AC651BE4BF457EF7A150DA (uint32_t ___v0, const RuntimeMethod* method)
{
	{
		uint32_t L_0 = ___v0;
		uint32_t L_1 = ___v0;
		___v0 = ((int32_t)((int32_t)L_0|(int32_t)((int32_t)((uint32_t)L_1>>1))));
		uint32_t L_2 = ___v0;
		uint32_t L_3 = ___v0;
		___v0 = ((int32_t)((int32_t)L_2|(int32_t)((int32_t)((uint32_t)L_3>>2))));
		uint32_t L_4 = ___v0;
		uint32_t L_5 = ___v0;
		___v0 = ((int32_t)((int32_t)L_4|(int32_t)((int32_t)((uint32_t)L_5>>4))));
		uint32_t L_6 = ___v0;
		uint32_t L_7 = ___v0;
		___v0 = ((int32_t)((int32_t)L_6|(int32_t)((int32_t)((uint32_t)L_7>>8))));
		uint32_t L_8 = ___v0;
		uint32_t L_9 = ___v0;
		___v0 = ((int32_t)((int32_t)L_8|(int32_t)((int32_t)((uint32_t)L_9>>((int32_t)16)))));
		uint32_t L_10 = ___v0;
		___v0 = ((int32_t)il2cpp_codegen_add((int32_t)L_10, (int32_t)1));
		uint32_t L_11 = ___v0;
		return L_11;
	}
}
// Byn.Awrtc.ByteArrayBuffer Byn.Awrtc.ByteArrayBuffer::Get(System.Int32,System.Boolean)
extern "C" IL2CPP_METHOD_ATTR ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * ByteArrayBuffer_Get_m1CA04F719970DD2C4E61B152A14D1A8528641CC0 (int32_t ___size0, bool ___enforceZeroOffset1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ByteArrayBuffer_Get_m1CA04F719970DD2C4E61B152A14D1A8528641CC0_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	uint32_t V_0 = 0;
	int32_t V_1 = 0;
	ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * V_2 = NULL;
	List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * V_3 = NULL;
	List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* V_4 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 1);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		int32_t L_0 = ___size0;
		IL2CPP_RUNTIME_CLASS_INIT(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var);
		uint32_t L_1 = ByteArrayBuffer_NextPowerOfTwo_m799FA4F6BC6E6ADE97AC651BE4BF457EF7A150DA(L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		uint32_t L_2 = V_0;
		if ((!(((uint32_t)L_2) < ((uint32_t)((int32_t)128)))))
		{
			goto IL_0015;
		}
	}
	{
		V_0 = ((int32_t)128);
	}

IL_0015:
	{
		uint32_t L_3 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var);
		int32_t L_4 = ByteArrayBuffer_GetPower_m16CF6A82A1F8D26A5882179C21617A3960CA7F82(L_3, /*hidden argument*/NULL);
		V_1 = L_4;
		List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* L_5 = ((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields*)il2cpp_codegen_static_fields_for(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var))->get_sPool_0();
		List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* L_6 = L_5;
		V_4 = L_6;
		Monitor_Enter_m903755FCC479745619842CCDBF5E6355319FA102((RuntimeObject *)(RuntimeObject *)L_6, /*hidden argument*/NULL);
	}

IL_0029:
	try
	{ // begin try (depth: 1)
		{
			IL2CPP_RUNTIME_CLASS_INIT(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var);
			List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* L_7 = ((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields*)il2cpp_codegen_static_fields_for(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var))->get_sPool_0();
			int32_t L_8 = V_1;
			NullCheck(L_7);
			int32_t L_9 = L_8;
			List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * L_10 = (List_1_t43B2D37CF48E04673A48558029581722DDF26F4E *)(L_7)->GetAt(static_cast<il2cpp_array_size_t>(L_9));
			NullCheck(L_10);
			int32_t L_11 = List_1_get_Count_m185E91DB90246AA3DA769184ADCC7B79E8F8E101(L_10, /*hidden argument*/List_1_get_Count_m185E91DB90246AA3DA769184ADCC7B79E8F8E101_RuntimeMethod_var);
			if (L_11)
			{
				goto IL_0040;
			}
		}

IL_0037:
		{
			uint32_t L_12 = V_0;
			ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_13 = (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B *)il2cpp_codegen_object_new(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var);
			ByteArrayBuffer__ctor_mCE37F5382D4D067550B5BBB53DB62B4C98EE3B09(L_13, L_12, /*hidden argument*/NULL);
			V_2 = L_13;
			goto IL_006b;
		}

IL_0040:
		{
			IL2CPP_RUNTIME_CLASS_INIT(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var);
			List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* L_14 = ((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields*)il2cpp_codegen_static_fields_for(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var))->get_sPool_0();
			int32_t L_15 = V_1;
			NullCheck(L_14);
			int32_t L_16 = L_15;
			List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * L_17 = (List_1_t43B2D37CF48E04673A48558029581722DDF26F4E *)(L_14)->GetAt(static_cast<il2cpp_array_size_t>(L_16));
			V_3 = L_17;
			List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * L_18 = V_3;
			List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * L_19 = V_3;
			NullCheck(L_19);
			int32_t L_20 = List_1_get_Count_m185E91DB90246AA3DA769184ADCC7B79E8F8E101(L_19, /*hidden argument*/List_1_get_Count_m185E91DB90246AA3DA769184ADCC7B79E8F8E101_RuntimeMethod_var);
			NullCheck(L_18);
			ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_21 = List_1_get_Item_mA5D732CCE04960301F17718BCCB163F63F83AE02(L_18, ((int32_t)il2cpp_codegen_subtract((int32_t)L_20, (int32_t)1)), /*hidden argument*/List_1_get_Item_mA5D732CCE04960301F17718BCCB163F63F83AE02_RuntimeMethod_var);
			V_2 = L_21;
			List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * L_22 = V_3;
			List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * L_23 = V_3;
			NullCheck(L_23);
			int32_t L_24 = List_1_get_Count_m185E91DB90246AA3DA769184ADCC7B79E8F8E101(L_23, /*hidden argument*/List_1_get_Count_m185E91DB90246AA3DA769184ADCC7B79E8F8E101_RuntimeMethod_var);
			NullCheck(L_22);
			List_1_RemoveAt_mEFDCEF7205CBAAE8676FB4BF94B91B5F7DF29113(L_22, ((int32_t)il2cpp_codegen_subtract((int32_t)L_24, (int32_t)1)), /*hidden argument*/List_1_RemoveAt_mEFDCEF7205CBAAE8676FB4BF94B91B5F7DF29113_RuntimeMethod_var);
			ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_25 = V_2;
			NullCheck(L_25);
			ByteArrayBuffer_Reset_m375E1E454C447037210ACFEC6D1C5C769DD54448(L_25, /*hidden argument*/NULL);
		}

IL_006b:
		{
			IL2CPP_LEAVE(0x75, FINALLY_006d);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_006d;
	}

FINALLY_006d:
	{ // begin finally (depth: 1)
		List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* L_26 = V_4;
		Monitor_Exit_m49A1E5356D984D0B934BB97A305E2E5E207225C2((RuntimeObject *)(RuntimeObject *)L_26, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(109)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(109)
	{
		IL2CPP_JUMP_TBL(0x75, IL_0075)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
	}

IL_0075:
	{
		ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_27 = V_2;
		return L_27;
	}
}
// System.Void Byn.Awrtc.ByteArrayBuffer::Dispose()
extern "C" IL2CPP_METHOD_ATTR void ByteArrayBuffer_Dispose_mEEBA9EE7B80671DB5228061B31B43ED8F577CDF3 (ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ByteArrayBuffer_Dispose_mEEBA9EE7B80671DB5228061B31B43ED8F577CDF3_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* V_1 = NULL;
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 1);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		IL2CPP_RUNTIME_CLASS_INIT(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var);
		List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* L_0 = ((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields*)il2cpp_codegen_static_fields_for(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var))->get_sPool_0();
		List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* L_1 = L_0;
		V_1 = L_1;
		Monitor_Enter_m903755FCC479745619842CCDBF5E6355319FA102((RuntimeObject *)(RuntimeObject *)L_1, /*hidden argument*/NULL);
	}

IL_000c:
	try
	{ // begin try (depth: 1)
		{
			bool L_2 = __this->get_mDisposed_7();
			if (!L_2)
			{
				goto IL_001f;
			}
		}

IL_0014:
		{
			InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 * L_3 = (InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 *)il2cpp_codegen_object_new(InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1_il2cpp_TypeInfo_var);
			InvalidOperationException__ctor_m72027D5F1D513C25C05137E203EEED8FD8297706(L_3, _stringLiteral00BA3C9A92109B36A8FFDBA4A8323A8E89412FCC, /*hidden argument*/NULL);
			IL2CPP_RAISE_MANAGED_EXCEPTION(L_3, NULL, ByteArrayBuffer_Dispose_mEEBA9EE7B80671DB5228061B31B43ED8F577CDF3_RuntimeMethod_var);
		}

IL_001f:
		{
			__this->set_mDisposed_7((bool)1);
			bool L_4 = __this->get_mFromPool_6();
			if (!L_4)
			{
				goto IL_0049;
			}
		}

IL_002e:
		{
			ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_5 = __this->get_array_2();
			NullCheck(L_5);
			IL2CPP_RUNTIME_CLASS_INIT(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var);
			int32_t L_6 = ByteArrayBuffer_GetPower_m16CF6A82A1F8D26A5882179C21617A3960CA7F82((((int32_t)((int32_t)(((RuntimeArray *)L_5)->max_length)))), /*hidden argument*/NULL);
			V_0 = L_6;
			List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* L_7 = ((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_StaticFields*)il2cpp_codegen_static_fields_for(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var))->get_sPool_0();
			int32_t L_8 = V_0;
			NullCheck(L_7);
			int32_t L_9 = L_8;
			List_1_t43B2D37CF48E04673A48558029581722DDF26F4E * L_10 = (List_1_t43B2D37CF48E04673A48558029581722DDF26F4E *)(L_7)->GetAt(static_cast<il2cpp_array_size_t>(L_9));
			NullCheck(L_10);
			List_1_Add_m8FC2727372ADD2DF6382E5687F43987CAEF0C19B(L_10, __this, /*hidden argument*/List_1_Add_m8FC2727372ADD2DF6382E5687F43987CAEF0C19B_RuntimeMethod_var);
		}

IL_0049:
		{
			IL2CPP_LEAVE(0x52, FINALLY_004b);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_004b;
	}

FINALLY_004b:
	{ // begin finally (depth: 1)
		List_1U5BU5D_t7366BBFA7897398AEA705F0DC2C3421160B2A592* L_11 = V_1;
		Monitor_Exit_m49A1E5356D984D0B934BB97A305E2E5E207225C2((RuntimeObject *)(RuntimeObject *)L_11, /*hidden argument*/NULL);
		IL2CPP_END_FINALLY(75)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(75)
	{
		IL2CPP_JUMP_TBL(0x52, IL_0052)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
	}

IL_0052:
	{
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Byn.Awrtc.ConnectionId Byn.Awrtc.CallAcceptedEventArgs::get_ConnectionId()
extern "C" IL2CPP_METHOD_ATTR ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  CallAcceptedEventArgs_get_ConnectionId_mDC42510DDFF826CD4DC0AD45FF74242C24853268 (CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA * __this, const RuntimeMethod* method)
{
	{
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_0 = __this->get_mConnectionId_1();
		return L_0;
	}
}
// System.Void Byn.Awrtc.CallAcceptedEventArgs::.ctor(Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR void CallAcceptedEventArgs__ctor_m313593CBB34D49EC5E4A3F90FB0EB0069E4C1C9A (CallAcceptedEventArgs_t66A1A51D65180197BBA42227E68BF517AC6503DA * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___connectionId0, const RuntimeMethod* method)
{
	{
		CallEventArgs__ctor_m4ED27A352EC2D4A66D78EEE46EE96B30F119ACCD(__this, 2, /*hidden argument*/NULL);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_0 = ___connectionId0;
		__this->set_mConnectionId_1(L_0);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Byn.Awrtc.ConnectionId Byn.Awrtc.CallEndedEventArgs::get_ConnectionId()
extern "C" IL2CPP_METHOD_ATTR ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  CallEndedEventArgs_get_ConnectionId_mCA04B58382AE52B024639F14A5DB44B3DCED0B0B (CallEndedEventArgs_tE3A3B50FDE883A4D052920EB6073028ACFF81128 * __this, const RuntimeMethod* method)
{
	{
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_0 = __this->get_mConnectionId_1();
		return L_0;
	}
}
// System.Void Byn.Awrtc.CallEndedEventArgs::.ctor(Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR void CallEndedEventArgs__ctor_m5C66FFEB0C34E59EB177FBDF82759A1F235ABE74 (CallEndedEventArgs_tE3A3B50FDE883A4D052920EB6073028ACFF81128 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___connectionId0, const RuntimeMethod* method)
{
	{
		CallEventArgs__ctor_m4ED27A352EC2D4A66D78EEE46EE96B30F119ACCD(__this, 3, /*hidden argument*/NULL);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_0 = ___connectionId0;
		__this->set_mConnectionId_1(L_0);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Byn.Awrtc.CallEventType Byn.Awrtc.CallEventArgs::get_Type()
extern "C" IL2CPP_METHOD_ATTR int32_t CallEventArgs_get_Type_m0BF7426058DBFB74B027F71703D096F557ADA077 (CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_mType_0();
		return L_0;
	}
}
// System.Void Byn.Awrtc.CallEventArgs::.ctor(Byn.Awrtc.CallEventType)
extern "C" IL2CPP_METHOD_ATTR void CallEventArgs__ctor_m4ED27A352EC2D4A66D78EEE46EE96B30F119ACCD (CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * __this, int32_t ___type0, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		int32_t L_0 = ___type0;
		__this->set_mType_0(L_0);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Byn.Awrtc.CallEventHandler::.ctor(System.Object,System.IntPtr)
extern "C" IL2CPP_METHOD_ATTR void CallEventHandler__ctor_mDAFA7082D690EF7E2C977F76235AAE7A9CE6AAC5 (CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * __this, RuntimeObject * ___object0, intptr_t ___method1, const RuntimeMethod* method)
{
	__this->set_method_ptr_0(il2cpp_codegen_get_method_pointer((RuntimeMethod*)___method1));
	__this->set_method_3(___method1);
	__this->set_m_target_2(___object0);
}
// System.Void Byn.Awrtc.CallEventHandler::Invoke(System.Object,Byn.Awrtc.CallEventArgs)
extern "C" IL2CPP_METHOD_ATTR void CallEventHandler_Invoke_m4E24EBFA859C707089DF4C71DD8359DC0635B6B1 (CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * __this, RuntimeObject * ___sender0, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * ___args1, const RuntimeMethod* method)
{
	DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* delegatesToInvoke = __this->get_delegates_11();
	if (delegatesToInvoke != NULL)
	{
		il2cpp_array_size_t length = delegatesToInvoke->max_length;
		for (il2cpp_array_size_t i = 0; i < length; i++)
		{
			Delegate_t* currentDelegate = (delegatesToInvoke)->GetAtUnchecked(static_cast<il2cpp_array_size_t>(i));
			Il2CppMethodPointer targetMethodPointer = currentDelegate->get_method_ptr_0();
			RuntimeMethod* targetMethod = (RuntimeMethod*)(currentDelegate->get_method_3());
			RuntimeObject* targetThis = currentDelegate->get_m_target_2();
			if (!il2cpp_codegen_method_is_virtual(targetMethod))
			{
				il2cpp_codegen_raise_execution_engine_exception_if_method_is_not_found(targetMethod);
			}
			bool ___methodIsStatic = MethodIsStatic(targetMethod);
			int ___parameterCount = il2cpp_codegen_method_parameter_count(targetMethod);
			if (___methodIsStatic)
			{
				if (___parameterCount == 2)
				{
					// open
					typedef void (*FunctionPointerType) (RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 *, const RuntimeMethod*);
					((FunctionPointerType)targetMethodPointer)(___sender0, ___args1, targetMethod);
				}
				else
				{
					// closed
					typedef void (*FunctionPointerType) (void*, RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 *, const RuntimeMethod*);
					((FunctionPointerType)targetMethodPointer)(targetThis, ___sender0, ___args1, targetMethod);
				}
			}
			else if (___parameterCount != 2)
			{
				// open
				if (il2cpp_codegen_method_is_virtual(targetMethod) && !il2cpp_codegen_object_is_of_sealed_type(targetThis) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
				{
					if (il2cpp_codegen_method_is_virtual(targetMethod) && !il2cpp_codegen_object_is_of_sealed_type(targetThis) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
					{
						if (il2cpp_codegen_method_is_generic_instance(targetMethod))
						{
							if (il2cpp_codegen_method_is_interface_method(targetMethod))
								GenericInterfaceActionInvoker1< CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * >::Invoke(targetMethod, ___sender0, ___args1);
							else
								GenericVirtActionInvoker1< CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * >::Invoke(targetMethod, ___sender0, ___args1);
						}
						else
						{
							if (il2cpp_codegen_method_is_interface_method(targetMethod))
								InterfaceActionInvoker1< CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), il2cpp_codegen_method_get_declaring_type(targetMethod), ___sender0, ___args1);
							else
								VirtActionInvoker1< CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), ___sender0, ___args1);
						}
					}
				}
				else
				{
					typedef void (*FunctionPointerType) (RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 *, const RuntimeMethod*);
					((FunctionPointerType)targetMethodPointer)(___sender0, ___args1, targetMethod);
				}
			}
			else
			{
				// closed
				if (il2cpp_codegen_method_is_virtual(targetMethod) && !il2cpp_codegen_object_is_of_sealed_type(targetThis) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
				{
					if (il2cpp_codegen_method_is_virtual(targetMethod) && !il2cpp_codegen_object_is_of_sealed_type(targetThis) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
					{
						if (targetThis == NULL)
						{
							typedef void (*FunctionPointerType) (RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 *, const RuntimeMethod*);
							((FunctionPointerType)targetMethodPointer)(___sender0, ___args1, targetMethod);
						}
						else if (il2cpp_codegen_method_is_generic_instance(targetMethod))
						{
							if (il2cpp_codegen_method_is_interface_method(targetMethod))
								GenericInterfaceActionInvoker2< RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * >::Invoke(targetMethod, targetThis, ___sender0, ___args1);
							else
								GenericVirtActionInvoker2< RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * >::Invoke(targetMethod, targetThis, ___sender0, ___args1);
						}
						else
						{
							if (il2cpp_codegen_method_is_interface_method(targetMethod))
								InterfaceActionInvoker2< RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), il2cpp_codegen_method_get_declaring_type(targetMethod), targetThis, ___sender0, ___args1);
							else
								VirtActionInvoker2< RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), targetThis, ___sender0, ___args1);
						}
					}
				}
				else
				{
					typedef void (*FunctionPointerType) (void*, RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 *, const RuntimeMethod*);
					((FunctionPointerType)targetMethodPointer)(targetThis, ___sender0, ___args1, targetMethod);
				}
			}
		}
	}
	else
	{
		Il2CppMethodPointer targetMethodPointer = __this->get_method_ptr_0();
		RuntimeMethod* targetMethod = (RuntimeMethod*)(__this->get_method_3());
		RuntimeObject* targetThis = __this->get_m_target_2();
		if (!il2cpp_codegen_method_is_virtual(targetMethod))
		{
			il2cpp_codegen_raise_execution_engine_exception_if_method_is_not_found(targetMethod);
		}
		bool ___methodIsStatic = MethodIsStatic(targetMethod);
		int ___parameterCount = il2cpp_codegen_method_parameter_count(targetMethod);
		if (___methodIsStatic)
		{
			if (___parameterCount == 2)
			{
				// open
				typedef void (*FunctionPointerType) (RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 *, const RuntimeMethod*);
				((FunctionPointerType)targetMethodPointer)(___sender0, ___args1, targetMethod);
			}
			else
			{
				// closed
				typedef void (*FunctionPointerType) (void*, RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 *, const RuntimeMethod*);
				((FunctionPointerType)targetMethodPointer)(targetThis, ___sender0, ___args1, targetMethod);
			}
		}
		else if (___parameterCount != 2)
		{
			// open
			if (il2cpp_codegen_method_is_virtual(targetMethod) && !il2cpp_codegen_object_is_of_sealed_type(targetThis) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
			{
				if (il2cpp_codegen_method_is_virtual(targetMethod) && !il2cpp_codegen_object_is_of_sealed_type(targetThis) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
				{
					if (il2cpp_codegen_method_is_generic_instance(targetMethod))
					{
						if (il2cpp_codegen_method_is_interface_method(targetMethod))
							GenericInterfaceActionInvoker1< CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * >::Invoke(targetMethod, ___sender0, ___args1);
						else
							GenericVirtActionInvoker1< CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * >::Invoke(targetMethod, ___sender0, ___args1);
					}
					else
					{
						if (il2cpp_codegen_method_is_interface_method(targetMethod))
							InterfaceActionInvoker1< CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), il2cpp_codegen_method_get_declaring_type(targetMethod), ___sender0, ___args1);
						else
							VirtActionInvoker1< CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), ___sender0, ___args1);
					}
				}
			}
			else
			{
				typedef void (*FunctionPointerType) (RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 *, const RuntimeMethod*);
				((FunctionPointerType)targetMethodPointer)(___sender0, ___args1, targetMethod);
			}
		}
		else
		{
			// closed
			if (il2cpp_codegen_method_is_virtual(targetMethod) && !il2cpp_codegen_object_is_of_sealed_type(targetThis) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
			{
				if (il2cpp_codegen_method_is_virtual(targetMethod) && !il2cpp_codegen_object_is_of_sealed_type(targetThis) && il2cpp_codegen_delegate_has_invoker((Il2CppDelegate*)__this))
				{
					if (targetThis == NULL)
					{
						typedef void (*FunctionPointerType) (RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 *, const RuntimeMethod*);
						((FunctionPointerType)targetMethodPointer)(___sender0, ___args1, targetMethod);
					}
					else if (il2cpp_codegen_method_is_generic_instance(targetMethod))
					{
						if (il2cpp_codegen_method_is_interface_method(targetMethod))
							GenericInterfaceActionInvoker2< RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * >::Invoke(targetMethod, targetThis, ___sender0, ___args1);
						else
							GenericVirtActionInvoker2< RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * >::Invoke(targetMethod, targetThis, ___sender0, ___args1);
					}
					else
					{
						if (il2cpp_codegen_method_is_interface_method(targetMethod))
							InterfaceActionInvoker2< RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), il2cpp_codegen_method_get_declaring_type(targetMethod), targetThis, ___sender0, ___args1);
						else
							VirtActionInvoker2< RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * >::Invoke(il2cpp_codegen_method_get_slot(targetMethod), targetThis, ___sender0, ___args1);
					}
				}
			}
			else
			{
				typedef void (*FunctionPointerType) (void*, RuntimeObject *, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 *, const RuntimeMethod*);
				((FunctionPointerType)targetMethodPointer)(targetThis, ___sender0, ___args1, targetMethod);
			}
		}
	}
}
// System.IAsyncResult Byn.Awrtc.CallEventHandler::BeginInvoke(System.Object,Byn.Awrtc.CallEventArgs,System.AsyncCallback,System.Object)
extern "C" IL2CPP_METHOD_ATTR RuntimeObject* CallEventHandler_BeginInvoke_mC7E50FFAF70A8CD0AC92E8A9883BE4265EF016B7 (CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * __this, RuntimeObject * ___sender0, CallEventArgs_t818567BF1A3D4FFC096A4A4018C229D78D8ECFC0 * ___args1, AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4 * ___callback2, RuntimeObject * ___object3, const RuntimeMethod* method)
{
	void *__d_args[3] = {0};
	__d_args[0] = ___sender0;
	__d_args[1] = ___args1;
	return (RuntimeObject*)il2cpp_codegen_delegate_begin_invoke((RuntimeDelegate*)__this, __d_args, (RuntimeDelegate*)___callback2, (RuntimeObject*)___object3);
}
// System.Void Byn.Awrtc.CallEventHandler::EndInvoke(System.IAsyncResult)
extern "C" IL2CPP_METHOD_ATTR void CallEventHandler_EndInvoke_m8842C3AF89BBBAD0297F4300A9FBA6F0CC119481 (CallEventHandler_tC9D919E3867CEBE6B3D26923028AB6E2A713387F * __this, RuntimeObject* ___result0, const RuntimeMethod* method)
{
	il2cpp_codegen_delegate_end_invoke((Il2CppAsyncResult*) ___result0, 0);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Byn.Awrtc.ConnectionId::.ctor(System.Int16)
extern "C" IL2CPP_METHOD_ATTR void ConnectionId__ctor_m1B23DF8F185ADBFE90CF43E74F2A84983E6C5382 (ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * __this, int16_t ___lId0, const RuntimeMethod* method)
{
	{
		int16_t L_0 = ___lId0;
		__this->set_id_1(L_0);
		return;
	}
}
extern "C"  void ConnectionId__ctor_m1B23DF8F185ADBFE90CF43E74F2A84983E6C5382_AdjustorThunk (RuntimeObject * __this, int16_t ___lId0, const RuntimeMethod* method)
{
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * _thisAdjusted = reinterpret_cast<ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D *>(__this + 1);
	ConnectionId__ctor_m1B23DF8F185ADBFE90CF43E74F2A84983E6C5382(_thisAdjusted, ___lId0, method);
}
// System.Boolean Byn.Awrtc.ConnectionId::Equals(System.Object)
extern "C" IL2CPP_METHOD_ATTR bool ConnectionId_Equals_m3319070F68965CAA3729089E1A7700B71527ADB6 (ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConnectionId_Equals_m3319070F68965CAA3729089E1A7700B71527ADB6_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		RuntimeObject * L_0 = ___obj0;
		if (!((RuntimeObject *)IsInstSealed((RuntimeObject*)L_0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var)))
		{
			goto IL_001c;
		}
	}
	{
		RuntimeObject * L_1 = ___obj0;
		V_0 = ((*(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D *)((ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D *)UnBox(L_1, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var))));
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_2 = V_0;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_3 = (*(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D *)__this);
		IL2CPP_RUNTIME_CLASS_INIT(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var);
		bool L_4 = ConnectionId_op_Equality_m59535C3744B394D8EC43CCE6A2C0521BBDDA6A15(L_2, L_3, /*hidden argument*/NULL);
		return L_4;
	}

IL_001c:
	{
		return (bool)0;
	}
}
extern "C"  bool ConnectionId_Equals_m3319070F68965CAA3729089E1A7700B71527ADB6_AdjustorThunk (RuntimeObject * __this, RuntimeObject * ___obj0, const RuntimeMethod* method)
{
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * _thisAdjusted = reinterpret_cast<ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D *>(__this + 1);
	return ConnectionId_Equals_m3319070F68965CAA3729089E1A7700B71527ADB6(_thisAdjusted, ___obj0, method);
}
// System.Int32 Byn.Awrtc.ConnectionId::GetHashCode()
extern "C" IL2CPP_METHOD_ATTR int32_t ConnectionId_GetHashCode_mF80556358DA5A32ECEA07264C5F8138393804388 (ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * __this, const RuntimeMethod* method)
{
	{
		int16_t* L_0 = __this->get_address_of_id_1();
		int32_t L_1 = Int16_GetHashCode_m5DE8889F965D31CFDE23E2CD58650C85259FD798((int16_t*)L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
extern "C"  int32_t ConnectionId_GetHashCode_mF80556358DA5A32ECEA07264C5F8138393804388_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * _thisAdjusted = reinterpret_cast<ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D *>(__this + 1);
	return ConnectionId_GetHashCode_mF80556358DA5A32ECEA07264C5F8138393804388(_thisAdjusted, method);
}
// System.Boolean Byn.Awrtc.ConnectionId::op_Equality(Byn.Awrtc.ConnectionId,Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR bool ConnectionId_op_Equality_m59535C3744B394D8EC43CCE6A2C0521BBDDA6A15 (ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___i10, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___i21, const RuntimeMethod* method)
{
	{
		int16_t L_0 = (&___i10)->get_id_1();
		int16_t L_1 = (&___i21)->get_id_1();
		return (bool)((((int32_t)L_0) == ((int32_t)L_1))? 1 : 0);
	}
}
// System.Boolean Byn.Awrtc.ConnectionId::op_Inequality(Byn.Awrtc.ConnectionId,Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR bool ConnectionId_op_Inequality_m4D5E6C47FF0450F312BA489473E9FF71D339CBC0 (ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___i10, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___i21, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConnectionId_op_Inequality_m4D5E6C47FF0450F312BA489473E9FF71D339CBC0_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	{
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_0 = ___i10;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = ___i21;
		IL2CPP_RUNTIME_CLASS_INIT(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var);
		bool L_2 = ConnectionId_op_Equality_m59535C3744B394D8EC43CCE6A2C0521BBDDA6A15(L_0, L_1, /*hidden argument*/NULL);
		V_0 = L_2;
		bool L_3 = V_0;
		return (bool)((((int32_t)L_3) == ((int32_t)0))? 1 : 0);
	}
}
// System.String Byn.Awrtc.ConnectionId::ToString()
extern "C" IL2CPP_METHOD_ATTR String_t* ConnectionId_ToString_m1F79176854ABAA347F6F91FA287BFC30B3BF4C27 (ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * __this, const RuntimeMethod* method)
{
	{
		int16_t* L_0 = __this->get_address_of_id_1();
		String_t* L_1 = Int16_ToString_m9945F0E2E7E6BE9E91203BFFA7125ABFC6843BA5((int16_t*)L_0, /*hidden argument*/NULL);
		return L_1;
	}
}
extern "C"  String_t* ConnectionId_ToString_m1F79176854ABAA347F6F91FA287BFC30B3BF4C27_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * _thisAdjusted = reinterpret_cast<ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D *>(__this + 1);
	return ConnectionId_ToString_m1F79176854ABAA347F6F91FA287BFC30B3BF4C27(_thisAdjusted, method);
}
// System.Void Byn.Awrtc.ConnectionId::.cctor()
extern "C" IL2CPP_METHOD_ATTR void ConnectionId__cctor_m7FBEAF5033170D16F7B20CBC1B5465410DD4B651 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConnectionId__cctor_m7FBEAF5033170D16F7B20CBC1B5465410DD4B651_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		il2cpp_codegen_initobj((&V_0), sizeof(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D ));
		(&V_0)->set_id_1((int16_t)(-1));
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_0 = V_0;
		((ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields*)il2cpp_codegen_static_fields_for(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var))->set_INVALID_0(L_0);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Byn.Awrtc.DataMessageEventArgs::.ctor(Byn.Awrtc.ConnectionId,System.Byte[],System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void DataMessageEventArgs__ctor_m0696EC373C208888C4E333D1FB9B99D52224A03A (DataMessageEventArgs_tB8CDB5F6F5AF24BE92C6606DF93F697743EB6E37 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___id0, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___data1, bool ___reliable2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DataMessageEventArgs__ctor_m0696EC373C208888C4E333D1FB9B99D52224A03A_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_0 = ((ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields*)il2cpp_codegen_static_fields_for(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var))->get_INVALID_0();
		__this->set_mConnectionId_1(L_0);
		CallEventArgs__ctor_m4ED27A352EC2D4A66D78EEE46EE96B30F119ACCD(__this, ((int32_t)10), /*hidden argument*/NULL);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = ___id0;
		__this->set_mConnectionId_1(L_1);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_2 = ___data1;
		__this->set_mContent_2(L_2);
		bool L_3 = ___reliable2;
		__this->set_mReliable_3(L_3);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Boolean Byn.Awrtc.DefaultValues::get_AuthenticateAsClientBugWorkaround()
extern "C" IL2CPP_METHOD_ATTR bool DefaultValues_get_AuthenticateAsClientBugWorkaround_m9760747B06464A0A858D9D415F2B7F62569EA792 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (DefaultValues_get_AuthenticateAsClientBugWorkaround_m9760747B06464A0A858D9D415F2B7F62569EA792_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(DefaultValues_tFB168B56BA06FD7096D0B3A6454AD6873A4104CA_il2cpp_TypeInfo_var);
		bool L_0 = ((DefaultValues_tFB168B56BA06FD7096D0B3A6454AD6873A4104CA_StaticFields*)il2cpp_codegen_static_fields_for(DefaultValues_tFB168B56BA06FD7096D0B3A6454AD6873A4104CA_il2cpp_TypeInfo_var))->get_sAuthenticateAsClientBugWorkaround_0();
		return L_0;
	}
}
// System.Void Byn.Awrtc.DefaultValues::.cctor()
extern "C" IL2CPP_METHOD_ATTR void DefaultValues__cctor_m5666EF22DF277171DB10E651BB9354D36082A690 (const RuntimeMethod* method)
{
	{
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Byn.Awrtc.ErrorInfo Byn.Awrtc.ErrorEventArgs::get_Info()
extern "C" IL2CPP_METHOD_ATTR ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * ErrorEventArgs_get_Info_mE804CE356C5573E5CAC8D711190FB2C7891040A3 (ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246 * __this, const RuntimeMethod* method)
{
	{
		ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * L_0 = __this->get_mErrorInfo_1();
		return L_0;
	}
}
// System.Void Byn.Awrtc.ErrorEventArgs::.ctor(Byn.Awrtc.CallEventType,Byn.Awrtc.ErrorInfo)
extern "C" IL2CPP_METHOD_ATTR void ErrorEventArgs__ctor_m8BEABC103A358B03A2FF9F9D546B443FF579F366 (ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246 * __this, int32_t ___eventType0, ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * ___errorInfo1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ErrorEventArgs__ctor_m8BEABC103A358B03A2FF9F9D546B443FF579F366_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		int32_t L_0 = ___eventType0;
		CallEventArgs__ctor_m4ED27A352EC2D4A66D78EEE46EE96B30F119ACCD(__this, L_0, /*hidden argument*/NULL);
		ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * L_1 = ___errorInfo1;
		__this->set_mErrorInfo_1(L_1);
		ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * L_2 = __this->get_mErrorInfo_1();
		if (L_2)
		{
			goto IL_0027;
		}
	}
	{
		String_t* L_3 = ErrorEventArgs_GuessError_m6A6732680478E119C59FA45A2CB9129290265497(__this, /*hidden argument*/NULL);
		ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * L_4 = (ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 *)il2cpp_codegen_object_new(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var);
		ErrorInfo__ctor_m48716C55A898B5D004BF029D7246647CD5B4B23D(L_4, L_3, /*hidden argument*/NULL);
		__this->set_mErrorInfo_1(L_4);
	}

IL_0027:
	{
		return;
	}
}
// System.String Byn.Awrtc.ErrorEventArgs::GuessError()
extern "C" IL2CPP_METHOD_ATTR String_t* ErrorEventArgs_GuessError_m6A6732680478E119C59FA45A2CB9129290265497 (ErrorEventArgs_t5A287854C72ED85A9C48B9F18F88C56475C02246 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ErrorEventArgs_GuessError_m6A6732680478E119C59FA45A2CB9129290265497_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	String_t* V_0 = NULL;
	int32_t V_1 = 0;
	{
		int32_t L_0 = CallEventArgs_get_Type_m0BF7426058DBFB74B027F71703D096F557ADA077(__this, /*hidden argument*/NULL);
		V_1 = L_0;
		int32_t L_1 = V_1;
		switch (((int32_t)il2cpp_codegen_subtract((int32_t)L_1, (int32_t)6)))
		{
			case 0:
			{
				goto IL_0019;
			}
			case 1:
			{
				goto IL_0021;
			}
		}
	}
	{
		goto IL_0029;
	}

IL_0019:
	{
		V_0 = _stringLiteral4B8425C313ECC40E5F2A30B13A056344376E4FD9;
		goto IL_002f;
	}

IL_0021:
	{
		V_0 = _stringLiteralAD50C3BEAA126E3D524ABD3F15A336D933F6CDF1;
		goto IL_002f;
	}

IL_0029:
	{
		V_0 = _stringLiteral3716D64264F900396F1AF7FC16D7B86FDF992A50;
	}

IL_002f:
	{
		String_t* L_2 = V_0;
		return L_2;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Byn.Awrtc.ErrorInfo::.ctor(System.String)
extern "C" IL2CPP_METHOD_ATTR void ErrorInfo__ctor_m48716C55A898B5D004BF029D7246647CD5B4B23D (ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * __this, String_t* ___error0, const RuntimeMethod* method)
{
	{
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		String_t* L_0 = ___error0;
		__this->set_mErrorMessage_10(L_0);
		return;
	}
}
// System.String Byn.Awrtc.ErrorInfo::ToString()
extern "C" IL2CPP_METHOD_ATTR String_t* ErrorInfo_ToString_m9FF48FDBCBFBA7B39A1DD9DC0B8E96459F76281E (ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * __this, const RuntimeMethod* method)
{
	{
		String_t* L_0 = __this->get_mErrorMessage_10();
		return L_0;
	}
}
// System.Void Byn.Awrtc.ErrorInfo::.cctor()
extern "C" IL2CPP_METHOD_ATTR void ErrorInfo__cctor_m16E68031F48D4019AB86A46DE9F26588B1B72C75 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ErrorInfo__cctor_m16E68031F48D4019AB86A46DE9F26588B1B72C75_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		((ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields*)il2cpp_codegen_static_fields_for(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var))->set_SERVER_INIT_FAILED_ADDRESS_IN_USE_0(_stringLiteralD838C49EC4C8CE20DC29CCB60C2789B5F0E47998);
		((ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields*)il2cpp_codegen_static_fields_for(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var))->set_CONNECTION_FAILED_ADDRESS_UNKNOWN_1(_stringLiteral8F1AA36AEDBD3E481D3236E3E4A8739EA0C14409);
		((ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields*)il2cpp_codegen_static_fields_for(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var))->set_SERVER_INIT_FAILED_REQURED_CONNECTION_OFFLINE_2(_stringLiteralB51CBAA564000A2843B51CB636A2694EB74893D6);
		((ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields*)il2cpp_codegen_static_fields_for(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var))->set_CONNECTION_FAILED_REQURED_CONNECTION_OFFLINE_3(_stringLiteral27743FF867B90795547A94A6879B23455154D7CB);
		((ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields*)il2cpp_codegen_static_fields_for(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var))->set_DISCONNECTED_REQURED_CONNECTION_OFFLINE_4(_stringLiteralE76519C94CB56A5F865FF3FEBBE6DEC1B1A984CC);
		((ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields*)il2cpp_codegen_static_fields_for(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var))->set_SERVER_CLOSED_REQURED_CONNECTION_OFFLINE_5(_stringLiteralF4C897B2DB3977E54492B9D5DC0FDFF516A4DF8A);
		((ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields*)il2cpp_codegen_static_fields_for(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var))->set_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_6(_stringLiteralA1FEF0B42008F225256B6F991B25DDFFCFD238D7);
		((ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields*)il2cpp_codegen_static_fields_for(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var))->set_INCOMING_CONNECTION_FAILED_TO_CONNECT_DIRECTLY_7(_stringLiteral836DF255926302A2BED5CFD9869346BFB8BE6B7A);
		((ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields*)il2cpp_codegen_static_fields_for(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var))->set_DISCONNECTED_DUE_TO_TIMEOUT_8(_stringLiteral645C18B68EF4227E273294B86C37A5E293ED2EAF);
		((ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields*)il2cpp_codegen_static_fields_for(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var))->set_CONFIGURATION_FAILED_9(_stringLiteralD24A4420AE0C6330E6C72788294F1978C40BC5AB);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Byn.Awrtc.FramePixelFormat Byn.Awrtc.FrameUpdateEventArgs::get_Format()
extern "C" IL2CPP_METHOD_ATTR int32_t FrameUpdateEventArgs_get_Format_m5177E64E40BBD863EED1FA232F8723A9062995BA (FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_mFormat_1();
		return L_0;
	}
}
// Byn.Awrtc.ConnectionId Byn.Awrtc.FrameUpdateEventArgs::get_ConnectionId()
extern "C" IL2CPP_METHOD_ATTR ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  FrameUpdateEventArgs_get_ConnectionId_m9C8635494A8367A71A6B9E744F699FC0D53D8FC2 (FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C * __this, const RuntimeMethod* method)
{
	{
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_0 = __this->get_mConnectionId_2();
		return L_0;
	}
}
// System.Boolean Byn.Awrtc.FrameUpdateEventArgs::get_IsRemote()
extern "C" IL2CPP_METHOD_ATTR bool FrameUpdateEventArgs_get_IsRemote_m2754AE629569A1DD3D909BDBE8BD9A620AEC69FA (FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FrameUpdateEventArgs_get_IsRemote_m2754AE629569A1DD3D909BDBE8BD9A620AEC69FA_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_0 = __this->get_mConnectionId_2();
		IL2CPP_RUNTIME_CLASS_INIT(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = ((ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields*)il2cpp_codegen_static_fields_for(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var))->get_INVALID_0();
		bool L_2 = ConnectionId_op_Inequality_m4D5E6C47FF0450F312BA489473E9FF71D339CBC0(L_0, L_1, /*hidden argument*/NULL);
		return L_2;
	}
}
// Byn.Awrtc.IFrame Byn.Awrtc.FrameUpdateEventArgs::get_Frame()
extern "C" IL2CPP_METHOD_ATTR RuntimeObject* FrameUpdateEventArgs_get_Frame_m542290AC318831D475BA437E3CE91BCAEA48F50D (FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C * __this, const RuntimeMethod* method)
{
	{
		RuntimeObject* L_0 = __this->get_mFrame_3();
		return L_0;
	}
}
// System.Void Byn.Awrtc.FrameUpdateEventArgs::.ctor(Byn.Awrtc.ConnectionId,Byn.Awrtc.IFrame)
extern "C" IL2CPP_METHOD_ATTR void FrameUpdateEventArgs__ctor_mA0D47D896195E97BBE9FEB1BF9EE2CAABC8F53E4 (FrameUpdateEventArgs_t634A4325664A8B135DEB37E87967686C9690DE6C * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___conId0, RuntimeObject* ___frame1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FrameUpdateEventArgs__ctor_mA0D47D896195E97BBE9FEB1BF9EE2CAABC8F53E4_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_0 = ((ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields*)il2cpp_codegen_static_fields_for(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var))->get_INVALID_0();
		__this->set_mConnectionId_2(L_0);
		CallEventArgs__ctor_m4ED27A352EC2D4A66D78EEE46EE96B30F119ACCD(__this, 4, /*hidden argument*/NULL);
		__this->set_mFormat_1(1);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = ___conId0;
		__this->set_mConnectionId_2(L_1);
		RuntimeObject* L_2 = ___frame1;
		__this->set_mFrame_3(L_2);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Collections.Generic.List`1<System.String> Byn.Awrtc.IceServer::get_Urls()
extern "C" IL2CPP_METHOD_ATTR List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * IceServer_get_Urls_mD3E85B113CB05451E02FD54D7770B2A7E3909B8A (IceServer_t423A5044DD3B2346555973AF68F71585262E07FA * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (IceServer_get_Urls_mD3E85B113CB05451E02FD54D7770B2A7E3909B8A_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * L_0 = __this->get_mUrls_0();
		List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * L_1 = (List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 *)il2cpp_codegen_object_new(List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3_il2cpp_TypeInfo_var);
		List_1__ctor_mE9FDDA3E872C3CB2DBDC8562E9ABA76CA3124599(L_1, L_0, /*hidden argument*/List_1__ctor_mE9FDDA3E872C3CB2DBDC8562E9ABA76CA3124599_RuntimeMethod_var);
		return L_1;
	}
}
// System.String Byn.Awrtc.IceServer::get_Username()
extern "C" IL2CPP_METHOD_ATTR String_t* IceServer_get_Username_m388B0012517F44C8895EBC05EF2A982D54C575FE (IceServer_t423A5044DD3B2346555973AF68F71585262E07FA * __this, const RuntimeMethod* method)
{
	{
		String_t* L_0 = __this->get_mUsername_1();
		return L_0;
	}
}
// System.String Byn.Awrtc.IceServer::get_Credential()
extern "C" IL2CPP_METHOD_ATTR String_t* IceServer_get_Credential_mAD235B95FCC8AA0EF58E9E5C9084323EA6B29049 (IceServer_t423A5044DD3B2346555973AF68F71585262E07FA * __this, const RuntimeMethod* method)
{
	{
		String_t* L_0 = __this->get_mCredential_2();
		return L_0;
	}
}
// System.Void Byn.Awrtc.IceServer::.ctor(System.String,System.String,System.String)
extern "C" IL2CPP_METHOD_ATTR void IceServer__ctor_m9B4C7129BE2E61E4B73E186A7810035AA0ED8AF7 (IceServer_t423A5044DD3B2346555973AF68F71585262E07FA * __this, String_t* ___lUrl0, String_t* ___lUsername1, String_t* ___lCredential2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (IceServer__ctor_m9B4C7129BE2E61E4B73E186A7810035AA0ED8AF7_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * L_0 = (List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 *)il2cpp_codegen_object_new(List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3_il2cpp_TypeInfo_var);
		List_1__ctor_mDA22758D73530683C950C5CCF39BDB4E7E1F3F06(L_0, /*hidden argument*/List_1__ctor_mDA22758D73530683C950C5CCF39BDB4E7E1F3F06_RuntimeMethod_var);
		__this->set_mUrls_0(L_0);
		__this->set_mUsername_1(_stringLiteralDA39A3EE5E6B4B0D3255BFEF95601890AFD80709);
		__this->set_mCredential_2(_stringLiteralDA39A3EE5E6B4B0D3255BFEF95601890AFD80709);
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * L_1 = __this->get_mUrls_0();
		String_t* L_2 = ___lUrl0;
		NullCheck(L_1);
		List_1_Add_mA348FA1140766465189459D25B01EB179001DE83(L_1, L_2, /*hidden argument*/List_1_Add_mA348FA1140766465189459D25B01EB179001DE83_RuntimeMethod_var);
		String_t* L_3 = ___lUsername1;
		__this->set_mUsername_1(L_3);
		String_t* L_4 = ___lCredential2;
		__this->set_mCredential_2(L_4);
		return;
	}
}
// System.String Byn.Awrtc.IceServer::ToString()
extern "C" IL2CPP_METHOD_ATTR String_t* IceServer_ToString_mD92D1EC60C32C0AF7E7546296C4D10DD59097DBF (IceServer_t423A5044DD3B2346555973AF68F71585262E07FA * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (IceServer_ToString_mD92D1EC60C32C0AF7E7546296C4D10DD59097DBF_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringBuilder_t * V_0 = NULL;
	int32_t V_1 = 0;
	{
		StringBuilder_t * L_0 = (StringBuilder_t *)il2cpp_codegen_object_new(StringBuilder_t_il2cpp_TypeInfo_var);
		StringBuilder__ctor_mF928376F82E8C8FF3C11842C562DB8CF28B2735E(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		StringBuilder_t * L_1 = V_0;
		NullCheck(L_1);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_1, _stringLiteral60BA4B2DAA4ED4D070FEC06687E249E0E6F9EE45, /*hidden argument*/NULL);
		StringBuilder_t * L_2 = V_0;
		NullCheck(L_2);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_2, _stringLiteral7279BBEB8F30C2D351F23C21DA72A80940E69428, /*hidden argument*/NULL);
		V_1 = 0;
		goto IL_0048;
	}

IL_0022:
	{
		int32_t L_3 = V_1;
		if (!L_3)
		{
			goto IL_0031;
		}
	}
	{
		StringBuilder_t * L_4 = V_0;
		NullCheck(L_4);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_4, _stringLiteral5C10B5B2CD673A0616D529AA5234B12EE7153808, /*hidden argument*/NULL);
	}

IL_0031:
	{
		StringBuilder_t * L_5 = V_0;
		List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * L_6 = __this->get_mUrls_0();
		int32_t L_7 = V_1;
		NullCheck(L_6);
		String_t* L_8 = List_1_get_Item_mB739B0066E5F7EBDBA9978F24A73D26D4FAE5BED(L_6, L_7, /*hidden argument*/List_1_get_Item_mB739B0066E5F7EBDBA9978F24A73D26D4FAE5BED_RuntimeMethod_var);
		NullCheck(L_5);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_5, L_8, /*hidden argument*/NULL);
		int32_t L_9 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_9, (int32_t)1));
	}

IL_0048:
	{
		int32_t L_10 = V_1;
		List_1_tE8032E48C661C350FF9550E9063D595C0AB25CD3 * L_11 = __this->get_mUrls_0();
		NullCheck(L_11);
		int32_t L_12 = List_1_get_Count_m4151A68BD4CB1D737213E7595F574987F8C812B4(L_11, /*hidden argument*/List_1_get_Count_m4151A68BD4CB1D737213E7595F574987F8C812B4_RuntimeMethod_var);
		if ((((int32_t)L_10) < ((int32_t)L_12)))
		{
			goto IL_0022;
		}
	}
	{
		StringBuilder_t * L_13 = V_0;
		NullCheck(L_13);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_13, _stringLiteral4FF447B8EF42CA51FA6FB287BED8D40F49BE58F1, /*hidden argument*/NULL);
		StringBuilder_t * L_14 = V_0;
		NullCheck(L_14);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_14, _stringLiteral6B7F2BF79AADF0550CF3C31FA77DC122F0C35E56, /*hidden argument*/NULL);
		StringBuilder_t * L_15 = V_0;
		String_t* L_16 = IceServer_get_Username_m388B0012517F44C8895EBC05EF2A982D54C575FE(__this, /*hidden argument*/NULL);
		NullCheck(L_15);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_15, L_16, /*hidden argument*/NULL);
		StringBuilder_t * L_17 = V_0;
		NullCheck(L_17);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_17, _stringLiteralD8927A1FEADE42C87E0F653443C952EBE59AA0C6, /*hidden argument*/NULL);
		StringBuilder_t * L_18 = V_0;
		String_t* L_19 = IceServer_get_Credential_mAD235B95FCC8AA0EF58E9E5C9084323EA6B29049(__this, /*hidden argument*/NULL);
		NullCheck(L_18);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_18, L_19, /*hidden argument*/NULL);
		StringBuilder_t * L_20 = V_0;
		NullCheck(L_20);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_20, _stringLiteralC2B7DF6201FDD3362399091F0A29550DF3505B6A, /*hidden argument*/NULL);
		StringBuilder_t * L_21 = V_0;
		NullCheck(L_21);
		String_t* L_22 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_21);
		return L_22;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Boolean Byn.Awrtc.LocalNetwork::get_IsServer()
extern "C" IL2CPP_METHOD_ATTR bool LocalNetwork_get_IsServer_m4553266982BFDDB8D6B3A7C8E90CA0F97F7AB852 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, const RuntimeMethod* method)
{
	{
		String_t* L_0 = __this->get_mServerAddress_5();
		return (bool)((((int32_t)((((RuntimeObject*)(String_t*)L_0) == ((RuntimeObject*)(RuntimeObject *)NULL))? 1 : 0)) == ((int32_t)0))? 1 : 0);
	}
}
// System.Void Byn.Awrtc.LocalNetwork::.ctor()
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork__ctor_mEBFB0CF251BEF4406BF3F74DFF4B659EDFE231B5 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocalNetwork__ctor_mEBFB0CF251BEF4406BF3F74DFF4B659EDFE231B5_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		il2cpp_codegen_initobj((&V_0), sizeof(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D ));
		(&V_0)->set_id_1((int16_t)1);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_0 = V_0;
		__this->set_mNextNetworkId_4(L_0);
		Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * L_1 = (Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF *)il2cpp_codegen_object_new(Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF_il2cpp_TypeInfo_var);
		Queue_1__ctor_m207784283861C71375B6A150AA6E6CD3CE6E1ECE(L_1, /*hidden argument*/Queue_1__ctor_m207784283861C71375B6A150AA6E6CD3CE6E1ECE_RuntimeMethod_var);
		__this->set_mEvents_6(L_1);
		Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * L_2 = (Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB *)il2cpp_codegen_object_new(Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_m218A1B086C18400F1C4C49B88A47AE87D133AF19(L_2, /*hidden argument*/Dictionary_2__ctor_m218A1B086C18400F1C4C49B88A47AE87D133AF19_RuntimeMethod_var);
		__this->set_mConnectionNetwork_7(L_2);
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var);
		int32_t L_3 = ((LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields*)il2cpp_codegen_static_fields_for(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var))->get_sNextId_1();
		__this->set_mId_3(L_3);
		int32_t L_4 = ((LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields*)il2cpp_codegen_static_fields_for(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var))->get_sNextId_1();
		((LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields*)il2cpp_codegen_static_fields_for(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var))->set_sNextId_1(((int32_t)il2cpp_codegen_add((int32_t)L_4, (int32_t)1)));
		return;
	}
}
// System.Boolean Byn.Awrtc.LocalNetwork::IsAddressInUse(System.String)
extern "C" IL2CPP_METHOD_ATTR bool LocalNetwork_IsAddressInUse_mFBB6B273F779EAB3093BF356EF57475856DE60A4 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, String_t* ___serverAddress0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocalNetwork_IsAddressInUse_mFBB6B273F779EAB3093BF356EF57475856DE60A4_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var);
		Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * L_0 = ((LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields*)il2cpp_codegen_static_fields_for(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var))->get_mServers_2();
		String_t* L_1 = ___serverAddress0;
		NullCheck(L_0);
		bool L_2 = Dictionary_2_ContainsKey_m7BFA24B1A05E327F5909B68AF1566C84BEFA6431(L_0, L_1, /*hidden argument*/Dictionary_2_ContainsKey_m7BFA24B1A05E327F5909B68AF1566C84BEFA6431_RuntimeMethod_var);
		if (!L_2)
		{
			goto IL_0021;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var);
		Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * L_3 = ((LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields*)il2cpp_codegen_static_fields_for(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var))->get_mServers_2();
		String_t* L_4 = ___serverAddress0;
		NullCheck(L_3);
		WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * L_5 = Dictionary_2_get_Item_mED59F647D10601AFE6764BB277AC05B4673F158C(L_3, L_4, /*hidden argument*/Dictionary_2_get_Item_mED59F647D10601AFE6764BB277AC05B4673F158C_RuntimeMethod_var);
		NullCheck(L_5);
		LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * L_6 = WeakRef_1_Get_m7326E507F345D748A6AD3E9BA422CFE3275BC7D8(L_5, /*hidden argument*/WeakRef_1_Get_m7326E507F345D748A6AD3E9BA422CFE3275BC7D8_RuntimeMethod_var);
		if (!L_6)
		{
			goto IL_0021;
		}
	}
	{
		return (bool)1;
	}

IL_0021:
	{
		String_t* L_7 = ___serverAddress0;
		IL2CPP_RUNTIME_CLASS_INIT(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var);
		String_t* L_8 = ((LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields*)il2cpp_codegen_static_fields_for(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var))->get_LOCK_ADDRESS_0();
		bool L_9 = String_op_Equality_m139F0E4195AE2F856019E63B241F36F016997FCE(L_7, L_8, /*hidden argument*/NULL);
		if (!L_9)
		{
			goto IL_0030;
		}
	}
	{
		return (bool)1;
	}

IL_0030:
	{
		return (bool)0;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::StartServer(System.String)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_StartServer_m6FF3B6576EC1BA7BFD808D8BC358209FFC518420 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, String_t* ___serverAddress0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocalNetwork_StartServer_m6FF3B6576EC1BA7BFD808D8BC358209FFC518420_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		String_t* L_0 = ___serverAddress0;
		if (L_0)
		{
			goto IL_0015;
		}
	}
	{
		int32_t L_1 = __this->get_mId_3();
		int32_t L_2 = L_1;
		RuntimeObject * L_3 = Box(Int32_t585191389E07734F19F3156FF88FB3EF4800D102_il2cpp_TypeInfo_var, &L_2);
		String_t* L_4 = String_Concat_m798542DE19B3F02DC4F4B777BB2E73169F129DE1(L_3, /*hidden argument*/NULL);
		___serverAddress0 = L_4;
	}

IL_0015:
	{
		String_t* L_5 = ___serverAddress0;
		bool L_6 = LocalNetwork_IsAddressInUse_mFBB6B273F779EAB3093BF356EF57475856DE60A4(__this, L_5, /*hidden argument*/NULL);
		if (!L_6)
		{
			goto IL_0035;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_7 = ((ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields*)il2cpp_codegen_static_fields_for(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var))->get_INVALID_0();
		IL2CPP_RUNTIME_CLASS_INIT(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var);
		String_t* L_8 = ((ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields*)il2cpp_codegen_static_fields_for(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var))->get_SERVER_INIT_FAILED_ADDRESS_IN_USE_0();
		ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * L_9 = (ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 *)il2cpp_codegen_object_new(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var);
		ErrorInfo__ctor_m48716C55A898B5D004BF029D7246647CD5B4B23D(L_9, L_8, /*hidden argument*/NULL);
		LocalNetwork_Enqueue_m6586F0D0E759C97E13F274594A787292C16FD85C(__this, 4, L_7, L_9, /*hidden argument*/NULL);
		return;
	}

IL_0035:
	{
		IL2CPP_RUNTIME_CLASS_INIT(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var);
		Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * L_10 = ((LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields*)il2cpp_codegen_static_fields_for(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var))->get_mServers_2();
		String_t* L_11 = ___serverAddress0;
		WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * L_12 = (WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 *)il2cpp_codegen_object_new(WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4_il2cpp_TypeInfo_var);
		WeakRef_1__ctor_mC13774F5C531EC799D4800F075E8FEE759322DC4(L_12, __this, /*hidden argument*/WeakRef_1__ctor_mC13774F5C531EC799D4800F075E8FEE759322DC4_RuntimeMethod_var);
		NullCheck(L_10);
		Dictionary_2_set_Item_mAA053E88F5E5469750D0D6CE2A7A36521BB7BF52(L_10, L_11, L_12, /*hidden argument*/Dictionary_2_set_Item_mAA053E88F5E5469750D0D6CE2A7A36521BB7BF52_RuntimeMethod_var);
		String_t* L_13 = ___serverAddress0;
		__this->set_mServerAddress_5(L_13);
		IL2CPP_RUNTIME_CLASS_INIT(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_14 = ((ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields*)il2cpp_codegen_static_fields_for(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var))->get_INVALID_0();
		String_t* L_15 = ___serverAddress0;
		NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  L_16;
		memset(&L_16, 0, sizeof(L_16));
		NetworkEvent__ctor_mA7EF6BADF8188FC05D529262AC7801F91609C857((&L_16), 3, L_14, L_15, /*hidden argument*/NULL);
		LocalNetwork_Enqueue_m9D20B54FF730F80913DB2B65C28636DA3BCA14E1(__this, L_16, /*hidden argument*/NULL);
		return;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::StopServer()
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_StopServer_m4ED0D3C401EF3C16E1EB7B64672ACDF02A1D7C45 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocalNetwork_StopServer_m4ED0D3C401EF3C16E1EB7B64672ACDF02A1D7C45_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		bool L_0 = LocalNetwork_get_IsServer_m4553266982BFDDB8D6B3A7C8E90CA0F97F7AB852(__this, /*hidden argument*/NULL);
		if (!L_0)
		{
			goto IL_002c;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = ((ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields*)il2cpp_codegen_static_fields_for(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var))->get_INVALID_0();
		LocalNetwork_Enqueue_mCDC62798381553BB3D9B5E660D18C6E328B1FB59(__this, 5, L_1, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var);
		Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * L_2 = ((LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields*)il2cpp_codegen_static_fields_for(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var))->get_mServers_2();
		String_t* L_3 = __this->get_mServerAddress_5();
		NullCheck(L_2);
		Dictionary_2_Remove_mA480C3AD301A4030ED16BD4432EB7AEF76A7B4C4(L_2, L_3, /*hidden argument*/Dictionary_2_Remove_mA480C3AD301A4030ED16BD4432EB7AEF76A7B4C4_RuntimeMethod_var);
		__this->set_mServerAddress_5((String_t*)NULL);
	}

IL_002c:
	{
		return;
	}
}
// Byn.Awrtc.ConnectionId Byn.Awrtc.LocalNetwork::Connect(System.String)
extern "C" IL2CPP_METHOD_ATTR ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  LocalNetwork_Connect_m59F1B0EE1678E54EFC67222D45DFC0F33F05AC57 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, String_t* ___address0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocalNetwork_Connect_m59F1B0EE1678E54EFC67222D45DFC0F33F05AC57_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  V_0;
	memset(&V_0, 0, sizeof(V_0));
	bool V_1 = false;
	LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * V_2 = NULL;
	{
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_0 = LocalNetwork_NextConnectionId_m52D7F7F6AFFC8C040EEC8A25BA57E8EA556489E1(__this, /*hidden argument*/NULL);
		V_0 = L_0;
		V_1 = (bool)0;
		IL2CPP_RUNTIME_CLASS_INIT(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var);
		Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * L_1 = ((LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields*)il2cpp_codegen_static_fields_for(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var))->get_mServers_2();
		String_t* L_2 = ___address0;
		NullCheck(L_1);
		bool L_3 = Dictionary_2_ContainsKey_m7BFA24B1A05E327F5909B68AF1566C84BEFA6431(L_1, L_2, /*hidden argument*/Dictionary_2_ContainsKey_m7BFA24B1A05E327F5909B68AF1566C84BEFA6431_RuntimeMethod_var);
		if (!L_3)
		{
			goto IL_0052;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var);
		Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * L_4 = ((LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields*)il2cpp_codegen_static_fields_for(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var))->get_mServers_2();
		String_t* L_5 = ___address0;
		NullCheck(L_4);
		WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * L_6 = Dictionary_2_get_Item_mED59F647D10601AFE6764BB277AC05B4673F158C(L_4, L_5, /*hidden argument*/Dictionary_2_get_Item_mED59F647D10601AFE6764BB277AC05B4673F158C_RuntimeMethod_var);
		NullCheck(L_6);
		LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * L_7 = WeakRef_1_Get_m7326E507F345D748A6AD3E9BA422CFE3275BC7D8(L_6, /*hidden argument*/WeakRef_1_Get_m7326E507F345D748A6AD3E9BA422CFE3275BC7D8_RuntimeMethod_var);
		V_2 = L_7;
		LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * L_8 = V_2;
		if (!L_8)
		{
			goto IL_0052;
		}
	}
	{
		LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * L_9 = V_2;
		NullCheck(L_9);
		LocalNetwork_ConnectClient_m2DA894173389D07ABAEECDA48F14DCBE6DD5D92D(L_9, __this, /*hidden argument*/NULL);
		Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * L_10 = __this->get_mConnectionNetwork_7();
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_11 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var);
		Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * L_12 = ((LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields*)il2cpp_codegen_static_fields_for(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var))->get_mServers_2();
		String_t* L_13 = ___address0;
		NullCheck(L_12);
		WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * L_14 = Dictionary_2_get_Item_mED59F647D10601AFE6764BB277AC05B4673F158C(L_12, L_13, /*hidden argument*/Dictionary_2_get_Item_mED59F647D10601AFE6764BB277AC05B4673F158C_RuntimeMethod_var);
		NullCheck(L_10);
		Dictionary_2_set_Item_m9E06F377398DEEF5E6E39D45249196F434BC21C8(L_10, L_11, L_14, /*hidden argument*/Dictionary_2_set_Item_m9E06F377398DEEF5E6E39D45249196F434BC21C8_RuntimeMethod_var);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_15 = V_0;
		LocalNetwork_Enqueue_mCDC62798381553BB3D9B5E660D18C6E328B1FB59(__this, 6, L_15, /*hidden argument*/NULL);
		V_1 = (bool)1;
	}

IL_0052:
	{
		bool L_16 = V_1;
		if (L_16)
		{
			goto IL_0067;
		}
	}
	{
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_17 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var);
		String_t* L_18 = ((ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_StaticFields*)il2cpp_codegen_static_fields_for(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var))->get_CONNECTION_FAILED_ADDRESS_UNKNOWN_1();
		ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * L_19 = (ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 *)il2cpp_codegen_object_new(ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var);
		ErrorInfo__ctor_m48716C55A898B5D004BF029D7246647CD5B4B23D(L_19, L_18, /*hidden argument*/NULL);
		LocalNetwork_Enqueue_m6586F0D0E759C97E13F274594A787292C16FD85C(__this, 7, L_17, L_19, /*hidden argument*/NULL);
	}

IL_0067:
	{
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_20 = V_0;
		return L_20;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::Shutdown()
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_Shutdown_m0C1D588250811D685CEE21E92FC2B079179AF461 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocalNetwork_Shutdown_m0C1D588250811D685CEE21E92FC2B079179AF461_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  V_0;
	memset(&V_0, 0, sizeof(V_0));
	Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17  V_1;
	memset(&V_1, 0, sizeof(V_1));
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 1);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * L_0 = __this->get_mConnectionNetwork_7();
		NullCheck(L_0);
		KeyCollection_t22184C5C648B98E1130AB2CB15D732A497552019 * L_1 = Dictionary_2_get_Keys_mEFE37E13A4EF1325942D50D41D88AA4EC71B76D7(L_0, /*hidden argument*/Dictionary_2_get_Keys_mEFE37E13A4EF1325942D50D41D88AA4EC71B76D7_RuntimeMethod_var);
		List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * L_2 = Enumerable_ToList_TisConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_m993BAFA400E4493769271824E19E78B7023A85C5(L_1, /*hidden argument*/Enumerable_ToList_TisConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_m993BAFA400E4493769271824E19E78B7023A85C5_RuntimeMethod_var);
		NullCheck(L_2);
		Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17  L_3 = List_1_GetEnumerator_m72711B857C13554E60D06AE2C418B4FA59870E65(L_2, /*hidden argument*/List_1_GetEnumerator_m72711B857C13554E60D06AE2C418B4FA59870E65_RuntimeMethod_var);
		V_1 = L_3;
	}

IL_0016:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0027;
		}

IL_0018:
		{
			ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_4 = Enumerator_get_Current_m0203034B79126F512CC77691D03434942FE5EE6C((Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 *)(&V_1), /*hidden argument*/Enumerator_get_Current_m0203034B79126F512CC77691D03434942FE5EE6C_RuntimeMethod_var);
			V_0 = L_4;
			ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_5 = V_0;
			LocalNetwork_Disconnect_m3F8609F3C16315A6962AED155F2EE0E6371477D7(__this, L_5, /*hidden argument*/NULL);
		}

IL_0027:
		{
			bool L_6 = Enumerator_MoveNext_m50BD3D91B026FC120054CB6B187B49A57689E4E7((Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 *)(&V_1), /*hidden argument*/Enumerator_MoveNext_m50BD3D91B026FC120054CB6B187B49A57689E4E7_RuntimeMethod_var);
			if (L_6)
			{
				goto IL_0018;
			}
		}

IL_0030:
		{
			IL2CPP_LEAVE(0x40, FINALLY_0032);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_0032;
	}

FINALLY_0032:
	{ // begin finally (depth: 1)
		Enumerator_Dispose_m62E14E84F0EFE2CD8FC246C3779797583ED04D49((Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 *)(&V_1), /*hidden argument*/Enumerator_Dispose_m62E14E84F0EFE2CD8FC246C3779797583ED04D49_RuntimeMethod_var);
		IL2CPP_END_FINALLY(50)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(50)
	{
		IL2CPP_JUMP_TBL(0x40, IL_0040)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
	}

IL_0040:
	{
		Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * L_7 = __this->get_mConnectionNetwork_7();
		NullCheck(L_7);
		Dictionary_2_Clear_m2E85D7A98838E7A8D9EFCF534596F39DFA0AA211(L_7, /*hidden argument*/Dictionary_2_Clear_m2E85D7A98838E7A8D9EFCF534596F39DFA0AA211_RuntimeMethod_var);
		LocalNetwork_StopServer_m4ED0D3C401EF3C16E1EB7B64672ACDF02A1D7C45(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Boolean Byn.Awrtc.LocalNetwork::SendData(Byn.Awrtc.ConnectionId,System.Byte[],System.Int32,System.Int32,System.Boolean)
extern "C" IL2CPP_METHOD_ATTR bool LocalNetwork_SendData_m2A244BFD191B788AD8A96EBE7D285D514BB12F98 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___userId0, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___data1, int32_t ___offset2, int32_t ___length3, bool ___reliable4, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocalNetwork_SendData_m2A244BFD191B788AD8A96EBE7D285D514BB12F98_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * V_0 = NULL;
	LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * V_1 = NULL;
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_0 = ___data1;
		if (!L_0)
		{
			goto IL_0008;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_1 = ___data1;
		NullCheck(L_1);
		if ((((int32_t)((int32_t)(((RuntimeArray *)L_1)->max_length)))))
		{
			goto IL_000a;
		}
	}

IL_0008:
	{
		return (bool)0;
	}

IL_000a:
	{
		Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * L_2 = __this->get_mConnectionNetwork_7();
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_3 = ___userId0;
		NullCheck(L_2);
		bool L_4 = Dictionary_2_TryGetValue_m42A4CC885EBDCFDC472F9F49D8683A6AAC23F9B9(L_2, L_3, (WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 **)(&V_0), /*hidden argument*/Dictionary_2_TryGetValue_m42A4CC885EBDCFDC472F9F49D8683A6AAC23F9B9_RuntimeMethod_var);
		if (!L_4)
		{
			goto IL_003b;
		}
	}
	{
		Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * L_5 = __this->get_mConnectionNetwork_7();
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_6 = ___userId0;
		NullCheck(L_5);
		WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * L_7 = Dictionary_2_get_Item_m1701F17231AAD3E30A9EACC44EBC78404D336E3D(L_5, L_6, /*hidden argument*/Dictionary_2_get_Item_m1701F17231AAD3E30A9EACC44EBC78404D336E3D_RuntimeMethod_var);
		NullCheck(L_7);
		LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * L_8 = WeakRef_1_Get_m7326E507F345D748A6AD3E9BA422CFE3275BC7D8(L_7, /*hidden argument*/WeakRef_1_Get_m7326E507F345D748A6AD3E9BA422CFE3275BC7D8_RuntimeMethod_var);
		V_1 = L_8;
		LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * L_9 = V_1;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_10 = ___data1;
		int32_t L_11 = ___offset2;
		int32_t L_12 = ___length3;
		bool L_13 = ___reliable4;
		NullCheck(L_9);
		LocalNetwork_ReceiveData_mB8112F374B300211274D8C38432A155CFEE9D31B(L_9, __this, L_10, L_11, L_12, L_13, /*hidden argument*/NULL);
		return (bool)1;
	}

IL_003b:
	{
		return (bool)0;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::Update()
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_Update_m6752589296AB92E3F3D20821187D8BABA9814B26 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, const RuntimeMethod* method)
{
	{
		LocalNetwork_CleanupWreakReferences_m1337A34E6D7A17810C73FFB7A2BDDDCDC02C6AD6(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Boolean Byn.Awrtc.LocalNetwork::Dequeue(Byn.Awrtc.NetworkEventU26)
extern "C" IL2CPP_METHOD_ATTR bool LocalNetwork_Dequeue_m6338D7028DEF3B984552DD7EC6686C9B794CC8AE (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * ___evt0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocalNetwork_Dequeue_m6338D7028DEF3B984552DD7EC6686C9B794CC8AE_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * L_0 = __this->get_mEvents_6();
		NullCheck(L_0);
		int32_t L_1 = Queue_1_get_Count_mB49A946DB72811EC8C21C704B0973456642963CB(L_0, /*hidden argument*/Queue_1_get_Count_mB49A946DB72811EC8C21C704B0973456642963CB_RuntimeMethod_var);
		if (L_1)
		{
			goto IL_0016;
		}
	}
	{
		NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * L_2 = ___evt0;
		il2cpp_codegen_initobj(L_2, sizeof(NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C ));
		return (bool)0;
	}

IL_0016:
	{
		NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * L_3 = ___evt0;
		Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * L_4 = __this->get_mEvents_6();
		NullCheck(L_4);
		NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  L_5 = Queue_1_Dequeue_m2D5C4E39A011B35CD6218B0FA62B5CB0D962F535(L_4, /*hidden argument*/Queue_1_Dequeue_m2D5C4E39A011B35CD6218B0FA62B5CB0D962F535_RuntimeMethod_var);
		*(NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)L_3 = L_5;
		return (bool)1;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::Flush()
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_Flush_mBAE91457F1EF4B54B45082BC2BB5D9F9B4B317AD (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, const RuntimeMethod* method)
{
	{
		return;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::Disconnect(Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_Disconnect_m3F8609F3C16315A6962AED155F2EE0E6371477D7 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___id0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocalNetwork_Disconnect_m3F8609F3C16315A6962AED155F2EE0E6371477D7_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * V_0 = NULL;
	{
		Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * L_0 = __this->get_mConnectionNetwork_7();
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = ___id0;
		NullCheck(L_0);
		bool L_2 = Dictionary_2_ContainsKey_m421F3F245DD820A5F1189EDFDE3364AA2811EFE3(L_0, L_1, /*hidden argument*/Dictionary_2_ContainsKey_m421F3F245DD820A5F1189EDFDE3364AA2811EFE3_RuntimeMethod_var);
		if (!L_2)
		{
			goto IL_0038;
		}
	}
	{
		Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * L_3 = __this->get_mConnectionNetwork_7();
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_4 = ___id0;
		NullCheck(L_3);
		WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * L_5 = Dictionary_2_get_Item_m1701F17231AAD3E30A9EACC44EBC78404D336E3D(L_3, L_4, /*hidden argument*/Dictionary_2_get_Item_m1701F17231AAD3E30A9EACC44EBC78404D336E3D_RuntimeMethod_var);
		NullCheck(L_5);
		LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * L_6 = WeakRef_1_Get_m7326E507F345D748A6AD3E9BA422CFE3275BC7D8(L_5, /*hidden argument*/WeakRef_1_Get_m7326E507F345D748A6AD3E9BA422CFE3275BC7D8_RuntimeMethod_var);
		V_0 = L_6;
		LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * L_7 = V_0;
		if (!L_7)
		{
			goto IL_0032;
		}
	}
	{
		LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * L_8 = V_0;
		NullCheck(L_8);
		LocalNetwork_InternalDisconnect_mD5774B0D59C47658D08C882017A481640DD0A386(L_8, __this, /*hidden argument*/NULL);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_9 = ___id0;
		LocalNetwork_InternalDisconnect_mEF513BD39E3796C3C0744D5AE51EC9F2F8853C72(__this, L_9, /*hidden argument*/NULL);
		return;
	}

IL_0032:
	{
		LocalNetwork_CleanupWreakReferences_m1337A34E6D7A17810C73FFB7A2BDDDCDC02C6AD6(__this, /*hidden argument*/NULL);
	}

IL_0038:
	{
		return;
	}
}
// Byn.Awrtc.ConnectionId Byn.Awrtc.LocalNetwork::FindConnectionId(Byn.Awrtc.LocalNetwork)
extern "C" IL2CPP_METHOD_ATTR ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  LocalNetwork_FindConnectionId_m9A3BD72C12EC7D9809CDB08C37B15B043BB2014D (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * ___network0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocalNetwork_FindConnectionId_m9A3BD72C12EC7D9809CDB08C37B15B043BB2014D_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  V_0;
	memset(&V_0, 0, sizeof(V_0));
	KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F  V_1;
	memset(&V_1, 0, sizeof(V_1));
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  V_2;
	memset(&V_2, 0, sizeof(V_2));
	Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08  V_3;
	memset(&V_3, 0, sizeof(V_3));
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 2);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * L_0 = __this->get_mConnectionNetwork_7();
		NullCheck(L_0);
		Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08  L_1 = Dictionary_2_GetEnumerator_mE62B21D25025E42B5C035C8843139621A467EA22(L_0, /*hidden argument*/Dictionary_2_GetEnumerator_mE62B21D25025E42B5C035C8843139621A467EA22_RuntimeMethod_var);
		V_3 = L_1;
	}

IL_000c:
	try
	{ // begin try (depth: 1)
		{
			goto IL_0031;
		}

IL_000e:
		{
			KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F  L_2 = Enumerator_get_Current_m003120CE0D40F915FB399DE3CB7FD3DB8F5663DA((Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08 *)(&V_3), /*hidden argument*/Enumerator_get_Current_m003120CE0D40F915FB399DE3CB7FD3DB8F5663DA_RuntimeMethod_var);
			V_1 = L_2;
			WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * L_3 = KeyValuePair_2_get_Value_mD5E7F1EC28FEF494AFD05F853C4B120549642FC1((KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F *)(&V_1), /*hidden argument*/KeyValuePair_2_get_Value_mD5E7F1EC28FEF494AFD05F853C4B120549642FC1_RuntimeMethod_var);
			NullCheck(L_3);
			LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * L_4 = WeakRef_1_Get_m7326E507F345D748A6AD3E9BA422CFE3275BC7D8(L_3, /*hidden argument*/WeakRef_1_Get_m7326E507F345D748A6AD3E9BA422CFE3275BC7D8_RuntimeMethod_var);
			LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * L_5 = ___network0;
			if ((!(((RuntimeObject*)(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 *)L_4) == ((RuntimeObject*)(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 *)L_5))))
			{
				goto IL_0031;
			}
		}

IL_0025:
		{
			ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_6 = KeyValuePair_2_get_Key_mF0E7E961867D8DF96DBB3A101E204AFFF4BE8570((KeyValuePair_2_t285938DD1E0EAC06C49621A86B042A11EE26877F *)(&V_1), /*hidden argument*/KeyValuePair_2_get_Key_mF0E7E961867D8DF96DBB3A101E204AFFF4BE8570_RuntimeMethod_var);
			V_0 = L_6;
			ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_7 = V_0;
			V_2 = L_7;
			IL2CPP_LEAVE(0x50, FINALLY_003c);
		}

IL_0031:
		{
			bool L_8 = Enumerator_MoveNext_mADC221420F19A87B6C2DE5C2EE1C2796D03FA138((Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08 *)(&V_3), /*hidden argument*/Enumerator_MoveNext_mADC221420F19A87B6C2DE5C2EE1C2796D03FA138_RuntimeMethod_var);
			if (L_8)
			{
				goto IL_000e;
			}
		}

IL_003a:
		{
			IL2CPP_LEAVE(0x4A, FINALLY_003c);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_003c;
	}

FINALLY_003c:
	{ // begin finally (depth: 1)
		Enumerator_Dispose_m555891B16D47D7D2E19E328764F6E8AEB9BBE073((Enumerator_t0A3DDFBD2093944DC075E7C3F127251B540B3F08 *)(&V_3), /*hidden argument*/Enumerator_Dispose_m555891B16D47D7D2E19E328764F6E8AEB9BBE073_RuntimeMethod_var);
		IL2CPP_END_FINALLY(60)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(60)
	{
		IL2CPP_JUMP_TBL(0x50, IL_0050)
		IL2CPP_JUMP_TBL(0x4A, IL_004a)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
	}

IL_004a:
	{
		IL2CPP_RUNTIME_CLASS_INIT(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_9 = ((ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields*)il2cpp_codegen_static_fields_for(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var))->get_INVALID_0();
		return L_9;
	}

IL_0050:
	{
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_10 = V_2;
		return L_10;
	}
}
// Byn.Awrtc.ConnectionId Byn.Awrtc.LocalNetwork::NextConnectionId()
extern "C" IL2CPP_METHOD_ATTR ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  LocalNetwork_NextConnectionId_m52D7F7F6AFFC8C040EEC8A25BA57E8EA556489E1 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, const RuntimeMethod* method)
{
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_0 = __this->get_mNextNetworkId_4();
		V_0 = L_0;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * L_1 = __this->get_address_of_mNextNetworkId_4();
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * L_2 = L_1;
		int16_t L_3 = L_2->get_id_1();
		L_2->set_id_1((((int16_t)((int16_t)((int32_t)il2cpp_codegen_add((int32_t)L_3, (int32_t)1))))));
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_4 = V_0;
		return L_4;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::ConnectClient(Byn.Awrtc.LocalNetwork)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_ConnectClient_m2DA894173389D07ABAEECDA48F14DCBE6DD5D92D (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * ___client0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocalNetwork_ConnectClient_m2DA894173389D07ABAEECDA48F14DCBE6DD5D92D_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		bool L_0 = LocalNetwork_get_IsServer_m4553266982BFDDB8D6B3A7C8E90CA0F97F7AB852(__this, /*hidden argument*/NULL);
		if (L_0)
		{
			goto IL_000e;
		}
	}
	{
		InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 * L_1 = (InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1 *)il2cpp_codegen_object_new(InvalidOperationException_t0530E734D823F78310CAFAFA424CA5164D93A1F1_il2cpp_TypeInfo_var);
		InvalidOperationException__ctor_m1F94EA1226068BD1B7EAA1B836A59C99979F579E(L_1, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_1, NULL, LocalNetwork_ConnectClient_m2DA894173389D07ABAEECDA48F14DCBE6DD5D92D_RuntimeMethod_var);
	}

IL_000e:
	{
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_2 = LocalNetwork_NextConnectionId_m52D7F7F6AFFC8C040EEC8A25BA57E8EA556489E1(__this, /*hidden argument*/NULL);
		V_0 = L_2;
		Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * L_3 = __this->get_mConnectionNetwork_7();
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_4 = V_0;
		LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * L_5 = ___client0;
		WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * L_6 = (WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 *)il2cpp_codegen_object_new(WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4_il2cpp_TypeInfo_var);
		WeakRef_1__ctor_mC13774F5C531EC799D4800F075E8FEE759322DC4(L_6, L_5, /*hidden argument*/WeakRef_1__ctor_mC13774F5C531EC799D4800F075E8FEE759322DC4_RuntimeMethod_var);
		NullCheck(L_3);
		Dictionary_2_set_Item_m9E06F377398DEEF5E6E39D45249196F434BC21C8(L_3, L_4, L_6, /*hidden argument*/Dictionary_2_set_Item_m9E06F377398DEEF5E6E39D45249196F434BC21C8_RuntimeMethod_var);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_7 = V_0;
		LocalNetwork_Enqueue_mCDC62798381553BB3D9B5E660D18C6E328B1FB59(__this, 6, L_7, /*hidden argument*/NULL);
		return;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::Enqueue(Byn.Awrtc.NetEventType,Byn.Awrtc.ConnectionId,Byn.Awrtc.ByteArrayBuffer)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_Enqueue_m3364B7754275AC65776D6AD3AFB86F0FB59122C6 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, uint8_t ___type0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___id1, ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * ___data2, const RuntimeMethod* method)
{
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		uint8_t L_0 = ___type0;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = ___id1;
		ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_2 = ___data2;
		NetworkEvent__ctor_mF53983C4264CD0231654304A49965EC5B9D94C9E((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&V_0), L_0, L_1, L_2, /*hidden argument*/NULL);
		NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  L_3 = V_0;
		LocalNetwork_Enqueue_m9D20B54FF730F80913DB2B65C28636DA3BCA14E1(__this, L_3, /*hidden argument*/NULL);
		return;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::Enqueue(Byn.Awrtc.NetEventType,Byn.Awrtc.ConnectionId,Byn.Awrtc.ErrorInfo)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_Enqueue_m6586F0D0E759C97E13F274594A787292C16FD85C (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, uint8_t ___type0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___id1, ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * ___error2, const RuntimeMethod* method)
{
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		uint8_t L_0 = ___type0;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = ___id1;
		ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * L_2 = ___error2;
		NetworkEvent__ctor_mB80AF54D4891D78B87014B9855C68EE206381C89((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&V_0), L_0, L_1, L_2, /*hidden argument*/NULL);
		NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  L_3 = V_0;
		LocalNetwork_Enqueue_m9D20B54FF730F80913DB2B65C28636DA3BCA14E1(__this, L_3, /*hidden argument*/NULL);
		return;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::Enqueue(Byn.Awrtc.NetEventType,Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_Enqueue_mCDC62798381553BB3D9B5E660D18C6E328B1FB59 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, uint8_t ___type0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___id1, const RuntimeMethod* method)
{
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  V_0;
	memset(&V_0, 0, sizeof(V_0));
	{
		uint8_t L_0 = ___type0;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = ___id1;
		NetworkEvent__ctor_m331245C2DC884EF629C1B1103876AD951A650585((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&V_0), L_0, L_1, /*hidden argument*/NULL);
		NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  L_2 = V_0;
		LocalNetwork_Enqueue_m9D20B54FF730F80913DB2B65C28636DA3BCA14E1(__this, L_2, /*hidden argument*/NULL);
		return;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::Enqueue(Byn.Awrtc.NetworkEvent)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_Enqueue_m9D20B54FF730F80913DB2B65C28636DA3BCA14E1 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  ___ev0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocalNetwork_Enqueue_m9D20B54FF730F80913DB2B65C28636DA3BCA14E1_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Queue_1_t9466208D536BE6F2841E0F91579602EAEB5162BF * L_0 = __this->get_mEvents_6();
		NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  L_1 = ___ev0;
		NullCheck(L_0);
		Queue_1_Enqueue_m4EABC517D5EF21AD49565B814AEBA980EEC805DB(L_0, L_1, /*hidden argument*/Queue_1_Enqueue_m4EABC517D5EF21AD49565B814AEBA980EEC805DB_RuntimeMethod_var);
		return;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::ReceiveData(Byn.Awrtc.LocalNetwork,System.Byte[],System.Int32,System.Int32,System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_ReceiveData_mB8112F374B300211274D8C38432A155CFEE9D31B (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * ___network0, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___data1, int32_t ___offset2, int32_t ___length3, bool ___reliable4, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocalNetwork_ReceiveData_mB8112F374B300211274D8C38432A155CFEE9D31B_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  V_0;
	memset(&V_0, 0, sizeof(V_0));
	ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * V_1 = NULL;
	uint8_t V_2 = 0;
	{
		LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * L_0 = ___network0;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = LocalNetwork_FindConnectionId_m9A3BD72C12EC7D9809CDB08C37B15B043BB2014D(__this, L_0, /*hidden argument*/NULL);
		V_0 = L_1;
		int32_t L_2 = ___length3;
		IL2CPP_RUNTIME_CLASS_INIT(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var);
		ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_3 = ByteArrayBuffer_Get_m1CA04F719970DD2C4E61B152A14D1A8528641CC0(L_2, (bool)0, /*hidden argument*/NULL);
		V_1 = L_3;
		ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_4 = V_1;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_5 = ___data1;
		int32_t L_6 = ___offset2;
		int32_t L_7 = ___length3;
		NullCheck(L_4);
		ByteArrayBuffer_CopyFrom_mEF2A576FF26FA7A4FD0A4EEB865770FC72DEDD94(L_4, L_5, L_6, L_7, /*hidden argument*/NULL);
		ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_8 = V_1;
		NullCheck(L_8);
		int32_t L_9 = ByteArrayBuffer_get_PositionReadRelative_m0E958B7F3E5C4BA2A813CC0B243B1441FDE7B044(L_8, /*hidden argument*/NULL);
		if (!L_9)
		{
			goto IL_0043;
		}
	}
	{
		ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_10 = V_1;
		NullCheck(L_10);
		int32_t L_11 = ByteArrayBuffer_get_PositionReadRelative_m0E958B7F3E5C4BA2A813CC0B243B1441FDE7B044(L_10, /*hidden argument*/NULL);
		int32_t L_12 = L_11;
		RuntimeObject * L_13 = Box(Int32_t585191389E07734F19F3156FF88FB3EF4800D102_il2cpp_TypeInfo_var, &L_12);
		String_t* L_14 = String_Concat_mBB19C73816BDD1C3519F248E1ADC8E11A6FDB495(_stringLiteralF871D3987850781C13A3676A6FA22AE6FC2C6BDD, L_13, /*hidden argument*/NULL);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_15 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)0);
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		SLog_LE_m4B26380D8909353763D54ED1E2E1217292226234(L_14, L_15, /*hidden argument*/NULL);
	}

IL_0043:
	{
		ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_16 = V_1;
		NullCheck(L_16);
		int32_t L_17 = ByteArrayBuffer_get_PositionWriteRelative_m5BA1493019330918106D5CB819DEAD7FCC62B987(L_16, /*hidden argument*/NULL);
		if (L_17)
		{
			goto IL_005b;
		}
	}
	{
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_18 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)0);
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		SLog_LE_m4B26380D8909353763D54ED1E2E1217292226234(_stringLiteral436BCD6F201AF8D6436297C9014927BC8E346692, L_18, /*hidden argument*/NULL);
	}

IL_005b:
	{
		V_2 = 1;
		bool L_19 = ___reliable4;
		if (!L_19)
		{
			goto IL_0063;
		}
	}
	{
		V_2 = 2;
	}

IL_0063:
	{
		uint8_t L_20 = V_2;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_21 = V_0;
		ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_22 = V_1;
		LocalNetwork_Enqueue_m3364B7754275AC65776D6AD3AFB86F0FB59122C6(__this, L_20, L_21, L_22, /*hidden argument*/NULL);
		return;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::InternalDisconnect(Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_InternalDisconnect_mEF513BD39E3796C3C0744D5AE51EC9F2F8853C72 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___id0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocalNetwork_InternalDisconnect_mEF513BD39E3796C3C0744D5AE51EC9F2F8853C72_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * L_0 = __this->get_mConnectionNetwork_7();
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = ___id0;
		NullCheck(L_0);
		bool L_2 = Dictionary_2_ContainsKey_m421F3F245DD820A5F1189EDFDE3364AA2811EFE3(L_0, L_1, /*hidden argument*/Dictionary_2_ContainsKey_m421F3F245DD820A5F1189EDFDE3364AA2811EFE3_RuntimeMethod_var);
		if (!L_2)
		{
			goto IL_0023;
		}
	}
	{
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_3 = ___id0;
		LocalNetwork_Enqueue_mCDC62798381553BB3D9B5E660D18C6E328B1FB59(__this, 8, L_3, /*hidden argument*/NULL);
		Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * L_4 = __this->get_mConnectionNetwork_7();
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_5 = ___id0;
		NullCheck(L_4);
		Dictionary_2_Remove_m7985E72DCEF57B284CCA7633890A1FAC9F5169CA(L_4, L_5, /*hidden argument*/Dictionary_2_Remove_m7985E72DCEF57B284CCA7633890A1FAC9F5169CA_RuntimeMethod_var);
	}

IL_0023:
	{
		return;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::InternalDisconnect(Byn.Awrtc.LocalNetwork)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_InternalDisconnect_mD5774B0D59C47658D08C882017A481640DD0A386 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * ___ln0, const RuntimeMethod* method)
{
	{
		LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * L_0 = ___ln0;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = LocalNetwork_FindConnectionId_m9A3BD72C12EC7D9809CDB08C37B15B043BB2014D(__this, L_0, /*hidden argument*/NULL);
		LocalNetwork_InternalDisconnect_mEF513BD39E3796C3C0744D5AE51EC9F2F8853C72(__this, L_1, /*hidden argument*/NULL);
		return;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::CleanupWreakReferences()
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_CleanupWreakReferences_m1337A34E6D7A17810C73FFB7A2BDDDCDC02C6AD6 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocalNetwork_CleanupWreakReferences_m1337A34E6D7A17810C73FFB7A2BDDDCDC02C6AD6_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  V_0;
	memset(&V_0, 0, sizeof(V_0));
	WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * V_1 = NULL;
	Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17  V_2;
	memset(&V_2, 0, sizeof(V_2));
	Exception_t * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	void* __leave_targets_storage = alloca(sizeof(int32_t) * 1);
	il2cpp::utils::LeaveTargetStack __leave_targets(__leave_targets_storage);
	NO_UNUSED_WARNING (__leave_targets);
	{
		Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * L_0 = __this->get_mConnectionNetwork_7();
		NullCheck(L_0);
		KeyCollection_t22184C5C648B98E1130AB2CB15D732A497552019 * L_1 = Dictionary_2_get_Keys_mEFE37E13A4EF1325942D50D41D88AA4EC71B76D7(L_0, /*hidden argument*/Dictionary_2_get_Keys_mEFE37E13A4EF1325942D50D41D88AA4EC71B76D7_RuntimeMethod_var);
		List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * L_2 = Enumerable_ToList_TisConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_m993BAFA400E4493769271824E19E78B7023A85C5(L_1, /*hidden argument*/Enumerable_ToList_TisConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_m993BAFA400E4493769271824E19E78B7023A85C5_RuntimeMethod_var);
		NullCheck(L_2);
		Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17  L_3 = List_1_GetEnumerator_m72711B857C13554E60D06AE2C418B4FA59870E65(L_2, /*hidden argument*/List_1_GetEnumerator_m72711B857C13554E60D06AE2C418B4FA59870E65_RuntimeMethod_var);
		V_2 = L_3;
	}

IL_0016:
	try
	{ // begin try (depth: 1)
		{
			goto IL_003c;
		}

IL_0018:
		{
			ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_4 = Enumerator_get_Current_m0203034B79126F512CC77691D03434942FE5EE6C((Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 *)(&V_2), /*hidden argument*/Enumerator_get_Current_m0203034B79126F512CC77691D03434942FE5EE6C_RuntimeMethod_var);
			V_0 = L_4;
			Dictionary_2_t4C6804D07FE496BAF55D71FE2554D8EABBE6B9DB * L_5 = __this->get_mConnectionNetwork_7();
			ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_6 = V_0;
			NullCheck(L_5);
			WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * L_7 = Dictionary_2_get_Item_m1701F17231AAD3E30A9EACC44EBC78404D336E3D(L_5, L_6, /*hidden argument*/Dictionary_2_get_Item_m1701F17231AAD3E30A9EACC44EBC78404D336E3D_RuntimeMethod_var);
			V_1 = L_7;
			WeakRef_1_t52AD80447FEB9076E42A22CED25E3B181B1177F4 * L_8 = V_1;
			NullCheck(L_8);
			LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * L_9 = WeakRef_1_Get_m7326E507F345D748A6AD3E9BA422CFE3275BC7D8(L_8, /*hidden argument*/WeakRef_1_Get_m7326E507F345D748A6AD3E9BA422CFE3275BC7D8_RuntimeMethod_var);
			if (L_9)
			{
				goto IL_003c;
			}
		}

IL_0035:
		{
			ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_10 = V_0;
			LocalNetwork_InternalDisconnect_mEF513BD39E3796C3C0744D5AE51EC9F2F8853C72(__this, L_10, /*hidden argument*/NULL);
		}

IL_003c:
		{
			bool L_11 = Enumerator_MoveNext_m50BD3D91B026FC120054CB6B187B49A57689E4E7((Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 *)(&V_2), /*hidden argument*/Enumerator_MoveNext_m50BD3D91B026FC120054CB6B187B49A57689E4E7_RuntimeMethod_var);
			if (L_11)
			{
				goto IL_0018;
			}
		}

IL_0045:
		{
			IL2CPP_LEAVE(0x55, FINALLY_0047);
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__last_unhandled_exception = (Exception_t *)e.ex;
		goto FINALLY_0047;
	}

FINALLY_0047:
	{ // begin finally (depth: 1)
		Enumerator_Dispose_m62E14E84F0EFE2CD8FC246C3779797583ED04D49((Enumerator_tF0CB7A53A76C5C79B395257361774995129CAD17 *)(&V_2), /*hidden argument*/Enumerator_Dispose_m62E14E84F0EFE2CD8FC246C3779797583ED04D49_RuntimeMethod_var);
		IL2CPP_END_FINALLY(71)
	} // end finally (depth: 1)
	IL2CPP_CLEANUP(71)
	{
		IL2CPP_JUMP_TBL(0x55, IL_0055)
		IL2CPP_RETHROW_IF_UNHANDLED(Exception_t *)
	}

IL_0055:
	{
		return;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::Dispose(System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_Dispose_m7BA54233357F7A76263C3659F9AB8F018265E162 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, bool ___disposing0, const RuntimeMethod* method)
{
	{
		bool L_0 = __this->get_disposedValue_8();
		if (L_0)
		{
			goto IL_0018;
		}
	}
	{
		bool L_1 = ___disposing0;
		if (!L_1)
		{
			goto IL_0011;
		}
	}
	{
		LocalNetwork_Shutdown_m0C1D588250811D685CEE21E92FC2B079179AF461(__this, /*hidden argument*/NULL);
	}

IL_0011:
	{
		__this->set_disposedValue_8((bool)1);
	}

IL_0018:
	{
		return;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::Dispose()
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork_Dispose_mF5044853F8334A60F7B9956A5A53315ECE2416D1 (LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562 * __this, const RuntimeMethod* method)
{
	{
		VirtActionInvoker1< bool >::Invoke(14 /* System.Void Byn.Awrtc.LocalNetwork::Dispose(System.Boolean) */, __this, (bool)1);
		return;
	}
}
// System.Void Byn.Awrtc.LocalNetwork::.cctor()
extern "C" IL2CPP_METHOD_ATTR void LocalNetwork__cctor_m4D0C07B2709CDC5DAAD363D51554369A8107D377 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LocalNetwork__cctor_m4D0C07B2709CDC5DAAD363D51554369A8107D377_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		((LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields*)il2cpp_codegen_static_fields_for(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var))->set_LOCK_ADDRESS_0(_stringLiteral8585EF1239EC3A7825E5ACA3E5BB3BF44A44F792);
		((LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields*)il2cpp_codegen_static_fields_for(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var))->set_sNextId_1(1);
		Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 * L_0 = (Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2 *)il2cpp_codegen_object_new(Dictionary_2_t3D83C47A25C154C47BE0619594AB0435F23CA7C2_il2cpp_TypeInfo_var);
		Dictionary_2__ctor_mBE3AA4ECD11E0C6081829CED3F9A71E82C905F2A(L_0, /*hidden argument*/Dictionary_2__ctor_mBE3AA4ECD11E0C6081829CED3F9A71E82C905F2A_RuntimeMethod_var);
		((LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_StaticFields*)il2cpp_codegen_static_fields_for(LocalNetwork_t6CC9C9ABD435AA34E75B28DA1079343D30AEA562_il2cpp_TypeInfo_var))->set_mServers_2(L_0);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Boolean Byn.Awrtc.MediaConfig::get_Audio()
extern "C" IL2CPP_METHOD_ATTR bool MediaConfig_get_Audio_m9A5EA6849D1119E2C35B658ED37CA0504D445327 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method)
{
	{
		bool L_0 = __this->get_mAudio_0();
		return L_0;
	}
}
// System.Void Byn.Awrtc.MediaConfig::set_Audio(System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void MediaConfig_set_Audio_m1D782AA0B593C78C31E6748EA46AA59112E1F8CE (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		bool L_0 = ___value0;
		__this->set_mAudio_0(L_0);
		return;
	}
}
// System.Boolean Byn.Awrtc.MediaConfig::get_Video()
extern "C" IL2CPP_METHOD_ATTR bool MediaConfig_get_Video_mC7B07DF1B36ED8B5B7B014073DE4A47FA0B13068 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method)
{
	{
		bool L_0 = __this->get_mVideo_1();
		return L_0;
	}
}
// System.Void Byn.Awrtc.MediaConfig::set_Video(System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void MediaConfig_set_Video_m8465D09CCCE207B7E4B0D416364EEB8EA354AFE0 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		bool L_0 = ___value0;
		__this->set_mVideo_1(L_0);
		return;
	}
}
// System.String Byn.Awrtc.MediaConfig::get_VideoDeviceName()
extern "C" IL2CPP_METHOD_ATTR String_t* MediaConfig_get_VideoDeviceName_mDC5973B52BF33E6B4FFA79E0214ABE0B01AFE108 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method)
{
	{
		String_t* L_0 = __this->get_mVideoDeviceName_2();
		return L_0;
	}
}
// System.Void Byn.Awrtc.MediaConfig::set_VideoDeviceName(System.String)
extern "C" IL2CPP_METHOD_ATTR void MediaConfig_set_VideoDeviceName_mD78E973CE4A45C0CA249C5FD1ED456CBC83EF2D0 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, String_t* ___value0, const RuntimeMethod* method)
{
	{
		String_t* L_0 = ___value0;
		__this->set_mVideoDeviceName_2(L_0);
		return;
	}
}
// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::get_MinWidth()
extern "C" IL2CPP_METHOD_ATTR Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  MediaConfig_get_MinWidth_m3206840C824A7767C4F8DB4EEC60EF7408201EDB (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method)
{
	{
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_0 = __this->get_mMinWidth_3();
		return L_0;
	}
}
// System.Void Byn.Awrtc.MediaConfig::set_MinWidth(System.Nullable`1<System.Int32>)
extern "C" IL2CPP_METHOD_ATTR void MediaConfig_set_MinWidth_mF3F552A1F743F7BE65082AF128B1A3EE54D46B5D (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___value0, const RuntimeMethod* method)
{
	{
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_0 = ___value0;
		__this->set_mMinWidth_3(L_0);
		return;
	}
}
// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::get_MinHeight()
extern "C" IL2CPP_METHOD_ATTR Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  MediaConfig_get_MinHeight_mA08FE71B377AF08C0561EBC75AAA8F1F6BEABD22 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method)
{
	{
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_0 = __this->get_mMinHeight_4();
		return L_0;
	}
}
// System.Void Byn.Awrtc.MediaConfig::set_MinHeight(System.Nullable`1<System.Int32>)
extern "C" IL2CPP_METHOD_ATTR void MediaConfig_set_MinHeight_mE35C7CD18C15594CAE8178371F20FF72EE80721D (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___value0, const RuntimeMethod* method)
{
	{
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_0 = ___value0;
		__this->set_mMinHeight_4(L_0);
		return;
	}
}
// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::get_MaxWidth()
extern "C" IL2CPP_METHOD_ATTR Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  MediaConfig_get_MaxWidth_m88A44DD29260CC3594F7AF0C9B000883F6332A29 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method)
{
	{
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_0 = __this->get_mMaxWidth_5();
		return L_0;
	}
}
// System.Void Byn.Awrtc.MediaConfig::set_MaxWidth(System.Nullable`1<System.Int32>)
extern "C" IL2CPP_METHOD_ATTR void MediaConfig_set_MaxWidth_m40ECFFAB3600027BF70B7FD100AA9F94735A1FC8 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___value0, const RuntimeMethod* method)
{
	{
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_0 = ___value0;
		__this->set_mMaxWidth_5(L_0);
		return;
	}
}
// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::get_MaxHeight()
extern "C" IL2CPP_METHOD_ATTR Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  MediaConfig_get_MaxHeight_m7F772654AC31AA4CA86305634E8D0BA0695FC253 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method)
{
	{
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_0 = __this->get_mMaxHeight_6();
		return L_0;
	}
}
// System.Void Byn.Awrtc.MediaConfig::set_MaxHeight(System.Nullable`1<System.Int32>)
extern "C" IL2CPP_METHOD_ATTR void MediaConfig_set_MaxHeight_m9528F762FBCA544FE81FEED89116947ACDAE9477 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___value0, const RuntimeMethod* method)
{
	{
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_0 = ___value0;
		__this->set_mMaxHeight_6(L_0);
		return;
	}
}
// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::get_IdealWidth()
extern "C" IL2CPP_METHOD_ATTR Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  MediaConfig_get_IdealWidth_mCAF4D2637DB2C207E89E9E4B1B94D21C2FC5D9FE (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method)
{
	{
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_0 = __this->get_mIdealWidth_7();
		return L_0;
	}
}
// System.Void Byn.Awrtc.MediaConfig::set_IdealWidth(System.Nullable`1<System.Int32>)
extern "C" IL2CPP_METHOD_ATTR void MediaConfig_set_IdealWidth_m4660A65C8E78F0FED4ED3023CBE2D2CB2886A615 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___value0, const RuntimeMethod* method)
{
	{
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_0 = ___value0;
		__this->set_mIdealWidth_7(L_0);
		return;
	}
}
// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::get_IdealHeight()
extern "C" IL2CPP_METHOD_ATTR Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  MediaConfig_get_IdealHeight_mC4FA1D5E861B781CE7BE0DF4AC6FF4B2EB0B01C1 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method)
{
	{
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_0 = __this->get_mIdealHeight_8();
		return L_0;
	}
}
// System.Void Byn.Awrtc.MediaConfig::set_IdealHeight(System.Nullable`1<System.Int32>)
extern "C" IL2CPP_METHOD_ATTR void MediaConfig_set_IdealHeight_m88433F39BBDF1584EB240B5225EE19AEF0B1DEF1 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___value0, const RuntimeMethod* method)
{
	{
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_0 = ___value0;
		__this->set_mIdealHeight_8(L_0);
		return;
	}
}
// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::get_IdealFrameRate()
extern "C" IL2CPP_METHOD_ATTR Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  MediaConfig_get_IdealFrameRate_m21DE0AEACAD550A06342C353FEC64140872BA2E1 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method)
{
	{
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_0 = __this->get_mIdealFrameRate_9();
		return L_0;
	}
}
// System.Void Byn.Awrtc.MediaConfig::set_IdealFrameRate(System.Nullable`1<System.Int32>)
extern "C" IL2CPP_METHOD_ATTR void MediaConfig_set_IdealFrameRate_m0AA6DA5B871C5DECD098CCCA084B1AFDACA709B2 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  ___value0, const RuntimeMethod* method)
{
	{
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_0 = ___value0;
		__this->set_mIdealFrameRate_9(L_0);
		return;
	}
}
// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::get_MinFrameRate()
extern "C" IL2CPP_METHOD_ATTR Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  MediaConfig_get_MinFrameRate_m70A65C63DDEA9BF11B803D23AB9C489CC6753FDD (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method)
{
	{
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_0 = __this->get_mMinFrameRate_10();
		return L_0;
	}
}
// System.Nullable`1<System.Int32> Byn.Awrtc.MediaConfig::get_MaxFrameRate()
extern "C" IL2CPP_METHOD_ATTR Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  MediaConfig_get_MaxFrameRate_m8E4D79608AD51FB8318A829386D72F77638E0E32 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method)
{
	{
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_0 = __this->get_mMaxFrameRate_11();
		return L_0;
	}
}
// Byn.Awrtc.FramePixelFormat Byn.Awrtc.MediaConfig::get_Format()
extern "C" IL2CPP_METHOD_ATTR int32_t MediaConfig_get_Format_mC7D69871CE9963DAFC16EA2C9D5F25488DDC2492 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method)
{
	{
		int32_t L_0 = __this->get_mFormat_12();
		return L_0;
	}
}
// System.Void Byn.Awrtc.MediaConfig::set_Format(Byn.Awrtc.FramePixelFormat)
extern "C" IL2CPP_METHOD_ATTR void MediaConfig_set_Format_m323534BEA6DFD56ECE96A4C0E8409E0E1389D905 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, int32_t ___value0, const RuntimeMethod* method)
{
	{
		int32_t L_0 = ___value0;
		__this->set_mFormat_12(L_0);
		return;
	}
}
// System.Void Byn.Awrtc.MediaConfig::.ctor()
extern "C" IL2CPP_METHOD_ATTR void MediaConfig__ctor_m9F57DF2DA5B07EAEA3FD116B734412547CF95C50 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MediaConfig__ctor_m9F57DF2DA5B07EAEA3FD116B734412547CF95C50_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		__this->set_mAudio_0((bool)1);
		__this->set_mVideo_1((bool)1);
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * L_0 = __this->get_address_of_mMinWidth_3();
		il2cpp_codegen_initobj(L_0, sizeof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB ));
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * L_1 = __this->get_address_of_mMinHeight_4();
		il2cpp_codegen_initobj(L_1, sizeof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB ));
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * L_2 = __this->get_address_of_mMaxWidth_5();
		il2cpp_codegen_initobj(L_2, sizeof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB ));
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * L_3 = __this->get_address_of_mMaxHeight_6();
		il2cpp_codegen_initobj(L_3, sizeof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB ));
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * L_4 = __this->get_address_of_mIdealWidth_7();
		il2cpp_codegen_initobj(L_4, sizeof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB ));
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * L_5 = __this->get_address_of_mIdealHeight_8();
		il2cpp_codegen_initobj(L_5, sizeof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB ));
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * L_6 = __this->get_address_of_mIdealFrameRate_9();
		il2cpp_codegen_initobj(L_6, sizeof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB ));
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_7;
		memset(&L_7, 0, sizeof(L_7));
		Nullable_1__ctor_m11F9C228CFDF836DDFCD7880C09CB4098AB9D7F2((&L_7), (-1), /*hidden argument*/Nullable_1__ctor_m11F9C228CFDF836DDFCD7880C09CB4098AB9D7F2_RuntimeMethod_var);
		__this->set_mMinFrameRate_10(L_7);
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * L_8 = __this->get_address_of_mMaxFrameRate_11();
		il2cpp_codegen_initobj(L_8, sizeof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB ));
		__this->set_mFormat_12(1);
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void Byn.Awrtc.MediaConfig::.ctor(Byn.Awrtc.MediaConfig)
extern "C" IL2CPP_METHOD_ATTR void MediaConfig__ctor_m8DD3603B96D321F06BDC020E2341355B83584967 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___other0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MediaConfig__ctor_m8DD3603B96D321F06BDC020E2341355B83584967_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		__this->set_mAudio_0((bool)1);
		__this->set_mVideo_1((bool)1);
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * L_0 = __this->get_address_of_mMinWidth_3();
		il2cpp_codegen_initobj(L_0, sizeof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB ));
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * L_1 = __this->get_address_of_mMinHeight_4();
		il2cpp_codegen_initobj(L_1, sizeof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB ));
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * L_2 = __this->get_address_of_mMaxWidth_5();
		il2cpp_codegen_initobj(L_2, sizeof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB ));
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * L_3 = __this->get_address_of_mMaxHeight_6();
		il2cpp_codegen_initobj(L_3, sizeof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB ));
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * L_4 = __this->get_address_of_mIdealWidth_7();
		il2cpp_codegen_initobj(L_4, sizeof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB ));
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * L_5 = __this->get_address_of_mIdealHeight_8();
		il2cpp_codegen_initobj(L_5, sizeof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB ));
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * L_6 = __this->get_address_of_mIdealFrameRate_9();
		il2cpp_codegen_initobj(L_6, sizeof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB ));
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_7;
		memset(&L_7, 0, sizeof(L_7));
		Nullable_1__ctor_m11F9C228CFDF836DDFCD7880C09CB4098AB9D7F2((&L_7), (-1), /*hidden argument*/Nullable_1__ctor_m11F9C228CFDF836DDFCD7880C09CB4098AB9D7F2_RuntimeMethod_var);
		__this->set_mMinFrameRate_10(L_7);
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB * L_8 = __this->get_address_of_mMaxFrameRate_11();
		il2cpp_codegen_initobj(L_8, sizeof(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB ));
		__this->set_mFormat_12(1);
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_9 = ___other0;
		NullCheck(L_9);
		bool L_10 = L_9->get_mAudio_0();
		__this->set_mAudio_0(L_10);
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_11 = ___other0;
		NullCheck(L_11);
		bool L_12 = L_11->get_mVideo_1();
		__this->set_mVideo_1(L_12);
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_13 = ___other0;
		NullCheck(L_13);
		String_t* L_14 = L_13->get_mVideoDeviceName_2();
		__this->set_mVideoDeviceName_2(L_14);
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_15 = ___other0;
		NullCheck(L_15);
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_16 = L_15->get_mMinWidth_3();
		__this->set_mMinWidth_3(L_16);
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_17 = ___other0;
		NullCheck(L_17);
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_18 = L_17->get_mMinHeight_4();
		__this->set_mMinHeight_4(L_18);
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_19 = ___other0;
		NullCheck(L_19);
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_20 = L_19->get_mMaxWidth_5();
		__this->set_mMaxWidth_5(L_20);
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_21 = ___other0;
		NullCheck(L_21);
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_22 = L_21->get_mMaxHeight_6();
		__this->set_mMaxHeight_6(L_22);
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_23 = ___other0;
		NullCheck(L_23);
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_24 = L_23->get_mIdealWidth_7();
		__this->set_mIdealWidth_7(L_24);
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_25 = ___other0;
		NullCheck(L_25);
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_26 = L_25->get_mIdealHeight_8();
		__this->set_mIdealHeight_8(L_26);
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_27 = ___other0;
		NullCheck(L_27);
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_28 = L_27->get_mMinFrameRate_10();
		__this->set_mMinFrameRate_10(L_28);
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_29 = ___other0;
		NullCheck(L_29);
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_30 = L_29->get_mMaxFrameRate_11();
		__this->set_mMaxFrameRate_11(L_30);
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_31 = ___other0;
		NullCheck(L_31);
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_32 = L_31->get_mIdealFrameRate_9();
		__this->set_mIdealFrameRate_9(L_32);
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_33 = ___other0;
		NullCheck(L_33);
		int32_t L_34 = L_33->get_mFormat_12();
		__this->set_mFormat_12(L_34);
		return;
	}
}
// Byn.Awrtc.MediaConfig Byn.Awrtc.MediaConfig::DeepClone()
extern "C" IL2CPP_METHOD_ATTR MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * MediaConfig_DeepClone_m6700A00DAD34DACF1BA7266DD35A793AE6DCAC9F (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MediaConfig_DeepClone_m6700A00DAD34DACF1BA7266DD35A793AE6DCAC9F_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * L_0 = (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D *)il2cpp_codegen_object_new(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D_il2cpp_TypeInfo_var);
		MediaConfig__ctor_m8DD3603B96D321F06BDC020E2341355B83584967(L_0, __this, /*hidden argument*/NULL);
		return L_0;
	}
}
// System.String Byn.Awrtc.MediaConfig::ToString()
extern "C" IL2CPP_METHOD_ATTR String_t* MediaConfig_ToString_m63DACCF2CFA322BA1BE5597B28E7FD5B5D90CFA9 (MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MediaConfig_ToString_m63DACCF2CFA322BA1BE5597B28E7FD5B5D90CFA9_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringBuilder_t * V_0 = NULL;
	{
		StringBuilder_t * L_0 = (StringBuilder_t *)il2cpp_codegen_object_new(StringBuilder_t_il2cpp_TypeInfo_var);
		StringBuilder__ctor_mF928376F82E8C8FF3C11842C562DB8CF28B2735E(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		StringBuilder_t * L_1 = V_0;
		NullCheck(L_1);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_1, _stringLiteral60BA4B2DAA4ED4D070FEC06687E249E0E6F9EE45, /*hidden argument*/NULL);
		StringBuilder_t * L_2 = V_0;
		NullCheck(L_2);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_2, _stringLiteral31698239127E4EAC1142CFD64FAAE6593723B903, /*hidden argument*/NULL);
		StringBuilder_t * L_3 = V_0;
		bool L_4 = __this->get_mAudio_0();
		NullCheck(L_3);
		StringBuilder_Append_mF2E955F0669F464B89C29B8783A3E898D7E22281(L_3, L_4, /*hidden argument*/NULL);
		StringBuilder_t * L_5 = V_0;
		NullCheck(L_5);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_5, _stringLiteralBAED7BA5AEC6413E08748868412B7DC0CA626552, /*hidden argument*/NULL);
		StringBuilder_t * L_6 = V_0;
		bool L_7 = __this->get_mVideo_1();
		NullCheck(L_6);
		StringBuilder_Append_mF2E955F0669F464B89C29B8783A3E898D7E22281(L_6, L_7, /*hidden argument*/NULL);
		StringBuilder_t * L_8 = V_0;
		NullCheck(L_8);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_8, _stringLiteral09A4151F14096C2A7408B4149DE022F1D966AEA8, /*hidden argument*/NULL);
		StringBuilder_t * L_9 = V_0;
		String_t* L_10 = __this->get_mVideoDeviceName_2();
		NullCheck(L_9);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_9, L_10, /*hidden argument*/NULL);
		StringBuilder_t * L_11 = V_0;
		NullCheck(L_11);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_11, _stringLiteralA0362F9D229E59514AF33D56FA8DC257B140B594, /*hidden argument*/NULL);
		StringBuilder_t * L_12 = V_0;
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_13 = __this->get_mMinWidth_3();
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_14 = L_13;
		RuntimeObject * L_15 = Box(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_il2cpp_TypeInfo_var, &L_14);
		NullCheck(L_12);
		StringBuilder_Append_mA1A063A1388A21C8EA011DBA7FC98C24C3EE3D65(L_12, L_15, /*hidden argument*/NULL);
		StringBuilder_t * L_16 = V_0;
		NullCheck(L_16);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_16, _stringLiteral4E23A32827B8C9A20FB5A8553A8233548D1DF248, /*hidden argument*/NULL);
		StringBuilder_t * L_17 = V_0;
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_18 = __this->get_mMinHeight_4();
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_19 = L_18;
		RuntimeObject * L_20 = Box(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_il2cpp_TypeInfo_var, &L_19);
		NullCheck(L_17);
		StringBuilder_Append_mA1A063A1388A21C8EA011DBA7FC98C24C3EE3D65(L_17, L_20, /*hidden argument*/NULL);
		StringBuilder_t * L_21 = V_0;
		NullCheck(L_21);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_21, _stringLiteralEDEA56933012F1F90F89A742C42A3C78EDC92A5D, /*hidden argument*/NULL);
		StringBuilder_t * L_22 = V_0;
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_23 = __this->get_mMaxWidth_5();
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_24 = L_23;
		RuntimeObject * L_25 = Box(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_il2cpp_TypeInfo_var, &L_24);
		NullCheck(L_22);
		StringBuilder_Append_mA1A063A1388A21C8EA011DBA7FC98C24C3EE3D65(L_22, L_25, /*hidden argument*/NULL);
		StringBuilder_t * L_26 = V_0;
		NullCheck(L_26);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_26, _stringLiteral155ED2E1623BE36604E1FC855CB6975C8D4F65E8, /*hidden argument*/NULL);
		StringBuilder_t * L_27 = V_0;
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_28 = __this->get_mMaxHeight_6();
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_29 = L_28;
		RuntimeObject * L_30 = Box(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_il2cpp_TypeInfo_var, &L_29);
		NullCheck(L_27);
		StringBuilder_Append_mA1A063A1388A21C8EA011DBA7FC98C24C3EE3D65(L_27, L_30, /*hidden argument*/NULL);
		StringBuilder_t * L_31 = V_0;
		NullCheck(L_31);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_31, _stringLiteralAFC1B662AA96F0A75E199326CB377CE0820597E3, /*hidden argument*/NULL);
		StringBuilder_t * L_32 = V_0;
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_33 = __this->get_mIdealWidth_7();
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_34 = L_33;
		RuntimeObject * L_35 = Box(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_il2cpp_TypeInfo_var, &L_34);
		NullCheck(L_32);
		StringBuilder_Append_mA1A063A1388A21C8EA011DBA7FC98C24C3EE3D65(L_32, L_35, /*hidden argument*/NULL);
		StringBuilder_t * L_36 = V_0;
		NullCheck(L_36);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_36, _stringLiteralDAE75A5B63A16B78EF40E2A6B8F852114C259234, /*hidden argument*/NULL);
		StringBuilder_t * L_37 = V_0;
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_38 = __this->get_mIdealHeight_8();
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_39 = L_38;
		RuntimeObject * L_40 = Box(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_il2cpp_TypeInfo_var, &L_39);
		NullCheck(L_37);
		StringBuilder_Append_mA1A063A1388A21C8EA011DBA7FC98C24C3EE3D65(L_37, L_40, /*hidden argument*/NULL);
		StringBuilder_t * L_41 = V_0;
		NullCheck(L_41);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_41, _stringLiteral29713B181926E55DFCC9942DED648CB51605607D, /*hidden argument*/NULL);
		StringBuilder_t * L_42 = V_0;
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_43 = __this->get_mMinFrameRate_10();
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_44 = L_43;
		RuntimeObject * L_45 = Box(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_il2cpp_TypeInfo_var, &L_44);
		NullCheck(L_42);
		StringBuilder_Append_mA1A063A1388A21C8EA011DBA7FC98C24C3EE3D65(L_42, L_45, /*hidden argument*/NULL);
		StringBuilder_t * L_46 = V_0;
		NullCheck(L_46);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_46, _stringLiteral0BEC5A2BEF18B46CACEFC216CF20B85002919CB0, /*hidden argument*/NULL);
		StringBuilder_t * L_47 = V_0;
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_48 = __this->get_mMaxFrameRate_11();
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_49 = L_48;
		RuntimeObject * L_50 = Box(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_il2cpp_TypeInfo_var, &L_49);
		NullCheck(L_47);
		StringBuilder_Append_mA1A063A1388A21C8EA011DBA7FC98C24C3EE3D65(L_47, L_50, /*hidden argument*/NULL);
		StringBuilder_t * L_51 = V_0;
		NullCheck(L_51);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_51, _stringLiteral15B8795405497E337C7EA8AE5F558C94E45E5F5C, /*hidden argument*/NULL);
		StringBuilder_t * L_52 = V_0;
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_53 = __this->get_mIdealFrameRate_9();
		Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB  L_54 = L_53;
		RuntimeObject * L_55 = Box(Nullable_1_t0D03270832B3FFDDC0E7C2D89D4A0EA25376A1EB_il2cpp_TypeInfo_var, &L_54);
		NullCheck(L_52);
		StringBuilder_Append_mA1A063A1388A21C8EA011DBA7FC98C24C3EE3D65(L_52, L_55, /*hidden argument*/NULL);
		StringBuilder_t * L_56 = V_0;
		NullCheck(L_56);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_56, _stringLiteral10F8A517AC4EB3CB8D93AA1A33C9C5F706B3F896, /*hidden argument*/NULL);
		StringBuilder_t * L_57 = V_0;
		int32_t L_58 = __this->get_mFormat_12();
		int32_t L_59 = L_58;
		RuntimeObject * L_60 = Box(FramePixelFormat_tDCE4288D3AD386370E428FCC0668229B6994D9BB_il2cpp_TypeInfo_var, &L_59);
		NullCheck(L_57);
		StringBuilder_Append_mA1A063A1388A21C8EA011DBA7FC98C24C3EE3D65(L_57, L_60, /*hidden argument*/NULL);
		StringBuilder_t * L_61 = V_0;
		NullCheck(L_61);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_61, _stringLiteralC2B7DF6201FDD3362399091F0A29550DF3505B6A, /*hidden argument*/NULL);
		StringBuilder_t * L_62 = V_0;
		NullCheck(L_62);
		String_t* L_63 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_62);
		return L_63;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.String Byn.Awrtc.MessageDataBufferExt::AsStringUnicode(Byn.Awrtc.MessageDataBuffer)
extern "C" IL2CPP_METHOD_ATTR String_t* MessageDataBufferExt_AsStringUnicode_m2B5AC83632488AE41F7BA5C2272A089F61B8FCED (RuntimeObject* ___buffer0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MessageDataBufferExt_AsStringUnicode_m2B5AC83632488AE41F7BA5C2272A089F61B8FCED_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject* L_0 = ___buffer0;
		NullCheck(L_0);
		int32_t L_1 = InterfaceFuncInvoker0< int32_t >::Invoke(2 /* System.Int32 Byn.Awrtc.MessageDataBuffer::get_ContentLength() */, MessageDataBuffer_t4A531F1D6D5F8E87A1BBB8C1D88A497911547498_il2cpp_TypeInfo_var, L_0);
		if (L_1)
		{
			goto IL_000e;
		}
	}
	{
		return _stringLiteralDA39A3EE5E6B4B0D3255BFEF95601890AFD80709;
	}

IL_000e:
	{
		Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * L_2 = Encoding_get_Unicode_m86CC470F70F9BB52DDB26721F0C0D6EDAFC318AA(/*hidden argument*/NULL);
		RuntimeObject* L_3 = ___buffer0;
		NullCheck(L_3);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_4 = InterfaceFuncInvoker0< ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* >::Invoke(0 /* System.Byte[] Byn.Awrtc.MessageDataBuffer::get_Buffer() */, MessageDataBuffer_t4A531F1D6D5F8E87A1BBB8C1D88A497911547498_il2cpp_TypeInfo_var, L_3);
		RuntimeObject* L_5 = ___buffer0;
		NullCheck(L_5);
		int32_t L_6 = InterfaceFuncInvoker0< int32_t >::Invoke(1 /* System.Int32 Byn.Awrtc.MessageDataBuffer::get_Offset() */, MessageDataBuffer_t4A531F1D6D5F8E87A1BBB8C1D88A497911547498_il2cpp_TypeInfo_var, L_5);
		RuntimeObject* L_7 = ___buffer0;
		NullCheck(L_7);
		int32_t L_8 = InterfaceFuncInvoker0< int32_t >::Invoke(2 /* System.Int32 Byn.Awrtc.MessageDataBuffer::get_ContentLength() */, MessageDataBuffer_t4A531F1D6D5F8E87A1BBB8C1D88A497911547498_il2cpp_TypeInfo_var, L_7);
		NullCheck(L_2);
		String_t* L_9 = VirtFuncInvoker3< String_t*, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*, int32_t, int32_t >::Invoke(33 /* System.String System.Text.Encoding::GetString(System.Byte[],System.Int32,System.Int32) */, L_2, L_4, L_6, L_8);
		return L_9;
	}
}
// System.Byte[] Byn.Awrtc.MessageDataBufferExt::Copy(Byn.Awrtc.MessageDataBuffer)
extern "C" IL2CPP_METHOD_ATTR ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* MessageDataBufferExt_Copy_mA35B174D17F81FB2AB25399BDD5325CA8326E210 (RuntimeObject* ___buffer0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MessageDataBufferExt_Copy_mA35B174D17F81FB2AB25399BDD5325CA8326E210_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* V_0 = NULL;
	{
		RuntimeObject* L_0 = ___buffer0;
		NullCheck(L_0);
		int32_t L_1 = InterfaceFuncInvoker0< int32_t >::Invoke(2 /* System.Int32 Byn.Awrtc.MessageDataBuffer::get_ContentLength() */, MessageDataBuffer_t4A531F1D6D5F8E87A1BBB8C1D88A497911547498_il2cpp_TypeInfo_var, L_0);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_2 = (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*)SZArrayNew(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821_il2cpp_TypeInfo_var, (uint32_t)L_1);
		V_0 = L_2;
		RuntimeObject* L_3 = ___buffer0;
		NullCheck(L_3);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_4 = InterfaceFuncInvoker0< ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* >::Invoke(0 /* System.Byte[] Byn.Awrtc.MessageDataBuffer::get_Buffer() */, MessageDataBuffer_t4A531F1D6D5F8E87A1BBB8C1D88A497911547498_il2cpp_TypeInfo_var, L_3);
		RuntimeObject* L_5 = ___buffer0;
		NullCheck(L_5);
		int32_t L_6 = InterfaceFuncInvoker0< int32_t >::Invoke(1 /* System.Int32 Byn.Awrtc.MessageDataBuffer::get_Offset() */, MessageDataBuffer_t4A531F1D6D5F8E87A1BBB8C1D88A497911547498_il2cpp_TypeInfo_var, L_5);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_7 = V_0;
		RuntimeObject* L_8 = ___buffer0;
		NullCheck(L_8);
		int32_t L_9 = InterfaceFuncInvoker0< int32_t >::Invoke(2 /* System.Int32 Byn.Awrtc.MessageDataBuffer::get_ContentLength() */, MessageDataBuffer_t4A531F1D6D5F8E87A1BBB8C1D88A497911547498_il2cpp_TypeInfo_var, L_8);
		Array_Copy_mA10D079DD8D9700CA44721A219A934A2397653F6((RuntimeArray *)(RuntimeArray *)L_4, L_6, (RuntimeArray *)(RuntimeArray *)L_7, 0, L_9, /*hidden argument*/NULL);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_10 = V_0;
		return L_10;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.String Byn.Awrtc.MessageEventArgs::get_Content()
extern "C" IL2CPP_METHOD_ATTR String_t* MessageEventArgs_get_Content_m5D299FF76DC2CD14D3C4E00748472395915BC91C (MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899 * __this, const RuntimeMethod* method)
{
	{
		String_t* L_0 = __this->get_mContent_3();
		return L_0;
	}
}
// System.Void Byn.Awrtc.MessageEventArgs::.ctor(Byn.Awrtc.ConnectionId,System.String,System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void MessageEventArgs__ctor_m3F3C0FE07EDBD02D58DE442EA60D74FBA9FBC1B8 (MessageEventArgs_tB3C1E5D169AD3A3A277DADD79A5F098F53040899 * __this, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___id0, String_t* ___message1, bool ___reliable2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MessageEventArgs__ctor_m3F3C0FE07EDBD02D58DE442EA60D74FBA9FBC1B8_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_0 = ((ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields*)il2cpp_codegen_static_fields_for(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var))->get_INVALID_0();
		__this->set_mConnectionId_1(L_0);
		CallEventArgs__ctor_m4ED27A352EC2D4A66D78EEE46EE96B30F119ACCD(__this, 5, /*hidden argument*/NULL);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = ___id0;
		__this->set_mConnectionId_1(L_1);
		String_t* L_2 = ___message1;
		__this->set_mContent_3(L_2);
		bool L_3 = ___reliable2;
		__this->set_mReliable_2(L_3);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Collections.Generic.List`1<Byn.Awrtc.IceServer> Byn.Awrtc.NetworkConfig::get_IceServers()
extern "C" IL2CPP_METHOD_ATTR List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 * NetworkConfig_get_IceServers_m5E6A3C383226E2FCDB32569895032DA5F78937C2 (NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * __this, const RuntimeMethod* method)
{
	{
		List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 * L_0 = __this->get_mIceServers_0();
		return L_0;
	}
}
// System.String Byn.Awrtc.NetworkConfig::get_SignalingUrl()
extern "C" IL2CPP_METHOD_ATTR String_t* NetworkConfig_get_SignalingUrl_m23E0B3DF7D3A55FDCA43AB1FDC6CD17B3D6692E4 (NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * __this, const RuntimeMethod* method)
{
	{
		String_t* L_0 = __this->get_mSignalingUrl_1();
		return L_0;
	}
}
// System.Void Byn.Awrtc.NetworkConfig::set_SignalingUrl(System.String)
extern "C" IL2CPP_METHOD_ATTR void NetworkConfig_set_SignalingUrl_m8BE7C4E830F00645F4EBBCFAB689A4E8F15C8194 (NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * __this, String_t* ___value0, const RuntimeMethod* method)
{
	{
		String_t* L_0 = ___value0;
		__this->set_mSignalingUrl_1(L_0);
		return;
	}
}
// System.Boolean Byn.Awrtc.NetworkConfig::get_AllowRenegotiation()
extern "C" IL2CPP_METHOD_ATTR bool NetworkConfig_get_AllowRenegotiation_m053139CFE0705A02E35D62A572F3ED7A5807E94E (NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * __this, const RuntimeMethod* method)
{
	{
		bool L_0 = __this->get_mAllowRenegotiation_2();
		return L_0;
	}
}
// System.Boolean Byn.Awrtc.NetworkConfig::get_IsConference()
extern "C" IL2CPP_METHOD_ATTR bool NetworkConfig_get_IsConference_mFACBDD257AE18F00F8BED9B4325AF4956FA857D4 (NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * __this, const RuntimeMethod* method)
{
	{
		bool L_0 = __this->get_mIsConference_3();
		return L_0;
	}
}
// System.Void Byn.Awrtc.NetworkConfig::set_IsConference(System.Boolean)
extern "C" IL2CPP_METHOD_ATTR void NetworkConfig_set_IsConference_m4CBB6787E50567622F7584668B61BD237A318EE7 (NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * __this, bool ___value0, const RuntimeMethod* method)
{
	{
		bool L_0 = ___value0;
		__this->set_mIsConference_3(L_0);
		return;
	}
}
// System.String Byn.Awrtc.NetworkConfig::ToString()
extern "C" IL2CPP_METHOD_ATTR String_t* NetworkConfig_ToString_m6C2BDF22F5AFE8B70F6444BB3F20E7167DC2D305 (NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (NetworkConfig_ToString_m6C2BDF22F5AFE8B70F6444BB3F20E7167DC2D305_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringBuilder_t * V_0 = NULL;
	int32_t V_1 = 0;
	{
		StringBuilder_t * L_0 = (StringBuilder_t *)il2cpp_codegen_object_new(StringBuilder_t_il2cpp_TypeInfo_var);
		StringBuilder__ctor_mF928376F82E8C8FF3C11842C562DB8CF28B2735E(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		StringBuilder_t * L_1 = V_0;
		NullCheck(L_1);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_1, _stringLiteral60BA4B2DAA4ED4D070FEC06687E249E0E6F9EE45, /*hidden argument*/NULL);
		StringBuilder_t * L_2 = V_0;
		NullCheck(L_2);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_2, _stringLiteralCF25C07F0472FA7268D2ACC313033D48FAED9821, /*hidden argument*/NULL);
		V_1 = 0;
		goto IL_004d;
	}

IL_0022:
	{
		int32_t L_3 = V_1;
		if (!L_3)
		{
			goto IL_0031;
		}
	}
	{
		StringBuilder_t * L_4 = V_0;
		NullCheck(L_4);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_4, _stringLiteral5C10B5B2CD673A0616D529AA5234B12EE7153808, /*hidden argument*/NULL);
	}

IL_0031:
	{
		StringBuilder_t * L_5 = V_0;
		List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 * L_6 = __this->get_mIceServers_0();
		int32_t L_7 = V_1;
		NullCheck(L_6);
		IceServer_t423A5044DD3B2346555973AF68F71585262E07FA * L_8 = List_1_get_Item_mE1FEED1E5EED436AB33E8CE49D4FF88CBBF502F4(L_6, L_7, /*hidden argument*/List_1_get_Item_mE1FEED1E5EED436AB33E8CE49D4FF88CBBF502F4_RuntimeMethod_var);
		NullCheck(L_8);
		String_t* L_9 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_8);
		NullCheck(L_5);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_5, L_9, /*hidden argument*/NULL);
		int32_t L_10 = V_1;
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_10, (int32_t)1));
	}

IL_004d:
	{
		int32_t L_11 = V_1;
		List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 * L_12 = __this->get_mIceServers_0();
		NullCheck(L_12);
		int32_t L_13 = List_1_get_Count_mD6BCE7AA51AD2DF7D510F44A83CC847762DCBCFF(L_12, /*hidden argument*/List_1_get_Count_mD6BCE7AA51AD2DF7D510F44A83CC847762DCBCFF_RuntimeMethod_var);
		if ((((int32_t)L_11) < ((int32_t)L_13)))
		{
			goto IL_0022;
		}
	}
	{
		StringBuilder_t * L_14 = V_0;
		NullCheck(L_14);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_14, _stringLiteral4FF447B8EF42CA51FA6FB287BED8D40F49BE58F1, /*hidden argument*/NULL);
		StringBuilder_t * L_15 = V_0;
		NullCheck(L_15);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_15, _stringLiteralAC6BE8502DAC9F9A3BCC544E72CEF0813C14EEBC, /*hidden argument*/NULL);
		StringBuilder_t * L_16 = V_0;
		String_t* L_17 = NetworkConfig_get_SignalingUrl_m23E0B3DF7D3A55FDCA43AB1FDC6CD17B3D6692E4(__this, /*hidden argument*/NULL);
		NullCheck(L_16);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_16, L_17, /*hidden argument*/NULL);
		StringBuilder_t * L_18 = V_0;
		NullCheck(L_18);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_18, _stringLiteralAEEEE4762A134C720F75C41D126D0C6991B514AC, /*hidden argument*/NULL);
		StringBuilder_t * L_19 = V_0;
		bool L_20 = __this->get_mAllowRenegotiation_2();
		NullCheck(L_19);
		StringBuilder_Append_mF2E955F0669F464B89C29B8783A3E898D7E22281(L_19, L_20, /*hidden argument*/NULL);
		StringBuilder_t * L_21 = V_0;
		NullCheck(L_21);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_21, _stringLiteralB2CCBB7A7A9B6CB96A9B2513B508C1C56C569857, /*hidden argument*/NULL);
		StringBuilder_t * L_22 = V_0;
		bool L_23 = NetworkConfig_get_IsConference_mFACBDD257AE18F00F8BED9B4325AF4956FA857D4(__this, /*hidden argument*/NULL);
		NullCheck(L_22);
		StringBuilder_Append_mF2E955F0669F464B89C29B8783A3E898D7E22281(L_22, L_23, /*hidden argument*/NULL);
		StringBuilder_t * L_24 = V_0;
		NullCheck(L_24);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_24, _stringLiteralC2B7DF6201FDD3362399091F0A29550DF3505B6A, /*hidden argument*/NULL);
		StringBuilder_t * L_25 = V_0;
		NullCheck(L_25);
		String_t* L_26 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_25);
		return L_26;
	}
}
// System.Void Byn.Awrtc.NetworkConfig::.ctor()
extern "C" IL2CPP_METHOD_ATTR void NetworkConfig__ctor_m602D7088B4491C0C9438A2316195FAA7F1C0E5F4 (NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (NetworkConfig__ctor_m602D7088B4491C0C9438A2316195FAA7F1C0E5F4_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 * L_0 = (List_1_t071E9AF889461644CC5513065D8B09A62D4EE708 *)il2cpp_codegen_object_new(List_1_t071E9AF889461644CC5513065D8B09A62D4EE708_il2cpp_TypeInfo_var);
		List_1__ctor_mE30432DD9DBAB30B7710521567A284CCF1B2E64F(L_0, /*hidden argument*/List_1__ctor_mE30432DD9DBAB30B7710521567A284CCF1B2E64F_RuntimeMethod_var);
		__this->set_mIceServers_0(L_0);
		Object__ctor_m925ECA5E85CA100E3FB86A4F9E15C120E9A184C0(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// Conversion methods for marshalling of: Byn.Awrtc.NetworkEvent
extern "C" void NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshal_pinvoke(const NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C& unmarshaled, NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshaled_pinvoke& marshaled)
{
	marshaled.___type_0 = unmarshaled.get_type_0();
	marshaled.___connectionId_1 = unmarshaled.get_connectionId_1();
	if (unmarshaled.get_data_2() != NULL)
	{
		if (il2cpp_codegen_is_import_or_windows_runtime(unmarshaled.get_data_2()))
		{
			marshaled.___data_2 = il2cpp_codegen_com_query_interface<Il2CppIUnknown>(static_cast<Il2CppComObject*>(unmarshaled.get_data_2()));
			(marshaled.___data_2)->AddRef();
		}
		else
		{
			marshaled.___data_2 = il2cpp_codegen_com_get_or_create_ccw<Il2CppIUnknown>(unmarshaled.get_data_2());
		}
	}
	else
	{
		marshaled.___data_2 = NULL;
	}
}
extern "C" void NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshal_pinvoke_back(const NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshaled_pinvoke& marshaled, NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C& unmarshaled)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_pinvoke_FromNativeMethodDefinition_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	uint8_t unmarshaled_type_temp_0 = 0;
	unmarshaled_type_temp_0 = marshaled.___type_0;
	unmarshaled.set_type_0(unmarshaled_type_temp_0);
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  unmarshaled_connectionId_temp_1;
	memset(&unmarshaled_connectionId_temp_1, 0, sizeof(unmarshaled_connectionId_temp_1));
	unmarshaled_connectionId_temp_1 = marshaled.___connectionId_1;
	unmarshaled.set_connectionId_1(unmarshaled_connectionId_temp_1);
	if (marshaled.___data_2 != NULL)
	{
		unmarshaled.set_data_2(il2cpp_codegen_com_get_or_create_rcw_from_iunknown<RuntimeObject>(marshaled.___data_2, Il2CppComObject_il2cpp_TypeInfo_var));

		if (il2cpp_codegen_is_import_or_windows_runtime(unmarshaled.get_data_2()))
		{
			il2cpp_codegen_com_cache_queried_interface(static_cast<Il2CppComObject*>(unmarshaled.get_data_2()), Il2CppIUnknown::IID, marshaled.___data_2);
		}
	}
	else
	{
		unmarshaled.set_data_2(NULL);
	}
}
// Conversion method for clean up from marshalling of: Byn.Awrtc.NetworkEvent
extern "C" void NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshal_pinvoke_cleanup(NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshaled_pinvoke& marshaled)
{
	if (marshaled.___data_2 != NULL)
	{
		(marshaled.___data_2)->Release();
		marshaled.___data_2 = NULL;
	}
}
// Conversion methods for marshalling of: Byn.Awrtc.NetworkEvent
extern "C" void NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshal_com(const NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C& unmarshaled, NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshaled_com& marshaled)
{
	marshaled.___type_0 = unmarshaled.get_type_0();
	marshaled.___connectionId_1 = unmarshaled.get_connectionId_1();
	if (unmarshaled.get_data_2() != NULL)
	{
		if (il2cpp_codegen_is_import_or_windows_runtime(unmarshaled.get_data_2()))
		{
			marshaled.___data_2 = il2cpp_codegen_com_query_interface<Il2CppIUnknown>(static_cast<Il2CppComObject*>(unmarshaled.get_data_2()));
			(marshaled.___data_2)->AddRef();
		}
		else
		{
			marshaled.___data_2 = il2cpp_codegen_com_get_or_create_ccw<Il2CppIUnknown>(unmarshaled.get_data_2());
		}
	}
	else
	{
		marshaled.___data_2 = NULL;
	}
}
extern "C" void NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshal_com_back(const NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshaled_com& marshaled, NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C& unmarshaled)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_com_FromNativeMethodDefinition_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	uint8_t unmarshaled_type_temp_0 = 0;
	unmarshaled_type_temp_0 = marshaled.___type_0;
	unmarshaled.set_type_0(unmarshaled_type_temp_0);
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  unmarshaled_connectionId_temp_1;
	memset(&unmarshaled_connectionId_temp_1, 0, sizeof(unmarshaled_connectionId_temp_1));
	unmarshaled_connectionId_temp_1 = marshaled.___connectionId_1;
	unmarshaled.set_connectionId_1(unmarshaled_connectionId_temp_1);
	if (marshaled.___data_2 != NULL)
	{
		unmarshaled.set_data_2(il2cpp_codegen_com_get_or_create_rcw_from_iunknown<RuntimeObject>(marshaled.___data_2, Il2CppComObject_il2cpp_TypeInfo_var));

		if (il2cpp_codegen_is_import_or_windows_runtime(unmarshaled.get_data_2()))
		{
			il2cpp_codegen_com_cache_queried_interface(static_cast<Il2CppComObject*>(unmarshaled.get_data_2()), Il2CppIUnknown::IID, marshaled.___data_2);
		}
	}
	else
	{
		unmarshaled.set_data_2(NULL);
	}
}
// Conversion method for clean up from marshalling of: Byn.Awrtc.NetworkEvent
extern "C" void NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshal_com_cleanup(NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C_marshaled_com& marshaled)
{
	if (marshaled.___data_2 != NULL)
	{
		(marshaled.___data_2)->Release();
		marshaled.___data_2 = NULL;
	}
}
// Byn.Awrtc.NetEventType Byn.Awrtc.NetworkEvent::get_Type()
extern "C" IL2CPP_METHOD_ATTR uint8_t NetworkEvent_get_Type_m90AD2D28598E4CB47CC71E363D104C8AC7A705C5 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, const RuntimeMethod* method)
{
	{
		uint8_t L_0 = __this->get_type_0();
		return L_0;
	}
}
extern "C"  uint8_t NetworkEvent_get_Type_m90AD2D28598E4CB47CC71E363D104C8AC7A705C5_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * _thisAdjusted = reinterpret_cast<NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *>(__this + 1);
	return NetworkEvent_get_Type_m90AD2D28598E4CB47CC71E363D104C8AC7A705C5(_thisAdjusted, method);
}
// Byn.Awrtc.ConnectionId Byn.Awrtc.NetworkEvent::get_ConnectionId()
extern "C" IL2CPP_METHOD_ATTR ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  NetworkEvent_get_ConnectionId_m63ED1FC3B26ED68918F1395BA9D0EAF1306F2524 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, const RuntimeMethod* method)
{
	{
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_0 = __this->get_connectionId_1();
		return L_0;
	}
}
extern "C"  ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  NetworkEvent_get_ConnectionId_m63ED1FC3B26ED68918F1395BA9D0EAF1306F2524_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * _thisAdjusted = reinterpret_cast<NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *>(__this + 1);
	return NetworkEvent_get_ConnectionId_m63ED1FC3B26ED68918F1395BA9D0EAF1306F2524(_thisAdjusted, method);
}
// Byn.Awrtc.MessageDataBuffer Byn.Awrtc.NetworkEvent::get_MessageData()
extern "C" IL2CPP_METHOD_ATTR RuntimeObject* NetworkEvent_get_MessageData_m4E9F1B0D89F50E350EF0262187C7DE74ADCEED26 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (NetworkEvent_get_MessageData_m4E9F1B0D89F50E350EF0262187C7DE74ADCEED26_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject * L_0 = __this->get_data_2();
		return ((RuntimeObject*)IsInst((RuntimeObject*)L_0, MessageDataBuffer_t4A531F1D6D5F8E87A1BBB8C1D88A497911547498_il2cpp_TypeInfo_var));
	}
}
extern "C"  RuntimeObject* NetworkEvent_get_MessageData_m4E9F1B0D89F50E350EF0262187C7DE74ADCEED26_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * _thisAdjusted = reinterpret_cast<NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *>(__this + 1);
	return NetworkEvent_get_MessageData_m4E9F1B0D89F50E350EF0262187C7DE74ADCEED26(_thisAdjusted, method);
}
// System.String Byn.Awrtc.NetworkEvent::get_Info()
extern "C" IL2CPP_METHOD_ATTR String_t* NetworkEvent_get_Info_mA98458FF9FA0B252D18705DD6B1A3B17D9503E16 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (NetworkEvent_get_Info_mA98458FF9FA0B252D18705DD6B1A3B17D9503E16_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject * L_0 = __this->get_data_2();
		if (!((String_t*)IsInstSealed((RuntimeObject*)L_0, String_t_il2cpp_TypeInfo_var)))
		{
			goto IL_0019;
		}
	}
	{
		RuntimeObject * L_1 = __this->get_data_2();
		return ((String_t*)CastclassSealed((RuntimeObject*)L_1, String_t_il2cpp_TypeInfo_var));
	}

IL_0019:
	{
		RuntimeObject * L_2 = __this->get_data_2();
		if (!L_2)
		{
			goto IL_002d;
		}
	}
	{
		RuntimeObject * L_3 = __this->get_data_2();
		NullCheck(L_3);
		String_t* L_4 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_3);
		return L_4;
	}

IL_002d:
	{
		return (String_t*)NULL;
	}
}
extern "C"  String_t* NetworkEvent_get_Info_mA98458FF9FA0B252D18705DD6B1A3B17D9503E16_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * _thisAdjusted = reinterpret_cast<NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *>(__this + 1);
	return NetworkEvent_get_Info_mA98458FF9FA0B252D18705DD6B1A3B17D9503E16(_thisAdjusted, method);
}
// Byn.Awrtc.ErrorInfo Byn.Awrtc.NetworkEvent::get_ErrorInfo()
extern "C" IL2CPP_METHOD_ATTR ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * NetworkEvent_get_ErrorInfo_m8AEF4E79F149ACDE34B56754A88ADA709AAD8D95 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (NetworkEvent_get_ErrorInfo_m8AEF4E79F149ACDE34B56754A88ADA709AAD8D95_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RuntimeObject * L_0 = __this->get_data_2();
		return ((ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 *)IsInstClass((RuntimeObject*)L_0, ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167_il2cpp_TypeInfo_var));
	}
}
extern "C"  ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * NetworkEvent_get_ErrorInfo_m8AEF4E79F149ACDE34B56754A88ADA709AAD8D95_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * _thisAdjusted = reinterpret_cast<NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *>(__this + 1);
	return NetworkEvent_get_ErrorInfo_m8AEF4E79F149ACDE34B56754A88ADA709AAD8D95(_thisAdjusted, method);
}
// System.Void Byn.Awrtc.NetworkEvent::.ctor(Byn.Awrtc.NetEventType,Byn.Awrtc.ConnectionId)
extern "C" IL2CPP_METHOD_ATTR void NetworkEvent__ctor_m331245C2DC884EF629C1B1103876AD951A650585 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, uint8_t ___t0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___conId1, const RuntimeMethod* method)
{
	{
		uint8_t L_0 = ___t0;
		__this->set_type_0(L_0);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = ___conId1;
		__this->set_connectionId_1(L_1);
		__this->set_data_2(NULL);
		return;
	}
}
extern "C"  void NetworkEvent__ctor_m331245C2DC884EF629C1B1103876AD951A650585_AdjustorThunk (RuntimeObject * __this, uint8_t ___t0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___conId1, const RuntimeMethod* method)
{
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * _thisAdjusted = reinterpret_cast<NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *>(__this + 1);
	NetworkEvent__ctor_m331245C2DC884EF629C1B1103876AD951A650585(_thisAdjusted, ___t0, ___conId1, method);
}
// System.Void Byn.Awrtc.NetworkEvent::.ctor(Byn.Awrtc.NetEventType,Byn.Awrtc.ConnectionId,Byn.Awrtc.MessageDataBuffer)
extern "C" IL2CPP_METHOD_ATTR void NetworkEvent__ctor_mF53983C4264CD0231654304A49965EC5B9D94C9E (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, uint8_t ___t0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___conId1, RuntimeObject* ___dt2, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (NetworkEvent__ctor_mF53983C4264CD0231654304A49965EC5B9D94C9E_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		uint8_t L_0 = ___t0;
		__this->set_type_0(L_0);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = ___conId1;
		__this->set_connectionId_1(L_1);
		RuntimeObject* L_2 = ___dt2;
		__this->set_data_2(L_2);
		RuntimeObject * L_3 = __this->get_data_2();
		if (!L_3)
		{
			goto IL_0042;
		}
	}
	{
		RuntimeObject * L_4 = __this->get_data_2();
		if (((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B *)IsInstClass((RuntimeObject*)L_4, ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var)))
		{
			goto IL_0042;
		}
	}
	{
		RuntimeObject * L_5 = __this->get_data_2();
		if (((String_t*)IsInstSealed((RuntimeObject*)L_5, String_t_il2cpp_TypeInfo_var)))
		{
			goto IL_0042;
		}
	}
	{
		ArgumentException_tEDCD16F20A09ECE461C3DA766C16EDA8864057D1 * L_6 = (ArgumentException_tEDCD16F20A09ECE461C3DA766C16EDA8864057D1 *)il2cpp_codegen_object_new(ArgumentException_tEDCD16F20A09ECE461C3DA766C16EDA8864057D1_il2cpp_TypeInfo_var);
		ArgumentException__ctor_m9A85EF7FEFEC21DDD525A67E831D77278E5165B7(L_6, _stringLiteral7C1991541B07E44CFE14A3786817A99E02646866, /*hidden argument*/NULL);
		IL2CPP_RAISE_MANAGED_EXCEPTION(L_6, NULL, NetworkEvent__ctor_mF53983C4264CD0231654304A49965EC5B9D94C9E_RuntimeMethod_var);
	}

IL_0042:
	{
		return;
	}
}
extern "C"  void NetworkEvent__ctor_mF53983C4264CD0231654304A49965EC5B9D94C9E_AdjustorThunk (RuntimeObject * __this, uint8_t ___t0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___conId1, RuntimeObject* ___dt2, const RuntimeMethod* method)
{
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * _thisAdjusted = reinterpret_cast<NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *>(__this + 1);
	NetworkEvent__ctor_mF53983C4264CD0231654304A49965EC5B9D94C9E(_thisAdjusted, ___t0, ___conId1, ___dt2, method);
}
// System.Void Byn.Awrtc.NetworkEvent::.ctor(Byn.Awrtc.NetEventType,Byn.Awrtc.ConnectionId,System.String)
extern "C" IL2CPP_METHOD_ATTR void NetworkEvent__ctor_mA7EF6BADF8188FC05D529262AC7801F91609C857 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, uint8_t ___t0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___conId1, String_t* ___address2, const RuntimeMethod* method)
{
	{
		uint8_t L_0 = ___t0;
		__this->set_type_0(L_0);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = ___conId1;
		__this->set_connectionId_1(L_1);
		String_t* L_2 = ___address2;
		__this->set_data_2(L_2);
		return;
	}
}
extern "C"  void NetworkEvent__ctor_mA7EF6BADF8188FC05D529262AC7801F91609C857_AdjustorThunk (RuntimeObject * __this, uint8_t ___t0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___conId1, String_t* ___address2, const RuntimeMethod* method)
{
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * _thisAdjusted = reinterpret_cast<NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *>(__this + 1);
	NetworkEvent__ctor_mA7EF6BADF8188FC05D529262AC7801F91609C857(_thisAdjusted, ___t0, ___conId1, ___address2, method);
}
// System.Void Byn.Awrtc.NetworkEvent::.ctor(Byn.Awrtc.NetEventType,Byn.Awrtc.ConnectionId,Byn.Awrtc.ErrorInfo)
extern "C" IL2CPP_METHOD_ATTR void NetworkEvent__ctor_mB80AF54D4891D78B87014B9855C68EE206381C89 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, uint8_t ___t0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___conId1, ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * ___errorInfo2, const RuntimeMethod* method)
{
	{
		uint8_t L_0 = ___t0;
		__this->set_type_0(L_0);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_1 = ___conId1;
		__this->set_connectionId_1(L_1);
		ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * L_2 = ___errorInfo2;
		__this->set_data_2(L_2);
		return;
	}
}
extern "C"  void NetworkEvent__ctor_mB80AF54D4891D78B87014B9855C68EE206381C89_AdjustorThunk (RuntimeObject * __this, uint8_t ___t0, ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___conId1, ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * ___errorInfo2, const RuntimeMethod* method)
{
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * _thisAdjusted = reinterpret_cast<NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *>(__this + 1);
	NetworkEvent__ctor_mB80AF54D4891D78B87014B9855C68EE206381C89(_thisAdjusted, ___t0, ___conId1, ___errorInfo2, method);
}
// System.String Byn.Awrtc.NetworkEvent::ToString()
extern "C" IL2CPP_METHOD_ATTR String_t* NetworkEvent_ToString_m4B700DB0C7D27B2855D19F7ABF80FB5112ED2105 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (NetworkEvent_ToString_m4B700DB0C7D27B2855D19F7ABF80FB5112ED2105_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringBuilder_t * V_0 = NULL;
	ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * V_1 = NULL;
	{
		StringBuilder_t * L_0 = (StringBuilder_t *)il2cpp_codegen_object_new(StringBuilder_t_il2cpp_TypeInfo_var);
		StringBuilder__ctor_mF928376F82E8C8FF3C11842C562DB8CF28B2735E(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		StringBuilder_t * L_1 = V_0;
		NullCheck(L_1);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_1, _stringLiteral5B8E7680AFA692243CBC67CBBF5C4A5B11CD144A, /*hidden argument*/NULL);
		StringBuilder_t * L_2 = V_0;
		uint8_t L_3 = __this->get_type_0();
		uint8_t L_4 = L_3;
		RuntimeObject * L_5 = Box(NetEventType_tD5213CE1DD8CDE1161395E0973FC1F8E5FB7B0A8_il2cpp_TypeInfo_var, &L_4);
		NullCheck(L_2);
		StringBuilder_Append_mA1A063A1388A21C8EA011DBA7FC98C24C3EE3D65(L_2, L_5, /*hidden argument*/NULL);
		StringBuilder_t * L_6 = V_0;
		NullCheck(L_6);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_6, _stringLiteralDF70FFC90A8389D569FB4969E8234AE261FDFB10, /*hidden argument*/NULL);
		StringBuilder_t * L_7 = V_0;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_8 = __this->get_connectionId_1();
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_9 = L_8;
		RuntimeObject * L_10 = Box(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_il2cpp_TypeInfo_var, &L_9);
		NullCheck(L_7);
		StringBuilder_Append_mA1A063A1388A21C8EA011DBA7FC98C24C3EE3D65(L_7, L_10, /*hidden argument*/NULL);
		StringBuilder_t * L_11 = V_0;
		NullCheck(L_11);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_11, _stringLiteral2D4B2D61A9CC07F09AEC3507C0EEBDDFE12AD53C, /*hidden argument*/NULL);
		RuntimeObject * L_12 = __this->get_data_2();
		if (!((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B *)IsInstClass((RuntimeObject*)L_12, ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var)))
		{
			goto IL_0087;
		}
	}
	{
		RuntimeObject * L_13 = __this->get_data_2();
		V_1 = ((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B *)CastclassClass((RuntimeObject*)L_13, ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var));
		StringBuilder_t * L_14 = V_0;
		ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_15 = V_1;
		NullCheck(L_15);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_16 = L_15->get_array_2();
		ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_17 = V_1;
		NullCheck(L_17);
		int32_t L_18 = ByteArrayBuffer_get_Offset_m8DD0FD9586C6A3D4B70A82EF5E3B5AF9AF0A59A3(L_17, /*hidden argument*/NULL);
		ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_19 = V_1;
		NullCheck(L_19);
		int32_t L_20 = ByteArrayBuffer_get_PositionWriteAbsolute_m1E594C7A0C8E7051D4EB302510851064471D4D9D(L_19, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(BitConverter_tD5DF1CB5C5A5CB087D90BD881C8E75A332E546EE_il2cpp_TypeInfo_var);
		String_t* L_21 = BitConverter_ToString_mE205625C9473E721CCB9D53D113874A4C0E31211(L_16, L_18, L_20, /*hidden argument*/NULL);
		NullCheck(L_14);
		StringBuilder_Append_mDBB8CCBB7750C67BE2F2D92F47E6C0FA42793260(L_14, L_21, /*hidden argument*/NULL);
		goto IL_0094;
	}

IL_0087:
	{
		StringBuilder_t * L_22 = V_0;
		RuntimeObject * L_23 = __this->get_data_2();
		NullCheck(L_22);
		StringBuilder_Append_mA1A063A1388A21C8EA011DBA7FC98C24C3EE3D65(L_22, L_23, /*hidden argument*/NULL);
	}

IL_0094:
	{
		StringBuilder_t * L_24 = V_0;
		NullCheck(L_24);
		String_t* L_25 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_24);
		return L_25;
	}
}
extern "C"  String_t* NetworkEvent_ToString_m4B700DB0C7D27B2855D19F7ABF80FB5112ED2105_AdjustorThunk (RuntimeObject * __this, const RuntimeMethod* method)
{
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * _thisAdjusted = reinterpret_cast<NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *>(__this + 1);
	return NetworkEvent_ToString_m4B700DB0C7D27B2855D19F7ABF80FB5112ED2105(_thisAdjusted, method);
}
// System.Boolean Byn.Awrtc.NetworkEvent::IsMetaEvent(System.Byte[])
extern "C" IL2CPP_METHOD_ATTR bool NetworkEvent_IsMetaEvent_m6BEFDA1C4672772D4B0256672EC9F15661FCBFDB (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___arr0, const RuntimeMethod* method)
{
	uint8_t V_0 = 0x0;
	{
		V_0 = (uint8_t)((int32_t)200);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_0 = ___arr0;
		if (!L_0)
		{
			goto IL_0014;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_1 = ___arr0;
		NullCheck(L_1);
		if (!(((int32_t)((int32_t)(((RuntimeArray *)L_1)->max_length)))))
		{
			goto IL_0014;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_2 = ___arr0;
		NullCheck(L_2);
		int32_t L_3 = 0;
		uint8_t L_4 = (L_2)->GetAt(static_cast<il2cpp_array_size_t>(L_3));
		uint8_t L_5 = V_0;
		if ((((int32_t)L_4) < ((int32_t)L_5)))
		{
			goto IL_0016;
		}
	}

IL_0014:
	{
		return (bool)1;
	}

IL_0016:
	{
		return (bool)0;
	}
}
// Byn.Awrtc.NetworkEvent Byn.Awrtc.NetworkEvent::FromByteArray(System.Byte[])
extern "C" IL2CPP_METHOD_ATTR NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  NetworkEvent_FromByteArray_m31466305C7DB5DFC36469055EB90ECD536E165FC (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___arr0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (NetworkEvent_FromByteArray_m31466305C7DB5DFC36469055EB90ECD536E165FC_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	uint8_t V_0 = 0;
	uint8_t V_1 = 0;
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  V_2;
	memset(&V_2, 0, sizeof(V_2));
	uint32_t V_3 = 0;
	ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * V_4 = NULL;
	uint32_t V_5 = 0;
	uint32_t V_6 = 0;
	String_t* V_7 = NULL;
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_0 = ___arr0;
		NullCheck(L_0);
		int32_t L_1 = 0;
		uint8_t L_2 = (L_0)->GetAt(static_cast<il2cpp_array_size_t>(L_1));
		V_0 = L_2;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_3 = ___arr0;
		NullCheck(L_3);
		int32_t L_4 = 1;
		uint8_t L_5 = (L_3)->GetAt(static_cast<il2cpp_array_size_t>(L_4));
		V_1 = L_5;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_6 = ___arr0;
		IL2CPP_RUNTIME_CLASS_INIT(BitConverter_tD5DF1CB5C5A5CB087D90BD881C8E75A332E546EE_il2cpp_TypeInfo_var);
		int16_t L_7 = BitConverter_ToInt16_mBFC7B476188DF611E2B21C89693258F6A4969CEA(L_6, 2, /*hidden argument*/NULL);
		ConnectionId__ctor_m1B23DF8F185ADBFE90CF43E74F2A84983E6C5382((ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D *)(&V_2), L_7, /*hidden argument*/NULL);
		uint8_t L_8 = V_1;
		if ((!(((uint32_t)L_8) == ((uint32_t)1))))
		{
			goto IL_0069;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_9 = ___arr0;
		IL2CPP_RUNTIME_CLASS_INIT(BitConverter_tD5DF1CB5C5A5CB087D90BD881C8E75A332E546EE_il2cpp_TypeInfo_var);
		uint32_t L_10 = BitConverter_ToUInt32_mD6A3C2F4BA020691B99FABF863F6FFF6A456FF59(L_9, 4, /*hidden argument*/NULL);
		V_3 = L_10;
		uint32_t L_11 = V_3;
		IL2CPP_RUNTIME_CLASS_INIT(ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var);
		ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_12 = ByteArrayBuffer_Get_m1CA04F719970DD2C4E61B152A14D1A8528641CC0(L_11, (bool)0, /*hidden argument*/NULL);
		V_4 = L_12;
		V_5 = 0;
		goto IL_0052;
	}

IL_0030:
	{
		ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_13 = V_4;
		NullCheck(L_13);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_14 = ByteArrayBuffer_get_Buffer_mEA87A81D37582411E6A368A0E111DF7BF394433F(L_13, /*hidden argument*/NULL);
		ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_15 = V_4;
		NullCheck(L_15);
		int32_t L_16 = ByteArrayBuffer_get_Offset_m8DD0FD9586C6A3D4B70A82EF5E3B5AF9AF0A59A3(L_15, /*hidden argument*/NULL);
		uint32_t L_17 = V_5;
		if ((int64_t)(((int64_t)il2cpp_codegen_add((int64_t)(((int64_t)((int64_t)L_16))), (int64_t)(((int64_t)((uint64_t)L_17)))))) > INTPTR_MAX) IL2CPP_RAISE_MANAGED_EXCEPTION(il2cpp_codegen_get_overflow_exception(), NULL, NetworkEvent_FromByteArray_m31466305C7DB5DFC36469055EB90ECD536E165FC_RuntimeMethod_var);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_18 = ___arr0;
		uint32_t L_19 = V_5;
		NullCheck(L_18);
		uintptr_t L_20 = (((uintptr_t)((int32_t)il2cpp_codegen_add((int32_t)8, (int32_t)L_19))));
		uint8_t L_21 = (L_18)->GetAt(static_cast<il2cpp_array_size_t>(L_20));
		NullCheck(L_14);
		(L_14)->SetAt(static_cast<il2cpp_array_size_t>((((intptr_t)((int64_t)il2cpp_codegen_add((int64_t)(((int64_t)((int64_t)L_16))), (int64_t)(((int64_t)((uint64_t)L_17)))))))), (uint8_t)L_21);
		uint32_t L_22 = V_5;
		V_5 = ((int32_t)il2cpp_codegen_add((int32_t)L_22, (int32_t)1));
	}

IL_0052:
	{
		uint32_t L_23 = V_5;
		uint32_t L_24 = V_3;
		if ((!(((uint32_t)L_23) >= ((uint32_t)L_24))))
		{
			goto IL_0030;
		}
	}
	{
		ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_25 = V_4;
		uint32_t L_26 = V_3;
		NullCheck(L_25);
		ByteArrayBuffer_set_PositionWriteRelative_m934AA17DAF8473055C81A696C548D40EB8573C4D(L_25, L_26, /*hidden argument*/NULL);
		uint8_t L_27 = V_0;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_28 = V_2;
		ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B * L_29 = V_4;
		NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  L_30;
		memset(&L_30, 0, sizeof(L_30));
		NetworkEvent__ctor_mF53983C4264CD0231654304A49965EC5B9D94C9E((&L_30), L_27, L_28, L_29, /*hidden argument*/NULL);
		return L_30;
	}

IL_0069:
	{
		uint8_t L_31 = V_1;
		if ((!(((uint32_t)L_31) == ((uint32_t)2))))
		{
			goto IL_0096;
		}
	}
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_32 = ___arr0;
		IL2CPP_RUNTIME_CLASS_INIT(BitConverter_tD5DF1CB5C5A5CB087D90BD881C8E75A332E546EE_il2cpp_TypeInfo_var);
		uint32_t L_33 = BitConverter_ToUInt32_mD6A3C2F4BA020691B99FABF863F6FFF6A456FF59(L_32, 4, /*hidden argument*/NULL);
		V_6 = L_33;
		uint32_t L_34 = V_6;
		V_6 = ((int32_t)il2cpp_codegen_multiply((int32_t)L_34, (int32_t)2));
		Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * L_35 = Encoding_get_Unicode_m86CC470F70F9BB52DDB26721F0C0D6EDAFC318AA(/*hidden argument*/NULL);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_36 = ___arr0;
		uint32_t L_37 = V_6;
		NullCheck(L_35);
		String_t* L_38 = VirtFuncInvoker3< String_t*, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*, int32_t, int32_t >::Invoke(33 /* System.String System.Text.Encoding::GetString(System.Byte[],System.Int32,System.Int32) */, L_35, L_36, 8, L_37);
		V_7 = L_38;
		uint8_t L_39 = V_0;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_40 = V_2;
		String_t* L_41 = V_7;
		NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  L_42;
		memset(&L_42, 0, sizeof(L_42));
		NetworkEvent__ctor_mA7EF6BADF8188FC05D529262AC7801F91609C857((&L_42), L_39, L_40, L_41, /*hidden argument*/NULL);
		return L_42;
	}

IL_0096:
	{
		uint8_t L_43 = V_0;
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  L_44 = V_2;
		NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  L_45;
		memset(&L_45, 0, sizeof(L_45));
		NetworkEvent__ctor_m331245C2DC884EF629C1B1103876AD951A650585((&L_45), L_43, L_44, /*hidden argument*/NULL);
		return L_45;
	}
}
// System.Byte[] Byn.Awrtc.NetworkEvent::ToByteArray(Byn.Awrtc.NetworkEvent)
extern "C" IL2CPP_METHOD_ATTR ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* NetworkEvent_ToByteArray_m2C19FC5A5C98D7795FACBFC34CA65C40EDFB6785 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C  ___evt0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (NetworkEvent_ToByteArray_m2C19FC5A5C98D7795FACBFC34CA65C40EDFB6785_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	bool V_0 = false;
	uint32_t V_1 = 0;
	uint8_t V_2 = 0x0;
	String_t* V_3 = NULL;
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* V_4 = NULL;
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* V_5 = NULL;
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* V_6 = NULL;
	int32_t V_7 = 0;
	int32_t V_8 = 0;
	String_t* V_9 = NULL;
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* V_10 = NULL;
	int32_t V_11 = 0;
	uint16_t V_12 = 0;
	String_t* V_13 = NULL;
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* V_14 = NULL;
	{
		V_0 = (bool)1;
		V_1 = 4;
		V_2 = (uint8_t)0;
		RuntimeObject * L_0 = (&___evt0)->get_data_2();
		if (!((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B *)IsInstClass((RuntimeObject*)L_0, ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var)))
		{
			goto IL_0029;
		}
	}
	{
		V_2 = (uint8_t)1;
		uint32_t L_1 = V_1;
		RuntimeObject* L_2 = NetworkEvent_get_MessageData_m4E9F1B0D89F50E350EF0262187C7DE74ADCEED26((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		NullCheck(L_2);
		int32_t L_3 = InterfaceFuncInvoker0< int32_t >::Invoke(2 /* System.Int32 Byn.Awrtc.MessageDataBuffer::get_ContentLength() */, MessageDataBuffer_t4A531F1D6D5F8E87A1BBB8C1D88A497911547498_il2cpp_TypeInfo_var, L_2);
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_1, (int32_t)((int32_t)il2cpp_codegen_add((int32_t)4, (int32_t)L_3))));
		goto IL_0068;
	}

IL_0029:
	{
		RuntimeObject * L_4 = (&___evt0)->get_data_2();
		if (!((String_t*)IsInstSealed((RuntimeObject*)L_4, String_t_il2cpp_TypeInfo_var)))
		{
			goto IL_0068;
		}
	}
	{
		V_2 = (uint8_t)2;
		RuntimeObject * L_5 = (&___evt0)->get_data_2();
		V_3 = ((String_t*)IsInstSealed((RuntimeObject*)L_5, String_t_il2cpp_TypeInfo_var));
		bool L_6 = V_0;
		if (!L_6)
		{
			goto IL_0058;
		}
	}
	{
		uint32_t L_7 = V_1;
		String_t* L_8 = V_3;
		NullCheck(L_8);
		int32_t L_9 = String_get_Length_mD48C8A16A5CF1914F330DCE82D9BE15C3BEDD018(L_8, /*hidden argument*/NULL);
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_7, (int32_t)((int32_t)il2cpp_codegen_add((int32_t)4, (int32_t)((int32_t)il2cpp_codegen_multiply((int32_t)L_9, (int32_t)2))))));
		goto IL_0068;
	}

IL_0058:
	{
		uint32_t L_10 = V_1;
		Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * L_11 = Encoding_get_Unicode_m86CC470F70F9BB52DDB26721F0C0D6EDAFC318AA(/*hidden argument*/NULL);
		String_t* L_12 = V_3;
		NullCheck(L_11);
		int32_t L_13 = VirtFuncInvoker1< int32_t, String_t* >::Invoke(9 /* System.Int32 System.Text.Encoding::GetByteCount(System.String) */, L_11, L_12);
		V_1 = ((int32_t)il2cpp_codegen_add((int32_t)L_10, (int32_t)((int32_t)il2cpp_codegen_add((int32_t)4, (int32_t)L_13))));
	}

IL_0068:
	{
		uint32_t L_14 = V_1;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_15 = (ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*)SZArrayNew(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821_il2cpp_TypeInfo_var, (uint32_t)(((uintptr_t)L_14)));
		V_4 = L_15;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_16 = V_4;
		uint8_t L_17 = (&___evt0)->get_type_0();
		NullCheck(L_16);
		(L_16)->SetAt(static_cast<il2cpp_array_size_t>(0), (uint8_t)L_17);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_18 = V_4;
		uint8_t L_19 = V_2;
		NullCheck(L_18);
		(L_18)->SetAt(static_cast<il2cpp_array_size_t>(1), (uint8_t)L_19);
		ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * L_20 = (&___evt0)->get_address_of_connectionId_1();
		int16_t L_21 = L_20->get_id_1();
		IL2CPP_RUNTIME_CLASS_INIT(BitConverter_tD5DF1CB5C5A5CB087D90BD881C8E75A332E546EE_il2cpp_TypeInfo_var);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_22 = BitConverter_GetBytes_mB7DFC7C4705F916C40527A87C9AA6D0EABC23512(L_21, /*hidden argument*/NULL);
		V_5 = L_22;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_23 = V_4;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_24 = V_5;
		NullCheck(L_24);
		int32_t L_25 = 0;
		uint8_t L_26 = (L_24)->GetAt(static_cast<il2cpp_array_size_t>(L_25));
		NullCheck(L_23);
		(L_23)->SetAt(static_cast<il2cpp_array_size_t>(2), (uint8_t)L_26);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_27 = V_4;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_28 = V_5;
		NullCheck(L_28);
		int32_t L_29 = 1;
		uint8_t L_30 = (L_28)->GetAt(static_cast<il2cpp_array_size_t>(L_29));
		NullCheck(L_27);
		(L_27)->SetAt(static_cast<il2cpp_array_size_t>(3), (uint8_t)L_30);
		RuntimeObject * L_31 = (&___evt0)->get_data_2();
		if (!((ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B *)IsInstClass((RuntimeObject*)L_31, ByteArrayBuffer_t39C5A4320D8C9053876A3C5A596EF95EB40E257B_il2cpp_TypeInfo_var)))
		{
			goto IL_012c;
		}
	}
	{
		RuntimeObject* L_32 = NetworkEvent_get_MessageData_m4E9F1B0D89F50E350EF0262187C7DE74ADCEED26((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		NullCheck(L_32);
		int32_t L_33 = InterfaceFuncInvoker0< int32_t >::Invoke(2 /* System.Int32 Byn.Awrtc.MessageDataBuffer::get_ContentLength() */, MessageDataBuffer_t4A531F1D6D5F8E87A1BBB8C1D88A497911547498_il2cpp_TypeInfo_var, L_32);
		IL2CPP_RUNTIME_CLASS_INIT(BitConverter_tD5DF1CB5C5A5CB087D90BD881C8E75A332E546EE_il2cpp_TypeInfo_var);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_34 = BitConverter_GetBytes_mB5BCBAAFE3AE14F2AF1731187C7155A236DF38EA(L_33, /*hidden argument*/NULL);
		V_6 = L_34;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_35 = V_4;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_36 = V_6;
		NullCheck(L_36);
		int32_t L_37 = 0;
		uint8_t L_38 = (L_36)->GetAt(static_cast<il2cpp_array_size_t>(L_37));
		NullCheck(L_35);
		(L_35)->SetAt(static_cast<il2cpp_array_size_t>(4), (uint8_t)L_38);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_39 = V_4;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_40 = V_6;
		NullCheck(L_40);
		int32_t L_41 = 1;
		uint8_t L_42 = (L_40)->GetAt(static_cast<il2cpp_array_size_t>(L_41));
		NullCheck(L_39);
		(L_39)->SetAt(static_cast<il2cpp_array_size_t>(5), (uint8_t)L_42);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_43 = V_4;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_44 = V_6;
		NullCheck(L_44);
		int32_t L_45 = 2;
		uint8_t L_46 = (L_44)->GetAt(static_cast<il2cpp_array_size_t>(L_45));
		NullCheck(L_43);
		(L_43)->SetAt(static_cast<il2cpp_array_size_t>(6), (uint8_t)L_46);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_47 = V_4;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_48 = V_6;
		NullCheck(L_48);
		int32_t L_49 = 3;
		uint8_t L_50 = (L_48)->GetAt(static_cast<il2cpp_array_size_t>(L_49));
		NullCheck(L_47);
		(L_47)->SetAt(static_cast<il2cpp_array_size_t>(7), (uint8_t)L_50);
		RuntimeObject* L_51 = NetworkEvent_get_MessageData_m4E9F1B0D89F50E350EF0262187C7DE74ADCEED26((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		NullCheck(L_51);
		int32_t L_52 = InterfaceFuncInvoker0< int32_t >::Invoke(1 /* System.Int32 Byn.Awrtc.MessageDataBuffer::get_Offset() */, MessageDataBuffer_t4A531F1D6D5F8E87A1BBB8C1D88A497911547498_il2cpp_TypeInfo_var, L_51);
		V_7 = L_52;
		V_8 = 0;
		goto IL_0117;
	}

IL_00f8:
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_53 = V_4;
		int32_t L_54 = V_8;
		RuntimeObject* L_55 = NetworkEvent_get_MessageData_m4E9F1B0D89F50E350EF0262187C7DE74ADCEED26((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		NullCheck(L_55);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_56 = InterfaceFuncInvoker0< ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* >::Invoke(0 /* System.Byte[] Byn.Awrtc.MessageDataBuffer::get_Buffer() */, MessageDataBuffer_t4A531F1D6D5F8E87A1BBB8C1D88A497911547498_il2cpp_TypeInfo_var, L_55);
		int32_t L_57 = V_7;
		int32_t L_58 = V_8;
		NullCheck(L_56);
		int32_t L_59 = ((int32_t)il2cpp_codegen_add((int32_t)L_57, (int32_t)L_58));
		uint8_t L_60 = (L_56)->GetAt(static_cast<il2cpp_array_size_t>(L_59));
		NullCheck(L_53);
		(L_53)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add((int32_t)8, (int32_t)L_54))), (uint8_t)L_60);
		int32_t L_61 = V_8;
		V_8 = ((int32_t)il2cpp_codegen_add((int32_t)L_61, (int32_t)1));
	}

IL_0117:
	{
		int32_t L_62 = V_8;
		RuntimeObject* L_63 = NetworkEvent_get_MessageData_m4E9F1B0D89F50E350EF0262187C7DE74ADCEED26((NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *)(&___evt0), /*hidden argument*/NULL);
		NullCheck(L_63);
		int32_t L_64 = InterfaceFuncInvoker0< int32_t >::Invoke(2 /* System.Int32 Byn.Awrtc.MessageDataBuffer::get_ContentLength() */, MessageDataBuffer_t4A531F1D6D5F8E87A1BBB8C1D88A497911547498_il2cpp_TypeInfo_var, L_63);
		if ((((int32_t)L_62) < ((int32_t)L_64)))
		{
			goto IL_00f8;
		}
	}
	{
		goto IL_0216;
	}

IL_012c:
	{
		RuntimeObject * L_65 = (&___evt0)->get_data_2();
		if (!((String_t*)IsInstSealed((RuntimeObject*)L_65, String_t_il2cpp_TypeInfo_var)))
		{
			goto IL_0216;
		}
	}
	{
		bool L_66 = V_0;
		if (!L_66)
		{
			goto IL_01bb;
		}
	}
	{
		RuntimeObject * L_67 = (&___evt0)->get_data_2();
		V_9 = ((String_t*)IsInstSealed((RuntimeObject*)L_67, String_t_il2cpp_TypeInfo_var));
		String_t* L_68 = V_9;
		NullCheck(L_68);
		int32_t L_69 = String_get_Length_mD48C8A16A5CF1914F330DCE82D9BE15C3BEDD018(L_68, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(BitConverter_tD5DF1CB5C5A5CB087D90BD881C8E75A332E546EE_il2cpp_TypeInfo_var);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_70 = BitConverter_GetBytes_mB5BCBAAFE3AE14F2AF1731187C7155A236DF38EA(L_69, /*hidden argument*/NULL);
		V_10 = L_70;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_71 = V_4;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_72 = V_10;
		NullCheck(L_72);
		int32_t L_73 = 0;
		uint8_t L_74 = (L_72)->GetAt(static_cast<il2cpp_array_size_t>(L_73));
		NullCheck(L_71);
		(L_71)->SetAt(static_cast<il2cpp_array_size_t>(4), (uint8_t)L_74);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_75 = V_4;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_76 = V_10;
		NullCheck(L_76);
		int32_t L_77 = 1;
		uint8_t L_78 = (L_76)->GetAt(static_cast<il2cpp_array_size_t>(L_77));
		NullCheck(L_75);
		(L_75)->SetAt(static_cast<il2cpp_array_size_t>(5), (uint8_t)L_78);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_79 = V_4;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_80 = V_10;
		NullCheck(L_80);
		int32_t L_81 = 2;
		uint8_t L_82 = (L_80)->GetAt(static_cast<il2cpp_array_size_t>(L_81));
		NullCheck(L_79);
		(L_79)->SetAt(static_cast<il2cpp_array_size_t>(6), (uint8_t)L_82);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_83 = V_4;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_84 = V_10;
		NullCheck(L_84);
		int32_t L_85 = 3;
		uint8_t L_86 = (L_84)->GetAt(static_cast<il2cpp_array_size_t>(L_85));
		NullCheck(L_83);
		(L_83)->SetAt(static_cast<il2cpp_array_size_t>(7), (uint8_t)L_86);
		V_11 = 0;
		goto IL_01ae;
	}

IL_0181:
	{
		String_t* L_87 = V_9;
		int32_t L_88 = V_11;
		NullCheck(L_87);
		Il2CppChar L_89 = String_get_Chars_m14308AC3B95F8C1D9F1D1055B116B37D595F1D96(L_87, L_88, /*hidden argument*/NULL);
		V_12 = (uint16_t)L_89;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_90 = V_4;
		int32_t L_91 = V_11;
		uint16_t L_92 = V_12;
		NullCheck(L_90);
		(L_90)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add((int32_t)8, (int32_t)((int32_t)il2cpp_codegen_multiply((int32_t)L_91, (int32_t)2))))), (uint8_t)(((int32_t)((uint8_t)L_92))));
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_93 = V_4;
		int32_t L_94 = V_11;
		uint16_t L_95 = V_12;
		NullCheck(L_93);
		(L_93)->SetAt(static_cast<il2cpp_array_size_t>(((int32_t)il2cpp_codegen_add((int32_t)((int32_t)il2cpp_codegen_add((int32_t)8, (int32_t)((int32_t)il2cpp_codegen_multiply((int32_t)L_94, (int32_t)2)))), (int32_t)1))), (uint8_t)(((int32_t)((uint8_t)((int32_t)((int32_t)L_95>>(int32_t)8))))));
		int32_t L_96 = V_11;
		V_11 = ((int32_t)il2cpp_codegen_add((int32_t)L_96, (int32_t)1));
	}

IL_01ae:
	{
		int32_t L_97 = V_11;
		String_t* L_98 = V_9;
		NullCheck(L_98);
		int32_t L_99 = String_get_Length_mD48C8A16A5CF1914F330DCE82D9BE15C3BEDD018(L_98, /*hidden argument*/NULL);
		if ((((int32_t)L_97) < ((int32_t)L_99)))
		{
			goto IL_0181;
		}
	}
	{
		goto IL_0216;
	}

IL_01bb:
	{
		RuntimeObject * L_100 = (&___evt0)->get_data_2();
		V_13 = ((String_t*)IsInstSealed((RuntimeObject*)L_100, String_t_il2cpp_TypeInfo_var));
		Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * L_101 = Encoding_get_Unicode_m86CC470F70F9BB52DDB26721F0C0D6EDAFC318AA(/*hidden argument*/NULL);
		String_t* L_102 = V_13;
		NullCheck(L_101);
		int32_t L_103 = VirtFuncInvoker1< int32_t, String_t* >::Invoke(9 /* System.Int32 System.Text.Encoding::GetByteCount(System.String) */, L_101, L_102);
		IL2CPP_RUNTIME_CLASS_INIT(BitConverter_tD5DF1CB5C5A5CB087D90BD881C8E75A332E546EE_il2cpp_TypeInfo_var);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_104 = BitConverter_GetBytes_mB5BCBAAFE3AE14F2AF1731187C7155A236DF38EA(((int32_t)((int32_t)L_103/(int32_t)2)), /*hidden argument*/NULL);
		V_14 = L_104;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_105 = V_4;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_106 = V_14;
		NullCheck(L_106);
		int32_t L_107 = 0;
		uint8_t L_108 = (L_106)->GetAt(static_cast<il2cpp_array_size_t>(L_107));
		NullCheck(L_105);
		(L_105)->SetAt(static_cast<il2cpp_array_size_t>(4), (uint8_t)L_108);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_109 = V_4;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_110 = V_14;
		NullCheck(L_110);
		int32_t L_111 = 1;
		uint8_t L_112 = (L_110)->GetAt(static_cast<il2cpp_array_size_t>(L_111));
		NullCheck(L_109);
		(L_109)->SetAt(static_cast<il2cpp_array_size_t>(5), (uint8_t)L_112);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_113 = V_4;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_114 = V_14;
		NullCheck(L_114);
		int32_t L_115 = 2;
		uint8_t L_116 = (L_114)->GetAt(static_cast<il2cpp_array_size_t>(L_115));
		NullCheck(L_113);
		(L_113)->SetAt(static_cast<il2cpp_array_size_t>(6), (uint8_t)L_116);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_117 = V_4;
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_118 = V_14;
		NullCheck(L_118);
		int32_t L_119 = 3;
		uint8_t L_120 = (L_118)->GetAt(static_cast<il2cpp_array_size_t>(L_119));
		NullCheck(L_117);
		(L_117)->SetAt(static_cast<il2cpp_array_size_t>(7), (uint8_t)L_120);
		Encoding_t7837A3C0F55EAE0E3959A53C6D6E88B113ED78A4 * L_121 = Encoding_get_Unicode_m86CC470F70F9BB52DDB26721F0C0D6EDAFC318AA(/*hidden argument*/NULL);
		String_t* L_122 = V_13;
		String_t* L_123 = V_13;
		NullCheck(L_123);
		int32_t L_124 = String_get_Length_mD48C8A16A5CF1914F330DCE82D9BE15C3BEDD018(L_123, /*hidden argument*/NULL);
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_125 = V_4;
		NullCheck(L_121);
		VirtFuncInvoker5< int32_t, String_t*, int32_t, int32_t, ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821*, int32_t >::Invoke(17 /* System.Int32 System.Text.Encoding::GetBytes(System.String,System.Int32,System.Int32,System.Byte[],System.Int32) */, L_121, L_122, 0, L_124, L_125, 8);
	}

IL_0216:
	{
		ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* L_126 = V_4;
		return L_126;
	}
}
// System.Void Byn.Awrtc.NetworkEvent::AttachError(Byn.Awrtc.ErrorInfo)
extern "C" IL2CPP_METHOD_ATTR void NetworkEvent_AttachError_m04E5757641BF4A66B8CDD83705378B4147F3EC15 (NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * __this, ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * ___error0, const RuntimeMethod* method)
{
	{
		ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * L_0 = ___error0;
		__this->set_data_2(L_0);
		return;
	}
}
extern "C"  void NetworkEvent_AttachError_m04E5757641BF4A66B8CDD83705378B4147F3EC15_AdjustorThunk (RuntimeObject * __this, ErrorInfo_t7BF4629517FDF63B912A4B6AE78C4B2BD9207167 * ___error0, const RuntimeMethod* method)
{
	NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C * _thisAdjusted = reinterpret_cast<NetworkEvent_t4DD89489B65D724D8D201A81F4243CF3CF96827C *>(__this + 1);
	NetworkEvent_AttachError_m04E5757641BF4A66B8CDD83705378B4147F3EC15(_thisAdjusted, ___error0, method);
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void Byn.Awrtc.SLog::SetLogger(System.Action`2<System.Object,System.String[]>)
extern "C" IL2CPP_METHOD_ATTR void SLog_SetLogger_m5D3E7F714E0AC197E10DB6FCDB06D1209D463F91 (Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 * ___logger0, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (SLog_SetLogger_m5D3E7F714E0AC197E10DB6FCDB06D1209D463F91_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 * L_0 = ___logger0;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->set_sLogger_6(L_0);
		return;
	}
}
// System.Void Byn.Awrtc.SLog::LogException(System.Object,System.String[])
extern "C" IL2CPP_METHOD_ATTR void SLog_LogException_m36D2B19FEACBC5A8799BFC23E8B2DB1A183E88B0 (RuntimeObject * ___msg0, StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___tags1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (SLog_LogException_m36D2B19FEACBC5A8799BFC23E8B2DB1A183E88B0_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* V_0 = NULL;
	{
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 * L_0 = ((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->get_sLogger_6();
		if (!L_0)
		{
			goto IL_0023;
		}
	}
	{
		RuntimeObject * L_1 = ___msg0;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_2 = ___tags1;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_3 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)1);
		V_0 = L_3;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_4 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		String_t* L_5 = ((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->get_TAG_EXCEPTION_2();
		NullCheck(L_4);
		ArrayElementTypeCheck (L_4, L_5);
		(L_4)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_5);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_6 = V_0;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_7 = SLog_MergeTags_mFF2513B04A32F652F6FDA529489D942C805803AA(L_2, L_6, /*hidden argument*/NULL);
		SLog_LogArray_mAD74446C19CFC07B879694644E4C675F3F30508E(L_1, L_7, /*hidden argument*/NULL);
	}

IL_0023:
	{
		return;
	}
}
// System.Void Byn.Awrtc.SLog::LE(System.Object,System.String[])
extern "C" IL2CPP_METHOD_ATTR void SLog_LE_m4B26380D8909353763D54ED1E2E1217292226234 (RuntimeObject * ___msg0, StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___tags1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (SLog_LE_m4B26380D8909353763D54ED1E2E1217292226234_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* V_0 = NULL;
	{
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 * L_0 = ((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->get_sLogger_6();
		if (!L_0)
		{
			goto IL_0023;
		}
	}
	{
		RuntimeObject * L_1 = ___msg0;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_2 = ___tags1;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_3 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)1);
		V_0 = L_3;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_4 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		String_t* L_5 = ((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->get_TAG_ERROR_1();
		NullCheck(L_4);
		ArrayElementTypeCheck (L_4, L_5);
		(L_4)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_5);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_6 = V_0;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_7 = SLog_MergeTags_mFF2513B04A32F652F6FDA529489D942C805803AA(L_2, L_6, /*hidden argument*/NULL);
		SLog_LogArray_mAD74446C19CFC07B879694644E4C675F3F30508E(L_1, L_7, /*hidden argument*/NULL);
	}

IL_0023:
	{
		return;
	}
}
// System.Void Byn.Awrtc.SLog::LW(System.Object,System.String[])
extern "C" IL2CPP_METHOD_ATTR void SLog_LW_m4C1FD9091E37D07F12DFBDCE665962B60B7F2DE5 (RuntimeObject * ___msg0, StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___tags1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (SLog_LW_m4C1FD9091E37D07F12DFBDCE665962B60B7F2DE5_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* V_0 = NULL;
	{
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 * L_0 = ((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->get_sLogger_6();
		if (!L_0)
		{
			goto IL_0023;
		}
	}
	{
		RuntimeObject * L_1 = ___msg0;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_2 = ___tags1;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_3 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)1);
		V_0 = L_3;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_4 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		String_t* L_5 = ((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->get_TAG_WARNING_0();
		NullCheck(L_4);
		ArrayElementTypeCheck (L_4, L_5);
		(L_4)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_5);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_6 = V_0;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_7 = SLog_MergeTags_mFF2513B04A32F652F6FDA529489D942C805803AA(L_2, L_6, /*hidden argument*/NULL);
		SLog_LogArray_mAD74446C19CFC07B879694644E4C675F3F30508E(L_1, L_7, /*hidden argument*/NULL);
	}

IL_0023:
	{
		return;
	}
}
// System.Void Byn.Awrtc.SLog::L(System.Object,System.String[])
extern "C" IL2CPP_METHOD_ATTR void SLog_L_m2B84D1BE41D8BA16E73F6E952C5C17D7D2B686A1 (RuntimeObject * ___msg0, StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___tags1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (SLog_L_m2B84D1BE41D8BA16E73F6E952C5C17D7D2B686A1_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* V_0 = NULL;
	{
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 * L_0 = ((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->get_sLogger_6();
		if (!L_0)
		{
			goto IL_0023;
		}
	}
	{
		RuntimeObject * L_1 = ___msg0;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_2 = ___tags1;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_3 = (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E*)SZArrayNew(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E_il2cpp_TypeInfo_var, (uint32_t)1);
		V_0 = L_3;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_4 = V_0;
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		String_t* L_5 = ((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->get_TAG_INFO_3();
		NullCheck(L_4);
		ArrayElementTypeCheck (L_4, L_5);
		(L_4)->SetAt(static_cast<il2cpp_array_size_t>(0), (String_t*)L_5);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_6 = V_0;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_7 = SLog_MergeTags_mFF2513B04A32F652F6FDA529489D942C805803AA(L_2, L_6, /*hidden argument*/NULL);
		SLog_LogArray_mAD74446C19CFC07B879694644E4C675F3F30508E(L_1, L_7, /*hidden argument*/NULL);
	}

IL_0023:
	{
		return;
	}
}
// System.String[] Byn.Awrtc.SLog::MergeTags(System.String[],System.String[])
extern "C" IL2CPP_METHOD_ATTR StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* SLog_MergeTags_mFF2513B04A32F652F6FDA529489D942C805803AA (StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___tags0, StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___newTags1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (SLog_MergeTags_mFF2513B04A32F652F6FDA529489D942C805803AA_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	int32_t V_0 = 0;
	{
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_0 = ___newTags1;
		NullCheck(L_0);
		V_0 = (((int32_t)((int32_t)(((RuntimeArray *)L_0)->max_length))));
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_1 = ___newTags1;
		NullCheck(L_1);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_2 = ___tags0;
		NullCheck(L_2);
		Array_Resize_TisString_t_m2F4F7DA2A10041FA80DD5A60977304E4803AAC17((StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E**)(&___newTags1), ((int32_t)il2cpp_codegen_add((int32_t)(((int32_t)((int32_t)(((RuntimeArray *)L_1)->max_length)))), (int32_t)(((int32_t)((int32_t)(((RuntimeArray *)L_2)->max_length)))))), /*hidden argument*/Array_Resize_TisString_t_m2F4F7DA2A10041FA80DD5A60977304E4803AAC17_RuntimeMethod_var);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_3 = ___tags0;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_4 = ___newTags1;
		int32_t L_5 = V_0;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_6 = ___tags0;
		NullCheck(L_6);
		Array_Copy_mA10D079DD8D9700CA44721A219A934A2397653F6((RuntimeArray *)(RuntimeArray *)L_3, 0, (RuntimeArray *)(RuntimeArray *)L_4, L_5, (((int32_t)((int32_t)(((RuntimeArray *)L_6)->max_length)))), /*hidden argument*/NULL);
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_7 = ___newTags1;
		return L_7;
	}
}
// System.Void Byn.Awrtc.SLog::LogArray(System.Object,System.String[])
extern "C" IL2CPP_METHOD_ATTR void SLog_LogArray_mAD74446C19CFC07B879694644E4C675F3F30508E (RuntimeObject * ___obj0, StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___tags1, const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (SLog_LogArray_mAD74446C19CFC07B879694644E4C675F3F30508E_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 * L_0 = ((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->get_sLogger_6();
		if (!L_0)
		{
			goto IL_0013;
		}
	}
	{
		IL2CPP_RUNTIME_CLASS_INIT(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var);
		Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 * L_1 = ((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->get_sLogger_6();
		RuntimeObject * L_2 = ___obj0;
		StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* L_3 = ___tags1;
		NullCheck(L_1);
		Action_2_Invoke_m81A2607B01BDBA54F7C5575704E3B52B9063A079(L_1, L_2, L_3, /*hidden argument*/Action_2_Invoke_m81A2607B01BDBA54F7C5575704E3B52B9063A079_RuntimeMethod_var);
	}

IL_0013:
	{
		return;
	}
}
// System.Void Byn.Awrtc.SLog::.cctor()
extern "C" IL2CPP_METHOD_ATTR void SLog__cctor_mC00C1300F50AA43CB5BFCFABC5C6FC5BD20DADC6 (const RuntimeMethod* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (SLog__cctor_mC00C1300F50AA43CB5BFCFABC5C6FC5BD20DADC6_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->set_TAG_WARNING_0(_stringLiteralFD3EDC641024A335A508FDACEFB5F51DED5905CC);
		((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->set_TAG_ERROR_1(_stringLiteral0B99CEBE565822C64AC5D84AECB00FE40E59CBD3);
		((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->set_TAG_EXCEPTION_2(_stringLiteral587B648C037DD2A8DF4F910CEA10C5F1645EF052);
		((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->set_TAG_INFO_3(_stringLiteral9C9CF999829193894067BBD9E1484756AB736AC0);
		((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->set_TAG_DEBUG_4(_stringLiteral3F67E8F4EECF241B91F4CC8C976A487ADE34D09D);
		((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->set_TAG_VERBOSE_5(_stringLiteralA95558ADD3F80F61A7E7875E0C263324890E3782);
		((SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_StaticFields*)il2cpp_codegen_static_fields_for(SLog_t859DA99D2A0A51C719F956D188DCA86775781CE0_il2cpp_TypeInfo_var))->set_sLogger_6((Action_2_tB43DEA48F8F66EE379F215A4A4BCC7F6E7A34944 *)NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.String Byn.Awrtc.WaitForIncomingCallEventArgs::get_Address()
extern "C" IL2CPP_METHOD_ATTR String_t* WaitForIncomingCallEventArgs_get_Address_m15526D607B261340AD661D739058F58E71E2F170 (WaitForIncomingCallEventArgs_tD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86 * __this, const RuntimeMethod* method)
{
	{
		String_t* L_0 = __this->get_mAddress_1();
		return L_0;
	}
}
// System.Void Byn.Awrtc.WaitForIncomingCallEventArgs::.ctor(System.String)
extern "C" IL2CPP_METHOD_ATTR void WaitForIncomingCallEventArgs__ctor_m8A615252C226AD8065E43B233EA90820188AEE22 (WaitForIncomingCallEventArgs_tD2EF1D21CC7AFD69C0A91D106CE4E17EFF38DF86 * __this, String_t* ___address0, const RuntimeMethod* method)
{
	{
		CallEventArgs__ctor_m4ED27A352EC2D4A66D78EEE46EE96B30F119ACCD(__this, 1, /*hidden argument*/NULL);
		String_t* L_0 = ___address0;
		__this->set_mAddress_1(L_0);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
