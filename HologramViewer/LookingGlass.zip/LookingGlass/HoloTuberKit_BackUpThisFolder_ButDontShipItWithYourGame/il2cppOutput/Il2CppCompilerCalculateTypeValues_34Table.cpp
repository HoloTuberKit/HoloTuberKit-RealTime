﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "il2cpp-class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"


// Byn.Awrtc.IAwrtcFactory
struct IAwrtcFactory_t382B630EB79D3C53486E6CE2CCE3D678F862D798;
// Byn.Awrtc.IBasicNetwork
struct IBasicNetwork_t60318DADF4A0AF6F2063D0F7E9CE5611F6CB198D;
// Byn.Awrtc.ICall
struct ICall_t264BF08904DEE5C5D41DC5638FF2BF08066400CD;
// Byn.Awrtc.ICall[]
struct ICallU5BU5D_t88E87BA53231880D2D4272EBF46A2A691ADA8741;
// Byn.Awrtc.IMediaNetwork
struct IMediaNetwork_tCBCBB7AA66CDF9F9B708E061377F47420D467780;
// Byn.Awrtc.MediaConfig
struct MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D;
// Byn.Awrtc.Native.NativeVideoInput
struct NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C;
// Byn.Awrtc.NetworkConfig
struct NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47;
// Byn.Awrtc.Unity.UnityCallFactory
struct UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB;
// Byn.Unity.Examples.OneToMany
struct OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086;
// Byn.Unity.Examples.SimpleCall
struct SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD;
// CallApp
struct CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43;
// CallAppUi
struct CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867;
// InterProcessCommunicator
struct InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019;
// InterProcessCommunicator/MessageReceived
struct MessageReceived_t8F3129EEA322B159C6FD7D6F55678D155E6A9A12;
// LookingGlass.Calibration[]
struct CalibrationU5BU5D_tC92D5273B1332F23D1A9C48B726AE22F60E7B292;
// LookingGlass.Holoplay
struct Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A;
// LookingGlass.Holoplay/ViewRenderEvent
struct ViewRenderEvent_t8A52588044E632F42B64DC1EE219DC39E0DA957C;
// LookingGlass.Holoplay[]
struct HoloplayU5BU5D_t87CF66265BEF411B8D2B7F3F8EB6DBA48A1900BD;
// LookingGlass.LoadEvent
struct LoadEvent_tE7ACDCDE718293339A984D1E678134087257D727;
// LookingGlass.Quilt/Settings[]
struct SettingsU5BU5D_t91DD8F7D5BBA1B7170CB6F4ED752A213DCB2E5A3;
// MessageList
struct MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC;
// System.Action
struct Action_t591D2A86165F896B4B800BB5C25CE18672A55579;
// System.Action`1<System.String>
struct Action_1_t32A9EECF5D4397CC1B9A7C7079870875411B06D0;
// System.AsyncCallback
struct AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4;
// System.Byte[]
struct ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821;
// System.Char[]
struct CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2;
// System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Unity.Examples.ConferenceApp/VideoData>
struct Dictionary_2_t506AF32D1300A531CEAA46A92593E3079E4692F1;
// System.Collections.Generic.Dictionary`2<System.Int32,UnityEngine.KeyCode>
struct Dictionary_2_t62DE54E46DE2592000A3E642D70CC960007FB495;
// System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId>
struct List_1_tCB9967EC4C00221A410117D712FF423882EB5832;
// System.Collections.Generic.List`1<Byn.Awrtc.Unity.UnityCallFactory/InitCallbacks>
struct List_1_tA9DD76095D2B3253680DE30E64CB3A486DFBDAF7;
// System.Collections.Generic.List`1<System.Int32>
struct List_1_tE1526161A558A17A39A8B69D8EEF3801393B6226;
// System.Collections.Generic.List`1<UnityEngine.Color32>
struct List_1_t749ADA5233D9B421293A000DCB83608A24C3D5D5;
// System.Collections.Generic.List`1<UnityEngine.RectTransform>
struct List_1_t0CD9761E1DF9817484CF4FB4253C6A626DC2311C;
// System.Collections.Generic.List`1<UnityEngine.Vector2>
struct List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB;
// System.Collections.Generic.List`1<UnityEngine.Vector3>
struct List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5;
// System.Collections.Generic.List`1<UnityEngine.Vector4>
struct List_1_tFF4005B40E5BA433006DA11C56DB086B1E2FC955;
// System.Collections.Generic.Queue`1<System.String>
struct Queue_1_t234B58D376F3C134441C47D5A9EF7789374EE172;
// System.DelegateData
struct DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE;
// System.Delegate[]
struct DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86;
// System.Func`2<UnityEngine.KeyCode,System.Boolean>
struct Func_2_t53B81A840243D682C934213ABEBCB0638922A18F;
// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single>
struct Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3;
// System.IAsyncResult
struct IAsyncResult_t8E194308510B375B42432981AE5E7488C458D598;
// System.Int32[]
struct Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83;
// System.Net.IPEndPoint
struct IPEndPoint_tCD29981135F7B1989C3845BF455AD44EBC13DE3F;
// System.Net.Security.RemoteCertificateValidationCallback
struct RemoteCertificateValidationCallback_t9C6BA19681BAA3CD78E6674293A57FF5DF62831E;
// System.Net.Sockets.UdpClient
struct UdpClient_t94741C2FBA0D9E3270ABDDBA57811D00881D5641;
// System.Object[]
struct ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A;
// System.Predicate`1<UnityEngine.Component>
struct Predicate_1_t1A9CE8ADB6E9328794CC409FD5BEAACA86D7D769;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.Single[]
struct SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5;
// System.String
struct String_t;
// System.Threading.Thread
struct Thread_tF60E0A146CD3B5480CB65FF9B6016E84C5460CC7;
// System.Version
struct Version_tDBE6876C59B6F56D4F8CAA03851177ABC6FE0DFD;
// System.Void
struct Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017;
// UnityEngine.AnimationCurve
struct AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C;
// UnityEngine.Camera
struct Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34;
// UnityEngine.Canvas
struct Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591;
// UnityEngine.Color32[]
struct Color32U5BU5D_tABFBCB467E6D1B791303A0D3A3AA1A482F620983;
// UnityEngine.ComputeShader
struct ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A;
// UnityEngine.EventSystems.EventSystem
struct EventSystem_t06ACEF1C8D95D44D3A7F57ED4BAA577101B4EA77;
// UnityEngine.Events.InvokableCallList
struct InvokableCallList_t18AA4F473C7B295216B7D4B9723B4F3DFCCC9A3F;
// UnityEngine.Events.PersistentCallGroup
struct PersistentCallGroup_t6E5DF2EBDA42794B5FE0C6DAA97DF65F0BFF571F;
// UnityEngine.Events.UnityAction`1<UnityEngine.Component>
struct UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99;
// UnityEngine.GameObject
struct GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F;
// UnityEngine.Material
struct Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598;
// UnityEngine.Mesh
struct Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C;
// UnityEngine.RaycastHit2D[]
struct RaycastHit2DU5BU5D_t5F37B944987342C401FA9A231A75AD2991A66165;
// UnityEngine.RaycastHit[]
struct RaycastHitU5BU5D_tE9BB282384F0196211AD1A480477254188211F57;
// UnityEngine.RectOffset
struct RectOffset_tED44B1176E93501050480416699D1F11BAE8C87A;
// UnityEngine.RectTransform
struct RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20;
// UnityEngine.RectTransform/ReapplyDrivenProperties
struct ReapplyDrivenProperties_t431F4FBD9C59AE097FE33C4354CC6251B01B527D;
// UnityEngine.RenderTexture
struct RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6;
// UnityEngine.Renderer
struct Renderer_t0556D67DD582620D1F495627EDE30D03284151F4;
// UnityEngine.Shader
struct Shader_tE2731FF351B74AB4186897484FB01E000C1160CA;
// UnityEngine.Texture
struct Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4;
// UnityEngine.Texture2D
struct Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C;
// UnityEngine.Transform
struct Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA;
// UnityEngine.UI.Button
struct Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B;
// UnityEngine.UI.Graphic
struct Graphic_tBA2C3EF11D3DAEBB57F6879AB0BB4F8BD40D00D8;
// UnityEngine.UI.GridLayoutGroup
struct GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8;
// UnityEngine.UI.InputField
struct InputField_t533609195B110760BCFF00B746C87D81969CB005;
// UnityEngine.UI.ObjectPool`1<UnityEngine.UI.LayoutRebuilder>
struct ObjectPool_1_tFA4F33849836CDB27432AE22249BB79D68619541;
// UnityEngine.UI.RawImage
struct RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8;
// UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllCallback
struct GetRayIntersectionAllCallback_t68C2581CCF05E868297EBD3F3361274954845095;
// UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllNonAllocCallback
struct GetRayIntersectionAllNonAllocCallback_tAD7508D45DB6679B6394983579AD18D967CC2AD4;
// UnityEngine.UI.ReflectionMethodsCache/GetRaycastNonAllocCallback
struct GetRaycastNonAllocCallback_tC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D;
// UnityEngine.UI.ReflectionMethodsCache/Raycast2DCallback
struct Raycast2DCallback_tE99ABF9ABC3A380677949E8C05A3E477889B82BE;
// UnityEngine.UI.ReflectionMethodsCache/Raycast3DCallback
struct Raycast3DCallback_t83483916473C9710AEDB316A65CBE62C58935C5F;
// UnityEngine.UI.ReflectionMethodsCache/RaycastAllCallback
struct RaycastAllCallback_t751407A44270E02FAA43D0846A58EE6A8C4AE1CE;
// UnityEngine.Vector2[]
struct Vector2U5BU5D_tA065A07DFC060C1B8786BBAA5F3A6577CCEB27D6;
// UnityEngine.Vector3[]
struct Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28;

struct Delegate_t_marshaled_com;
struct Delegate_t_marshaled_pinvoke;



#ifndef U3CMODULEU3E_TCE4B768174CDE0294B05DD8ED59A7763FF34E99B_H
#define U3CMODULEU3E_TCE4B768174CDE0294B05DD8ED59A7763FF34E99B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_tCE4B768174CDE0294B05DD8ED59A7763FF34E99B 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_TCE4B768174CDE0294B05DD8ED59A7763FF34E99B_H
#ifndef U3CMODULEU3E_T51CA7CF080E6CE0730273E28881393B61A64D06E_H
#define U3CMODULEU3E_T51CA7CF080E6CE0730273E28881393B61A64D06E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t51CA7CF080E6CE0730273E28881393B61A64D06E 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T51CA7CF080E6CE0730273E28881393B61A64D06E_H
#ifndef U3CMODULEU3E_T6CDDDF959E7E18A6744E43B613F41CDAC780256A_H
#define U3CMODULEU3E_T6CDDDF959E7E18A6744E43B613F41CDAC780256A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct  U3CModuleU3E_t6CDDDF959E7E18A6744E43B613F41CDAC780256A 
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CMODULEU3E_T6CDDDF959E7E18A6744E43B613F41CDAC780256A_H
#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
#ifndef ANDROIDHELPER_TC0B54CF40032DFE35CD9AB26816E265E12D56969_H
#define ANDROIDHELPER_TC0B54CF40032DFE35CD9AB26816E265E12D56969_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.AndroidHelper
struct  AndroidHelper_tC0B54CF40032DFE35CD9AB26816E265E12D56969  : public RuntimeObject
{
public:

public:
};

struct AndroidHelper_tC0B54CF40032DFE35CD9AB26816E265E12D56969_StaticFields
{
public:
	// System.String Byn.Awrtc.Unity.AndroidHelper::jclass_AndroidVideo
	String_t* ___jclass_AndroidVideo_0;
	// System.String Byn.Awrtc.Unity.AndroidHelper::jclass_PermissionHelper
	String_t* ___jclass_PermissionHelper_1;

public:
	inline static int32_t get_offset_of_jclass_AndroidVideo_0() { return static_cast<int32_t>(offsetof(AndroidHelper_tC0B54CF40032DFE35CD9AB26816E265E12D56969_StaticFields, ___jclass_AndroidVideo_0)); }
	inline String_t* get_jclass_AndroidVideo_0() const { return ___jclass_AndroidVideo_0; }
	inline String_t** get_address_of_jclass_AndroidVideo_0() { return &___jclass_AndroidVideo_0; }
	inline void set_jclass_AndroidVideo_0(String_t* value)
	{
		___jclass_AndroidVideo_0 = value;
		Il2CppCodeGenWriteBarrier((&___jclass_AndroidVideo_0), value);
	}

	inline static int32_t get_offset_of_jclass_PermissionHelper_1() { return static_cast<int32_t>(offsetof(AndroidHelper_tC0B54CF40032DFE35CD9AB26816E265E12D56969_StaticFields, ___jclass_PermissionHelper_1)); }
	inline String_t* get_jclass_PermissionHelper_1() const { return ___jclass_PermissionHelper_1; }
	inline String_t** get_address_of_jclass_PermissionHelper_1() { return &___jclass_PermissionHelper_1; }
	inline void set_jclass_PermissionHelper_1(String_t* value)
	{
		___jclass_PermissionHelper_1 = value;
		Il2CppCodeGenWriteBarrier((&___jclass_PermissionHelper_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ANDROIDHELPER_TC0B54CF40032DFE35CD9AB26816E265E12D56969_H
#ifndef U3CU3EC_T2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_H
#define U3CU3EC_T2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityCallFactory_<>c
struct  U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_StaticFields
{
public:
	// Byn.Awrtc.Unity.UnityCallFactory_<>c Byn.Awrtc.Unity.UnityCallFactory_<>c::<>9
	U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE * ___U3CU3E9_0;
	// System.Net.Security.RemoteCertificateValidationCallback Byn.Awrtc.Unity.UnityCallFactory_<>c::<>9__30_0
	RemoteCertificateValidationCallback_t9C6BA19681BAA3CD78E6674293A57FF5DF62831E * ___U3CU3E9__30_0_1;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9_0), value);
	}

	inline static int32_t get_offset_of_U3CU3E9__30_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_StaticFields, ___U3CU3E9__30_0_1)); }
	inline RemoteCertificateValidationCallback_t9C6BA19681BAA3CD78E6674293A57FF5DF62831E * get_U3CU3E9__30_0_1() const { return ___U3CU3E9__30_0_1; }
	inline RemoteCertificateValidationCallback_t9C6BA19681BAA3CD78E6674293A57FF5DF62831E ** get_address_of_U3CU3E9__30_0_1() { return &___U3CU3E9__30_0_1; }
	inline void set_U3CU3E9__30_0_1(RemoteCertificateValidationCallback_t9C6BA19681BAA3CD78E6674293A57FF5DF62831E * value)
	{
		___U3CU3E9__30_0_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9__30_0_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC_T2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_H
#ifndef U3CCOROUTINEINITASYNCU3ED__28_TA3214622DB8E78242139C65CDFDC288D7A17C3D9_H
#define U3CCOROUTINEINITASYNCU3ED__28_TA3214622DB8E78242139C65CDFDC288D7A17C3D9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityCallFactory_<CoroutineInitAsync>d__28
struct  U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9  : public RuntimeObject
{
public:
	// System.Int32 Byn.Awrtc.Unity.UnityCallFactory_<CoroutineInitAsync>d__28::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Byn.Awrtc.Unity.UnityCallFactory_<CoroutineInitAsync>d__28::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// Byn.Awrtc.Unity.UnityCallFactory Byn.Awrtc.Unity.UnityCallFactory_<CoroutineInitAsync>d__28::<>4__this
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB * ___U3CU3E4__this_2;
	// System.Int32 Byn.Awrtc.Unity.UnityCallFactory_<CoroutineInitAsync>d__28::<waitCounter>5__2
	int32_t ___U3CwaitCounterU3E5__2_3;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9, ___U3CU3E4__this_2)); }
	inline UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E4__this_2), value);
	}

	inline static int32_t get_offset_of_U3CwaitCounterU3E5__2_3() { return static_cast<int32_t>(offsetof(U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9, ___U3CwaitCounterU3E5__2_3)); }
	inline int32_t get_U3CwaitCounterU3E5__2_3() const { return ___U3CwaitCounterU3E5__2_3; }
	inline int32_t* get_address_of_U3CwaitCounterU3E5__2_3() { return &___U3CwaitCounterU3E5__2_3; }
	inline void set_U3CwaitCounterU3E5__2_3(int32_t value)
	{
		___U3CwaitCounterU3E5__2_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CCOROUTINEINITASYNCU3ED__28_TA3214622DB8E78242139C65CDFDC288D7A17C3D9_H
#ifndef INITCALLBACKS_T1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6_H
#define INITCALLBACKS_T1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityCallFactory_InitCallbacks
struct  InitCallbacks_t1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6  : public RuntimeObject
{
public:
	// System.Action Byn.Awrtc.Unity.UnityCallFactory_InitCallbacks::onSuccess
	Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * ___onSuccess_0;
	// System.Action`1<System.String> Byn.Awrtc.Unity.UnityCallFactory_InitCallbacks::onFailure
	Action_1_t32A9EECF5D4397CC1B9A7C7079870875411B06D0 * ___onFailure_1;

public:
	inline static int32_t get_offset_of_onSuccess_0() { return static_cast<int32_t>(offsetof(InitCallbacks_t1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6, ___onSuccess_0)); }
	inline Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * get_onSuccess_0() const { return ___onSuccess_0; }
	inline Action_t591D2A86165F896B4B800BB5C25CE18672A55579 ** get_address_of_onSuccess_0() { return &___onSuccess_0; }
	inline void set_onSuccess_0(Action_t591D2A86165F896B4B800BB5C25CE18672A55579 * value)
	{
		___onSuccess_0 = value;
		Il2CppCodeGenWriteBarrier((&___onSuccess_0), value);
	}

	inline static int32_t get_offset_of_onFailure_1() { return static_cast<int32_t>(offsetof(InitCallbacks_t1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6, ___onFailure_1)); }
	inline Action_1_t32A9EECF5D4397CC1B9A7C7079870875411B06D0 * get_onFailure_1() const { return ___onFailure_1; }
	inline Action_1_t32A9EECF5D4397CC1B9A7C7079870875411B06D0 ** get_address_of_onFailure_1() { return &___onFailure_1; }
	inline void set_onFailure_1(Action_1_t32A9EECF5D4397CC1B9A7C7079870875411B06D0 * value)
	{
		___onFailure_1 = value;
		Il2CppCodeGenWriteBarrier((&___onFailure_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INITCALLBACKS_T1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6_H
#ifndef UNITYHELPER_T8385B1C3D90FCE7C88494C24381E90C932B73841_H
#define UNITYHELPER_T8385B1C3D90FCE7C88494C24381E90C932B73841_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityHelper
struct  UnityHelper_t8385B1C3D90FCE7C88494C24381E90C932B73841  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNITYHELPER_T8385B1C3D90FCE7C88494C24381E90C932B73841_H
#ifndef UNITYMEDIAHELPER_T909B65F549010A7353DC82E5AF7C0E259B42FC00_H
#define UNITYMEDIAHELPER_T909B65F549010A7353DC82E5AF7C0E259B42FC00_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityMediaHelper
struct  UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00  : public RuntimeObject
{
public:

public:
};

struct UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00_StaticFields
{
public:
	// System.String Byn.Awrtc.Unity.UnityMediaHelper::I420_MAT_NAME
	String_t* ___I420_MAT_NAME_0;
	// System.String Byn.Awrtc.Unity.UnityMediaHelper::I420_MAT_UPLANE
	String_t* ___I420_MAT_UPLANE_1;
	// System.String Byn.Awrtc.Unity.UnityMediaHelper::I420_MAT_VPLANE
	String_t* ___I420_MAT_VPLANE_2;

public:
	inline static int32_t get_offset_of_I420_MAT_NAME_0() { return static_cast<int32_t>(offsetof(UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00_StaticFields, ___I420_MAT_NAME_0)); }
	inline String_t* get_I420_MAT_NAME_0() const { return ___I420_MAT_NAME_0; }
	inline String_t** get_address_of_I420_MAT_NAME_0() { return &___I420_MAT_NAME_0; }
	inline void set_I420_MAT_NAME_0(String_t* value)
	{
		___I420_MAT_NAME_0 = value;
		Il2CppCodeGenWriteBarrier((&___I420_MAT_NAME_0), value);
	}

	inline static int32_t get_offset_of_I420_MAT_UPLANE_1() { return static_cast<int32_t>(offsetof(UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00_StaticFields, ___I420_MAT_UPLANE_1)); }
	inline String_t* get_I420_MAT_UPLANE_1() const { return ___I420_MAT_UPLANE_1; }
	inline String_t** get_address_of_I420_MAT_UPLANE_1() { return &___I420_MAT_UPLANE_1; }
	inline void set_I420_MAT_UPLANE_1(String_t* value)
	{
		___I420_MAT_UPLANE_1 = value;
		Il2CppCodeGenWriteBarrier((&___I420_MAT_UPLANE_1), value);
	}

	inline static int32_t get_offset_of_I420_MAT_VPLANE_2() { return static_cast<int32_t>(offsetof(UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00_StaticFields, ___I420_MAT_VPLANE_2)); }
	inline String_t* get_I420_MAT_VPLANE_2() const { return ___I420_MAT_VPLANE_2; }
	inline String_t** get_address_of_I420_MAT_VPLANE_2() { return &___I420_MAT_VPLANE_2; }
	inline void set_I420_MAT_VPLANE_2(String_t* value)
	{
		___I420_MAT_VPLANE_2 = value;
		Il2CppCodeGenWriteBarrier((&___I420_MAT_VPLANE_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNITYMEDIAHELPER_T909B65F549010A7353DC82E5AF7C0E259B42FC00_H
#ifndef VIDEODATA_T9C078487B97498970A01E98DEF8304B622527398_H
#define VIDEODATA_T9C078487B97498970A01E98DEF8304B622527398_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.ConferenceApp_VideoData
struct  VideoData_t9C078487B97498970A01E98DEF8304B622527398  : public RuntimeObject
{
public:
	// UnityEngine.GameObject Byn.Unity.Examples.ConferenceApp_VideoData::uiObject
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___uiObject_0;
	// UnityEngine.Texture2D Byn.Unity.Examples.ConferenceApp_VideoData::texture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___texture_1;
	// UnityEngine.UI.RawImage Byn.Unity.Examples.ConferenceApp_VideoData::image
	RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * ___image_2;

public:
	inline static int32_t get_offset_of_uiObject_0() { return static_cast<int32_t>(offsetof(VideoData_t9C078487B97498970A01E98DEF8304B622527398, ___uiObject_0)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_uiObject_0() const { return ___uiObject_0; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_uiObject_0() { return &___uiObject_0; }
	inline void set_uiObject_0(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___uiObject_0 = value;
		Il2CppCodeGenWriteBarrier((&___uiObject_0), value);
	}

	inline static int32_t get_offset_of_texture_1() { return static_cast<int32_t>(offsetof(VideoData_t9C078487B97498970A01E98DEF8304B622527398, ___texture_1)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_texture_1() const { return ___texture_1; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_texture_1() { return &___texture_1; }
	inline void set_texture_1(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___texture_1 = value;
		Il2CppCodeGenWriteBarrier((&___texture_1), value);
	}

	inline static int32_t get_offset_of_image_2() { return static_cast<int32_t>(offsetof(VideoData_t9C078487B97498970A01E98DEF8304B622527398, ___image_2)); }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * get_image_2() const { return ___image_2; }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 ** get_address_of_image_2() { return &___image_2; }
	inline void set_image_2(RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * value)
	{
		___image_2 = value;
		Il2CppCodeGenWriteBarrier((&___image_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEODATA_T9C078487B97498970A01E98DEF8304B622527398_H
#ifndef EXAMPLEGLOBALS_T56851F8D33D17DD137BD47D6F3F683BE900B236B_H
#define EXAMPLEGLOBALS_T56851F8D33D17DD137BD47D6F3F683BE900B236B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.ExampleGlobals
struct  ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B  : public RuntimeObject
{
public:

public:
};

struct ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields
{
public:
	// System.String Byn.Unity.Examples.ExampleGlobals::StunUrl
	String_t* ___StunUrl_0;
	// System.String Byn.Unity.Examples.ExampleGlobals::TurnUrl
	String_t* ___TurnUrl_1;
	// System.String Byn.Unity.Examples.ExampleGlobals::TurnUser
	String_t* ___TurnUser_2;
	// System.String Byn.Unity.Examples.ExampleGlobals::TurnPass
	String_t* ___TurnPass_3;
	// System.String Byn.Unity.Examples.ExampleGlobals::BackupStunUrl
	String_t* ___BackupStunUrl_4;

public:
	inline static int32_t get_offset_of_StunUrl_0() { return static_cast<int32_t>(offsetof(ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields, ___StunUrl_0)); }
	inline String_t* get_StunUrl_0() const { return ___StunUrl_0; }
	inline String_t** get_address_of_StunUrl_0() { return &___StunUrl_0; }
	inline void set_StunUrl_0(String_t* value)
	{
		___StunUrl_0 = value;
		Il2CppCodeGenWriteBarrier((&___StunUrl_0), value);
	}

	inline static int32_t get_offset_of_TurnUrl_1() { return static_cast<int32_t>(offsetof(ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields, ___TurnUrl_1)); }
	inline String_t* get_TurnUrl_1() const { return ___TurnUrl_1; }
	inline String_t** get_address_of_TurnUrl_1() { return &___TurnUrl_1; }
	inline void set_TurnUrl_1(String_t* value)
	{
		___TurnUrl_1 = value;
		Il2CppCodeGenWriteBarrier((&___TurnUrl_1), value);
	}

	inline static int32_t get_offset_of_TurnUser_2() { return static_cast<int32_t>(offsetof(ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields, ___TurnUser_2)); }
	inline String_t* get_TurnUser_2() const { return ___TurnUser_2; }
	inline String_t** get_address_of_TurnUser_2() { return &___TurnUser_2; }
	inline void set_TurnUser_2(String_t* value)
	{
		___TurnUser_2 = value;
		Il2CppCodeGenWriteBarrier((&___TurnUser_2), value);
	}

	inline static int32_t get_offset_of_TurnPass_3() { return static_cast<int32_t>(offsetof(ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields, ___TurnPass_3)); }
	inline String_t* get_TurnPass_3() const { return ___TurnPass_3; }
	inline String_t** get_address_of_TurnPass_3() { return &___TurnPass_3; }
	inline void set_TurnPass_3(String_t* value)
	{
		___TurnPass_3 = value;
		Il2CppCodeGenWriteBarrier((&___TurnPass_3), value);
	}

	inline static int32_t get_offset_of_BackupStunUrl_4() { return static_cast<int32_t>(offsetof(ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields, ___BackupStunUrl_4)); }
	inline String_t* get_BackupStunUrl_4() const { return ___BackupStunUrl_4; }
	inline String_t** get_address_of_BackupStunUrl_4() { return &___BackupStunUrl_4; }
	inline void set_BackupStunUrl_4(String_t* value)
	{
		___BackupStunUrl_4 = value;
		Il2CppCodeGenWriteBarrier((&___BackupStunUrl_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXAMPLEGLOBALS_T56851F8D33D17DD137BD47D6F3F683BE900B236B_H
#ifndef U3CREQUESTAUDIOPERMISSIONU3ED__17_TCBCB2E5936A36A838919E3777D2B4B3FD140600E_H
#define U3CREQUESTAUDIOPERMISSIONU3ED__17_TCBCB2E5936A36A838919E3777D2B4B3FD140600E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.ExampleGlobals_<RequestAudioPermission>d__17
struct  U3CRequestAudioPermissionU3Ed__17_tCBCB2E5936A36A838919E3777D2B4B3FD140600E  : public RuntimeObject
{
public:
	// System.Int32 Byn.Unity.Examples.ExampleGlobals_<RequestAudioPermission>d__17::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Byn.Unity.Examples.ExampleGlobals_<RequestAudioPermission>d__17::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CRequestAudioPermissionU3Ed__17_tCBCB2E5936A36A838919E3777D2B4B3FD140600E, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CRequestAudioPermissionU3Ed__17_tCBCB2E5936A36A838919E3777D2B4B3FD140600E, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CREQUESTAUDIOPERMISSIONU3ED__17_TCBCB2E5936A36A838919E3777D2B4B3FD140600E_H
#ifndef U3CREQUESTPERMISSIONSU3ED__19_T67EA9769316E4B44407430981C52658E479F9856_H
#define U3CREQUESTPERMISSIONSU3ED__19_T67EA9769316E4B44407430981C52658E479F9856_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.ExampleGlobals_<RequestPermissions>d__19
struct  U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856  : public RuntimeObject
{
public:
	// System.Int32 Byn.Unity.Examples.ExampleGlobals_<RequestPermissions>d__19::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Byn.Unity.Examples.ExampleGlobals_<RequestPermissions>d__19::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// System.Boolean Byn.Unity.Examples.ExampleGlobals_<RequestPermissions>d__19::audio
	bool ___audio_2;
	// System.Boolean Byn.Unity.Examples.ExampleGlobals_<RequestPermissions>d__19::video
	bool ___video_3;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}

	inline static int32_t get_offset_of_audio_2() { return static_cast<int32_t>(offsetof(U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856, ___audio_2)); }
	inline bool get_audio_2() const { return ___audio_2; }
	inline bool* get_address_of_audio_2() { return &___audio_2; }
	inline void set_audio_2(bool value)
	{
		___audio_2 = value;
	}

	inline static int32_t get_offset_of_video_3() { return static_cast<int32_t>(offsetof(U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856, ___video_3)); }
	inline bool get_video_3() const { return ___video_3; }
	inline bool* get_address_of_video_3() { return &___video_3; }
	inline void set_video_3(bool value)
	{
		___video_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CREQUESTPERMISSIONSU3ED__19_T67EA9769316E4B44407430981C52658E479F9856_H
#ifndef U3CREQUESTVIDEOPERMISSIONU3ED__18_T284CC5B8067172F41554DA77F7863C49E75F053E_H
#define U3CREQUESTVIDEOPERMISSIONU3ED__18_T284CC5B8067172F41554DA77F7863C49E75F053E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.ExampleGlobals_<RequestVideoPermission>d__18
struct  U3CRequestVideoPermissionU3Ed__18_t284CC5B8067172F41554DA77F7863C49E75F053E  : public RuntimeObject
{
public:
	// System.Int32 Byn.Unity.Examples.ExampleGlobals_<RequestVideoPermission>d__18::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Byn.Unity.Examples.ExampleGlobals_<RequestVideoPermission>d__18::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CRequestVideoPermissionU3Ed__18_t284CC5B8067172F41554DA77F7863C49E75F053E, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CRequestVideoPermissionU3Ed__18_t284CC5B8067172F41554DA77F7863C49E75F053E, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CREQUESTVIDEOPERMISSIONU3ED__18_T284CC5B8067172F41554DA77F7863C49E75F053E_H
#ifndef U3CSTARTU3ED__11_T55FDB25F620252AE5B728D0548DB05649BD4CAC8_H
#define U3CSTARTU3ED__11_T55FDB25F620252AE5B728D0548DB05649BD4CAC8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.OneToMany_<Start>d__11
struct  U3CStartU3Ed__11_t55FDB25F620252AE5B728D0548DB05649BD4CAC8  : public RuntimeObject
{
public:
	// System.Int32 Byn.Unity.Examples.OneToMany_<Start>d__11::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Byn.Unity.Examples.OneToMany_<Start>d__11::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// Byn.Unity.Examples.OneToMany Byn.Unity.Examples.OneToMany_<Start>d__11::<>4__this
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086 * ___U3CU3E4__this_2;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CStartU3Ed__11_t55FDB25F620252AE5B728D0548DB05649BD4CAC8, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CStartU3Ed__11_t55FDB25F620252AE5B728D0548DB05649BD4CAC8, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CStartU3Ed__11_t55FDB25F620252AE5B728D0548DB05649BD4CAC8, ___U3CU3E4__this_2)); }
	inline OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E4__this_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CSTARTU3ED__11_T55FDB25F620252AE5B728D0548DB05649BD4CAC8_H
#ifndef U3CCONFIGUREDELAYEDU3ED__9_T42904B407A0DCE5F3444308EB9C6E569B1031C68_H
#define U3CCONFIGUREDELAYEDU3ED__9_T42904B407A0DCE5F3444308EB9C6E569B1031C68_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.SimpleCall_<ConfigureDelayed>d__9
struct  U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68  : public RuntimeObject
{
public:
	// System.Int32 Byn.Unity.Examples.SimpleCall_<ConfigureDelayed>d__9::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Byn.Unity.Examples.SimpleCall_<ConfigureDelayed>d__9::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// System.Single Byn.Unity.Examples.SimpleCall_<ConfigureDelayed>d__9::startInSec
	float ___startInSec_2;
	// Byn.Unity.Examples.SimpleCall Byn.Unity.Examples.SimpleCall_<ConfigureDelayed>d__9::<>4__this
	SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD * ___U3CU3E4__this_3;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}

	inline static int32_t get_offset_of_startInSec_2() { return static_cast<int32_t>(offsetof(U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68, ___startInSec_2)); }
	inline float get_startInSec_2() const { return ___startInSec_2; }
	inline float* get_address_of_startInSec_2() { return &___startInSec_2; }
	inline void set_startInSec_2(float value)
	{
		___startInSec_2 = value;
	}

	inline static int32_t get_offset_of_U3CU3E4__this_3() { return static_cast<int32_t>(offsetof(U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68, ___U3CU3E4__this_3)); }
	inline SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD * get_U3CU3E4__this_3() const { return ___U3CU3E4__this_3; }
	inline SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD ** get_address_of_U3CU3E4__this_3() { return &___U3CU3E4__this_3; }
	inline void set_U3CU3E4__this_3(SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD * value)
	{
		___U3CU3E4__this_3 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E4__this_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CCONFIGUREDELAYEDU3ED__9_T42904B407A0DCE5F3444308EB9C6E569B1031C68_H
#ifndef U3CCOROUTINEREFRESHLATERU3ED__1_T9AF1BDEE238458547E50F4B52D8F01FDAC02D18E_H
#define U3CCOROUTINEREFRESHLATERU3ED__1_T9AF1BDEE238458547E50F4B52D8F01FDAC02D18E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.VideoInputApp_<CoroutineRefreshLater>d__1
struct  U3CCoroutineRefreshLaterU3Ed__1_t9AF1BDEE238458547E50F4B52D8F01FDAC02D18E  : public RuntimeObject
{
public:
	// System.Int32 Byn.Unity.Examples.VideoInputApp_<CoroutineRefreshLater>d__1::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Byn.Unity.Examples.VideoInputApp_<CoroutineRefreshLater>d__1::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CCoroutineRefreshLaterU3Ed__1_t9AF1BDEE238458547E50F4B52D8F01FDAC02D18E, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CCoroutineRefreshLaterU3Ed__1_t9AF1BDEE238458547E50F4B52D8F01FDAC02D18E, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CCOROUTINEREFRESHLATERU3ED__1_T9AF1BDEE238458547E50F4B52D8F01FDAC02D18E_H
#ifndef U3CCOROUTINEREJOINU3ED__37_TE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2_H
#define U3CCOROUTINEREJOINU3ED__37_TE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// CallApp_<CoroutineRejoin>d__37
struct  U3CCoroutineRejoinU3Ed__37_tE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2  : public RuntimeObject
{
public:
	// System.Int32 CallApp_<CoroutineRejoin>d__37::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object CallApp_<CoroutineRejoin>d__37::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// CallApp CallApp_<CoroutineRejoin>d__37::<>4__this
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43 * ___U3CU3E4__this_2;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CCoroutineRejoinU3Ed__37_tE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CCoroutineRejoinU3Ed__37_tE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CCoroutineRejoinU3Ed__37_tE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2, ___U3CU3E4__this_2)); }
	inline CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E4__this_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CCOROUTINEREJOINU3ED__37_TE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2_H
#ifndef U3CREQUESTAUDIOPERMISSIONSU3ED__22_T9C17C56991F50213F4C48325729588E25B140775_H
#define U3CREQUESTAUDIOPERMISSIONSU3ED__22_T9C17C56991F50213F4C48325729588E25B140775_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// CallAppUi_<RequestAudioPermissions>d__22
struct  U3CRequestAudioPermissionsU3Ed__22_t9C17C56991F50213F4C48325729588E25B140775  : public RuntimeObject
{
public:
	// System.Int32 CallAppUi_<RequestAudioPermissions>d__22::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object CallAppUi_<RequestAudioPermissions>d__22::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// CallAppUi CallAppUi_<RequestAudioPermissions>d__22::<>4__this
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * ___U3CU3E4__this_2;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CRequestAudioPermissionsU3Ed__22_t9C17C56991F50213F4C48325729588E25B140775, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CRequestAudioPermissionsU3Ed__22_t9C17C56991F50213F4C48325729588E25B140775, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CRequestAudioPermissionsU3Ed__22_t9C17C56991F50213F4C48325729588E25B140775, ___U3CU3E4__this_2)); }
	inline CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E4__this_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CREQUESTAUDIOPERMISSIONSU3ED__22_T9C17C56991F50213F4C48325729588E25B140775_H
#ifndef U3CSTARTBUTTONU3ED__20_TD7D0D415BC8F3F262D7F0FDE55D2527DE96E078A_H
#define U3CSTARTBUTTONU3ED__20_TD7D0D415BC8F3F262D7F0FDE55D2527DE96E078A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// CallAppUi_<startbutton>d__20
struct  U3CstartbuttonU3Ed__20_tD7D0D415BC8F3F262D7F0FDE55D2527DE96E078A  : public RuntimeObject
{
public:
	// System.Int32 CallAppUi_<startbutton>d__20::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object CallAppUi_<startbutton>d__20::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// CallAppUi CallAppUi_<startbutton>d__20::<>4__this
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * ___U3CU3E4__this_2;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CstartbuttonU3Ed__20_tD7D0D415BC8F3F262D7F0FDE55D2527DE96E078A, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CstartbuttonU3Ed__20_tD7D0D415BC8F3F262D7F0FDE55D2527DE96E078A, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CstartbuttonU3Ed__20_tD7D0D415BC8F3F262D7F0FDE55D2527DE96E078A, ___U3CU3E4__this_2)); }
	inline CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E4__this_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CSTARTBUTTONU3ED__20_TD7D0D415BC8F3F262D7F0FDE55D2527DE96E078A_H
#ifndef U3CDOEVALUATEMESSAGESU3ED__24_TE689A15D2581E01CA8288FFF481A2A22E3869E23_H
#define U3CDOEVALUATEMESSAGESU3ED__24_TE689A15D2581E01CA8288FFF481A2A22E3869E23_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// InterProcessCommunicator_<DoEvaluateMessages>d__24
struct  U3CDoEvaluateMessagesU3Ed__24_tE689A15D2581E01CA8288FFF481A2A22E3869E23  : public RuntimeObject
{
public:
	// System.Int32 InterProcessCommunicator_<DoEvaluateMessages>d__24::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object InterProcessCommunicator_<DoEvaluateMessages>d__24::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// InterProcessCommunicator InterProcessCommunicator_<DoEvaluateMessages>d__24::<>4__this
	InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019 * ___U3CU3E4__this_2;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CDoEvaluateMessagesU3Ed__24_tE689A15D2581E01CA8288FFF481A2A22E3869E23, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CDoEvaluateMessagesU3Ed__24_tE689A15D2581E01CA8288FFF481A2A22E3869E23, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E2__current_1), value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CDoEvaluateMessagesU3Ed__24_tE689A15D2581E01CA8288FFF481A2A22E3869E23, ___U3CU3E4__this_2)); }
	inline InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E4__this_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CDOEVALUATEMESSAGESU3ED__24_TE689A15D2581E01CA8288FFF481A2A22E3869E23_H
#ifndef U3CU3EC_TE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE_H
#define U3CU3EC_TE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.ButtonManager_<>c
struct  U3CU3Ec_tE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_tE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE_StaticFields
{
public:
	// LookingGlass.ButtonManager_<>c LookingGlass.ButtonManager_<>c::<>9
	U3CU3Ec_tE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE * ___U3CU3E9_0;
	// System.Func`2<UnityEngine.KeyCode,System.Boolean> LookingGlass.ButtonManager_<>c::<>9__10_0
	Func_2_t53B81A840243D682C934213ABEBCB0638922A18F * ___U3CU3E9__10_0_1;
	// System.Func`2<UnityEngine.KeyCode,System.Boolean> LookingGlass.ButtonManager_<>c::<>9__11_0
	Func_2_t53B81A840243D682C934213ABEBCB0638922A18F * ___U3CU3E9__11_0_2;
	// System.Func`2<UnityEngine.KeyCode,System.Boolean> LookingGlass.ButtonManager_<>c::<>9__12_0
	Func_2_t53B81A840243D682C934213ABEBCB0638922A18F * ___U3CU3E9__12_0_3;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_tE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_tE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_tE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_tE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9_0), value);
	}

	inline static int32_t get_offset_of_U3CU3E9__10_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_tE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE_StaticFields, ___U3CU3E9__10_0_1)); }
	inline Func_2_t53B81A840243D682C934213ABEBCB0638922A18F * get_U3CU3E9__10_0_1() const { return ___U3CU3E9__10_0_1; }
	inline Func_2_t53B81A840243D682C934213ABEBCB0638922A18F ** get_address_of_U3CU3E9__10_0_1() { return &___U3CU3E9__10_0_1; }
	inline void set_U3CU3E9__10_0_1(Func_2_t53B81A840243D682C934213ABEBCB0638922A18F * value)
	{
		___U3CU3E9__10_0_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9__10_0_1), value);
	}

	inline static int32_t get_offset_of_U3CU3E9__11_0_2() { return static_cast<int32_t>(offsetof(U3CU3Ec_tE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE_StaticFields, ___U3CU3E9__11_0_2)); }
	inline Func_2_t53B81A840243D682C934213ABEBCB0638922A18F * get_U3CU3E9__11_0_2() const { return ___U3CU3E9__11_0_2; }
	inline Func_2_t53B81A840243D682C934213ABEBCB0638922A18F ** get_address_of_U3CU3E9__11_0_2() { return &___U3CU3E9__11_0_2; }
	inline void set_U3CU3E9__11_0_2(Func_2_t53B81A840243D682C934213ABEBCB0638922A18F * value)
	{
		___U3CU3E9__11_0_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9__11_0_2), value);
	}

	inline static int32_t get_offset_of_U3CU3E9__12_0_3() { return static_cast<int32_t>(offsetof(U3CU3Ec_tE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE_StaticFields, ___U3CU3E9__12_0_3)); }
	inline Func_2_t53B81A840243D682C934213ABEBCB0638922A18F * get_U3CU3E9__12_0_3() const { return ___U3CU3E9__12_0_3; }
	inline Func_2_t53B81A840243D682C934213ABEBCB0638922A18F ** get_address_of_U3CU3E9__12_0_3() { return &___U3CU3E9__12_0_3; }
	inline void set_U3CU3E9__12_0_3(Func_2_t53B81A840243D682C934213ABEBCB0638922A18F * value)
	{
		___U3CU3E9__12_0_3 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9__12_0_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC_TE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE_H
#ifndef CALIBRATIONMANAGER_T69C929BA4E560058B15736462A6C613CDD0A580A_H
#define CALIBRATIONMANAGER_T69C929BA4E560058B15736462A6C613CDD0A580A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.CalibrationManager
struct  CalibrationManager_t69C929BA4E560058B15736462A6C613CDD0A580A  : public RuntimeObject
{
public:

public:
};

struct CalibrationManager_t69C929BA4E560058B15736462A6C613CDD0A580A_StaticFields
{
public:
	// System.Boolean LookingGlass.CalibrationManager::isInit
	bool ___isInit_0;
	// LookingGlass.Calibration[] LookingGlass.CalibrationManager::calibrations
	CalibrationU5BU5D_tC92D5273B1332F23D1A9C48B726AE22F60E7B292* ___calibrations_1;

public:
	inline static int32_t get_offset_of_isInit_0() { return static_cast<int32_t>(offsetof(CalibrationManager_t69C929BA4E560058B15736462A6C613CDD0A580A_StaticFields, ___isInit_0)); }
	inline bool get_isInit_0() const { return ___isInit_0; }
	inline bool* get_address_of_isInit_0() { return &___isInit_0; }
	inline void set_isInit_0(bool value)
	{
		___isInit_0 = value;
	}

	inline static int32_t get_offset_of_calibrations_1() { return static_cast<int32_t>(offsetof(CalibrationManager_t69C929BA4E560058B15736462A6C613CDD0A580A_StaticFields, ___calibrations_1)); }
	inline CalibrationU5BU5D_tC92D5273B1332F23D1A9C48B726AE22F60E7B292* get_calibrations_1() const { return ___calibrations_1; }
	inline CalibrationU5BU5D_tC92D5273B1332F23D1A9C48B726AE22F60E7B292** get_address_of_calibrations_1() { return &___calibrations_1; }
	inline void set_calibrations_1(CalibrationU5BU5D_tC92D5273B1332F23D1A9C48B726AE22F60E7B292* value)
	{
		___calibrations_1 = value;
		Il2CppCodeGenWriteBarrier((&___calibrations_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALIBRATIONMANAGER_T69C929BA4E560058B15736462A6C613CDD0A580A_H
#ifndef PLUGINCORE_T155DE0EF086674BD0D934961B21B44479B5F0C10_H
#define PLUGINCORE_T155DE0EF086674BD0D934961B21B44479B5F0C10_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.PluginCore
struct  PluginCore_t155DE0EF086674BD0D934961B21B44479B5F0C10  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PLUGINCORE_T155DE0EF086674BD0D934961B21B44479B5F0C10_H
#ifndef QUILT_TB58F63BCC9DFCA96CA7EDF608AED3E9EC0440957_H
#define QUILT_TB58F63BCC9DFCA96CA7EDF608AED3E9EC0440957_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Quilt
struct  Quilt_tB58F63BCC9DFCA96CA7EDF608AED3E9EC0440957  : public RuntimeObject
{
public:

public:
};

struct Quilt_tB58F63BCC9DFCA96CA7EDF608AED3E9EC0440957_StaticFields
{
public:
	// LookingGlass.Quilt_Settings[] LookingGlass.Quilt::presets
	SettingsU5BU5D_t91DD8F7D5BBA1B7170CB6F4ED752A213DCB2E5A3* ___presets_0;

public:
	inline static int32_t get_offset_of_presets_0() { return static_cast<int32_t>(offsetof(Quilt_tB58F63BCC9DFCA96CA7EDF608AED3E9EC0440957_StaticFields, ___presets_0)); }
	inline SettingsU5BU5D_t91DD8F7D5BBA1B7170CB6F4ED752A213DCB2E5A3* get_presets_0() const { return ___presets_0; }
	inline SettingsU5BU5D_t91DD8F7D5BBA1B7170CB6F4ED752A213DCB2E5A3** get_address_of_presets_0() { return &___presets_0; }
	inline void set_presets_0(SettingsU5BU5D_t91DD8F7D5BBA1B7170CB6F4ED752A213DCB2E5A3* value)
	{
		___presets_0 = value;
		Il2CppCodeGenWriteBarrier((&___presets_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // QUILT_TB58F63BCC9DFCA96CA7EDF608AED3E9EC0440957_H
#ifndef VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#define VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_com
{
};
#endif // VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#ifndef UNITYEVENTBASE_T6E0F7823762EE94BB8489B5AE41C7802A266D3D5_H
#define UNITYEVENTBASE_T6E0F7823762EE94BB8489B5AE41C7802A266D3D5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Events.UnityEventBase
struct  UnityEventBase_t6E0F7823762EE94BB8489B5AE41C7802A266D3D5  : public RuntimeObject
{
public:
	// UnityEngine.Events.InvokableCallList UnityEngine.Events.UnityEventBase::m_Calls
	InvokableCallList_t18AA4F473C7B295216B7D4B9723B4F3DFCCC9A3F * ___m_Calls_0;
	// UnityEngine.Events.PersistentCallGroup UnityEngine.Events.UnityEventBase::m_PersistentCalls
	PersistentCallGroup_t6E5DF2EBDA42794B5FE0C6DAA97DF65F0BFF571F * ___m_PersistentCalls_1;
	// System.Boolean UnityEngine.Events.UnityEventBase::m_CallsDirty
	bool ___m_CallsDirty_2;

public:
	inline static int32_t get_offset_of_m_Calls_0() { return static_cast<int32_t>(offsetof(UnityEventBase_t6E0F7823762EE94BB8489B5AE41C7802A266D3D5, ___m_Calls_0)); }
	inline InvokableCallList_t18AA4F473C7B295216B7D4B9723B4F3DFCCC9A3F * get_m_Calls_0() const { return ___m_Calls_0; }
	inline InvokableCallList_t18AA4F473C7B295216B7D4B9723B4F3DFCCC9A3F ** get_address_of_m_Calls_0() { return &___m_Calls_0; }
	inline void set_m_Calls_0(InvokableCallList_t18AA4F473C7B295216B7D4B9723B4F3DFCCC9A3F * value)
	{
		___m_Calls_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_Calls_0), value);
	}

	inline static int32_t get_offset_of_m_PersistentCalls_1() { return static_cast<int32_t>(offsetof(UnityEventBase_t6E0F7823762EE94BB8489B5AE41C7802A266D3D5, ___m_PersistentCalls_1)); }
	inline PersistentCallGroup_t6E5DF2EBDA42794B5FE0C6DAA97DF65F0BFF571F * get_m_PersistentCalls_1() const { return ___m_PersistentCalls_1; }
	inline PersistentCallGroup_t6E5DF2EBDA42794B5FE0C6DAA97DF65F0BFF571F ** get_address_of_m_PersistentCalls_1() { return &___m_PersistentCalls_1; }
	inline void set_m_PersistentCalls_1(PersistentCallGroup_t6E5DF2EBDA42794B5FE0C6DAA97DF65F0BFF571F * value)
	{
		___m_PersistentCalls_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_PersistentCalls_1), value);
	}

	inline static int32_t get_offset_of_m_CallsDirty_2() { return static_cast<int32_t>(offsetof(UnityEventBase_t6E0F7823762EE94BB8489B5AE41C7802A266D3D5, ___m_CallsDirty_2)); }
	inline bool get_m_CallsDirty_2() const { return ___m_CallsDirty_2; }
	inline bool* get_address_of_m_CallsDirty_2() { return &___m_CallsDirty_2; }
	inline void set_m_CallsDirty_2(bool value)
	{
		___m_CallsDirty_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNITYEVENTBASE_T6E0F7823762EE94BB8489B5AE41C7802A266D3D5_H
#ifndef VERTEXHELPEREXTENSION_T593AF80A941B7208D2CC88AE671873CE6E2AA8E3_H
#define VERTEXHELPEREXTENSION_T593AF80A941B7208D2CC88AE671873CE6E2AA8E3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Experimental.UI.VertexHelperExtension
struct  VertexHelperExtension_t593AF80A941B7208D2CC88AE671873CE6E2AA8E3  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VERTEXHELPEREXTENSION_T593AF80A941B7208D2CC88AE671873CE6E2AA8E3_H
#ifndef BASEVERTEXEFFECT_T1EF95AB1FC33A027710E7DC86D19F700156C4F6A_H
#define BASEVERTEXEFFECT_T1EF95AB1FC33A027710E7DC86D19F700156C4F6A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.BaseVertexEffect
struct  BaseVertexEffect_t1EF95AB1FC33A027710E7DC86D19F700156C4F6A  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BASEVERTEXEFFECT_T1EF95AB1FC33A027710E7DC86D19F700156C4F6A_H
#ifndef U3CDELAYEDSETDIRTYU3EC__ITERATOR0_TB8BB61C2C033D95240B4E2704971663E4DC08073_H
#define U3CDELAYEDSETDIRTYU3EC__ITERATOR0_TB8BB61C2C033D95240B4E2704971663E4DC08073_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.LayoutGroup_<DelayedSetDirty>c__Iterator0
struct  U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073  : public RuntimeObject
{
public:
	// UnityEngine.RectTransform UnityEngine.UI.LayoutGroup_<DelayedSetDirty>c__Iterator0::rectTransform
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___rectTransform_0;
	// System.Object UnityEngine.UI.LayoutGroup_<DelayedSetDirty>c__Iterator0::U24current
	RuntimeObject * ___U24current_1;
	// System.Boolean UnityEngine.UI.LayoutGroup_<DelayedSetDirty>c__Iterator0::U24disposing
	bool ___U24disposing_2;
	// System.Int32 UnityEngine.UI.LayoutGroup_<DelayedSetDirty>c__Iterator0::U24PC
	int32_t ___U24PC_3;

public:
	inline static int32_t get_offset_of_rectTransform_0() { return static_cast<int32_t>(offsetof(U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073, ___rectTransform_0)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_rectTransform_0() const { return ___rectTransform_0; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_rectTransform_0() { return &___rectTransform_0; }
	inline void set_rectTransform_0(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___rectTransform_0 = value;
		Il2CppCodeGenWriteBarrier((&___rectTransform_0), value);
	}

	inline static int32_t get_offset_of_U24current_1() { return static_cast<int32_t>(offsetof(U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073, ___U24current_1)); }
	inline RuntimeObject * get_U24current_1() const { return ___U24current_1; }
	inline RuntimeObject ** get_address_of_U24current_1() { return &___U24current_1; }
	inline void set_U24current_1(RuntimeObject * value)
	{
		___U24current_1 = value;
		Il2CppCodeGenWriteBarrier((&___U24current_1), value);
	}

	inline static int32_t get_offset_of_U24disposing_2() { return static_cast<int32_t>(offsetof(U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073, ___U24disposing_2)); }
	inline bool get_U24disposing_2() const { return ___U24disposing_2; }
	inline bool* get_address_of_U24disposing_2() { return &___U24disposing_2; }
	inline void set_U24disposing_2(bool value)
	{
		___U24disposing_2 = value;
	}

	inline static int32_t get_offset_of_U24PC_3() { return static_cast<int32_t>(offsetof(U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073, ___U24PC_3)); }
	inline int32_t get_U24PC_3() const { return ___U24PC_3; }
	inline int32_t* get_address_of_U24PC_3() { return &___U24PC_3; }
	inline void set_U24PC_3(int32_t value)
	{
		___U24PC_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CDELAYEDSETDIRTYU3EC__ITERATOR0_TB8BB61C2C033D95240B4E2704971663E4DC08073_H
#ifndef LAYOUTREBUILDER_T8D3501B43B1DE666140E2931FFA732B5B09EA5BD_H
#define LAYOUTREBUILDER_T8D3501B43B1DE666140E2931FFA732B5B09EA5BD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.LayoutRebuilder
struct  LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD  : public RuntimeObject
{
public:
	// UnityEngine.RectTransform UnityEngine.UI.LayoutRebuilder::m_ToRebuild
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___m_ToRebuild_0;
	// System.Int32 UnityEngine.UI.LayoutRebuilder::m_CachedHashFromTransform
	int32_t ___m_CachedHashFromTransform_1;

public:
	inline static int32_t get_offset_of_m_ToRebuild_0() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD, ___m_ToRebuild_0)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_m_ToRebuild_0() const { return ___m_ToRebuild_0; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_m_ToRebuild_0() { return &___m_ToRebuild_0; }
	inline void set_m_ToRebuild_0(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___m_ToRebuild_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_ToRebuild_0), value);
	}

	inline static int32_t get_offset_of_m_CachedHashFromTransform_1() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD, ___m_CachedHashFromTransform_1)); }
	inline int32_t get_m_CachedHashFromTransform_1() const { return ___m_CachedHashFromTransform_1; }
	inline int32_t* get_address_of_m_CachedHashFromTransform_1() { return &___m_CachedHashFromTransform_1; }
	inline void set_m_CachedHashFromTransform_1(int32_t value)
	{
		___m_CachedHashFromTransform_1 = value;
	}
};

struct LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields
{
public:
	// UnityEngine.UI.ObjectPool`1<UnityEngine.UI.LayoutRebuilder> UnityEngine.UI.LayoutRebuilder::s_Rebuilders
	ObjectPool_1_tFA4F33849836CDB27432AE22249BB79D68619541 * ___s_Rebuilders_2;
	// UnityEngine.RectTransform_ReapplyDrivenProperties UnityEngine.UI.LayoutRebuilder::<>f__mgU24cache0
	ReapplyDrivenProperties_t431F4FBD9C59AE097FE33C4354CC6251B01B527D * ___U3CU3Ef__mgU24cache0_3;
	// System.Predicate`1<UnityEngine.Component> UnityEngine.UI.LayoutRebuilder::<>f__amU24cache0
	Predicate_1_t1A9CE8ADB6E9328794CC409FD5BEAACA86D7D769 * ___U3CU3Ef__amU24cache0_4;
	// UnityEngine.Events.UnityAction`1<UnityEngine.Component> UnityEngine.UI.LayoutRebuilder::<>f__amU24cache1
	UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * ___U3CU3Ef__amU24cache1_5;
	// UnityEngine.Events.UnityAction`1<UnityEngine.Component> UnityEngine.UI.LayoutRebuilder::<>f__amU24cache2
	UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * ___U3CU3Ef__amU24cache2_6;
	// UnityEngine.Events.UnityAction`1<UnityEngine.Component> UnityEngine.UI.LayoutRebuilder::<>f__amU24cache3
	UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * ___U3CU3Ef__amU24cache3_7;
	// UnityEngine.Events.UnityAction`1<UnityEngine.Component> UnityEngine.UI.LayoutRebuilder::<>f__amU24cache4
	UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * ___U3CU3Ef__amU24cache4_8;

public:
	inline static int32_t get_offset_of_s_Rebuilders_2() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields, ___s_Rebuilders_2)); }
	inline ObjectPool_1_tFA4F33849836CDB27432AE22249BB79D68619541 * get_s_Rebuilders_2() const { return ___s_Rebuilders_2; }
	inline ObjectPool_1_tFA4F33849836CDB27432AE22249BB79D68619541 ** get_address_of_s_Rebuilders_2() { return &___s_Rebuilders_2; }
	inline void set_s_Rebuilders_2(ObjectPool_1_tFA4F33849836CDB27432AE22249BB79D68619541 * value)
	{
		___s_Rebuilders_2 = value;
		Il2CppCodeGenWriteBarrier((&___s_Rebuilders_2), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__mgU24cache0_3() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields, ___U3CU3Ef__mgU24cache0_3)); }
	inline ReapplyDrivenProperties_t431F4FBD9C59AE097FE33C4354CC6251B01B527D * get_U3CU3Ef__mgU24cache0_3() const { return ___U3CU3Ef__mgU24cache0_3; }
	inline ReapplyDrivenProperties_t431F4FBD9C59AE097FE33C4354CC6251B01B527D ** get_address_of_U3CU3Ef__mgU24cache0_3() { return &___U3CU3Ef__mgU24cache0_3; }
	inline void set_U3CU3Ef__mgU24cache0_3(ReapplyDrivenProperties_t431F4FBD9C59AE097FE33C4354CC6251B01B527D * value)
	{
		___U3CU3Ef__mgU24cache0_3 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__mgU24cache0_3), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache0_4() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields, ___U3CU3Ef__amU24cache0_4)); }
	inline Predicate_1_t1A9CE8ADB6E9328794CC409FD5BEAACA86D7D769 * get_U3CU3Ef__amU24cache0_4() const { return ___U3CU3Ef__amU24cache0_4; }
	inline Predicate_1_t1A9CE8ADB6E9328794CC409FD5BEAACA86D7D769 ** get_address_of_U3CU3Ef__amU24cache0_4() { return &___U3CU3Ef__amU24cache0_4; }
	inline void set_U3CU3Ef__amU24cache0_4(Predicate_1_t1A9CE8ADB6E9328794CC409FD5BEAACA86D7D769 * value)
	{
		___U3CU3Ef__amU24cache0_4 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache0_4), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache1_5() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields, ___U3CU3Ef__amU24cache1_5)); }
	inline UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * get_U3CU3Ef__amU24cache1_5() const { return ___U3CU3Ef__amU24cache1_5; }
	inline UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 ** get_address_of_U3CU3Ef__amU24cache1_5() { return &___U3CU3Ef__amU24cache1_5; }
	inline void set_U3CU3Ef__amU24cache1_5(UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * value)
	{
		___U3CU3Ef__amU24cache1_5 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache1_5), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache2_6() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields, ___U3CU3Ef__amU24cache2_6)); }
	inline UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * get_U3CU3Ef__amU24cache2_6() const { return ___U3CU3Ef__amU24cache2_6; }
	inline UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 ** get_address_of_U3CU3Ef__amU24cache2_6() { return &___U3CU3Ef__amU24cache2_6; }
	inline void set_U3CU3Ef__amU24cache2_6(UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * value)
	{
		___U3CU3Ef__amU24cache2_6 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache2_6), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache3_7() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields, ___U3CU3Ef__amU24cache3_7)); }
	inline UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * get_U3CU3Ef__amU24cache3_7() const { return ___U3CU3Ef__amU24cache3_7; }
	inline UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 ** get_address_of_U3CU3Ef__amU24cache3_7() { return &___U3CU3Ef__amU24cache3_7; }
	inline void set_U3CU3Ef__amU24cache3_7(UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * value)
	{
		___U3CU3Ef__amU24cache3_7 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache3_7), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache4_8() { return static_cast<int32_t>(offsetof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields, ___U3CU3Ef__amU24cache4_8)); }
	inline UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * get_U3CU3Ef__amU24cache4_8() const { return ___U3CU3Ef__amU24cache4_8; }
	inline UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 ** get_address_of_U3CU3Ef__amU24cache4_8() { return &___U3CU3Ef__amU24cache4_8; }
	inline void set_U3CU3Ef__amU24cache4_8(UnityAction_1_tD07424D822F8527D240A320A1866C70C835C7C99 * value)
	{
		___U3CU3Ef__amU24cache4_8 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache4_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LAYOUTREBUILDER_T8D3501B43B1DE666140E2931FFA732B5B09EA5BD_H
#ifndef LAYOUTUTILITY_T3B5074E34900DA384884FC50809EA395CB69E7D5_H
#define LAYOUTUTILITY_T3B5074E34900DA384884FC50809EA395CB69E7D5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.LayoutUtility
struct  LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5  : public RuntimeObject
{
public:

public:
};

struct LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields
{
public:
	// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single> UnityEngine.UI.LayoutUtility::<>f__amU24cache0
	Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * ___U3CU3Ef__amU24cache0_0;
	// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single> UnityEngine.UI.LayoutUtility::<>f__amU24cache1
	Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * ___U3CU3Ef__amU24cache1_1;
	// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single> UnityEngine.UI.LayoutUtility::<>f__amU24cache2
	Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * ___U3CU3Ef__amU24cache2_2;
	// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single> UnityEngine.UI.LayoutUtility::<>f__amU24cache3
	Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * ___U3CU3Ef__amU24cache3_3;
	// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single> UnityEngine.UI.LayoutUtility::<>f__amU24cache4
	Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * ___U3CU3Ef__amU24cache4_4;
	// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single> UnityEngine.UI.LayoutUtility::<>f__amU24cache5
	Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * ___U3CU3Ef__amU24cache5_5;
	// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single> UnityEngine.UI.LayoutUtility::<>f__amU24cache6
	Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * ___U3CU3Ef__amU24cache6_6;
	// System.Func`2<UnityEngine.UI.ILayoutElement,System.Single> UnityEngine.UI.LayoutUtility::<>f__amU24cache7
	Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * ___U3CU3Ef__amU24cache7_7;

public:
	inline static int32_t get_offset_of_U3CU3Ef__amU24cache0_0() { return static_cast<int32_t>(offsetof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields, ___U3CU3Ef__amU24cache0_0)); }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * get_U3CU3Ef__amU24cache0_0() const { return ___U3CU3Ef__amU24cache0_0; }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 ** get_address_of_U3CU3Ef__amU24cache0_0() { return &___U3CU3Ef__amU24cache0_0; }
	inline void set_U3CU3Ef__amU24cache0_0(Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * value)
	{
		___U3CU3Ef__amU24cache0_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache0_0), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache1_1() { return static_cast<int32_t>(offsetof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields, ___U3CU3Ef__amU24cache1_1)); }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * get_U3CU3Ef__amU24cache1_1() const { return ___U3CU3Ef__amU24cache1_1; }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 ** get_address_of_U3CU3Ef__amU24cache1_1() { return &___U3CU3Ef__amU24cache1_1; }
	inline void set_U3CU3Ef__amU24cache1_1(Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * value)
	{
		___U3CU3Ef__amU24cache1_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache1_1), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache2_2() { return static_cast<int32_t>(offsetof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields, ___U3CU3Ef__amU24cache2_2)); }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * get_U3CU3Ef__amU24cache2_2() const { return ___U3CU3Ef__amU24cache2_2; }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 ** get_address_of_U3CU3Ef__amU24cache2_2() { return &___U3CU3Ef__amU24cache2_2; }
	inline void set_U3CU3Ef__amU24cache2_2(Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * value)
	{
		___U3CU3Ef__amU24cache2_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache2_2), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache3_3() { return static_cast<int32_t>(offsetof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields, ___U3CU3Ef__amU24cache3_3)); }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * get_U3CU3Ef__amU24cache3_3() const { return ___U3CU3Ef__amU24cache3_3; }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 ** get_address_of_U3CU3Ef__amU24cache3_3() { return &___U3CU3Ef__amU24cache3_3; }
	inline void set_U3CU3Ef__amU24cache3_3(Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * value)
	{
		___U3CU3Ef__amU24cache3_3 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache3_3), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache4_4() { return static_cast<int32_t>(offsetof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields, ___U3CU3Ef__amU24cache4_4)); }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * get_U3CU3Ef__amU24cache4_4() const { return ___U3CU3Ef__amU24cache4_4; }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 ** get_address_of_U3CU3Ef__amU24cache4_4() { return &___U3CU3Ef__amU24cache4_4; }
	inline void set_U3CU3Ef__amU24cache4_4(Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * value)
	{
		___U3CU3Ef__amU24cache4_4 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache4_4), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache5_5() { return static_cast<int32_t>(offsetof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields, ___U3CU3Ef__amU24cache5_5)); }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * get_U3CU3Ef__amU24cache5_5() const { return ___U3CU3Ef__amU24cache5_5; }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 ** get_address_of_U3CU3Ef__amU24cache5_5() { return &___U3CU3Ef__amU24cache5_5; }
	inline void set_U3CU3Ef__amU24cache5_5(Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * value)
	{
		___U3CU3Ef__amU24cache5_5 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache5_5), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache6_6() { return static_cast<int32_t>(offsetof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields, ___U3CU3Ef__amU24cache6_6)); }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * get_U3CU3Ef__amU24cache6_6() const { return ___U3CU3Ef__amU24cache6_6; }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 ** get_address_of_U3CU3Ef__amU24cache6_6() { return &___U3CU3Ef__amU24cache6_6; }
	inline void set_U3CU3Ef__amU24cache6_6(Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * value)
	{
		___U3CU3Ef__amU24cache6_6 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache6_6), value);
	}

	inline static int32_t get_offset_of_U3CU3Ef__amU24cache7_7() { return static_cast<int32_t>(offsetof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields, ___U3CU3Ef__amU24cache7_7)); }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * get_U3CU3Ef__amU24cache7_7() const { return ___U3CU3Ef__amU24cache7_7; }
	inline Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 ** get_address_of_U3CU3Ef__amU24cache7_7() { return &___U3CU3Ef__amU24cache7_7; }
	inline void set_U3CU3Ef__amU24cache7_7(Func_2_tCC31999C8C9743F42A2D59A3570B71FFA3DB09B3 * value)
	{
		___U3CU3Ef__amU24cache7_7 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3Ef__amU24cache7_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LAYOUTUTILITY_T3B5074E34900DA384884FC50809EA395CB69E7D5_H
#ifndef REFLECTIONMETHODSCACHE_TBDADDC80D50C5F10BD00965217980B9A8D24BE8A_H
#define REFLECTIONMETHODSCACHE_TBDADDC80D50C5F10BD00965217980B9A8D24BE8A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.ReflectionMethodsCache
struct  ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A  : public RuntimeObject
{
public:
	// UnityEngine.UI.ReflectionMethodsCache_Raycast3DCallback UnityEngine.UI.ReflectionMethodsCache::raycast3D
	Raycast3DCallback_t83483916473C9710AEDB316A65CBE62C58935C5F * ___raycast3D_0;
	// UnityEngine.UI.ReflectionMethodsCache_RaycastAllCallback UnityEngine.UI.ReflectionMethodsCache::raycast3DAll
	RaycastAllCallback_t751407A44270E02FAA43D0846A58EE6A8C4AE1CE * ___raycast3DAll_1;
	// UnityEngine.UI.ReflectionMethodsCache_Raycast2DCallback UnityEngine.UI.ReflectionMethodsCache::raycast2D
	Raycast2DCallback_tE99ABF9ABC3A380677949E8C05A3E477889B82BE * ___raycast2D_2;
	// UnityEngine.UI.ReflectionMethodsCache_GetRayIntersectionAllCallback UnityEngine.UI.ReflectionMethodsCache::getRayIntersectionAll
	GetRayIntersectionAllCallback_t68C2581CCF05E868297EBD3F3361274954845095 * ___getRayIntersectionAll_3;
	// UnityEngine.UI.ReflectionMethodsCache_GetRayIntersectionAllNonAllocCallback UnityEngine.UI.ReflectionMethodsCache::getRayIntersectionAllNonAlloc
	GetRayIntersectionAllNonAllocCallback_tAD7508D45DB6679B6394983579AD18D967CC2AD4 * ___getRayIntersectionAllNonAlloc_4;
	// UnityEngine.UI.ReflectionMethodsCache_GetRaycastNonAllocCallback UnityEngine.UI.ReflectionMethodsCache::getRaycastNonAlloc
	GetRaycastNonAllocCallback_tC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D * ___getRaycastNonAlloc_5;

public:
	inline static int32_t get_offset_of_raycast3D_0() { return static_cast<int32_t>(offsetof(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A, ___raycast3D_0)); }
	inline Raycast3DCallback_t83483916473C9710AEDB316A65CBE62C58935C5F * get_raycast3D_0() const { return ___raycast3D_0; }
	inline Raycast3DCallback_t83483916473C9710AEDB316A65CBE62C58935C5F ** get_address_of_raycast3D_0() { return &___raycast3D_0; }
	inline void set_raycast3D_0(Raycast3DCallback_t83483916473C9710AEDB316A65CBE62C58935C5F * value)
	{
		___raycast3D_0 = value;
		Il2CppCodeGenWriteBarrier((&___raycast3D_0), value);
	}

	inline static int32_t get_offset_of_raycast3DAll_1() { return static_cast<int32_t>(offsetof(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A, ___raycast3DAll_1)); }
	inline RaycastAllCallback_t751407A44270E02FAA43D0846A58EE6A8C4AE1CE * get_raycast3DAll_1() const { return ___raycast3DAll_1; }
	inline RaycastAllCallback_t751407A44270E02FAA43D0846A58EE6A8C4AE1CE ** get_address_of_raycast3DAll_1() { return &___raycast3DAll_1; }
	inline void set_raycast3DAll_1(RaycastAllCallback_t751407A44270E02FAA43D0846A58EE6A8C4AE1CE * value)
	{
		___raycast3DAll_1 = value;
		Il2CppCodeGenWriteBarrier((&___raycast3DAll_1), value);
	}

	inline static int32_t get_offset_of_raycast2D_2() { return static_cast<int32_t>(offsetof(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A, ___raycast2D_2)); }
	inline Raycast2DCallback_tE99ABF9ABC3A380677949E8C05A3E477889B82BE * get_raycast2D_2() const { return ___raycast2D_2; }
	inline Raycast2DCallback_tE99ABF9ABC3A380677949E8C05A3E477889B82BE ** get_address_of_raycast2D_2() { return &___raycast2D_2; }
	inline void set_raycast2D_2(Raycast2DCallback_tE99ABF9ABC3A380677949E8C05A3E477889B82BE * value)
	{
		___raycast2D_2 = value;
		Il2CppCodeGenWriteBarrier((&___raycast2D_2), value);
	}

	inline static int32_t get_offset_of_getRayIntersectionAll_3() { return static_cast<int32_t>(offsetof(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A, ___getRayIntersectionAll_3)); }
	inline GetRayIntersectionAllCallback_t68C2581CCF05E868297EBD3F3361274954845095 * get_getRayIntersectionAll_3() const { return ___getRayIntersectionAll_3; }
	inline GetRayIntersectionAllCallback_t68C2581CCF05E868297EBD3F3361274954845095 ** get_address_of_getRayIntersectionAll_3() { return &___getRayIntersectionAll_3; }
	inline void set_getRayIntersectionAll_3(GetRayIntersectionAllCallback_t68C2581CCF05E868297EBD3F3361274954845095 * value)
	{
		___getRayIntersectionAll_3 = value;
		Il2CppCodeGenWriteBarrier((&___getRayIntersectionAll_3), value);
	}

	inline static int32_t get_offset_of_getRayIntersectionAllNonAlloc_4() { return static_cast<int32_t>(offsetof(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A, ___getRayIntersectionAllNonAlloc_4)); }
	inline GetRayIntersectionAllNonAllocCallback_tAD7508D45DB6679B6394983579AD18D967CC2AD4 * get_getRayIntersectionAllNonAlloc_4() const { return ___getRayIntersectionAllNonAlloc_4; }
	inline GetRayIntersectionAllNonAllocCallback_tAD7508D45DB6679B6394983579AD18D967CC2AD4 ** get_address_of_getRayIntersectionAllNonAlloc_4() { return &___getRayIntersectionAllNonAlloc_4; }
	inline void set_getRayIntersectionAllNonAlloc_4(GetRayIntersectionAllNonAllocCallback_tAD7508D45DB6679B6394983579AD18D967CC2AD4 * value)
	{
		___getRayIntersectionAllNonAlloc_4 = value;
		Il2CppCodeGenWriteBarrier((&___getRayIntersectionAllNonAlloc_4), value);
	}

	inline static int32_t get_offset_of_getRaycastNonAlloc_5() { return static_cast<int32_t>(offsetof(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A, ___getRaycastNonAlloc_5)); }
	inline GetRaycastNonAllocCallback_tC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D * get_getRaycastNonAlloc_5() const { return ___getRaycastNonAlloc_5; }
	inline GetRaycastNonAllocCallback_tC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D ** get_address_of_getRaycastNonAlloc_5() { return &___getRaycastNonAlloc_5; }
	inline void set_getRaycastNonAlloc_5(GetRaycastNonAllocCallback_tC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D * value)
	{
		___getRaycastNonAlloc_5 = value;
		Il2CppCodeGenWriteBarrier((&___getRaycastNonAlloc_5), value);
	}
};

struct ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A_StaticFields
{
public:
	// UnityEngine.UI.ReflectionMethodsCache UnityEngine.UI.ReflectionMethodsCache::s_ReflectionMethodsCache
	ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A * ___s_ReflectionMethodsCache_6;

public:
	inline static int32_t get_offset_of_s_ReflectionMethodsCache_6() { return static_cast<int32_t>(offsetof(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A_StaticFields, ___s_ReflectionMethodsCache_6)); }
	inline ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A * get_s_ReflectionMethodsCache_6() const { return ___s_ReflectionMethodsCache_6; }
	inline ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A ** get_address_of_s_ReflectionMethodsCache_6() { return &___s_ReflectionMethodsCache_6; }
	inline void set_s_ReflectionMethodsCache_6(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A * value)
	{
		___s_ReflectionMethodsCache_6 = value;
		Il2CppCodeGenWriteBarrier((&___s_ReflectionMethodsCache_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // REFLECTIONMETHODSCACHE_TBDADDC80D50C5F10BD00965217980B9A8D24BE8A_H
#ifndef U24ARRAYTYPEU3D12_T25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199_H
#define U24ARRAYTYPEU3D12_T25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>_U24ArrayTypeU3D12
#pragma pack(push, tp, 1)
struct  U24ArrayTypeU3D12_t25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199 
{
public:
	union
	{
		struct
		{
		};
		uint8_t U24ArrayTypeU3D12_t25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199__padding[12];
	};

public:
};
#pragma pack(pop, tp)

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U24ARRAYTYPEU3D12_T25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199_H
#ifndef CONNECTIONID_T47DBB761AF0DB1559EACE774B317DA2B8B67F66D_H
#define CONNECTIONID_T47DBB761AF0DB1559EACE774B317DA2B8B67F66D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.ConnectionId
struct  ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D 
{
public:
	// System.Int16 Byn.Awrtc.ConnectionId::id
	int16_t ___id_1;

public:
	inline static int32_t get_offset_of_id_1() { return static_cast<int32_t>(offsetof(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D, ___id_1)); }
	inline int16_t get_id_1() const { return ___id_1; }
	inline int16_t* get_address_of_id_1() { return &___id_1; }
	inline void set_id_1(int16_t value)
	{
		___id_1 = value;
	}
};

struct ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields
{
public:
	// Byn.Awrtc.ConnectionId Byn.Awrtc.ConnectionId::INVALID
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___INVALID_0;

public:
	inline static int32_t get_offset_of_INVALID_0() { return static_cast<int32_t>(offsetof(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D_StaticFields, ___INVALID_0)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_INVALID_0() const { return ___INVALID_0; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_INVALID_0() { return &___INVALID_0; }
	inline void set_INVALID_0(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___INVALID_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONNECTIONID_T47DBB761AF0DB1559EACE774B317DA2B8B67F66D_H
#ifndef CALIBRATION_T9AB78454E6D4068384FB24A31465696019A429D0_H
#define CALIBRATION_T9AB78454E6D4068384FB24A31465696019A429D0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Calibration
struct  Calibration_t9AB78454E6D4068384FB24A31465696019A429D0 
{
public:
	// System.Int32 LookingGlass.Calibration::index
	int32_t ___index_0;
	// System.Int32 LookingGlass.Calibration::screenWidth
	int32_t ___screenWidth_1;
	// System.Int32 LookingGlass.Calibration::screenHeight
	int32_t ___screenHeight_2;
	// System.Single LookingGlass.Calibration::subp
	float ___subp_3;
	// System.Single LookingGlass.Calibration::viewCone
	float ___viewCone_4;
	// System.Single LookingGlass.Calibration::aspect
	float ___aspect_5;
	// System.Single LookingGlass.Calibration::pitch
	float ___pitch_6;
	// System.Single LookingGlass.Calibration::slope
	float ___slope_7;
	// System.Single LookingGlass.Calibration::center
	float ___center_8;
	// System.Single LookingGlass.Calibration::fringe
	float ___fringe_9;
	// System.String LookingGlass.Calibration::serial
	String_t* ___serial_10;
	// System.String LookingGlass.Calibration::LKGname
	String_t* ___LKGname_11;
	// System.Int32 LookingGlass.Calibration::unityIndex
	int32_t ___unityIndex_12;
	// System.Int32 LookingGlass.Calibration::xpos
	int32_t ___xpos_13;
	// System.Int32 LookingGlass.Calibration::ypos
	int32_t ___ypos_14;

public:
	inline static int32_t get_offset_of_index_0() { return static_cast<int32_t>(offsetof(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0, ___index_0)); }
	inline int32_t get_index_0() const { return ___index_0; }
	inline int32_t* get_address_of_index_0() { return &___index_0; }
	inline void set_index_0(int32_t value)
	{
		___index_0 = value;
	}

	inline static int32_t get_offset_of_screenWidth_1() { return static_cast<int32_t>(offsetof(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0, ___screenWidth_1)); }
	inline int32_t get_screenWidth_1() const { return ___screenWidth_1; }
	inline int32_t* get_address_of_screenWidth_1() { return &___screenWidth_1; }
	inline void set_screenWidth_1(int32_t value)
	{
		___screenWidth_1 = value;
	}

	inline static int32_t get_offset_of_screenHeight_2() { return static_cast<int32_t>(offsetof(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0, ___screenHeight_2)); }
	inline int32_t get_screenHeight_2() const { return ___screenHeight_2; }
	inline int32_t* get_address_of_screenHeight_2() { return &___screenHeight_2; }
	inline void set_screenHeight_2(int32_t value)
	{
		___screenHeight_2 = value;
	}

	inline static int32_t get_offset_of_subp_3() { return static_cast<int32_t>(offsetof(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0, ___subp_3)); }
	inline float get_subp_3() const { return ___subp_3; }
	inline float* get_address_of_subp_3() { return &___subp_3; }
	inline void set_subp_3(float value)
	{
		___subp_3 = value;
	}

	inline static int32_t get_offset_of_viewCone_4() { return static_cast<int32_t>(offsetof(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0, ___viewCone_4)); }
	inline float get_viewCone_4() const { return ___viewCone_4; }
	inline float* get_address_of_viewCone_4() { return &___viewCone_4; }
	inline void set_viewCone_4(float value)
	{
		___viewCone_4 = value;
	}

	inline static int32_t get_offset_of_aspect_5() { return static_cast<int32_t>(offsetof(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0, ___aspect_5)); }
	inline float get_aspect_5() const { return ___aspect_5; }
	inline float* get_address_of_aspect_5() { return &___aspect_5; }
	inline void set_aspect_5(float value)
	{
		___aspect_5 = value;
	}

	inline static int32_t get_offset_of_pitch_6() { return static_cast<int32_t>(offsetof(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0, ___pitch_6)); }
	inline float get_pitch_6() const { return ___pitch_6; }
	inline float* get_address_of_pitch_6() { return &___pitch_6; }
	inline void set_pitch_6(float value)
	{
		___pitch_6 = value;
	}

	inline static int32_t get_offset_of_slope_7() { return static_cast<int32_t>(offsetof(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0, ___slope_7)); }
	inline float get_slope_7() const { return ___slope_7; }
	inline float* get_address_of_slope_7() { return &___slope_7; }
	inline void set_slope_7(float value)
	{
		___slope_7 = value;
	}

	inline static int32_t get_offset_of_center_8() { return static_cast<int32_t>(offsetof(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0, ___center_8)); }
	inline float get_center_8() const { return ___center_8; }
	inline float* get_address_of_center_8() { return &___center_8; }
	inline void set_center_8(float value)
	{
		___center_8 = value;
	}

	inline static int32_t get_offset_of_fringe_9() { return static_cast<int32_t>(offsetof(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0, ___fringe_9)); }
	inline float get_fringe_9() const { return ___fringe_9; }
	inline float* get_address_of_fringe_9() { return &___fringe_9; }
	inline void set_fringe_9(float value)
	{
		___fringe_9 = value;
	}

	inline static int32_t get_offset_of_serial_10() { return static_cast<int32_t>(offsetof(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0, ___serial_10)); }
	inline String_t* get_serial_10() const { return ___serial_10; }
	inline String_t** get_address_of_serial_10() { return &___serial_10; }
	inline void set_serial_10(String_t* value)
	{
		___serial_10 = value;
		Il2CppCodeGenWriteBarrier((&___serial_10), value);
	}

	inline static int32_t get_offset_of_LKGname_11() { return static_cast<int32_t>(offsetof(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0, ___LKGname_11)); }
	inline String_t* get_LKGname_11() const { return ___LKGname_11; }
	inline String_t** get_address_of_LKGname_11() { return &___LKGname_11; }
	inline void set_LKGname_11(String_t* value)
	{
		___LKGname_11 = value;
		Il2CppCodeGenWriteBarrier((&___LKGname_11), value);
	}

	inline static int32_t get_offset_of_unityIndex_12() { return static_cast<int32_t>(offsetof(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0, ___unityIndex_12)); }
	inline int32_t get_unityIndex_12() const { return ___unityIndex_12; }
	inline int32_t* get_address_of_unityIndex_12() { return &___unityIndex_12; }
	inline void set_unityIndex_12(int32_t value)
	{
		___unityIndex_12 = value;
	}

	inline static int32_t get_offset_of_xpos_13() { return static_cast<int32_t>(offsetof(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0, ___xpos_13)); }
	inline int32_t get_xpos_13() const { return ___xpos_13; }
	inline int32_t* get_address_of_xpos_13() { return &___xpos_13; }
	inline void set_xpos_13(int32_t value)
	{
		___xpos_13 = value;
	}

	inline static int32_t get_offset_of_ypos_14() { return static_cast<int32_t>(offsetof(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0, ___ypos_14)); }
	inline int32_t get_ypos_14() const { return ___ypos_14; }
	inline int32_t* get_address_of_ypos_14() { return &___ypos_14; }
	inline void set_ypos_14(int32_t value)
	{
		___ypos_14 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of LookingGlass.Calibration
struct Calibration_t9AB78454E6D4068384FB24A31465696019A429D0_marshaled_pinvoke
{
	int32_t ___index_0;
	int32_t ___screenWidth_1;
	int32_t ___screenHeight_2;
	float ___subp_3;
	float ___viewCone_4;
	float ___aspect_5;
	float ___pitch_6;
	float ___slope_7;
	float ___center_8;
	float ___fringe_9;
	char* ___serial_10;
	char* ___LKGname_11;
	int32_t ___unityIndex_12;
	int32_t ___xpos_13;
	int32_t ___ypos_14;
};
// Native definition for COM marshalling of LookingGlass.Calibration
struct Calibration_t9AB78454E6D4068384FB24A31465696019A429D0_marshaled_com
{
	int32_t ___index_0;
	int32_t ___screenWidth_1;
	int32_t ___screenHeight_2;
	float ___subp_3;
	float ___viewCone_4;
	float ___aspect_5;
	float ___pitch_6;
	float ___slope_7;
	float ___center_8;
	float ___fringe_9;
	Il2CppChar* ___serial_10;
	Il2CppChar* ___LKGname_11;
	int32_t ___unityIndex_12;
	int32_t ___xpos_13;
	int32_t ___ypos_14;
};
#endif // CALIBRATION_T9AB78454E6D4068384FB24A31465696019A429D0_H
#ifndef LOADRESULTS_T3028A604D8ED7E35E4316051844BAEECE1930F02_H
#define LOADRESULTS_T3028A604D8ED7E35E4316051844BAEECE1930F02_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.LoadResults
struct  LoadResults_t3028A604D8ED7E35E4316051844BAEECE1930F02 
{
public:
	// System.Boolean LookingGlass.LoadResults::attempted
	bool ___attempted_0;
	// System.Boolean LookingGlass.LoadResults::calibrationFound
	bool ___calibrationFound_1;
	// System.Boolean LookingGlass.LoadResults::lkgDisplayFound
	bool ___lkgDisplayFound_2;

public:
	inline static int32_t get_offset_of_attempted_0() { return static_cast<int32_t>(offsetof(LoadResults_t3028A604D8ED7E35E4316051844BAEECE1930F02, ___attempted_0)); }
	inline bool get_attempted_0() const { return ___attempted_0; }
	inline bool* get_address_of_attempted_0() { return &___attempted_0; }
	inline void set_attempted_0(bool value)
	{
		___attempted_0 = value;
	}

	inline static int32_t get_offset_of_calibrationFound_1() { return static_cast<int32_t>(offsetof(LoadResults_t3028A604D8ED7E35E4316051844BAEECE1930F02, ___calibrationFound_1)); }
	inline bool get_calibrationFound_1() const { return ___calibrationFound_1; }
	inline bool* get_address_of_calibrationFound_1() { return &___calibrationFound_1; }
	inline void set_calibrationFound_1(bool value)
	{
		___calibrationFound_1 = value;
	}

	inline static int32_t get_offset_of_lkgDisplayFound_2() { return static_cast<int32_t>(offsetof(LoadResults_t3028A604D8ED7E35E4316051844BAEECE1930F02, ___lkgDisplayFound_2)); }
	inline bool get_lkgDisplayFound_2() const { return ___lkgDisplayFound_2; }
	inline bool* get_address_of_lkgDisplayFound_2() { return &___lkgDisplayFound_2; }
	inline void set_lkgDisplayFound_2(bool value)
	{
		___lkgDisplayFound_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of LookingGlass.LoadResults
struct LoadResults_t3028A604D8ED7E35E4316051844BAEECE1930F02_marshaled_pinvoke
{
	int32_t ___attempted_0;
	int32_t ___calibrationFound_1;
	int32_t ___lkgDisplayFound_2;
};
// Native definition for COM marshalling of LookingGlass.LoadResults
struct LoadResults_t3028A604D8ED7E35E4316051844BAEECE1930F02_marshaled_com
{
	int32_t ___attempted_0;
	int32_t ___calibrationFound_1;
	int32_t ___lkgDisplayFound_2;
};
#endif // LOADRESULTS_T3028A604D8ED7E35E4316051844BAEECE1930F02_H
#ifndef SETTINGS_T66035998D175B806D5716B35A62E2BCA7FC51F46_H
#define SETTINGS_T66035998D175B806D5716B35A62E2BCA7FC51F46_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Quilt_Settings
struct  Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46 
{
public:
	// System.Int32 LookingGlass.Quilt_Settings::quiltWidth
	int32_t ___quiltWidth_0;
	// System.Int32 LookingGlass.Quilt_Settings::quiltHeight
	int32_t ___quiltHeight_1;
	// System.Int32 LookingGlass.Quilt_Settings::viewColumns
	int32_t ___viewColumns_2;
	// System.Int32 LookingGlass.Quilt_Settings::viewRows
	int32_t ___viewRows_3;
	// System.Int32 LookingGlass.Quilt_Settings::numViews
	int32_t ___numViews_4;
	// System.Int32 LookingGlass.Quilt_Settings::viewWidth
	int32_t ___viewWidth_5;
	// System.Int32 LookingGlass.Quilt_Settings::viewHeight
	int32_t ___viewHeight_6;
	// System.Int32 LookingGlass.Quilt_Settings::paddingHorizontal
	int32_t ___paddingHorizontal_7;
	// System.Int32 LookingGlass.Quilt_Settings::paddingVertical
	int32_t ___paddingVertical_8;
	// System.Single LookingGlass.Quilt_Settings::viewPortionHorizontal
	float ___viewPortionHorizontal_9;
	// System.Single LookingGlass.Quilt_Settings::viewPortionVertical
	float ___viewPortionVertical_10;
	// System.Single LookingGlass.Quilt_Settings::aspect
	float ___aspect_11;
	// System.Boolean LookingGlass.Quilt_Settings::overscan
	bool ___overscan_12;

public:
	inline static int32_t get_offset_of_quiltWidth_0() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___quiltWidth_0)); }
	inline int32_t get_quiltWidth_0() const { return ___quiltWidth_0; }
	inline int32_t* get_address_of_quiltWidth_0() { return &___quiltWidth_0; }
	inline void set_quiltWidth_0(int32_t value)
	{
		___quiltWidth_0 = value;
	}

	inline static int32_t get_offset_of_quiltHeight_1() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___quiltHeight_1)); }
	inline int32_t get_quiltHeight_1() const { return ___quiltHeight_1; }
	inline int32_t* get_address_of_quiltHeight_1() { return &___quiltHeight_1; }
	inline void set_quiltHeight_1(int32_t value)
	{
		___quiltHeight_1 = value;
	}

	inline static int32_t get_offset_of_viewColumns_2() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___viewColumns_2)); }
	inline int32_t get_viewColumns_2() const { return ___viewColumns_2; }
	inline int32_t* get_address_of_viewColumns_2() { return &___viewColumns_2; }
	inline void set_viewColumns_2(int32_t value)
	{
		___viewColumns_2 = value;
	}

	inline static int32_t get_offset_of_viewRows_3() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___viewRows_3)); }
	inline int32_t get_viewRows_3() const { return ___viewRows_3; }
	inline int32_t* get_address_of_viewRows_3() { return &___viewRows_3; }
	inline void set_viewRows_3(int32_t value)
	{
		___viewRows_3 = value;
	}

	inline static int32_t get_offset_of_numViews_4() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___numViews_4)); }
	inline int32_t get_numViews_4() const { return ___numViews_4; }
	inline int32_t* get_address_of_numViews_4() { return &___numViews_4; }
	inline void set_numViews_4(int32_t value)
	{
		___numViews_4 = value;
	}

	inline static int32_t get_offset_of_viewWidth_5() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___viewWidth_5)); }
	inline int32_t get_viewWidth_5() const { return ___viewWidth_5; }
	inline int32_t* get_address_of_viewWidth_5() { return &___viewWidth_5; }
	inline void set_viewWidth_5(int32_t value)
	{
		___viewWidth_5 = value;
	}

	inline static int32_t get_offset_of_viewHeight_6() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___viewHeight_6)); }
	inline int32_t get_viewHeight_6() const { return ___viewHeight_6; }
	inline int32_t* get_address_of_viewHeight_6() { return &___viewHeight_6; }
	inline void set_viewHeight_6(int32_t value)
	{
		___viewHeight_6 = value;
	}

	inline static int32_t get_offset_of_paddingHorizontal_7() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___paddingHorizontal_7)); }
	inline int32_t get_paddingHorizontal_7() const { return ___paddingHorizontal_7; }
	inline int32_t* get_address_of_paddingHorizontal_7() { return &___paddingHorizontal_7; }
	inline void set_paddingHorizontal_7(int32_t value)
	{
		___paddingHorizontal_7 = value;
	}

	inline static int32_t get_offset_of_paddingVertical_8() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___paddingVertical_8)); }
	inline int32_t get_paddingVertical_8() const { return ___paddingVertical_8; }
	inline int32_t* get_address_of_paddingVertical_8() { return &___paddingVertical_8; }
	inline void set_paddingVertical_8(int32_t value)
	{
		___paddingVertical_8 = value;
	}

	inline static int32_t get_offset_of_viewPortionHorizontal_9() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___viewPortionHorizontal_9)); }
	inline float get_viewPortionHorizontal_9() const { return ___viewPortionHorizontal_9; }
	inline float* get_address_of_viewPortionHorizontal_9() { return &___viewPortionHorizontal_9; }
	inline void set_viewPortionHorizontal_9(float value)
	{
		___viewPortionHorizontal_9 = value;
	}

	inline static int32_t get_offset_of_viewPortionVertical_10() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___viewPortionVertical_10)); }
	inline float get_viewPortionVertical_10() const { return ___viewPortionVertical_10; }
	inline float* get_address_of_viewPortionVertical_10() { return &___viewPortionVertical_10; }
	inline void set_viewPortionVertical_10(float value)
	{
		___viewPortionVertical_10 = value;
	}

	inline static int32_t get_offset_of_aspect_11() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___aspect_11)); }
	inline float get_aspect_11() const { return ___aspect_11; }
	inline float* get_address_of_aspect_11() { return &___aspect_11; }
	inline void set_aspect_11(float value)
	{
		___aspect_11 = value;
	}

	inline static int32_t get_offset_of_overscan_12() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___overscan_12)); }
	inline bool get_overscan_12() const { return ___overscan_12; }
	inline bool* get_address_of_overscan_12() { return &___overscan_12; }
	inline void set_overscan_12(bool value)
	{
		___overscan_12 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of LookingGlass.Quilt/Settings
struct Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46_marshaled_pinvoke
{
	int32_t ___quiltWidth_0;
	int32_t ___quiltHeight_1;
	int32_t ___viewColumns_2;
	int32_t ___viewRows_3;
	int32_t ___numViews_4;
	int32_t ___viewWidth_5;
	int32_t ___viewHeight_6;
	int32_t ___paddingHorizontal_7;
	int32_t ___paddingVertical_8;
	float ___viewPortionHorizontal_9;
	float ___viewPortionVertical_10;
	float ___aspect_11;
	int32_t ___overscan_12;
};
// Native definition for COM marshalling of LookingGlass.Quilt/Settings
struct Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46_marshaled_com
{
	int32_t ___quiltWidth_0;
	int32_t ___quiltHeight_1;
	int32_t ___viewColumns_2;
	int32_t ___viewRows_3;
	int32_t ___numViews_4;
	int32_t ___viewWidth_5;
	int32_t ___viewHeight_6;
	int32_t ___paddingHorizontal_7;
	int32_t ___paddingVertical_8;
	float ___viewPortionHorizontal_9;
	float ___viewPortionVertical_10;
	float ___aspect_11;
	int32_t ___overscan_12;
};
#endif // SETTINGS_T66035998D175B806D5716B35A62E2BCA7FC51F46_H
#ifndef ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#define ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t2AF27C02B8653AE29442467390005ABC74D8F521  : public ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF
{
public:

public:
};

struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((&___enumSeperatorCharArray_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_com
{
};
#endif // ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#ifndef INT32_T585191389E07734F19F3156FF88FB3EF4800D102_H
#define INT32_T585191389E07734F19F3156FF88FB3EF4800D102_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Int32
struct  Int32_t585191389E07734F19F3156FF88FB3EF4800D102 
{
public:
	// System.Int32 System.Int32::m_value
	int32_t ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Int32_t585191389E07734F19F3156FF88FB3EF4800D102, ___m_value_0)); }
	inline int32_t get_m_value_0() const { return ___m_value_0; }
	inline int32_t* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(int32_t value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INT32_T585191389E07734F19F3156FF88FB3EF4800D102_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef SINGLE_TDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1_H
#define SINGLE_TDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Single
struct  Single_tDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1 
{
public:
	// System.Single System.Single::m_value
	float ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(Single_tDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1, ___m_value_0)); }
	inline float get_m_value_0() const { return ___m_value_0; }
	inline float* get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(float value)
	{
		___m_value_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SINGLE_TDDDA9169C4E4E308AC6D7A824F9B28DC82204AE1_H
#ifndef VOID_T22962CB4C05B1D89B55A6E1139F0E87A90987017_H
#define VOID_T22962CB4C05B1D89B55A6E1139F0E87A90987017_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Void
struct  Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017__padding[1];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VOID_T22962CB4C05B1D89B55A6E1139F0E87A90987017_H
#ifndef COLOR_T119BCA590009762C7223FDD3AF9706653AC84ED2_H
#define COLOR_T119BCA590009762C7223FDD3AF9706653AC84ED2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Color
struct  Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 
{
public:
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;

public:
	inline static int32_t get_offset_of_r_0() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___r_0)); }
	inline float get_r_0() const { return ___r_0; }
	inline float* get_address_of_r_0() { return &___r_0; }
	inline void set_r_0(float value)
	{
		___r_0 = value;
	}

	inline static int32_t get_offset_of_g_1() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___g_1)); }
	inline float get_g_1() const { return ___g_1; }
	inline float* get_address_of_g_1() { return &___g_1; }
	inline void set_g_1(float value)
	{
		___g_1 = value;
	}

	inline static int32_t get_offset_of_b_2() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___b_2)); }
	inline float get_b_2() const { return ___b_2; }
	inline float* get_address_of_b_2() { return &___b_2; }
	inline void set_b_2(float value)
	{
		___b_2 = value;
	}

	inline static int32_t get_offset_of_a_3() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___a_3)); }
	inline float get_a_3() const { return ___a_3; }
	inline float* get_address_of_a_3() { return &___a_3; }
	inline void set_a_3(float value)
	{
		___a_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLOR_T119BCA590009762C7223FDD3AF9706653AC84ED2_H
#ifndef DRIVENRECTTRANSFORMTRACKER_TB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03_H
#define DRIVENRECTTRANSFORMTRACKER_TB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.DrivenRectTransformTracker
struct  DrivenRectTransformTracker_tB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03 
{
public:
	union
	{
		struct
		{
		};
		uint8_t DrivenRectTransformTracker_tB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03__padding[1];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DRIVENRECTTRANSFORMTRACKER_TB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03_H
#ifndef UNITYEVENT_1_TFA903A9843B19B1ABCA8061C5BEC94800BF1CD81_H
#define UNITYEVENT_1_TFA903A9843B19B1ABCA8061C5BEC94800BF1CD81_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Events.UnityEvent`1<LookingGlass.LoadResults>
struct  UnityEvent_1_tFA903A9843B19B1ABCA8061C5BEC94800BF1CD81  : public UnityEventBase_t6E0F7823762EE94BB8489B5AE41C7802A266D3D5
{
public:
	// System.Object[] UnityEngine.Events.UnityEvent`1::m_InvokeArray
	ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* ___m_InvokeArray_3;

public:
	inline static int32_t get_offset_of_m_InvokeArray_3() { return static_cast<int32_t>(offsetof(UnityEvent_1_tFA903A9843B19B1ABCA8061C5BEC94800BF1CD81, ___m_InvokeArray_3)); }
	inline ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* get_m_InvokeArray_3() const { return ___m_InvokeArray_3; }
	inline ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A** get_address_of_m_InvokeArray_3() { return &___m_InvokeArray_3; }
	inline void set_m_InvokeArray_3(ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* value)
	{
		___m_InvokeArray_3 = value;
		Il2CppCodeGenWriteBarrier((&___m_InvokeArray_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNITYEVENT_1_TFA903A9843B19B1ABCA8061C5BEC94800BF1CD81_H
#ifndef UNITYEVENT_2_T41702E3BA912BDFCAEF2171F44BD45CFE01C793A_H
#define UNITYEVENT_2_T41702E3BA912BDFCAEF2171F44BD45CFE01C793A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Events.UnityEvent`2<LookingGlass.Holoplay,System.Int32>
struct  UnityEvent_2_t41702E3BA912BDFCAEF2171F44BD45CFE01C793A  : public UnityEventBase_t6E0F7823762EE94BB8489B5AE41C7802A266D3D5
{
public:
	// System.Object[] UnityEngine.Events.UnityEvent`2::m_InvokeArray
	ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* ___m_InvokeArray_3;

public:
	inline static int32_t get_offset_of_m_InvokeArray_3() { return static_cast<int32_t>(offsetof(UnityEvent_2_t41702E3BA912BDFCAEF2171F44BD45CFE01C793A, ___m_InvokeArray_3)); }
	inline ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* get_m_InvokeArray_3() const { return ___m_InvokeArray_3; }
	inline ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A** get_address_of_m_InvokeArray_3() { return &___m_InvokeArray_3; }
	inline void set_m_InvokeArray_3(ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* value)
	{
		___m_InvokeArray_3 = value;
		Il2CppCodeGenWriteBarrier((&___m_InvokeArray_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNITYEVENT_2_T41702E3BA912BDFCAEF2171F44BD45CFE01C793A_H
#ifndef LAYERMASK_TBB9173D8B6939D476E67E849280AC9F4EC4D93B0_H
#define LAYERMASK_TBB9173D8B6939D476E67E849280AC9F4EC4D93B0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.LayerMask
struct  LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0 
{
public:
	// System.Int32 UnityEngine.LayerMask::m_Mask
	int32_t ___m_Mask_0;

public:
	inline static int32_t get_offset_of_m_Mask_0() { return static_cast<int32_t>(offsetof(LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0, ___m_Mask_0)); }
	inline int32_t get_m_Mask_0() const { return ___m_Mask_0; }
	inline int32_t* get_address_of_m_Mask_0() { return &___m_Mask_0; }
	inline void set_m_Mask_0(int32_t value)
	{
		___m_Mask_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LAYERMASK_TBB9173D8B6939D476E67E849280AC9F4EC4D93B0_H
#ifndef QUATERNION_T319F3319A7D43FFA5D819AD6C0A98851F0095357_H
#define QUATERNION_T319F3319A7D43FFA5D819AD6C0A98851F0095357_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Quaternion
struct  Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357 
{
public:
	// System.Single UnityEngine.Quaternion::x
	float ___x_0;
	// System.Single UnityEngine.Quaternion::y
	float ___y_1;
	// System.Single UnityEngine.Quaternion::z
	float ___z_2;
	// System.Single UnityEngine.Quaternion::w
	float ___w_3;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}

	inline static int32_t get_offset_of_z_2() { return static_cast<int32_t>(offsetof(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357, ___z_2)); }
	inline float get_z_2() const { return ___z_2; }
	inline float* get_address_of_z_2() { return &___z_2; }
	inline void set_z_2(float value)
	{
		___z_2 = value;
	}

	inline static int32_t get_offset_of_w_3() { return static_cast<int32_t>(offsetof(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357, ___w_3)); }
	inline float get_w_3() const { return ___w_3; }
	inline float* get_address_of_w_3() { return &___w_3; }
	inline void set_w_3(float value)
	{
		___w_3 = value;
	}
};

struct Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357_StaticFields
{
public:
	// UnityEngine.Quaternion UnityEngine.Quaternion::identityQuaternion
	Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  ___identityQuaternion_4;

public:
	inline static int32_t get_offset_of_identityQuaternion_4() { return static_cast<int32_t>(offsetof(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357_StaticFields, ___identityQuaternion_4)); }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  get_identityQuaternion_4() const { return ___identityQuaternion_4; }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357 * get_address_of_identityQuaternion_4() { return &___identityQuaternion_4; }
	inline void set_identityQuaternion_4(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  value)
	{
		___identityQuaternion_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // QUATERNION_T319F3319A7D43FFA5D819AD6C0A98851F0095357_H
#ifndef VECTOR2_TA85D2DD88578276CA8A8796756458277E72D073D_H
#define VECTOR2_TA85D2DD88578276CA8A8796756458277E72D073D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector2
struct  Vector2_tA85D2DD88578276CA8A8796756458277E72D073D 
{
public:
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}
};

struct Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields
{
public:
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___negativeInfinityVector_9;

public:
	inline static int32_t get_offset_of_zeroVector_2() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___zeroVector_2)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_zeroVector_2() const { return ___zeroVector_2; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_zeroVector_2() { return &___zeroVector_2; }
	inline void set_zeroVector_2(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___zeroVector_2 = value;
	}

	inline static int32_t get_offset_of_oneVector_3() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___oneVector_3)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_oneVector_3() const { return ___oneVector_3; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_oneVector_3() { return &___oneVector_3; }
	inline void set_oneVector_3(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___oneVector_3 = value;
	}

	inline static int32_t get_offset_of_upVector_4() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___upVector_4)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_upVector_4() const { return ___upVector_4; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_upVector_4() { return &___upVector_4; }
	inline void set_upVector_4(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___upVector_4 = value;
	}

	inline static int32_t get_offset_of_downVector_5() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___downVector_5)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_downVector_5() const { return ___downVector_5; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_downVector_5() { return &___downVector_5; }
	inline void set_downVector_5(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___downVector_5 = value;
	}

	inline static int32_t get_offset_of_leftVector_6() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___leftVector_6)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_leftVector_6() const { return ___leftVector_6; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_leftVector_6() { return &___leftVector_6; }
	inline void set_leftVector_6(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___leftVector_6 = value;
	}

	inline static int32_t get_offset_of_rightVector_7() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___rightVector_7)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_rightVector_7() const { return ___rightVector_7; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_rightVector_7() { return &___rightVector_7; }
	inline void set_rightVector_7(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___rightVector_7 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___positiveInfinityVector_8)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_positiveInfinityVector_8() const { return ___positiveInfinityVector_8; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_positiveInfinityVector_8() { return &___positiveInfinityVector_8; }
	inline void set_positiveInfinityVector_8(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___positiveInfinityVector_8 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_9() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___negativeInfinityVector_9)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_negativeInfinityVector_9() const { return ___negativeInfinityVector_9; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_negativeInfinityVector_9() { return &___negativeInfinityVector_9; }
	inline void set_negativeInfinityVector_9(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___negativeInfinityVector_9 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR2_TA85D2DD88578276CA8A8796756458277E72D073D_H
#ifndef VECTOR2INT_T339DA203C037FA6BCFC926C36DC2194D52D5F905_H
#define VECTOR2INT_T339DA203C037FA6BCFC926C36DC2194D52D5F905_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector2Int
struct  Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905 
{
public:
	// System.Int32 UnityEngine.Vector2Int::m_X
	int32_t ___m_X_0;
	// System.Int32 UnityEngine.Vector2Int::m_Y
	int32_t ___m_Y_1;

public:
	inline static int32_t get_offset_of_m_X_0() { return static_cast<int32_t>(offsetof(Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905, ___m_X_0)); }
	inline int32_t get_m_X_0() const { return ___m_X_0; }
	inline int32_t* get_address_of_m_X_0() { return &___m_X_0; }
	inline void set_m_X_0(int32_t value)
	{
		___m_X_0 = value;
	}

	inline static int32_t get_offset_of_m_Y_1() { return static_cast<int32_t>(offsetof(Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905, ___m_Y_1)); }
	inline int32_t get_m_Y_1() const { return ___m_Y_1; }
	inline int32_t* get_address_of_m_Y_1() { return &___m_Y_1; }
	inline void set_m_Y_1(int32_t value)
	{
		___m_Y_1 = value;
	}
};

struct Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905_StaticFields
{
public:
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Zero
	Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  ___s_Zero_2;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_One
	Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  ___s_One_3;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Up
	Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  ___s_Up_4;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Down
	Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  ___s_Down_5;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Left
	Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  ___s_Left_6;
	// UnityEngine.Vector2Int UnityEngine.Vector2Int::s_Right
	Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  ___s_Right_7;

public:
	inline static int32_t get_offset_of_s_Zero_2() { return static_cast<int32_t>(offsetof(Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905_StaticFields, ___s_Zero_2)); }
	inline Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  get_s_Zero_2() const { return ___s_Zero_2; }
	inline Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905 * get_address_of_s_Zero_2() { return &___s_Zero_2; }
	inline void set_s_Zero_2(Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  value)
	{
		___s_Zero_2 = value;
	}

	inline static int32_t get_offset_of_s_One_3() { return static_cast<int32_t>(offsetof(Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905_StaticFields, ___s_One_3)); }
	inline Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  get_s_One_3() const { return ___s_One_3; }
	inline Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905 * get_address_of_s_One_3() { return &___s_One_3; }
	inline void set_s_One_3(Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  value)
	{
		___s_One_3 = value;
	}

	inline static int32_t get_offset_of_s_Up_4() { return static_cast<int32_t>(offsetof(Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905_StaticFields, ___s_Up_4)); }
	inline Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  get_s_Up_4() const { return ___s_Up_4; }
	inline Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905 * get_address_of_s_Up_4() { return &___s_Up_4; }
	inline void set_s_Up_4(Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  value)
	{
		___s_Up_4 = value;
	}

	inline static int32_t get_offset_of_s_Down_5() { return static_cast<int32_t>(offsetof(Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905_StaticFields, ___s_Down_5)); }
	inline Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  get_s_Down_5() const { return ___s_Down_5; }
	inline Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905 * get_address_of_s_Down_5() { return &___s_Down_5; }
	inline void set_s_Down_5(Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  value)
	{
		___s_Down_5 = value;
	}

	inline static int32_t get_offset_of_s_Left_6() { return static_cast<int32_t>(offsetof(Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905_StaticFields, ___s_Left_6)); }
	inline Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  get_s_Left_6() const { return ___s_Left_6; }
	inline Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905 * get_address_of_s_Left_6() { return &___s_Left_6; }
	inline void set_s_Left_6(Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  value)
	{
		___s_Left_6 = value;
	}

	inline static int32_t get_offset_of_s_Right_7() { return static_cast<int32_t>(offsetof(Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905_StaticFields, ___s_Right_7)); }
	inline Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  get_s_Right_7() const { return ___s_Right_7; }
	inline Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905 * get_address_of_s_Right_7() { return &___s_Right_7; }
	inline void set_s_Right_7(Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  value)
	{
		___s_Right_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR2INT_T339DA203C037FA6BCFC926C36DC2194D52D5F905_H
#ifndef VECTOR3_TDCF05E21F632FE2BA260C06E0D10CA81513E6720_H
#define VECTOR3_TDCF05E21F632FE2BA260C06E0D10CA81513E6720_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector3
struct  Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 
{
public:
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;

public:
	inline static int32_t get_offset_of_x_2() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___x_2)); }
	inline float get_x_2() const { return ___x_2; }
	inline float* get_address_of_x_2() { return &___x_2; }
	inline void set_x_2(float value)
	{
		___x_2 = value;
	}

	inline static int32_t get_offset_of_y_3() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___y_3)); }
	inline float get_y_3() const { return ___y_3; }
	inline float* get_address_of_y_3() { return &___y_3; }
	inline void set_y_3(float value)
	{
		___y_3 = value;
	}

	inline static int32_t get_offset_of_z_4() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___z_4)); }
	inline float get_z_4() const { return ___z_4; }
	inline float* get_address_of_z_4() { return &___z_4; }
	inline void set_z_4(float value)
	{
		___z_4 = value;
	}
};

struct Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields
{
public:
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___negativeInfinityVector_14;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___zeroVector_5)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___oneVector_6)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_upVector_7() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___upVector_7)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_upVector_7() const { return ___upVector_7; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_upVector_7() { return &___upVector_7; }
	inline void set_upVector_7(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___upVector_7 = value;
	}

	inline static int32_t get_offset_of_downVector_8() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___downVector_8)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_downVector_8() const { return ___downVector_8; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_downVector_8() { return &___downVector_8; }
	inline void set_downVector_8(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___downVector_8 = value;
	}

	inline static int32_t get_offset_of_leftVector_9() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___leftVector_9)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_leftVector_9() const { return ___leftVector_9; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_leftVector_9() { return &___leftVector_9; }
	inline void set_leftVector_9(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___leftVector_9 = value;
	}

	inline static int32_t get_offset_of_rightVector_10() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___rightVector_10)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_rightVector_10() const { return ___rightVector_10; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_rightVector_10() { return &___rightVector_10; }
	inline void set_rightVector_10(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___rightVector_10 = value;
	}

	inline static int32_t get_offset_of_forwardVector_11() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___forwardVector_11)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_forwardVector_11() const { return ___forwardVector_11; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_forwardVector_11() { return &___forwardVector_11; }
	inline void set_forwardVector_11(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___forwardVector_11 = value;
	}

	inline static int32_t get_offset_of_backVector_12() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___backVector_12)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_backVector_12() const { return ___backVector_12; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_backVector_12() { return &___backVector_12; }
	inline void set_backVector_12(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___backVector_12 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_13() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___positiveInfinityVector_13)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_positiveInfinityVector_13() const { return ___positiveInfinityVector_13; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_positiveInfinityVector_13() { return &___positiveInfinityVector_13; }
	inline void set_positiveInfinityVector_13(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___positiveInfinityVector_13 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_14() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___negativeInfinityVector_14)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_negativeInfinityVector_14() const { return ___negativeInfinityVector_14; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_negativeInfinityVector_14() { return &___negativeInfinityVector_14; }
	inline void set_negativeInfinityVector_14(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___negativeInfinityVector_14 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR3_TDCF05E21F632FE2BA260C06E0D10CA81513E6720_H
#ifndef VECTOR4_TD148D6428C3F8FF6CD998F82090113C2B490B76E_H
#define VECTOR4_TD148D6428C3F8FF6CD998F82090113C2B490B76E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector4
struct  Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E 
{
public:
	// System.Single UnityEngine.Vector4::x
	float ___x_1;
	// System.Single UnityEngine.Vector4::y
	float ___y_2;
	// System.Single UnityEngine.Vector4::z
	float ___z_3;
	// System.Single UnityEngine.Vector4::w
	float ___w_4;

public:
	inline static int32_t get_offset_of_x_1() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E, ___x_1)); }
	inline float get_x_1() const { return ___x_1; }
	inline float* get_address_of_x_1() { return &___x_1; }
	inline void set_x_1(float value)
	{
		___x_1 = value;
	}

	inline static int32_t get_offset_of_y_2() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E, ___y_2)); }
	inline float get_y_2() const { return ___y_2; }
	inline float* get_address_of_y_2() { return &___y_2; }
	inline void set_y_2(float value)
	{
		___y_2 = value;
	}

	inline static int32_t get_offset_of_z_3() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E, ___z_3)); }
	inline float get_z_3() const { return ___z_3; }
	inline float* get_address_of_z_3() { return &___z_3; }
	inline void set_z_3(float value)
	{
		___z_3 = value;
	}

	inline static int32_t get_offset_of_w_4() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E, ___w_4)); }
	inline float get_w_4() const { return ___w_4; }
	inline float* get_address_of_w_4() { return &___w_4; }
	inline void set_w_4(float value)
	{
		___w_4 = value;
	}
};

struct Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields
{
public:
	// UnityEngine.Vector4 UnityEngine.Vector4::zeroVector
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___zeroVector_5;
	// UnityEngine.Vector4 UnityEngine.Vector4::oneVector
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___oneVector_6;
	// UnityEngine.Vector4 UnityEngine.Vector4::positiveInfinityVector
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___positiveInfinityVector_7;
	// UnityEngine.Vector4 UnityEngine.Vector4::negativeInfinityVector
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___negativeInfinityVector_8;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields, ___zeroVector_5)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields, ___oneVector_6)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_7() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields, ___positiveInfinityVector_7)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_positiveInfinityVector_7() const { return ___positiveInfinityVector_7; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_positiveInfinityVector_7() { return &___positiveInfinityVector_7; }
	inline void set_positiveInfinityVector_7(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___positiveInfinityVector_7 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields, ___negativeInfinityVector_8)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_negativeInfinityVector_8() const { return ___negativeInfinityVector_8; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_negativeInfinityVector_8() { return &___negativeInfinityVector_8; }
	inline void set_negativeInfinityVector_8(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___negativeInfinityVector_8 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR4_TD148D6428C3F8FF6CD998F82090113C2B490B76E_H
#ifndef U3CPRIVATEIMPLEMENTATIONDETAILSU3E_TC8332394FBFEEB4B73459A35E182942340DA3537_H
#define U3CPRIVATEIMPLEMENTATIONDETAILSU3E_TC8332394FBFEEB4B73459A35E182942340DA3537_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>
struct  U3CPrivateImplementationDetailsU3E_tC8332394FBFEEB4B73459A35E182942340DA3537  : public RuntimeObject
{
public:

public:
};

struct U3CPrivateImplementationDetailsU3E_tC8332394FBFEEB4B73459A35E182942340DA3537_StaticFields
{
public:
	// <PrivateImplementationDetails>_U24ArrayTypeU3D12 <PrivateImplementationDetails>::U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46
	U24ArrayTypeU3D12_t25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199  ___U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0;

public:
	inline static int32_t get_offset_of_U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tC8332394FBFEEB4B73459A35E182942340DA3537_StaticFields, ___U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0)); }
	inline U24ArrayTypeU3D12_t25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199  get_U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0() const { return ___U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0; }
	inline U24ArrayTypeU3D12_t25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199 * get_address_of_U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0() { return &___U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0; }
	inline void set_U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0(U24ArrayTypeU3D12_t25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199  value)
	{
		___U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CPRIVATEIMPLEMENTATIONDETAILSU3E_TC8332394FBFEEB4B73459A35E182942340DA3537_H
#ifndef FRAMEPIXELFORMAT_TDCE4288D3AD386370E428FCC0668229B6994D9BB_H
#define FRAMEPIXELFORMAT_TDCE4288D3AD386370E428FCC0668229B6994D9BB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.FramePixelFormat
struct  FramePixelFormat_tDCE4288D3AD386370E428FCC0668229B6994D9BB 
{
public:
	// System.Int32 Byn.Awrtc.FramePixelFormat::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(FramePixelFormat_tDCE4288D3AD386370E428FCC0668229B6994D9BB, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FRAMEPIXELFORMAT_TDCE4288D3AD386370E428FCC0668229B6994D9BB_H
#ifndef INITSTATE_TF0A3A2CE215643EDF5BC6E278CE7E7578E38A18C_H
#define INITSTATE_TF0A3A2CE215643EDF5BC6E278CE7E7578E38A18C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityCallFactory_InitState
struct  InitState_tF0A3A2CE215643EDF5BC6E278CE7E7578E38A18C 
{
public:
	// System.Int32 Byn.Awrtc.Unity.UnityCallFactory_InitState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(InitState_tF0A3A2CE215643EDF5BC6E278CE7E7578E38A18C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INITSTATE_TF0A3A2CE215643EDF5BC6E278CE7E7578E38A18C_H
#ifndef INITSTATUSUPDATE_T9CB7C4BBAF73AE515E423C78CBDE4AB3C0ED96AF_H
#define INITSTATUSUPDATE_T9CB7C4BBAF73AE515E423C78CBDE4AB3C0ED96AF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityCallFactory_InitStatusUpdate
struct  InitStatusUpdate_t9CB7C4BBAF73AE515E423C78CBDE4AB3C0ED96AF 
{
public:
	// System.Int32 Byn.Awrtc.Unity.UnityCallFactory_InitStatusUpdate::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(InitStatusUpdate_t9CB7C4BBAF73AE515E423C78CBDE4AB3C0ED96AF, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INITSTATUSUPDATE_T9CB7C4BBAF73AE515E423C78CBDE4AB3C0ED96AF_H
#ifndef LOGLEVEL_TEBEAF97CA6FC143AAFFCBF123E970D39D79AE144_H
#define LOGLEVEL_TEBEAF97CA6FC143AAFFCBF123E970D39D79AE144_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityCallFactory_LogLevel
struct  LogLevel_tEBEAF97CA6FC143AAFFCBF123E970D39D79AE144 
{
public:
	// System.Int32 Byn.Awrtc.Unity.UnityCallFactory_LogLevel::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(LogLevel_tEBEAF97CA6FC143AAFFCBF123E970D39D79AE144, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOGLEVEL_TEBEAF97CA6FC143AAFFCBF123E970D39D79AE144_H
#ifndef SIMPLECALLSTATE_T57C23CDEB50ACA1A8FEE6905D5B0B3DBEBA5493A_H
#define SIMPLECALLSTATE_T57C23CDEB50ACA1A8FEE6905D5B0B3DBEBA5493A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.SimpleCall_SimpleCallState
struct  SimpleCallState_t57C23CDEB50ACA1A8FEE6905D5B0B3DBEBA5493A 
{
public:
	// System.Int32 Byn.Unity.Examples.SimpleCall_SimpleCallState::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(SimpleCallState_t57C23CDEB50ACA1A8FEE6905D5B0B3DBEBA5493A, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SIMPLECALLSTATE_T57C23CDEB50ACA1A8FEE6905D5B0B3DBEBA5493A_H
#ifndef ROLE_TF3905ABBC3761D7A0769787409DF35B6C3EA615D_H
#define ROLE_TF3905ABBC3761D7A0769787409DF35B6C3EA615D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// InterProcessCommunicator_Role
struct  Role_tF3905ABBC3761D7A0769787409DF35B6C3EA615D 
{
public:
	// System.Int32 InterProcessCommunicator_Role::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Role_tF3905ABBC3761D7A0769787409DF35B6C3EA615D, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ROLE_TF3905ABBC3761D7A0769787409DF35B6C3EA615D_H
#ifndef BUTTONTYPE_TA98D458F69E8B2F1F49622D0A02EAF4909C77AC7_H
#define BUTTONTYPE_TA98D458F69E8B2F1F49622D0A02EAF4909C77AC7_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.ButtonType
struct  ButtonType_tA98D458F69E8B2F1F49622D0A02EAF4909C77AC7 
{
public:
	// System.Int32 LookingGlass.ButtonType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ButtonType_tA98D458F69E8B2F1F49622D0A02EAF4909C77AC7, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BUTTONTYPE_TA98D458F69E8B2F1F49622D0A02EAF4909C77AC7_H
#ifndef VIEWINTERPOLATIONTYPE_TFE84ADCF02AAD2929ED2BD7892982130EFD062DD_H
#define VIEWINTERPOLATIONTYPE_TFE84ADCF02AAD2929ED2BD7892982130EFD062DD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Holoplay_ViewInterpolationType
struct  ViewInterpolationType_tFE84ADCF02AAD2929ED2BD7892982130EFD062DD 
{
public:
	// System.Int32 LookingGlass.Holoplay_ViewInterpolationType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ViewInterpolationType_tFE84ADCF02AAD2929ED2BD7892982130EFD062DD, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIEWINTERPOLATIONTYPE_TFE84ADCF02AAD2929ED2BD7892982130EFD062DD_H
#ifndef VIEWRENDEREVENT_T8A52588044E632F42B64DC1EE219DC39E0DA957C_H
#define VIEWRENDEREVENT_T8A52588044E632F42B64DC1EE219DC39E0DA957C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Holoplay_ViewRenderEvent
struct  ViewRenderEvent_t8A52588044E632F42B64DC1EE219DC39E0DA957C  : public UnityEvent_2_t41702E3BA912BDFCAEF2171F44BD45CFE01C793A
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIEWRENDEREVENT_T8A52588044E632F42B64DC1EE219DC39E0DA957C_H
#ifndef LOADEVENT_TE7ACDCDE718293339A984D1E678134087257D727_H
#define LOADEVENT_TE7ACDCDE718293339A984D1E678134087257D727_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.LoadEvent
struct  LoadEvent_tE7ACDCDE718293339A984D1E678134087257D727  : public UnityEvent_1_tFA903A9843B19B1ABCA8061C5BEC94800BF1CD81
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOADEVENT_TE7ACDCDE718293339A984D1E678134087257D727_H
#ifndef DISPLAYPOSITIONER_T72462E5B3E20F9FCD1AA67B4CA8025EAB6D5C8CB_H
#define DISPLAYPOSITIONER_T72462E5B3E20F9FCD1AA67B4CA8025EAB6D5C8CB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Multiplex_DisplayPositioner
struct  DisplayPositioner_t72462E5B3E20F9FCD1AA67B4CA8025EAB6D5C8CB  : public RuntimeObject
{
public:
	// System.Int32 LookingGlass.Multiplex_DisplayPositioner::targetLKG
	int32_t ___targetLKG_0;
	// System.Int32 LookingGlass.Multiplex_DisplayPositioner::targetDisplay
	int32_t ___targetDisplay_1;
	// UnityEngine.Vector2Int LookingGlass.Multiplex_DisplayPositioner::position
	Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  ___position_2;

public:
	inline static int32_t get_offset_of_targetLKG_0() { return static_cast<int32_t>(offsetof(DisplayPositioner_t72462E5B3E20F9FCD1AA67B4CA8025EAB6D5C8CB, ___targetLKG_0)); }
	inline int32_t get_targetLKG_0() const { return ___targetLKG_0; }
	inline int32_t* get_address_of_targetLKG_0() { return &___targetLKG_0; }
	inline void set_targetLKG_0(int32_t value)
	{
		___targetLKG_0 = value;
	}

	inline static int32_t get_offset_of_targetDisplay_1() { return static_cast<int32_t>(offsetof(DisplayPositioner_t72462E5B3E20F9FCD1AA67B4CA8025EAB6D5C8CB, ___targetDisplay_1)); }
	inline int32_t get_targetDisplay_1() const { return ___targetDisplay_1; }
	inline int32_t* get_address_of_targetDisplay_1() { return &___targetDisplay_1; }
	inline void set_targetDisplay_1(int32_t value)
	{
		___targetDisplay_1 = value;
	}

	inline static int32_t get_offset_of_position_2() { return static_cast<int32_t>(offsetof(DisplayPositioner_t72462E5B3E20F9FCD1AA67B4CA8025EAB6D5C8CB, ___position_2)); }
	inline Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  get_position_2() const { return ___position_2; }
	inline Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905 * get_address_of_position_2() { return &___position_2; }
	inline void set_position_2(Vector2Int_t339DA203C037FA6BCFC926C36DC2194D52D5F905  value)
	{
		___position_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DISPLAYPOSITIONER_T72462E5B3E20F9FCD1AA67B4CA8025EAB6D5C8CB_H
#ifndef HPC_CLIENT_ERROR_T52A579A0931AFF4F1E3C8246418E37794C65DF98_H
#define HPC_CLIENT_ERROR_T52A579A0931AFF4F1E3C8246418E37794C65DF98_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.PluginCore_hpc_client_error
struct  hpc_client_error_t52A579A0931AFF4F1E3C8246418E37794C65DF98 
{
public:
	// System.Int32 LookingGlass.PluginCore_hpc_client_error::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(hpc_client_error_t52A579A0931AFF4F1E3C8246418E37794C65DF98, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HPC_CLIENT_ERROR_T52A579A0931AFF4F1E3C8246418E37794C65DF98_H
#ifndef HPC_LICENSE_TYPE_T94C2E00B85628AD601D0E63B6EB1EF2CAA54342C_H
#define HPC_LICENSE_TYPE_T94C2E00B85628AD601D0E63B6EB1EF2CAA54342C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.PluginCore_hpc_license_type
struct  hpc_license_type_t94C2E00B85628AD601D0E63B6EB1EF2CAA54342C 
{
public:
	// System.Int32 LookingGlass.PluginCore_hpc_license_type::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(hpc_license_type_t94C2E00B85628AD601D0E63B6EB1EF2CAA54342C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HPC_LICENSE_TYPE_T94C2E00B85628AD601D0E63B6EB1EF2CAA54342C_H
#ifndef PRESET_T27691E17FCF96CC5B8FEA0D1EE87E5ECAD724C86_H
#define PRESET_T27691E17FCF96CC5B8FEA0D1EE87E5ECAD724C86_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Quilt_Preset
struct  Preset_t27691E17FCF96CC5B8FEA0D1EE87E5ECAD724C86 
{
public:
	// System.Int32 LookingGlass.Quilt_Preset::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Preset_t27691E17FCF96CC5B8FEA0D1EE87E5ECAD724C86, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PRESET_T27691E17FCF96CC5B8FEA0D1EE87E5ECAD724C86_H
#ifndef DELEGATE_T_H
#define DELEGATE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Delegate
struct  Delegate_t  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::extra_arg
	intptr_t ___extra_arg_5;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_6;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_7;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_8;
	// System.DelegateData System.Delegate::data
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	// System.Boolean System.Delegate::method_is_virtual
	bool ___method_is_virtual_10;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t, ___invoke_impl_1)); }
	inline intptr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline intptr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(intptr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_target_2), value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_3)); }
	inline intptr_t get_method_3() const { return ___method_3; }
	inline intptr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(intptr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t, ___delegate_trampoline_4)); }
	inline intptr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline intptr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(intptr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_extra_arg_5() { return static_cast<int32_t>(offsetof(Delegate_t, ___extra_arg_5)); }
	inline intptr_t get_extra_arg_5() const { return ___extra_arg_5; }
	inline intptr_t* get_address_of_extra_arg_5() { return &___extra_arg_5; }
	inline void set_extra_arg_5(intptr_t value)
	{
		___extra_arg_5 = value;
	}

	inline static int32_t get_offset_of_method_code_6() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_code_6)); }
	inline intptr_t get_method_code_6() const { return ___method_code_6; }
	inline intptr_t* get_address_of_method_code_6() { return &___method_code_6; }
	inline void set_method_code_6(intptr_t value)
	{
		___method_code_6 = value;
	}

	inline static int32_t get_offset_of_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_info_7)); }
	inline MethodInfo_t * get_method_info_7() const { return ___method_info_7; }
	inline MethodInfo_t ** get_address_of_method_info_7() { return &___method_info_7; }
	inline void set_method_info_7(MethodInfo_t * value)
	{
		___method_info_7 = value;
		Il2CppCodeGenWriteBarrier((&___method_info_7), value);
	}

	inline static int32_t get_offset_of_original_method_info_8() { return static_cast<int32_t>(offsetof(Delegate_t, ___original_method_info_8)); }
	inline MethodInfo_t * get_original_method_info_8() const { return ___original_method_info_8; }
	inline MethodInfo_t ** get_address_of_original_method_info_8() { return &___original_method_info_8; }
	inline void set_original_method_info_8(MethodInfo_t * value)
	{
		___original_method_info_8 = value;
		Il2CppCodeGenWriteBarrier((&___original_method_info_8), value);
	}

	inline static int32_t get_offset_of_data_9() { return static_cast<int32_t>(offsetof(Delegate_t, ___data_9)); }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * get_data_9() const { return ___data_9; }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE ** get_address_of_data_9() { return &___data_9; }
	inline void set_data_9(DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * value)
	{
		___data_9 = value;
		Il2CppCodeGenWriteBarrier((&___data_9), value);
	}

	inline static int32_t get_offset_of_method_is_virtual_10() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_is_virtual_10)); }
	inline bool get_method_is_virtual_10() const { return ___method_is_virtual_10; }
	inline bool* get_address_of_method_is_virtual_10() { return &___method_is_virtual_10; }
	inline void set_method_is_virtual_10(bool value)
	{
		___method_is_virtual_10 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Delegate
struct Delegate_t_marshaled_pinvoke
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};
// Native definition for COM marshalling of System.Delegate
struct Delegate_t_marshaled_com
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};
#endif // DELEGATE_T_H
#ifndef CAMERACLEARFLAGS_TAC22BD22D12708CBDC63F6CFB31109E5E17CF239_H
#define CAMERACLEARFLAGS_TAC22BD22D12708CBDC63F6CFB31109E5E17CF239_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.CameraClearFlags
struct  CameraClearFlags_tAC22BD22D12708CBDC63F6CFB31109E5E17CF239 
{
public:
	// System.Int32 UnityEngine.CameraClearFlags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(CameraClearFlags_tAC22BD22D12708CBDC63F6CFB31109E5E17CF239, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CAMERACLEARFLAGS_TAC22BD22D12708CBDC63F6CFB31109E5E17CF239_H
#ifndef KEYCODE_TC93EA87C5A6901160B583ADFCD3EF6726570DC3C_H
#define KEYCODE_TC93EA87C5A6901160B583ADFCD3EF6726570DC3C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.KeyCode
struct  KeyCode_tC93EA87C5A6901160B583ADFCD3EF6726570DC3C 
{
public:
	// System.Int32 UnityEngine.KeyCode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(KeyCode_tC93EA87C5A6901160B583ADFCD3EF6726570DC3C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // KEYCODE_TC93EA87C5A6901160B583ADFCD3EF6726570DC3C_H
#ifndef OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#define OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Object
struct  Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};
#endif // OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#ifndef RAY_TE2163D4CB3E6B267E29F8ABE41684490E4A614B2_H
#define RAY_TE2163D4CB3E6B267E29F8ABE41684490E4A614B2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Ray
struct  Ray_tE2163D4CB3E6B267E29F8ABE41684490E4A614B2 
{
public:
	// UnityEngine.Vector3 UnityEngine.Ray::m_Origin
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___m_Origin_0;
	// UnityEngine.Vector3 UnityEngine.Ray::m_Direction
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___m_Direction_1;

public:
	inline static int32_t get_offset_of_m_Origin_0() { return static_cast<int32_t>(offsetof(Ray_tE2163D4CB3E6B267E29F8ABE41684490E4A614B2, ___m_Origin_0)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_m_Origin_0() const { return ___m_Origin_0; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_m_Origin_0() { return &___m_Origin_0; }
	inline void set_m_Origin_0(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___m_Origin_0 = value;
	}

	inline static int32_t get_offset_of_m_Direction_1() { return static_cast<int32_t>(offsetof(Ray_tE2163D4CB3E6B267E29F8ABE41684490E4A614B2, ___m_Direction_1)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_m_Direction_1() const { return ___m_Direction_1; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_m_Direction_1() { return &___m_Direction_1; }
	inline void set_m_Direction_1(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___m_Direction_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RAY_TE2163D4CB3E6B267E29F8ABE41684490E4A614B2_H
#ifndef RAYCASTHIT_T19695F18F9265FE5425062BBA6A4D330480538C3_H
#define RAYCASTHIT_T19695F18F9265FE5425062BBA6A4D330480538C3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RaycastHit
struct  RaycastHit_t19695F18F9265FE5425062BBA6A4D330480538C3 
{
public:
	// UnityEngine.Vector3 UnityEngine.RaycastHit::m_Point
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___m_Point_0;
	// UnityEngine.Vector3 UnityEngine.RaycastHit::m_Normal
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___m_Normal_1;
	// System.UInt32 UnityEngine.RaycastHit::m_FaceID
	uint32_t ___m_FaceID_2;
	// System.Single UnityEngine.RaycastHit::m_Distance
	float ___m_Distance_3;
	// UnityEngine.Vector2 UnityEngine.RaycastHit::m_UV
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_UV_4;
	// System.Int32 UnityEngine.RaycastHit::m_Collider
	int32_t ___m_Collider_5;

public:
	inline static int32_t get_offset_of_m_Point_0() { return static_cast<int32_t>(offsetof(RaycastHit_t19695F18F9265FE5425062BBA6A4D330480538C3, ___m_Point_0)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_m_Point_0() const { return ___m_Point_0; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_m_Point_0() { return &___m_Point_0; }
	inline void set_m_Point_0(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___m_Point_0 = value;
	}

	inline static int32_t get_offset_of_m_Normal_1() { return static_cast<int32_t>(offsetof(RaycastHit_t19695F18F9265FE5425062BBA6A4D330480538C3, ___m_Normal_1)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_m_Normal_1() const { return ___m_Normal_1; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_m_Normal_1() { return &___m_Normal_1; }
	inline void set_m_Normal_1(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___m_Normal_1 = value;
	}

	inline static int32_t get_offset_of_m_FaceID_2() { return static_cast<int32_t>(offsetof(RaycastHit_t19695F18F9265FE5425062BBA6A4D330480538C3, ___m_FaceID_2)); }
	inline uint32_t get_m_FaceID_2() const { return ___m_FaceID_2; }
	inline uint32_t* get_address_of_m_FaceID_2() { return &___m_FaceID_2; }
	inline void set_m_FaceID_2(uint32_t value)
	{
		___m_FaceID_2 = value;
	}

	inline static int32_t get_offset_of_m_Distance_3() { return static_cast<int32_t>(offsetof(RaycastHit_t19695F18F9265FE5425062BBA6A4D330480538C3, ___m_Distance_3)); }
	inline float get_m_Distance_3() const { return ___m_Distance_3; }
	inline float* get_address_of_m_Distance_3() { return &___m_Distance_3; }
	inline void set_m_Distance_3(float value)
	{
		___m_Distance_3 = value;
	}

	inline static int32_t get_offset_of_m_UV_4() { return static_cast<int32_t>(offsetof(RaycastHit_t19695F18F9265FE5425062BBA6A4D330480538C3, ___m_UV_4)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_UV_4() const { return ___m_UV_4; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_UV_4() { return &___m_UV_4; }
	inline void set_m_UV_4(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_UV_4 = value;
	}

	inline static int32_t get_offset_of_m_Collider_5() { return static_cast<int32_t>(offsetof(RaycastHit_t19695F18F9265FE5425062BBA6A4D330480538C3, ___m_Collider_5)); }
	inline int32_t get_m_Collider_5() const { return ___m_Collider_5; }
	inline int32_t* get_address_of_m_Collider_5() { return &___m_Collider_5; }
	inline void set_m_Collider_5(int32_t value)
	{
		___m_Collider_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RAYCASTHIT_T19695F18F9265FE5425062BBA6A4D330480538C3_H
#ifndef RAYCASTHIT2D_T5E8A7F96317BAF2033362FC780F4D72DC72764BE_H
#define RAYCASTHIT2D_T5E8A7F96317BAF2033362FC780F4D72DC72764BE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RaycastHit2D
struct  RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE 
{
public:
	// UnityEngine.Vector2 UnityEngine.RaycastHit2D::m_Centroid
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_Centroid_0;
	// UnityEngine.Vector2 UnityEngine.RaycastHit2D::m_Point
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_Point_1;
	// UnityEngine.Vector2 UnityEngine.RaycastHit2D::m_Normal
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_Normal_2;
	// System.Single UnityEngine.RaycastHit2D::m_Distance
	float ___m_Distance_3;
	// System.Single UnityEngine.RaycastHit2D::m_Fraction
	float ___m_Fraction_4;
	// System.Int32 UnityEngine.RaycastHit2D::m_Collider
	int32_t ___m_Collider_5;

public:
	inline static int32_t get_offset_of_m_Centroid_0() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Centroid_0)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_Centroid_0() const { return ___m_Centroid_0; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_Centroid_0() { return &___m_Centroid_0; }
	inline void set_m_Centroid_0(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_Centroid_0 = value;
	}

	inline static int32_t get_offset_of_m_Point_1() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Point_1)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_Point_1() const { return ___m_Point_1; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_Point_1() { return &___m_Point_1; }
	inline void set_m_Point_1(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_Point_1 = value;
	}

	inline static int32_t get_offset_of_m_Normal_2() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Normal_2)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_Normal_2() const { return ___m_Normal_2; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_Normal_2() { return &___m_Normal_2; }
	inline void set_m_Normal_2(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_Normal_2 = value;
	}

	inline static int32_t get_offset_of_m_Distance_3() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Distance_3)); }
	inline float get_m_Distance_3() const { return ___m_Distance_3; }
	inline float* get_address_of_m_Distance_3() { return &___m_Distance_3; }
	inline void set_m_Distance_3(float value)
	{
		___m_Distance_3 = value;
	}

	inline static int32_t get_offset_of_m_Fraction_4() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Fraction_4)); }
	inline float get_m_Fraction_4() const { return ___m_Fraction_4; }
	inline float* get_address_of_m_Fraction_4() { return &___m_Fraction_4; }
	inline void set_m_Fraction_4(float value)
	{
		___m_Fraction_4 = value;
	}

	inline static int32_t get_offset_of_m_Collider_5() { return static_cast<int32_t>(offsetof(RaycastHit2D_t5E8A7F96317BAF2033362FC780F4D72DC72764BE, ___m_Collider_5)); }
	inline int32_t get_m_Collider_5() const { return ___m_Collider_5; }
	inline int32_t* get_address_of_m_Collider_5() { return &___m_Collider_5; }
	inline void set_m_Collider_5(int32_t value)
	{
		___m_Collider_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RAYCASTHIT2D_T5E8A7F96317BAF2033362FC780F4D72DC72764BE_H
#ifndef RENDERINGPATH_T5E196960B7ECE9BA17943445415336FA4E19F82B_H
#define RENDERINGPATH_T5E196960B7ECE9BA17943445415336FA4E19F82B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RenderingPath
struct  RenderingPath_t5E196960B7ECE9BA17943445415336FA4E19F82B 
{
public:
	// System.Int32 UnityEngine.RenderingPath::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(RenderingPath_t5E196960B7ECE9BA17943445415336FA4E19F82B, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RENDERINGPATH_T5E196960B7ECE9BA17943445415336FA4E19F82B_H
#ifndef TEXTANCHOR_TEC19034D476659A5E05366C63564F34DD30E7C57_H
#define TEXTANCHOR_TEC19034D476659A5E05366C63564F34DD30E7C57_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.TextAnchor
struct  TextAnchor_tEC19034D476659A5E05366C63564F34DD30E7C57 
{
public:
	// System.Int32 UnityEngine.TextAnchor::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(TextAnchor_tEC19034D476659A5E05366C63564F34DD30E7C57, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TEXTANCHOR_TEC19034D476659A5E05366C63564F34DD30E7C57_H
#ifndef VERTEXHELPER_T27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_H
#define VERTEXHELPER_T27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.VertexHelper
struct  VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F  : public RuntimeObject
{
public:
	// System.Collections.Generic.List`1<UnityEngine.Vector3> UnityEngine.UI.VertexHelper::m_Positions
	List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5 * ___m_Positions_0;
	// System.Collections.Generic.List`1<UnityEngine.Color32> UnityEngine.UI.VertexHelper::m_Colors
	List_1_t749ADA5233D9B421293A000DCB83608A24C3D5D5 * ___m_Colors_1;
	// System.Collections.Generic.List`1<UnityEngine.Vector2> UnityEngine.UI.VertexHelper::m_Uv0S
	List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * ___m_Uv0S_2;
	// System.Collections.Generic.List`1<UnityEngine.Vector2> UnityEngine.UI.VertexHelper::m_Uv1S
	List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * ___m_Uv1S_3;
	// System.Collections.Generic.List`1<UnityEngine.Vector2> UnityEngine.UI.VertexHelper::m_Uv2S
	List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * ___m_Uv2S_4;
	// System.Collections.Generic.List`1<UnityEngine.Vector2> UnityEngine.UI.VertexHelper::m_Uv3S
	List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * ___m_Uv3S_5;
	// System.Collections.Generic.List`1<UnityEngine.Vector3> UnityEngine.UI.VertexHelper::m_Normals
	List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5 * ___m_Normals_6;
	// System.Collections.Generic.List`1<UnityEngine.Vector4> UnityEngine.UI.VertexHelper::m_Tangents
	List_1_tFF4005B40E5BA433006DA11C56DB086B1E2FC955 * ___m_Tangents_7;
	// System.Collections.Generic.List`1<System.Int32> UnityEngine.UI.VertexHelper::m_Indices
	List_1_tE1526161A558A17A39A8B69D8EEF3801393B6226 * ___m_Indices_8;
	// System.Boolean UnityEngine.UI.VertexHelper::m_ListsInitalized
	bool ___m_ListsInitalized_11;

public:
	inline static int32_t get_offset_of_m_Positions_0() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Positions_0)); }
	inline List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5 * get_m_Positions_0() const { return ___m_Positions_0; }
	inline List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5 ** get_address_of_m_Positions_0() { return &___m_Positions_0; }
	inline void set_m_Positions_0(List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5 * value)
	{
		___m_Positions_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_Positions_0), value);
	}

	inline static int32_t get_offset_of_m_Colors_1() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Colors_1)); }
	inline List_1_t749ADA5233D9B421293A000DCB83608A24C3D5D5 * get_m_Colors_1() const { return ___m_Colors_1; }
	inline List_1_t749ADA5233D9B421293A000DCB83608A24C3D5D5 ** get_address_of_m_Colors_1() { return &___m_Colors_1; }
	inline void set_m_Colors_1(List_1_t749ADA5233D9B421293A000DCB83608A24C3D5D5 * value)
	{
		___m_Colors_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_Colors_1), value);
	}

	inline static int32_t get_offset_of_m_Uv0S_2() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Uv0S_2)); }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * get_m_Uv0S_2() const { return ___m_Uv0S_2; }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB ** get_address_of_m_Uv0S_2() { return &___m_Uv0S_2; }
	inline void set_m_Uv0S_2(List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * value)
	{
		___m_Uv0S_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_Uv0S_2), value);
	}

	inline static int32_t get_offset_of_m_Uv1S_3() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Uv1S_3)); }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * get_m_Uv1S_3() const { return ___m_Uv1S_3; }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB ** get_address_of_m_Uv1S_3() { return &___m_Uv1S_3; }
	inline void set_m_Uv1S_3(List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * value)
	{
		___m_Uv1S_3 = value;
		Il2CppCodeGenWriteBarrier((&___m_Uv1S_3), value);
	}

	inline static int32_t get_offset_of_m_Uv2S_4() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Uv2S_4)); }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * get_m_Uv2S_4() const { return ___m_Uv2S_4; }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB ** get_address_of_m_Uv2S_4() { return &___m_Uv2S_4; }
	inline void set_m_Uv2S_4(List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * value)
	{
		___m_Uv2S_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_Uv2S_4), value);
	}

	inline static int32_t get_offset_of_m_Uv3S_5() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Uv3S_5)); }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * get_m_Uv3S_5() const { return ___m_Uv3S_5; }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB ** get_address_of_m_Uv3S_5() { return &___m_Uv3S_5; }
	inline void set_m_Uv3S_5(List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * value)
	{
		___m_Uv3S_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_Uv3S_5), value);
	}

	inline static int32_t get_offset_of_m_Normals_6() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Normals_6)); }
	inline List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5 * get_m_Normals_6() const { return ___m_Normals_6; }
	inline List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5 ** get_address_of_m_Normals_6() { return &___m_Normals_6; }
	inline void set_m_Normals_6(List_1_tFCCBEDAA56D8F7598520FB136A9F8D713033D6B5 * value)
	{
		___m_Normals_6 = value;
		Il2CppCodeGenWriteBarrier((&___m_Normals_6), value);
	}

	inline static int32_t get_offset_of_m_Tangents_7() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Tangents_7)); }
	inline List_1_tFF4005B40E5BA433006DA11C56DB086B1E2FC955 * get_m_Tangents_7() const { return ___m_Tangents_7; }
	inline List_1_tFF4005B40E5BA433006DA11C56DB086B1E2FC955 ** get_address_of_m_Tangents_7() { return &___m_Tangents_7; }
	inline void set_m_Tangents_7(List_1_tFF4005B40E5BA433006DA11C56DB086B1E2FC955 * value)
	{
		___m_Tangents_7 = value;
		Il2CppCodeGenWriteBarrier((&___m_Tangents_7), value);
	}

	inline static int32_t get_offset_of_m_Indices_8() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_Indices_8)); }
	inline List_1_tE1526161A558A17A39A8B69D8EEF3801393B6226 * get_m_Indices_8() const { return ___m_Indices_8; }
	inline List_1_tE1526161A558A17A39A8B69D8EEF3801393B6226 ** get_address_of_m_Indices_8() { return &___m_Indices_8; }
	inline void set_m_Indices_8(List_1_tE1526161A558A17A39A8B69D8EEF3801393B6226 * value)
	{
		___m_Indices_8 = value;
		Il2CppCodeGenWriteBarrier((&___m_Indices_8), value);
	}

	inline static int32_t get_offset_of_m_ListsInitalized_11() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F, ___m_ListsInitalized_11)); }
	inline bool get_m_ListsInitalized_11() const { return ___m_ListsInitalized_11; }
	inline bool* get_address_of_m_ListsInitalized_11() { return &___m_ListsInitalized_11; }
	inline void set_m_ListsInitalized_11(bool value)
	{
		___m_ListsInitalized_11 = value;
	}
};

struct VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_StaticFields
{
public:
	// UnityEngine.Vector4 UnityEngine.UI.VertexHelper::s_DefaultTangent
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___s_DefaultTangent_9;
	// UnityEngine.Vector3 UnityEngine.UI.VertexHelper::s_DefaultNormal
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___s_DefaultNormal_10;

public:
	inline static int32_t get_offset_of_s_DefaultTangent_9() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_StaticFields, ___s_DefaultTangent_9)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_s_DefaultTangent_9() const { return ___s_DefaultTangent_9; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_s_DefaultTangent_9() { return &___s_DefaultTangent_9; }
	inline void set_s_DefaultTangent_9(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___s_DefaultTangent_9 = value;
	}

	inline static int32_t get_offset_of_s_DefaultNormal_10() { return static_cast<int32_t>(offsetof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_StaticFields, ___s_DefaultNormal_10)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_s_DefaultNormal_10() const { return ___s_DefaultNormal_10; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_s_DefaultNormal_10() { return &___s_DefaultNormal_10; }
	inline void set_s_DefaultNormal_10(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___s_DefaultNormal_10 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VERTEXHELPER_T27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_H
#ifndef MULTICASTDELEGATE_T_H
#define MULTICASTDELEGATE_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.MulticastDelegate
struct  MulticastDelegate_t  : public Delegate_t
{
public:
	// System.Delegate[] System.MulticastDelegate::delegates
	DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* ___delegates_11;

public:
	inline static int32_t get_offset_of_delegates_11() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___delegates_11)); }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* get_delegates_11() const { return ___delegates_11; }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86** get_address_of_delegates_11() { return &___delegates_11; }
	inline void set_delegates_11(DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* value)
	{
		___delegates_11 = value;
		Il2CppCodeGenWriteBarrier((&___delegates_11), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_pinvoke : public Delegate_t_marshaled_pinvoke
{
	Delegate_t_marshaled_pinvoke** ___delegates_11;
};
// Native definition for COM marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_com : public Delegate_t_marshaled_com
{
	Delegate_t_marshaled_com** ___delegates_11;
};
#endif // MULTICASTDELEGATE_T_H
#ifndef COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#define COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Component
struct  Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#ifndef MESSAGERECEIVED_T8F3129EEA322B159C6FD7D6F55678D155E6A9A12_H
#define MESSAGERECEIVED_T8F3129EEA322B159C6FD7D6F55678D155E6A9A12_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// InterProcessCommunicator_MessageReceived
struct  MessageReceived_t8F3129EEA322B159C6FD7D6F55678D155E6A9A12  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MESSAGERECEIVED_T8F3129EEA322B159C6FD7D6F55678D155E6A9A12_H
#ifndef BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#define BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Behaviour
struct  Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8  : public Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#ifndef GETRAYINTERSECTIONALLCALLBACK_T68C2581CCF05E868297EBD3F3361274954845095_H
#define GETRAYINTERSECTIONALLCALLBACK_T68C2581CCF05E868297EBD3F3361274954845095_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.ReflectionMethodsCache_GetRayIntersectionAllCallback
struct  GetRayIntersectionAllCallback_t68C2581CCF05E868297EBD3F3361274954845095  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GETRAYINTERSECTIONALLCALLBACK_T68C2581CCF05E868297EBD3F3361274954845095_H
#ifndef GETRAYINTERSECTIONALLNONALLOCCALLBACK_TAD7508D45DB6679B6394983579AD18D967CC2AD4_H
#define GETRAYINTERSECTIONALLNONALLOCCALLBACK_TAD7508D45DB6679B6394983579AD18D967CC2AD4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.ReflectionMethodsCache_GetRayIntersectionAllNonAllocCallback
struct  GetRayIntersectionAllNonAllocCallback_tAD7508D45DB6679B6394983579AD18D967CC2AD4  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GETRAYINTERSECTIONALLNONALLOCCALLBACK_TAD7508D45DB6679B6394983579AD18D967CC2AD4_H
#ifndef GETRAYCASTNONALLOCCALLBACK_TC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D_H
#define GETRAYCASTNONALLOCCALLBACK_TC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.ReflectionMethodsCache_GetRaycastNonAllocCallback
struct  GetRaycastNonAllocCallback_tC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GETRAYCASTNONALLOCCALLBACK_TC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D_H
#ifndef RAYCAST2DCALLBACK_TE99ABF9ABC3A380677949E8C05A3E477889B82BE_H
#define RAYCAST2DCALLBACK_TE99ABF9ABC3A380677949E8C05A3E477889B82BE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.ReflectionMethodsCache_Raycast2DCallback
struct  Raycast2DCallback_tE99ABF9ABC3A380677949E8C05A3E477889B82BE  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RAYCAST2DCALLBACK_TE99ABF9ABC3A380677949E8C05A3E477889B82BE_H
#ifndef RAYCAST3DCALLBACK_T83483916473C9710AEDB316A65CBE62C58935C5F_H
#define RAYCAST3DCALLBACK_T83483916473C9710AEDB316A65CBE62C58935C5F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.ReflectionMethodsCache_Raycast3DCallback
struct  Raycast3DCallback_t83483916473C9710AEDB316A65CBE62C58935C5F  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RAYCAST3DCALLBACK_T83483916473C9710AEDB316A65CBE62C58935C5F_H
#ifndef RAYCASTALLCALLBACK_T751407A44270E02FAA43D0846A58EE6A8C4AE1CE_H
#define RAYCASTALLCALLBACK_T751407A44270E02FAA43D0846A58EE6A8C4AE1CE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.ReflectionMethodsCache_RaycastAllCallback
struct  RaycastAllCallback_t751407A44270E02FAA43D0846A58EE6A8C4AE1CE  : public MulticastDelegate_t
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RAYCASTALLCALLBACK_T751407A44270E02FAA43D0846A58EE6A8C4AE1CE_H
#ifndef MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#define MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.MonoBehaviour
struct  MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429  : public Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#ifndef UNITYCALLFACTORY_T8EDDA82C4443ADF36445011BE4CCD732000E06AB_H
#define UNITYCALLFACTORY_T8EDDA82C4443ADF36445011BE4CCD732000E06AB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Awrtc.Unity.UnityCallFactory
struct  UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Int32 Byn.Awrtc.Unity.UnityCallFactory::mAndroidPreviousAudioMode
	int32_t ___mAndroidPreviousAudioMode_10;
	// System.Int32 Byn.Awrtc.Unity.UnityCallFactory::mSleepTimeoutBackup
	int32_t ___mSleepTimeoutBackup_11;
	// System.Boolean Byn.Awrtc.Unity.UnityCallFactory::mHasActiveCall
	bool ___mHasActiveCall_12;
	// Byn.Awrtc.IAwrtcFactory Byn.Awrtc.Unity.UnityCallFactory::mFactory
	RuntimeObject* ___mFactory_19;

public:
	inline static int32_t get_offset_of_mAndroidPreviousAudioMode_10() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB, ___mAndroidPreviousAudioMode_10)); }
	inline int32_t get_mAndroidPreviousAudioMode_10() const { return ___mAndroidPreviousAudioMode_10; }
	inline int32_t* get_address_of_mAndroidPreviousAudioMode_10() { return &___mAndroidPreviousAudioMode_10; }
	inline void set_mAndroidPreviousAudioMode_10(int32_t value)
	{
		___mAndroidPreviousAudioMode_10 = value;
	}

	inline static int32_t get_offset_of_mSleepTimeoutBackup_11() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB, ___mSleepTimeoutBackup_11)); }
	inline int32_t get_mSleepTimeoutBackup_11() const { return ___mSleepTimeoutBackup_11; }
	inline int32_t* get_address_of_mSleepTimeoutBackup_11() { return &___mSleepTimeoutBackup_11; }
	inline void set_mSleepTimeoutBackup_11(int32_t value)
	{
		___mSleepTimeoutBackup_11 = value;
	}

	inline static int32_t get_offset_of_mHasActiveCall_12() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB, ___mHasActiveCall_12)); }
	inline bool get_mHasActiveCall_12() const { return ___mHasActiveCall_12; }
	inline bool* get_address_of_mHasActiveCall_12() { return &___mHasActiveCall_12; }
	inline void set_mHasActiveCall_12(bool value)
	{
		___mHasActiveCall_12 = value;
	}

	inline static int32_t get_offset_of_mFactory_19() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB, ___mFactory_19)); }
	inline RuntimeObject* get_mFactory_19() const { return ___mFactory_19; }
	inline RuntimeObject** get_address_of_mFactory_19() { return &___mFactory_19; }
	inline void set_mFactory_19(RuntimeObject* value)
	{
		___mFactory_19 = value;
		Il2CppCodeGenWriteBarrier((&___mFactory_19), value);
	}
};

struct UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields
{
public:
	// System.Boolean Byn.Awrtc.Unity.UnityCallFactory::ALLOW_SYNCHRONOUS_INIT
	bool ___ALLOW_SYNCHRONOUS_INIT_4;
	// System.Boolean Byn.Awrtc.Unity.UnityCallFactory::ANDROID_SET_COMMUNICATION_MODE
	bool ___ANDROID_SET_COMMUNICATION_MODE_5;
	// System.Boolean Byn.Awrtc.Unity.UnityCallFactory::ALLOW_UNCHECKED_REMOTE_CERTIFICATE
	bool ___ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6;
	// System.Boolean Byn.Awrtc.Unity.UnityCallFactory::KEEP_AWAKE
	bool ___KEEP_AWAKE_7;
	// Byn.Awrtc.Unity.UnityCallFactory_LogLevel Byn.Awrtc.Unity.UnityCallFactory::DEFAULT_LOG_LEVEL
	int32_t ___DEFAULT_LOG_LEVEL_8;
	// System.Boolean Byn.Awrtc.Unity.UnityCallFactory::NATIVE_VERBOSE_LOG
	bool ___NATIVE_VERBOSE_LOG_9;
	// Byn.Awrtc.Unity.UnityCallFactory_InitState Byn.Awrtc.Unity.UnityCallFactory::sInitState
	int32_t ___sInitState_13;
	// System.Collections.Generic.List`1<Byn.Awrtc.Unity.UnityCallFactory_InitCallbacks> Byn.Awrtc.Unity.UnityCallFactory::sInitCallbacks
	List_1_tA9DD76095D2B3253680DE30E64CB3A486DFBDAF7 * ___sInitCallbacks_14;
	// System.String Byn.Awrtc.Unity.UnityCallFactory::sInitFailedMessage
	String_t* ___sInitFailedMessage_15;
	// Byn.Awrtc.Unity.UnityCallFactory_LogLevel Byn.Awrtc.Unity.UnityCallFactory::sActiveLogLevel
	int32_t ___sActiveLogLevel_16;
	// System.String Byn.Awrtc.Unity.UnityCallFactory::LOG_PREFIX
	String_t* ___LOG_PREFIX_17;
	// Byn.Awrtc.Unity.UnityCallFactory Byn.Awrtc.Unity.UnityCallFactory::sInstance
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB * ___sInstance_18;

public:
	inline static int32_t get_offset_of_ALLOW_SYNCHRONOUS_INIT_4() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___ALLOW_SYNCHRONOUS_INIT_4)); }
	inline bool get_ALLOW_SYNCHRONOUS_INIT_4() const { return ___ALLOW_SYNCHRONOUS_INIT_4; }
	inline bool* get_address_of_ALLOW_SYNCHRONOUS_INIT_4() { return &___ALLOW_SYNCHRONOUS_INIT_4; }
	inline void set_ALLOW_SYNCHRONOUS_INIT_4(bool value)
	{
		___ALLOW_SYNCHRONOUS_INIT_4 = value;
	}

	inline static int32_t get_offset_of_ANDROID_SET_COMMUNICATION_MODE_5() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___ANDROID_SET_COMMUNICATION_MODE_5)); }
	inline bool get_ANDROID_SET_COMMUNICATION_MODE_5() const { return ___ANDROID_SET_COMMUNICATION_MODE_5; }
	inline bool* get_address_of_ANDROID_SET_COMMUNICATION_MODE_5() { return &___ANDROID_SET_COMMUNICATION_MODE_5; }
	inline void set_ANDROID_SET_COMMUNICATION_MODE_5(bool value)
	{
		___ANDROID_SET_COMMUNICATION_MODE_5 = value;
	}

	inline static int32_t get_offset_of_ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6)); }
	inline bool get_ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6() const { return ___ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6; }
	inline bool* get_address_of_ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6() { return &___ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6; }
	inline void set_ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6(bool value)
	{
		___ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6 = value;
	}

	inline static int32_t get_offset_of_KEEP_AWAKE_7() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___KEEP_AWAKE_7)); }
	inline bool get_KEEP_AWAKE_7() const { return ___KEEP_AWAKE_7; }
	inline bool* get_address_of_KEEP_AWAKE_7() { return &___KEEP_AWAKE_7; }
	inline void set_KEEP_AWAKE_7(bool value)
	{
		___KEEP_AWAKE_7 = value;
	}

	inline static int32_t get_offset_of_DEFAULT_LOG_LEVEL_8() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___DEFAULT_LOG_LEVEL_8)); }
	inline int32_t get_DEFAULT_LOG_LEVEL_8() const { return ___DEFAULT_LOG_LEVEL_8; }
	inline int32_t* get_address_of_DEFAULT_LOG_LEVEL_8() { return &___DEFAULT_LOG_LEVEL_8; }
	inline void set_DEFAULT_LOG_LEVEL_8(int32_t value)
	{
		___DEFAULT_LOG_LEVEL_8 = value;
	}

	inline static int32_t get_offset_of_NATIVE_VERBOSE_LOG_9() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___NATIVE_VERBOSE_LOG_9)); }
	inline bool get_NATIVE_VERBOSE_LOG_9() const { return ___NATIVE_VERBOSE_LOG_9; }
	inline bool* get_address_of_NATIVE_VERBOSE_LOG_9() { return &___NATIVE_VERBOSE_LOG_9; }
	inline void set_NATIVE_VERBOSE_LOG_9(bool value)
	{
		___NATIVE_VERBOSE_LOG_9 = value;
	}

	inline static int32_t get_offset_of_sInitState_13() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___sInitState_13)); }
	inline int32_t get_sInitState_13() const { return ___sInitState_13; }
	inline int32_t* get_address_of_sInitState_13() { return &___sInitState_13; }
	inline void set_sInitState_13(int32_t value)
	{
		___sInitState_13 = value;
	}

	inline static int32_t get_offset_of_sInitCallbacks_14() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___sInitCallbacks_14)); }
	inline List_1_tA9DD76095D2B3253680DE30E64CB3A486DFBDAF7 * get_sInitCallbacks_14() const { return ___sInitCallbacks_14; }
	inline List_1_tA9DD76095D2B3253680DE30E64CB3A486DFBDAF7 ** get_address_of_sInitCallbacks_14() { return &___sInitCallbacks_14; }
	inline void set_sInitCallbacks_14(List_1_tA9DD76095D2B3253680DE30E64CB3A486DFBDAF7 * value)
	{
		___sInitCallbacks_14 = value;
		Il2CppCodeGenWriteBarrier((&___sInitCallbacks_14), value);
	}

	inline static int32_t get_offset_of_sInitFailedMessage_15() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___sInitFailedMessage_15)); }
	inline String_t* get_sInitFailedMessage_15() const { return ___sInitFailedMessage_15; }
	inline String_t** get_address_of_sInitFailedMessage_15() { return &___sInitFailedMessage_15; }
	inline void set_sInitFailedMessage_15(String_t* value)
	{
		___sInitFailedMessage_15 = value;
		Il2CppCodeGenWriteBarrier((&___sInitFailedMessage_15), value);
	}

	inline static int32_t get_offset_of_sActiveLogLevel_16() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___sActiveLogLevel_16)); }
	inline int32_t get_sActiveLogLevel_16() const { return ___sActiveLogLevel_16; }
	inline int32_t* get_address_of_sActiveLogLevel_16() { return &___sActiveLogLevel_16; }
	inline void set_sActiveLogLevel_16(int32_t value)
	{
		___sActiveLogLevel_16 = value;
	}

	inline static int32_t get_offset_of_LOG_PREFIX_17() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___LOG_PREFIX_17)); }
	inline String_t* get_LOG_PREFIX_17() const { return ___LOG_PREFIX_17; }
	inline String_t** get_address_of_LOG_PREFIX_17() { return &___LOG_PREFIX_17; }
	inline void set_LOG_PREFIX_17(String_t* value)
	{
		___LOG_PREFIX_17 = value;
		Il2CppCodeGenWriteBarrier((&___LOG_PREFIX_17), value);
	}

	inline static int32_t get_offset_of_sInstance_18() { return static_cast<int32_t>(offsetof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields, ___sInstance_18)); }
	inline UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB * get_sInstance_18() const { return ___sInstance_18; }
	inline UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB ** get_address_of_sInstance_18() { return &___sInstance_18; }
	inline void set_sInstance_18(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB * value)
	{
		___sInstance_18 = value;
		Il2CppCodeGenWriteBarrier((&___sInstance_18), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNITYCALLFACTORY_T8EDDA82C4443ADF36445011BE4CCD732000E06AB_H
#ifndef CONFERENCEAPP_T0EFD286CF629E11657DF84B2F40D842EA3F74EBE_H
#define CONFERENCEAPP_T0EFD286CF629E11657DF84B2F40D842EA3F74EBE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.ConferenceApp
struct  ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.UI.InputField Byn.Unity.Examples.ConferenceApp::uRoomName
	InputField_t533609195B110760BCFF00B746C87D81969CB005 * ___uRoomName_5;
	// UnityEngine.UI.InputField Byn.Unity.Examples.ConferenceApp::uMessageField
	InputField_t533609195B110760BCFF00B746C87D81969CB005 * ___uMessageField_6;
	// MessageList Byn.Unity.Examples.ConferenceApp::uOutput
	MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC * ___uOutput_7;
	// UnityEngine.UI.Button Byn.Unity.Examples.ConferenceApp::uJoin
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uJoin_8;
	// UnityEngine.UI.Button Byn.Unity.Examples.ConferenceApp::uSend
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uSend_9;
	// UnityEngine.UI.Button Byn.Unity.Examples.ConferenceApp::uShutdown
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uShutdown_10;
	// UnityEngine.GameObject Byn.Unity.Examples.ConferenceApp::uSetupPanel
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___uSetupPanel_11;
	// UnityEngine.GameObject Byn.Unity.Examples.ConferenceApp::uVideoLayout
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___uVideoLayout_12;
	// UnityEngine.GameObject Byn.Unity.Examples.ConferenceApp::uVideoPrefab
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___uVideoPrefab_13;
	// UnityEngine.Texture2D Byn.Unity.Examples.ConferenceApp::uNoImgTexture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___uNoImgTexture_14;
	// Byn.Awrtc.ICall Byn.Unity.Examples.ConferenceApp::mCall
	RuntimeObject* ___mCall_15;
	// Byn.Awrtc.MediaConfig Byn.Unity.Examples.ConferenceApp::config
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___config_16;
	// System.Collections.Generic.Dictionary`2<Byn.Awrtc.ConnectionId,Byn.Unity.Examples.ConferenceApp_VideoData> Byn.Unity.Examples.ConferenceApp::mVideoUiElements
	Dictionary_2_t506AF32D1300A531CEAA46A92593E3079E4692F1 * ___mVideoUiElements_17;

public:
	inline static int32_t get_offset_of_uRoomName_5() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uRoomName_5)); }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 * get_uRoomName_5() const { return ___uRoomName_5; }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 ** get_address_of_uRoomName_5() { return &___uRoomName_5; }
	inline void set_uRoomName_5(InputField_t533609195B110760BCFF00B746C87D81969CB005 * value)
	{
		___uRoomName_5 = value;
		Il2CppCodeGenWriteBarrier((&___uRoomName_5), value);
	}

	inline static int32_t get_offset_of_uMessageField_6() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uMessageField_6)); }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 * get_uMessageField_6() const { return ___uMessageField_6; }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 ** get_address_of_uMessageField_6() { return &___uMessageField_6; }
	inline void set_uMessageField_6(InputField_t533609195B110760BCFF00B746C87D81969CB005 * value)
	{
		___uMessageField_6 = value;
		Il2CppCodeGenWriteBarrier((&___uMessageField_6), value);
	}

	inline static int32_t get_offset_of_uOutput_7() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uOutput_7)); }
	inline MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC * get_uOutput_7() const { return ___uOutput_7; }
	inline MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC ** get_address_of_uOutput_7() { return &___uOutput_7; }
	inline void set_uOutput_7(MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC * value)
	{
		___uOutput_7 = value;
		Il2CppCodeGenWriteBarrier((&___uOutput_7), value);
	}

	inline static int32_t get_offset_of_uJoin_8() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uJoin_8)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uJoin_8() const { return ___uJoin_8; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uJoin_8() { return &___uJoin_8; }
	inline void set_uJoin_8(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uJoin_8 = value;
		Il2CppCodeGenWriteBarrier((&___uJoin_8), value);
	}

	inline static int32_t get_offset_of_uSend_9() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uSend_9)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uSend_9() const { return ___uSend_9; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uSend_9() { return &___uSend_9; }
	inline void set_uSend_9(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uSend_9 = value;
		Il2CppCodeGenWriteBarrier((&___uSend_9), value);
	}

	inline static int32_t get_offset_of_uShutdown_10() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uShutdown_10)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uShutdown_10() const { return ___uShutdown_10; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uShutdown_10() { return &___uShutdown_10; }
	inline void set_uShutdown_10(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uShutdown_10 = value;
		Il2CppCodeGenWriteBarrier((&___uShutdown_10), value);
	}

	inline static int32_t get_offset_of_uSetupPanel_11() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uSetupPanel_11)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_uSetupPanel_11() const { return ___uSetupPanel_11; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_uSetupPanel_11() { return &___uSetupPanel_11; }
	inline void set_uSetupPanel_11(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___uSetupPanel_11 = value;
		Il2CppCodeGenWriteBarrier((&___uSetupPanel_11), value);
	}

	inline static int32_t get_offset_of_uVideoLayout_12() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uVideoLayout_12)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_uVideoLayout_12() const { return ___uVideoLayout_12; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_uVideoLayout_12() { return &___uVideoLayout_12; }
	inline void set_uVideoLayout_12(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___uVideoLayout_12 = value;
		Il2CppCodeGenWriteBarrier((&___uVideoLayout_12), value);
	}

	inline static int32_t get_offset_of_uVideoPrefab_13() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uVideoPrefab_13)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_uVideoPrefab_13() const { return ___uVideoPrefab_13; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_uVideoPrefab_13() { return &___uVideoPrefab_13; }
	inline void set_uVideoPrefab_13(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___uVideoPrefab_13 = value;
		Il2CppCodeGenWriteBarrier((&___uVideoPrefab_13), value);
	}

	inline static int32_t get_offset_of_uNoImgTexture_14() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___uNoImgTexture_14)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_uNoImgTexture_14() const { return ___uNoImgTexture_14; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_uNoImgTexture_14() { return &___uNoImgTexture_14; }
	inline void set_uNoImgTexture_14(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___uNoImgTexture_14 = value;
		Il2CppCodeGenWriteBarrier((&___uNoImgTexture_14), value);
	}

	inline static int32_t get_offset_of_mCall_15() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___mCall_15)); }
	inline RuntimeObject* get_mCall_15() const { return ___mCall_15; }
	inline RuntimeObject** get_address_of_mCall_15() { return &___mCall_15; }
	inline void set_mCall_15(RuntimeObject* value)
	{
		___mCall_15 = value;
		Il2CppCodeGenWriteBarrier((&___mCall_15), value);
	}

	inline static int32_t get_offset_of_config_16() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___config_16)); }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * get_config_16() const { return ___config_16; }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D ** get_address_of_config_16() { return &___config_16; }
	inline void set_config_16(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * value)
	{
		___config_16 = value;
		Il2CppCodeGenWriteBarrier((&___config_16), value);
	}

	inline static int32_t get_offset_of_mVideoUiElements_17() { return static_cast<int32_t>(offsetof(ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE, ___mVideoUiElements_17)); }
	inline Dictionary_2_t506AF32D1300A531CEAA46A92593E3079E4692F1 * get_mVideoUiElements_17() const { return ___mVideoUiElements_17; }
	inline Dictionary_2_t506AF32D1300A531CEAA46A92593E3079E4692F1 ** get_address_of_mVideoUiElements_17() { return &___mVideoUiElements_17; }
	inline void set_mVideoUiElements_17(Dictionary_2_t506AF32D1300A531CEAA46A92593E3079E4692F1 * value)
	{
		___mVideoUiElements_17 = value;
		Il2CppCodeGenWriteBarrier((&___mVideoUiElements_17), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CONFERENCEAPP_T0EFD286CF629E11657DF84B2F40D842EA3F74EBE_H
#ifndef MINIMALCALL_T1A616F4059C1AC885A34A5636B57E1687B1E9E73_H
#define MINIMALCALL_T1A616F4059C1AC885A34A5636B57E1687B1E9E73_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.MinimalCall
struct  MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// Byn.Awrtc.ICall Byn.Unity.Examples.MinimalCall::sender
	RuntimeObject* ___sender_4;
	// Byn.Awrtc.ICall Byn.Unity.Examples.MinimalCall::receiver
	RuntimeObject* ___receiver_5;
	// Byn.Awrtc.NetworkConfig Byn.Unity.Examples.MinimalCall::netConf
	NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * ___netConf_6;
	// System.String Byn.Unity.Examples.MinimalCall::address
	String_t* ___address_7;

public:
	inline static int32_t get_offset_of_sender_4() { return static_cast<int32_t>(offsetof(MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73, ___sender_4)); }
	inline RuntimeObject* get_sender_4() const { return ___sender_4; }
	inline RuntimeObject** get_address_of_sender_4() { return &___sender_4; }
	inline void set_sender_4(RuntimeObject* value)
	{
		___sender_4 = value;
		Il2CppCodeGenWriteBarrier((&___sender_4), value);
	}

	inline static int32_t get_offset_of_receiver_5() { return static_cast<int32_t>(offsetof(MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73, ___receiver_5)); }
	inline RuntimeObject* get_receiver_5() const { return ___receiver_5; }
	inline RuntimeObject** get_address_of_receiver_5() { return &___receiver_5; }
	inline void set_receiver_5(RuntimeObject* value)
	{
		___receiver_5 = value;
		Il2CppCodeGenWriteBarrier((&___receiver_5), value);
	}

	inline static int32_t get_offset_of_netConf_6() { return static_cast<int32_t>(offsetof(MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73, ___netConf_6)); }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * get_netConf_6() const { return ___netConf_6; }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 ** get_address_of_netConf_6() { return &___netConf_6; }
	inline void set_netConf_6(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * value)
	{
		___netConf_6 = value;
		Il2CppCodeGenWriteBarrier((&___netConf_6), value);
	}

	inline static int32_t get_offset_of_address_7() { return static_cast<int32_t>(offsetof(MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73, ___address_7)); }
	inline String_t* get_address_7() const { return ___address_7; }
	inline String_t** get_address_of_address_7() { return &___address_7; }
	inline void set_address_7(String_t* value)
	{
		___address_7 = value;
		Il2CppCodeGenWriteBarrier((&___address_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MINIMALCALL_T1A616F4059C1AC885A34A5636B57E1687B1E9E73_H
#ifndef MINIMALCONFERENCE_T9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3_H
#define MINIMALCONFERENCE_T9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.MinimalConference
struct  MinimalConference_t9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// Byn.Awrtc.ICall[] Byn.Unity.Examples.MinimalConference::calls
	ICallU5BU5D_t88E87BA53231880D2D4272EBF46A2A691ADA8741* ___calls_4;
	// Byn.Awrtc.NetworkConfig Byn.Unity.Examples.MinimalConference::netConf
	NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * ___netConf_5;
	// System.String Byn.Unity.Examples.MinimalConference::address
	String_t* ___address_6;

public:
	inline static int32_t get_offset_of_calls_4() { return static_cast<int32_t>(offsetof(MinimalConference_t9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3, ___calls_4)); }
	inline ICallU5BU5D_t88E87BA53231880D2D4272EBF46A2A691ADA8741* get_calls_4() const { return ___calls_4; }
	inline ICallU5BU5D_t88E87BA53231880D2D4272EBF46A2A691ADA8741** get_address_of_calls_4() { return &___calls_4; }
	inline void set_calls_4(ICallU5BU5D_t88E87BA53231880D2D4272EBF46A2A691ADA8741* value)
	{
		___calls_4 = value;
		Il2CppCodeGenWriteBarrier((&___calls_4), value);
	}

	inline static int32_t get_offset_of_netConf_5() { return static_cast<int32_t>(offsetof(MinimalConference_t9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3, ___netConf_5)); }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * get_netConf_5() const { return ___netConf_5; }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 ** get_address_of_netConf_5() { return &___netConf_5; }
	inline void set_netConf_5(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * value)
	{
		___netConf_5 = value;
		Il2CppCodeGenWriteBarrier((&___netConf_5), value);
	}

	inline static int32_t get_offset_of_address_6() { return static_cast<int32_t>(offsetof(MinimalConference_t9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3, ___address_6)); }
	inline String_t* get_address_6() const { return ___address_6; }
	inline String_t** get_address_of_address_6() { return &___address_6; }
	inline void set_address_6(String_t* value)
	{
		___address_6 = value;
		Il2CppCodeGenWriteBarrier((&___address_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MINIMALCONFERENCE_T9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3_H
#ifndef MINIMALMEDIANETWORK_T99B14410205FF74DEFEF6E056C1A045777B89FFF_H
#define MINIMALMEDIANETWORK_T99B14410205FF74DEFEF6E056C1A045777B89FFF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.MinimalMediaNetwork
struct  MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// Byn.Awrtc.IMediaNetwork Byn.Unity.Examples.MinimalMediaNetwork::sender
	RuntimeObject* ___sender_4;
	// System.Boolean Byn.Unity.Examples.MinimalMediaNetwork::mSenderConfigured
	bool ___mSenderConfigured_5;
	// Byn.Awrtc.IMediaNetwork Byn.Unity.Examples.MinimalMediaNetwork::receiver
	RuntimeObject* ___receiver_6;
	// System.Boolean Byn.Unity.Examples.MinimalMediaNetwork::mReceiverConfigured
	bool ___mReceiverConfigured_7;
	// Byn.Awrtc.NetworkConfig Byn.Unity.Examples.MinimalMediaNetwork::netConf
	NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * ___netConf_8;
	// System.String Byn.Unity.Examples.MinimalMediaNetwork::address
	String_t* ___address_9;

public:
	inline static int32_t get_offset_of_sender_4() { return static_cast<int32_t>(offsetof(MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF, ___sender_4)); }
	inline RuntimeObject* get_sender_4() const { return ___sender_4; }
	inline RuntimeObject** get_address_of_sender_4() { return &___sender_4; }
	inline void set_sender_4(RuntimeObject* value)
	{
		___sender_4 = value;
		Il2CppCodeGenWriteBarrier((&___sender_4), value);
	}

	inline static int32_t get_offset_of_mSenderConfigured_5() { return static_cast<int32_t>(offsetof(MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF, ___mSenderConfigured_5)); }
	inline bool get_mSenderConfigured_5() const { return ___mSenderConfigured_5; }
	inline bool* get_address_of_mSenderConfigured_5() { return &___mSenderConfigured_5; }
	inline void set_mSenderConfigured_5(bool value)
	{
		___mSenderConfigured_5 = value;
	}

	inline static int32_t get_offset_of_receiver_6() { return static_cast<int32_t>(offsetof(MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF, ___receiver_6)); }
	inline RuntimeObject* get_receiver_6() const { return ___receiver_6; }
	inline RuntimeObject** get_address_of_receiver_6() { return &___receiver_6; }
	inline void set_receiver_6(RuntimeObject* value)
	{
		___receiver_6 = value;
		Il2CppCodeGenWriteBarrier((&___receiver_6), value);
	}

	inline static int32_t get_offset_of_mReceiverConfigured_7() { return static_cast<int32_t>(offsetof(MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF, ___mReceiverConfigured_7)); }
	inline bool get_mReceiverConfigured_7() const { return ___mReceiverConfigured_7; }
	inline bool* get_address_of_mReceiverConfigured_7() { return &___mReceiverConfigured_7; }
	inline void set_mReceiverConfigured_7(bool value)
	{
		___mReceiverConfigured_7 = value;
	}

	inline static int32_t get_offset_of_netConf_8() { return static_cast<int32_t>(offsetof(MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF, ___netConf_8)); }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * get_netConf_8() const { return ___netConf_8; }
	inline NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 ** get_address_of_netConf_8() { return &___netConf_8; }
	inline void set_netConf_8(NetworkConfig_t91786901660F3E2FB39AA6F01F3F9295D0751A47 * value)
	{
		___netConf_8 = value;
		Il2CppCodeGenWriteBarrier((&___netConf_8), value);
	}

	inline static int32_t get_offset_of_address_9() { return static_cast<int32_t>(offsetof(MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF, ___address_9)); }
	inline String_t* get_address_9() const { return ___address_9; }
	inline String_t** get_address_of_address_9() { return &___address_9; }
	inline void set_address_9(String_t* value)
	{
		___address_9 = value;
		Il2CppCodeGenWriteBarrier((&___address_9), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MINIMALMEDIANETWORK_T99B14410205FF74DEFEF6E056C1A045777B89FFF_H
#ifndef ONETOMANY_TD2FD726816556B1F8CD9045B5FE9F44C4E00C086_H
#define ONETOMANY_TD2FD726816556B1F8CD9045B5FE9F44C4E00C086_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.OneToMany
struct  OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.String Byn.Unity.Examples.OneToMany::mSignalingServer
	String_t* ___mSignalingServer_4;
	// System.String Byn.Unity.Examples.OneToMany::mStunServer
	String_t* ___mStunServer_5;
	// Byn.Awrtc.IMediaNetwork Byn.Unity.Examples.OneToMany::mMediaNetwork
	RuntimeObject* ___mMediaNetwork_6;
	// Byn.Awrtc.MediaConfig Byn.Unity.Examples.OneToMany::mMediaConfig
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___mMediaConfig_7;
	// System.Int32 Byn.Unity.Examples.OneToMany::mIndex
	int32_t ___mIndex_9;
	// System.Boolean Byn.Unity.Examples.OneToMany::uSender
	bool ___uSender_10;
	// UnityEngine.UI.RawImage Byn.Unity.Examples.OneToMany::uVideoOutput
	RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * ___uVideoOutput_11;
	// UnityEngine.Texture2D Byn.Unity.Examples.OneToMany::mVideoTexture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___mVideoTexture_12;
	// System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId> Byn.Unity.Examples.OneToMany::mConnectionIds
	List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * ___mConnectionIds_14;

public:
	inline static int32_t get_offset_of_mSignalingServer_4() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___mSignalingServer_4)); }
	inline String_t* get_mSignalingServer_4() const { return ___mSignalingServer_4; }
	inline String_t** get_address_of_mSignalingServer_4() { return &___mSignalingServer_4; }
	inline void set_mSignalingServer_4(String_t* value)
	{
		___mSignalingServer_4 = value;
		Il2CppCodeGenWriteBarrier((&___mSignalingServer_4), value);
	}

	inline static int32_t get_offset_of_mStunServer_5() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___mStunServer_5)); }
	inline String_t* get_mStunServer_5() const { return ___mStunServer_5; }
	inline String_t** get_address_of_mStunServer_5() { return &___mStunServer_5; }
	inline void set_mStunServer_5(String_t* value)
	{
		___mStunServer_5 = value;
		Il2CppCodeGenWriteBarrier((&___mStunServer_5), value);
	}

	inline static int32_t get_offset_of_mMediaNetwork_6() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___mMediaNetwork_6)); }
	inline RuntimeObject* get_mMediaNetwork_6() const { return ___mMediaNetwork_6; }
	inline RuntimeObject** get_address_of_mMediaNetwork_6() { return &___mMediaNetwork_6; }
	inline void set_mMediaNetwork_6(RuntimeObject* value)
	{
		___mMediaNetwork_6 = value;
		Il2CppCodeGenWriteBarrier((&___mMediaNetwork_6), value);
	}

	inline static int32_t get_offset_of_mMediaConfig_7() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___mMediaConfig_7)); }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * get_mMediaConfig_7() const { return ___mMediaConfig_7; }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D ** get_address_of_mMediaConfig_7() { return &___mMediaConfig_7; }
	inline void set_mMediaConfig_7(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * value)
	{
		___mMediaConfig_7 = value;
		Il2CppCodeGenWriteBarrier((&___mMediaConfig_7), value);
	}

	inline static int32_t get_offset_of_mIndex_9() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___mIndex_9)); }
	inline int32_t get_mIndex_9() const { return ___mIndex_9; }
	inline int32_t* get_address_of_mIndex_9() { return &___mIndex_9; }
	inline void set_mIndex_9(int32_t value)
	{
		___mIndex_9 = value;
	}

	inline static int32_t get_offset_of_uSender_10() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___uSender_10)); }
	inline bool get_uSender_10() const { return ___uSender_10; }
	inline bool* get_address_of_uSender_10() { return &___uSender_10; }
	inline void set_uSender_10(bool value)
	{
		___uSender_10 = value;
	}

	inline static int32_t get_offset_of_uVideoOutput_11() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___uVideoOutput_11)); }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * get_uVideoOutput_11() const { return ___uVideoOutput_11; }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 ** get_address_of_uVideoOutput_11() { return &___uVideoOutput_11; }
	inline void set_uVideoOutput_11(RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * value)
	{
		___uVideoOutput_11 = value;
		Il2CppCodeGenWriteBarrier((&___uVideoOutput_11), value);
	}

	inline static int32_t get_offset_of_mVideoTexture_12() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___mVideoTexture_12)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_mVideoTexture_12() const { return ___mVideoTexture_12; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_mVideoTexture_12() { return &___mVideoTexture_12; }
	inline void set_mVideoTexture_12(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___mVideoTexture_12 = value;
		Il2CppCodeGenWriteBarrier((&___mVideoTexture_12), value);
	}

	inline static int32_t get_offset_of_mConnectionIds_14() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086, ___mConnectionIds_14)); }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * get_mConnectionIds_14() const { return ___mConnectionIds_14; }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 ** get_address_of_mConnectionIds_14() { return &___mConnectionIds_14; }
	inline void set_mConnectionIds_14(List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * value)
	{
		___mConnectionIds_14 = value;
		Il2CppCodeGenWriteBarrier((&___mConnectionIds_14), value);
	}
};

struct OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086_StaticFields
{
public:
	// System.Int32 Byn.Unity.Examples.OneToMany::sInstances
	int32_t ___sInstances_8;
	// System.String Byn.Unity.Examples.OneToMany::sAddress
	String_t* ___sAddress_13;

public:
	inline static int32_t get_offset_of_sInstances_8() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086_StaticFields, ___sInstances_8)); }
	inline int32_t get_sInstances_8() const { return ___sInstances_8; }
	inline int32_t* get_address_of_sInstances_8() { return &___sInstances_8; }
	inline void set_sInstances_8(int32_t value)
	{
		___sInstances_8 = value;
	}

	inline static int32_t get_offset_of_sAddress_13() { return static_cast<int32_t>(offsetof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086_StaticFields, ___sAddress_13)); }
	inline String_t* get_sAddress_13() const { return ___sAddress_13; }
	inline String_t** get_address_of_sAddress_13() { return &___sAddress_13; }
	inline void set_sAddress_13(String_t* value)
	{
		___sAddress_13 = value;
		Il2CppCodeGenWriteBarrier((&___sAddress_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ONETOMANY_TD2FD726816556B1F8CD9045B5FE9F44C4E00C086_H
#ifndef SIMPLECALL_TAC3DAAD0B3C5CACD29E70007F210F6E373A179AD_H
#define SIMPLECALL_TAC3DAAD0B3C5CACD29E70007F210F6E373A179AD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.SimpleCall
struct  SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Boolean Byn.Unity.Examples.SimpleCall::_Sender
	bool ____Sender_4;
	// UnityEngine.UI.RawImage Byn.Unity.Examples.SimpleCall::_LocalImage
	RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * ____LocalImage_5;
	// UnityEngine.UI.RawImage Byn.Unity.Examples.SimpleCall::_RemoteImage
	RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * ____RemoteImage_6;
	// System.Boolean Byn.Unity.Examples.SimpleCall::_TryI420
	bool ____TryI420_7;
	// Byn.Unity.Examples.SimpleCall_SimpleCallState Byn.Unity.Examples.SimpleCall::mState
	int32_t ___mState_8;
	// Byn.Awrtc.ICall Byn.Unity.Examples.SimpleCall::mCall
	RuntimeObject* ___mCall_9;

public:
	inline static int32_t get_offset_of__Sender_4() { return static_cast<int32_t>(offsetof(SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD, ____Sender_4)); }
	inline bool get__Sender_4() const { return ____Sender_4; }
	inline bool* get_address_of__Sender_4() { return &____Sender_4; }
	inline void set__Sender_4(bool value)
	{
		____Sender_4 = value;
	}

	inline static int32_t get_offset_of__LocalImage_5() { return static_cast<int32_t>(offsetof(SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD, ____LocalImage_5)); }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * get__LocalImage_5() const { return ____LocalImage_5; }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 ** get_address_of__LocalImage_5() { return &____LocalImage_5; }
	inline void set__LocalImage_5(RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * value)
	{
		____LocalImage_5 = value;
		Il2CppCodeGenWriteBarrier((&____LocalImage_5), value);
	}

	inline static int32_t get_offset_of__RemoteImage_6() { return static_cast<int32_t>(offsetof(SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD, ____RemoteImage_6)); }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * get__RemoteImage_6() const { return ____RemoteImage_6; }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 ** get_address_of__RemoteImage_6() { return &____RemoteImage_6; }
	inline void set__RemoteImage_6(RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * value)
	{
		____RemoteImage_6 = value;
		Il2CppCodeGenWriteBarrier((&____RemoteImage_6), value);
	}

	inline static int32_t get_offset_of__TryI420_7() { return static_cast<int32_t>(offsetof(SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD, ____TryI420_7)); }
	inline bool get__TryI420_7() const { return ____TryI420_7; }
	inline bool* get_address_of__TryI420_7() { return &____TryI420_7; }
	inline void set__TryI420_7(bool value)
	{
		____TryI420_7 = value;
	}

	inline static int32_t get_offset_of_mState_8() { return static_cast<int32_t>(offsetof(SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD, ___mState_8)); }
	inline int32_t get_mState_8() const { return ___mState_8; }
	inline int32_t* get_address_of_mState_8() { return &___mState_8; }
	inline void set_mState_8(int32_t value)
	{
		___mState_8 = value;
	}

	inline static int32_t get_offset_of_mCall_9() { return static_cast<int32_t>(offsetof(SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD, ___mCall_9)); }
	inline RuntimeObject* get_mCall_9() const { return ___mCall_9; }
	inline RuntimeObject** get_address_of_mCall_9() { return &___mCall_9; }
	inline void set_mCall_9(RuntimeObject* value)
	{
		___mCall_9 = value;
		Il2CppCodeGenWriteBarrier((&___mCall_9), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SIMPLECALL_TAC3DAAD0B3C5CACD29E70007F210F6E373A179AD_H
#ifndef VIRTUALCAMERA_T3480DEF62386D17D6EC2771DED373229F30D4175_H
#define VIRTUALCAMERA_T3480DEF62386D17D6EC2771DED373229F30D4175_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.VirtualCamera
struct  VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Camera Byn.Unity.Examples.VirtualCamera::_Camera
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ____Camera_4;
	// System.Single Byn.Unity.Examples.VirtualCamera::mLastSample
	float ___mLastSample_5;
	// UnityEngine.Texture2D Byn.Unity.Examples.VirtualCamera::mTexture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___mTexture_6;
	// UnityEngine.RenderTexture Byn.Unity.Examples.VirtualCamera::mRtBuffer
	RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * ___mRtBuffer_7;
	// UnityEngine.UI.RawImage Byn.Unity.Examples.VirtualCamera::_DebugTarget
	RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * ____DebugTarget_8;
	// System.String Byn.Unity.Examples.VirtualCamera::_DeviceName
	String_t* ____DeviceName_9;
	// System.Int32 Byn.Unity.Examples.VirtualCamera::_Fps
	int32_t ____Fps_10;
	// System.Int32 Byn.Unity.Examples.VirtualCamera::_Width
	int32_t ____Width_11;
	// System.Int32 Byn.Unity.Examples.VirtualCamera::_Height
	int32_t ____Height_12;
	// System.String Byn.Unity.Examples.VirtualCamera::mUsedDeviceName
	String_t* ___mUsedDeviceName_13;
	// System.Byte[] Byn.Unity.Examples.VirtualCamera::mByteBuffer
	ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* ___mByteBuffer_14;
	// Byn.Awrtc.Native.NativeVideoInput Byn.Unity.Examples.VirtualCamera::mVideoInput
	NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C * ___mVideoInput_15;

public:
	inline static int32_t get_offset_of__Camera_4() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ____Camera_4)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get__Camera_4() const { return ____Camera_4; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of__Camera_4() { return &____Camera_4; }
	inline void set__Camera_4(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		____Camera_4 = value;
		Il2CppCodeGenWriteBarrier((&____Camera_4), value);
	}

	inline static int32_t get_offset_of_mLastSample_5() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ___mLastSample_5)); }
	inline float get_mLastSample_5() const { return ___mLastSample_5; }
	inline float* get_address_of_mLastSample_5() { return &___mLastSample_5; }
	inline void set_mLastSample_5(float value)
	{
		___mLastSample_5 = value;
	}

	inline static int32_t get_offset_of_mTexture_6() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ___mTexture_6)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_mTexture_6() const { return ___mTexture_6; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_mTexture_6() { return &___mTexture_6; }
	inline void set_mTexture_6(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___mTexture_6 = value;
		Il2CppCodeGenWriteBarrier((&___mTexture_6), value);
	}

	inline static int32_t get_offset_of_mRtBuffer_7() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ___mRtBuffer_7)); }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * get_mRtBuffer_7() const { return ___mRtBuffer_7; }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 ** get_address_of_mRtBuffer_7() { return &___mRtBuffer_7; }
	inline void set_mRtBuffer_7(RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * value)
	{
		___mRtBuffer_7 = value;
		Il2CppCodeGenWriteBarrier((&___mRtBuffer_7), value);
	}

	inline static int32_t get_offset_of__DebugTarget_8() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ____DebugTarget_8)); }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * get__DebugTarget_8() const { return ____DebugTarget_8; }
	inline RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 ** get_address_of__DebugTarget_8() { return &____DebugTarget_8; }
	inline void set__DebugTarget_8(RawImage_t68991514DB8F48442D614E7904A298C936B3C7C8 * value)
	{
		____DebugTarget_8 = value;
		Il2CppCodeGenWriteBarrier((&____DebugTarget_8), value);
	}

	inline static int32_t get_offset_of__DeviceName_9() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ____DeviceName_9)); }
	inline String_t* get__DeviceName_9() const { return ____DeviceName_9; }
	inline String_t** get_address_of__DeviceName_9() { return &____DeviceName_9; }
	inline void set__DeviceName_9(String_t* value)
	{
		____DeviceName_9 = value;
		Il2CppCodeGenWriteBarrier((&____DeviceName_9), value);
	}

	inline static int32_t get_offset_of__Fps_10() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ____Fps_10)); }
	inline int32_t get__Fps_10() const { return ____Fps_10; }
	inline int32_t* get_address_of__Fps_10() { return &____Fps_10; }
	inline void set__Fps_10(int32_t value)
	{
		____Fps_10 = value;
	}

	inline static int32_t get_offset_of__Width_11() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ____Width_11)); }
	inline int32_t get__Width_11() const { return ____Width_11; }
	inline int32_t* get_address_of__Width_11() { return &____Width_11; }
	inline void set__Width_11(int32_t value)
	{
		____Width_11 = value;
	}

	inline static int32_t get_offset_of__Height_12() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ____Height_12)); }
	inline int32_t get__Height_12() const { return ____Height_12; }
	inline int32_t* get_address_of__Height_12() { return &____Height_12; }
	inline void set__Height_12(int32_t value)
	{
		____Height_12 = value;
	}

	inline static int32_t get_offset_of_mUsedDeviceName_13() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ___mUsedDeviceName_13)); }
	inline String_t* get_mUsedDeviceName_13() const { return ___mUsedDeviceName_13; }
	inline String_t** get_address_of_mUsedDeviceName_13() { return &___mUsedDeviceName_13; }
	inline void set_mUsedDeviceName_13(String_t* value)
	{
		___mUsedDeviceName_13 = value;
		Il2CppCodeGenWriteBarrier((&___mUsedDeviceName_13), value);
	}

	inline static int32_t get_offset_of_mByteBuffer_14() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ___mByteBuffer_14)); }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* get_mByteBuffer_14() const { return ___mByteBuffer_14; }
	inline ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821** get_address_of_mByteBuffer_14() { return &___mByteBuffer_14; }
	inline void set_mByteBuffer_14(ByteU5BU5D_tD06FDBE8142446525DF1C40351D523A228373821* value)
	{
		___mByteBuffer_14 = value;
		Il2CppCodeGenWriteBarrier((&___mByteBuffer_14), value);
	}

	inline static int32_t get_offset_of_mVideoInput_15() { return static_cast<int32_t>(offsetof(VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175, ___mVideoInput_15)); }
	inline NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C * get_mVideoInput_15() const { return ___mVideoInput_15; }
	inline NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C ** get_address_of_mVideoInput_15() { return &___mVideoInput_15; }
	inline void set_mVideoInput_15(NativeVideoInput_tED1E44C6598D8C56781E19484E523B74C654315C * value)
	{
		___mVideoInput_15 = value;
		Il2CppCodeGenWriteBarrier((&___mVideoInput_15), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIRTUALCAMERA_T3480DEF62386D17D6EC2771DED373229F30D4175_H
#ifndef CALLAPP_T4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43_H
#define CALLAPP_T4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// CallApp
struct  CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.String CallApp::uSignalingUrl
	String_t* ___uSignalingUrl_4;
	// System.String CallApp::uSecureSignalingUrl
	String_t* ___uSecureSignalingUrl_5;
	// System.Boolean CallApp::uForceSecureSignaling
	bool ___uForceSecureSignaling_6;
	// System.String CallApp::uIceServer
	String_t* ___uIceServer_7;
	// System.String CallApp::uIceServerUser
	String_t* ___uIceServerUser_8;
	// System.String CallApp::uIceServerPassword
	String_t* ___uIceServerPassword_9;
	// System.String CallApp::uIceServer2
	String_t* ___uIceServer2_10;
	// Byn.Awrtc.ICall CallApp::mCall
	RuntimeObject* ___mCall_12;
	// CallAppUi CallApp::mUi
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * ___mUi_13;
	// Byn.Awrtc.MediaConfig CallApp::mMediaConfig
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___mMediaConfig_14;
	// System.Boolean CallApp::mCallActive
	bool ___mCallActive_15;
	// System.String CallApp::mUseAddress
	String_t* ___mUseAddress_16;
	// Byn.Awrtc.MediaConfig CallApp::mMediaConfigInUse
	MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * ___mMediaConfigInUse_17;
	// Byn.Awrtc.ConnectionId CallApp::mRemoteUserId
	ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  ___mRemoteUserId_18;
	// System.Boolean CallApp::mAutoRejoin
	bool ___mAutoRejoin_19;
	// System.Single CallApp::mRejoinTime
	float ___mRejoinTime_20;
	// System.Boolean CallApp::mLocalFrameEvents
	bool ___mLocalFrameEvents_21;

public:
	inline static int32_t get_offset_of_uSignalingUrl_4() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___uSignalingUrl_4)); }
	inline String_t* get_uSignalingUrl_4() const { return ___uSignalingUrl_4; }
	inline String_t** get_address_of_uSignalingUrl_4() { return &___uSignalingUrl_4; }
	inline void set_uSignalingUrl_4(String_t* value)
	{
		___uSignalingUrl_4 = value;
		Il2CppCodeGenWriteBarrier((&___uSignalingUrl_4), value);
	}

	inline static int32_t get_offset_of_uSecureSignalingUrl_5() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___uSecureSignalingUrl_5)); }
	inline String_t* get_uSecureSignalingUrl_5() const { return ___uSecureSignalingUrl_5; }
	inline String_t** get_address_of_uSecureSignalingUrl_5() { return &___uSecureSignalingUrl_5; }
	inline void set_uSecureSignalingUrl_5(String_t* value)
	{
		___uSecureSignalingUrl_5 = value;
		Il2CppCodeGenWriteBarrier((&___uSecureSignalingUrl_5), value);
	}

	inline static int32_t get_offset_of_uForceSecureSignaling_6() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___uForceSecureSignaling_6)); }
	inline bool get_uForceSecureSignaling_6() const { return ___uForceSecureSignaling_6; }
	inline bool* get_address_of_uForceSecureSignaling_6() { return &___uForceSecureSignaling_6; }
	inline void set_uForceSecureSignaling_6(bool value)
	{
		___uForceSecureSignaling_6 = value;
	}

	inline static int32_t get_offset_of_uIceServer_7() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___uIceServer_7)); }
	inline String_t* get_uIceServer_7() const { return ___uIceServer_7; }
	inline String_t** get_address_of_uIceServer_7() { return &___uIceServer_7; }
	inline void set_uIceServer_7(String_t* value)
	{
		___uIceServer_7 = value;
		Il2CppCodeGenWriteBarrier((&___uIceServer_7), value);
	}

	inline static int32_t get_offset_of_uIceServerUser_8() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___uIceServerUser_8)); }
	inline String_t* get_uIceServerUser_8() const { return ___uIceServerUser_8; }
	inline String_t** get_address_of_uIceServerUser_8() { return &___uIceServerUser_8; }
	inline void set_uIceServerUser_8(String_t* value)
	{
		___uIceServerUser_8 = value;
		Il2CppCodeGenWriteBarrier((&___uIceServerUser_8), value);
	}

	inline static int32_t get_offset_of_uIceServerPassword_9() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___uIceServerPassword_9)); }
	inline String_t* get_uIceServerPassword_9() const { return ___uIceServerPassword_9; }
	inline String_t** get_address_of_uIceServerPassword_9() { return &___uIceServerPassword_9; }
	inline void set_uIceServerPassword_9(String_t* value)
	{
		___uIceServerPassword_9 = value;
		Il2CppCodeGenWriteBarrier((&___uIceServerPassword_9), value);
	}

	inline static int32_t get_offset_of_uIceServer2_10() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___uIceServer2_10)); }
	inline String_t* get_uIceServer2_10() const { return ___uIceServer2_10; }
	inline String_t** get_address_of_uIceServer2_10() { return &___uIceServer2_10; }
	inline void set_uIceServer2_10(String_t* value)
	{
		___uIceServer2_10 = value;
		Il2CppCodeGenWriteBarrier((&___uIceServer2_10), value);
	}

	inline static int32_t get_offset_of_mCall_12() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mCall_12)); }
	inline RuntimeObject* get_mCall_12() const { return ___mCall_12; }
	inline RuntimeObject** get_address_of_mCall_12() { return &___mCall_12; }
	inline void set_mCall_12(RuntimeObject* value)
	{
		___mCall_12 = value;
		Il2CppCodeGenWriteBarrier((&___mCall_12), value);
	}

	inline static int32_t get_offset_of_mUi_13() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mUi_13)); }
	inline CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * get_mUi_13() const { return ___mUi_13; }
	inline CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 ** get_address_of_mUi_13() { return &___mUi_13; }
	inline void set_mUi_13(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * value)
	{
		___mUi_13 = value;
		Il2CppCodeGenWriteBarrier((&___mUi_13), value);
	}

	inline static int32_t get_offset_of_mMediaConfig_14() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mMediaConfig_14)); }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * get_mMediaConfig_14() const { return ___mMediaConfig_14; }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D ** get_address_of_mMediaConfig_14() { return &___mMediaConfig_14; }
	inline void set_mMediaConfig_14(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * value)
	{
		___mMediaConfig_14 = value;
		Il2CppCodeGenWriteBarrier((&___mMediaConfig_14), value);
	}

	inline static int32_t get_offset_of_mCallActive_15() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mCallActive_15)); }
	inline bool get_mCallActive_15() const { return ___mCallActive_15; }
	inline bool* get_address_of_mCallActive_15() { return &___mCallActive_15; }
	inline void set_mCallActive_15(bool value)
	{
		___mCallActive_15 = value;
	}

	inline static int32_t get_offset_of_mUseAddress_16() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mUseAddress_16)); }
	inline String_t* get_mUseAddress_16() const { return ___mUseAddress_16; }
	inline String_t** get_address_of_mUseAddress_16() { return &___mUseAddress_16; }
	inline void set_mUseAddress_16(String_t* value)
	{
		___mUseAddress_16 = value;
		Il2CppCodeGenWriteBarrier((&___mUseAddress_16), value);
	}

	inline static int32_t get_offset_of_mMediaConfigInUse_17() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mMediaConfigInUse_17)); }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * get_mMediaConfigInUse_17() const { return ___mMediaConfigInUse_17; }
	inline MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D ** get_address_of_mMediaConfigInUse_17() { return &___mMediaConfigInUse_17; }
	inline void set_mMediaConfigInUse_17(MediaConfig_t27C1D9728366F53BC7E49A1E16B020363B3A304D * value)
	{
		___mMediaConfigInUse_17 = value;
		Il2CppCodeGenWriteBarrier((&___mMediaConfigInUse_17), value);
	}

	inline static int32_t get_offset_of_mRemoteUserId_18() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mRemoteUserId_18)); }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  get_mRemoteUserId_18() const { return ___mRemoteUserId_18; }
	inline ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D * get_address_of_mRemoteUserId_18() { return &___mRemoteUserId_18; }
	inline void set_mRemoteUserId_18(ConnectionId_t47DBB761AF0DB1559EACE774B317DA2B8B67F66D  value)
	{
		___mRemoteUserId_18 = value;
	}

	inline static int32_t get_offset_of_mAutoRejoin_19() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mAutoRejoin_19)); }
	inline bool get_mAutoRejoin_19() const { return ___mAutoRejoin_19; }
	inline bool* get_address_of_mAutoRejoin_19() { return &___mAutoRejoin_19; }
	inline void set_mAutoRejoin_19(bool value)
	{
		___mAutoRejoin_19 = value;
	}

	inline static int32_t get_offset_of_mRejoinTime_20() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mRejoinTime_20)); }
	inline float get_mRejoinTime_20() const { return ___mRejoinTime_20; }
	inline float* get_address_of_mRejoinTime_20() { return &___mRejoinTime_20; }
	inline void set_mRejoinTime_20(float value)
	{
		___mRejoinTime_20 = value;
	}

	inline static int32_t get_offset_of_mLocalFrameEvents_21() { return static_cast<int32_t>(offsetof(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43, ___mLocalFrameEvents_21)); }
	inline bool get_mLocalFrameEvents_21() const { return ___mLocalFrameEvents_21; }
	inline bool* get_address_of_mLocalFrameEvents_21() { return &___mLocalFrameEvents_21; }
	inline void set_mLocalFrameEvents_21(bool value)
	{
		___mLocalFrameEvents_21 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLAPP_T4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43_H
#ifndef CALLAPPUI_TACD06D4561F5F727B12FC86E8F703D58DC811867_H
#define CALLAPPUI_TACD06D4561F5F727B12FC86E8F703D58DC811867_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// CallAppUi
struct  CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Boolean CallAppUi::audioEnabled
	bool ___audioEnabled_4;
	// System.String CallAppUi::roomName
	String_t* ___roomName_5;
	// UnityEngine.Material CallAppUi::mat
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___mat_6;
	// UnityEngine.Texture2D CallAppUi::mRemoteVideoTexture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___mRemoteVideoTexture_7;
	// UnityEngine.Texture2D CallAppUi::uNoCameraTexture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___uNoCameraTexture_8;
	// CallApp CallAppUi::mApp
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43 * ___mApp_9;
	// System.Single CallAppUi::mVideoOverlayTimeout
	float ___mVideoOverlayTimeout_10;
	// Byn.Awrtc.FramePixelFormat CallAppUi::mLocalVideoFormat
	int32_t ___mLocalVideoFormat_12;
	// System.Boolean CallAppUi::mHasRemoteVideo
	bool ___mHasRemoteVideo_13;
	// System.Int32 CallAppUi::mRemoteVideoWidth
	int32_t ___mRemoteVideoWidth_14;
	// System.Int32 CallAppUi::mRemoteVideoHeight
	int32_t ___mRemoteVideoHeight_15;
	// System.Int32 CallAppUi::mRemoteFps
	int32_t ___mRemoteFps_16;
	// System.Int32 CallAppUi::mRemoteRotation
	int32_t ___mRemoteRotation_17;
	// System.Int32 CallAppUi::mRemoteFrameCounter
	int32_t ___mRemoteFrameCounter_18;
	// Byn.Awrtc.FramePixelFormat CallAppUi::mRemoteVideoFormat
	int32_t ___mRemoteVideoFormat_19;
	// System.Single CallAppUi::mFpsTimer
	float ___mFpsTimer_20;

public:
	inline static int32_t get_offset_of_audioEnabled_4() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___audioEnabled_4)); }
	inline bool get_audioEnabled_4() const { return ___audioEnabled_4; }
	inline bool* get_address_of_audioEnabled_4() { return &___audioEnabled_4; }
	inline void set_audioEnabled_4(bool value)
	{
		___audioEnabled_4 = value;
	}

	inline static int32_t get_offset_of_roomName_5() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___roomName_5)); }
	inline String_t* get_roomName_5() const { return ___roomName_5; }
	inline String_t** get_address_of_roomName_5() { return &___roomName_5; }
	inline void set_roomName_5(String_t* value)
	{
		___roomName_5 = value;
		Il2CppCodeGenWriteBarrier((&___roomName_5), value);
	}

	inline static int32_t get_offset_of_mat_6() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mat_6)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_mat_6() const { return ___mat_6; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_mat_6() { return &___mat_6; }
	inline void set_mat_6(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___mat_6 = value;
		Il2CppCodeGenWriteBarrier((&___mat_6), value);
	}

	inline static int32_t get_offset_of_mRemoteVideoTexture_7() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mRemoteVideoTexture_7)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_mRemoteVideoTexture_7() const { return ___mRemoteVideoTexture_7; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_mRemoteVideoTexture_7() { return &___mRemoteVideoTexture_7; }
	inline void set_mRemoteVideoTexture_7(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___mRemoteVideoTexture_7 = value;
		Il2CppCodeGenWriteBarrier((&___mRemoteVideoTexture_7), value);
	}

	inline static int32_t get_offset_of_uNoCameraTexture_8() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___uNoCameraTexture_8)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_uNoCameraTexture_8() const { return ___uNoCameraTexture_8; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_uNoCameraTexture_8() { return &___uNoCameraTexture_8; }
	inline void set_uNoCameraTexture_8(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___uNoCameraTexture_8 = value;
		Il2CppCodeGenWriteBarrier((&___uNoCameraTexture_8), value);
	}

	inline static int32_t get_offset_of_mApp_9() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mApp_9)); }
	inline CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43 * get_mApp_9() const { return ___mApp_9; }
	inline CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43 ** get_address_of_mApp_9() { return &___mApp_9; }
	inline void set_mApp_9(CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43 * value)
	{
		___mApp_9 = value;
		Il2CppCodeGenWriteBarrier((&___mApp_9), value);
	}

	inline static int32_t get_offset_of_mVideoOverlayTimeout_10() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mVideoOverlayTimeout_10)); }
	inline float get_mVideoOverlayTimeout_10() const { return ___mVideoOverlayTimeout_10; }
	inline float* get_address_of_mVideoOverlayTimeout_10() { return &___mVideoOverlayTimeout_10; }
	inline void set_mVideoOverlayTimeout_10(float value)
	{
		___mVideoOverlayTimeout_10 = value;
	}

	inline static int32_t get_offset_of_mLocalVideoFormat_12() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mLocalVideoFormat_12)); }
	inline int32_t get_mLocalVideoFormat_12() const { return ___mLocalVideoFormat_12; }
	inline int32_t* get_address_of_mLocalVideoFormat_12() { return &___mLocalVideoFormat_12; }
	inline void set_mLocalVideoFormat_12(int32_t value)
	{
		___mLocalVideoFormat_12 = value;
	}

	inline static int32_t get_offset_of_mHasRemoteVideo_13() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mHasRemoteVideo_13)); }
	inline bool get_mHasRemoteVideo_13() const { return ___mHasRemoteVideo_13; }
	inline bool* get_address_of_mHasRemoteVideo_13() { return &___mHasRemoteVideo_13; }
	inline void set_mHasRemoteVideo_13(bool value)
	{
		___mHasRemoteVideo_13 = value;
	}

	inline static int32_t get_offset_of_mRemoteVideoWidth_14() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mRemoteVideoWidth_14)); }
	inline int32_t get_mRemoteVideoWidth_14() const { return ___mRemoteVideoWidth_14; }
	inline int32_t* get_address_of_mRemoteVideoWidth_14() { return &___mRemoteVideoWidth_14; }
	inline void set_mRemoteVideoWidth_14(int32_t value)
	{
		___mRemoteVideoWidth_14 = value;
	}

	inline static int32_t get_offset_of_mRemoteVideoHeight_15() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mRemoteVideoHeight_15)); }
	inline int32_t get_mRemoteVideoHeight_15() const { return ___mRemoteVideoHeight_15; }
	inline int32_t* get_address_of_mRemoteVideoHeight_15() { return &___mRemoteVideoHeight_15; }
	inline void set_mRemoteVideoHeight_15(int32_t value)
	{
		___mRemoteVideoHeight_15 = value;
	}

	inline static int32_t get_offset_of_mRemoteFps_16() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mRemoteFps_16)); }
	inline int32_t get_mRemoteFps_16() const { return ___mRemoteFps_16; }
	inline int32_t* get_address_of_mRemoteFps_16() { return &___mRemoteFps_16; }
	inline void set_mRemoteFps_16(int32_t value)
	{
		___mRemoteFps_16 = value;
	}

	inline static int32_t get_offset_of_mRemoteRotation_17() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mRemoteRotation_17)); }
	inline int32_t get_mRemoteRotation_17() const { return ___mRemoteRotation_17; }
	inline int32_t* get_address_of_mRemoteRotation_17() { return &___mRemoteRotation_17; }
	inline void set_mRemoteRotation_17(int32_t value)
	{
		___mRemoteRotation_17 = value;
	}

	inline static int32_t get_offset_of_mRemoteFrameCounter_18() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mRemoteFrameCounter_18)); }
	inline int32_t get_mRemoteFrameCounter_18() const { return ___mRemoteFrameCounter_18; }
	inline int32_t* get_address_of_mRemoteFrameCounter_18() { return &___mRemoteFrameCounter_18; }
	inline void set_mRemoteFrameCounter_18(int32_t value)
	{
		___mRemoteFrameCounter_18 = value;
	}

	inline static int32_t get_offset_of_mRemoteVideoFormat_19() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mRemoteVideoFormat_19)); }
	inline int32_t get_mRemoteVideoFormat_19() const { return ___mRemoteVideoFormat_19; }
	inline int32_t* get_address_of_mRemoteVideoFormat_19() { return &___mRemoteVideoFormat_19; }
	inline void set_mRemoteVideoFormat_19(int32_t value)
	{
		___mRemoteVideoFormat_19 = value;
	}

	inline static int32_t get_offset_of_mFpsTimer_20() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867, ___mFpsTimer_20)); }
	inline float get_mFpsTimer_20() const { return ___mFpsTimer_20; }
	inline float* get_address_of_mFpsTimer_20() { return &___mFpsTimer_20; }
	inline void set_mFpsTimer_20(float value)
	{
		___mFpsTimer_20 = value;
	}
};

struct CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields
{
public:
	// System.Single CallAppUi::sDefaultOverlayTimeout
	float ___sDefaultOverlayTimeout_11;

public:
	inline static int32_t get_offset_of_sDefaultOverlayTimeout_11() { return static_cast<int32_t>(offsetof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields, ___sDefaultOverlayTimeout_11)); }
	inline float get_sDefaultOverlayTimeout_11() const { return ___sDefaultOverlayTimeout_11; }
	inline float* get_address_of_sDefaultOverlayTimeout_11() { return &___sDefaultOverlayTimeout_11; }
	inline void set_sDefaultOverlayTimeout_11(float value)
	{
		___sDefaultOverlayTimeout_11 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CALLAPPUI_TACD06D4561F5F727B12FC86E8F703D58DC811867_H
#ifndef CHATAPP_T0290B0B9E87598552A8CB2A528FC37BB576DD5A7_H
#define CHATAPP_T0290B0B9E87598552A8CB2A528FC37BB576DD5A7_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// ChatApp
struct  ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.String ChatApp::uSignalingUrl
	String_t* ___uSignalingUrl_4;
	// System.String ChatApp::uSecureSignalingUrl
	String_t* ___uSecureSignalingUrl_5;
	// System.Boolean ChatApp::uForceSecureSignaling
	bool ___uForceSecureSignaling_6;
	// System.String ChatApp::uIceServer
	String_t* ___uIceServer_7;
	// System.String ChatApp::uIceServerUser
	String_t* ___uIceServerUser_8;
	// System.String ChatApp::uIceServerPassword
	String_t* ___uIceServerPassword_9;
	// System.String ChatApp::uIceServer2
	String_t* ___uIceServer2_10;
	// UnityEngine.UI.InputField ChatApp::uRoomName
	InputField_t533609195B110760BCFF00B746C87D81969CB005 * ___uRoomName_11;
	// UnityEngine.UI.InputField ChatApp::uMessageInput
	InputField_t533609195B110760BCFF00B746C87D81969CB005 * ___uMessageInput_12;
	// MessageList ChatApp::uOutput
	MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC * ___uOutput_13;
	// UnityEngine.UI.Button ChatApp::uJoin
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uJoin_14;
	// UnityEngine.UI.Button ChatApp::uSend
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uSend_15;
	// UnityEngine.UI.Button ChatApp::uOpenRoom
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uOpenRoom_16;
	// UnityEngine.UI.Button ChatApp::uLeave
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___uLeave_17;
	// Byn.Awrtc.IBasicNetwork ChatApp::mNetwork
	RuntimeObject* ___mNetwork_18;
	// System.Boolean ChatApp::mIsServer
	bool ___mIsServer_19;
	// System.Collections.Generic.List`1<Byn.Awrtc.ConnectionId> ChatApp::mConnections
	List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * ___mConnections_20;

public:
	inline static int32_t get_offset_of_uSignalingUrl_4() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uSignalingUrl_4)); }
	inline String_t* get_uSignalingUrl_4() const { return ___uSignalingUrl_4; }
	inline String_t** get_address_of_uSignalingUrl_4() { return &___uSignalingUrl_4; }
	inline void set_uSignalingUrl_4(String_t* value)
	{
		___uSignalingUrl_4 = value;
		Il2CppCodeGenWriteBarrier((&___uSignalingUrl_4), value);
	}

	inline static int32_t get_offset_of_uSecureSignalingUrl_5() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uSecureSignalingUrl_5)); }
	inline String_t* get_uSecureSignalingUrl_5() const { return ___uSecureSignalingUrl_5; }
	inline String_t** get_address_of_uSecureSignalingUrl_5() { return &___uSecureSignalingUrl_5; }
	inline void set_uSecureSignalingUrl_5(String_t* value)
	{
		___uSecureSignalingUrl_5 = value;
		Il2CppCodeGenWriteBarrier((&___uSecureSignalingUrl_5), value);
	}

	inline static int32_t get_offset_of_uForceSecureSignaling_6() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uForceSecureSignaling_6)); }
	inline bool get_uForceSecureSignaling_6() const { return ___uForceSecureSignaling_6; }
	inline bool* get_address_of_uForceSecureSignaling_6() { return &___uForceSecureSignaling_6; }
	inline void set_uForceSecureSignaling_6(bool value)
	{
		___uForceSecureSignaling_6 = value;
	}

	inline static int32_t get_offset_of_uIceServer_7() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uIceServer_7)); }
	inline String_t* get_uIceServer_7() const { return ___uIceServer_7; }
	inline String_t** get_address_of_uIceServer_7() { return &___uIceServer_7; }
	inline void set_uIceServer_7(String_t* value)
	{
		___uIceServer_7 = value;
		Il2CppCodeGenWriteBarrier((&___uIceServer_7), value);
	}

	inline static int32_t get_offset_of_uIceServerUser_8() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uIceServerUser_8)); }
	inline String_t* get_uIceServerUser_8() const { return ___uIceServerUser_8; }
	inline String_t** get_address_of_uIceServerUser_8() { return &___uIceServerUser_8; }
	inline void set_uIceServerUser_8(String_t* value)
	{
		___uIceServerUser_8 = value;
		Il2CppCodeGenWriteBarrier((&___uIceServerUser_8), value);
	}

	inline static int32_t get_offset_of_uIceServerPassword_9() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uIceServerPassword_9)); }
	inline String_t* get_uIceServerPassword_9() const { return ___uIceServerPassword_9; }
	inline String_t** get_address_of_uIceServerPassword_9() { return &___uIceServerPassword_9; }
	inline void set_uIceServerPassword_9(String_t* value)
	{
		___uIceServerPassword_9 = value;
		Il2CppCodeGenWriteBarrier((&___uIceServerPassword_9), value);
	}

	inline static int32_t get_offset_of_uIceServer2_10() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uIceServer2_10)); }
	inline String_t* get_uIceServer2_10() const { return ___uIceServer2_10; }
	inline String_t** get_address_of_uIceServer2_10() { return &___uIceServer2_10; }
	inline void set_uIceServer2_10(String_t* value)
	{
		___uIceServer2_10 = value;
		Il2CppCodeGenWriteBarrier((&___uIceServer2_10), value);
	}

	inline static int32_t get_offset_of_uRoomName_11() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uRoomName_11)); }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 * get_uRoomName_11() const { return ___uRoomName_11; }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 ** get_address_of_uRoomName_11() { return &___uRoomName_11; }
	inline void set_uRoomName_11(InputField_t533609195B110760BCFF00B746C87D81969CB005 * value)
	{
		___uRoomName_11 = value;
		Il2CppCodeGenWriteBarrier((&___uRoomName_11), value);
	}

	inline static int32_t get_offset_of_uMessageInput_12() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uMessageInput_12)); }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 * get_uMessageInput_12() const { return ___uMessageInput_12; }
	inline InputField_t533609195B110760BCFF00B746C87D81969CB005 ** get_address_of_uMessageInput_12() { return &___uMessageInput_12; }
	inline void set_uMessageInput_12(InputField_t533609195B110760BCFF00B746C87D81969CB005 * value)
	{
		___uMessageInput_12 = value;
		Il2CppCodeGenWriteBarrier((&___uMessageInput_12), value);
	}

	inline static int32_t get_offset_of_uOutput_13() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uOutput_13)); }
	inline MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC * get_uOutput_13() const { return ___uOutput_13; }
	inline MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC ** get_address_of_uOutput_13() { return &___uOutput_13; }
	inline void set_uOutput_13(MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC * value)
	{
		___uOutput_13 = value;
		Il2CppCodeGenWriteBarrier((&___uOutput_13), value);
	}

	inline static int32_t get_offset_of_uJoin_14() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uJoin_14)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uJoin_14() const { return ___uJoin_14; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uJoin_14() { return &___uJoin_14; }
	inline void set_uJoin_14(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uJoin_14 = value;
		Il2CppCodeGenWriteBarrier((&___uJoin_14), value);
	}

	inline static int32_t get_offset_of_uSend_15() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uSend_15)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uSend_15() const { return ___uSend_15; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uSend_15() { return &___uSend_15; }
	inline void set_uSend_15(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uSend_15 = value;
		Il2CppCodeGenWriteBarrier((&___uSend_15), value);
	}

	inline static int32_t get_offset_of_uOpenRoom_16() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uOpenRoom_16)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uOpenRoom_16() const { return ___uOpenRoom_16; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uOpenRoom_16() { return &___uOpenRoom_16; }
	inline void set_uOpenRoom_16(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uOpenRoom_16 = value;
		Il2CppCodeGenWriteBarrier((&___uOpenRoom_16), value);
	}

	inline static int32_t get_offset_of_uLeave_17() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___uLeave_17)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_uLeave_17() const { return ___uLeave_17; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_uLeave_17() { return &___uLeave_17; }
	inline void set_uLeave_17(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___uLeave_17 = value;
		Il2CppCodeGenWriteBarrier((&___uLeave_17), value);
	}

	inline static int32_t get_offset_of_mNetwork_18() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___mNetwork_18)); }
	inline RuntimeObject* get_mNetwork_18() const { return ___mNetwork_18; }
	inline RuntimeObject** get_address_of_mNetwork_18() { return &___mNetwork_18; }
	inline void set_mNetwork_18(RuntimeObject* value)
	{
		___mNetwork_18 = value;
		Il2CppCodeGenWriteBarrier((&___mNetwork_18), value);
	}

	inline static int32_t get_offset_of_mIsServer_19() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___mIsServer_19)); }
	inline bool get_mIsServer_19() const { return ___mIsServer_19; }
	inline bool* get_address_of_mIsServer_19() { return &___mIsServer_19; }
	inline void set_mIsServer_19(bool value)
	{
		___mIsServer_19 = value;
	}

	inline static int32_t get_offset_of_mConnections_20() { return static_cast<int32_t>(offsetof(ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7, ___mConnections_20)); }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * get_mConnections_20() const { return ___mConnections_20; }
	inline List_1_tCB9967EC4C00221A410117D712FF423882EB5832 ** get_address_of_mConnections_20() { return &___mConnections_20; }
	inline void set_mConnections_20(List_1_tCB9967EC4C00221A410117D712FF423882EB5832 * value)
	{
		___mConnections_20 = value;
		Il2CppCodeGenWriteBarrier((&___mConnections_20), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CHATAPP_T0290B0B9E87598552A8CB2A528FC37BB576DD5A7_H
#ifndef DEMOBUTTONPRESSES_T4E38441FCA6AC3950E176902E7DD3BC5E459F134_H
#define DEMOBUTTONPRESSES_T4E38441FCA6AC3950E176902E7DD3BC5E459F134_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// DemoButtonPresses
struct  DemoButtonPresses_t4E38441FCA6AC3950E176902E7DD3BC5E459F134  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Boolean DemoButtonPresses::squareIsCurrentlyDown
	bool ___squareIsCurrentlyDown_4;
	// System.Boolean DemoButtonPresses::leftIsCurrentlyDown
	bool ___leftIsCurrentlyDown_5;
	// System.Boolean DemoButtonPresses::rightIsCurrentlyDown
	bool ___rightIsCurrentlyDown_6;
	// System.Boolean DemoButtonPresses::circleIsCurrentlyDown
	bool ___circleIsCurrentlyDown_7;

public:
	inline static int32_t get_offset_of_squareIsCurrentlyDown_4() { return static_cast<int32_t>(offsetof(DemoButtonPresses_t4E38441FCA6AC3950E176902E7DD3BC5E459F134, ___squareIsCurrentlyDown_4)); }
	inline bool get_squareIsCurrentlyDown_4() const { return ___squareIsCurrentlyDown_4; }
	inline bool* get_address_of_squareIsCurrentlyDown_4() { return &___squareIsCurrentlyDown_4; }
	inline void set_squareIsCurrentlyDown_4(bool value)
	{
		___squareIsCurrentlyDown_4 = value;
	}

	inline static int32_t get_offset_of_leftIsCurrentlyDown_5() { return static_cast<int32_t>(offsetof(DemoButtonPresses_t4E38441FCA6AC3950E176902E7DD3BC5E459F134, ___leftIsCurrentlyDown_5)); }
	inline bool get_leftIsCurrentlyDown_5() const { return ___leftIsCurrentlyDown_5; }
	inline bool* get_address_of_leftIsCurrentlyDown_5() { return &___leftIsCurrentlyDown_5; }
	inline void set_leftIsCurrentlyDown_5(bool value)
	{
		___leftIsCurrentlyDown_5 = value;
	}

	inline static int32_t get_offset_of_rightIsCurrentlyDown_6() { return static_cast<int32_t>(offsetof(DemoButtonPresses_t4E38441FCA6AC3950E176902E7DD3BC5E459F134, ___rightIsCurrentlyDown_6)); }
	inline bool get_rightIsCurrentlyDown_6() const { return ___rightIsCurrentlyDown_6; }
	inline bool* get_address_of_rightIsCurrentlyDown_6() { return &___rightIsCurrentlyDown_6; }
	inline void set_rightIsCurrentlyDown_6(bool value)
	{
		___rightIsCurrentlyDown_6 = value;
	}

	inline static int32_t get_offset_of_circleIsCurrentlyDown_7() { return static_cast<int32_t>(offsetof(DemoButtonPresses_t4E38441FCA6AC3950E176902E7DD3BC5E459F134, ___circleIsCurrentlyDown_7)); }
	inline bool get_circleIsCurrentlyDown_7() const { return ___circleIsCurrentlyDown_7; }
	inline bool* get_address_of_circleIsCurrentlyDown_7() { return &___circleIsCurrentlyDown_7; }
	inline void set_circleIsCurrentlyDown_7(bool value)
	{
		___circleIsCurrentlyDown_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEMOBUTTONPRESSES_T4E38441FCA6AC3950E176902E7DD3BC5E459F134_H
#ifndef GRIDMANAGER_T05748D877516CE2E0F9FBFACCF8AF0F6A21D4804_H
#define GRIDMANAGER_T05748D877516CE2E0F9FBFACCF8AF0F6A21D4804_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// GridManager
struct  GridManager_t05748D877516CE2E0F9FBFACCF8AF0F6A21D4804  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Int32 GridManager::mKnownItems
	int32_t ___mKnownItems_4;
	// UnityEngine.UI.GridLayoutGroup GridManager::mGrid
	GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8 * ___mGrid_5;
	// UnityEngine.RectTransform GridManager::mTransform
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___mTransform_6;

public:
	inline static int32_t get_offset_of_mKnownItems_4() { return static_cast<int32_t>(offsetof(GridManager_t05748D877516CE2E0F9FBFACCF8AF0F6A21D4804, ___mKnownItems_4)); }
	inline int32_t get_mKnownItems_4() const { return ___mKnownItems_4; }
	inline int32_t* get_address_of_mKnownItems_4() { return &___mKnownItems_4; }
	inline void set_mKnownItems_4(int32_t value)
	{
		___mKnownItems_4 = value;
	}

	inline static int32_t get_offset_of_mGrid_5() { return static_cast<int32_t>(offsetof(GridManager_t05748D877516CE2E0F9FBFACCF8AF0F6A21D4804, ___mGrid_5)); }
	inline GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8 * get_mGrid_5() const { return ___mGrid_5; }
	inline GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8 ** get_address_of_mGrid_5() { return &___mGrid_5; }
	inline void set_mGrid_5(GridLayoutGroup_t1C70294BD2567FD584672222A8BFD5A0DF1CA2A8 * value)
	{
		___mGrid_5 = value;
		Il2CppCodeGenWriteBarrier((&___mGrid_5), value);
	}

	inline static int32_t get_offset_of_mTransform_6() { return static_cast<int32_t>(offsetof(GridManager_t05748D877516CE2E0F9FBFACCF8AF0F6A21D4804, ___mTransform_6)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_mTransform_6() const { return ___mTransform_6; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_mTransform_6() { return &___mTransform_6; }
	inline void set_mTransform_6(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___mTransform_6 = value;
		Il2CppCodeGenWriteBarrier((&___mTransform_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GRIDMANAGER_T05748D877516CE2E0F9FBFACCF8AF0F6A21D4804_H
#ifndef IMGFITTER_T8C2D5035D612E3A0EA1E2F51DFD3870672984F40_H
#define IMGFITTER_T8C2D5035D612E3A0EA1E2F51DFD3870672984F40_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// ImgFitter
struct  ImgFitter_t8C2D5035D612E3A0EA1E2F51DFD3870672984F40  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // IMGFITTER_T8C2D5035D612E3A0EA1E2F51DFD3870672984F40_H
#ifndef INTERPROCESSCOMMUNICATOR_TC57C16C709EAB83416D28F1855D4860758C35019_H
#define INTERPROCESSCOMMUNICATOR_TC57C16C709EAB83416D28F1855D4860758C35019_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// InterProcessCommunicator
struct  InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// InterProcessCommunicator_MessageReceived InterProcessCommunicator::OnMessageReceived
	MessageReceived_t8F3129EEA322B159C6FD7D6F55678D155E6A9A12 * ___OnMessageReceived_4;
	// InterProcessCommunicator_Role InterProcessCommunicator::role
	int32_t ___role_7;
	// System.Int32 InterProcessCommunicator::receiverPort
	int32_t ___receiverPort_8;
	// System.Int32 InterProcessCommunicator::senderPort
	int32_t ___senderPort_9;
	// System.Boolean InterProcessCommunicator::signMessages
	bool ___signMessages_10;
	// System.Char InterProcessCommunicator::signingChar
	Il2CppChar ___signingChar_11;
	// System.Net.IPEndPoint InterProcessCommunicator::anyIP
	IPEndPoint_tCD29981135F7B1989C3845BF455AD44EBC13DE3F * ___anyIP_12;
	// System.Collections.Generic.Queue`1<System.String> InterProcessCommunicator::messageQueue
	Queue_1_t234B58D376F3C134441C47D5A9EF7789374EE172 * ___messageQueue_13;
	// System.Net.Sockets.UdpClient InterProcessCommunicator::client
	UdpClient_t94741C2FBA0D9E3270ABDDBA57811D00881D5641 * ___client_14;
	// System.Threading.Thread InterProcessCommunicator::receiveThread
	Thread_tF60E0A146CD3B5480CB65FF9B6016E84C5460CC7 * ___receiveThread_15;
	// System.Net.IPEndPoint InterProcessCommunicator::remoteEndPoint
	IPEndPoint_tCD29981135F7B1989C3845BF455AD44EBC13DE3F * ___remoteEndPoint_16;

public:
	inline static int32_t get_offset_of_OnMessageReceived_4() { return static_cast<int32_t>(offsetof(InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019, ___OnMessageReceived_4)); }
	inline MessageReceived_t8F3129EEA322B159C6FD7D6F55678D155E6A9A12 * get_OnMessageReceived_4() const { return ___OnMessageReceived_4; }
	inline MessageReceived_t8F3129EEA322B159C6FD7D6F55678D155E6A9A12 ** get_address_of_OnMessageReceived_4() { return &___OnMessageReceived_4; }
	inline void set_OnMessageReceived_4(MessageReceived_t8F3129EEA322B159C6FD7D6F55678D155E6A9A12 * value)
	{
		___OnMessageReceived_4 = value;
		Il2CppCodeGenWriteBarrier((&___OnMessageReceived_4), value);
	}

	inline static int32_t get_offset_of_role_7() { return static_cast<int32_t>(offsetof(InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019, ___role_7)); }
	inline int32_t get_role_7() const { return ___role_7; }
	inline int32_t* get_address_of_role_7() { return &___role_7; }
	inline void set_role_7(int32_t value)
	{
		___role_7 = value;
	}

	inline static int32_t get_offset_of_receiverPort_8() { return static_cast<int32_t>(offsetof(InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019, ___receiverPort_8)); }
	inline int32_t get_receiverPort_8() const { return ___receiverPort_8; }
	inline int32_t* get_address_of_receiverPort_8() { return &___receiverPort_8; }
	inline void set_receiverPort_8(int32_t value)
	{
		___receiverPort_8 = value;
	}

	inline static int32_t get_offset_of_senderPort_9() { return static_cast<int32_t>(offsetof(InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019, ___senderPort_9)); }
	inline int32_t get_senderPort_9() const { return ___senderPort_9; }
	inline int32_t* get_address_of_senderPort_9() { return &___senderPort_9; }
	inline void set_senderPort_9(int32_t value)
	{
		___senderPort_9 = value;
	}

	inline static int32_t get_offset_of_signMessages_10() { return static_cast<int32_t>(offsetof(InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019, ___signMessages_10)); }
	inline bool get_signMessages_10() const { return ___signMessages_10; }
	inline bool* get_address_of_signMessages_10() { return &___signMessages_10; }
	inline void set_signMessages_10(bool value)
	{
		___signMessages_10 = value;
	}

	inline static int32_t get_offset_of_signingChar_11() { return static_cast<int32_t>(offsetof(InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019, ___signingChar_11)); }
	inline Il2CppChar get_signingChar_11() const { return ___signingChar_11; }
	inline Il2CppChar* get_address_of_signingChar_11() { return &___signingChar_11; }
	inline void set_signingChar_11(Il2CppChar value)
	{
		___signingChar_11 = value;
	}

	inline static int32_t get_offset_of_anyIP_12() { return static_cast<int32_t>(offsetof(InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019, ___anyIP_12)); }
	inline IPEndPoint_tCD29981135F7B1989C3845BF455AD44EBC13DE3F * get_anyIP_12() const { return ___anyIP_12; }
	inline IPEndPoint_tCD29981135F7B1989C3845BF455AD44EBC13DE3F ** get_address_of_anyIP_12() { return &___anyIP_12; }
	inline void set_anyIP_12(IPEndPoint_tCD29981135F7B1989C3845BF455AD44EBC13DE3F * value)
	{
		___anyIP_12 = value;
		Il2CppCodeGenWriteBarrier((&___anyIP_12), value);
	}

	inline static int32_t get_offset_of_messageQueue_13() { return static_cast<int32_t>(offsetof(InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019, ___messageQueue_13)); }
	inline Queue_1_t234B58D376F3C134441C47D5A9EF7789374EE172 * get_messageQueue_13() const { return ___messageQueue_13; }
	inline Queue_1_t234B58D376F3C134441C47D5A9EF7789374EE172 ** get_address_of_messageQueue_13() { return &___messageQueue_13; }
	inline void set_messageQueue_13(Queue_1_t234B58D376F3C134441C47D5A9EF7789374EE172 * value)
	{
		___messageQueue_13 = value;
		Il2CppCodeGenWriteBarrier((&___messageQueue_13), value);
	}

	inline static int32_t get_offset_of_client_14() { return static_cast<int32_t>(offsetof(InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019, ___client_14)); }
	inline UdpClient_t94741C2FBA0D9E3270ABDDBA57811D00881D5641 * get_client_14() const { return ___client_14; }
	inline UdpClient_t94741C2FBA0D9E3270ABDDBA57811D00881D5641 ** get_address_of_client_14() { return &___client_14; }
	inline void set_client_14(UdpClient_t94741C2FBA0D9E3270ABDDBA57811D00881D5641 * value)
	{
		___client_14 = value;
		Il2CppCodeGenWriteBarrier((&___client_14), value);
	}

	inline static int32_t get_offset_of_receiveThread_15() { return static_cast<int32_t>(offsetof(InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019, ___receiveThread_15)); }
	inline Thread_tF60E0A146CD3B5480CB65FF9B6016E84C5460CC7 * get_receiveThread_15() const { return ___receiveThread_15; }
	inline Thread_tF60E0A146CD3B5480CB65FF9B6016E84C5460CC7 ** get_address_of_receiveThread_15() { return &___receiveThread_15; }
	inline void set_receiveThread_15(Thread_tF60E0A146CD3B5480CB65FF9B6016E84C5460CC7 * value)
	{
		___receiveThread_15 = value;
		Il2CppCodeGenWriteBarrier((&___receiveThread_15), value);
	}

	inline static int32_t get_offset_of_remoteEndPoint_16() { return static_cast<int32_t>(offsetof(InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019, ___remoteEndPoint_16)); }
	inline IPEndPoint_tCD29981135F7B1989C3845BF455AD44EBC13DE3F * get_remoteEndPoint_16() const { return ___remoteEndPoint_16; }
	inline IPEndPoint_tCD29981135F7B1989C3845BF455AD44EBC13DE3F ** get_address_of_remoteEndPoint_16() { return &___remoteEndPoint_16; }
	inline void set_remoteEndPoint_16(IPEndPoint_tCD29981135F7B1989C3845BF455AD44EBC13DE3F * value)
	{
		___remoteEndPoint_16 = value;
		Il2CppCodeGenWriteBarrier((&___remoteEndPoint_16), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTERPROCESSCOMMUNICATOR_TC57C16C709EAB83416D28F1855D4860758C35019_H
#ifndef BUTTONMANAGER_T7795B64B4A21A90258F24137E6E2D8517B1D97B1_H
#define BUTTONMANAGER_T7795B64B4A21A90258F24137E6E2D8517B1D97B1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.ButtonManager
struct  ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Boolean LookingGlass.ButtonManager::emulateWithKeyboard
	bool ___emulateWithKeyboard_4;
	// System.Int32 LookingGlass.ButtonManager::joystickNumber
	int32_t ___joystickNumber_5;
	// System.Single LookingGlass.ButtonManager::timeSinceLastCheck
	float ___timeSinceLastCheck_6;
	// System.Single LookingGlass.ButtonManager::checkInterval
	float ___checkInterval_7;
	// System.Collections.Generic.Dictionary`2<System.Int32,UnityEngine.KeyCode> LookingGlass.ButtonManager::buttonKeyCodes
	Dictionary_2_t62DE54E46DE2592000A3E642D70CC960007FB495 * ___buttonKeyCodes_8;

public:
	inline static int32_t get_offset_of_emulateWithKeyboard_4() { return static_cast<int32_t>(offsetof(ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1, ___emulateWithKeyboard_4)); }
	inline bool get_emulateWithKeyboard_4() const { return ___emulateWithKeyboard_4; }
	inline bool* get_address_of_emulateWithKeyboard_4() { return &___emulateWithKeyboard_4; }
	inline void set_emulateWithKeyboard_4(bool value)
	{
		___emulateWithKeyboard_4 = value;
	}

	inline static int32_t get_offset_of_joystickNumber_5() { return static_cast<int32_t>(offsetof(ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1, ___joystickNumber_5)); }
	inline int32_t get_joystickNumber_5() const { return ___joystickNumber_5; }
	inline int32_t* get_address_of_joystickNumber_5() { return &___joystickNumber_5; }
	inline void set_joystickNumber_5(int32_t value)
	{
		___joystickNumber_5 = value;
	}

	inline static int32_t get_offset_of_timeSinceLastCheck_6() { return static_cast<int32_t>(offsetof(ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1, ___timeSinceLastCheck_6)); }
	inline float get_timeSinceLastCheck_6() const { return ___timeSinceLastCheck_6; }
	inline float* get_address_of_timeSinceLastCheck_6() { return &___timeSinceLastCheck_6; }
	inline void set_timeSinceLastCheck_6(float value)
	{
		___timeSinceLastCheck_6 = value;
	}

	inline static int32_t get_offset_of_checkInterval_7() { return static_cast<int32_t>(offsetof(ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1, ___checkInterval_7)); }
	inline float get_checkInterval_7() const { return ___checkInterval_7; }
	inline float* get_address_of_checkInterval_7() { return &___checkInterval_7; }
	inline void set_checkInterval_7(float value)
	{
		___checkInterval_7 = value;
	}

	inline static int32_t get_offset_of_buttonKeyCodes_8() { return static_cast<int32_t>(offsetof(ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1, ___buttonKeyCodes_8)); }
	inline Dictionary_2_t62DE54E46DE2592000A3E642D70CC960007FB495 * get_buttonKeyCodes_8() const { return ___buttonKeyCodes_8; }
	inline Dictionary_2_t62DE54E46DE2592000A3E642D70CC960007FB495 ** get_address_of_buttonKeyCodes_8() { return &___buttonKeyCodes_8; }
	inline void set_buttonKeyCodes_8(Dictionary_2_t62DE54E46DE2592000A3E642D70CC960007FB495 * value)
	{
		___buttonKeyCodes_8 = value;
		Il2CppCodeGenWriteBarrier((&___buttonKeyCodes_8), value);
	}
};

struct ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1_StaticFields
{
public:
	// LookingGlass.ButtonManager LookingGlass.ButtonManager::instance
	ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1 * ___instance_9;

public:
	inline static int32_t get_offset_of_instance_9() { return static_cast<int32_t>(offsetof(ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1_StaticFields, ___instance_9)); }
	inline ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1 * get_instance_9() const { return ___instance_9; }
	inline ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1 ** get_address_of_instance_9() { return &___instance_9; }
	inline void set_instance_9(ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1 * value)
	{
		___instance_9 = value;
		Il2CppCodeGenWriteBarrier((&___instance_9), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BUTTONMANAGER_T7795B64B4A21A90258F24137E6E2D8517B1D97B1_H
#ifndef CURSOR3D_TF4009A33E3994048D1FEE399C55AB2DF046900C6_H
#define CURSOR3D_TF4009A33E3994048D1FEE399C55AB2DF046900C6_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Cursor3D
struct  Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Boolean LookingGlass.Cursor3D::disableSystemCursor
	bool ___disableSystemCursor_5;
	// System.Boolean LookingGlass.Cursor3D::relativeScale
	bool ___relativeScale_6;
	// UnityEngine.Texture2D LookingGlass.Cursor3D::depthNormals
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___depthNormals_7;
	// UnityEngine.Shader LookingGlass.Cursor3D::depthOnlyShader
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___depthOnlyShader_8;
	// UnityEngine.Shader LookingGlass.Cursor3D::readDepthPixelShader
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___readDepthPixelShader_9;
	// UnityEngine.Material LookingGlass.Cursor3D::readDepthPixelMat
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___readDepthPixelMat_10;
	// UnityEngine.GameObject LookingGlass.Cursor3D::cursorGameObject
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___cursorGameObject_11;
	// System.Boolean LookingGlass.Cursor3D::cursorGameObjectExists
	bool ___cursorGameObjectExists_12;
	// System.Boolean LookingGlass.Cursor3D::frameRendered
	bool ___frameRendered_13;
	// UnityEngine.Camera LookingGlass.Cursor3D::cursorCam
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ___cursorCam_14;
	// UnityEngine.Vector3 LookingGlass.Cursor3D::worldPos
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___worldPos_15;
	// UnityEngine.Vector3 LookingGlass.Cursor3D::localPos
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___localPos_16;
	// UnityEngine.Vector3 LookingGlass.Cursor3D::normal
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___normal_17;
	// UnityEngine.Quaternion LookingGlass.Cursor3D::rotation
	Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  ___rotation_18;
	// UnityEngine.Quaternion LookingGlass.Cursor3D::localRotation
	Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  ___localRotation_19;
	// System.Boolean LookingGlass.Cursor3D::overObject
	bool ___overObject_20;
	// UnityEngine.RenderTexture LookingGlass.Cursor3D::debugTexture
	RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * ___debugTexture_21;
	// UnityEngine.GameObject LookingGlass.Cursor3D::uiCursor
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___uiCursor_22;
	// UnityEngine.Canvas LookingGlass.Cursor3D::parentCanvas
	Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591 * ___parentCanvas_23;
	// UnityEngine.Renderer LookingGlass.Cursor3D::rend
	Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 * ___rend_24;
	// System.Boolean LookingGlass.Cursor3D::uiCursorMode
	bool ___uiCursorMode_25;

public:
	inline static int32_t get_offset_of_disableSystemCursor_5() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___disableSystemCursor_5)); }
	inline bool get_disableSystemCursor_5() const { return ___disableSystemCursor_5; }
	inline bool* get_address_of_disableSystemCursor_5() { return &___disableSystemCursor_5; }
	inline void set_disableSystemCursor_5(bool value)
	{
		___disableSystemCursor_5 = value;
	}

	inline static int32_t get_offset_of_relativeScale_6() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___relativeScale_6)); }
	inline bool get_relativeScale_6() const { return ___relativeScale_6; }
	inline bool* get_address_of_relativeScale_6() { return &___relativeScale_6; }
	inline void set_relativeScale_6(bool value)
	{
		___relativeScale_6 = value;
	}

	inline static int32_t get_offset_of_depthNormals_7() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___depthNormals_7)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_depthNormals_7() const { return ___depthNormals_7; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_depthNormals_7() { return &___depthNormals_7; }
	inline void set_depthNormals_7(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___depthNormals_7 = value;
		Il2CppCodeGenWriteBarrier((&___depthNormals_7), value);
	}

	inline static int32_t get_offset_of_depthOnlyShader_8() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___depthOnlyShader_8)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_depthOnlyShader_8() const { return ___depthOnlyShader_8; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_depthOnlyShader_8() { return &___depthOnlyShader_8; }
	inline void set_depthOnlyShader_8(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___depthOnlyShader_8 = value;
		Il2CppCodeGenWriteBarrier((&___depthOnlyShader_8), value);
	}

	inline static int32_t get_offset_of_readDepthPixelShader_9() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___readDepthPixelShader_9)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_readDepthPixelShader_9() const { return ___readDepthPixelShader_9; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_readDepthPixelShader_9() { return &___readDepthPixelShader_9; }
	inline void set_readDepthPixelShader_9(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___readDepthPixelShader_9 = value;
		Il2CppCodeGenWriteBarrier((&___readDepthPixelShader_9), value);
	}

	inline static int32_t get_offset_of_readDepthPixelMat_10() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___readDepthPixelMat_10)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_readDepthPixelMat_10() const { return ___readDepthPixelMat_10; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_readDepthPixelMat_10() { return &___readDepthPixelMat_10; }
	inline void set_readDepthPixelMat_10(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___readDepthPixelMat_10 = value;
		Il2CppCodeGenWriteBarrier((&___readDepthPixelMat_10), value);
	}

	inline static int32_t get_offset_of_cursorGameObject_11() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___cursorGameObject_11)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_cursorGameObject_11() const { return ___cursorGameObject_11; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_cursorGameObject_11() { return &___cursorGameObject_11; }
	inline void set_cursorGameObject_11(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___cursorGameObject_11 = value;
		Il2CppCodeGenWriteBarrier((&___cursorGameObject_11), value);
	}

	inline static int32_t get_offset_of_cursorGameObjectExists_12() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___cursorGameObjectExists_12)); }
	inline bool get_cursorGameObjectExists_12() const { return ___cursorGameObjectExists_12; }
	inline bool* get_address_of_cursorGameObjectExists_12() { return &___cursorGameObjectExists_12; }
	inline void set_cursorGameObjectExists_12(bool value)
	{
		___cursorGameObjectExists_12 = value;
	}

	inline static int32_t get_offset_of_frameRendered_13() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___frameRendered_13)); }
	inline bool get_frameRendered_13() const { return ___frameRendered_13; }
	inline bool* get_address_of_frameRendered_13() { return &___frameRendered_13; }
	inline void set_frameRendered_13(bool value)
	{
		___frameRendered_13 = value;
	}

	inline static int32_t get_offset_of_cursorCam_14() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___cursorCam_14)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get_cursorCam_14() const { return ___cursorCam_14; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of_cursorCam_14() { return &___cursorCam_14; }
	inline void set_cursorCam_14(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		___cursorCam_14 = value;
		Il2CppCodeGenWriteBarrier((&___cursorCam_14), value);
	}

	inline static int32_t get_offset_of_worldPos_15() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___worldPos_15)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_worldPos_15() const { return ___worldPos_15; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_worldPos_15() { return &___worldPos_15; }
	inline void set_worldPos_15(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___worldPos_15 = value;
	}

	inline static int32_t get_offset_of_localPos_16() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___localPos_16)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_localPos_16() const { return ___localPos_16; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_localPos_16() { return &___localPos_16; }
	inline void set_localPos_16(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___localPos_16 = value;
	}

	inline static int32_t get_offset_of_normal_17() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___normal_17)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_normal_17() const { return ___normal_17; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_normal_17() { return &___normal_17; }
	inline void set_normal_17(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___normal_17 = value;
	}

	inline static int32_t get_offset_of_rotation_18() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___rotation_18)); }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  get_rotation_18() const { return ___rotation_18; }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357 * get_address_of_rotation_18() { return &___rotation_18; }
	inline void set_rotation_18(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  value)
	{
		___rotation_18 = value;
	}

	inline static int32_t get_offset_of_localRotation_19() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___localRotation_19)); }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  get_localRotation_19() const { return ___localRotation_19; }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357 * get_address_of_localRotation_19() { return &___localRotation_19; }
	inline void set_localRotation_19(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  value)
	{
		___localRotation_19 = value;
	}

	inline static int32_t get_offset_of_overObject_20() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___overObject_20)); }
	inline bool get_overObject_20() const { return ___overObject_20; }
	inline bool* get_address_of_overObject_20() { return &___overObject_20; }
	inline void set_overObject_20(bool value)
	{
		___overObject_20 = value;
	}

	inline static int32_t get_offset_of_debugTexture_21() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___debugTexture_21)); }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * get_debugTexture_21() const { return ___debugTexture_21; }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 ** get_address_of_debugTexture_21() { return &___debugTexture_21; }
	inline void set_debugTexture_21(RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * value)
	{
		___debugTexture_21 = value;
		Il2CppCodeGenWriteBarrier((&___debugTexture_21), value);
	}

	inline static int32_t get_offset_of_uiCursor_22() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___uiCursor_22)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_uiCursor_22() const { return ___uiCursor_22; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_uiCursor_22() { return &___uiCursor_22; }
	inline void set_uiCursor_22(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___uiCursor_22 = value;
		Il2CppCodeGenWriteBarrier((&___uiCursor_22), value);
	}

	inline static int32_t get_offset_of_parentCanvas_23() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___parentCanvas_23)); }
	inline Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591 * get_parentCanvas_23() const { return ___parentCanvas_23; }
	inline Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591 ** get_address_of_parentCanvas_23() { return &___parentCanvas_23; }
	inline void set_parentCanvas_23(Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591 * value)
	{
		___parentCanvas_23 = value;
		Il2CppCodeGenWriteBarrier((&___parentCanvas_23), value);
	}

	inline static int32_t get_offset_of_rend_24() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___rend_24)); }
	inline Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 * get_rend_24() const { return ___rend_24; }
	inline Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 ** get_address_of_rend_24() { return &___rend_24; }
	inline void set_rend_24(Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 * value)
	{
		___rend_24 = value;
		Il2CppCodeGenWriteBarrier((&___rend_24), value);
	}

	inline static int32_t get_offset_of_uiCursorMode_25() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6, ___uiCursorMode_25)); }
	inline bool get_uiCursorMode_25() const { return ___uiCursorMode_25; }
	inline bool* get_address_of_uiCursorMode_25() { return &___uiCursorMode_25; }
	inline void set_uiCursorMode_25(bool value)
	{
		___uiCursorMode_25 = value;
	}
};

struct Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6_StaticFields
{
public:
	// LookingGlass.Cursor3D LookingGlass.Cursor3D::instance
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6 * ___instance_4;

public:
	inline static int32_t get_offset_of_instance_4() { return static_cast<int32_t>(offsetof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6_StaticFields, ___instance_4)); }
	inline Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6 * get_instance_4() const { return ___instance_4; }
	inline Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6 ** get_address_of_instance_4() { return &___instance_4; }
	inline void set_instance_4(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6 * value)
	{
		___instance_4 = value;
		Il2CppCodeGenWriteBarrier((&___instance_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CURSOR3D_TF4009A33E3994048D1FEE399C55AB2DF046900C6_H
#ifndef EXTENDEDUI_T3A2E2222C569E098392D2FD2E39FCC390E6FE3A6_H
#define EXTENDEDUI_T3A2E2222C569E098392D2FD2E39FCC390E6FE3A6_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.ExtendedUI
struct  ExtendedUI_t3A2E2222C569E098392D2FD2E39FCC390E6FE3A6  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Canvas LookingGlass.ExtendedUI::canvas
	Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591 * ___canvas_4;
	// UnityEngine.Camera LookingGlass.ExtendedUI::bgCam
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ___bgCam_5;
	// System.Boolean LookingGlass.ExtendedUI::copyBGCamSettings
	bool ___copyBGCamSettings_6;
	// System.Boolean LookingGlass.ExtendedUI::singleDisplayMode
	bool ___singleDisplayMode_7;

public:
	inline static int32_t get_offset_of_canvas_4() { return static_cast<int32_t>(offsetof(ExtendedUI_t3A2E2222C569E098392D2FD2E39FCC390E6FE3A6, ___canvas_4)); }
	inline Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591 * get_canvas_4() const { return ___canvas_4; }
	inline Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591 ** get_address_of_canvas_4() { return &___canvas_4; }
	inline void set_canvas_4(Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591 * value)
	{
		___canvas_4 = value;
		Il2CppCodeGenWriteBarrier((&___canvas_4), value);
	}

	inline static int32_t get_offset_of_bgCam_5() { return static_cast<int32_t>(offsetof(ExtendedUI_t3A2E2222C569E098392D2FD2E39FCC390E6FE3A6, ___bgCam_5)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get_bgCam_5() const { return ___bgCam_5; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of_bgCam_5() { return &___bgCam_5; }
	inline void set_bgCam_5(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		___bgCam_5 = value;
		Il2CppCodeGenWriteBarrier((&___bgCam_5), value);
	}

	inline static int32_t get_offset_of_copyBGCamSettings_6() { return static_cast<int32_t>(offsetof(ExtendedUI_t3A2E2222C569E098392D2FD2E39FCC390E6FE3A6, ___copyBGCamSettings_6)); }
	inline bool get_copyBGCamSettings_6() const { return ___copyBGCamSettings_6; }
	inline bool* get_address_of_copyBGCamSettings_6() { return &___copyBGCamSettings_6; }
	inline void set_copyBGCamSettings_6(bool value)
	{
		___copyBGCamSettings_6 = value;
	}

	inline static int32_t get_offset_of_singleDisplayMode_7() { return static_cast<int32_t>(offsetof(ExtendedUI_t3A2E2222C569E098392D2FD2E39FCC390E6FE3A6, ___singleDisplayMode_7)); }
	inline bool get_singleDisplayMode_7() const { return ___singleDisplayMode_7; }
	inline bool* get_address_of_singleDisplayMode_7() { return &___singleDisplayMode_7; }
	inline void set_singleDisplayMode_7(bool value)
	{
		___singleDisplayMode_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EXTENDEDUI_T3A2E2222C569E098392D2FD2E39FCC390E6FE3A6_H
#ifndef HOLOPLAY_TE1D6BDF468D366341C53CDEAB3828B4ADF11A98A_H
#define HOLOPLAY_TE1D6BDF468D366341C53CDEAB3828B4ADF11A98A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Holoplay
struct  Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.CameraClearFlags LookingGlass.Holoplay::clearFlags
	int32_t ___clearFlags_7;
	// UnityEngine.Color LookingGlass.Holoplay::background
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___background_8;
	// UnityEngine.LayerMask LookingGlass.Holoplay::cullingMask
	LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0  ___cullingMask_9;
	// System.Single LookingGlass.Holoplay::size
	float ___size_10;
	// System.Single LookingGlass.Holoplay::depth
	float ___depth_11;
	// UnityEngine.RenderingPath LookingGlass.Holoplay::renderingPath
	int32_t ___renderingPath_12;
	// System.Boolean LookingGlass.Holoplay::occlusionCulling
	bool ___occlusionCulling_13;
	// System.Boolean LookingGlass.Holoplay::allowHDR
	bool ___allowHDR_14;
	// System.Boolean LookingGlass.Holoplay::allowMSAA
	bool ___allowMSAA_15;
	// System.Boolean LookingGlass.Holoplay::allowDynamicResolution
	bool ___allowDynamicResolution_16;
	// System.Int32 LookingGlass.Holoplay::targetDisplay
	int32_t ___targetDisplay_17;
	// System.Int32 LookingGlass.Holoplay::targetLKG
	int32_t ___targetLKG_18;
	// System.Boolean LookingGlass.Holoplay::preview2D
	bool ___preview2D_19;
	// System.Single LookingGlass.Holoplay::fov
	float ___fov_20;
	// System.Single LookingGlass.Holoplay::nearClipFactor
	float ___nearClipFactor_21;
	// System.Single LookingGlass.Holoplay::farClipFactor
	float ___farClipFactor_22;
	// System.Boolean LookingGlass.Holoplay::scaleFollowsSize
	bool ___scaleFollowsSize_23;
	// System.Single LookingGlass.Holoplay::viewconeModifier
	float ___viewconeModifier_24;
	// System.Single LookingGlass.Holoplay::centerOffset
	float ___centerOffset_25;
	// System.Single LookingGlass.Holoplay::horizontalFrustumOffset
	float ___horizontalFrustumOffset_26;
	// System.Single LookingGlass.Holoplay::verticalFrustumOffset
	float ___verticalFrustumOffset_27;
	// System.Boolean LookingGlass.Holoplay::useFrustumTarget
	bool ___useFrustumTarget_28;
	// UnityEngine.Transform LookingGlass.Holoplay::frustumTarget
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___frustumTarget_29;
	// LookingGlass.Quilt_Preset LookingGlass.Holoplay::quiltPreset
	int32_t ___quiltPreset_30;
	// LookingGlass.Quilt_Settings LookingGlass.Holoplay::customQuiltSettings
	Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46  ___customQuiltSettings_31;
	// UnityEngine.KeyCode LookingGlass.Holoplay::screenshot2DKey
	int32_t ___screenshot2DKey_32;
	// UnityEngine.KeyCode LookingGlass.Holoplay::screenshotQuiltKey
	int32_t ___screenshotQuiltKey_33;
	// UnityEngine.Texture LookingGlass.Holoplay::overrideQuilt
	Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * ___overrideQuilt_34;
	// System.Boolean LookingGlass.Holoplay::renderOverrideBehind
	bool ___renderOverrideBehind_35;
	// UnityEngine.RenderTexture LookingGlass.Holoplay::quiltRT
	RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * ___quiltRT_36;
	// UnityEngine.Material LookingGlass.Holoplay::lightfieldMat
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___lightfieldMat_37;
	// UnityEngine.Color LookingGlass.Holoplay::frustumColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___frustumColor_38;
	// UnityEngine.Color LookingGlass.Holoplay::middlePlaneColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___middlePlaneColor_39;
	// UnityEngine.Color LookingGlass.Holoplay::handleColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___handleColor_40;
	// System.Boolean LookingGlass.Holoplay::drawHandles
	bool ___drawHandles_41;
	// System.Single[] LookingGlass.Holoplay::cornerDists
	SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* ___cornerDists_42;
	// UnityEngine.Vector3[] LookingGlass.Holoplay::frustumCorners
	Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28* ___frustumCorners_43;
	// LookingGlass.LoadEvent LookingGlass.Holoplay::onHoloplayReady
	LoadEvent_tE7ACDCDE718293339A984D1E678134087257D727 * ___onHoloplayReady_44;
	// LookingGlass.LoadResults LookingGlass.Holoplay::loadResults
	LoadResults_t3028A604D8ED7E35E4316051844BAEECE1930F02  ___loadResults_45;
	// LookingGlass.Holoplay_ViewRenderEvent LookingGlass.Holoplay::onViewRender
	ViewRenderEvent_t8A52588044E632F42B64DC1EE219DC39E0DA957C * ___onViewRender_46;
	// LookingGlass.Holoplay_ViewInterpolationType LookingGlass.Holoplay::viewInterpolation
	int32_t ___viewInterpolation_47;
	// System.Boolean LookingGlass.Holoplay::reduceFlicker
	bool ___reduceFlicker_48;
	// System.Boolean LookingGlass.Holoplay::fillGaps
	bool ___fillGaps_49;
	// System.Boolean LookingGlass.Holoplay::blendViews
	bool ___blendViews_50;
	// UnityEngine.ComputeShader LookingGlass.Holoplay::interpolationComputeShader
	ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * ___interpolationComputeShader_51;
	// UnityEngine.Camera LookingGlass.Holoplay::cam
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ___cam_52;
	// UnityEngine.Camera LookingGlass.Holoplay::postProcessCam
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ___postProcessCam_53;
	// UnityEngine.Camera LookingGlass.Holoplay::lightfieldCam
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ___lightfieldCam_54;
	// LookingGlass.Calibration LookingGlass.Holoplay::cal
	Calibration_t9AB78454E6D4068384FB24A31465696019A429D0  ___cal_57;
	// System.Boolean LookingGlass.Holoplay::frameRendered
	bool ___frameRendered_58;
	// System.Single LookingGlass.Holoplay::camDist
	float ___camDist_59;
	// System.Boolean LookingGlass.Holoplay::debugInfo
	bool ___debugInfo_60;

public:
	inline static int32_t get_offset_of_clearFlags_7() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___clearFlags_7)); }
	inline int32_t get_clearFlags_7() const { return ___clearFlags_7; }
	inline int32_t* get_address_of_clearFlags_7() { return &___clearFlags_7; }
	inline void set_clearFlags_7(int32_t value)
	{
		___clearFlags_7 = value;
	}

	inline static int32_t get_offset_of_background_8() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___background_8)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_background_8() const { return ___background_8; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_background_8() { return &___background_8; }
	inline void set_background_8(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___background_8 = value;
	}

	inline static int32_t get_offset_of_cullingMask_9() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___cullingMask_9)); }
	inline LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0  get_cullingMask_9() const { return ___cullingMask_9; }
	inline LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0 * get_address_of_cullingMask_9() { return &___cullingMask_9; }
	inline void set_cullingMask_9(LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0  value)
	{
		___cullingMask_9 = value;
	}

	inline static int32_t get_offset_of_size_10() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___size_10)); }
	inline float get_size_10() const { return ___size_10; }
	inline float* get_address_of_size_10() { return &___size_10; }
	inline void set_size_10(float value)
	{
		___size_10 = value;
	}

	inline static int32_t get_offset_of_depth_11() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___depth_11)); }
	inline float get_depth_11() const { return ___depth_11; }
	inline float* get_address_of_depth_11() { return &___depth_11; }
	inline void set_depth_11(float value)
	{
		___depth_11 = value;
	}

	inline static int32_t get_offset_of_renderingPath_12() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___renderingPath_12)); }
	inline int32_t get_renderingPath_12() const { return ___renderingPath_12; }
	inline int32_t* get_address_of_renderingPath_12() { return &___renderingPath_12; }
	inline void set_renderingPath_12(int32_t value)
	{
		___renderingPath_12 = value;
	}

	inline static int32_t get_offset_of_occlusionCulling_13() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___occlusionCulling_13)); }
	inline bool get_occlusionCulling_13() const { return ___occlusionCulling_13; }
	inline bool* get_address_of_occlusionCulling_13() { return &___occlusionCulling_13; }
	inline void set_occlusionCulling_13(bool value)
	{
		___occlusionCulling_13 = value;
	}

	inline static int32_t get_offset_of_allowHDR_14() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___allowHDR_14)); }
	inline bool get_allowHDR_14() const { return ___allowHDR_14; }
	inline bool* get_address_of_allowHDR_14() { return &___allowHDR_14; }
	inline void set_allowHDR_14(bool value)
	{
		___allowHDR_14 = value;
	}

	inline static int32_t get_offset_of_allowMSAA_15() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___allowMSAA_15)); }
	inline bool get_allowMSAA_15() const { return ___allowMSAA_15; }
	inline bool* get_address_of_allowMSAA_15() { return &___allowMSAA_15; }
	inline void set_allowMSAA_15(bool value)
	{
		___allowMSAA_15 = value;
	}

	inline static int32_t get_offset_of_allowDynamicResolution_16() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___allowDynamicResolution_16)); }
	inline bool get_allowDynamicResolution_16() const { return ___allowDynamicResolution_16; }
	inline bool* get_address_of_allowDynamicResolution_16() { return &___allowDynamicResolution_16; }
	inline void set_allowDynamicResolution_16(bool value)
	{
		___allowDynamicResolution_16 = value;
	}

	inline static int32_t get_offset_of_targetDisplay_17() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___targetDisplay_17)); }
	inline int32_t get_targetDisplay_17() const { return ___targetDisplay_17; }
	inline int32_t* get_address_of_targetDisplay_17() { return &___targetDisplay_17; }
	inline void set_targetDisplay_17(int32_t value)
	{
		___targetDisplay_17 = value;
	}

	inline static int32_t get_offset_of_targetLKG_18() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___targetLKG_18)); }
	inline int32_t get_targetLKG_18() const { return ___targetLKG_18; }
	inline int32_t* get_address_of_targetLKG_18() { return &___targetLKG_18; }
	inline void set_targetLKG_18(int32_t value)
	{
		___targetLKG_18 = value;
	}

	inline static int32_t get_offset_of_preview2D_19() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___preview2D_19)); }
	inline bool get_preview2D_19() const { return ___preview2D_19; }
	inline bool* get_address_of_preview2D_19() { return &___preview2D_19; }
	inline void set_preview2D_19(bool value)
	{
		___preview2D_19 = value;
	}

	inline static int32_t get_offset_of_fov_20() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___fov_20)); }
	inline float get_fov_20() const { return ___fov_20; }
	inline float* get_address_of_fov_20() { return &___fov_20; }
	inline void set_fov_20(float value)
	{
		___fov_20 = value;
	}

	inline static int32_t get_offset_of_nearClipFactor_21() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___nearClipFactor_21)); }
	inline float get_nearClipFactor_21() const { return ___nearClipFactor_21; }
	inline float* get_address_of_nearClipFactor_21() { return &___nearClipFactor_21; }
	inline void set_nearClipFactor_21(float value)
	{
		___nearClipFactor_21 = value;
	}

	inline static int32_t get_offset_of_farClipFactor_22() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___farClipFactor_22)); }
	inline float get_farClipFactor_22() const { return ___farClipFactor_22; }
	inline float* get_address_of_farClipFactor_22() { return &___farClipFactor_22; }
	inline void set_farClipFactor_22(float value)
	{
		___farClipFactor_22 = value;
	}

	inline static int32_t get_offset_of_scaleFollowsSize_23() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___scaleFollowsSize_23)); }
	inline bool get_scaleFollowsSize_23() const { return ___scaleFollowsSize_23; }
	inline bool* get_address_of_scaleFollowsSize_23() { return &___scaleFollowsSize_23; }
	inline void set_scaleFollowsSize_23(bool value)
	{
		___scaleFollowsSize_23 = value;
	}

	inline static int32_t get_offset_of_viewconeModifier_24() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___viewconeModifier_24)); }
	inline float get_viewconeModifier_24() const { return ___viewconeModifier_24; }
	inline float* get_address_of_viewconeModifier_24() { return &___viewconeModifier_24; }
	inline void set_viewconeModifier_24(float value)
	{
		___viewconeModifier_24 = value;
	}

	inline static int32_t get_offset_of_centerOffset_25() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___centerOffset_25)); }
	inline float get_centerOffset_25() const { return ___centerOffset_25; }
	inline float* get_address_of_centerOffset_25() { return &___centerOffset_25; }
	inline void set_centerOffset_25(float value)
	{
		___centerOffset_25 = value;
	}

	inline static int32_t get_offset_of_horizontalFrustumOffset_26() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___horizontalFrustumOffset_26)); }
	inline float get_horizontalFrustumOffset_26() const { return ___horizontalFrustumOffset_26; }
	inline float* get_address_of_horizontalFrustumOffset_26() { return &___horizontalFrustumOffset_26; }
	inline void set_horizontalFrustumOffset_26(float value)
	{
		___horizontalFrustumOffset_26 = value;
	}

	inline static int32_t get_offset_of_verticalFrustumOffset_27() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___verticalFrustumOffset_27)); }
	inline float get_verticalFrustumOffset_27() const { return ___verticalFrustumOffset_27; }
	inline float* get_address_of_verticalFrustumOffset_27() { return &___verticalFrustumOffset_27; }
	inline void set_verticalFrustumOffset_27(float value)
	{
		___verticalFrustumOffset_27 = value;
	}

	inline static int32_t get_offset_of_useFrustumTarget_28() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___useFrustumTarget_28)); }
	inline bool get_useFrustumTarget_28() const { return ___useFrustumTarget_28; }
	inline bool* get_address_of_useFrustumTarget_28() { return &___useFrustumTarget_28; }
	inline void set_useFrustumTarget_28(bool value)
	{
		___useFrustumTarget_28 = value;
	}

	inline static int32_t get_offset_of_frustumTarget_29() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___frustumTarget_29)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_frustumTarget_29() const { return ___frustumTarget_29; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_frustumTarget_29() { return &___frustumTarget_29; }
	inline void set_frustumTarget_29(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___frustumTarget_29 = value;
		Il2CppCodeGenWriteBarrier((&___frustumTarget_29), value);
	}

	inline static int32_t get_offset_of_quiltPreset_30() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___quiltPreset_30)); }
	inline int32_t get_quiltPreset_30() const { return ___quiltPreset_30; }
	inline int32_t* get_address_of_quiltPreset_30() { return &___quiltPreset_30; }
	inline void set_quiltPreset_30(int32_t value)
	{
		___quiltPreset_30 = value;
	}

	inline static int32_t get_offset_of_customQuiltSettings_31() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___customQuiltSettings_31)); }
	inline Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46  get_customQuiltSettings_31() const { return ___customQuiltSettings_31; }
	inline Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46 * get_address_of_customQuiltSettings_31() { return &___customQuiltSettings_31; }
	inline void set_customQuiltSettings_31(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46  value)
	{
		___customQuiltSettings_31 = value;
	}

	inline static int32_t get_offset_of_screenshot2DKey_32() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___screenshot2DKey_32)); }
	inline int32_t get_screenshot2DKey_32() const { return ___screenshot2DKey_32; }
	inline int32_t* get_address_of_screenshot2DKey_32() { return &___screenshot2DKey_32; }
	inline void set_screenshot2DKey_32(int32_t value)
	{
		___screenshot2DKey_32 = value;
	}

	inline static int32_t get_offset_of_screenshotQuiltKey_33() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___screenshotQuiltKey_33)); }
	inline int32_t get_screenshotQuiltKey_33() const { return ___screenshotQuiltKey_33; }
	inline int32_t* get_address_of_screenshotQuiltKey_33() { return &___screenshotQuiltKey_33; }
	inline void set_screenshotQuiltKey_33(int32_t value)
	{
		___screenshotQuiltKey_33 = value;
	}

	inline static int32_t get_offset_of_overrideQuilt_34() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___overrideQuilt_34)); }
	inline Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * get_overrideQuilt_34() const { return ___overrideQuilt_34; }
	inline Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 ** get_address_of_overrideQuilt_34() { return &___overrideQuilt_34; }
	inline void set_overrideQuilt_34(Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * value)
	{
		___overrideQuilt_34 = value;
		Il2CppCodeGenWriteBarrier((&___overrideQuilt_34), value);
	}

	inline static int32_t get_offset_of_renderOverrideBehind_35() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___renderOverrideBehind_35)); }
	inline bool get_renderOverrideBehind_35() const { return ___renderOverrideBehind_35; }
	inline bool* get_address_of_renderOverrideBehind_35() { return &___renderOverrideBehind_35; }
	inline void set_renderOverrideBehind_35(bool value)
	{
		___renderOverrideBehind_35 = value;
	}

	inline static int32_t get_offset_of_quiltRT_36() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___quiltRT_36)); }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * get_quiltRT_36() const { return ___quiltRT_36; }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 ** get_address_of_quiltRT_36() { return &___quiltRT_36; }
	inline void set_quiltRT_36(RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * value)
	{
		___quiltRT_36 = value;
		Il2CppCodeGenWriteBarrier((&___quiltRT_36), value);
	}

	inline static int32_t get_offset_of_lightfieldMat_37() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___lightfieldMat_37)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_lightfieldMat_37() const { return ___lightfieldMat_37; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_lightfieldMat_37() { return &___lightfieldMat_37; }
	inline void set_lightfieldMat_37(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___lightfieldMat_37 = value;
		Il2CppCodeGenWriteBarrier((&___lightfieldMat_37), value);
	}

	inline static int32_t get_offset_of_frustumColor_38() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___frustumColor_38)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_frustumColor_38() const { return ___frustumColor_38; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_frustumColor_38() { return &___frustumColor_38; }
	inline void set_frustumColor_38(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___frustumColor_38 = value;
	}

	inline static int32_t get_offset_of_middlePlaneColor_39() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___middlePlaneColor_39)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_middlePlaneColor_39() const { return ___middlePlaneColor_39; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_middlePlaneColor_39() { return &___middlePlaneColor_39; }
	inline void set_middlePlaneColor_39(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___middlePlaneColor_39 = value;
	}

	inline static int32_t get_offset_of_handleColor_40() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___handleColor_40)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_handleColor_40() const { return ___handleColor_40; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_handleColor_40() { return &___handleColor_40; }
	inline void set_handleColor_40(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___handleColor_40 = value;
	}

	inline static int32_t get_offset_of_drawHandles_41() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___drawHandles_41)); }
	inline bool get_drawHandles_41() const { return ___drawHandles_41; }
	inline bool* get_address_of_drawHandles_41() { return &___drawHandles_41; }
	inline void set_drawHandles_41(bool value)
	{
		___drawHandles_41 = value;
	}

	inline static int32_t get_offset_of_cornerDists_42() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___cornerDists_42)); }
	inline SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* get_cornerDists_42() const { return ___cornerDists_42; }
	inline SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5** get_address_of_cornerDists_42() { return &___cornerDists_42; }
	inline void set_cornerDists_42(SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* value)
	{
		___cornerDists_42 = value;
		Il2CppCodeGenWriteBarrier((&___cornerDists_42), value);
	}

	inline static int32_t get_offset_of_frustumCorners_43() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___frustumCorners_43)); }
	inline Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28* get_frustumCorners_43() const { return ___frustumCorners_43; }
	inline Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28** get_address_of_frustumCorners_43() { return &___frustumCorners_43; }
	inline void set_frustumCorners_43(Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28* value)
	{
		___frustumCorners_43 = value;
		Il2CppCodeGenWriteBarrier((&___frustumCorners_43), value);
	}

	inline static int32_t get_offset_of_onHoloplayReady_44() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___onHoloplayReady_44)); }
	inline LoadEvent_tE7ACDCDE718293339A984D1E678134087257D727 * get_onHoloplayReady_44() const { return ___onHoloplayReady_44; }
	inline LoadEvent_tE7ACDCDE718293339A984D1E678134087257D727 ** get_address_of_onHoloplayReady_44() { return &___onHoloplayReady_44; }
	inline void set_onHoloplayReady_44(LoadEvent_tE7ACDCDE718293339A984D1E678134087257D727 * value)
	{
		___onHoloplayReady_44 = value;
		Il2CppCodeGenWriteBarrier((&___onHoloplayReady_44), value);
	}

	inline static int32_t get_offset_of_loadResults_45() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___loadResults_45)); }
	inline LoadResults_t3028A604D8ED7E35E4316051844BAEECE1930F02  get_loadResults_45() const { return ___loadResults_45; }
	inline LoadResults_t3028A604D8ED7E35E4316051844BAEECE1930F02 * get_address_of_loadResults_45() { return &___loadResults_45; }
	inline void set_loadResults_45(LoadResults_t3028A604D8ED7E35E4316051844BAEECE1930F02  value)
	{
		___loadResults_45 = value;
	}

	inline static int32_t get_offset_of_onViewRender_46() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___onViewRender_46)); }
	inline ViewRenderEvent_t8A52588044E632F42B64DC1EE219DC39E0DA957C * get_onViewRender_46() const { return ___onViewRender_46; }
	inline ViewRenderEvent_t8A52588044E632F42B64DC1EE219DC39E0DA957C ** get_address_of_onViewRender_46() { return &___onViewRender_46; }
	inline void set_onViewRender_46(ViewRenderEvent_t8A52588044E632F42B64DC1EE219DC39E0DA957C * value)
	{
		___onViewRender_46 = value;
		Il2CppCodeGenWriteBarrier((&___onViewRender_46), value);
	}

	inline static int32_t get_offset_of_viewInterpolation_47() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___viewInterpolation_47)); }
	inline int32_t get_viewInterpolation_47() const { return ___viewInterpolation_47; }
	inline int32_t* get_address_of_viewInterpolation_47() { return &___viewInterpolation_47; }
	inline void set_viewInterpolation_47(int32_t value)
	{
		___viewInterpolation_47 = value;
	}

	inline static int32_t get_offset_of_reduceFlicker_48() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___reduceFlicker_48)); }
	inline bool get_reduceFlicker_48() const { return ___reduceFlicker_48; }
	inline bool* get_address_of_reduceFlicker_48() { return &___reduceFlicker_48; }
	inline void set_reduceFlicker_48(bool value)
	{
		___reduceFlicker_48 = value;
	}

	inline static int32_t get_offset_of_fillGaps_49() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___fillGaps_49)); }
	inline bool get_fillGaps_49() const { return ___fillGaps_49; }
	inline bool* get_address_of_fillGaps_49() { return &___fillGaps_49; }
	inline void set_fillGaps_49(bool value)
	{
		___fillGaps_49 = value;
	}

	inline static int32_t get_offset_of_blendViews_50() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___blendViews_50)); }
	inline bool get_blendViews_50() const { return ___blendViews_50; }
	inline bool* get_address_of_blendViews_50() { return &___blendViews_50; }
	inline void set_blendViews_50(bool value)
	{
		___blendViews_50 = value;
	}

	inline static int32_t get_offset_of_interpolationComputeShader_51() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___interpolationComputeShader_51)); }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * get_interpolationComputeShader_51() const { return ___interpolationComputeShader_51; }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A ** get_address_of_interpolationComputeShader_51() { return &___interpolationComputeShader_51; }
	inline void set_interpolationComputeShader_51(ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * value)
	{
		___interpolationComputeShader_51 = value;
		Il2CppCodeGenWriteBarrier((&___interpolationComputeShader_51), value);
	}

	inline static int32_t get_offset_of_cam_52() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___cam_52)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get_cam_52() const { return ___cam_52; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of_cam_52() { return &___cam_52; }
	inline void set_cam_52(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		___cam_52 = value;
		Il2CppCodeGenWriteBarrier((&___cam_52), value);
	}

	inline static int32_t get_offset_of_postProcessCam_53() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___postProcessCam_53)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get_postProcessCam_53() const { return ___postProcessCam_53; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of_postProcessCam_53() { return &___postProcessCam_53; }
	inline void set_postProcessCam_53(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		___postProcessCam_53 = value;
		Il2CppCodeGenWriteBarrier((&___postProcessCam_53), value);
	}

	inline static int32_t get_offset_of_lightfieldCam_54() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___lightfieldCam_54)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get_lightfieldCam_54() const { return ___lightfieldCam_54; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of_lightfieldCam_54() { return &___lightfieldCam_54; }
	inline void set_lightfieldCam_54(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		___lightfieldCam_54 = value;
		Il2CppCodeGenWriteBarrier((&___lightfieldCam_54), value);
	}

	inline static int32_t get_offset_of_cal_57() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___cal_57)); }
	inline Calibration_t9AB78454E6D4068384FB24A31465696019A429D0  get_cal_57() const { return ___cal_57; }
	inline Calibration_t9AB78454E6D4068384FB24A31465696019A429D0 * get_address_of_cal_57() { return &___cal_57; }
	inline void set_cal_57(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0  value)
	{
		___cal_57 = value;
	}

	inline static int32_t get_offset_of_frameRendered_58() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___frameRendered_58)); }
	inline bool get_frameRendered_58() const { return ___frameRendered_58; }
	inline bool* get_address_of_frameRendered_58() { return &___frameRendered_58; }
	inline void set_frameRendered_58(bool value)
	{
		___frameRendered_58 = value;
	}

	inline static int32_t get_offset_of_camDist_59() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___camDist_59)); }
	inline float get_camDist_59() const { return ___camDist_59; }
	inline float* get_address_of_camDist_59() { return &___camDist_59; }
	inline void set_camDist_59(float value)
	{
		___camDist_59 = value;
	}

	inline static int32_t get_offset_of_debugInfo_60() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A, ___debugInfo_60)); }
	inline bool get_debugInfo_60() const { return ___debugInfo_60; }
	inline bool* get_address_of_debugInfo_60() { return &___debugInfo_60; }
	inline void set_debugInfo_60(bool value)
	{
		___debugInfo_60 = value;
	}
};

struct Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A_StaticFields
{
public:
	// LookingGlass.Holoplay LookingGlass.Holoplay::instance
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * ___instance_4;
	// System.Version LookingGlass.Holoplay::version
	Version_tDBE6876C59B6F56D4F8CAA03851177ABC6FE0DFD * ___version_5;

public:
	inline static int32_t get_offset_of_instance_4() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A_StaticFields, ___instance_4)); }
	inline Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * get_instance_4() const { return ___instance_4; }
	inline Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A ** get_address_of_instance_4() { return &___instance_4; }
	inline void set_instance_4(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * value)
	{
		___instance_4 = value;
		Il2CppCodeGenWriteBarrier((&___instance_4), value);
	}

	inline static int32_t get_offset_of_version_5() { return static_cast<int32_t>(offsetof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A_StaticFields, ___version_5)); }
	inline Version_tDBE6876C59B6F56D4F8CAA03851177ABC6FE0DFD * get_version_5() const { return ___version_5; }
	inline Version_tDBE6876C59B6F56D4F8CAA03851177ABC6FE0DFD ** get_address_of_version_5() { return &___version_5; }
	inline void set_version_5(Version_tDBE6876C59B6F56D4F8CAA03851177ABC6FE0DFD * value)
	{
		___version_5 = value;
		Il2CppCodeGenWriteBarrier((&___version_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HOLOPLAY_TE1D6BDF468D366341C53CDEAB3828B4ADF11A98A_H
#ifndef LIGHTFIELDPOSTPROCESS_T3AB37CE5BAC845BD9D2ECACEF447239C11AFCB49_H
#define LIGHTFIELDPOSTPROCESS_T3AB37CE5BAC845BD9D2ECACEF447239C11AFCB49_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.LightfieldPostProcess
struct  LightfieldPostProcess_t3AB37CE5BAC845BD9D2ECACEF447239C11AFCB49  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// LookingGlass.Holoplay LookingGlass.LightfieldPostProcess::holoplay
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * ___holoplay_4;

public:
	inline static int32_t get_offset_of_holoplay_4() { return static_cast<int32_t>(offsetof(LightfieldPostProcess_t3AB37CE5BAC845BD9D2ECACEF447239C11AFCB49, ___holoplay_4)); }
	inline Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * get_holoplay_4() const { return ___holoplay_4; }
	inline Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A ** get_address_of_holoplay_4() { return &___holoplay_4; }
	inline void set_holoplay_4(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * value)
	{
		___holoplay_4 = value;
		Il2CppCodeGenWriteBarrier((&___holoplay_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIGHTFIELDPOSTPROCESS_T3AB37CE5BAC845BD9D2ECACEF447239C11AFCB49_H
#ifndef MULTIPLEX_T3E93A908DD482C9CF94DEB9AA50C7E9DC575732F_H
#define MULTIPLEX_T3E93A908DD482C9CF94DEB9AA50C7E9DC575732F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Multiplex
struct  Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Boolean LookingGlass.Multiplex::automaticArrangement
	bool ___automaticArrangement_4;
	// System.Int32 LookingGlass.Multiplex::columns
	int32_t ___columns_5;
	// System.Int32 LookingGlass.Multiplex::rows
	int32_t ___rows_6;
	// System.Single LookingGlass.Multiplex::size
	float ___size_7;
	// System.Single LookingGlass.Multiplex::separation
	float ___separation_8;
	// LookingGlass.Holoplay[] LookingGlass.Multiplex::holoplays
	HoloplayU5BU5D_t87CF66265BEF411B8D2B7F3F8EB6DBA48A1900BD* ___holoplays_9;
	// System.Single LookingGlass.Multiplex::frustumShifting
	float ___frustumShifting_10;
	// System.Boolean LookingGlass.Multiplex::showUpdateWarning
	bool ___showUpdateWarning_11;
	// System.Boolean LookingGlass.Multiplex::initialSetup
	bool ___initialSetup_12;

public:
	inline static int32_t get_offset_of_automaticArrangement_4() { return static_cast<int32_t>(offsetof(Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F, ___automaticArrangement_4)); }
	inline bool get_automaticArrangement_4() const { return ___automaticArrangement_4; }
	inline bool* get_address_of_automaticArrangement_4() { return &___automaticArrangement_4; }
	inline void set_automaticArrangement_4(bool value)
	{
		___automaticArrangement_4 = value;
	}

	inline static int32_t get_offset_of_columns_5() { return static_cast<int32_t>(offsetof(Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F, ___columns_5)); }
	inline int32_t get_columns_5() const { return ___columns_5; }
	inline int32_t* get_address_of_columns_5() { return &___columns_5; }
	inline void set_columns_5(int32_t value)
	{
		___columns_5 = value;
	}

	inline static int32_t get_offset_of_rows_6() { return static_cast<int32_t>(offsetof(Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F, ___rows_6)); }
	inline int32_t get_rows_6() const { return ___rows_6; }
	inline int32_t* get_address_of_rows_6() { return &___rows_6; }
	inline void set_rows_6(int32_t value)
	{
		___rows_6 = value;
	}

	inline static int32_t get_offset_of_size_7() { return static_cast<int32_t>(offsetof(Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F, ___size_7)); }
	inline float get_size_7() const { return ___size_7; }
	inline float* get_address_of_size_7() { return &___size_7; }
	inline void set_size_7(float value)
	{
		___size_7 = value;
	}

	inline static int32_t get_offset_of_separation_8() { return static_cast<int32_t>(offsetof(Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F, ___separation_8)); }
	inline float get_separation_8() const { return ___separation_8; }
	inline float* get_address_of_separation_8() { return &___separation_8; }
	inline void set_separation_8(float value)
	{
		___separation_8 = value;
	}

	inline static int32_t get_offset_of_holoplays_9() { return static_cast<int32_t>(offsetof(Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F, ___holoplays_9)); }
	inline HoloplayU5BU5D_t87CF66265BEF411B8D2B7F3F8EB6DBA48A1900BD* get_holoplays_9() const { return ___holoplays_9; }
	inline HoloplayU5BU5D_t87CF66265BEF411B8D2B7F3F8EB6DBA48A1900BD** get_address_of_holoplays_9() { return &___holoplays_9; }
	inline void set_holoplays_9(HoloplayU5BU5D_t87CF66265BEF411B8D2B7F3F8EB6DBA48A1900BD* value)
	{
		___holoplays_9 = value;
		Il2CppCodeGenWriteBarrier((&___holoplays_9), value);
	}

	inline static int32_t get_offset_of_frustumShifting_10() { return static_cast<int32_t>(offsetof(Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F, ___frustumShifting_10)); }
	inline float get_frustumShifting_10() const { return ___frustumShifting_10; }
	inline float* get_address_of_frustumShifting_10() { return &___frustumShifting_10; }
	inline void set_frustumShifting_10(float value)
	{
		___frustumShifting_10 = value;
	}

	inline static int32_t get_offset_of_showUpdateWarning_11() { return static_cast<int32_t>(offsetof(Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F, ___showUpdateWarning_11)); }
	inline bool get_showUpdateWarning_11() const { return ___showUpdateWarning_11; }
	inline bool* get_address_of_showUpdateWarning_11() { return &___showUpdateWarning_11; }
	inline void set_showUpdateWarning_11(bool value)
	{
		___showUpdateWarning_11 = value;
	}

	inline static int32_t get_offset_of_initialSetup_12() { return static_cast<int32_t>(offsetof(Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F, ___initialSetup_12)); }
	inline bool get_initialSetup_12() const { return ___initialSetup_12; }
	inline bool* get_address_of_initialSetup_12() { return &___initialSetup_12; }
	inline void set_initialSetup_12(bool value)
	{
		___initialSetup_12 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MULTIPLEX_T3E93A908DD482C9CF94DEB9AA50C7E9DC575732F_H
#ifndef MENUSCRIPT_T9CD076A38B78730719E72CE473E966D0194B7B66_H
#define MENUSCRIPT_T9CD076A38B78730719E72CE473E966D0194B7B66_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// MenuScript
struct  MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.RectTransform MenuScript::_StartMenu
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ____StartMenu_5;
	// UnityEngine.UI.Button MenuScript::_ButtonMenu
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ____ButtonMenu_6;

public:
	inline static int32_t get_offset_of__StartMenu_5() { return static_cast<int32_t>(offsetof(MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66, ____StartMenu_5)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get__StartMenu_5() const { return ____StartMenu_5; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of__StartMenu_5() { return &____StartMenu_5; }
	inline void set__StartMenu_5(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		____StartMenu_5 = value;
		Il2CppCodeGenWriteBarrier((&____StartMenu_5), value);
	}

	inline static int32_t get_offset_of__ButtonMenu_6() { return static_cast<int32_t>(offsetof(MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66, ____ButtonMenu_6)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get__ButtonMenu_6() const { return ____ButtonMenu_6; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of__ButtonMenu_6() { return &____ButtonMenu_6; }
	inline void set__ButtonMenu_6(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		____ButtonMenu_6 = value;
		Il2CppCodeGenWriteBarrier((&____ButtonMenu_6), value);
	}
};

struct MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66_StaticFields
{
public:
	// System.Boolean MenuScript::sCreated
	bool ___sCreated_4;

public:
	inline static int32_t get_offset_of_sCreated_4() { return static_cast<int32_t>(offsetof(MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66_StaticFields, ___sCreated_4)); }
	inline bool get_sCreated_4() const { return ___sCreated_4; }
	inline bool* get_address_of_sCreated_4() { return &___sCreated_4; }
	inline void set_sCreated_4(bool value)
	{
		___sCreated_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MENUSCRIPT_T9CD076A38B78730719E72CE473E966D0194B7B66_H
#ifndef MESSAGELIST_TD66AFF3FCD283ACC670373072314E87D442C19DC_H
#define MESSAGELIST_TD66AFF3FCD283ACC670373072314E87D442C19DC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// MessageList
struct  MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject MessageList::uEntryPrefab
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___uEntryPrefab_4;
	// UnityEngine.RectTransform MessageList::mOwnTransform
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___mOwnTransform_5;
	// System.Int32 MessageList::mMaxMessages
	int32_t ___mMaxMessages_6;
	// System.Int32 MessageList::mCounter
	int32_t ___mCounter_7;

public:
	inline static int32_t get_offset_of_uEntryPrefab_4() { return static_cast<int32_t>(offsetof(MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC, ___uEntryPrefab_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_uEntryPrefab_4() const { return ___uEntryPrefab_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_uEntryPrefab_4() { return &___uEntryPrefab_4; }
	inline void set_uEntryPrefab_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___uEntryPrefab_4 = value;
		Il2CppCodeGenWriteBarrier((&___uEntryPrefab_4), value);
	}

	inline static int32_t get_offset_of_mOwnTransform_5() { return static_cast<int32_t>(offsetof(MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC, ___mOwnTransform_5)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_mOwnTransform_5() const { return ___mOwnTransform_5; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_mOwnTransform_5() { return &___mOwnTransform_5; }
	inline void set_mOwnTransform_5(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___mOwnTransform_5 = value;
		Il2CppCodeGenWriteBarrier((&___mOwnTransform_5), value);
	}

	inline static int32_t get_offset_of_mMaxMessages_6() { return static_cast<int32_t>(offsetof(MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC, ___mMaxMessages_6)); }
	inline int32_t get_mMaxMessages_6() const { return ___mMaxMessages_6; }
	inline int32_t* get_address_of_mMaxMessages_6() { return &___mMaxMessages_6; }
	inline void set_mMaxMessages_6(int32_t value)
	{
		___mMaxMessages_6 = value;
	}

	inline static int32_t get_offset_of_mCounter_7() { return static_cast<int32_t>(offsetof(MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC, ___mCounter_7)); }
	inline int32_t get_mCounter_7() const { return ___mCounter_7; }
	inline int32_t* get_address_of_mCounter_7() { return &___mCounter_7; }
	inline void set_mCounter_7(int32_t value)
	{
		___mCounter_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MESSAGELIST_TD66AFF3FCD283ACC670373072314E87D442C19DC_H
#ifndef ORBITCONTROL_T92EB06513B807BC8317734058465878739EBA84A_H
#define ORBITCONTROL_T92EB06513B807BC8317734058465878739EBA84A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// OrbitControl
struct  OrbitControl_t92EB06513B807BC8317734058465878739EBA84A  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Boolean OrbitControl::touchInputThisFrame
	bool ___touchInputThisFrame_5;
	// UnityEngine.Vector2 OrbitControl::rMomentum
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___rMomentum_6;
	// UnityEngine.Vector3 OrbitControl::rLastPos
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___rLastPos_7;
	// System.Single OrbitControl::rotateSpeed
	float ___rotateSpeed_8;
	// System.Single OrbitControl::rotateDrag
	float ___rotateDrag_9;
	// System.Single OrbitControl::yMax
	float ___yMax_10;
	// System.Single OrbitControl::yMin
	float ___yMin_11;
	// UnityEngine.Vector2 OrbitControl::pMomentum
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___pMomentum_12;
	// UnityEngine.Vector3 OrbitControl::pLastPos
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___pLastPos_13;
	// System.Single OrbitControl::panSpeed
	float ___panSpeed_14;
	// System.Single OrbitControl::panDrag
	float ___panDrag_15;
	// System.Single OrbitControl::zMomentum
	float ___zMomentum_16;
	// System.Single OrbitControl::zLastYPos
	float ___zLastYPos_17;
	// System.Single OrbitControl::mouseZoomSpeed
	float ___mouseZoomSpeed_18;
	// System.Single OrbitControl::multitouchZoomSpeed
	float ___multitouchZoomSpeed_19;
	// System.Single OrbitControl::zoomDrag
	float ___zoomDrag_20;
	// System.Single OrbitControl::multitouchZoomThreshold
	float ___multitouchZoomThreshold_21;
	// System.Single OrbitControl::multitouchMaxJump
	float ___multitouchMaxJump_22;
	// System.Single OrbitControl::minHoloplaySize
	float ___minHoloplaySize_23;
	// System.Single OrbitControl::maxHoloplaySize
	float ___maxHoloplaySize_24;
	// System.Boolean OrbitControl::validRotationStart
	bool ___validRotationStart_25;
	// System.Boolean OrbitControl::refocusingToPosition
	bool ___refocusingToPosition_26;
	// UnityEngine.Vector3 OrbitControl::refocusToPosition
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___refocusToPosition_27;
	// UnityEngine.Vector3 OrbitControl::startRefocusPosition
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___startRefocusPosition_28;
	// UnityEngine.AnimationCurve OrbitControl::refocusToPointCurve
	AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * ___refocusToPointCurve_29;
	// System.Single OrbitControl::refocusToTime
	float ___refocusToTime_30;
	// System.Single OrbitControl::maxDistBetweenClicksMouse
	float ___maxDistBetweenClicksMouse_31;
	// System.Single OrbitControl::maxDistBetweenClicksTouch
	float ___maxDistBetweenClicksTouch_32;
	// System.Single OrbitControl::doubleClickTime
	float ___doubleClickTime_33;
	// System.Single OrbitControl::doubleClickTimeTouch
	float ___doubleClickTimeTouch_34;
	// System.Single OrbitControl::doubleClickTimer
	float ___doubleClickTimer_35;
	// System.Single OrbitControl::refocusToTimer
	float ___refocusToTimer_36;
	// System.Boolean OrbitControl::oneClick
	bool ___oneClick_37;
	// System.Boolean OrbitControl::oneTouch
	bool ___oneTouch_38;
	// UnityEngine.Vector3 OrbitControl::oneClickPos
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___oneClickPos_39;
	// UnityEngine.EventSystems.EventSystem OrbitControl::eventSys
	EventSystem_t06ACEF1C8D95D44D3A7F57ED4BAA577101B4EA77 * ___eventSys_40;
	// System.Boolean OrbitControl::canInteract
	bool ___canInteract_41;
	// UnityEngine.Vector2 OrbitControl::multitouchRemapCursorY
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___multitouchRemapCursorY_42;
	// UnityEngine.Vector2 OrbitControl::multitouchRemapCursorX
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___multitouchRemapCursorX_43;
	// UnityEngine.Vector2[] OrbitControl::lastTouchPositions
	Vector2U5BU5D_tA065A07DFC060C1B8786BBAA5F3A6577CCEB27D6* ___lastTouchPositions_44;
	// UnityEngine.Renderer OrbitControl::cursorRend
	Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 * ___cursorRend_45;
	// UnityEngine.Vector3 OrbitControl::mousePosOnTouchEnd
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___mousePosOnTouchEnd_46;

public:
	inline static int32_t get_offset_of_touchInputThisFrame_5() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___touchInputThisFrame_5)); }
	inline bool get_touchInputThisFrame_5() const { return ___touchInputThisFrame_5; }
	inline bool* get_address_of_touchInputThisFrame_5() { return &___touchInputThisFrame_5; }
	inline void set_touchInputThisFrame_5(bool value)
	{
		___touchInputThisFrame_5 = value;
	}

	inline static int32_t get_offset_of_rMomentum_6() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___rMomentum_6)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_rMomentum_6() const { return ___rMomentum_6; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_rMomentum_6() { return &___rMomentum_6; }
	inline void set_rMomentum_6(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___rMomentum_6 = value;
	}

	inline static int32_t get_offset_of_rLastPos_7() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___rLastPos_7)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_rLastPos_7() const { return ___rLastPos_7; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_rLastPos_7() { return &___rLastPos_7; }
	inline void set_rLastPos_7(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___rLastPos_7 = value;
	}

	inline static int32_t get_offset_of_rotateSpeed_8() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___rotateSpeed_8)); }
	inline float get_rotateSpeed_8() const { return ___rotateSpeed_8; }
	inline float* get_address_of_rotateSpeed_8() { return &___rotateSpeed_8; }
	inline void set_rotateSpeed_8(float value)
	{
		___rotateSpeed_8 = value;
	}

	inline static int32_t get_offset_of_rotateDrag_9() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___rotateDrag_9)); }
	inline float get_rotateDrag_9() const { return ___rotateDrag_9; }
	inline float* get_address_of_rotateDrag_9() { return &___rotateDrag_9; }
	inline void set_rotateDrag_9(float value)
	{
		___rotateDrag_9 = value;
	}

	inline static int32_t get_offset_of_yMax_10() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___yMax_10)); }
	inline float get_yMax_10() const { return ___yMax_10; }
	inline float* get_address_of_yMax_10() { return &___yMax_10; }
	inline void set_yMax_10(float value)
	{
		___yMax_10 = value;
	}

	inline static int32_t get_offset_of_yMin_11() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___yMin_11)); }
	inline float get_yMin_11() const { return ___yMin_11; }
	inline float* get_address_of_yMin_11() { return &___yMin_11; }
	inline void set_yMin_11(float value)
	{
		___yMin_11 = value;
	}

	inline static int32_t get_offset_of_pMomentum_12() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___pMomentum_12)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_pMomentum_12() const { return ___pMomentum_12; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_pMomentum_12() { return &___pMomentum_12; }
	inline void set_pMomentum_12(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___pMomentum_12 = value;
	}

	inline static int32_t get_offset_of_pLastPos_13() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___pLastPos_13)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_pLastPos_13() const { return ___pLastPos_13; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_pLastPos_13() { return &___pLastPos_13; }
	inline void set_pLastPos_13(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___pLastPos_13 = value;
	}

	inline static int32_t get_offset_of_panSpeed_14() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___panSpeed_14)); }
	inline float get_panSpeed_14() const { return ___panSpeed_14; }
	inline float* get_address_of_panSpeed_14() { return &___panSpeed_14; }
	inline void set_panSpeed_14(float value)
	{
		___panSpeed_14 = value;
	}

	inline static int32_t get_offset_of_panDrag_15() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___panDrag_15)); }
	inline float get_panDrag_15() const { return ___panDrag_15; }
	inline float* get_address_of_panDrag_15() { return &___panDrag_15; }
	inline void set_panDrag_15(float value)
	{
		___panDrag_15 = value;
	}

	inline static int32_t get_offset_of_zMomentum_16() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___zMomentum_16)); }
	inline float get_zMomentum_16() const { return ___zMomentum_16; }
	inline float* get_address_of_zMomentum_16() { return &___zMomentum_16; }
	inline void set_zMomentum_16(float value)
	{
		___zMomentum_16 = value;
	}

	inline static int32_t get_offset_of_zLastYPos_17() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___zLastYPos_17)); }
	inline float get_zLastYPos_17() const { return ___zLastYPos_17; }
	inline float* get_address_of_zLastYPos_17() { return &___zLastYPos_17; }
	inline void set_zLastYPos_17(float value)
	{
		___zLastYPos_17 = value;
	}

	inline static int32_t get_offset_of_mouseZoomSpeed_18() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___mouseZoomSpeed_18)); }
	inline float get_mouseZoomSpeed_18() const { return ___mouseZoomSpeed_18; }
	inline float* get_address_of_mouseZoomSpeed_18() { return &___mouseZoomSpeed_18; }
	inline void set_mouseZoomSpeed_18(float value)
	{
		___mouseZoomSpeed_18 = value;
	}

	inline static int32_t get_offset_of_multitouchZoomSpeed_19() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___multitouchZoomSpeed_19)); }
	inline float get_multitouchZoomSpeed_19() const { return ___multitouchZoomSpeed_19; }
	inline float* get_address_of_multitouchZoomSpeed_19() { return &___multitouchZoomSpeed_19; }
	inline void set_multitouchZoomSpeed_19(float value)
	{
		___multitouchZoomSpeed_19 = value;
	}

	inline static int32_t get_offset_of_zoomDrag_20() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___zoomDrag_20)); }
	inline float get_zoomDrag_20() const { return ___zoomDrag_20; }
	inline float* get_address_of_zoomDrag_20() { return &___zoomDrag_20; }
	inline void set_zoomDrag_20(float value)
	{
		___zoomDrag_20 = value;
	}

	inline static int32_t get_offset_of_multitouchZoomThreshold_21() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___multitouchZoomThreshold_21)); }
	inline float get_multitouchZoomThreshold_21() const { return ___multitouchZoomThreshold_21; }
	inline float* get_address_of_multitouchZoomThreshold_21() { return &___multitouchZoomThreshold_21; }
	inline void set_multitouchZoomThreshold_21(float value)
	{
		___multitouchZoomThreshold_21 = value;
	}

	inline static int32_t get_offset_of_multitouchMaxJump_22() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___multitouchMaxJump_22)); }
	inline float get_multitouchMaxJump_22() const { return ___multitouchMaxJump_22; }
	inline float* get_address_of_multitouchMaxJump_22() { return &___multitouchMaxJump_22; }
	inline void set_multitouchMaxJump_22(float value)
	{
		___multitouchMaxJump_22 = value;
	}

	inline static int32_t get_offset_of_minHoloplaySize_23() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___minHoloplaySize_23)); }
	inline float get_minHoloplaySize_23() const { return ___minHoloplaySize_23; }
	inline float* get_address_of_minHoloplaySize_23() { return &___minHoloplaySize_23; }
	inline void set_minHoloplaySize_23(float value)
	{
		___minHoloplaySize_23 = value;
	}

	inline static int32_t get_offset_of_maxHoloplaySize_24() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___maxHoloplaySize_24)); }
	inline float get_maxHoloplaySize_24() const { return ___maxHoloplaySize_24; }
	inline float* get_address_of_maxHoloplaySize_24() { return &___maxHoloplaySize_24; }
	inline void set_maxHoloplaySize_24(float value)
	{
		___maxHoloplaySize_24 = value;
	}

	inline static int32_t get_offset_of_validRotationStart_25() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___validRotationStart_25)); }
	inline bool get_validRotationStart_25() const { return ___validRotationStart_25; }
	inline bool* get_address_of_validRotationStart_25() { return &___validRotationStart_25; }
	inline void set_validRotationStart_25(bool value)
	{
		___validRotationStart_25 = value;
	}

	inline static int32_t get_offset_of_refocusingToPosition_26() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___refocusingToPosition_26)); }
	inline bool get_refocusingToPosition_26() const { return ___refocusingToPosition_26; }
	inline bool* get_address_of_refocusingToPosition_26() { return &___refocusingToPosition_26; }
	inline void set_refocusingToPosition_26(bool value)
	{
		___refocusingToPosition_26 = value;
	}

	inline static int32_t get_offset_of_refocusToPosition_27() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___refocusToPosition_27)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_refocusToPosition_27() const { return ___refocusToPosition_27; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_refocusToPosition_27() { return &___refocusToPosition_27; }
	inline void set_refocusToPosition_27(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___refocusToPosition_27 = value;
	}

	inline static int32_t get_offset_of_startRefocusPosition_28() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___startRefocusPosition_28)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_startRefocusPosition_28() const { return ___startRefocusPosition_28; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_startRefocusPosition_28() { return &___startRefocusPosition_28; }
	inline void set_startRefocusPosition_28(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___startRefocusPosition_28 = value;
	}

	inline static int32_t get_offset_of_refocusToPointCurve_29() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___refocusToPointCurve_29)); }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * get_refocusToPointCurve_29() const { return ___refocusToPointCurve_29; }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C ** get_address_of_refocusToPointCurve_29() { return &___refocusToPointCurve_29; }
	inline void set_refocusToPointCurve_29(AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * value)
	{
		___refocusToPointCurve_29 = value;
		Il2CppCodeGenWriteBarrier((&___refocusToPointCurve_29), value);
	}

	inline static int32_t get_offset_of_refocusToTime_30() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___refocusToTime_30)); }
	inline float get_refocusToTime_30() const { return ___refocusToTime_30; }
	inline float* get_address_of_refocusToTime_30() { return &___refocusToTime_30; }
	inline void set_refocusToTime_30(float value)
	{
		___refocusToTime_30 = value;
	}

	inline static int32_t get_offset_of_maxDistBetweenClicksMouse_31() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___maxDistBetweenClicksMouse_31)); }
	inline float get_maxDistBetweenClicksMouse_31() const { return ___maxDistBetweenClicksMouse_31; }
	inline float* get_address_of_maxDistBetweenClicksMouse_31() { return &___maxDistBetweenClicksMouse_31; }
	inline void set_maxDistBetweenClicksMouse_31(float value)
	{
		___maxDistBetweenClicksMouse_31 = value;
	}

	inline static int32_t get_offset_of_maxDistBetweenClicksTouch_32() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___maxDistBetweenClicksTouch_32)); }
	inline float get_maxDistBetweenClicksTouch_32() const { return ___maxDistBetweenClicksTouch_32; }
	inline float* get_address_of_maxDistBetweenClicksTouch_32() { return &___maxDistBetweenClicksTouch_32; }
	inline void set_maxDistBetweenClicksTouch_32(float value)
	{
		___maxDistBetweenClicksTouch_32 = value;
	}

	inline static int32_t get_offset_of_doubleClickTime_33() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___doubleClickTime_33)); }
	inline float get_doubleClickTime_33() const { return ___doubleClickTime_33; }
	inline float* get_address_of_doubleClickTime_33() { return &___doubleClickTime_33; }
	inline void set_doubleClickTime_33(float value)
	{
		___doubleClickTime_33 = value;
	}

	inline static int32_t get_offset_of_doubleClickTimeTouch_34() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___doubleClickTimeTouch_34)); }
	inline float get_doubleClickTimeTouch_34() const { return ___doubleClickTimeTouch_34; }
	inline float* get_address_of_doubleClickTimeTouch_34() { return &___doubleClickTimeTouch_34; }
	inline void set_doubleClickTimeTouch_34(float value)
	{
		___doubleClickTimeTouch_34 = value;
	}

	inline static int32_t get_offset_of_doubleClickTimer_35() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___doubleClickTimer_35)); }
	inline float get_doubleClickTimer_35() const { return ___doubleClickTimer_35; }
	inline float* get_address_of_doubleClickTimer_35() { return &___doubleClickTimer_35; }
	inline void set_doubleClickTimer_35(float value)
	{
		___doubleClickTimer_35 = value;
	}

	inline static int32_t get_offset_of_refocusToTimer_36() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___refocusToTimer_36)); }
	inline float get_refocusToTimer_36() const { return ___refocusToTimer_36; }
	inline float* get_address_of_refocusToTimer_36() { return &___refocusToTimer_36; }
	inline void set_refocusToTimer_36(float value)
	{
		___refocusToTimer_36 = value;
	}

	inline static int32_t get_offset_of_oneClick_37() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___oneClick_37)); }
	inline bool get_oneClick_37() const { return ___oneClick_37; }
	inline bool* get_address_of_oneClick_37() { return &___oneClick_37; }
	inline void set_oneClick_37(bool value)
	{
		___oneClick_37 = value;
	}

	inline static int32_t get_offset_of_oneTouch_38() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___oneTouch_38)); }
	inline bool get_oneTouch_38() const { return ___oneTouch_38; }
	inline bool* get_address_of_oneTouch_38() { return &___oneTouch_38; }
	inline void set_oneTouch_38(bool value)
	{
		___oneTouch_38 = value;
	}

	inline static int32_t get_offset_of_oneClickPos_39() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___oneClickPos_39)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_oneClickPos_39() const { return ___oneClickPos_39; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_oneClickPos_39() { return &___oneClickPos_39; }
	inline void set_oneClickPos_39(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___oneClickPos_39 = value;
	}

	inline static int32_t get_offset_of_eventSys_40() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___eventSys_40)); }
	inline EventSystem_t06ACEF1C8D95D44D3A7F57ED4BAA577101B4EA77 * get_eventSys_40() const { return ___eventSys_40; }
	inline EventSystem_t06ACEF1C8D95D44D3A7F57ED4BAA577101B4EA77 ** get_address_of_eventSys_40() { return &___eventSys_40; }
	inline void set_eventSys_40(EventSystem_t06ACEF1C8D95D44D3A7F57ED4BAA577101B4EA77 * value)
	{
		___eventSys_40 = value;
		Il2CppCodeGenWriteBarrier((&___eventSys_40), value);
	}

	inline static int32_t get_offset_of_canInteract_41() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___canInteract_41)); }
	inline bool get_canInteract_41() const { return ___canInteract_41; }
	inline bool* get_address_of_canInteract_41() { return &___canInteract_41; }
	inline void set_canInteract_41(bool value)
	{
		___canInteract_41 = value;
	}

	inline static int32_t get_offset_of_multitouchRemapCursorY_42() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___multitouchRemapCursorY_42)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_multitouchRemapCursorY_42() const { return ___multitouchRemapCursorY_42; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_multitouchRemapCursorY_42() { return &___multitouchRemapCursorY_42; }
	inline void set_multitouchRemapCursorY_42(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___multitouchRemapCursorY_42 = value;
	}

	inline static int32_t get_offset_of_multitouchRemapCursorX_43() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___multitouchRemapCursorX_43)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_multitouchRemapCursorX_43() const { return ___multitouchRemapCursorX_43; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_multitouchRemapCursorX_43() { return &___multitouchRemapCursorX_43; }
	inline void set_multitouchRemapCursorX_43(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___multitouchRemapCursorX_43 = value;
	}

	inline static int32_t get_offset_of_lastTouchPositions_44() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___lastTouchPositions_44)); }
	inline Vector2U5BU5D_tA065A07DFC060C1B8786BBAA5F3A6577CCEB27D6* get_lastTouchPositions_44() const { return ___lastTouchPositions_44; }
	inline Vector2U5BU5D_tA065A07DFC060C1B8786BBAA5F3A6577CCEB27D6** get_address_of_lastTouchPositions_44() { return &___lastTouchPositions_44; }
	inline void set_lastTouchPositions_44(Vector2U5BU5D_tA065A07DFC060C1B8786BBAA5F3A6577CCEB27D6* value)
	{
		___lastTouchPositions_44 = value;
		Il2CppCodeGenWriteBarrier((&___lastTouchPositions_44), value);
	}

	inline static int32_t get_offset_of_cursorRend_45() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___cursorRend_45)); }
	inline Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 * get_cursorRend_45() const { return ___cursorRend_45; }
	inline Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 ** get_address_of_cursorRend_45() { return &___cursorRend_45; }
	inline void set_cursorRend_45(Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 * value)
	{
		___cursorRend_45 = value;
		Il2CppCodeGenWriteBarrier((&___cursorRend_45), value);
	}

	inline static int32_t get_offset_of_mousePosOnTouchEnd_46() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A, ___mousePosOnTouchEnd_46)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_mousePosOnTouchEnd_46() const { return ___mousePosOnTouchEnd_46; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_mousePosOnTouchEnd_46() { return &___mousePosOnTouchEnd_46; }
	inline void set_mousePosOnTouchEnd_46(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___mousePosOnTouchEnd_46 = value;
	}
};

struct OrbitControl_t92EB06513B807BC8317734058465878739EBA84A_StaticFields
{
public:
	// OrbitControl OrbitControl::instance
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A * ___instance_4;

public:
	inline static int32_t get_offset_of_instance_4() { return static_cast<int32_t>(offsetof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A_StaticFields, ___instance_4)); }
	inline OrbitControl_t92EB06513B807BC8317734058465878739EBA84A * get_instance_4() const { return ___instance_4; }
	inline OrbitControl_t92EB06513B807BC8317734058465878739EBA84A ** get_address_of_instance_4() { return &___instance_4; }
	inline void set_instance_4(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A * value)
	{
		___instance_4 = value;
		Il2CppCodeGenWriteBarrier((&___instance_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ORBITCONTROL_T92EB06513B807BC8317734058465878739EBA84A_H
#ifndef UIBEHAVIOUR_T3C3C339CD5677BA7FC27C352FED8B78052A3FE70_H
#define UIBEHAVIOUR_T3C3C339CD5677BA7FC27C352FED8B78052A3FE70_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.EventSystems.UIBehaviour
struct  UIBehaviour_t3C3C339CD5677BA7FC27C352FED8B78052A3FE70  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UIBEHAVIOUR_T3C3C339CD5677BA7FC27C352FED8B78052A3FE70_H
#ifndef VIDEOPANELEVENTHANDLER_T3541E619FE0500181F23443D1B6C8FD05DC18802_H
#define VIDEOPANELEVENTHANDLER_T3541E619FE0500181F23443D1B6C8FD05DC18802_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// VideoPanelEventHandler
struct  VideoPanelEventHandler_t3541E619FE0500181F23443D1B6C8FD05DC18802  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// CallAppUi VideoPanelEventHandler::mParent
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * ___mParent_4;
	// System.Single VideoPanelEventHandler::mLastClick
	float ___mLastClick_5;

public:
	inline static int32_t get_offset_of_mParent_4() { return static_cast<int32_t>(offsetof(VideoPanelEventHandler_t3541E619FE0500181F23443D1B6C8FD05DC18802, ___mParent_4)); }
	inline CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * get_mParent_4() const { return ___mParent_4; }
	inline CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 ** get_address_of_mParent_4() { return &___mParent_4; }
	inline void set_mParent_4(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867 * value)
	{
		___mParent_4 = value;
		Il2CppCodeGenWriteBarrier((&___mParent_4), value);
	}

	inline static int32_t get_offset_of_mLastClick_5() { return static_cast<int32_t>(offsetof(VideoPanelEventHandler_t3541E619FE0500181F23443D1B6C8FD05DC18802, ___mLastClick_5)); }
	inline float get_mLastClick_5() const { return ___mLastClick_5; }
	inline float* get_address_of_mLastClick_5() { return &___mLastClick_5; }
	inline void set_mLastClick_5(float value)
	{
		___mLastClick_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEOPANELEVENTHANDLER_T3541E619FE0500181F23443D1B6C8FD05DC18802_H
#ifndef VIDEOINPUTAPP_TBD1B4BA06062C26F8519013F665376060F9FC2CF_H
#define VIDEOINPUTAPP_TBD1B4BA06062C26F8519013F665376060F9FC2CF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// Byn.Unity.Examples.VideoInputApp
struct  VideoInputApp_tBD1B4BA06062C26F8519013F665376060F9FC2CF  : public CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIDEOINPUTAPP_TBD1B4BA06062C26F8519013F665376060F9FC2CF_H
#ifndef HOLOGRAMSCRIPT_T46465F6B8AE230374A19B02F315F9327AFCD702C_H
#define HOLOGRAMSCRIPT_T46465F6B8AE230374A19B02F315F9327AFCD702C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// HologramScript
struct  HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C  : public CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867
{
public:
	// UnityEngine.Texture2D HologramScript::tx
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___tx_21;
	// System.Int32 HologramScript::rcvWidth
	int32_t ___rcvWidth_22;
	// System.Int32 HologramScript::rcvHeight
	int32_t ___rcvHeight_23;
	// System.Int32 HologramScript::depthWidth
	int32_t ___depthWidth_24;
	// System.Int32 HologramScript::depthHeight
	int32_t ___depthHeight_25;
	// System.Single HologramScript::cx
	float ___cx_26;
	// System.Single HologramScript::cy
	float ___cy_27;
	// System.Single HologramScript::fx
	float ___fx_28;
	// System.Single HologramScript::fy
	float ___fy_29;
	// System.Single HologramScript::ratio
	float ___ratio_30;
	// System.Int32 HologramScript::margin
	int32_t ___margin_37;
	// System.Int32 HologramScript::num
	int32_t ___num_38;
	// UnityEngine.Mesh HologramScript::mesh
	Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * ___mesh_39;
	// UnityEngine.Vector3[] HologramScript::vertices
	Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28* ___vertices_40;
	// UnityEngine.Color32[] HologramScript::colors
	Color32U5BU5D_tABFBCB467E6D1B791303A0D3A3AA1A482F620983* ___colors_41;
	// System.Int32[] HologramScript::indices
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___indices_42;
	// System.Single HologramScript::pointsize
	float ___pointsize_43;
	// UnityEngine.Material HologramScript::pointcloudMat
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___pointcloudMat_44;

public:
	inline static int32_t get_offset_of_tx_21() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___tx_21)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_tx_21() const { return ___tx_21; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_tx_21() { return &___tx_21; }
	inline void set_tx_21(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___tx_21 = value;
		Il2CppCodeGenWriteBarrier((&___tx_21), value);
	}

	inline static int32_t get_offset_of_rcvWidth_22() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___rcvWidth_22)); }
	inline int32_t get_rcvWidth_22() const { return ___rcvWidth_22; }
	inline int32_t* get_address_of_rcvWidth_22() { return &___rcvWidth_22; }
	inline void set_rcvWidth_22(int32_t value)
	{
		___rcvWidth_22 = value;
	}

	inline static int32_t get_offset_of_rcvHeight_23() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___rcvHeight_23)); }
	inline int32_t get_rcvHeight_23() const { return ___rcvHeight_23; }
	inline int32_t* get_address_of_rcvHeight_23() { return &___rcvHeight_23; }
	inline void set_rcvHeight_23(int32_t value)
	{
		___rcvHeight_23 = value;
	}

	inline static int32_t get_offset_of_depthWidth_24() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___depthWidth_24)); }
	inline int32_t get_depthWidth_24() const { return ___depthWidth_24; }
	inline int32_t* get_address_of_depthWidth_24() { return &___depthWidth_24; }
	inline void set_depthWidth_24(int32_t value)
	{
		___depthWidth_24 = value;
	}

	inline static int32_t get_offset_of_depthHeight_25() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___depthHeight_25)); }
	inline int32_t get_depthHeight_25() const { return ___depthHeight_25; }
	inline int32_t* get_address_of_depthHeight_25() { return &___depthHeight_25; }
	inline void set_depthHeight_25(int32_t value)
	{
		___depthHeight_25 = value;
	}

	inline static int32_t get_offset_of_cx_26() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___cx_26)); }
	inline float get_cx_26() const { return ___cx_26; }
	inline float* get_address_of_cx_26() { return &___cx_26; }
	inline void set_cx_26(float value)
	{
		___cx_26 = value;
	}

	inline static int32_t get_offset_of_cy_27() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___cy_27)); }
	inline float get_cy_27() const { return ___cy_27; }
	inline float* get_address_of_cy_27() { return &___cy_27; }
	inline void set_cy_27(float value)
	{
		___cy_27 = value;
	}

	inline static int32_t get_offset_of_fx_28() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___fx_28)); }
	inline float get_fx_28() const { return ___fx_28; }
	inline float* get_address_of_fx_28() { return &___fx_28; }
	inline void set_fx_28(float value)
	{
		___fx_28 = value;
	}

	inline static int32_t get_offset_of_fy_29() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___fy_29)); }
	inline float get_fy_29() const { return ___fy_29; }
	inline float* get_address_of_fy_29() { return &___fy_29; }
	inline void set_fy_29(float value)
	{
		___fy_29 = value;
	}

	inline static int32_t get_offset_of_ratio_30() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___ratio_30)); }
	inline float get_ratio_30() const { return ___ratio_30; }
	inline float* get_address_of_ratio_30() { return &___ratio_30; }
	inline void set_ratio_30(float value)
	{
		___ratio_30 = value;
	}

	inline static int32_t get_offset_of_margin_37() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___margin_37)); }
	inline int32_t get_margin_37() const { return ___margin_37; }
	inline int32_t* get_address_of_margin_37() { return &___margin_37; }
	inline void set_margin_37(int32_t value)
	{
		___margin_37 = value;
	}

	inline static int32_t get_offset_of_num_38() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___num_38)); }
	inline int32_t get_num_38() const { return ___num_38; }
	inline int32_t* get_address_of_num_38() { return &___num_38; }
	inline void set_num_38(int32_t value)
	{
		___num_38 = value;
	}

	inline static int32_t get_offset_of_mesh_39() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___mesh_39)); }
	inline Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * get_mesh_39() const { return ___mesh_39; }
	inline Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C ** get_address_of_mesh_39() { return &___mesh_39; }
	inline void set_mesh_39(Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * value)
	{
		___mesh_39 = value;
		Il2CppCodeGenWriteBarrier((&___mesh_39), value);
	}

	inline static int32_t get_offset_of_vertices_40() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___vertices_40)); }
	inline Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28* get_vertices_40() const { return ___vertices_40; }
	inline Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28** get_address_of_vertices_40() { return &___vertices_40; }
	inline void set_vertices_40(Vector3U5BU5D_tB9EC3346CC4A0EA5447D968E84A9AC1F6F372C28* value)
	{
		___vertices_40 = value;
		Il2CppCodeGenWriteBarrier((&___vertices_40), value);
	}

	inline static int32_t get_offset_of_colors_41() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___colors_41)); }
	inline Color32U5BU5D_tABFBCB467E6D1B791303A0D3A3AA1A482F620983* get_colors_41() const { return ___colors_41; }
	inline Color32U5BU5D_tABFBCB467E6D1B791303A0D3A3AA1A482F620983** get_address_of_colors_41() { return &___colors_41; }
	inline void set_colors_41(Color32U5BU5D_tABFBCB467E6D1B791303A0D3A3AA1A482F620983* value)
	{
		___colors_41 = value;
		Il2CppCodeGenWriteBarrier((&___colors_41), value);
	}

	inline static int32_t get_offset_of_indices_42() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___indices_42)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_indices_42() const { return ___indices_42; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_indices_42() { return &___indices_42; }
	inline void set_indices_42(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___indices_42 = value;
		Il2CppCodeGenWriteBarrier((&___indices_42), value);
	}

	inline static int32_t get_offset_of_pointsize_43() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___pointsize_43)); }
	inline float get_pointsize_43() const { return ___pointsize_43; }
	inline float* get_address_of_pointsize_43() { return &___pointsize_43; }
	inline void set_pointsize_43(float value)
	{
		___pointsize_43 = value;
	}

	inline static int32_t get_offset_of_pointcloudMat_44() { return static_cast<int32_t>(offsetof(HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C, ___pointcloudMat_44)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_pointcloudMat_44() const { return ___pointcloudMat_44; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_pointcloudMat_44() { return &___pointcloudMat_44; }
	inline void set_pointcloudMat_44(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___pointcloudMat_44 = value;
		Il2CppCodeGenWriteBarrier((&___pointcloudMat_44), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HOLOGRAMSCRIPT_T46465F6B8AE230374A19B02F315F9327AFCD702C_H
#ifndef BASEMESHEFFECT_T72759F31F9D204D7EFB6B45097873809D4524BA5_H
#define BASEMESHEFFECT_T72759F31F9D204D7EFB6B45097873809D4524BA5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.BaseMeshEffect
struct  BaseMeshEffect_t72759F31F9D204D7EFB6B45097873809D4524BA5  : public UIBehaviour_t3C3C339CD5677BA7FC27C352FED8B78052A3FE70
{
public:
	// UnityEngine.UI.Graphic UnityEngine.UI.BaseMeshEffect::m_Graphic
	Graphic_tBA2C3EF11D3DAEBB57F6879AB0BB4F8BD40D00D8 * ___m_Graphic_4;

public:
	inline static int32_t get_offset_of_m_Graphic_4() { return static_cast<int32_t>(offsetof(BaseMeshEffect_t72759F31F9D204D7EFB6B45097873809D4524BA5, ___m_Graphic_4)); }
	inline Graphic_tBA2C3EF11D3DAEBB57F6879AB0BB4F8BD40D00D8 * get_m_Graphic_4() const { return ___m_Graphic_4; }
	inline Graphic_tBA2C3EF11D3DAEBB57F6879AB0BB4F8BD40D00D8 ** get_address_of_m_Graphic_4() { return &___m_Graphic_4; }
	inline void set_m_Graphic_4(Graphic_tBA2C3EF11D3DAEBB57F6879AB0BB4F8BD40D00D8 * value)
	{
		___m_Graphic_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_Graphic_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BASEMESHEFFECT_T72759F31F9D204D7EFB6B45097873809D4524BA5_H
#ifndef LAYOUTELEMENT_TD503826DB41B6EA85AC689292F8B2661B3C1048B_H
#define LAYOUTELEMENT_TD503826DB41B6EA85AC689292F8B2661B3C1048B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.LayoutElement
struct  LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B  : public UIBehaviour_t3C3C339CD5677BA7FC27C352FED8B78052A3FE70
{
public:
	// System.Boolean UnityEngine.UI.LayoutElement::m_IgnoreLayout
	bool ___m_IgnoreLayout_4;
	// System.Single UnityEngine.UI.LayoutElement::m_MinWidth
	float ___m_MinWidth_5;
	// System.Single UnityEngine.UI.LayoutElement::m_MinHeight
	float ___m_MinHeight_6;
	// System.Single UnityEngine.UI.LayoutElement::m_PreferredWidth
	float ___m_PreferredWidth_7;
	// System.Single UnityEngine.UI.LayoutElement::m_PreferredHeight
	float ___m_PreferredHeight_8;
	// System.Single UnityEngine.UI.LayoutElement::m_FlexibleWidth
	float ___m_FlexibleWidth_9;
	// System.Single UnityEngine.UI.LayoutElement::m_FlexibleHeight
	float ___m_FlexibleHeight_10;
	// System.Int32 UnityEngine.UI.LayoutElement::m_LayoutPriority
	int32_t ___m_LayoutPriority_11;

public:
	inline static int32_t get_offset_of_m_IgnoreLayout_4() { return static_cast<int32_t>(offsetof(LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B, ___m_IgnoreLayout_4)); }
	inline bool get_m_IgnoreLayout_4() const { return ___m_IgnoreLayout_4; }
	inline bool* get_address_of_m_IgnoreLayout_4() { return &___m_IgnoreLayout_4; }
	inline void set_m_IgnoreLayout_4(bool value)
	{
		___m_IgnoreLayout_4 = value;
	}

	inline static int32_t get_offset_of_m_MinWidth_5() { return static_cast<int32_t>(offsetof(LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B, ___m_MinWidth_5)); }
	inline float get_m_MinWidth_5() const { return ___m_MinWidth_5; }
	inline float* get_address_of_m_MinWidth_5() { return &___m_MinWidth_5; }
	inline void set_m_MinWidth_5(float value)
	{
		___m_MinWidth_5 = value;
	}

	inline static int32_t get_offset_of_m_MinHeight_6() { return static_cast<int32_t>(offsetof(LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B, ___m_MinHeight_6)); }
	inline float get_m_MinHeight_6() const { return ___m_MinHeight_6; }
	inline float* get_address_of_m_MinHeight_6() { return &___m_MinHeight_6; }
	inline void set_m_MinHeight_6(float value)
	{
		___m_MinHeight_6 = value;
	}

	inline static int32_t get_offset_of_m_PreferredWidth_7() { return static_cast<int32_t>(offsetof(LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B, ___m_PreferredWidth_7)); }
	inline float get_m_PreferredWidth_7() const { return ___m_PreferredWidth_7; }
	inline float* get_address_of_m_PreferredWidth_7() { return &___m_PreferredWidth_7; }
	inline void set_m_PreferredWidth_7(float value)
	{
		___m_PreferredWidth_7 = value;
	}

	inline static int32_t get_offset_of_m_PreferredHeight_8() { return static_cast<int32_t>(offsetof(LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B, ___m_PreferredHeight_8)); }
	inline float get_m_PreferredHeight_8() const { return ___m_PreferredHeight_8; }
	inline float* get_address_of_m_PreferredHeight_8() { return &___m_PreferredHeight_8; }
	inline void set_m_PreferredHeight_8(float value)
	{
		___m_PreferredHeight_8 = value;
	}

	inline static int32_t get_offset_of_m_FlexibleWidth_9() { return static_cast<int32_t>(offsetof(LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B, ___m_FlexibleWidth_9)); }
	inline float get_m_FlexibleWidth_9() const { return ___m_FlexibleWidth_9; }
	inline float* get_address_of_m_FlexibleWidth_9() { return &___m_FlexibleWidth_9; }
	inline void set_m_FlexibleWidth_9(float value)
	{
		___m_FlexibleWidth_9 = value;
	}

	inline static int32_t get_offset_of_m_FlexibleHeight_10() { return static_cast<int32_t>(offsetof(LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B, ___m_FlexibleHeight_10)); }
	inline float get_m_FlexibleHeight_10() const { return ___m_FlexibleHeight_10; }
	inline float* get_address_of_m_FlexibleHeight_10() { return &___m_FlexibleHeight_10; }
	inline void set_m_FlexibleHeight_10(float value)
	{
		___m_FlexibleHeight_10 = value;
	}

	inline static int32_t get_offset_of_m_LayoutPriority_11() { return static_cast<int32_t>(offsetof(LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B, ___m_LayoutPriority_11)); }
	inline int32_t get_m_LayoutPriority_11() const { return ___m_LayoutPriority_11; }
	inline int32_t* get_address_of_m_LayoutPriority_11() { return &___m_LayoutPriority_11; }
	inline void set_m_LayoutPriority_11(int32_t value)
	{
		___m_LayoutPriority_11 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LAYOUTELEMENT_TD503826DB41B6EA85AC689292F8B2661B3C1048B_H
#ifndef LAYOUTGROUP_T9E072B95DA6476C487C0B07A815291249025C0E4_H
#define LAYOUTGROUP_T9E072B95DA6476C487C0B07A815291249025C0E4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.LayoutGroup
struct  LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4  : public UIBehaviour_t3C3C339CD5677BA7FC27C352FED8B78052A3FE70
{
public:
	// UnityEngine.RectOffset UnityEngine.UI.LayoutGroup::m_Padding
	RectOffset_tED44B1176E93501050480416699D1F11BAE8C87A * ___m_Padding_4;
	// UnityEngine.TextAnchor UnityEngine.UI.LayoutGroup::m_ChildAlignment
	int32_t ___m_ChildAlignment_5;
	// UnityEngine.RectTransform UnityEngine.UI.LayoutGroup::m_Rect
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___m_Rect_6;
	// UnityEngine.DrivenRectTransformTracker UnityEngine.UI.LayoutGroup::m_Tracker
	DrivenRectTransformTracker_tB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03  ___m_Tracker_7;
	// UnityEngine.Vector2 UnityEngine.UI.LayoutGroup::m_TotalMinSize
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_TotalMinSize_8;
	// UnityEngine.Vector2 UnityEngine.UI.LayoutGroup::m_TotalPreferredSize
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_TotalPreferredSize_9;
	// UnityEngine.Vector2 UnityEngine.UI.LayoutGroup::m_TotalFlexibleSize
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_TotalFlexibleSize_10;
	// System.Collections.Generic.List`1<UnityEngine.RectTransform> UnityEngine.UI.LayoutGroup::m_RectChildren
	List_1_t0CD9761E1DF9817484CF4FB4253C6A626DC2311C * ___m_RectChildren_11;

public:
	inline static int32_t get_offset_of_m_Padding_4() { return static_cast<int32_t>(offsetof(LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4, ___m_Padding_4)); }
	inline RectOffset_tED44B1176E93501050480416699D1F11BAE8C87A * get_m_Padding_4() const { return ___m_Padding_4; }
	inline RectOffset_tED44B1176E93501050480416699D1F11BAE8C87A ** get_address_of_m_Padding_4() { return &___m_Padding_4; }
	inline void set_m_Padding_4(RectOffset_tED44B1176E93501050480416699D1F11BAE8C87A * value)
	{
		___m_Padding_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_Padding_4), value);
	}

	inline static int32_t get_offset_of_m_ChildAlignment_5() { return static_cast<int32_t>(offsetof(LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4, ___m_ChildAlignment_5)); }
	inline int32_t get_m_ChildAlignment_5() const { return ___m_ChildAlignment_5; }
	inline int32_t* get_address_of_m_ChildAlignment_5() { return &___m_ChildAlignment_5; }
	inline void set_m_ChildAlignment_5(int32_t value)
	{
		___m_ChildAlignment_5 = value;
	}

	inline static int32_t get_offset_of_m_Rect_6() { return static_cast<int32_t>(offsetof(LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4, ___m_Rect_6)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_m_Rect_6() const { return ___m_Rect_6; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_m_Rect_6() { return &___m_Rect_6; }
	inline void set_m_Rect_6(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___m_Rect_6 = value;
		Il2CppCodeGenWriteBarrier((&___m_Rect_6), value);
	}

	inline static int32_t get_offset_of_m_Tracker_7() { return static_cast<int32_t>(offsetof(LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4, ___m_Tracker_7)); }
	inline DrivenRectTransformTracker_tB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03  get_m_Tracker_7() const { return ___m_Tracker_7; }
	inline DrivenRectTransformTracker_tB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03 * get_address_of_m_Tracker_7() { return &___m_Tracker_7; }
	inline void set_m_Tracker_7(DrivenRectTransformTracker_tB8FBBE24EEE9618CA32E4B3CF52F4AD7FDDEBE03  value)
	{
		___m_Tracker_7 = value;
	}

	inline static int32_t get_offset_of_m_TotalMinSize_8() { return static_cast<int32_t>(offsetof(LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4, ___m_TotalMinSize_8)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_TotalMinSize_8() const { return ___m_TotalMinSize_8; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_TotalMinSize_8() { return &___m_TotalMinSize_8; }
	inline void set_m_TotalMinSize_8(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_TotalMinSize_8 = value;
	}

	inline static int32_t get_offset_of_m_TotalPreferredSize_9() { return static_cast<int32_t>(offsetof(LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4, ___m_TotalPreferredSize_9)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_TotalPreferredSize_9() const { return ___m_TotalPreferredSize_9; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_TotalPreferredSize_9() { return &___m_TotalPreferredSize_9; }
	inline void set_m_TotalPreferredSize_9(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_TotalPreferredSize_9 = value;
	}

	inline static int32_t get_offset_of_m_TotalFlexibleSize_10() { return static_cast<int32_t>(offsetof(LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4, ___m_TotalFlexibleSize_10)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_TotalFlexibleSize_10() const { return ___m_TotalFlexibleSize_10; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_TotalFlexibleSize_10() { return &___m_TotalFlexibleSize_10; }
	inline void set_m_TotalFlexibleSize_10(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_TotalFlexibleSize_10 = value;
	}

	inline static int32_t get_offset_of_m_RectChildren_11() { return static_cast<int32_t>(offsetof(LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4, ___m_RectChildren_11)); }
	inline List_1_t0CD9761E1DF9817484CF4FB4253C6A626DC2311C * get_m_RectChildren_11() const { return ___m_RectChildren_11; }
	inline List_1_t0CD9761E1DF9817484CF4FB4253C6A626DC2311C ** get_address_of_m_RectChildren_11() { return &___m_RectChildren_11; }
	inline void set_m_RectChildren_11(List_1_t0CD9761E1DF9817484CF4FB4253C6A626DC2311C * value)
	{
		___m_RectChildren_11 = value;
		Il2CppCodeGenWriteBarrier((&___m_RectChildren_11), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LAYOUTGROUP_T9E072B95DA6476C487C0B07A815291249025C0E4_H
#ifndef HORIZONTALORVERTICALLAYOUTGROUP_TFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB_H
#define HORIZONTALORVERTICALLAYOUTGROUP_TFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.HorizontalOrVerticalLayoutGroup
struct  HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB  : public LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4
{
public:
	// System.Single UnityEngine.UI.HorizontalOrVerticalLayoutGroup::m_Spacing
	float ___m_Spacing_12;
	// System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::m_ChildForceExpandWidth
	bool ___m_ChildForceExpandWidth_13;
	// System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::m_ChildForceExpandHeight
	bool ___m_ChildForceExpandHeight_14;
	// System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::m_ChildControlWidth
	bool ___m_ChildControlWidth_15;
	// System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::m_ChildControlHeight
	bool ___m_ChildControlHeight_16;

public:
	inline static int32_t get_offset_of_m_Spacing_12() { return static_cast<int32_t>(offsetof(HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB, ___m_Spacing_12)); }
	inline float get_m_Spacing_12() const { return ___m_Spacing_12; }
	inline float* get_address_of_m_Spacing_12() { return &___m_Spacing_12; }
	inline void set_m_Spacing_12(float value)
	{
		___m_Spacing_12 = value;
	}

	inline static int32_t get_offset_of_m_ChildForceExpandWidth_13() { return static_cast<int32_t>(offsetof(HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB, ___m_ChildForceExpandWidth_13)); }
	inline bool get_m_ChildForceExpandWidth_13() const { return ___m_ChildForceExpandWidth_13; }
	inline bool* get_address_of_m_ChildForceExpandWidth_13() { return &___m_ChildForceExpandWidth_13; }
	inline void set_m_ChildForceExpandWidth_13(bool value)
	{
		___m_ChildForceExpandWidth_13 = value;
	}

	inline static int32_t get_offset_of_m_ChildForceExpandHeight_14() { return static_cast<int32_t>(offsetof(HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB, ___m_ChildForceExpandHeight_14)); }
	inline bool get_m_ChildForceExpandHeight_14() const { return ___m_ChildForceExpandHeight_14; }
	inline bool* get_address_of_m_ChildForceExpandHeight_14() { return &___m_ChildForceExpandHeight_14; }
	inline void set_m_ChildForceExpandHeight_14(bool value)
	{
		___m_ChildForceExpandHeight_14 = value;
	}

	inline static int32_t get_offset_of_m_ChildControlWidth_15() { return static_cast<int32_t>(offsetof(HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB, ___m_ChildControlWidth_15)); }
	inline bool get_m_ChildControlWidth_15() const { return ___m_ChildControlWidth_15; }
	inline bool* get_address_of_m_ChildControlWidth_15() { return &___m_ChildControlWidth_15; }
	inline void set_m_ChildControlWidth_15(bool value)
	{
		___m_ChildControlWidth_15 = value;
	}

	inline static int32_t get_offset_of_m_ChildControlHeight_16() { return static_cast<int32_t>(offsetof(HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB, ___m_ChildControlHeight_16)); }
	inline bool get_m_ChildControlHeight_16() const { return ___m_ChildControlHeight_16; }
	inline bool* get_address_of_m_ChildControlHeight_16() { return &___m_ChildControlHeight_16; }
	inline void set_m_ChildControlHeight_16(bool value)
	{
		___m_ChildControlHeight_16 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HORIZONTALORVERTICALLAYOUTGROUP_TFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB_H
#ifndef POSITIONASUV1_T26F06E879E7B8DD2F93B8B3643053534D82F684A_H
#define POSITIONASUV1_T26F06E879E7B8DD2F93B8B3643053534D82F684A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.PositionAsUV1
struct  PositionAsUV1_t26F06E879E7B8DD2F93B8B3643053534D82F684A  : public BaseMeshEffect_t72759F31F9D204D7EFB6B45097873809D4524BA5
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSITIONASUV1_T26F06E879E7B8DD2F93B8B3643053534D82F684A_H
#ifndef SHADOW_TA03D2493843CDF8E64569F985AEB3FEEEEB412E1_H
#define SHADOW_TA03D2493843CDF8E64569F985AEB3FEEEEB412E1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.Shadow
struct  Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1  : public BaseMeshEffect_t72759F31F9D204D7EFB6B45097873809D4524BA5
{
public:
	// UnityEngine.Color UnityEngine.UI.Shadow::m_EffectColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___m_EffectColor_5;
	// UnityEngine.Vector2 UnityEngine.UI.Shadow::m_EffectDistance
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___m_EffectDistance_6;
	// System.Boolean UnityEngine.UI.Shadow::m_UseGraphicAlpha
	bool ___m_UseGraphicAlpha_7;

public:
	inline static int32_t get_offset_of_m_EffectColor_5() { return static_cast<int32_t>(offsetof(Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1, ___m_EffectColor_5)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_m_EffectColor_5() const { return ___m_EffectColor_5; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_m_EffectColor_5() { return &___m_EffectColor_5; }
	inline void set_m_EffectColor_5(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___m_EffectColor_5 = value;
	}

	inline static int32_t get_offset_of_m_EffectDistance_6() { return static_cast<int32_t>(offsetof(Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1, ___m_EffectDistance_6)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_m_EffectDistance_6() const { return ___m_EffectDistance_6; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_m_EffectDistance_6() { return &___m_EffectDistance_6; }
	inline void set_m_EffectDistance_6(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___m_EffectDistance_6 = value;
	}

	inline static int32_t get_offset_of_m_UseGraphicAlpha_7() { return static_cast<int32_t>(offsetof(Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1, ___m_UseGraphicAlpha_7)); }
	inline bool get_m_UseGraphicAlpha_7() const { return ___m_UseGraphicAlpha_7; }
	inline bool* get_address_of_m_UseGraphicAlpha_7() { return &___m_UseGraphicAlpha_7; }
	inline void set_m_UseGraphicAlpha_7(bool value)
	{
		___m_UseGraphicAlpha_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SHADOW_TA03D2493843CDF8E64569F985AEB3FEEEEB412E1_H
#ifndef OUTLINE_TB750E496976B072E79142D51C0A991AC20183095_H
#define OUTLINE_TB750E496976B072E79142D51C0A991AC20183095_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.Outline
struct  Outline_tB750E496976B072E79142D51C0A991AC20183095  : public Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OUTLINE_TB750E496976B072E79142D51C0A991AC20183095_H
#ifndef VERTICALLAYOUTGROUP_TAAEE0BAA82E9A110591DEC9A3FFC25A01C2FFA11_H
#define VERTICALLAYOUTGROUP_TAAEE0BAA82E9A110591DEC9A3FFC25A01C2FFA11_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.UI.VerticalLayoutGroup
struct  VerticalLayoutGroup_tAAEE0BAA82E9A110591DEC9A3FFC25A01C2FFA11  : public HorizontalOrVerticalLayoutGroup_tFE5C3DB19C2CC4906B3E5D5F4E1966CB585174AB
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VERTICALLAYOUTGROUP_TAAEE0BAA82E9A110591DEC9A3FFC25A01C2FFA11_H





#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3400 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3401 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3402 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3403 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3404 = { sizeof (LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3404[8] = 
{
	LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B::get_offset_of_m_IgnoreLayout_4(),
	LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B::get_offset_of_m_MinWidth_5(),
	LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B::get_offset_of_m_MinHeight_6(),
	LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B::get_offset_of_m_PreferredWidth_7(),
	LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B::get_offset_of_m_PreferredHeight_8(),
	LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B::get_offset_of_m_FlexibleWidth_9(),
	LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B::get_offset_of_m_FlexibleHeight_10(),
	LayoutElement_tD503826DB41B6EA85AC689292F8B2661B3C1048B::get_offset_of_m_LayoutPriority_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3405 = { sizeof (LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3405[8] = 
{
	LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4::get_offset_of_m_Padding_4(),
	LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4::get_offset_of_m_ChildAlignment_5(),
	LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4::get_offset_of_m_Rect_6(),
	LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4::get_offset_of_m_Tracker_7(),
	LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4::get_offset_of_m_TotalMinSize_8(),
	LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4::get_offset_of_m_TotalPreferredSize_9(),
	LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4::get_offset_of_m_TotalFlexibleSize_10(),
	LayoutGroup_t9E072B95DA6476C487C0B07A815291249025C0E4::get_offset_of_m_RectChildren_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3406 = { sizeof (U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3406[4] = 
{
	U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073::get_offset_of_rectTransform_0(),
	U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073::get_offset_of_U24current_1(),
	U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073::get_offset_of_U24disposing_2(),
	U3CDelayedSetDirtyU3Ec__Iterator0_tB8BB61C2C033D95240B4E2704971663E4DC08073::get_offset_of_U24PC_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3407 = { sizeof (LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD), -1, sizeof(LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3407[9] = 
{
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD::get_offset_of_m_ToRebuild_0(),
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD::get_offset_of_m_CachedHashFromTransform_1(),
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields::get_offset_of_s_Rebuilders_2(),
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields::get_offset_of_U3CU3Ef__mgU24cache0_3(),
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields::get_offset_of_U3CU3Ef__amU24cache0_4(),
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields::get_offset_of_U3CU3Ef__amU24cache1_5(),
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields::get_offset_of_U3CU3Ef__amU24cache2_6(),
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields::get_offset_of_U3CU3Ef__amU24cache3_7(),
	LayoutRebuilder_t8D3501B43B1DE666140E2931FFA732B5B09EA5BD_StaticFields::get_offset_of_U3CU3Ef__amU24cache4_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3408 = { sizeof (LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5), -1, sizeof(LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3408[8] = 
{
	LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields::get_offset_of_U3CU3Ef__amU24cache0_0(),
	LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields::get_offset_of_U3CU3Ef__amU24cache1_1(),
	LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields::get_offset_of_U3CU3Ef__amU24cache2_2(),
	LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields::get_offset_of_U3CU3Ef__amU24cache3_3(),
	LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields::get_offset_of_U3CU3Ef__amU24cache4_4(),
	LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields::get_offset_of_U3CU3Ef__amU24cache5_5(),
	LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields::get_offset_of_U3CU3Ef__amU24cache6_6(),
	LayoutUtility_t3B5074E34900DA384884FC50809EA395CB69E7D5_StaticFields::get_offset_of_U3CU3Ef__amU24cache7_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3409 = { sizeof (VerticalLayoutGroup_tAAEE0BAA82E9A110591DEC9A3FFC25A01C2FFA11), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3410 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3411 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable3411[2] = 
{
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3412 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable3412[2] = 
{
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3413 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable3413[4] = 
{
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3414 = { sizeof (ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A), -1, sizeof(ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3414[7] = 
{
	ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A::get_offset_of_raycast3D_0(),
	ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A::get_offset_of_raycast3DAll_1(),
	ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A::get_offset_of_raycast2D_2(),
	ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A::get_offset_of_getRayIntersectionAll_3(),
	ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A::get_offset_of_getRayIntersectionAllNonAlloc_4(),
	ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A::get_offset_of_getRaycastNonAlloc_5(),
	ReflectionMethodsCache_tBDADDC80D50C5F10BD00965217980B9A8D24BE8A_StaticFields::get_offset_of_s_ReflectionMethodsCache_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3415 = { sizeof (Raycast3DCallback_t83483916473C9710AEDB316A65CBE62C58935C5F), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3416 = { sizeof (Raycast2DCallback_tE99ABF9ABC3A380677949E8C05A3E477889B82BE), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3417 = { sizeof (RaycastAllCallback_t751407A44270E02FAA43D0846A58EE6A8C4AE1CE), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3418 = { sizeof (GetRayIntersectionAllCallback_t68C2581CCF05E868297EBD3F3361274954845095), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3419 = { sizeof (GetRayIntersectionAllNonAllocCallback_tAD7508D45DB6679B6394983579AD18D967CC2AD4), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3420 = { sizeof (GetRaycastNonAllocCallback_tC13D9767CFF00EAB26E9FCC4BDD505F0721A2B4D), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3421 = { sizeof (VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F), -1, sizeof(VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3421[12] = 
{
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Positions_0(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Colors_1(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Uv0S_2(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Uv1S_3(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Uv2S_4(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Uv3S_5(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Normals_6(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Tangents_7(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_Indices_8(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_StaticFields::get_offset_of_s_DefaultTangent_9(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F_StaticFields::get_offset_of_s_DefaultNormal_10(),
	VertexHelper_t27373EA2CF0F5810EC8CF873D0A6D6C0B23DAC3F::get_offset_of_m_ListsInitalized_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3422 = { sizeof (VertexHelperExtension_t593AF80A941B7208D2CC88AE671873CE6E2AA8E3), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3423 = { sizeof (BaseVertexEffect_t1EF95AB1FC33A027710E7DC86D19F700156C4F6A), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3424 = { sizeof (BaseMeshEffect_t72759F31F9D204D7EFB6B45097873809D4524BA5), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3424[1] = 
{
	BaseMeshEffect_t72759F31F9D204D7EFB6B45097873809D4524BA5::get_offset_of_m_Graphic_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3425 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3426 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3427 = { sizeof (Outline_tB750E496976B072E79142D51C0A991AC20183095), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3428 = { sizeof (PositionAsUV1_t26F06E879E7B8DD2F93B8B3643053534D82F684A), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3429 = { sizeof (Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3429[4] = 
{
	Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1::get_offset_of_m_EffectColor_5(),
	Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1::get_offset_of_m_EffectDistance_6(),
	Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1::get_offset_of_m_UseGraphicAlpha_7(),
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3430 = { sizeof (U3CPrivateImplementationDetailsU3E_tC8332394FBFEEB4B73459A35E182942340DA3537), -1, sizeof(U3CPrivateImplementationDetailsU3E_tC8332394FBFEEB4B73459A35E182942340DA3537_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3430[1] = 
{
	U3CPrivateImplementationDetailsU3E_tC8332394FBFEEB4B73459A35E182942340DA3537_StaticFields::get_offset_of_U24fieldU2D7BBE37982E6C057ED87163CAFC7FD6E5E42EEA46_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3431 = { sizeof (U24ArrayTypeU3D12_t25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199)+ sizeof (RuntimeObject), sizeof(U24ArrayTypeU3D12_t25F5D2FC4CFB01F181ED6F7A7F68C39C5D73E199 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3432 = { sizeof (U3CModuleU3E_tCE4B768174CDE0294B05DD8ED59A7763FF34E99B), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3433 = { sizeof (U3CModuleU3E_t51CA7CF080E6CE0730273E28881393B61A64D06E), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3434 = { sizeof (CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3434[18] = 
{
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_uSignalingUrl_4(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_uSecureSignalingUrl_5(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_uForceSecureSignaling_6(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_uIceServer_7(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_uIceServerUser_8(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_uIceServerPassword_9(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_uIceServer2_10(),
	0,
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mCall_12(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mUi_13(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mMediaConfig_14(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mCallActive_15(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mUseAddress_16(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mMediaConfigInUse_17(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mRemoteUserId_18(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mAutoRejoin_19(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mRejoinTime_20(),
	CallApp_t4DCD1A7EDC7FAC52EEAD0FBEC75978387BF22C43::get_offset_of_mLocalFrameEvents_21(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3435 = { sizeof (U3CCoroutineRejoinU3Ed__37_tE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3435[3] = 
{
	U3CCoroutineRejoinU3Ed__37_tE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2::get_offset_of_U3CU3E1__state_0(),
	U3CCoroutineRejoinU3Ed__37_tE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2::get_offset_of_U3CU3E2__current_1(),
	U3CCoroutineRejoinU3Ed__37_tE56E856EA5CC1340EFBA5AA42563F9542E5FB3C2::get_offset_of_U3CU3E4__this_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3436 = { sizeof (CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867), -1, sizeof(CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3436[17] = 
{
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_audioEnabled_4(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_roomName_5(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mat_6(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mRemoteVideoTexture_7(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_uNoCameraTexture_8(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mApp_9(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mVideoOverlayTimeout_10(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867_StaticFields::get_offset_of_sDefaultOverlayTimeout_11(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mLocalVideoFormat_12(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mHasRemoteVideo_13(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mRemoteVideoWidth_14(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mRemoteVideoHeight_15(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mRemoteFps_16(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mRemoteRotation_17(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mRemoteFrameCounter_18(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mRemoteVideoFormat_19(),
	CallAppUi_tACD06D4561F5F727B12FC86E8F703D58DC811867::get_offset_of_mFpsTimer_20(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3437 = { sizeof (U3CstartbuttonU3Ed__20_tD7D0D415BC8F3F262D7F0FDE55D2527DE96E078A), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3437[3] = 
{
	U3CstartbuttonU3Ed__20_tD7D0D415BC8F3F262D7F0FDE55D2527DE96E078A::get_offset_of_U3CU3E1__state_0(),
	U3CstartbuttonU3Ed__20_tD7D0D415BC8F3F262D7F0FDE55D2527DE96E078A::get_offset_of_U3CU3E2__current_1(),
	U3CstartbuttonU3Ed__20_tD7D0D415BC8F3F262D7F0FDE55D2527DE96E078A::get_offset_of_U3CU3E4__this_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3438 = { sizeof (U3CRequestAudioPermissionsU3Ed__22_t9C17C56991F50213F4C48325729588E25B140775), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3438[3] = 
{
	U3CRequestAudioPermissionsU3Ed__22_t9C17C56991F50213F4C48325729588E25B140775::get_offset_of_U3CU3E1__state_0(),
	U3CRequestAudioPermissionsU3Ed__22_t9C17C56991F50213F4C48325729588E25B140775::get_offset_of_U3CU3E2__current_1(),
	U3CRequestAudioPermissionsU3Ed__22_t9C17C56991F50213F4C48325729588E25B140775::get_offset_of_U3CU3E4__this_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3439 = { sizeof (ImgFitter_t8C2D5035D612E3A0EA1E2F51DFD3870672984F40), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3440 = { sizeof (VideoPanelEventHandler_t3541E619FE0500181F23443D1B6C8FD05DC18802), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3440[2] = 
{
	VideoPanelEventHandler_t3541E619FE0500181F23443D1B6C8FD05DC18802::get_offset_of_mParent_4(),
	VideoPanelEventHandler_t3541E619FE0500181F23443D1B6C8FD05DC18802::get_offset_of_mLastClick_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3441 = { sizeof (ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3441[18] = 
{
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uSignalingUrl_4(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uSecureSignalingUrl_5(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uForceSecureSignaling_6(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uIceServer_7(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uIceServerUser_8(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uIceServerPassword_9(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uIceServer2_10(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uRoomName_11(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uMessageInput_12(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uOutput_13(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uJoin_14(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uSend_15(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uOpenRoom_16(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_uLeave_17(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_mNetwork_18(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_mIsServer_19(),
	ChatApp_t0290B0B9E87598552A8CB2A528FC37BB576DD5A7::get_offset_of_mConnections_20(),
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3442 = { sizeof (MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3442[4] = 
{
	MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC::get_offset_of_uEntryPrefab_4(),
	MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC::get_offset_of_mOwnTransform_5(),
	MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC::get_offset_of_mMaxMessages_6(),
	MessageList_tD66AFF3FCD283ACC670373072314E87D442C19DC::get_offset_of_mCounter_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3443 = { sizeof (GridManager_t05748D877516CE2E0F9FBFACCF8AF0F6A21D4804), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3443[3] = 
{
	GridManager_t05748D877516CE2E0F9FBFACCF8AF0F6A21D4804::get_offset_of_mKnownItems_4(),
	GridManager_t05748D877516CE2E0F9FBFACCF8AF0F6A21D4804::get_offset_of_mGrid_5(),
	GridManager_t05748D877516CE2E0F9FBFACCF8AF0F6A21D4804::get_offset_of_mTransform_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3444 = { sizeof (MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66), -1, sizeof(MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3444[3] = 
{
	MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66_StaticFields::get_offset_of_sCreated_4(),
	MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66::get_offset_of__StartMenu_5(),
	MenuScript_t9CD076A38B78730719E72CE473E966D0194B7B66::get_offset_of__ButtonMenu_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3445 = { sizeof (AndroidHelper_tC0B54CF40032DFE35CD9AB26816E265E12D56969), -1, sizeof(AndroidHelper_tC0B54CF40032DFE35CD9AB26816E265E12D56969_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3445[2] = 
{
	AndroidHelper_tC0B54CF40032DFE35CD9AB26816E265E12D56969_StaticFields::get_offset_of_jclass_AndroidVideo_0(),
	AndroidHelper_tC0B54CF40032DFE35CD9AB26816E265E12D56969_StaticFields::get_offset_of_jclass_PermissionHelper_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3446 = { sizeof (UnityHelper_t8385B1C3D90FCE7C88494C24381E90C932B73841), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3447 = { sizeof (UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB), -1, sizeof(UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3447[16] = 
{
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_ALLOW_SYNCHRONOUS_INIT_4(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_ANDROID_SET_COMMUNICATION_MODE_5(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_ALLOW_UNCHECKED_REMOTE_CERTIFICATE_6(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_KEEP_AWAKE_7(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_DEFAULT_LOG_LEVEL_8(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_NATIVE_VERBOSE_LOG_9(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB::get_offset_of_mAndroidPreviousAudioMode_10(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB::get_offset_of_mSleepTimeoutBackup_11(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB::get_offset_of_mHasActiveCall_12(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_sInitState_13(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_sInitCallbacks_14(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_sInitFailedMessage_15(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_sActiveLogLevel_16(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_LOG_PREFIX_17(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB_StaticFields::get_offset_of_sInstance_18(),
	UnityCallFactory_t8EDDA82C4443ADF36445011BE4CCD732000E06AB::get_offset_of_mFactory_19(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3448 = { sizeof (InitState_tF0A3A2CE215643EDF5BC6E278CE7E7578E38A18C)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3448[7] = 
{
	InitState_tF0A3A2CE215643EDF5BC6E278CE7E7578E38A18C::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3449 = { sizeof (InitCallbacks_t1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3449[2] = 
{
	InitCallbacks_t1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6::get_offset_of_onSuccess_0(),
	InitCallbacks_t1B45316D40FE55B0D0E2B9C696FD207E38C0B0E6::get_offset_of_onFailure_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3450 = { sizeof (InitStatusUpdate_t9CB7C4BBAF73AE515E423C78CBDE4AB3C0ED96AF)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3450[4] = 
{
	InitStatusUpdate_t9CB7C4BBAF73AE515E423C78CBDE4AB3C0ED96AF::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3451 = { sizeof (LogLevel_tEBEAF97CA6FC143AAFFCBF123E970D39D79AE144)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3451[5] = 
{
	LogLevel_tEBEAF97CA6FC143AAFFCBF123E970D39D79AE144::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3452 = { sizeof (U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3452[4] = 
{
	U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9::get_offset_of_U3CU3E1__state_0(),
	U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9::get_offset_of_U3CU3E2__current_1(),
	U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9::get_offset_of_U3CU3E4__this_2(),
	U3CCoroutineInitAsyncU3Ed__28_tA3214622DB8E78242139C65CDFDC288D7A17C3D9::get_offset_of_U3CwaitCounterU3E5__2_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3453 = { sizeof (U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE), -1, sizeof(U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3453[2] = 
{
	U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_StaticFields::get_offset_of_U3CU3E9_0(),
	U3CU3Ec_t2CDFA09651C8C18ED2C857E1D144A6A9041E1AFE_StaticFields::get_offset_of_U3CU3E9__30_0_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3454 = { sizeof (UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00), -1, sizeof(UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3454[3] = 
{
	UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00_StaticFields::get_offset_of_I420_MAT_NAME_0(),
	UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00_StaticFields::get_offset_of_I420_MAT_UPLANE_1(),
	UnityMediaHelper_t909B65F549010A7353DC82E5AF7C0E259B42FC00_StaticFields::get_offset_of_I420_MAT_VPLANE_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3455 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable3455[3] = 
{
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3456 = { sizeof (ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B), -1, sizeof(ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3456[5] = 
{
	ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields::get_offset_of_StunUrl_0(),
	ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields::get_offset_of_TurnUrl_1(),
	ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields::get_offset_of_TurnUser_2(),
	ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields::get_offset_of_TurnPass_3(),
	ExampleGlobals_t56851F8D33D17DD137BD47D6F3F683BE900B236B_StaticFields::get_offset_of_BackupStunUrl_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3457 = { sizeof (U3CRequestAudioPermissionU3Ed__17_tCBCB2E5936A36A838919E3777D2B4B3FD140600E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3457[2] = 
{
	U3CRequestAudioPermissionU3Ed__17_tCBCB2E5936A36A838919E3777D2B4B3FD140600E::get_offset_of_U3CU3E1__state_0(),
	U3CRequestAudioPermissionU3Ed__17_tCBCB2E5936A36A838919E3777D2B4B3FD140600E::get_offset_of_U3CU3E2__current_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3458 = { sizeof (U3CRequestVideoPermissionU3Ed__18_t284CC5B8067172F41554DA77F7863C49E75F053E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3458[2] = 
{
	U3CRequestVideoPermissionU3Ed__18_t284CC5B8067172F41554DA77F7863C49E75F053E::get_offset_of_U3CU3E1__state_0(),
	U3CRequestVideoPermissionU3Ed__18_t284CC5B8067172F41554DA77F7863C49E75F053E::get_offset_of_U3CU3E2__current_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3459 = { sizeof (U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3459[4] = 
{
	U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856::get_offset_of_U3CU3E1__state_0(),
	U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856::get_offset_of_U3CU3E2__current_1(),
	U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856::get_offset_of_audio_2(),
	U3CRequestPermissionsU3Ed__19_t67EA9769316E4B44407430981C52658E479F9856::get_offset_of_video_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3460 = { sizeof (MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3460[4] = 
{
	MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73::get_offset_of_sender_4(),
	MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73::get_offset_of_receiver_5(),
	MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73::get_offset_of_netConf_6(),
	MinimalCall_t1A616F4059C1AC885A34A5636B57E1687B1E9E73::get_offset_of_address_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3461 = { sizeof (MinimalConference_t9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3461[3] = 
{
	MinimalConference_t9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3::get_offset_of_calls_4(),
	MinimalConference_t9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3::get_offset_of_netConf_5(),
	MinimalConference_t9BE980D66E93D123EAC4E8ABDFAFABCD87F382A3::get_offset_of_address_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3462 = { sizeof (MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3462[6] = 
{
	MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF::get_offset_of_sender_4(),
	MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF::get_offset_of_mSenderConfigured_5(),
	MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF::get_offset_of_receiver_6(),
	MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF::get_offset_of_mReceiverConfigured_7(),
	MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF::get_offset_of_netConf_8(),
	MinimalMediaNetwork_t99B14410205FF74DEFEF6E056C1A045777B89FFF::get_offset_of_address_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3463 = { sizeof (SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3463[6] = 
{
	SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD::get_offset_of__Sender_4(),
	SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD::get_offset_of__LocalImage_5(),
	SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD::get_offset_of__RemoteImage_6(),
	SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD::get_offset_of__TryI420_7(),
	SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD::get_offset_of_mState_8(),
	SimpleCall_tAC3DAAD0B3C5CACD29E70007F210F6E373A179AD::get_offset_of_mCall_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3464 = { sizeof (SimpleCallState_t57C23CDEB50ACA1A8FEE6905D5B0B3DBEBA5493A)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3464[7] = 
{
	SimpleCallState_t57C23CDEB50ACA1A8FEE6905D5B0B3DBEBA5493A::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3465 = { sizeof (U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3465[4] = 
{
	U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68::get_offset_of_U3CU3E1__state_0(),
	U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68::get_offset_of_U3CU3E2__current_1(),
	U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68::get_offset_of_startInSec_2(),
	U3CConfigureDelayedU3Ed__9_t42904B407A0DCE5F3444308EB9C6E569B1031C68::get_offset_of_U3CU3E4__this_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3466 = { sizeof (OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086), -1, sizeof(OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3466[11] = 
{
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_mSignalingServer_4(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_mStunServer_5(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_mMediaNetwork_6(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_mMediaConfig_7(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086_StaticFields::get_offset_of_sInstances_8(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_mIndex_9(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_uSender_10(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_uVideoOutput_11(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_mVideoTexture_12(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086_StaticFields::get_offset_of_sAddress_13(),
	OneToMany_tD2FD726816556B1F8CD9045B5FE9F44C4E00C086::get_offset_of_mConnectionIds_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3467 = { sizeof (U3CStartU3Ed__11_t55FDB25F620252AE5B728D0548DB05649BD4CAC8), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3467[3] = 
{
	U3CStartU3Ed__11_t55FDB25F620252AE5B728D0548DB05649BD4CAC8::get_offset_of_U3CU3E1__state_0(),
	U3CStartU3Ed__11_t55FDB25F620252AE5B728D0548DB05649BD4CAC8::get_offset_of_U3CU3E2__current_1(),
	U3CStartU3Ed__11_t55FDB25F620252AE5B728D0548DB05649BD4CAC8::get_offset_of_U3CU3E4__this_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3468 = { sizeof (ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3468[14] = 
{
	0,
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uRoomName_5(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uMessageField_6(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uOutput_7(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uJoin_8(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uSend_9(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uShutdown_10(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uSetupPanel_11(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uVideoLayout_12(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uVideoPrefab_13(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_uNoImgTexture_14(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_mCall_15(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_config_16(),
	ConferenceApp_t0EFD286CF629E11657DF84B2F40D842EA3F74EBE::get_offset_of_mVideoUiElements_17(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3469 = { sizeof (VideoData_t9C078487B97498970A01E98DEF8304B622527398), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3469[3] = 
{
	VideoData_t9C078487B97498970A01E98DEF8304B622527398::get_offset_of_uiObject_0(),
	VideoData_t9C078487B97498970A01E98DEF8304B622527398::get_offset_of_texture_1(),
	VideoData_t9C078487B97498970A01E98DEF8304B622527398::get_offset_of_image_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3470 = { sizeof (VideoInputApp_tBD1B4BA06062C26F8519013F665376060F9FC2CF), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3471 = { sizeof (U3CCoroutineRefreshLaterU3Ed__1_t9AF1BDEE238458547E50F4B52D8F01FDAC02D18E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3471[2] = 
{
	U3CCoroutineRefreshLaterU3Ed__1_t9AF1BDEE238458547E50F4B52D8F01FDAC02D18E::get_offset_of_U3CU3E1__state_0(),
	U3CCoroutineRefreshLaterU3Ed__1_t9AF1BDEE238458547E50F4B52D8F01FDAC02D18E::get_offset_of_U3CU3E2__current_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3472 = { sizeof (VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3472[12] = 
{
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of__Camera_4(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of_mLastSample_5(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of_mTexture_6(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of_mRtBuffer_7(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of__DebugTarget_8(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of__DeviceName_9(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of__Fps_10(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of__Width_11(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of__Height_12(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of_mUsedDeviceName_13(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of_mByteBuffer_14(),
	VirtualCamera_t3480DEF62386D17D6EC2771DED373229F30D4175::get_offset_of_mVideoInput_15(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3473 = { sizeof (U3CModuleU3E_t6CDDDF959E7E18A6744E43B613F41CDAC780256A), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3474 = { sizeof (HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3474[24] = 
{
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_tx_21(),
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_rcvWidth_22(),
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_rcvHeight_23(),
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_depthWidth_24(),
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_depthHeight_25(),
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_cx_26(),
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_cy_27(),
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_fx_28(),
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_fy_29(),
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_ratio_30(),
	0,
	0,
	0,
	0,
	0,
	0,
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_margin_37(),
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_num_38(),
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_mesh_39(),
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_vertices_40(),
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_colors_41(),
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_indices_42(),
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_pointsize_43(),
	HologramScript_t46465F6B8AE230374A19B02F315F9327AFCD702C::get_offset_of_pointcloudMat_44(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3475 = { sizeof (DemoButtonPresses_t4E38441FCA6AC3950E176902E7DD3BC5E459F134), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3475[4] = 
{
	DemoButtonPresses_t4E38441FCA6AC3950E176902E7DD3BC5E459F134::get_offset_of_squareIsCurrentlyDown_4(),
	DemoButtonPresses_t4E38441FCA6AC3950E176902E7DD3BC5E459F134::get_offset_of_leftIsCurrentlyDown_5(),
	DemoButtonPresses_t4E38441FCA6AC3950E176902E7DD3BC5E459F134::get_offset_of_rightIsCurrentlyDown_6(),
	DemoButtonPresses_t4E38441FCA6AC3950E176902E7DD3BC5E459F134::get_offset_of_circleIsCurrentlyDown_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3476 = { sizeof (InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3476[13] = 
{
	InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019::get_offset_of_OnMessageReceived_4(),
	0,
	0,
	InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019::get_offset_of_role_7(),
	InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019::get_offset_of_receiverPort_8(),
	InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019::get_offset_of_senderPort_9(),
	InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019::get_offset_of_signMessages_10(),
	InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019::get_offset_of_signingChar_11(),
	InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019::get_offset_of_anyIP_12(),
	InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019::get_offset_of_messageQueue_13(),
	InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019::get_offset_of_client_14(),
	InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019::get_offset_of_receiveThread_15(),
	InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019::get_offset_of_remoteEndPoint_16(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3477 = { sizeof (MessageReceived_t8F3129EEA322B159C6FD7D6F55678D155E6A9A12), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3478 = { sizeof (Role_tF3905ABBC3761D7A0769787409DF35B6C3EA615D)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3478[5] = 
{
	Role_tF3905ABBC3761D7A0769787409DF35B6C3EA615D::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3479 = { sizeof (U3CDoEvaluateMessagesU3Ed__24_tE689A15D2581E01CA8288FFF481A2A22E3869E23), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3479[3] = 
{
	U3CDoEvaluateMessagesU3Ed__24_tE689A15D2581E01CA8288FFF481A2A22E3869E23::get_offset_of_U3CU3E1__state_0(),
	U3CDoEvaluateMessagesU3Ed__24_tE689A15D2581E01CA8288FFF481A2A22E3869E23::get_offset_of_U3CU3E2__current_1(),
	U3CDoEvaluateMessagesU3Ed__24_tE689A15D2581E01CA8288FFF481A2A22E3869E23::get_offset_of_U3CU3E4__this_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3480 = { sizeof (OrbitControl_t92EB06513B807BC8317734058465878739EBA84A), -1, sizeof(OrbitControl_t92EB06513B807BC8317734058465878739EBA84A_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3480[43] = 
{
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A_StaticFields::get_offset_of_instance_4(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_touchInputThisFrame_5(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_rMomentum_6(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_rLastPos_7(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_rotateSpeed_8(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_rotateDrag_9(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_yMax_10(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_yMin_11(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_pMomentum_12(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_pLastPos_13(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_panSpeed_14(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_panDrag_15(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_zMomentum_16(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_zLastYPos_17(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_mouseZoomSpeed_18(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_multitouchZoomSpeed_19(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_zoomDrag_20(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_multitouchZoomThreshold_21(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_multitouchMaxJump_22(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_minHoloplaySize_23(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_maxHoloplaySize_24(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_validRotationStart_25(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_refocusingToPosition_26(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_refocusToPosition_27(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_startRefocusPosition_28(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_refocusToPointCurve_29(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_refocusToTime_30(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_maxDistBetweenClicksMouse_31(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_maxDistBetweenClicksTouch_32(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_doubleClickTime_33(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_doubleClickTimeTouch_34(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_doubleClickTimer_35(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_refocusToTimer_36(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_oneClick_37(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_oneTouch_38(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_oneClickPos_39(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_eventSys_40(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_canInteract_41(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_multitouchRemapCursorY_42(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_multitouchRemapCursorX_43(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_lastTouchPositions_44(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_cursorRend_45(),
	OrbitControl_t92EB06513B807BC8317734058465878739EBA84A::get_offset_of_mousePosOnTouchEnd_46(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3481 = { sizeof (ButtonType_tA98D458F69E8B2F1F49622D0A02EAF4909C77AC7)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3481[6] = 
{
	ButtonType_tA98D458F69E8B2F1F49622D0A02EAF4909C77AC7::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3482 = { sizeof (ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1), -1, sizeof(ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3482[6] = 
{
	ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1::get_offset_of_emulateWithKeyboard_4(),
	ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1::get_offset_of_joystickNumber_5(),
	ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1::get_offset_of_timeSinceLastCheck_6(),
	ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1::get_offset_of_checkInterval_7(),
	ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1::get_offset_of_buttonKeyCodes_8(),
	ButtonManager_t7795B64B4A21A90258F24137E6E2D8517B1D97B1_StaticFields::get_offset_of_instance_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3483 = { sizeof (U3CU3Ec_tE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE), -1, sizeof(U3CU3Ec_tE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3483[4] = 
{
	U3CU3Ec_tE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE_StaticFields::get_offset_of_U3CU3E9_0(),
	U3CU3Ec_tE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE_StaticFields::get_offset_of_U3CU3E9__10_0_1(),
	U3CU3Ec_tE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE_StaticFields::get_offset_of_U3CU3E9__11_0_2(),
	U3CU3Ec_tE872CA1EE2E4A856A9187EDEBD54E5454D9F40CE_StaticFields::get_offset_of_U3CU3E9__12_0_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3484 = { sizeof (CalibrationManager_t69C929BA4E560058B15736462A6C613CDD0A580A), -1, sizeof(CalibrationManager_t69C929BA4E560058B15736462A6C613CDD0A580A_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3484[2] = 
{
	CalibrationManager_t69C929BA4E560058B15736462A6C613CDD0A580A_StaticFields::get_offset_of_isInit_0(),
	CalibrationManager_t69C929BA4E560058B15736462A6C613CDD0A580A_StaticFields::get_offset_of_calibrations_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3485 = { sizeof (Calibration_t9AB78454E6D4068384FB24A31465696019A429D0)+ sizeof (RuntimeObject), sizeof(Calibration_t9AB78454E6D4068384FB24A31465696019A429D0_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable3485[15] = 
{
	Calibration_t9AB78454E6D4068384FB24A31465696019A429D0::get_offset_of_index_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Calibration_t9AB78454E6D4068384FB24A31465696019A429D0::get_offset_of_screenWidth_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Calibration_t9AB78454E6D4068384FB24A31465696019A429D0::get_offset_of_screenHeight_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Calibration_t9AB78454E6D4068384FB24A31465696019A429D0::get_offset_of_subp_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Calibration_t9AB78454E6D4068384FB24A31465696019A429D0::get_offset_of_viewCone_4() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Calibration_t9AB78454E6D4068384FB24A31465696019A429D0::get_offset_of_aspect_5() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Calibration_t9AB78454E6D4068384FB24A31465696019A429D0::get_offset_of_pitch_6() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Calibration_t9AB78454E6D4068384FB24A31465696019A429D0::get_offset_of_slope_7() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Calibration_t9AB78454E6D4068384FB24A31465696019A429D0::get_offset_of_center_8() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Calibration_t9AB78454E6D4068384FB24A31465696019A429D0::get_offset_of_fringe_9() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Calibration_t9AB78454E6D4068384FB24A31465696019A429D0::get_offset_of_serial_10() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Calibration_t9AB78454E6D4068384FB24A31465696019A429D0::get_offset_of_LKGname_11() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Calibration_t9AB78454E6D4068384FB24A31465696019A429D0::get_offset_of_unityIndex_12() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Calibration_t9AB78454E6D4068384FB24A31465696019A429D0::get_offset_of_xpos_13() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Calibration_t9AB78454E6D4068384FB24A31465696019A429D0::get_offset_of_ypos_14() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3486 = { sizeof (Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6), -1, sizeof(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3486[22] = 
{
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6_StaticFields::get_offset_of_instance_4(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_disableSystemCursor_5(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_relativeScale_6(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_depthNormals_7(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_depthOnlyShader_8(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_readDepthPixelShader_9(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_readDepthPixelMat_10(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_cursorGameObject_11(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_cursorGameObjectExists_12(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_frameRendered_13(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_cursorCam_14(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_worldPos_15(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_localPos_16(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_normal_17(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_rotation_18(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_localRotation_19(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_overObject_20(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_debugTexture_21(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_uiCursor_22(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_parentCanvas_23(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_rend_24(),
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6::get_offset_of_uiCursorMode_25(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3487 = { sizeof (ExtendedUI_t3A2E2222C569E098392D2FD2E39FCC390E6FE3A6), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3487[4] = 
{
	ExtendedUI_t3A2E2222C569E098392D2FD2E39FCC390E6FE3A6::get_offset_of_canvas_4(),
	ExtendedUI_t3A2E2222C569E098392D2FD2E39FCC390E6FE3A6::get_offset_of_bgCam_5(),
	ExtendedUI_t3A2E2222C569E098392D2FD2E39FCC390E6FE3A6::get_offset_of_copyBGCamSettings_6(),
	ExtendedUI_t3A2E2222C569E098392D2FD2E39FCC390E6FE3A6::get_offset_of_singleDisplayMode_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3488 = { sizeof (Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A), -1, sizeof(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3488[57] = 
{
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A_StaticFields::get_offset_of_instance_4(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A_StaticFields::get_offset_of_version_5(),
	0,
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_clearFlags_7(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_background_8(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_cullingMask_9(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_size_10(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_depth_11(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_renderingPath_12(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_occlusionCulling_13(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_allowHDR_14(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_allowMSAA_15(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_allowDynamicResolution_16(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_targetDisplay_17(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_targetLKG_18(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_preview2D_19(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_fov_20(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_nearClipFactor_21(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_farClipFactor_22(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_scaleFollowsSize_23(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_viewconeModifier_24(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_centerOffset_25(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_horizontalFrustumOffset_26(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_verticalFrustumOffset_27(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_useFrustumTarget_28(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_frustumTarget_29(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_quiltPreset_30(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_customQuiltSettings_31(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_screenshot2DKey_32(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_screenshotQuiltKey_33(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_overrideQuilt_34(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_renderOverrideBehind_35(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_quiltRT_36(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_lightfieldMat_37(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_frustumColor_38(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_middlePlaneColor_39(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_handleColor_40(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_drawHandles_41(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_cornerDists_42(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_frustumCorners_43(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_onHoloplayReady_44(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_loadResults_45(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_onViewRender_46(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_viewInterpolation_47(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_reduceFlicker_48(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_fillGaps_49(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_blendViews_50(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_interpolationComputeShader_51(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_cam_52(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_postProcessCam_53(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_lightfieldCam_54(),
	0,
	0,
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_cal_57(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_frameRendered_58(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_camDist_59(),
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A::get_offset_of_debugInfo_60(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3489 = { sizeof (ViewRenderEvent_t8A52588044E632F42B64DC1EE219DC39E0DA957C), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3490 = { sizeof (ViewInterpolationType_tFE84ADCF02AAD2929ED2BD7892982130EFD062DD)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3490[7] = 
{
	ViewInterpolationType_tFE84ADCF02AAD2929ED2BD7892982130EFD062DD::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3491 = { sizeof (LightfieldPostProcess_t3AB37CE5BAC845BD9D2ECACEF447239C11AFCB49), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3491[1] = 
{
	LightfieldPostProcess_t3AB37CE5BAC845BD9D2ECACEF447239C11AFCB49::get_offset_of_holoplay_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3492 = { sizeof (Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3492[9] = 
{
	Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F::get_offset_of_automaticArrangement_4(),
	Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F::get_offset_of_columns_5(),
	Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F::get_offset_of_rows_6(),
	Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F::get_offset_of_size_7(),
	Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F::get_offset_of_separation_8(),
	Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F::get_offset_of_holoplays_9(),
	Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F::get_offset_of_frustumShifting_10(),
	Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F::get_offset_of_showUpdateWarning_11(),
	Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F::get_offset_of_initialSetup_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3493 = { sizeof (DisplayPositioner_t72462E5B3E20F9FCD1AA67B4CA8025EAB6D5C8CB), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3493[3] = 
{
	DisplayPositioner_t72462E5B3E20F9FCD1AA67B4CA8025EAB6D5C8CB::get_offset_of_targetLKG_0(),
	DisplayPositioner_t72462E5B3E20F9FCD1AA67B4CA8025EAB6D5C8CB::get_offset_of_targetDisplay_1(),
	DisplayPositioner_t72462E5B3E20F9FCD1AA67B4CA8025EAB6D5C8CB::get_offset_of_position_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3494 = { sizeof (PluginCore_t155DE0EF086674BD0D934961B21B44479B5F0C10), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3494[2] = 
{
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3495 = { sizeof (hpc_client_error_t52A579A0931AFF4F1E3C8246418E37794C65DF98)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3495[10] = 
{
	hpc_client_error_t52A579A0931AFF4F1E3C8246418E37794C65DF98::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3496 = { sizeof (hpc_license_type_t94C2E00B85628AD601D0E63B6EB1EF2CAA54342C)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3496[3] = 
{
	hpc_license_type_t94C2E00B85628AD601D0E63B6EB1EF2CAA54342C::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3497 = { sizeof (LoadResults_t3028A604D8ED7E35E4316051844BAEECE1930F02)+ sizeof (RuntimeObject), sizeof(LoadResults_t3028A604D8ED7E35E4316051844BAEECE1930F02_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable3497[3] = 
{
	LoadResults_t3028A604D8ED7E35E4316051844BAEECE1930F02::get_offset_of_attempted_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	LoadResults_t3028A604D8ED7E35E4316051844BAEECE1930F02::get_offset_of_calibrationFound_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	LoadResults_t3028A604D8ED7E35E4316051844BAEECE1930F02::get_offset_of_lkgDisplayFound_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3498 = { sizeof (LoadEvent_tE7ACDCDE718293339A984D1E678134087257D727), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3499 = { sizeof (Quilt_tB58F63BCC9DFCA96CA7EDF608AED3E9EC0440957), -1, sizeof(Quilt_tB58F63BCC9DFCA96CA7EDF608AED3E9EC0440957_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3499[1] = 
{
	Quilt_tB58F63BCC9DFCA96CA7EDF608AED3E9EC0440957_StaticFields::get_offset_of_presets_0(),
};
#ifdef __clang__
#pragma clang diagnostic pop
#endif
