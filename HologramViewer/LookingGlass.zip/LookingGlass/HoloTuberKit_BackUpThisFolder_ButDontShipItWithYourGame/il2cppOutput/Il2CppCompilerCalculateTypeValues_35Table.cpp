﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "il2cpp-class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"


// InterProcessCommunicator
struct InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019;
// LookingGlass.Cursor3D
struct Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6;
// LookingGlass.Holoplay
struct Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A;
// LookingGlass.Multiplex
struct Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F;
// System.Char[]
struct CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2;
// System.Collections.ObjectModel.ReadOnlyCollection`1<UnityEngine.Rendering.PostProcessing.ParameterOverride>
struct ReadOnlyCollection_1_t09ED47FDFC3DF44855A0AECF526E54628E99D966;
// System.Diagnostics.Process
struct Process_t7F28AE318E6CCF89716D05E78E2CBD669767D6A1;
// System.Func`3<UnityEngine.Camera,UnityEngine.Vector2,UnityEngine.Matrix4x4>
struct Func_3_t76929AE26BC1464E59748B309462754D15C34712;
// System.Int32[]
struct Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83;
// System.Random
struct Random_t18A28484F67EFA289C256F508A5C71D9E6DEE09F;
// System.Single[]
struct SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5;
// System.String
struct String_t;
// System.Type
struct Type_t;
// System.Void
struct Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017;
// UnityEngine.Color[]
struct ColorU5BU5D_t166D390E0E6F24360F990D1F81881A72B73CA399;
// UnityEngine.ComputeBuffer
struct ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5;
// UnityEngine.GameObject
struct GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F;
// UnityEngine.Light
struct Light_tFDE490EADBC7E080F74CA804929513AF07C31A6C;
// UnityEngine.Material
struct Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598;
// UnityEngine.RenderTexture
struct RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6;
// UnityEngine.RenderTexture[][]
struct RenderTextureU5BU5DU5BU5D_t0481781C86014C56DE3E8711ADD0C18B122453EF;
// UnityEngine.Rendering.PostProcessing.AmbientOcclusion
struct AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88;
// UnityEngine.Rendering.PostProcessing.AmbientOcclusionModeParameter
struct AmbientOcclusionModeParameter_t79A104721D47E98613437F7F1A355695C397DDEF;
// UnityEngine.Rendering.PostProcessing.AmbientOcclusionQualityParameter
struct AmbientOcclusionQualityParameter_tE18805DEFF6A5466E44B02E6D820336B9EA0E2FD;
// UnityEngine.Rendering.PostProcessing.AutoExposure
struct AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C;
// UnityEngine.Rendering.PostProcessing.Bloom
struct Bloom_t366FA2D84798539D570B23E02789925E1079B3DD;
// UnityEngine.Rendering.PostProcessing.BloomRenderer/Level[]
struct LevelU5BU5D_tF50E5FC88D87D5276D3EBDA1A4F343212942ECC5;
// UnityEngine.Rendering.PostProcessing.BoolParameter
struct BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32;
// UnityEngine.Rendering.PostProcessing.ChromaticAberration
struct ChromaticAberration_t78EC7F7C23F37A371DD46BB3F1631FEFF046400F;
// UnityEngine.Rendering.PostProcessing.ColorGrading
struct ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206;
// UnityEngine.Rendering.PostProcessing.ColorParameter
struct ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85;
// UnityEngine.Rendering.PostProcessing.DepthOfField
struct DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88;
// UnityEngine.Rendering.PostProcessing.EyeAdaptationParameter
struct EyeAdaptationParameter_t7AC22D9A78944F2CA208B5E2FDB40BD76B1C0B70;
// UnityEngine.Rendering.PostProcessing.FloatParameter
struct FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703;
// UnityEngine.Rendering.PostProcessing.GradingModeParameter
struct GradingModeParameter_t30B66E571092CDA4D03618D02C0D71D84A7D9FA7;
// UnityEngine.Rendering.PostProcessing.Grain
struct Grain_t0ECCE83708F627DD09B42C375C38AC7387407A66;
// UnityEngine.Rendering.PostProcessing.HableCurve
struct HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78;
// UnityEngine.Rendering.PostProcessing.IAmbientOcclusionMethod[]
struct IAmbientOcclusionMethodU5BU5D_t62D9F0D9D4AE2C94A9C8CE9AA1A6A2219354B4FC;
// UnityEngine.Rendering.PostProcessing.IntParameter
struct IntParameter_tF314047E8059BF20F34E4202ACA31C6EAF8D7390;
// UnityEngine.Rendering.PostProcessing.KernelSizeParameter
struct KernelSizeParameter_t1290513B86C15182AD770816459A5398322F6642;
// UnityEngine.Rendering.PostProcessing.LensDistortion
struct LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB;
// UnityEngine.Rendering.PostProcessing.MotionBlur
struct MotionBlur_tC78F5B6F7B956D0BF4AE2E40BB2917C4FDB95D63;
// UnityEngine.Rendering.PostProcessing.PostProcessResources
struct PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98;
// UnityEngine.Rendering.PostProcessing.PostProcessVolume
struct PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3;
// UnityEngine.Rendering.PostProcessing.PropertySheet
struct PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212;
// UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionPresetParameter
struct ScreenSpaceReflectionPresetParameter_t268DBDBDBA87C22733B30A3E3587B328E7F834E4;
// UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionResolutionParameter
struct ScreenSpaceReflectionResolutionParameter_tC897149ADF64CB366527300D8A12FE2E5AE8B943;
// UnityEngine.Rendering.PostProcessing.ScreenSpaceReflections
struct ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5;
// UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionsRenderer/QualityPreset[]
struct QualityPresetU5BU5D_t60D3DE0232719D820134FB36A6ADAFA77352678C;
// UnityEngine.Rendering.PostProcessing.Spline
struct Spline_tE37069226E0B86697627CCEA38297277E55030CD;
// UnityEngine.Rendering.PostProcessing.SplineParameter
struct SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F;
// UnityEngine.Rendering.PostProcessing.TextureParameter
struct TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720;
// UnityEngine.Rendering.PostProcessing.TonemapperParameter
struct TonemapperParameter_tAE067595EA8479188AA91EC38AD4BBA34CF2DA3B;
// UnityEngine.Rendering.PostProcessing.Vector2Parameter
struct Vector2Parameter_t2138DCE95841B6A479E95D93280273119FCB0686;
// UnityEngine.Rendering.PostProcessing.Vector4Parameter
struct Vector4Parameter_t71A23EBB58A01E0FF756B1D104B8DE37F772E2F1;
// UnityEngine.Rendering.PostProcessing.Vignette
struct Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E;
// UnityEngine.Rendering.PostProcessing.VignetteModeParameter
struct VignetteModeParameter_t0853E96B549BCF8765CE8FEB6B50EB78706645A6;
// UnityEngine.Rendering.RenderTargetIdentifier[]
struct RenderTargetIdentifierU5BU5D_t57069CA3F97B36638E39044168D1BEB956436DD4;
// UnityEngine.TextMesh
struct TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A;
// UnityEngine.Texture2D
struct Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C;
// UnityEngine.Transform
struct Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA;
// UnityEngine.UI.Text
struct Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030;




#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
#ifndef ATTRIBUTE_TF048C13FB3C8CFCC53F82290E4A3F621089F9A74_H
#define ATTRIBUTE_TF048C13FB3C8CFCC53F82290E4A3F621089F9A74_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Attribute
struct  Attribute_tF048C13FB3C8CFCC53F82290E4A3F621089F9A74  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ATTRIBUTE_TF048C13FB3C8CFCC53F82290E4A3F621089F9A74_H
#ifndef VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#define VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_com
{
};
#endif // VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#ifndef DITHERING_T742ED682E1E94CAE24122F5E89ED166A97DCB547_H
#define DITHERING_T742ED682E1E94CAE24122F5E89ED166A97DCB547_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.Dithering
struct  Dithering_t742ED682E1E94CAE24122F5E89ED166A97DCB547  : public RuntimeObject
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.Dithering::m_NoiseTextureIndex
	int32_t ___m_NoiseTextureIndex_0;
	// System.Random UnityEngine.Rendering.PostProcessing.Dithering::m_Random
	Random_t18A28484F67EFA289C256F508A5C71D9E6DEE09F * ___m_Random_1;

public:
	inline static int32_t get_offset_of_m_NoiseTextureIndex_0() { return static_cast<int32_t>(offsetof(Dithering_t742ED682E1E94CAE24122F5E89ED166A97DCB547, ___m_NoiseTextureIndex_0)); }
	inline int32_t get_m_NoiseTextureIndex_0() const { return ___m_NoiseTextureIndex_0; }
	inline int32_t* get_address_of_m_NoiseTextureIndex_0() { return &___m_NoiseTextureIndex_0; }
	inline void set_m_NoiseTextureIndex_0(int32_t value)
	{
		___m_NoiseTextureIndex_0 = value;
	}

	inline static int32_t get_offset_of_m_Random_1() { return static_cast<int32_t>(offsetof(Dithering_t742ED682E1E94CAE24122F5E89ED166A97DCB547, ___m_Random_1)); }
	inline Random_t18A28484F67EFA289C256F508A5C71D9E6DEE09F * get_m_Random_1() const { return ___m_Random_1; }
	inline Random_t18A28484F67EFA289C256F508A5C71D9E6DEE09F ** get_address_of_m_Random_1() { return &___m_Random_1; }
	inline void set_m_Random_1(Random_t18A28484F67EFA289C256F508A5C71D9E6DEE09F * value)
	{
		___m_Random_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_Random_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DITHERING_T742ED682E1E94CAE24122F5E89ED166A97DCB547_H
#ifndef FASTAPPROXIMATEANTIALIASING_TDE38094B4113793694F81B6D782FA1D6F36768CD_H
#define FASTAPPROXIMATEANTIALIASING_TDE38094B4113793694F81B6D782FA1D6F36768CD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.FastApproximateAntialiasing
struct  FastApproximateAntialiasing_tDE38094B4113793694F81B6D782FA1D6F36768CD  : public RuntimeObject
{
public:
	// System.Boolean UnityEngine.Rendering.PostProcessing.FastApproximateAntialiasing::fastMode
	bool ___fastMode_0;
	// System.Boolean UnityEngine.Rendering.PostProcessing.FastApproximateAntialiasing::keepAlpha
	bool ___keepAlpha_1;

public:
	inline static int32_t get_offset_of_fastMode_0() { return static_cast<int32_t>(offsetof(FastApproximateAntialiasing_tDE38094B4113793694F81B6D782FA1D6F36768CD, ___fastMode_0)); }
	inline bool get_fastMode_0() const { return ___fastMode_0; }
	inline bool* get_address_of_fastMode_0() { return &___fastMode_0; }
	inline void set_fastMode_0(bool value)
	{
		___fastMode_0 = value;
	}

	inline static int32_t get_offset_of_keepAlpha_1() { return static_cast<int32_t>(offsetof(FastApproximateAntialiasing_tDE38094B4113793694F81B6D782FA1D6F36768CD, ___keepAlpha_1)); }
	inline bool get_keepAlpha_1() const { return ___keepAlpha_1; }
	inline bool* get_address_of_keepAlpha_1() { return &___keepAlpha_1; }
	inline void set_keepAlpha_1(bool value)
	{
		___keepAlpha_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FASTAPPROXIMATEANTIALIASING_TDE38094B4113793694F81B6D782FA1D6F36768CD_H
#ifndef FOG_TBCD51987A95009EBAB4ED7B98933E1B5A0A00196_H
#define FOG_TBCD51987A95009EBAB4ED7B98933E1B5A0A00196_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.Fog
struct  Fog_tBCD51987A95009EBAB4ED7B98933E1B5A0A00196  : public RuntimeObject
{
public:
	// System.Boolean UnityEngine.Rendering.PostProcessing.Fog::enabled
	bool ___enabled_0;
	// System.Boolean UnityEngine.Rendering.PostProcessing.Fog::excludeSkybox
	bool ___excludeSkybox_1;

public:
	inline static int32_t get_offset_of_enabled_0() { return static_cast<int32_t>(offsetof(Fog_tBCD51987A95009EBAB4ED7B98933E1B5A0A00196, ___enabled_0)); }
	inline bool get_enabled_0() const { return ___enabled_0; }
	inline bool* get_address_of_enabled_0() { return &___enabled_0; }
	inline void set_enabled_0(bool value)
	{
		___enabled_0 = value;
	}

	inline static int32_t get_offset_of_excludeSkybox_1() { return static_cast<int32_t>(offsetof(Fog_tBCD51987A95009EBAB4ED7B98933E1B5A0A00196, ___excludeSkybox_1)); }
	inline bool get_excludeSkybox_1() const { return ___excludeSkybox_1; }
	inline bool* get_address_of_excludeSkybox_1() { return &___excludeSkybox_1; }
	inline void set_excludeSkybox_1(bool value)
	{
		___excludeSkybox_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FOG_TBCD51987A95009EBAB4ED7B98933E1B5A0A00196_H
#ifndef MONITOR_TE317BECFE50FD51B2BBC2609C33E6ABE76A6338E_H
#define MONITOR_TE317BECFE50FD51B2BBC2609C33E6ABE76A6338E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.Monitor
struct  Monitor_tE317BECFE50FD51B2BBC2609C33E6ABE76A6338E  : public RuntimeObject
{
public:
	// UnityEngine.RenderTexture UnityEngine.Rendering.PostProcessing.Monitor::<output>k__BackingField
	RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * ___U3CoutputU3Ek__BackingField_0;
	// System.Boolean UnityEngine.Rendering.PostProcessing.Monitor::requested
	bool ___requested_1;

public:
	inline static int32_t get_offset_of_U3CoutputU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(Monitor_tE317BECFE50FD51B2BBC2609C33E6ABE76A6338E, ___U3CoutputU3Ek__BackingField_0)); }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * get_U3CoutputU3Ek__BackingField_0() const { return ___U3CoutputU3Ek__BackingField_0; }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 ** get_address_of_U3CoutputU3Ek__BackingField_0() { return &___U3CoutputU3Ek__BackingField_0; }
	inline void set_U3CoutputU3Ek__BackingField_0(RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * value)
	{
		___U3CoutputU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CoutputU3Ek__BackingField_0), value);
	}

	inline static int32_t get_offset_of_requested_1() { return static_cast<int32_t>(offsetof(Monitor_tE317BECFE50FD51B2BBC2609C33E6ABE76A6338E, ___requested_1)); }
	inline bool get_requested_1() const { return ___requested_1; }
	inline bool* get_address_of_requested_1() { return &___requested_1; }
	inline void set_requested_1(bool value)
	{
		___requested_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONITOR_TE317BECFE50FD51B2BBC2609C33E6ABE76A6338E_H
#ifndef MULTISCALEVO_T72BE3B27E520D5E61AD22146EBA6AF504013DF44_H
#define MULTISCALEVO_T72BE3B27E520D5E61AD22146EBA6AF504013DF44_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.MultiScaleVO
struct  MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44  : public RuntimeObject
{
public:
	// System.Single[] UnityEngine.Rendering.PostProcessing.MultiScaleVO::m_SampleThickness
	SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* ___m_SampleThickness_0;
	// System.Single[] UnityEngine.Rendering.PostProcessing.MultiScaleVO::m_InvThicknessTable
	SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* ___m_InvThicknessTable_1;
	// System.Single[] UnityEngine.Rendering.PostProcessing.MultiScaleVO::m_SampleWeightTable
	SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* ___m_SampleWeightTable_2;
	// System.Int32[] UnityEngine.Rendering.PostProcessing.MultiScaleVO::m_Widths
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___m_Widths_3;
	// System.Int32[] UnityEngine.Rendering.PostProcessing.MultiScaleVO::m_Heights
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___m_Heights_4;
	// UnityEngine.Rendering.PostProcessing.AmbientOcclusion UnityEngine.Rendering.PostProcessing.MultiScaleVO::m_Settings
	AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88 * ___m_Settings_5;
	// UnityEngine.Rendering.PostProcessing.PropertySheet UnityEngine.Rendering.PostProcessing.MultiScaleVO::m_PropertySheet
	PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 * ___m_PropertySheet_6;
	// UnityEngine.Rendering.PostProcessing.PostProcessResources UnityEngine.Rendering.PostProcessing.MultiScaleVO::m_Resources
	PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 * ___m_Resources_7;
	// UnityEngine.RenderTexture UnityEngine.Rendering.PostProcessing.MultiScaleVO::m_AmbientOnlyAO
	RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * ___m_AmbientOnlyAO_8;
	// UnityEngine.Rendering.RenderTargetIdentifier[] UnityEngine.Rendering.PostProcessing.MultiScaleVO::m_MRT
	RenderTargetIdentifierU5BU5D_t57069CA3F97B36638E39044168D1BEB956436DD4* ___m_MRT_9;

public:
	inline static int32_t get_offset_of_m_SampleThickness_0() { return static_cast<int32_t>(offsetof(MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44, ___m_SampleThickness_0)); }
	inline SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* get_m_SampleThickness_0() const { return ___m_SampleThickness_0; }
	inline SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5** get_address_of_m_SampleThickness_0() { return &___m_SampleThickness_0; }
	inline void set_m_SampleThickness_0(SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* value)
	{
		___m_SampleThickness_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_SampleThickness_0), value);
	}

	inline static int32_t get_offset_of_m_InvThicknessTable_1() { return static_cast<int32_t>(offsetof(MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44, ___m_InvThicknessTable_1)); }
	inline SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* get_m_InvThicknessTable_1() const { return ___m_InvThicknessTable_1; }
	inline SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5** get_address_of_m_InvThicknessTable_1() { return &___m_InvThicknessTable_1; }
	inline void set_m_InvThicknessTable_1(SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* value)
	{
		___m_InvThicknessTable_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_InvThicknessTable_1), value);
	}

	inline static int32_t get_offset_of_m_SampleWeightTable_2() { return static_cast<int32_t>(offsetof(MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44, ___m_SampleWeightTable_2)); }
	inline SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* get_m_SampleWeightTable_2() const { return ___m_SampleWeightTable_2; }
	inline SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5** get_address_of_m_SampleWeightTable_2() { return &___m_SampleWeightTable_2; }
	inline void set_m_SampleWeightTable_2(SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* value)
	{
		___m_SampleWeightTable_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_SampleWeightTable_2), value);
	}

	inline static int32_t get_offset_of_m_Widths_3() { return static_cast<int32_t>(offsetof(MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44, ___m_Widths_3)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_m_Widths_3() const { return ___m_Widths_3; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_m_Widths_3() { return &___m_Widths_3; }
	inline void set_m_Widths_3(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___m_Widths_3 = value;
		Il2CppCodeGenWriteBarrier((&___m_Widths_3), value);
	}

	inline static int32_t get_offset_of_m_Heights_4() { return static_cast<int32_t>(offsetof(MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44, ___m_Heights_4)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_m_Heights_4() const { return ___m_Heights_4; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_m_Heights_4() { return &___m_Heights_4; }
	inline void set_m_Heights_4(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___m_Heights_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_Heights_4), value);
	}

	inline static int32_t get_offset_of_m_Settings_5() { return static_cast<int32_t>(offsetof(MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44, ___m_Settings_5)); }
	inline AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88 * get_m_Settings_5() const { return ___m_Settings_5; }
	inline AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88 ** get_address_of_m_Settings_5() { return &___m_Settings_5; }
	inline void set_m_Settings_5(AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88 * value)
	{
		___m_Settings_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_Settings_5), value);
	}

	inline static int32_t get_offset_of_m_PropertySheet_6() { return static_cast<int32_t>(offsetof(MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44, ___m_PropertySheet_6)); }
	inline PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 * get_m_PropertySheet_6() const { return ___m_PropertySheet_6; }
	inline PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 ** get_address_of_m_PropertySheet_6() { return &___m_PropertySheet_6; }
	inline void set_m_PropertySheet_6(PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 * value)
	{
		___m_PropertySheet_6 = value;
		Il2CppCodeGenWriteBarrier((&___m_PropertySheet_6), value);
	}

	inline static int32_t get_offset_of_m_Resources_7() { return static_cast<int32_t>(offsetof(MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44, ___m_Resources_7)); }
	inline PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 * get_m_Resources_7() const { return ___m_Resources_7; }
	inline PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 ** get_address_of_m_Resources_7() { return &___m_Resources_7; }
	inline void set_m_Resources_7(PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 * value)
	{
		___m_Resources_7 = value;
		Il2CppCodeGenWriteBarrier((&___m_Resources_7), value);
	}

	inline static int32_t get_offset_of_m_AmbientOnlyAO_8() { return static_cast<int32_t>(offsetof(MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44, ___m_AmbientOnlyAO_8)); }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * get_m_AmbientOnlyAO_8() const { return ___m_AmbientOnlyAO_8; }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 ** get_address_of_m_AmbientOnlyAO_8() { return &___m_AmbientOnlyAO_8; }
	inline void set_m_AmbientOnlyAO_8(RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * value)
	{
		___m_AmbientOnlyAO_8 = value;
		Il2CppCodeGenWriteBarrier((&___m_AmbientOnlyAO_8), value);
	}

	inline static int32_t get_offset_of_m_MRT_9() { return static_cast<int32_t>(offsetof(MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44, ___m_MRT_9)); }
	inline RenderTargetIdentifierU5BU5D_t57069CA3F97B36638E39044168D1BEB956436DD4* get_m_MRT_9() const { return ___m_MRT_9; }
	inline RenderTargetIdentifierU5BU5D_t57069CA3F97B36638E39044168D1BEB956436DD4** get_address_of_m_MRT_9() { return &___m_MRT_9; }
	inline void set_m_MRT_9(RenderTargetIdentifierU5BU5D_t57069CA3F97B36638E39044168D1BEB956436DD4* value)
	{
		___m_MRT_9 = value;
		Il2CppCodeGenWriteBarrier((&___m_MRT_9), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MULTISCALEVO_T72BE3B27E520D5E61AD22146EBA6AF504013DF44_H
#ifndef PARAMETEROVERRIDE_T33733D55B6D63C97BF769220036767852B4AFB5F_H
#define PARAMETEROVERRIDE_T33733D55B6D63C97BF769220036767852B4AFB5F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride
struct  ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F  : public RuntimeObject
{
public:
	// System.Boolean UnityEngine.Rendering.PostProcessing.ParameterOverride::overrideState
	bool ___overrideState_0;

public:
	inline static int32_t get_offset_of_overrideState_0() { return static_cast<int32_t>(offsetof(ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F, ___overrideState_0)); }
	inline bool get_overrideState_0() const { return ___overrideState_0; }
	inline bool* get_address_of_overrideState_0() { return &___overrideState_0; }
	inline void set_overrideState_0(bool value)
	{
		___overrideState_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_T33733D55B6D63C97BF769220036767852B4AFB5F_H
#ifndef POSTPROCESSEFFECTRENDERER_T790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C_H
#define POSTPROCESSEFFECTRENDERER_T790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer
struct  PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C  : public RuntimeObject
{
public:
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer::m_ResetHistory
	bool ___m_ResetHistory_0;

public:
	inline static int32_t get_offset_of_m_ResetHistory_0() { return static_cast<int32_t>(offsetof(PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C, ___m_ResetHistory_0)); }
	inline bool get_m_ResetHistory_0() const { return ___m_ResetHistory_0; }
	inline bool* get_address_of_m_ResetHistory_0() { return &___m_ResetHistory_0; }
	inline void set_m_ResetHistory_0(bool value)
	{
		___m_ResetHistory_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEFFECTRENDERER_T790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C_H
#ifndef SCALABLEAO_T80A96F6B497216939B5D65393ABFF12B70F26A4B_H
#define SCALABLEAO_T80A96F6B497216939B5D65393ABFF12B70F26A4B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ScalableAO
struct  ScalableAO_t80A96F6B497216939B5D65393ABFF12B70F26A4B  : public RuntimeObject
{
public:
	// UnityEngine.RenderTexture UnityEngine.Rendering.PostProcessing.ScalableAO::m_Result
	RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * ___m_Result_0;
	// UnityEngine.Rendering.PostProcessing.PropertySheet UnityEngine.Rendering.PostProcessing.ScalableAO::m_PropertySheet
	PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 * ___m_PropertySheet_1;
	// UnityEngine.Rendering.PostProcessing.AmbientOcclusion UnityEngine.Rendering.PostProcessing.ScalableAO::m_Settings
	AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88 * ___m_Settings_2;
	// UnityEngine.Rendering.RenderTargetIdentifier[] UnityEngine.Rendering.PostProcessing.ScalableAO::m_MRT
	RenderTargetIdentifierU5BU5D_t57069CA3F97B36638E39044168D1BEB956436DD4* ___m_MRT_3;
	// System.Int32[] UnityEngine.Rendering.PostProcessing.ScalableAO::m_SampleCount
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___m_SampleCount_4;

public:
	inline static int32_t get_offset_of_m_Result_0() { return static_cast<int32_t>(offsetof(ScalableAO_t80A96F6B497216939B5D65393ABFF12B70F26A4B, ___m_Result_0)); }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * get_m_Result_0() const { return ___m_Result_0; }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 ** get_address_of_m_Result_0() { return &___m_Result_0; }
	inline void set_m_Result_0(RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * value)
	{
		___m_Result_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_Result_0), value);
	}

	inline static int32_t get_offset_of_m_PropertySheet_1() { return static_cast<int32_t>(offsetof(ScalableAO_t80A96F6B497216939B5D65393ABFF12B70F26A4B, ___m_PropertySheet_1)); }
	inline PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 * get_m_PropertySheet_1() const { return ___m_PropertySheet_1; }
	inline PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 ** get_address_of_m_PropertySheet_1() { return &___m_PropertySheet_1; }
	inline void set_m_PropertySheet_1(PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 * value)
	{
		___m_PropertySheet_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_PropertySheet_1), value);
	}

	inline static int32_t get_offset_of_m_Settings_2() { return static_cast<int32_t>(offsetof(ScalableAO_t80A96F6B497216939B5D65393ABFF12B70F26A4B, ___m_Settings_2)); }
	inline AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88 * get_m_Settings_2() const { return ___m_Settings_2; }
	inline AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88 ** get_address_of_m_Settings_2() { return &___m_Settings_2; }
	inline void set_m_Settings_2(AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88 * value)
	{
		___m_Settings_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_Settings_2), value);
	}

	inline static int32_t get_offset_of_m_MRT_3() { return static_cast<int32_t>(offsetof(ScalableAO_t80A96F6B497216939B5D65393ABFF12B70F26A4B, ___m_MRT_3)); }
	inline RenderTargetIdentifierU5BU5D_t57069CA3F97B36638E39044168D1BEB956436DD4* get_m_MRT_3() const { return ___m_MRT_3; }
	inline RenderTargetIdentifierU5BU5D_t57069CA3F97B36638E39044168D1BEB956436DD4** get_address_of_m_MRT_3() { return &___m_MRT_3; }
	inline void set_m_MRT_3(RenderTargetIdentifierU5BU5D_t57069CA3F97B36638E39044168D1BEB956436DD4* value)
	{
		___m_MRT_3 = value;
		Il2CppCodeGenWriteBarrier((&___m_MRT_3), value);
	}

	inline static int32_t get_offset_of_m_SampleCount_4() { return static_cast<int32_t>(offsetof(ScalableAO_t80A96F6B497216939B5D65393ABFF12B70F26A4B, ___m_SampleCount_4)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_m_SampleCount_4() const { return ___m_SampleCount_4; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_m_SampleCount_4() { return &___m_SampleCount_4; }
	inline void set_m_SampleCount_4(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___m_SampleCount_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_SampleCount_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SCALABLEAO_T80A96F6B497216939B5D65393ABFF12B70F26A4B_H
#ifndef SETTINGS_T66035998D175B806D5716B35A62E2BCA7FC51F46_H
#define SETTINGS_T66035998D175B806D5716B35A62E2BCA7FC51F46_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Quilt_Settings
struct  Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46 
{
public:
	// System.Int32 LookingGlass.Quilt_Settings::quiltWidth
	int32_t ___quiltWidth_0;
	// System.Int32 LookingGlass.Quilt_Settings::quiltHeight
	int32_t ___quiltHeight_1;
	// System.Int32 LookingGlass.Quilt_Settings::viewColumns
	int32_t ___viewColumns_2;
	// System.Int32 LookingGlass.Quilt_Settings::viewRows
	int32_t ___viewRows_3;
	// System.Int32 LookingGlass.Quilt_Settings::numViews
	int32_t ___numViews_4;
	// System.Int32 LookingGlass.Quilt_Settings::viewWidth
	int32_t ___viewWidth_5;
	// System.Int32 LookingGlass.Quilt_Settings::viewHeight
	int32_t ___viewHeight_6;
	// System.Int32 LookingGlass.Quilt_Settings::paddingHorizontal
	int32_t ___paddingHorizontal_7;
	// System.Int32 LookingGlass.Quilt_Settings::paddingVertical
	int32_t ___paddingVertical_8;
	// System.Single LookingGlass.Quilt_Settings::viewPortionHorizontal
	float ___viewPortionHorizontal_9;
	// System.Single LookingGlass.Quilt_Settings::viewPortionVertical
	float ___viewPortionVertical_10;
	// System.Single LookingGlass.Quilt_Settings::aspect
	float ___aspect_11;
	// System.Boolean LookingGlass.Quilt_Settings::overscan
	bool ___overscan_12;

public:
	inline static int32_t get_offset_of_quiltWidth_0() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___quiltWidth_0)); }
	inline int32_t get_quiltWidth_0() const { return ___quiltWidth_0; }
	inline int32_t* get_address_of_quiltWidth_0() { return &___quiltWidth_0; }
	inline void set_quiltWidth_0(int32_t value)
	{
		___quiltWidth_0 = value;
	}

	inline static int32_t get_offset_of_quiltHeight_1() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___quiltHeight_1)); }
	inline int32_t get_quiltHeight_1() const { return ___quiltHeight_1; }
	inline int32_t* get_address_of_quiltHeight_1() { return &___quiltHeight_1; }
	inline void set_quiltHeight_1(int32_t value)
	{
		___quiltHeight_1 = value;
	}

	inline static int32_t get_offset_of_viewColumns_2() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___viewColumns_2)); }
	inline int32_t get_viewColumns_2() const { return ___viewColumns_2; }
	inline int32_t* get_address_of_viewColumns_2() { return &___viewColumns_2; }
	inline void set_viewColumns_2(int32_t value)
	{
		___viewColumns_2 = value;
	}

	inline static int32_t get_offset_of_viewRows_3() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___viewRows_3)); }
	inline int32_t get_viewRows_3() const { return ___viewRows_3; }
	inline int32_t* get_address_of_viewRows_3() { return &___viewRows_3; }
	inline void set_viewRows_3(int32_t value)
	{
		___viewRows_3 = value;
	}

	inline static int32_t get_offset_of_numViews_4() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___numViews_4)); }
	inline int32_t get_numViews_4() const { return ___numViews_4; }
	inline int32_t* get_address_of_numViews_4() { return &___numViews_4; }
	inline void set_numViews_4(int32_t value)
	{
		___numViews_4 = value;
	}

	inline static int32_t get_offset_of_viewWidth_5() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___viewWidth_5)); }
	inline int32_t get_viewWidth_5() const { return ___viewWidth_5; }
	inline int32_t* get_address_of_viewWidth_5() { return &___viewWidth_5; }
	inline void set_viewWidth_5(int32_t value)
	{
		___viewWidth_5 = value;
	}

	inline static int32_t get_offset_of_viewHeight_6() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___viewHeight_6)); }
	inline int32_t get_viewHeight_6() const { return ___viewHeight_6; }
	inline int32_t* get_address_of_viewHeight_6() { return &___viewHeight_6; }
	inline void set_viewHeight_6(int32_t value)
	{
		___viewHeight_6 = value;
	}

	inline static int32_t get_offset_of_paddingHorizontal_7() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___paddingHorizontal_7)); }
	inline int32_t get_paddingHorizontal_7() const { return ___paddingHorizontal_7; }
	inline int32_t* get_address_of_paddingHorizontal_7() { return &___paddingHorizontal_7; }
	inline void set_paddingHorizontal_7(int32_t value)
	{
		___paddingHorizontal_7 = value;
	}

	inline static int32_t get_offset_of_paddingVertical_8() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___paddingVertical_8)); }
	inline int32_t get_paddingVertical_8() const { return ___paddingVertical_8; }
	inline int32_t* get_address_of_paddingVertical_8() { return &___paddingVertical_8; }
	inline void set_paddingVertical_8(int32_t value)
	{
		___paddingVertical_8 = value;
	}

	inline static int32_t get_offset_of_viewPortionHorizontal_9() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___viewPortionHorizontal_9)); }
	inline float get_viewPortionHorizontal_9() const { return ___viewPortionHorizontal_9; }
	inline float* get_address_of_viewPortionHorizontal_9() { return &___viewPortionHorizontal_9; }
	inline void set_viewPortionHorizontal_9(float value)
	{
		___viewPortionHorizontal_9 = value;
	}

	inline static int32_t get_offset_of_viewPortionVertical_10() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___viewPortionVertical_10)); }
	inline float get_viewPortionVertical_10() const { return ___viewPortionVertical_10; }
	inline float* get_address_of_viewPortionVertical_10() { return &___viewPortionVertical_10; }
	inline void set_viewPortionVertical_10(float value)
	{
		___viewPortionVertical_10 = value;
	}

	inline static int32_t get_offset_of_aspect_11() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___aspect_11)); }
	inline float get_aspect_11() const { return ___aspect_11; }
	inline float* get_address_of_aspect_11() { return &___aspect_11; }
	inline void set_aspect_11(float value)
	{
		___aspect_11 = value;
	}

	inline static int32_t get_offset_of_overscan_12() { return static_cast<int32_t>(offsetof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46, ___overscan_12)); }
	inline bool get_overscan_12() const { return ___overscan_12; }
	inline bool* get_address_of_overscan_12() { return &___overscan_12; }
	inline void set_overscan_12(bool value)
	{
		___overscan_12 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of LookingGlass.Quilt/Settings
struct Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46_marshaled_pinvoke
{
	int32_t ___quiltWidth_0;
	int32_t ___quiltHeight_1;
	int32_t ___viewColumns_2;
	int32_t ___viewRows_3;
	int32_t ___numViews_4;
	int32_t ___viewWidth_5;
	int32_t ___viewHeight_6;
	int32_t ___paddingHorizontal_7;
	int32_t ___paddingVertical_8;
	float ___viewPortionHorizontal_9;
	float ___viewPortionVertical_10;
	float ___aspect_11;
	int32_t ___overscan_12;
};
// Native definition for COM marshalling of LookingGlass.Quilt/Settings
struct Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46_marshaled_com
{
	int32_t ___quiltWidth_0;
	int32_t ___quiltHeight_1;
	int32_t ___viewColumns_2;
	int32_t ___viewRows_3;
	int32_t ___numViews_4;
	int32_t ___viewWidth_5;
	int32_t ___viewHeight_6;
	int32_t ___paddingHorizontal_7;
	int32_t ___paddingVertical_8;
	float ___viewPortionHorizontal_9;
	float ___viewPortionVertical_10;
	float ___aspect_11;
	int32_t ___overscan_12;
};
#endif // SETTINGS_T66035998D175B806D5716B35A62E2BCA7FC51F46_H
#ifndef ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#define ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t2AF27C02B8653AE29442467390005ABC74D8F521  : public ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF
{
public:

public:
};

struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((&___enumSeperatorCharArray_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_com
{
};
#endif // ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef COLOR_T119BCA590009762C7223FDD3AF9706653AC84ED2_H
#define COLOR_T119BCA590009762C7223FDD3AF9706653AC84ED2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Color
struct  Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 
{
public:
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;

public:
	inline static int32_t get_offset_of_r_0() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___r_0)); }
	inline float get_r_0() const { return ___r_0; }
	inline float* get_address_of_r_0() { return &___r_0; }
	inline void set_r_0(float value)
	{
		___r_0 = value;
	}

	inline static int32_t get_offset_of_g_1() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___g_1)); }
	inline float get_g_1() const { return ___g_1; }
	inline float* get_address_of_g_1() { return &___g_1; }
	inline void set_g_1(float value)
	{
		___g_1 = value;
	}

	inline static int32_t get_offset_of_b_2() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___b_2)); }
	inline float get_b_2() const { return ___b_2; }
	inline float* get_address_of_b_2() { return &___b_2; }
	inline void set_b_2(float value)
	{
		___b_2 = value;
	}

	inline static int32_t get_offset_of_a_3() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___a_3)); }
	inline float get_a_3() const { return ___a_3; }
	inline float* get_address_of_a_3() { return &___a_3; }
	inline void set_a_3(float value)
	{
		___a_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLOR_T119BCA590009762C7223FDD3AF9706653AC84ED2_H
#ifndef LEVEL_TE2980211EF4547353F9E222FF0F8C8DC9B7D18BC_H
#define LEVEL_TE2980211EF4547353F9E222FF0F8C8DC9B7D18BC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.BloomRenderer_Level
struct  Level_tE2980211EF4547353F9E222FF0F8C8DC9B7D18BC 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.BloomRenderer_Level::down
	int32_t ___down_0;
	// System.Int32 UnityEngine.Rendering.PostProcessing.BloomRenderer_Level::up
	int32_t ___up_1;

public:
	inline static int32_t get_offset_of_down_0() { return static_cast<int32_t>(offsetof(Level_tE2980211EF4547353F9E222FF0F8C8DC9B7D18BC, ___down_0)); }
	inline int32_t get_down_0() const { return ___down_0; }
	inline int32_t* get_address_of_down_0() { return &___down_0; }
	inline void set_down_0(int32_t value)
	{
		___down_0 = value;
	}

	inline static int32_t get_offset_of_up_1() { return static_cast<int32_t>(offsetof(Level_tE2980211EF4547353F9E222FF0F8C8DC9B7D18BC, ___up_1)); }
	inline int32_t get_up_1() const { return ___up_1; }
	inline int32_t* get_address_of_up_1() { return &___up_1; }
	inline void set_up_1(int32_t value)
	{
		___up_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LEVEL_TE2980211EF4547353F9E222FF0F8C8DC9B7D18BC_H
#ifndef DISPLAYNAMEATTRIBUTE_TFC24645A823EED0DE46DF51BCAFC54E78080B0CD_H
#define DISPLAYNAMEATTRIBUTE_TFC24645A823EED0DE46DF51BCAFC54E78080B0CD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.DisplayNameAttribute
struct  DisplayNameAttribute_tFC24645A823EED0DE46DF51BCAFC54E78080B0CD  : public Attribute_tF048C13FB3C8CFCC53F82290E4A3F621089F9A74
{
public:
	// System.String UnityEngine.Rendering.PostProcessing.DisplayNameAttribute::displayName
	String_t* ___displayName_0;

public:
	inline static int32_t get_offset_of_displayName_0() { return static_cast<int32_t>(offsetof(DisplayNameAttribute_tFC24645A823EED0DE46DF51BCAFC54E78080B0CD, ___displayName_0)); }
	inline String_t* get_displayName_0() const { return ___displayName_0; }
	inline String_t** get_address_of_displayName_0() { return &___displayName_0; }
	inline void set_displayName_0(String_t* value)
	{
		___displayName_0 = value;
		Il2CppCodeGenWriteBarrier((&___displayName_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DISPLAYNAMEATTRIBUTE_TFC24645A823EED0DE46DF51BCAFC54E78080B0CD_H
#ifndef LIGHTMETERMONITOR_T103A765AA459E486B43DFDD70451D3692977A684_H
#define LIGHTMETERMONITOR_T103A765AA459E486B43DFDD70451D3692977A684_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.LightMeterMonitor
struct  LightMeterMonitor_t103A765AA459E486B43DFDD70451D3692977A684  : public Monitor_tE317BECFE50FD51B2BBC2609C33E6ABE76A6338E
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.LightMeterMonitor::width
	int32_t ___width_2;
	// System.Int32 UnityEngine.Rendering.PostProcessing.LightMeterMonitor::height
	int32_t ___height_3;
	// System.Boolean UnityEngine.Rendering.PostProcessing.LightMeterMonitor::showCurves
	bool ___showCurves_4;

public:
	inline static int32_t get_offset_of_width_2() { return static_cast<int32_t>(offsetof(LightMeterMonitor_t103A765AA459E486B43DFDD70451D3692977A684, ___width_2)); }
	inline int32_t get_width_2() const { return ___width_2; }
	inline int32_t* get_address_of_width_2() { return &___width_2; }
	inline void set_width_2(int32_t value)
	{
		___width_2 = value;
	}

	inline static int32_t get_offset_of_height_3() { return static_cast<int32_t>(offsetof(LightMeterMonitor_t103A765AA459E486B43DFDD70451D3692977A684, ___height_3)); }
	inline int32_t get_height_3() const { return ___height_3; }
	inline int32_t* get_address_of_height_3() { return &___height_3; }
	inline void set_height_3(int32_t value)
	{
		___height_3 = value;
	}

	inline static int32_t get_offset_of_showCurves_4() { return static_cast<int32_t>(offsetof(LightMeterMonitor_t103A765AA459E486B43DFDD70451D3692977A684, ___showCurves_4)); }
	inline bool get_showCurves_4() const { return ___showCurves_4; }
	inline bool* get_address_of_showCurves_4() { return &___showCurves_4; }
	inline void set_showCurves_4(bool value)
	{
		___showCurves_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIGHTMETERMONITOR_T103A765AA459E486B43DFDD70451D3692977A684_H
#ifndef MAXATTRIBUTE_T286062821EC77935B79E0412828BC70BAA854CB1_H
#define MAXATTRIBUTE_T286062821EC77935B79E0412828BC70BAA854CB1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.MaxAttribute
struct  MaxAttribute_t286062821EC77935B79E0412828BC70BAA854CB1  : public Attribute_tF048C13FB3C8CFCC53F82290E4A3F621089F9A74
{
public:
	// System.Single UnityEngine.Rendering.PostProcessing.MaxAttribute::max
	float ___max_0;

public:
	inline static int32_t get_offset_of_max_0() { return static_cast<int32_t>(offsetof(MaxAttribute_t286062821EC77935B79E0412828BC70BAA854CB1, ___max_0)); }
	inline float get_max_0() const { return ___max_0; }
	inline float* get_address_of_max_0() { return &___max_0; }
	inline void set_max_0(float value)
	{
		___max_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MAXATTRIBUTE_T286062821EC77935B79E0412828BC70BAA854CB1_H
#ifndef MINATTRIBUTE_T31D810015C891DCB1E4CDCF4F5F150A80B341A56_H
#define MINATTRIBUTE_T31D810015C891DCB1E4CDCF4F5F150A80B341A56_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.MinAttribute
struct  MinAttribute_t31D810015C891DCB1E4CDCF4F5F150A80B341A56  : public Attribute_tF048C13FB3C8CFCC53F82290E4A3F621089F9A74
{
public:
	// System.Single UnityEngine.Rendering.PostProcessing.MinAttribute::min
	float ___min_0;

public:
	inline static int32_t get_offset_of_min_0() { return static_cast<int32_t>(offsetof(MinAttribute_t31D810015C891DCB1E4CDCF4F5F150A80B341A56, ___min_0)); }
	inline float get_min_0() const { return ___min_0; }
	inline float* get_address_of_min_0() { return &___min_0; }
	inline void set_min_0(float value)
	{
		___min_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MINATTRIBUTE_T31D810015C891DCB1E4CDCF4F5F150A80B341A56_H
#ifndef MINMAXATTRIBUTE_T1B75CAA0E8D21C67E1325ED64644644ECBD2383E_H
#define MINMAXATTRIBUTE_T1B75CAA0E8D21C67E1325ED64644644ECBD2383E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.MinMaxAttribute
struct  MinMaxAttribute_t1B75CAA0E8D21C67E1325ED64644644ECBD2383E  : public Attribute_tF048C13FB3C8CFCC53F82290E4A3F621089F9A74
{
public:
	// System.Single UnityEngine.Rendering.PostProcessing.MinMaxAttribute::min
	float ___min_0;
	// System.Single UnityEngine.Rendering.PostProcessing.MinMaxAttribute::max
	float ___max_1;

public:
	inline static int32_t get_offset_of_min_0() { return static_cast<int32_t>(offsetof(MinMaxAttribute_t1B75CAA0E8D21C67E1325ED64644644ECBD2383E, ___min_0)); }
	inline float get_min_0() const { return ___min_0; }
	inline float* get_address_of_min_0() { return &___min_0; }
	inline void set_min_0(float value)
	{
		___min_0 = value;
	}

	inline static int32_t get_offset_of_max_1() { return static_cast<int32_t>(offsetof(MinMaxAttribute_t1B75CAA0E8D21C67E1325ED64644644ECBD2383E, ___max_1)); }
	inline float get_max_1() const { return ___max_1; }
	inline float* get_address_of_max_1() { return &___max_1; }
	inline void set_max_1(float value)
	{
		___max_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MINMAXATTRIBUTE_T1B75CAA0E8D21C67E1325ED64644644ECBD2383E_H
#ifndef PARAMETEROVERRIDE_1_T3E0F0485F30346446015285000468E9C14046417_H
#define PARAMETEROVERRIDE_1_T3E0F0485F30346446015285000468E9C14046417_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<System.Boolean>
struct  ParameterOverride_1_t3E0F0485F30346446015285000468E9C14046417  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	bool ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_t3E0F0485F30346446015285000468E9C14046417, ___value_1)); }
	inline bool get_value_1() const { return ___value_1; }
	inline bool* get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(bool value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_T3E0F0485F30346446015285000468E9C14046417_H
#ifndef PARAMETEROVERRIDE_1_TFEC3B3FD3EB1D850E64F32B33AD557305BFE5B09_H
#define PARAMETEROVERRIDE_1_TFEC3B3FD3EB1D850E64F32B33AD557305BFE5B09_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<System.Int32>
struct  ParameterOverride_1_tFEC3B3FD3EB1D850E64F32B33AD557305BFE5B09  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	int32_t ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_tFEC3B3FD3EB1D850E64F32B33AD557305BFE5B09, ___value_1)); }
	inline int32_t get_value_1() const { return ___value_1; }
	inline int32_t* get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(int32_t value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_TFEC3B3FD3EB1D850E64F32B33AD557305BFE5B09_H
#ifndef PARAMETEROVERRIDE_1_TD862C720E602CF48A201439C668E2546C254FD2F_H
#define PARAMETEROVERRIDE_1_TD862C720E602CF48A201439C668E2546C254FD2F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<System.Single>
struct  ParameterOverride_1_tD862C720E602CF48A201439C668E2546C254FD2F  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	float ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_tD862C720E602CF48A201439C668E2546C254FD2F, ___value_1)); }
	inline float get_value_1() const { return ___value_1; }
	inline float* get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(float value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_TD862C720E602CF48A201439C668E2546C254FD2F_H
#ifndef PARAMETEROVERRIDE_1_TA7F786BD18721EEA18B5816C17B6F488FEE1ABC4_H
#define PARAMETEROVERRIDE_1_TA7F786BD18721EEA18B5816C17B6F488FEE1ABC4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<UnityEngine.Rendering.PostProcessing.Spline>
struct  ParameterOverride_1_tA7F786BD18721EEA18B5816C17B6F488FEE1ABC4  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	Spline_tE37069226E0B86697627CCEA38297277E55030CD * ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_tA7F786BD18721EEA18B5816C17B6F488FEE1ABC4, ___value_1)); }
	inline Spline_tE37069226E0B86697627CCEA38297277E55030CD * get_value_1() const { return ___value_1; }
	inline Spline_tE37069226E0B86697627CCEA38297277E55030CD ** get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(Spline_tE37069226E0B86697627CCEA38297277E55030CD * value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((&___value_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_TA7F786BD18721EEA18B5816C17B6F488FEE1ABC4_H
#ifndef POSTPROCESSEFFECTRENDERER_1_T09CF00282A9D4637AAA38486DD42A253E3FD58B0_H
#define POSTPROCESSEFFECTRENDERER_1_T09CF00282A9D4637AAA38486DD42A253E3FD58B0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1<UnityEngine.Rendering.PostProcessing.AmbientOcclusion>
struct  PostProcessEffectRenderer_1_t09CF00282A9D4637AAA38486DD42A253E3FD58B0  : public PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C
{
public:
	// T UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1::<settings>k__BackingField
	AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88 * ___U3CsettingsU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CsettingsU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PostProcessEffectRenderer_1_t09CF00282A9D4637AAA38486DD42A253E3FD58B0, ___U3CsettingsU3Ek__BackingField_1)); }
	inline AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88 * get_U3CsettingsU3Ek__BackingField_1() const { return ___U3CsettingsU3Ek__BackingField_1; }
	inline AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88 ** get_address_of_U3CsettingsU3Ek__BackingField_1() { return &___U3CsettingsU3Ek__BackingField_1; }
	inline void set_U3CsettingsU3Ek__BackingField_1(AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88 * value)
	{
		___U3CsettingsU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CsettingsU3Ek__BackingField_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEFFECTRENDERER_1_T09CF00282A9D4637AAA38486DD42A253E3FD58B0_H
#ifndef POSTPROCESSEFFECTRENDERER_1_T35B3530F1E84E26D80D74E8C4B1EDBC177FC8E17_H
#define POSTPROCESSEFFECTRENDERER_1_T35B3530F1E84E26D80D74E8C4B1EDBC177FC8E17_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1<UnityEngine.Rendering.PostProcessing.AutoExposure>
struct  PostProcessEffectRenderer_1_t35B3530F1E84E26D80D74E8C4B1EDBC177FC8E17  : public PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C
{
public:
	// T UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1::<settings>k__BackingField
	AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C * ___U3CsettingsU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CsettingsU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PostProcessEffectRenderer_1_t35B3530F1E84E26D80D74E8C4B1EDBC177FC8E17, ___U3CsettingsU3Ek__BackingField_1)); }
	inline AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C * get_U3CsettingsU3Ek__BackingField_1() const { return ___U3CsettingsU3Ek__BackingField_1; }
	inline AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C ** get_address_of_U3CsettingsU3Ek__BackingField_1() { return &___U3CsettingsU3Ek__BackingField_1; }
	inline void set_U3CsettingsU3Ek__BackingField_1(AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C * value)
	{
		___U3CsettingsU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CsettingsU3Ek__BackingField_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEFFECTRENDERER_1_T35B3530F1E84E26D80D74E8C4B1EDBC177FC8E17_H
#ifndef POSTPROCESSEFFECTRENDERER_1_T19E973E0507669F859DC42EF3AFC4221DACE6D92_H
#define POSTPROCESSEFFECTRENDERER_1_T19E973E0507669F859DC42EF3AFC4221DACE6D92_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1<UnityEngine.Rendering.PostProcessing.Bloom>
struct  PostProcessEffectRenderer_1_t19E973E0507669F859DC42EF3AFC4221DACE6D92  : public PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C
{
public:
	// T UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1::<settings>k__BackingField
	Bloom_t366FA2D84798539D570B23E02789925E1079B3DD * ___U3CsettingsU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CsettingsU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PostProcessEffectRenderer_1_t19E973E0507669F859DC42EF3AFC4221DACE6D92, ___U3CsettingsU3Ek__BackingField_1)); }
	inline Bloom_t366FA2D84798539D570B23E02789925E1079B3DD * get_U3CsettingsU3Ek__BackingField_1() const { return ___U3CsettingsU3Ek__BackingField_1; }
	inline Bloom_t366FA2D84798539D570B23E02789925E1079B3DD ** get_address_of_U3CsettingsU3Ek__BackingField_1() { return &___U3CsettingsU3Ek__BackingField_1; }
	inline void set_U3CsettingsU3Ek__BackingField_1(Bloom_t366FA2D84798539D570B23E02789925E1079B3DD * value)
	{
		___U3CsettingsU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CsettingsU3Ek__BackingField_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEFFECTRENDERER_1_T19E973E0507669F859DC42EF3AFC4221DACE6D92_H
#ifndef POSTPROCESSEFFECTRENDERER_1_TDCFD602822B9B17523E0C0ABA1F0D38D393C8F48_H
#define POSTPROCESSEFFECTRENDERER_1_TDCFD602822B9B17523E0C0ABA1F0D38D393C8F48_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1<UnityEngine.Rendering.PostProcessing.ChromaticAberration>
struct  PostProcessEffectRenderer_1_tDCFD602822B9B17523E0C0ABA1F0D38D393C8F48  : public PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C
{
public:
	// T UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1::<settings>k__BackingField
	ChromaticAberration_t78EC7F7C23F37A371DD46BB3F1631FEFF046400F * ___U3CsettingsU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CsettingsU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PostProcessEffectRenderer_1_tDCFD602822B9B17523E0C0ABA1F0D38D393C8F48, ___U3CsettingsU3Ek__BackingField_1)); }
	inline ChromaticAberration_t78EC7F7C23F37A371DD46BB3F1631FEFF046400F * get_U3CsettingsU3Ek__BackingField_1() const { return ___U3CsettingsU3Ek__BackingField_1; }
	inline ChromaticAberration_t78EC7F7C23F37A371DD46BB3F1631FEFF046400F ** get_address_of_U3CsettingsU3Ek__BackingField_1() { return &___U3CsettingsU3Ek__BackingField_1; }
	inline void set_U3CsettingsU3Ek__BackingField_1(ChromaticAberration_t78EC7F7C23F37A371DD46BB3F1631FEFF046400F * value)
	{
		___U3CsettingsU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CsettingsU3Ek__BackingField_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEFFECTRENDERER_1_TDCFD602822B9B17523E0C0ABA1F0D38D393C8F48_H
#ifndef POSTPROCESSEFFECTRENDERER_1_T6E66553820ABDE1818E2CD83971E7FB4BDC89557_H
#define POSTPROCESSEFFECTRENDERER_1_T6E66553820ABDE1818E2CD83971E7FB4BDC89557_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1<UnityEngine.Rendering.PostProcessing.ColorGrading>
struct  PostProcessEffectRenderer_1_t6E66553820ABDE1818E2CD83971E7FB4BDC89557  : public PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C
{
public:
	// T UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1::<settings>k__BackingField
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206 * ___U3CsettingsU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CsettingsU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PostProcessEffectRenderer_1_t6E66553820ABDE1818E2CD83971E7FB4BDC89557, ___U3CsettingsU3Ek__BackingField_1)); }
	inline ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206 * get_U3CsettingsU3Ek__BackingField_1() const { return ___U3CsettingsU3Ek__BackingField_1; }
	inline ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206 ** get_address_of_U3CsettingsU3Ek__BackingField_1() { return &___U3CsettingsU3Ek__BackingField_1; }
	inline void set_U3CsettingsU3Ek__BackingField_1(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206 * value)
	{
		___U3CsettingsU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CsettingsU3Ek__BackingField_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEFFECTRENDERER_1_T6E66553820ABDE1818E2CD83971E7FB4BDC89557_H
#ifndef POSTPROCESSEFFECTRENDERER_1_T6D8C7A5B96C7829A3421121015486BA79F700710_H
#define POSTPROCESSEFFECTRENDERER_1_T6D8C7A5B96C7829A3421121015486BA79F700710_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1<UnityEngine.Rendering.PostProcessing.DepthOfField>
struct  PostProcessEffectRenderer_1_t6D8C7A5B96C7829A3421121015486BA79F700710  : public PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C
{
public:
	// T UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1::<settings>k__BackingField
	DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88 * ___U3CsettingsU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CsettingsU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PostProcessEffectRenderer_1_t6D8C7A5B96C7829A3421121015486BA79F700710, ___U3CsettingsU3Ek__BackingField_1)); }
	inline DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88 * get_U3CsettingsU3Ek__BackingField_1() const { return ___U3CsettingsU3Ek__BackingField_1; }
	inline DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88 ** get_address_of_U3CsettingsU3Ek__BackingField_1() { return &___U3CsettingsU3Ek__BackingField_1; }
	inline void set_U3CsettingsU3Ek__BackingField_1(DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88 * value)
	{
		___U3CsettingsU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CsettingsU3Ek__BackingField_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEFFECTRENDERER_1_T6D8C7A5B96C7829A3421121015486BA79F700710_H
#ifndef POSTPROCESSEFFECTRENDERER_1_TB4EBCA325BC5D9270289A81F7D5D72CFCF8A6DE7_H
#define POSTPROCESSEFFECTRENDERER_1_TB4EBCA325BC5D9270289A81F7D5D72CFCF8A6DE7_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1<UnityEngine.Rendering.PostProcessing.Grain>
struct  PostProcessEffectRenderer_1_tB4EBCA325BC5D9270289A81F7D5D72CFCF8A6DE7  : public PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C
{
public:
	// T UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1::<settings>k__BackingField
	Grain_t0ECCE83708F627DD09B42C375C38AC7387407A66 * ___U3CsettingsU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CsettingsU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PostProcessEffectRenderer_1_tB4EBCA325BC5D9270289A81F7D5D72CFCF8A6DE7, ___U3CsettingsU3Ek__BackingField_1)); }
	inline Grain_t0ECCE83708F627DD09B42C375C38AC7387407A66 * get_U3CsettingsU3Ek__BackingField_1() const { return ___U3CsettingsU3Ek__BackingField_1; }
	inline Grain_t0ECCE83708F627DD09B42C375C38AC7387407A66 ** get_address_of_U3CsettingsU3Ek__BackingField_1() { return &___U3CsettingsU3Ek__BackingField_1; }
	inline void set_U3CsettingsU3Ek__BackingField_1(Grain_t0ECCE83708F627DD09B42C375C38AC7387407A66 * value)
	{
		___U3CsettingsU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CsettingsU3Ek__BackingField_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEFFECTRENDERER_1_TB4EBCA325BC5D9270289A81F7D5D72CFCF8A6DE7_H
#ifndef POSTPROCESSEFFECTRENDERER_1_T69338CD36F660BDD8B6C51C26764368285591CC4_H
#define POSTPROCESSEFFECTRENDERER_1_T69338CD36F660BDD8B6C51C26764368285591CC4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1<UnityEngine.Rendering.PostProcessing.LensDistortion>
struct  PostProcessEffectRenderer_1_t69338CD36F660BDD8B6C51C26764368285591CC4  : public PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C
{
public:
	// T UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1::<settings>k__BackingField
	LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB * ___U3CsettingsU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CsettingsU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PostProcessEffectRenderer_1_t69338CD36F660BDD8B6C51C26764368285591CC4, ___U3CsettingsU3Ek__BackingField_1)); }
	inline LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB * get_U3CsettingsU3Ek__BackingField_1() const { return ___U3CsettingsU3Ek__BackingField_1; }
	inline LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB ** get_address_of_U3CsettingsU3Ek__BackingField_1() { return &___U3CsettingsU3Ek__BackingField_1; }
	inline void set_U3CsettingsU3Ek__BackingField_1(LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB * value)
	{
		___U3CsettingsU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CsettingsU3Ek__BackingField_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEFFECTRENDERER_1_T69338CD36F660BDD8B6C51C26764368285591CC4_H
#ifndef POSTPROCESSEFFECTRENDERER_1_TC225F3992B0BA1F684E9857B077B551DAC285931_H
#define POSTPROCESSEFFECTRENDERER_1_TC225F3992B0BA1F684E9857B077B551DAC285931_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1<UnityEngine.Rendering.PostProcessing.MotionBlur>
struct  PostProcessEffectRenderer_1_tC225F3992B0BA1F684E9857B077B551DAC285931  : public PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C
{
public:
	// T UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1::<settings>k__BackingField
	MotionBlur_tC78F5B6F7B956D0BF4AE2E40BB2917C4FDB95D63 * ___U3CsettingsU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CsettingsU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PostProcessEffectRenderer_1_tC225F3992B0BA1F684E9857B077B551DAC285931, ___U3CsettingsU3Ek__BackingField_1)); }
	inline MotionBlur_tC78F5B6F7B956D0BF4AE2E40BB2917C4FDB95D63 * get_U3CsettingsU3Ek__BackingField_1() const { return ___U3CsettingsU3Ek__BackingField_1; }
	inline MotionBlur_tC78F5B6F7B956D0BF4AE2E40BB2917C4FDB95D63 ** get_address_of_U3CsettingsU3Ek__BackingField_1() { return &___U3CsettingsU3Ek__BackingField_1; }
	inline void set_U3CsettingsU3Ek__BackingField_1(MotionBlur_tC78F5B6F7B956D0BF4AE2E40BB2917C4FDB95D63 * value)
	{
		___U3CsettingsU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CsettingsU3Ek__BackingField_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEFFECTRENDERER_1_TC225F3992B0BA1F684E9857B077B551DAC285931_H
#ifndef POSTPROCESSEFFECTRENDERER_1_TF39455A9F066D9A86491A45D54B5840CBCC8E2C0_H
#define POSTPROCESSEFFECTRENDERER_1_TF39455A9F066D9A86491A45D54B5840CBCC8E2C0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1<UnityEngine.Rendering.PostProcessing.ScreenSpaceReflections>
struct  PostProcessEffectRenderer_1_tF39455A9F066D9A86491A45D54B5840CBCC8E2C0  : public PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C
{
public:
	// T UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1::<settings>k__BackingField
	ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5 * ___U3CsettingsU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CsettingsU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PostProcessEffectRenderer_1_tF39455A9F066D9A86491A45D54B5840CBCC8E2C0, ___U3CsettingsU3Ek__BackingField_1)); }
	inline ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5 * get_U3CsettingsU3Ek__BackingField_1() const { return ___U3CsettingsU3Ek__BackingField_1; }
	inline ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5 ** get_address_of_U3CsettingsU3Ek__BackingField_1() { return &___U3CsettingsU3Ek__BackingField_1; }
	inline void set_U3CsettingsU3Ek__BackingField_1(ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5 * value)
	{
		___U3CsettingsU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CsettingsU3Ek__BackingField_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEFFECTRENDERER_1_TF39455A9F066D9A86491A45D54B5840CBCC8E2C0_H
#ifndef POSTPROCESSEFFECTRENDERER_1_TE69D334B38BB977ABE5C9F0DB0EF2F1DFD1478F3_H
#define POSTPROCESSEFFECTRENDERER_1_TE69D334B38BB977ABE5C9F0DB0EF2F1DFD1478F3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1<UnityEngine.Rendering.PostProcessing.Vignette>
struct  PostProcessEffectRenderer_1_tE69D334B38BB977ABE5C9F0DB0EF2F1DFD1478F3  : public PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C
{
public:
	// T UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer`1::<settings>k__BackingField
	Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E * ___U3CsettingsU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CsettingsU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PostProcessEffectRenderer_1_tE69D334B38BB977ABE5C9F0DB0EF2F1DFD1478F3, ___U3CsettingsU3Ek__BackingField_1)); }
	inline Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E * get_U3CsettingsU3Ek__BackingField_1() const { return ___U3CsettingsU3Ek__BackingField_1; }
	inline Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E ** get_address_of_U3CsettingsU3Ek__BackingField_1() { return &___U3CsettingsU3Ek__BackingField_1; }
	inline void set_U3CsettingsU3Ek__BackingField_1(Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E * value)
	{
		___U3CsettingsU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CsettingsU3Ek__BackingField_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEFFECTRENDERER_1_TE69D334B38BB977ABE5C9F0DB0EF2F1DFD1478F3_H
#ifndef VECTORSCOPEMONITOR_TC3774A687F71D73031BC417A080D6C6BC9C519EA_H
#define VECTORSCOPEMONITOR_TC3774A687F71D73031BC417A080D6C6BC9C519EA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.VectorscopeMonitor
struct  VectorscopeMonitor_tC3774A687F71D73031BC417A080D6C6BC9C519EA  : public Monitor_tE317BECFE50FD51B2BBC2609C33E6ABE76A6338E
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.VectorscopeMonitor::size
	int32_t ___size_2;
	// System.Single UnityEngine.Rendering.PostProcessing.VectorscopeMonitor::exposure
	float ___exposure_3;
	// UnityEngine.ComputeBuffer UnityEngine.Rendering.PostProcessing.VectorscopeMonitor::m_Data
	ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5 * ___m_Data_4;

public:
	inline static int32_t get_offset_of_size_2() { return static_cast<int32_t>(offsetof(VectorscopeMonitor_tC3774A687F71D73031BC417A080D6C6BC9C519EA, ___size_2)); }
	inline int32_t get_size_2() const { return ___size_2; }
	inline int32_t* get_address_of_size_2() { return &___size_2; }
	inline void set_size_2(int32_t value)
	{
		___size_2 = value;
	}

	inline static int32_t get_offset_of_exposure_3() { return static_cast<int32_t>(offsetof(VectorscopeMonitor_tC3774A687F71D73031BC417A080D6C6BC9C519EA, ___exposure_3)); }
	inline float get_exposure_3() const { return ___exposure_3; }
	inline float* get_address_of_exposure_3() { return &___exposure_3; }
	inline void set_exposure_3(float value)
	{
		___exposure_3 = value;
	}

	inline static int32_t get_offset_of_m_Data_4() { return static_cast<int32_t>(offsetof(VectorscopeMonitor_tC3774A687F71D73031BC417A080D6C6BC9C519EA, ___m_Data_4)); }
	inline ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5 * get_m_Data_4() const { return ___m_Data_4; }
	inline ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5 ** get_address_of_m_Data_4() { return &___m_Data_4; }
	inline void set_m_Data_4(ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5 * value)
	{
		___m_Data_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_Data_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTORSCOPEMONITOR_TC3774A687F71D73031BC417A080D6C6BC9C519EA_H
#ifndef WAVEFORMMONITOR_TFB0CBA9B59F081E6C36547430F4E417133968CA8_H
#define WAVEFORMMONITOR_TFB0CBA9B59F081E6C36547430F4E417133968CA8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.WaveformMonitor
struct  WaveformMonitor_tFB0CBA9B59F081E6C36547430F4E417133968CA8  : public Monitor_tE317BECFE50FD51B2BBC2609C33E6ABE76A6338E
{
public:
	// System.Single UnityEngine.Rendering.PostProcessing.WaveformMonitor::exposure
	float ___exposure_2;
	// System.Int32 UnityEngine.Rendering.PostProcessing.WaveformMonitor::height
	int32_t ___height_3;
	// UnityEngine.ComputeBuffer UnityEngine.Rendering.PostProcessing.WaveformMonitor::m_Data
	ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5 * ___m_Data_4;

public:
	inline static int32_t get_offset_of_exposure_2() { return static_cast<int32_t>(offsetof(WaveformMonitor_tFB0CBA9B59F081E6C36547430F4E417133968CA8, ___exposure_2)); }
	inline float get_exposure_2() const { return ___exposure_2; }
	inline float* get_address_of_exposure_2() { return &___exposure_2; }
	inline void set_exposure_2(float value)
	{
		___exposure_2 = value;
	}

	inline static int32_t get_offset_of_height_3() { return static_cast<int32_t>(offsetof(WaveformMonitor_tFB0CBA9B59F081E6C36547430F4E417133968CA8, ___height_3)); }
	inline int32_t get_height_3() const { return ___height_3; }
	inline int32_t* get_address_of_height_3() { return &___height_3; }
	inline void set_height_3(int32_t value)
	{
		___height_3 = value;
	}

	inline static int32_t get_offset_of_m_Data_4() { return static_cast<int32_t>(offsetof(WaveformMonitor_tFB0CBA9B59F081E6C36547430F4E417133968CA8, ___m_Data_4)); }
	inline ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5 * get_m_Data_4() const { return ___m_Data_4; }
	inline ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5 ** get_address_of_m_Data_4() { return &___m_Data_4; }
	inline void set_m_Data_4(ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5 * value)
	{
		___m_Data_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_Data_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WAVEFORMMONITOR_TFB0CBA9B59F081E6C36547430F4E417133968CA8_H
#ifndef VECTOR2_TA85D2DD88578276CA8A8796756458277E72D073D_H
#define VECTOR2_TA85D2DD88578276CA8A8796756458277E72D073D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector2
struct  Vector2_tA85D2DD88578276CA8A8796756458277E72D073D 
{
public:
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}
};

struct Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields
{
public:
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___negativeInfinityVector_9;

public:
	inline static int32_t get_offset_of_zeroVector_2() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___zeroVector_2)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_zeroVector_2() const { return ___zeroVector_2; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_zeroVector_2() { return &___zeroVector_2; }
	inline void set_zeroVector_2(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___zeroVector_2 = value;
	}

	inline static int32_t get_offset_of_oneVector_3() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___oneVector_3)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_oneVector_3() const { return ___oneVector_3; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_oneVector_3() { return &___oneVector_3; }
	inline void set_oneVector_3(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___oneVector_3 = value;
	}

	inline static int32_t get_offset_of_upVector_4() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___upVector_4)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_upVector_4() const { return ___upVector_4; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_upVector_4() { return &___upVector_4; }
	inline void set_upVector_4(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___upVector_4 = value;
	}

	inline static int32_t get_offset_of_downVector_5() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___downVector_5)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_downVector_5() const { return ___downVector_5; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_downVector_5() { return &___downVector_5; }
	inline void set_downVector_5(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___downVector_5 = value;
	}

	inline static int32_t get_offset_of_leftVector_6() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___leftVector_6)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_leftVector_6() const { return ___leftVector_6; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_leftVector_6() { return &___leftVector_6; }
	inline void set_leftVector_6(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___leftVector_6 = value;
	}

	inline static int32_t get_offset_of_rightVector_7() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___rightVector_7)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_rightVector_7() const { return ___rightVector_7; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_rightVector_7() { return &___rightVector_7; }
	inline void set_rightVector_7(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___rightVector_7 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___positiveInfinityVector_8)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_positiveInfinityVector_8() const { return ___positiveInfinityVector_8; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_positiveInfinityVector_8() { return &___positiveInfinityVector_8; }
	inline void set_positiveInfinityVector_8(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___positiveInfinityVector_8 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_9() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___negativeInfinityVector_9)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_negativeInfinityVector_9() const { return ___negativeInfinityVector_9; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_negativeInfinityVector_9() { return &___negativeInfinityVector_9; }
	inline void set_negativeInfinityVector_9(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___negativeInfinityVector_9 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR2_TA85D2DD88578276CA8A8796756458277E72D073D_H
#ifndef VECTOR3_TDCF05E21F632FE2BA260C06E0D10CA81513E6720_H
#define VECTOR3_TDCF05E21F632FE2BA260C06E0D10CA81513E6720_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector3
struct  Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 
{
public:
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;

public:
	inline static int32_t get_offset_of_x_2() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___x_2)); }
	inline float get_x_2() const { return ___x_2; }
	inline float* get_address_of_x_2() { return &___x_2; }
	inline void set_x_2(float value)
	{
		___x_2 = value;
	}

	inline static int32_t get_offset_of_y_3() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___y_3)); }
	inline float get_y_3() const { return ___y_3; }
	inline float* get_address_of_y_3() { return &___y_3; }
	inline void set_y_3(float value)
	{
		___y_3 = value;
	}

	inline static int32_t get_offset_of_z_4() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___z_4)); }
	inline float get_z_4() const { return ___z_4; }
	inline float* get_address_of_z_4() { return &___z_4; }
	inline void set_z_4(float value)
	{
		___z_4 = value;
	}
};

struct Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields
{
public:
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___negativeInfinityVector_14;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___zeroVector_5)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___oneVector_6)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_upVector_7() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___upVector_7)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_upVector_7() const { return ___upVector_7; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_upVector_7() { return &___upVector_7; }
	inline void set_upVector_7(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___upVector_7 = value;
	}

	inline static int32_t get_offset_of_downVector_8() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___downVector_8)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_downVector_8() const { return ___downVector_8; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_downVector_8() { return &___downVector_8; }
	inline void set_downVector_8(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___downVector_8 = value;
	}

	inline static int32_t get_offset_of_leftVector_9() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___leftVector_9)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_leftVector_9() const { return ___leftVector_9; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_leftVector_9() { return &___leftVector_9; }
	inline void set_leftVector_9(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___leftVector_9 = value;
	}

	inline static int32_t get_offset_of_rightVector_10() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___rightVector_10)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_rightVector_10() const { return ___rightVector_10; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_rightVector_10() { return &___rightVector_10; }
	inline void set_rightVector_10(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___rightVector_10 = value;
	}

	inline static int32_t get_offset_of_forwardVector_11() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___forwardVector_11)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_forwardVector_11() const { return ___forwardVector_11; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_forwardVector_11() { return &___forwardVector_11; }
	inline void set_forwardVector_11(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___forwardVector_11 = value;
	}

	inline static int32_t get_offset_of_backVector_12() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___backVector_12)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_backVector_12() const { return ___backVector_12; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_backVector_12() { return &___backVector_12; }
	inline void set_backVector_12(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___backVector_12 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_13() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___positiveInfinityVector_13)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_positiveInfinityVector_13() const { return ___positiveInfinityVector_13; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_positiveInfinityVector_13() { return &___positiveInfinityVector_13; }
	inline void set_positiveInfinityVector_13(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___positiveInfinityVector_13 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_14() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___negativeInfinityVector_14)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_negativeInfinityVector_14() const { return ___negativeInfinityVector_14; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_negativeInfinityVector_14() { return &___negativeInfinityVector_14; }
	inline void set_negativeInfinityVector_14(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___negativeInfinityVector_14 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR3_TDCF05E21F632FE2BA260C06E0D10CA81513E6720_H
#ifndef VECTOR4_TD148D6428C3F8FF6CD998F82090113C2B490B76E_H
#define VECTOR4_TD148D6428C3F8FF6CD998F82090113C2B490B76E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector4
struct  Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E 
{
public:
	// System.Single UnityEngine.Vector4::x
	float ___x_1;
	// System.Single UnityEngine.Vector4::y
	float ___y_2;
	// System.Single UnityEngine.Vector4::z
	float ___z_3;
	// System.Single UnityEngine.Vector4::w
	float ___w_4;

public:
	inline static int32_t get_offset_of_x_1() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E, ___x_1)); }
	inline float get_x_1() const { return ___x_1; }
	inline float* get_address_of_x_1() { return &___x_1; }
	inline void set_x_1(float value)
	{
		___x_1 = value;
	}

	inline static int32_t get_offset_of_y_2() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E, ___y_2)); }
	inline float get_y_2() const { return ___y_2; }
	inline float* get_address_of_y_2() { return &___y_2; }
	inline void set_y_2(float value)
	{
		___y_2 = value;
	}

	inline static int32_t get_offset_of_z_3() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E, ___z_3)); }
	inline float get_z_3() const { return ___z_3; }
	inline float* get_address_of_z_3() { return &___z_3; }
	inline void set_z_3(float value)
	{
		___z_3 = value;
	}

	inline static int32_t get_offset_of_w_4() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E, ___w_4)); }
	inline float get_w_4() const { return ___w_4; }
	inline float* get_address_of_w_4() { return &___w_4; }
	inline void set_w_4(float value)
	{
		___w_4 = value;
	}
};

struct Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields
{
public:
	// UnityEngine.Vector4 UnityEngine.Vector4::zeroVector
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___zeroVector_5;
	// UnityEngine.Vector4 UnityEngine.Vector4::oneVector
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___oneVector_6;
	// UnityEngine.Vector4 UnityEngine.Vector4::positiveInfinityVector
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___positiveInfinityVector_7;
	// UnityEngine.Vector4 UnityEngine.Vector4::negativeInfinityVector
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___negativeInfinityVector_8;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields, ___zeroVector_5)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields, ___oneVector_6)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_7() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields, ___positiveInfinityVector_7)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_positiveInfinityVector_7() const { return ___positiveInfinityVector_7; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_positiveInfinityVector_7() { return &___positiveInfinityVector_7; }
	inline void set_positiveInfinityVector_7(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___positiveInfinityVector_7 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E_StaticFields, ___negativeInfinityVector_8)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_negativeInfinityVector_8() const { return ___negativeInfinityVector_8; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_negativeInfinityVector_8() { return &___negativeInfinityVector_8; }
	inline void set_negativeInfinityVector_8(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___negativeInfinityVector_8 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR4_TD148D6428C3F8FF6CD998F82090113C2B490B76E_H
#ifndef WHATTOSHOW_TDB67EDA2591419EEE6AB54DC0713AD548BD8CD39_H
#define WHATTOSHOW_TDB67EDA2591419EEE6AB54DC0713AD548BD8CD39_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Demos.DemoQuiltToggle_WhatToShow
struct  WhatToShow_tDB67EDA2591419EEE6AB54DC0713AD548BD8CD39 
{
public:
	// System.Int32 LookingGlass.Demos.DemoQuiltToggle_WhatToShow::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(WhatToShow_tDB67EDA2591419EEE6AB54DC0713AD548BD8CD39, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // WHATTOSHOW_TDB67EDA2591419EEE6AB54DC0713AD548BD8CD39_H
#ifndef PROWORKSTATIONDISPLAY_T97FAAFFA6708F832EB706D8CD1C32B67C4FD6303_H
#define PROWORKSTATIONDISPLAY_T97FAAFFA6708F832EB706D8CD1C32B67C4FD6303_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.ProWorkstation.ProWorkstationDisplay
struct  ProWorkstationDisplay_t97FAAFFA6708F832EB706D8CD1C32B67C4FD6303 
{
public:
	// System.Int32 LookingGlass.ProWorkstation.ProWorkstationDisplay::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ProWorkstationDisplay_t97FAAFFA6708F832EB706D8CD1C32B67C4FD6303, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PROWORKSTATIONDISPLAY_T97FAAFFA6708F832EB706D8CD1C32B67C4FD6303_H
#ifndef PRESET_T27691E17FCF96CC5B8FEA0D1EE87E5ECAD724C86_H
#define PRESET_T27691E17FCF96CC5B8FEA0D1EE87E5ECAD724C86_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Quilt_Preset
struct  Preset_t27691E17FCF96CC5B8FEA0D1EE87E5ECAD724C86 
{
public:
	// System.Int32 LookingGlass.Quilt_Preset::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Preset_t27691E17FCF96CC5B8FEA0D1EE87E5ECAD724C86, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PRESET_T27691E17FCF96CC5B8FEA0D1EE87E5ECAD724C86_H
#ifndef OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#define OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Object
struct  Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};
#endif // OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#ifndef AMBIENTOCCLUSIONMODE_TBAA58AC8FBA3590D5188DCFD19449343CCDF6CA7_H
#define AMBIENTOCCLUSIONMODE_TBAA58AC8FBA3590D5188DCFD19449343CCDF6CA7_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.AmbientOcclusionMode
struct  AmbientOcclusionMode_tBAA58AC8FBA3590D5188DCFD19449343CCDF6CA7 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.AmbientOcclusionMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(AmbientOcclusionMode_tBAA58AC8FBA3590D5188DCFD19449343CCDF6CA7, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AMBIENTOCCLUSIONMODE_TBAA58AC8FBA3590D5188DCFD19449343CCDF6CA7_H
#ifndef AMBIENTOCCLUSIONQUALITY_TB54DB359F384B4A00DFD26DCA99C2BD9CABB9B6B_H
#define AMBIENTOCCLUSIONQUALITY_TB54DB359F384B4A00DFD26DCA99C2BD9CABB9B6B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.AmbientOcclusionQuality
struct  AmbientOcclusionQuality_tB54DB359F384B4A00DFD26DCA99C2BD9CABB9B6B 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.AmbientOcclusionQuality::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(AmbientOcclusionQuality_tB54DB359F384B4A00DFD26DCA99C2BD9CABB9B6B, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AMBIENTOCCLUSIONQUALITY_TB54DB359F384B4A00DFD26DCA99C2BD9CABB9B6B_H
#ifndef AMBIENTOCCLUSIONRENDERER_T530B3D3BA9E89BD4E2D39A987F6BF2D06FF5E948_H
#define AMBIENTOCCLUSIONRENDERER_T530B3D3BA9E89BD4E2D39A987F6BF2D06FF5E948_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.AmbientOcclusionRenderer
struct  AmbientOcclusionRenderer_t530B3D3BA9E89BD4E2D39A987F6BF2D06FF5E948  : public PostProcessEffectRenderer_1_t09CF00282A9D4637AAA38486DD42A253E3FD58B0
{
public:
	// UnityEngine.Rendering.PostProcessing.IAmbientOcclusionMethod[] UnityEngine.Rendering.PostProcessing.AmbientOcclusionRenderer::m_Methods
	IAmbientOcclusionMethodU5BU5D_t62D9F0D9D4AE2C94A9C8CE9AA1A6A2219354B4FC* ___m_Methods_2;

public:
	inline static int32_t get_offset_of_m_Methods_2() { return static_cast<int32_t>(offsetof(AmbientOcclusionRenderer_t530B3D3BA9E89BD4E2D39A987F6BF2D06FF5E948, ___m_Methods_2)); }
	inline IAmbientOcclusionMethodU5BU5D_t62D9F0D9D4AE2C94A9C8CE9AA1A6A2219354B4FC* get_m_Methods_2() const { return ___m_Methods_2; }
	inline IAmbientOcclusionMethodU5BU5D_t62D9F0D9D4AE2C94A9C8CE9AA1A6A2219354B4FC** get_address_of_m_Methods_2() { return &___m_Methods_2; }
	inline void set_m_Methods_2(IAmbientOcclusionMethodU5BU5D_t62D9F0D9D4AE2C94A9C8CE9AA1A6A2219354B4FC* value)
	{
		___m_Methods_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_Methods_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AMBIENTOCCLUSIONRENDERER_T530B3D3BA9E89BD4E2D39A987F6BF2D06FF5E948_H
#ifndef AUTOEXPOSURERENDERER_T76625B37271B0D13CEA54C8E4C35540F4F7CBC6B_H
#define AUTOEXPOSURERENDERER_T76625B37271B0D13CEA54C8E4C35540F4F7CBC6B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.AutoExposureRenderer
struct  AutoExposureRenderer_t76625B37271B0D13CEA54C8E4C35540F4F7CBC6B  : public PostProcessEffectRenderer_1_t35B3530F1E84E26D80D74E8C4B1EDBC177FC8E17
{
public:
	// UnityEngine.RenderTexture[][] UnityEngine.Rendering.PostProcessing.AutoExposureRenderer::m_AutoExposurePool
	RenderTextureU5BU5DU5BU5D_t0481781C86014C56DE3E8711ADD0C18B122453EF* ___m_AutoExposurePool_4;
	// System.Int32[] UnityEngine.Rendering.PostProcessing.AutoExposureRenderer::m_AutoExposurePingPong
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___m_AutoExposurePingPong_5;
	// UnityEngine.RenderTexture UnityEngine.Rendering.PostProcessing.AutoExposureRenderer::m_CurrentAutoExposure
	RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * ___m_CurrentAutoExposure_6;

public:
	inline static int32_t get_offset_of_m_AutoExposurePool_4() { return static_cast<int32_t>(offsetof(AutoExposureRenderer_t76625B37271B0D13CEA54C8E4C35540F4F7CBC6B, ___m_AutoExposurePool_4)); }
	inline RenderTextureU5BU5DU5BU5D_t0481781C86014C56DE3E8711ADD0C18B122453EF* get_m_AutoExposurePool_4() const { return ___m_AutoExposurePool_4; }
	inline RenderTextureU5BU5DU5BU5D_t0481781C86014C56DE3E8711ADD0C18B122453EF** get_address_of_m_AutoExposurePool_4() { return &___m_AutoExposurePool_4; }
	inline void set_m_AutoExposurePool_4(RenderTextureU5BU5DU5BU5D_t0481781C86014C56DE3E8711ADD0C18B122453EF* value)
	{
		___m_AutoExposurePool_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_AutoExposurePool_4), value);
	}

	inline static int32_t get_offset_of_m_AutoExposurePingPong_5() { return static_cast<int32_t>(offsetof(AutoExposureRenderer_t76625B37271B0D13CEA54C8E4C35540F4F7CBC6B, ___m_AutoExposurePingPong_5)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_m_AutoExposurePingPong_5() const { return ___m_AutoExposurePingPong_5; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_m_AutoExposurePingPong_5() { return &___m_AutoExposurePingPong_5; }
	inline void set_m_AutoExposurePingPong_5(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___m_AutoExposurePingPong_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_AutoExposurePingPong_5), value);
	}

	inline static int32_t get_offset_of_m_CurrentAutoExposure_6() { return static_cast<int32_t>(offsetof(AutoExposureRenderer_t76625B37271B0D13CEA54C8E4C35540F4F7CBC6B, ___m_CurrentAutoExposure_6)); }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * get_m_CurrentAutoExposure_6() const { return ___m_CurrentAutoExposure_6; }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 ** get_address_of_m_CurrentAutoExposure_6() { return &___m_CurrentAutoExposure_6; }
	inline void set_m_CurrentAutoExposure_6(RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * value)
	{
		___m_CurrentAutoExposure_6 = value;
		Il2CppCodeGenWriteBarrier((&___m_CurrentAutoExposure_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AUTOEXPOSURERENDERER_T76625B37271B0D13CEA54C8E4C35540F4F7CBC6B_H
#ifndef BLOOMRENDERER_TBC3F0FE4E43AD0A3E8552E923D239A8514A31FE9_H
#define BLOOMRENDERER_TBC3F0FE4E43AD0A3E8552E923D239A8514A31FE9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.BloomRenderer
struct  BloomRenderer_tBC3F0FE4E43AD0A3E8552E923D239A8514A31FE9  : public PostProcessEffectRenderer_1_t19E973E0507669F859DC42EF3AFC4221DACE6D92
{
public:
	// UnityEngine.Rendering.PostProcessing.BloomRenderer_Level[] UnityEngine.Rendering.PostProcessing.BloomRenderer::m_Pyramid
	LevelU5BU5D_tF50E5FC88D87D5276D3EBDA1A4F343212942ECC5* ___m_Pyramid_2;

public:
	inline static int32_t get_offset_of_m_Pyramid_2() { return static_cast<int32_t>(offsetof(BloomRenderer_tBC3F0FE4E43AD0A3E8552E923D239A8514A31FE9, ___m_Pyramid_2)); }
	inline LevelU5BU5D_tF50E5FC88D87D5276D3EBDA1A4F343212942ECC5* get_m_Pyramid_2() const { return ___m_Pyramid_2; }
	inline LevelU5BU5D_tF50E5FC88D87D5276D3EBDA1A4F343212942ECC5** get_address_of_m_Pyramid_2() { return &___m_Pyramid_2; }
	inline void set_m_Pyramid_2(LevelU5BU5D_tF50E5FC88D87D5276D3EBDA1A4F343212942ECC5* value)
	{
		___m_Pyramid_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_Pyramid_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BLOOMRENDERER_TBC3F0FE4E43AD0A3E8552E923D239A8514A31FE9_H
#ifndef PASS_TE2091DA72BF7C28286D2262969C7370D682E9C83_H
#define PASS_TE2091DA72BF7C28286D2262969C7370D682E9C83_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.BloomRenderer_Pass
struct  Pass_tE2091DA72BF7C28286D2262969C7370D682E9C83 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.BloomRenderer_Pass::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Pass_tE2091DA72BF7C28286D2262969C7370D682E9C83, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PASS_TE2091DA72BF7C28286D2262969C7370D682E9C83_H
#ifndef BOOLPARAMETER_TE4336B5D1812A2D76EE6C9769F0EA15A36993A32_H
#define BOOLPARAMETER_TE4336B5D1812A2D76EE6C9769F0EA15A36993A32_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.BoolParameter
struct  BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32  : public ParameterOverride_1_t3E0F0485F30346446015285000468E9C14046417
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BOOLPARAMETER_TE4336B5D1812A2D76EE6C9769F0EA15A36993A32_H
#ifndef CHROMATICABERRATIONRENDERER_TD640E75AAD5381FDB96653920F4270F3D1FB13A4_H
#define CHROMATICABERRATIONRENDERER_TD640E75AAD5381FDB96653920F4270F3D1FB13A4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ChromaticAberrationRenderer
struct  ChromaticAberrationRenderer_tD640E75AAD5381FDB96653920F4270F3D1FB13A4  : public PostProcessEffectRenderer_1_tDCFD602822B9B17523E0C0ABA1F0D38D393C8F48
{
public:
	// UnityEngine.Texture2D UnityEngine.Rendering.PostProcessing.ChromaticAberrationRenderer::m_InternalSpectralLut
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___m_InternalSpectralLut_2;

public:
	inline static int32_t get_offset_of_m_InternalSpectralLut_2() { return static_cast<int32_t>(offsetof(ChromaticAberrationRenderer_tD640E75AAD5381FDB96653920F4270F3D1FB13A4, ___m_InternalSpectralLut_2)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_m_InternalSpectralLut_2() const { return ___m_InternalSpectralLut_2; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_m_InternalSpectralLut_2() { return &___m_InternalSpectralLut_2; }
	inline void set_m_InternalSpectralLut_2(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___m_InternalSpectralLut_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_InternalSpectralLut_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CHROMATICABERRATIONRENDERER_TD640E75AAD5381FDB96653920F4270F3D1FB13A4_H
#ifndef COLORGRADINGRENDERER_T5FCD2E275CDA37CB4EF2596896191C5E52DF0D0D_H
#define COLORGRADINGRENDERER_T5FCD2E275CDA37CB4EF2596896191C5E52DF0D0D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ColorGradingRenderer
struct  ColorGradingRenderer_t5FCD2E275CDA37CB4EF2596896191C5E52DF0D0D  : public PostProcessEffectRenderer_1_t6E66553820ABDE1818E2CD83971E7FB4BDC89557
{
public:
	// UnityEngine.Texture2D UnityEngine.Rendering.PostProcessing.ColorGradingRenderer::m_GradingCurves
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___m_GradingCurves_2;
	// UnityEngine.Color[] UnityEngine.Rendering.PostProcessing.ColorGradingRenderer::m_Pixels
	ColorU5BU5D_t166D390E0E6F24360F990D1F81881A72B73CA399* ___m_Pixels_3;
	// UnityEngine.RenderTexture UnityEngine.Rendering.PostProcessing.ColorGradingRenderer::m_InternalLdrLut
	RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * ___m_InternalLdrLut_4;
	// UnityEngine.RenderTexture UnityEngine.Rendering.PostProcessing.ColorGradingRenderer::m_InternalLogLut
	RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * ___m_InternalLogLut_5;
	// UnityEngine.Rendering.PostProcessing.HableCurve UnityEngine.Rendering.PostProcessing.ColorGradingRenderer::m_HableCurve
	HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78 * ___m_HableCurve_8;

public:
	inline static int32_t get_offset_of_m_GradingCurves_2() { return static_cast<int32_t>(offsetof(ColorGradingRenderer_t5FCD2E275CDA37CB4EF2596896191C5E52DF0D0D, ___m_GradingCurves_2)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_m_GradingCurves_2() const { return ___m_GradingCurves_2; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_m_GradingCurves_2() { return &___m_GradingCurves_2; }
	inline void set_m_GradingCurves_2(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___m_GradingCurves_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_GradingCurves_2), value);
	}

	inline static int32_t get_offset_of_m_Pixels_3() { return static_cast<int32_t>(offsetof(ColorGradingRenderer_t5FCD2E275CDA37CB4EF2596896191C5E52DF0D0D, ___m_Pixels_3)); }
	inline ColorU5BU5D_t166D390E0E6F24360F990D1F81881A72B73CA399* get_m_Pixels_3() const { return ___m_Pixels_3; }
	inline ColorU5BU5D_t166D390E0E6F24360F990D1F81881A72B73CA399** get_address_of_m_Pixels_3() { return &___m_Pixels_3; }
	inline void set_m_Pixels_3(ColorU5BU5D_t166D390E0E6F24360F990D1F81881A72B73CA399* value)
	{
		___m_Pixels_3 = value;
		Il2CppCodeGenWriteBarrier((&___m_Pixels_3), value);
	}

	inline static int32_t get_offset_of_m_InternalLdrLut_4() { return static_cast<int32_t>(offsetof(ColorGradingRenderer_t5FCD2E275CDA37CB4EF2596896191C5E52DF0D0D, ___m_InternalLdrLut_4)); }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * get_m_InternalLdrLut_4() const { return ___m_InternalLdrLut_4; }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 ** get_address_of_m_InternalLdrLut_4() { return &___m_InternalLdrLut_4; }
	inline void set_m_InternalLdrLut_4(RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * value)
	{
		___m_InternalLdrLut_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_InternalLdrLut_4), value);
	}

	inline static int32_t get_offset_of_m_InternalLogLut_5() { return static_cast<int32_t>(offsetof(ColorGradingRenderer_t5FCD2E275CDA37CB4EF2596896191C5E52DF0D0D, ___m_InternalLogLut_5)); }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * get_m_InternalLogLut_5() const { return ___m_InternalLogLut_5; }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 ** get_address_of_m_InternalLogLut_5() { return &___m_InternalLogLut_5; }
	inline void set_m_InternalLogLut_5(RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * value)
	{
		___m_InternalLogLut_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_InternalLogLut_5), value);
	}

	inline static int32_t get_offset_of_m_HableCurve_8() { return static_cast<int32_t>(offsetof(ColorGradingRenderer_t5FCD2E275CDA37CB4EF2596896191C5E52DF0D0D, ___m_HableCurve_8)); }
	inline HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78 * get_m_HableCurve_8() const { return ___m_HableCurve_8; }
	inline HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78 ** get_address_of_m_HableCurve_8() { return &___m_HableCurve_8; }
	inline void set_m_HableCurve_8(HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78 * value)
	{
		___m_HableCurve_8 = value;
		Il2CppCodeGenWriteBarrier((&___m_HableCurve_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLORGRADINGRENDERER_T5FCD2E275CDA37CB4EF2596896191C5E52DF0D0D_H
#ifndef PASS_T7529527D523DA94869CE9CF13B00549DBAB898E5_H
#define PASS_T7529527D523DA94869CE9CF13B00549DBAB898E5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ColorGradingRenderer_Pass
struct  Pass_t7529527D523DA94869CE9CF13B00549DBAB898E5 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.ColorGradingRenderer_Pass::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Pass_t7529527D523DA94869CE9CF13B00549DBAB898E5, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PASS_T7529527D523DA94869CE9CF13B00549DBAB898E5_H
#ifndef DEPTHOFFIELDRENDERER_TB1D8D006ED9B295629DFEC92124C404AE2CD31EE_H
#define DEPTHOFFIELDRENDERER_TB1D8D006ED9B295629DFEC92124C404AE2CD31EE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.DepthOfFieldRenderer
struct  DepthOfFieldRenderer_tB1D8D006ED9B295629DFEC92124C404AE2CD31EE  : public PostProcessEffectRenderer_1_t6D8C7A5B96C7829A3421121015486BA79F700710
{
public:
	// UnityEngine.RenderTexture[][] UnityEngine.Rendering.PostProcessing.DepthOfFieldRenderer::m_CoCHistoryTextures
	RenderTextureU5BU5DU5BU5D_t0481781C86014C56DE3E8711ADD0C18B122453EF* ___m_CoCHistoryTextures_4;
	// System.Int32[] UnityEngine.Rendering.PostProcessing.DepthOfFieldRenderer::m_HistoryPingPong
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___m_HistoryPingPong_5;

public:
	inline static int32_t get_offset_of_m_CoCHistoryTextures_4() { return static_cast<int32_t>(offsetof(DepthOfFieldRenderer_tB1D8D006ED9B295629DFEC92124C404AE2CD31EE, ___m_CoCHistoryTextures_4)); }
	inline RenderTextureU5BU5DU5BU5D_t0481781C86014C56DE3E8711ADD0C18B122453EF* get_m_CoCHistoryTextures_4() const { return ___m_CoCHistoryTextures_4; }
	inline RenderTextureU5BU5DU5BU5D_t0481781C86014C56DE3E8711ADD0C18B122453EF** get_address_of_m_CoCHistoryTextures_4() { return &___m_CoCHistoryTextures_4; }
	inline void set_m_CoCHistoryTextures_4(RenderTextureU5BU5DU5BU5D_t0481781C86014C56DE3E8711ADD0C18B122453EF* value)
	{
		___m_CoCHistoryTextures_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_CoCHistoryTextures_4), value);
	}

	inline static int32_t get_offset_of_m_HistoryPingPong_5() { return static_cast<int32_t>(offsetof(DepthOfFieldRenderer_tB1D8D006ED9B295629DFEC92124C404AE2CD31EE, ___m_HistoryPingPong_5)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_m_HistoryPingPong_5() const { return ___m_HistoryPingPong_5; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_m_HistoryPingPong_5() { return &___m_HistoryPingPong_5; }
	inline void set_m_HistoryPingPong_5(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___m_HistoryPingPong_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_HistoryPingPong_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEPTHOFFIELDRENDERER_TB1D8D006ED9B295629DFEC92124C404AE2CD31EE_H
#ifndef PASS_T58D979E9324109771CB3BD763C13E631ABA84032_H
#define PASS_T58D979E9324109771CB3BD763C13E631ABA84032_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.DepthOfFieldRenderer_Pass
struct  Pass_t58D979E9324109771CB3BD763C13E631ABA84032 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.DepthOfFieldRenderer_Pass::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Pass_t58D979E9324109771CB3BD763C13E631ABA84032, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PASS_T58D979E9324109771CB3BD763C13E631ABA84032_H
#ifndef EYEADAPTATION_T933C17351A512F83920EFA56D30DB2B3CD474793_H
#define EYEADAPTATION_T933C17351A512F83920EFA56D30DB2B3CD474793_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.EyeAdaptation
struct  EyeAdaptation_t933C17351A512F83920EFA56D30DB2B3CD474793 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.EyeAdaptation::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(EyeAdaptation_t933C17351A512F83920EFA56D30DB2B3CD474793, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EYEADAPTATION_T933C17351A512F83920EFA56D30DB2B3CD474793_H
#ifndef FLOATPARAMETER_T9009F81EB449255B9AE9F90F007F91F343437703_H
#define FLOATPARAMETER_T9009F81EB449255B9AE9F90F007F91F343437703_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.FloatParameter
struct  FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703  : public ParameterOverride_1_tD862C720E602CF48A201439C668E2546C254FD2F
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FLOATPARAMETER_T9009F81EB449255B9AE9F90F007F91F343437703_H
#ifndef GRADINGMODE_T26234A50CAEB0E6E2A69683474CA2052461265C9_H
#define GRADINGMODE_T26234A50CAEB0E6E2A69683474CA2052461265C9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.GradingMode
struct  GradingMode_t26234A50CAEB0E6E2A69683474CA2052461265C9 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.GradingMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(GradingMode_t26234A50CAEB0E6E2A69683474CA2052461265C9, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GRADINGMODE_T26234A50CAEB0E6E2A69683474CA2052461265C9_H
#ifndef GRAINRENDERER_TD2C170FF4FAEAEBAF2835B13F8E16F3A22547EF6_H
#define GRAINRENDERER_TD2C170FF4FAEAEBAF2835B13F8E16F3A22547EF6_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.GrainRenderer
struct  GrainRenderer_tD2C170FF4FAEAEBAF2835B13F8E16F3A22547EF6  : public PostProcessEffectRenderer_1_tB4EBCA325BC5D9270289A81F7D5D72CFCF8A6DE7
{
public:
	// UnityEngine.RenderTexture UnityEngine.Rendering.PostProcessing.GrainRenderer::m_GrainLookupRT
	RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * ___m_GrainLookupRT_2;
	// System.Int32 UnityEngine.Rendering.PostProcessing.GrainRenderer::m_SampleIndex
	int32_t ___m_SampleIndex_4;

public:
	inline static int32_t get_offset_of_m_GrainLookupRT_2() { return static_cast<int32_t>(offsetof(GrainRenderer_tD2C170FF4FAEAEBAF2835B13F8E16F3A22547EF6, ___m_GrainLookupRT_2)); }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * get_m_GrainLookupRT_2() const { return ___m_GrainLookupRT_2; }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 ** get_address_of_m_GrainLookupRT_2() { return &___m_GrainLookupRT_2; }
	inline void set_m_GrainLookupRT_2(RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * value)
	{
		___m_GrainLookupRT_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_GrainLookupRT_2), value);
	}

	inline static int32_t get_offset_of_m_SampleIndex_4() { return static_cast<int32_t>(offsetof(GrainRenderer_tD2C170FF4FAEAEBAF2835B13F8E16F3A22547EF6, ___m_SampleIndex_4)); }
	inline int32_t get_m_SampleIndex_4() const { return ___m_SampleIndex_4; }
	inline int32_t* get_address_of_m_SampleIndex_4() { return &___m_SampleIndex_4; }
	inline void set_m_SampleIndex_4(int32_t value)
	{
		___m_SampleIndex_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GRAINRENDERER_TD2C170FF4FAEAEBAF2835B13F8E16F3A22547EF6_H
#ifndef CHANNEL_T83BA5F9DFDAD22C6DF638E04B10B63CBDDBE4A39_H
#define CHANNEL_T83BA5F9DFDAD22C6DF638E04B10B63CBDDBE4A39_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.HistogramMonitor_Channel
struct  Channel_t83BA5F9DFDAD22C6DF638E04B10B63CBDDBE4A39 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.HistogramMonitor_Channel::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Channel_t83BA5F9DFDAD22C6DF638E04B10B63CBDDBE4A39, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CHANNEL_T83BA5F9DFDAD22C6DF638E04B10B63CBDDBE4A39_H
#ifndef INTPARAMETER_TF314047E8059BF20F34E4202ACA31C6EAF8D7390_H
#define INTPARAMETER_TF314047E8059BF20F34E4202ACA31C6EAF8D7390_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.IntParameter
struct  IntParameter_tF314047E8059BF20F34E4202ACA31C6EAF8D7390  : public ParameterOverride_1_tFEC3B3FD3EB1D850E64F32B33AD557305BFE5B09
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPARAMETER_TF314047E8059BF20F34E4202ACA31C6EAF8D7390_H
#ifndef KERNELSIZE_T4924DA4E775CBA62B19F6E8482147AA9716A2E2C_H
#define KERNELSIZE_T4924DA4E775CBA62B19F6E8482147AA9716A2E2C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.KernelSize
struct  KernelSize_t4924DA4E775CBA62B19F6E8482147AA9716A2E2C 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.KernelSize::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(KernelSize_t4924DA4E775CBA62B19F6E8482147AA9716A2E2C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // KERNELSIZE_T4924DA4E775CBA62B19F6E8482147AA9716A2E2C_H
#ifndef LENSDISTORTIONRENDERER_T8B185A86C3562080F78F8C39179894AC0B8D633D_H
#define LENSDISTORTIONRENDERER_T8B185A86C3562080F78F8C39179894AC0B8D633D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.LensDistortionRenderer
struct  LensDistortionRenderer_t8B185A86C3562080F78F8C39179894AC0B8D633D  : public PostProcessEffectRenderer_1_t69338CD36F660BDD8B6C51C26764368285591CC4
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LENSDISTORTIONRENDERER_T8B185A86C3562080F78F8C39179894AC0B8D633D_H
#ifndef MONITORTYPE_TD794EA77396E262DC8289139BA16B0FBC3768330_H
#define MONITORTYPE_TD794EA77396E262DC8289139BA16B0FBC3768330_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.MonitorType
struct  MonitorType_tD794EA77396E262DC8289139BA16B0FBC3768330 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.MonitorType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(MonitorType_tD794EA77396E262DC8289139BA16B0FBC3768330, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONITORTYPE_TD794EA77396E262DC8289139BA16B0FBC3768330_H
#ifndef MOTIONBLURRENDERER_T52EBEFE0D8A92188ADC2AEA259E96017D06334C3_H
#define MOTIONBLURRENDERER_T52EBEFE0D8A92188ADC2AEA259E96017D06334C3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.MotionBlurRenderer
struct  MotionBlurRenderer_t52EBEFE0D8A92188ADC2AEA259E96017D06334C3  : public PostProcessEffectRenderer_1_tC225F3992B0BA1F684E9857B077B551DAC285931
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MOTIONBLURRENDERER_T52EBEFE0D8A92188ADC2AEA259E96017D06334C3_H
#ifndef PASS_TDA1E60CC2E7998A18F47C250C046B72ECC1ECCFA_H
#define PASS_TDA1E60CC2E7998A18F47C250C046B72ECC1ECCFA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.MotionBlurRenderer_Pass
struct  Pass_tDA1E60CC2E7998A18F47C250C046B72ECC1ECCFA 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.MotionBlurRenderer_Pass::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Pass_tDA1E60CC2E7998A18F47C250C046B72ECC1ECCFA, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PASS_TDA1E60CC2E7998A18F47C250C046B72ECC1ECCFA_H
#ifndef MIPLEVEL_T734F1C34D089FFDC34DCB9DD7C7AE04BD9BBFDCF_H
#define MIPLEVEL_T734F1C34D089FFDC34DCB9DD7C7AE04BD9BBFDCF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.MultiScaleVO_MipLevel
struct  MipLevel_t734F1C34D089FFDC34DCB9DD7C7AE04BD9BBFDCF 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.MultiScaleVO_MipLevel::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(MipLevel_t734F1C34D089FFDC34DCB9DD7C7AE04BD9BBFDCF, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MIPLEVEL_T734F1C34D089FFDC34DCB9DD7C7AE04BD9BBFDCF_H
#ifndef PASS_T38D6CABA9D11CA7A8E6AD93707DCC32D86530638_H
#define PASS_T38D6CABA9D11CA7A8E6AD93707DCC32D86530638_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.MultiScaleVO_Pass
struct  Pass_t38D6CABA9D11CA7A8E6AD93707DCC32D86530638 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.MultiScaleVO_Pass::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Pass_t38D6CABA9D11CA7A8E6AD93707DCC32D86530638, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PASS_T38D6CABA9D11CA7A8E6AD93707DCC32D86530638_H
#ifndef PARAMETEROVERRIDE_1_TCC4F5A5FE23AAB5A2DCDE972FF24EEB2829DC9EB_H
#define PARAMETEROVERRIDE_1_TCC4F5A5FE23AAB5A2DCDE972FF24EEB2829DC9EB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<UnityEngine.Color>
struct  ParameterOverride_1_tCC4F5A5FE23AAB5A2DCDE972FF24EEB2829DC9EB  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_tCC4F5A5FE23AAB5A2DCDE972FF24EEB2829DC9EB, ___value_1)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_value_1() const { return ___value_1; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_TCC4F5A5FE23AAB5A2DCDE972FF24EEB2829DC9EB_H
#ifndef PARAMETEROVERRIDE_1_T1B99A7CE476310DAEDE4309B1A58A4D7383CCC18_H
#define PARAMETEROVERRIDE_1_T1B99A7CE476310DAEDE4309B1A58A4D7383CCC18_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<UnityEngine.Vector2>
struct  ParameterOverride_1_t1B99A7CE476310DAEDE4309B1A58A4D7383CCC18  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_t1B99A7CE476310DAEDE4309B1A58A4D7383CCC18, ___value_1)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_value_1() const { return ___value_1; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_T1B99A7CE476310DAEDE4309B1A58A4D7383CCC18_H
#ifndef PARAMETEROVERRIDE_1_T1B598EA9B6500D5D4413D42600754E91F7B4D617_H
#define PARAMETEROVERRIDE_1_T1B598EA9B6500D5D4413D42600754E91F7B4D617_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<UnityEngine.Vector3>
struct  ParameterOverride_1_t1B598EA9B6500D5D4413D42600754E91F7B4D617  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_t1B598EA9B6500D5D4413D42600754E91F7B4D617, ___value_1)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_value_1() const { return ___value_1; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_T1B598EA9B6500D5D4413D42600754E91F7B4D617_H
#ifndef PARAMETEROVERRIDE_1_T76BE25A0DD99283353CA7E8C9B2BCE2C721CD9E9_H
#define PARAMETEROVERRIDE_1_T76BE25A0DD99283353CA7E8C9B2BCE2C721CD9E9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<UnityEngine.Vector4>
struct  ParameterOverride_1_t76BE25A0DD99283353CA7E8C9B2BCE2C721CD9E9  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_t76BE25A0DD99283353CA7E8C9B2BCE2C721CD9E9, ___value_1)); }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  get_value_1() const { return ___value_1; }
	inline Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E * get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(Vector4_tD148D6428C3F8FF6CD998F82090113C2B490B76E  value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_T76BE25A0DD99283353CA7E8C9B2BCE2C721CD9E9_H
#ifndef POSTPROCESSEVENT_TB213B5070E972AC9A0D6983CF2686144655765D0_H
#define POSTPROCESSEVENT_TB213B5070E972AC9A0D6983CF2686144655765D0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEvent
struct  PostProcessEvent_tB213B5070E972AC9A0D6983CF2686144655765D0 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.PostProcessEvent::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(PostProcessEvent_tB213B5070E972AC9A0D6983CF2686144655765D0, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEVENT_TB213B5070E972AC9A0D6983CF2686144655765D0_H
#ifndef PASS_TE70B7AA76B7B31510FE879A49B695B5E845737F3_H
#define PASS_TE70B7AA76B7B31510FE879A49B695B5E845737F3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ScalableAO_Pass
struct  Pass_tE70B7AA76B7B31510FE879A49B695B5E845737F3 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.ScalableAO_Pass::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Pass_tE70B7AA76B7B31510FE879A49B695B5E845737F3, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PASS_TE70B7AA76B7B31510FE879A49B695B5E845737F3_H
#ifndef SCREENSPACEREFLECTIONPRESET_T08B6AB6E6AA127256D37FEC1C16A890A17661F6C_H
#define SCREENSPACEREFLECTIONPRESET_T08B6AB6E6AA127256D37FEC1C16A890A17661F6C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionPreset
struct  ScreenSpaceReflectionPreset_t08B6AB6E6AA127256D37FEC1C16A890A17661F6C 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionPreset::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ScreenSpaceReflectionPreset_t08B6AB6E6AA127256D37FEC1C16A890A17661F6C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SCREENSPACEREFLECTIONPRESET_T08B6AB6E6AA127256D37FEC1C16A890A17661F6C_H
#ifndef SCREENSPACEREFLECTIONRESOLUTION_TE69E1FAD4252F2175F2B4C59C8C82F6EDA429164_H
#define SCREENSPACEREFLECTIONRESOLUTION_TE69E1FAD4252F2175F2B4C59C8C82F6EDA429164_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionResolution
struct  ScreenSpaceReflectionResolution_tE69E1FAD4252F2175F2B4C59C8C82F6EDA429164 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionResolution::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ScreenSpaceReflectionResolution_tE69E1FAD4252F2175F2B4C59C8C82F6EDA429164, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SCREENSPACEREFLECTIONRESOLUTION_TE69E1FAD4252F2175F2B4C59C8C82F6EDA429164_H
#ifndef SCREENSPACEREFLECTIONSRENDERER_TC2E6E485E1A1967D6C8641AF66376BD42CA6E79F_H
#define SCREENSPACEREFLECTIONSRENDERER_TC2E6E485E1A1967D6C8641AF66376BD42CA6E79F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionsRenderer
struct  ScreenSpaceReflectionsRenderer_tC2E6E485E1A1967D6C8641AF66376BD42CA6E79F  : public PostProcessEffectRenderer_1_tF39455A9F066D9A86491A45D54B5840CBCC8E2C0
{
public:
	// UnityEngine.RenderTexture UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionsRenderer::m_Resolve
	RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * ___m_Resolve_2;
	// UnityEngine.RenderTexture UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionsRenderer::m_History
	RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * ___m_History_3;
	// System.Int32[] UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionsRenderer::m_MipIDs
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___m_MipIDs_4;
	// UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionsRenderer_QualityPreset[] UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionsRenderer::m_Presets
	QualityPresetU5BU5D_t60D3DE0232719D820134FB36A6ADAFA77352678C* ___m_Presets_5;

public:
	inline static int32_t get_offset_of_m_Resolve_2() { return static_cast<int32_t>(offsetof(ScreenSpaceReflectionsRenderer_tC2E6E485E1A1967D6C8641AF66376BD42CA6E79F, ___m_Resolve_2)); }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * get_m_Resolve_2() const { return ___m_Resolve_2; }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 ** get_address_of_m_Resolve_2() { return &___m_Resolve_2; }
	inline void set_m_Resolve_2(RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * value)
	{
		___m_Resolve_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_Resolve_2), value);
	}

	inline static int32_t get_offset_of_m_History_3() { return static_cast<int32_t>(offsetof(ScreenSpaceReflectionsRenderer_tC2E6E485E1A1967D6C8641AF66376BD42CA6E79F, ___m_History_3)); }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * get_m_History_3() const { return ___m_History_3; }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 ** get_address_of_m_History_3() { return &___m_History_3; }
	inline void set_m_History_3(RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * value)
	{
		___m_History_3 = value;
		Il2CppCodeGenWriteBarrier((&___m_History_3), value);
	}

	inline static int32_t get_offset_of_m_MipIDs_4() { return static_cast<int32_t>(offsetof(ScreenSpaceReflectionsRenderer_tC2E6E485E1A1967D6C8641AF66376BD42CA6E79F, ___m_MipIDs_4)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_m_MipIDs_4() const { return ___m_MipIDs_4; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_m_MipIDs_4() { return &___m_MipIDs_4; }
	inline void set_m_MipIDs_4(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___m_MipIDs_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_MipIDs_4), value);
	}

	inline static int32_t get_offset_of_m_Presets_5() { return static_cast<int32_t>(offsetof(ScreenSpaceReflectionsRenderer_tC2E6E485E1A1967D6C8641AF66376BD42CA6E79F, ___m_Presets_5)); }
	inline QualityPresetU5BU5D_t60D3DE0232719D820134FB36A6ADAFA77352678C* get_m_Presets_5() const { return ___m_Presets_5; }
	inline QualityPresetU5BU5D_t60D3DE0232719D820134FB36A6ADAFA77352678C** get_address_of_m_Presets_5() { return &___m_Presets_5; }
	inline void set_m_Presets_5(QualityPresetU5BU5D_t60D3DE0232719D820134FB36A6ADAFA77352678C* value)
	{
		___m_Presets_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_Presets_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SCREENSPACEREFLECTIONSRENDERER_TC2E6E485E1A1967D6C8641AF66376BD42CA6E79F_H
#ifndef PASS_T5719EC3281C9B370C5054228F003B08CEA69CCA6_H
#define PASS_T5719EC3281C9B370C5054228F003B08CEA69CCA6_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionsRenderer_Pass
struct  Pass_t5719EC3281C9B370C5054228F003B08CEA69CCA6 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionsRenderer_Pass::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Pass_t5719EC3281C9B370C5054228F003B08CEA69CCA6, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PASS_T5719EC3281C9B370C5054228F003B08CEA69CCA6_H
#ifndef SPLINEPARAMETER_T70C9BA684726F930046ADF7D5509E44F0E8F860F_H
#define SPLINEPARAMETER_T70C9BA684726F930046ADF7D5509E44F0E8F860F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.SplineParameter
struct  SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F  : public ParameterOverride_1_tA7F786BD18721EEA18B5816C17B6F488FEE1ABC4
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SPLINEPARAMETER_T70C9BA684726F930046ADF7D5509E44F0E8F860F_H
#ifndef PASS_TE189D8DA92AFBBD1C9D9A495E15885B842FB80AA_H
#define PASS_TE189D8DA92AFBBD1C9D9A495E15885B842FB80AA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.SubpixelMorphologicalAntialiasing_Pass
struct  Pass_tE189D8DA92AFBBD1C9D9A495E15885B842FB80AA 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.SubpixelMorphologicalAntialiasing_Pass::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Pass_tE189D8DA92AFBBD1C9D9A495E15885B842FB80AA, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PASS_TE189D8DA92AFBBD1C9D9A495E15885B842FB80AA_H
#ifndef QUALITY_T47754692CA99716F6403286C22B367747A7F3C4D_H
#define QUALITY_T47754692CA99716F6403286C22B367747A7F3C4D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.SubpixelMorphologicalAntialiasing_Quality
struct  Quality_t47754692CA99716F6403286C22B367747A7F3C4D 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.SubpixelMorphologicalAntialiasing_Quality::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Quality_t47754692CA99716F6403286C22B367747A7F3C4D, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // QUALITY_T47754692CA99716F6403286C22B367747A7F3C4D_H
#ifndef TEMPORALANTIALIASING_TD4267BD257770578FA6003198771D631995A322B_H
#define TEMPORALANTIALIASING_TD4267BD257770578FA6003198771D631995A322B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.TemporalAntialiasing
struct  TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B  : public RuntimeObject
{
public:
	// System.Single UnityEngine.Rendering.PostProcessing.TemporalAntialiasing::jitterSpread
	float ___jitterSpread_0;
	// System.Single UnityEngine.Rendering.PostProcessing.TemporalAntialiasing::sharpness
	float ___sharpness_1;
	// System.Single UnityEngine.Rendering.PostProcessing.TemporalAntialiasing::stationaryBlending
	float ___stationaryBlending_2;
	// System.Single UnityEngine.Rendering.PostProcessing.TemporalAntialiasing::motionBlending
	float ___motionBlending_3;
	// System.Func`3<UnityEngine.Camera,UnityEngine.Vector2,UnityEngine.Matrix4x4> UnityEngine.Rendering.PostProcessing.TemporalAntialiasing::jitteredMatrixFunc
	Func_3_t76929AE26BC1464E59748B309462754D15C34712 * ___jitteredMatrixFunc_4;
	// UnityEngine.Vector2 UnityEngine.Rendering.PostProcessing.TemporalAntialiasing::<jitter>k__BackingField
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___U3CjitterU3Ek__BackingField_5;
	// UnityEngine.Rendering.RenderTargetIdentifier[] UnityEngine.Rendering.PostProcessing.TemporalAntialiasing::m_Mrt
	RenderTargetIdentifierU5BU5D_t57069CA3F97B36638E39044168D1BEB956436DD4* ___m_Mrt_6;
	// System.Boolean UnityEngine.Rendering.PostProcessing.TemporalAntialiasing::m_ResetHistory
	bool ___m_ResetHistory_7;
	// System.Int32 UnityEngine.Rendering.PostProcessing.TemporalAntialiasing::<sampleIndex>k__BackingField
	int32_t ___U3CsampleIndexU3Ek__BackingField_9;
	// UnityEngine.RenderTexture[][] UnityEngine.Rendering.PostProcessing.TemporalAntialiasing::m_HistoryTextures
	RenderTextureU5BU5DU5BU5D_t0481781C86014C56DE3E8711ADD0C18B122453EF* ___m_HistoryTextures_12;
	// System.Int32[] UnityEngine.Rendering.PostProcessing.TemporalAntialiasing::m_HistoryPingPong
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___m_HistoryPingPong_13;

public:
	inline static int32_t get_offset_of_jitterSpread_0() { return static_cast<int32_t>(offsetof(TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B, ___jitterSpread_0)); }
	inline float get_jitterSpread_0() const { return ___jitterSpread_0; }
	inline float* get_address_of_jitterSpread_0() { return &___jitterSpread_0; }
	inline void set_jitterSpread_0(float value)
	{
		___jitterSpread_0 = value;
	}

	inline static int32_t get_offset_of_sharpness_1() { return static_cast<int32_t>(offsetof(TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B, ___sharpness_1)); }
	inline float get_sharpness_1() const { return ___sharpness_1; }
	inline float* get_address_of_sharpness_1() { return &___sharpness_1; }
	inline void set_sharpness_1(float value)
	{
		___sharpness_1 = value;
	}

	inline static int32_t get_offset_of_stationaryBlending_2() { return static_cast<int32_t>(offsetof(TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B, ___stationaryBlending_2)); }
	inline float get_stationaryBlending_2() const { return ___stationaryBlending_2; }
	inline float* get_address_of_stationaryBlending_2() { return &___stationaryBlending_2; }
	inline void set_stationaryBlending_2(float value)
	{
		___stationaryBlending_2 = value;
	}

	inline static int32_t get_offset_of_motionBlending_3() { return static_cast<int32_t>(offsetof(TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B, ___motionBlending_3)); }
	inline float get_motionBlending_3() const { return ___motionBlending_3; }
	inline float* get_address_of_motionBlending_3() { return &___motionBlending_3; }
	inline void set_motionBlending_3(float value)
	{
		___motionBlending_3 = value;
	}

	inline static int32_t get_offset_of_jitteredMatrixFunc_4() { return static_cast<int32_t>(offsetof(TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B, ___jitteredMatrixFunc_4)); }
	inline Func_3_t76929AE26BC1464E59748B309462754D15C34712 * get_jitteredMatrixFunc_4() const { return ___jitteredMatrixFunc_4; }
	inline Func_3_t76929AE26BC1464E59748B309462754D15C34712 ** get_address_of_jitteredMatrixFunc_4() { return &___jitteredMatrixFunc_4; }
	inline void set_jitteredMatrixFunc_4(Func_3_t76929AE26BC1464E59748B309462754D15C34712 * value)
	{
		___jitteredMatrixFunc_4 = value;
		Il2CppCodeGenWriteBarrier((&___jitteredMatrixFunc_4), value);
	}

	inline static int32_t get_offset_of_U3CjitterU3Ek__BackingField_5() { return static_cast<int32_t>(offsetof(TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B, ___U3CjitterU3Ek__BackingField_5)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_U3CjitterU3Ek__BackingField_5() const { return ___U3CjitterU3Ek__BackingField_5; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_U3CjitterU3Ek__BackingField_5() { return &___U3CjitterU3Ek__BackingField_5; }
	inline void set_U3CjitterU3Ek__BackingField_5(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___U3CjitterU3Ek__BackingField_5 = value;
	}

	inline static int32_t get_offset_of_m_Mrt_6() { return static_cast<int32_t>(offsetof(TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B, ___m_Mrt_6)); }
	inline RenderTargetIdentifierU5BU5D_t57069CA3F97B36638E39044168D1BEB956436DD4* get_m_Mrt_6() const { return ___m_Mrt_6; }
	inline RenderTargetIdentifierU5BU5D_t57069CA3F97B36638E39044168D1BEB956436DD4** get_address_of_m_Mrt_6() { return &___m_Mrt_6; }
	inline void set_m_Mrt_6(RenderTargetIdentifierU5BU5D_t57069CA3F97B36638E39044168D1BEB956436DD4* value)
	{
		___m_Mrt_6 = value;
		Il2CppCodeGenWriteBarrier((&___m_Mrt_6), value);
	}

	inline static int32_t get_offset_of_m_ResetHistory_7() { return static_cast<int32_t>(offsetof(TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B, ___m_ResetHistory_7)); }
	inline bool get_m_ResetHistory_7() const { return ___m_ResetHistory_7; }
	inline bool* get_address_of_m_ResetHistory_7() { return &___m_ResetHistory_7; }
	inline void set_m_ResetHistory_7(bool value)
	{
		___m_ResetHistory_7 = value;
	}

	inline static int32_t get_offset_of_U3CsampleIndexU3Ek__BackingField_9() { return static_cast<int32_t>(offsetof(TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B, ___U3CsampleIndexU3Ek__BackingField_9)); }
	inline int32_t get_U3CsampleIndexU3Ek__BackingField_9() const { return ___U3CsampleIndexU3Ek__BackingField_9; }
	inline int32_t* get_address_of_U3CsampleIndexU3Ek__BackingField_9() { return &___U3CsampleIndexU3Ek__BackingField_9; }
	inline void set_U3CsampleIndexU3Ek__BackingField_9(int32_t value)
	{
		___U3CsampleIndexU3Ek__BackingField_9 = value;
	}

	inline static int32_t get_offset_of_m_HistoryTextures_12() { return static_cast<int32_t>(offsetof(TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B, ___m_HistoryTextures_12)); }
	inline RenderTextureU5BU5DU5BU5D_t0481781C86014C56DE3E8711ADD0C18B122453EF* get_m_HistoryTextures_12() const { return ___m_HistoryTextures_12; }
	inline RenderTextureU5BU5DU5BU5D_t0481781C86014C56DE3E8711ADD0C18B122453EF** get_address_of_m_HistoryTextures_12() { return &___m_HistoryTextures_12; }
	inline void set_m_HistoryTextures_12(RenderTextureU5BU5DU5BU5D_t0481781C86014C56DE3E8711ADD0C18B122453EF* value)
	{
		___m_HistoryTextures_12 = value;
		Il2CppCodeGenWriteBarrier((&___m_HistoryTextures_12), value);
	}

	inline static int32_t get_offset_of_m_HistoryPingPong_13() { return static_cast<int32_t>(offsetof(TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B, ___m_HistoryPingPong_13)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_m_HistoryPingPong_13() const { return ___m_HistoryPingPong_13; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_m_HistoryPingPong_13() { return &___m_HistoryPingPong_13; }
	inline void set_m_HistoryPingPong_13(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___m_HistoryPingPong_13 = value;
		Il2CppCodeGenWriteBarrier((&___m_HistoryPingPong_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TEMPORALANTIALIASING_TD4267BD257770578FA6003198771D631995A322B_H
#ifndef PASS_T283EA1DF1922B3E29857B5F4D7A7EC89A432EB4F_H
#define PASS_T283EA1DF1922B3E29857B5F4D7A7EC89A432EB4F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.TemporalAntialiasing_Pass
struct  Pass_t283EA1DF1922B3E29857B5F4D7A7EC89A432EB4F 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.TemporalAntialiasing_Pass::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Pass_t283EA1DF1922B3E29857B5F4D7A7EC89A432EB4F, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PASS_T283EA1DF1922B3E29857B5F4D7A7EC89A432EB4F_H
#ifndef TONEMAPPER_TADC047088F116B3047D90BB3CFCB022E09F2EFC8_H
#define TONEMAPPER_TADC047088F116B3047D90BB3CFCB022E09F2EFC8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.Tonemapper
struct  Tonemapper_tADC047088F116B3047D90BB3CFCB022E09F2EFC8 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.Tonemapper::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Tonemapper_tADC047088F116B3047D90BB3CFCB022E09F2EFC8, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TONEMAPPER_TADC047088F116B3047D90BB3CFCB022E09F2EFC8_H
#ifndef MODE_T9A2CFAD08E18EF76BAA8714445F27F45F8F601ED_H
#define MODE_T9A2CFAD08E18EF76BAA8714445F27F45F8F601ED_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.TrackballAttribute_Mode
struct  Mode_t9A2CFAD08E18EF76BAA8714445F27F45F8F601ED 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.TrackballAttribute_Mode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Mode_t9A2CFAD08E18EF76BAA8714445F27F45F8F601ED, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MODE_T9A2CFAD08E18EF76BAA8714445F27F45F8F601ED_H
#ifndef VIGNETTEMODE_TC4E66BF0248EBE1B64A87D2ECE33BC5081CE5809_H
#define VIGNETTEMODE_TC4E66BF0248EBE1B64A87D2ECE33BC5081CE5809_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.VignetteMode
struct  VignetteMode_tC4E66BF0248EBE1B64A87D2ECE33BC5081CE5809 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.VignetteMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(VignetteMode_tC4E66BF0248EBE1B64A87D2ECE33BC5081CE5809, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIGNETTEMODE_TC4E66BF0248EBE1B64A87D2ECE33BC5081CE5809_H
#ifndef VIGNETTERENDERER_T601587477A5F76F63577992A1C9317ADB07697DE_H
#define VIGNETTERENDERER_T601587477A5F76F63577992A1C9317ADB07697DE_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.VignetteRenderer
struct  VignetteRenderer_t601587477A5F76F63577992A1C9317ADB07697DE  : public PostProcessEffectRenderer_1_tE69D334B38BB977ABE5C9F0DB0EF2F1DFD1478F3
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIGNETTERENDERER_T601587477A5F76F63577992A1C9317ADB07697DE_H
#ifndef COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#define COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Component
struct  Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#ifndef COLORPARAMETER_TC6DED9B62CC1066E49029ECB8152FBE78DC05D85_H
#define COLORPARAMETER_TC6DED9B62CC1066E49029ECB8152FBE78DC05D85_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ColorParameter
struct  ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85  : public ParameterOverride_1_tCC4F5A5FE23AAB5A2DCDE972FF24EEB2829DC9EB
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLORPARAMETER_TC6DED9B62CC1066E49029ECB8152FBE78DC05D85_H
#ifndef HISTOGRAMMONITOR_T682E9ACE9C9874B0230608D0A1C1382307907D87_H
#define HISTOGRAMMONITOR_T682E9ACE9C9874B0230608D0A1C1382307907D87_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.HistogramMonitor
struct  HistogramMonitor_t682E9ACE9C9874B0230608D0A1C1382307907D87  : public Monitor_tE317BECFE50FD51B2BBC2609C33E6ABE76A6338E
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.HistogramMonitor::width
	int32_t ___width_2;
	// System.Int32 UnityEngine.Rendering.PostProcessing.HistogramMonitor::height
	int32_t ___height_3;
	// UnityEngine.Rendering.PostProcessing.HistogramMonitor_Channel UnityEngine.Rendering.PostProcessing.HistogramMonitor::channel
	int32_t ___channel_4;
	// UnityEngine.ComputeBuffer UnityEngine.Rendering.PostProcessing.HistogramMonitor::m_Data
	ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5 * ___m_Data_5;

public:
	inline static int32_t get_offset_of_width_2() { return static_cast<int32_t>(offsetof(HistogramMonitor_t682E9ACE9C9874B0230608D0A1C1382307907D87, ___width_2)); }
	inline int32_t get_width_2() const { return ___width_2; }
	inline int32_t* get_address_of_width_2() { return &___width_2; }
	inline void set_width_2(int32_t value)
	{
		___width_2 = value;
	}

	inline static int32_t get_offset_of_height_3() { return static_cast<int32_t>(offsetof(HistogramMonitor_t682E9ACE9C9874B0230608D0A1C1382307907D87, ___height_3)); }
	inline int32_t get_height_3() const { return ___height_3; }
	inline int32_t* get_address_of_height_3() { return &___height_3; }
	inline void set_height_3(int32_t value)
	{
		___height_3 = value;
	}

	inline static int32_t get_offset_of_channel_4() { return static_cast<int32_t>(offsetof(HistogramMonitor_t682E9ACE9C9874B0230608D0A1C1382307907D87, ___channel_4)); }
	inline int32_t get_channel_4() const { return ___channel_4; }
	inline int32_t* get_address_of_channel_4() { return &___channel_4; }
	inline void set_channel_4(int32_t value)
	{
		___channel_4 = value;
	}

	inline static int32_t get_offset_of_m_Data_5() { return static_cast<int32_t>(offsetof(HistogramMonitor_t682E9ACE9C9874B0230608D0A1C1382307907D87, ___m_Data_5)); }
	inline ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5 * get_m_Data_5() const { return ___m_Data_5; }
	inline ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5 ** get_address_of_m_Data_5() { return &___m_Data_5; }
	inline void set_m_Data_5(ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5 * value)
	{
		___m_Data_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_Data_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HISTOGRAMMONITOR_T682E9ACE9C9874B0230608D0A1C1382307907D87_H
#ifndef PARAMETEROVERRIDE_1_TED057FB98E61C8519A9A750F00AD8F15B70E1723_H
#define PARAMETEROVERRIDE_1_TED057FB98E61C8519A9A750F00AD8F15B70E1723_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<UnityEngine.Rendering.PostProcessing.AmbientOcclusionMode>
struct  ParameterOverride_1_tED057FB98E61C8519A9A750F00AD8F15B70E1723  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	int32_t ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_tED057FB98E61C8519A9A750F00AD8F15B70E1723, ___value_1)); }
	inline int32_t get_value_1() const { return ___value_1; }
	inline int32_t* get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(int32_t value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_TED057FB98E61C8519A9A750F00AD8F15B70E1723_H
#ifndef PARAMETEROVERRIDE_1_TCF2CBF6232AE1A23B62CF62C76409337AD8A800A_H
#define PARAMETEROVERRIDE_1_TCF2CBF6232AE1A23B62CF62C76409337AD8A800A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<UnityEngine.Rendering.PostProcessing.AmbientOcclusionQuality>
struct  ParameterOverride_1_tCF2CBF6232AE1A23B62CF62C76409337AD8A800A  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	int32_t ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_tCF2CBF6232AE1A23B62CF62C76409337AD8A800A, ___value_1)); }
	inline int32_t get_value_1() const { return ___value_1; }
	inline int32_t* get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(int32_t value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_TCF2CBF6232AE1A23B62CF62C76409337AD8A800A_H
#ifndef PARAMETEROVERRIDE_1_T4BCB1B75E98E0CB0F0814A32BDB8ADF6F02AC5F4_H
#define PARAMETEROVERRIDE_1_T4BCB1B75E98E0CB0F0814A32BDB8ADF6F02AC5F4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<UnityEngine.Rendering.PostProcessing.EyeAdaptation>
struct  ParameterOverride_1_t4BCB1B75E98E0CB0F0814A32BDB8ADF6F02AC5F4  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	int32_t ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_t4BCB1B75E98E0CB0F0814A32BDB8ADF6F02AC5F4, ___value_1)); }
	inline int32_t get_value_1() const { return ___value_1; }
	inline int32_t* get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(int32_t value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_T4BCB1B75E98E0CB0F0814A32BDB8ADF6F02AC5F4_H
#ifndef PARAMETEROVERRIDE_1_T66D865F4AAE77DAE14C12DDB00EDFE02B3CE70DD_H
#define PARAMETEROVERRIDE_1_T66D865F4AAE77DAE14C12DDB00EDFE02B3CE70DD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<UnityEngine.Rendering.PostProcessing.GradingMode>
struct  ParameterOverride_1_t66D865F4AAE77DAE14C12DDB00EDFE02B3CE70DD  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	int32_t ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_t66D865F4AAE77DAE14C12DDB00EDFE02B3CE70DD, ___value_1)); }
	inline int32_t get_value_1() const { return ___value_1; }
	inline int32_t* get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(int32_t value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_T66D865F4AAE77DAE14C12DDB00EDFE02B3CE70DD_H
#ifndef PARAMETEROVERRIDE_1_T5F6B370395E7C55D643666B010C0DEE4E261BBCF_H
#define PARAMETEROVERRIDE_1_T5F6B370395E7C55D643666B010C0DEE4E261BBCF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<UnityEngine.Rendering.PostProcessing.KernelSize>
struct  ParameterOverride_1_t5F6B370395E7C55D643666B010C0DEE4E261BBCF  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	int32_t ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_t5F6B370395E7C55D643666B010C0DEE4E261BBCF, ___value_1)); }
	inline int32_t get_value_1() const { return ___value_1; }
	inline int32_t* get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(int32_t value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_T5F6B370395E7C55D643666B010C0DEE4E261BBCF_H
#ifndef PARAMETEROVERRIDE_1_TFD1DAF041F5A09C38209D0A97F56F1022D1D9932_H
#define PARAMETEROVERRIDE_1_TFD1DAF041F5A09C38209D0A97F56F1022D1D9932_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionPreset>
struct  ParameterOverride_1_tFD1DAF041F5A09C38209D0A97F56F1022D1D9932  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	int32_t ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_tFD1DAF041F5A09C38209D0A97F56F1022D1D9932, ___value_1)); }
	inline int32_t get_value_1() const { return ___value_1; }
	inline int32_t* get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(int32_t value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_TFD1DAF041F5A09C38209D0A97F56F1022D1D9932_H
#ifndef PARAMETEROVERRIDE_1_TE418605CA828846D2305A280E722546913E5E69E_H
#define PARAMETEROVERRIDE_1_TE418605CA828846D2305A280E722546913E5E69E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionResolution>
struct  ParameterOverride_1_tE418605CA828846D2305A280E722546913E5E69E  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	int32_t ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_tE418605CA828846D2305A280E722546913E5E69E, ___value_1)); }
	inline int32_t get_value_1() const { return ___value_1; }
	inline int32_t* get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(int32_t value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_TE418605CA828846D2305A280E722546913E5E69E_H
#ifndef PARAMETEROVERRIDE_1_T905B62F3EA7EFB634F571C82F5194443F5E8136E_H
#define PARAMETEROVERRIDE_1_T905B62F3EA7EFB634F571C82F5194443F5E8136E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<UnityEngine.Rendering.PostProcessing.Tonemapper>
struct  ParameterOverride_1_t905B62F3EA7EFB634F571C82F5194443F5E8136E  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	int32_t ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_t905B62F3EA7EFB634F571C82F5194443F5E8136E, ___value_1)); }
	inline int32_t get_value_1() const { return ___value_1; }
	inline int32_t* get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(int32_t value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_T905B62F3EA7EFB634F571C82F5194443F5E8136E_H
#ifndef PARAMETEROVERRIDE_1_TA4004F5877059FDCF0352DAB8D9B022E211CE6C5_H
#define PARAMETEROVERRIDE_1_TA4004F5877059FDCF0352DAB8D9B022E211CE6C5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<UnityEngine.Rendering.PostProcessing.VignetteMode>
struct  ParameterOverride_1_tA4004F5877059FDCF0352DAB8D9B022E211CE6C5  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	int32_t ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_tA4004F5877059FDCF0352DAB8D9B022E211CE6C5, ___value_1)); }
	inline int32_t get_value_1() const { return ___value_1; }
	inline int32_t* get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(int32_t value)
	{
		___value_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_TA4004F5877059FDCF0352DAB8D9B022E211CE6C5_H
#ifndef POSTPROCESSATTRIBUTE_T795817D592C782B0F5E50962B2525AE1A4D92F54_H
#define POSTPROCESSATTRIBUTE_T795817D592C782B0F5E50962B2525AE1A4D92F54_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessAttribute
struct  PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54  : public Attribute_tF048C13FB3C8CFCC53F82290E4A3F621089F9A74
{
public:
	// System.Type UnityEngine.Rendering.PostProcessing.PostProcessAttribute::renderer
	Type_t * ___renderer_0;
	// UnityEngine.Rendering.PostProcessing.PostProcessEvent UnityEngine.Rendering.PostProcessing.PostProcessAttribute::eventType
	int32_t ___eventType_1;
	// System.String UnityEngine.Rendering.PostProcessing.PostProcessAttribute::menuItem
	String_t* ___menuItem_2;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessAttribute::allowInSceneView
	bool ___allowInSceneView_3;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessAttribute::builtinEffect
	bool ___builtinEffect_4;

public:
	inline static int32_t get_offset_of_renderer_0() { return static_cast<int32_t>(offsetof(PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54, ___renderer_0)); }
	inline Type_t * get_renderer_0() const { return ___renderer_0; }
	inline Type_t ** get_address_of_renderer_0() { return &___renderer_0; }
	inline void set_renderer_0(Type_t * value)
	{
		___renderer_0 = value;
		Il2CppCodeGenWriteBarrier((&___renderer_0), value);
	}

	inline static int32_t get_offset_of_eventType_1() { return static_cast<int32_t>(offsetof(PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54, ___eventType_1)); }
	inline int32_t get_eventType_1() const { return ___eventType_1; }
	inline int32_t* get_address_of_eventType_1() { return &___eventType_1; }
	inline void set_eventType_1(int32_t value)
	{
		___eventType_1 = value;
	}

	inline static int32_t get_offset_of_menuItem_2() { return static_cast<int32_t>(offsetof(PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54, ___menuItem_2)); }
	inline String_t* get_menuItem_2() const { return ___menuItem_2; }
	inline String_t** get_address_of_menuItem_2() { return &___menuItem_2; }
	inline void set_menuItem_2(String_t* value)
	{
		___menuItem_2 = value;
		Il2CppCodeGenWriteBarrier((&___menuItem_2), value);
	}

	inline static int32_t get_offset_of_allowInSceneView_3() { return static_cast<int32_t>(offsetof(PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54, ___allowInSceneView_3)); }
	inline bool get_allowInSceneView_3() const { return ___allowInSceneView_3; }
	inline bool* get_address_of_allowInSceneView_3() { return &___allowInSceneView_3; }
	inline void set_allowInSceneView_3(bool value)
	{
		___allowInSceneView_3 = value;
	}

	inline static int32_t get_offset_of_builtinEffect_4() { return static_cast<int32_t>(offsetof(PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54, ___builtinEffect_4)); }
	inline bool get_builtinEffect_4() const { return ___builtinEffect_4; }
	inline bool* get_address_of_builtinEffect_4() { return &___builtinEffect_4; }
	inline void set_builtinEffect_4(bool value)
	{
		___builtinEffect_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSATTRIBUTE_T795817D592C782B0F5E50962B2525AE1A4D92F54_H
#ifndef QUALITYPRESET_TD633200BBFFD7F29AC915A1D5FA1D361BC15AA17_H
#define QUALITYPRESET_TD633200BBFFD7F29AC915A1D5FA1D361BC15AA17_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionsRenderer_QualityPreset
struct  QualityPreset_tD633200BBFFD7F29AC915A1D5FA1D361BC15AA17  : public RuntimeObject
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionsRenderer_QualityPreset::maximumIterationCount
	int32_t ___maximumIterationCount_0;
	// System.Single UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionsRenderer_QualityPreset::thickness
	float ___thickness_1;
	// UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionResolution UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionsRenderer_QualityPreset::downsampling
	int32_t ___downsampling_2;

public:
	inline static int32_t get_offset_of_maximumIterationCount_0() { return static_cast<int32_t>(offsetof(QualityPreset_tD633200BBFFD7F29AC915A1D5FA1D361BC15AA17, ___maximumIterationCount_0)); }
	inline int32_t get_maximumIterationCount_0() const { return ___maximumIterationCount_0; }
	inline int32_t* get_address_of_maximumIterationCount_0() { return &___maximumIterationCount_0; }
	inline void set_maximumIterationCount_0(int32_t value)
	{
		___maximumIterationCount_0 = value;
	}

	inline static int32_t get_offset_of_thickness_1() { return static_cast<int32_t>(offsetof(QualityPreset_tD633200BBFFD7F29AC915A1D5FA1D361BC15AA17, ___thickness_1)); }
	inline float get_thickness_1() const { return ___thickness_1; }
	inline float* get_address_of_thickness_1() { return &___thickness_1; }
	inline void set_thickness_1(float value)
	{
		___thickness_1 = value;
	}

	inline static int32_t get_offset_of_downsampling_2() { return static_cast<int32_t>(offsetof(QualityPreset_tD633200BBFFD7F29AC915A1D5FA1D361BC15AA17, ___downsampling_2)); }
	inline int32_t get_downsampling_2() const { return ___downsampling_2; }
	inline int32_t* get_address_of_downsampling_2() { return &___downsampling_2; }
	inline void set_downsampling_2(int32_t value)
	{
		___downsampling_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // QUALITYPRESET_TD633200BBFFD7F29AC915A1D5FA1D361BC15AA17_H
#ifndef SUBPIXELMORPHOLOGICALANTIALIASING_T79DFA0E989BC5D03E07D5A9E5DFC9E7170B0CB3A_H
#define SUBPIXELMORPHOLOGICALANTIALIASING_T79DFA0E989BC5D03E07D5A9E5DFC9E7170B0CB3A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.SubpixelMorphologicalAntialiasing
struct  SubpixelMorphologicalAntialiasing_t79DFA0E989BC5D03E07D5A9E5DFC9E7170B0CB3A  : public RuntimeObject
{
public:
	// UnityEngine.Rendering.PostProcessing.SubpixelMorphologicalAntialiasing_Quality UnityEngine.Rendering.PostProcessing.SubpixelMorphologicalAntialiasing::quality
	int32_t ___quality_0;

public:
	inline static int32_t get_offset_of_quality_0() { return static_cast<int32_t>(offsetof(SubpixelMorphologicalAntialiasing_t79DFA0E989BC5D03E07D5A9E5DFC9E7170B0CB3A, ___quality_0)); }
	inline int32_t get_quality_0() const { return ___quality_0; }
	inline int32_t* get_address_of_quality_0() { return &___quality_0; }
	inline void set_quality_0(int32_t value)
	{
		___quality_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SUBPIXELMORPHOLOGICALANTIALIASING_T79DFA0E989BC5D03E07D5A9E5DFC9E7170B0CB3A_H
#ifndef TRACKBALLATTRIBUTE_T8D831ADAC589D7DAA910878C85236E7C53A9FE33_H
#define TRACKBALLATTRIBUTE_T8D831ADAC589D7DAA910878C85236E7C53A9FE33_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.TrackballAttribute
struct  TrackballAttribute_t8D831ADAC589D7DAA910878C85236E7C53A9FE33  : public Attribute_tF048C13FB3C8CFCC53F82290E4A3F621089F9A74
{
public:
	// UnityEngine.Rendering.PostProcessing.TrackballAttribute_Mode UnityEngine.Rendering.PostProcessing.TrackballAttribute::mode
	int32_t ___mode_0;

public:
	inline static int32_t get_offset_of_mode_0() { return static_cast<int32_t>(offsetof(TrackballAttribute_t8D831ADAC589D7DAA910878C85236E7C53A9FE33, ___mode_0)); }
	inline int32_t get_mode_0() const { return ___mode_0; }
	inline int32_t* get_address_of_mode_0() { return &___mode_0; }
	inline void set_mode_0(int32_t value)
	{
		___mode_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TRACKBALLATTRIBUTE_T8D831ADAC589D7DAA910878C85236E7C53A9FE33_H
#ifndef VECTOR2PARAMETER_T2138DCE95841B6A479E95D93280273119FCB0686_H
#define VECTOR2PARAMETER_T2138DCE95841B6A479E95D93280273119FCB0686_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.Vector2Parameter
struct  Vector2Parameter_t2138DCE95841B6A479E95D93280273119FCB0686  : public ParameterOverride_1_t1B99A7CE476310DAEDE4309B1A58A4D7383CCC18
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR2PARAMETER_T2138DCE95841B6A479E95D93280273119FCB0686_H
#ifndef VECTOR3PARAMETER_TA5890D7B9F137A9F6400D41814891154F7FA26D2_H
#define VECTOR3PARAMETER_TA5890D7B9F137A9F6400D41814891154F7FA26D2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.Vector3Parameter
struct  Vector3Parameter_tA5890D7B9F137A9F6400D41814891154F7FA26D2  : public ParameterOverride_1_t1B598EA9B6500D5D4413D42600754E91F7B4D617
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR3PARAMETER_TA5890D7B9F137A9F6400D41814891154F7FA26D2_H
#ifndef VECTOR4PARAMETER_T71A23EBB58A01E0FF756B1D104B8DE37F772E2F1_H
#define VECTOR4PARAMETER_T71A23EBB58A01E0FF756B1D104B8DE37F772E2F1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.Vector4Parameter
struct  Vector4Parameter_t71A23EBB58A01E0FF756B1D104B8DE37F772E2F1  : public ParameterOverride_1_t76BE25A0DD99283353CA7E8C9B2BCE2C721CD9E9
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR4PARAMETER_T71A23EBB58A01E0FF756B1D104B8DE37F772E2F1_H
#ifndef SCRIPTABLEOBJECT_TAB015486CEAB714DA0D5C1BA389B84FB90427734_H
#define SCRIPTABLEOBJECT_TAB015486CEAB714DA0D5C1BA389B84FB90427734_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.ScriptableObject
struct  ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734_marshaled_pinvoke : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
};
// Native definition for COM marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734_marshaled_com : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
};
#endif // SCRIPTABLEOBJECT_TAB015486CEAB714DA0D5C1BA389B84FB90427734_H
#ifndef BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#define BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Behaviour
struct  Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8  : public Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#ifndef AMBIENTOCCLUSIONMODEPARAMETER_T79A104721D47E98613437F7F1A355695C397DDEF_H
#define AMBIENTOCCLUSIONMODEPARAMETER_T79A104721D47E98613437F7F1A355695C397DDEF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.AmbientOcclusionModeParameter
struct  AmbientOcclusionModeParameter_t79A104721D47E98613437F7F1A355695C397DDEF  : public ParameterOverride_1_tED057FB98E61C8519A9A750F00AD8F15B70E1723
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AMBIENTOCCLUSIONMODEPARAMETER_T79A104721D47E98613437F7F1A355695C397DDEF_H
#ifndef AMBIENTOCCLUSIONQUALITYPARAMETER_TE18805DEFF6A5466E44B02E6D820336B9EA0E2FD_H
#define AMBIENTOCCLUSIONQUALITYPARAMETER_TE18805DEFF6A5466E44B02E6D820336B9EA0E2FD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.AmbientOcclusionQualityParameter
struct  AmbientOcclusionQualityParameter_tE18805DEFF6A5466E44B02E6D820336B9EA0E2FD  : public ParameterOverride_1_tCF2CBF6232AE1A23B62CF62C76409337AD8A800A
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AMBIENTOCCLUSIONQUALITYPARAMETER_TE18805DEFF6A5466E44B02E6D820336B9EA0E2FD_H
#ifndef EYEADAPTATIONPARAMETER_T7AC22D9A78944F2CA208B5E2FDB40BD76B1C0B70_H
#define EYEADAPTATIONPARAMETER_T7AC22D9A78944F2CA208B5E2FDB40BD76B1C0B70_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.EyeAdaptationParameter
struct  EyeAdaptationParameter_t7AC22D9A78944F2CA208B5E2FDB40BD76B1C0B70  : public ParameterOverride_1_t4BCB1B75E98E0CB0F0814A32BDB8ADF6F02AC5F4
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EYEADAPTATIONPARAMETER_T7AC22D9A78944F2CA208B5E2FDB40BD76B1C0B70_H
#ifndef GRADINGMODEPARAMETER_T30B66E571092CDA4D03618D02C0D71D84A7D9FA7_H
#define GRADINGMODEPARAMETER_T30B66E571092CDA4D03618D02C0D71D84A7D9FA7_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.GradingModeParameter
struct  GradingModeParameter_t30B66E571092CDA4D03618D02C0D71D84A7D9FA7  : public ParameterOverride_1_t66D865F4AAE77DAE14C12DDB00EDFE02B3CE70DD
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GRADINGMODEPARAMETER_T30B66E571092CDA4D03618D02C0D71D84A7D9FA7_H
#ifndef KERNELSIZEPARAMETER_T1290513B86C15182AD770816459A5398322F6642_H
#define KERNELSIZEPARAMETER_T1290513B86C15182AD770816459A5398322F6642_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.KernelSizeParameter
struct  KernelSizeParameter_t1290513B86C15182AD770816459A5398322F6642  : public ParameterOverride_1_t5F6B370395E7C55D643666B010C0DEE4E261BBCF
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // KERNELSIZEPARAMETER_T1290513B86C15182AD770816459A5398322F6642_H
#ifndef POSTPROCESSEFFECTSETTINGS_T52802C256968EC72036018D471331281EC46E56E_H
#define POSTPROCESSEFFECTSETTINGS_T52802C256968EC72036018D471331281EC46E56E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings
struct  PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E  : public ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734
{
public:
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings::active
	bool ___active_4;
	// UnityEngine.Rendering.PostProcessing.BoolParameter UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings::enabled
	BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * ___enabled_5;
	// System.Collections.ObjectModel.ReadOnlyCollection`1<UnityEngine.Rendering.PostProcessing.ParameterOverride> UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings::parameters
	ReadOnlyCollection_1_t09ED47FDFC3DF44855A0AECF526E54628E99D966 * ___parameters_6;

public:
	inline static int32_t get_offset_of_active_4() { return static_cast<int32_t>(offsetof(PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E, ___active_4)); }
	inline bool get_active_4() const { return ___active_4; }
	inline bool* get_address_of_active_4() { return &___active_4; }
	inline void set_active_4(bool value)
	{
		___active_4 = value;
	}

	inline static int32_t get_offset_of_enabled_5() { return static_cast<int32_t>(offsetof(PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E, ___enabled_5)); }
	inline BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * get_enabled_5() const { return ___enabled_5; }
	inline BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 ** get_address_of_enabled_5() { return &___enabled_5; }
	inline void set_enabled_5(BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * value)
	{
		___enabled_5 = value;
		Il2CppCodeGenWriteBarrier((&___enabled_5), value);
	}

	inline static int32_t get_offset_of_parameters_6() { return static_cast<int32_t>(offsetof(PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E, ___parameters_6)); }
	inline ReadOnlyCollection_1_t09ED47FDFC3DF44855A0AECF526E54628E99D966 * get_parameters_6() const { return ___parameters_6; }
	inline ReadOnlyCollection_1_t09ED47FDFC3DF44855A0AECF526E54628E99D966 ** get_address_of_parameters_6() { return &___parameters_6; }
	inline void set_parameters_6(ReadOnlyCollection_1_t09ED47FDFC3DF44855A0AECF526E54628E99D966 * value)
	{
		___parameters_6 = value;
		Il2CppCodeGenWriteBarrier((&___parameters_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEFFECTSETTINGS_T52802C256968EC72036018D471331281EC46E56E_H
#ifndef SCREENSPACEREFLECTIONPRESETPARAMETER_T268DBDBDBA87C22733B30A3E3587B328E7F834E4_H
#define SCREENSPACEREFLECTIONPRESETPARAMETER_T268DBDBDBA87C22733B30A3E3587B328E7F834E4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionPresetParameter
struct  ScreenSpaceReflectionPresetParameter_t268DBDBDBA87C22733B30A3E3587B328E7F834E4  : public ParameterOverride_1_tFD1DAF041F5A09C38209D0A97F56F1022D1D9932
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SCREENSPACEREFLECTIONPRESETPARAMETER_T268DBDBDBA87C22733B30A3E3587B328E7F834E4_H
#ifndef SCREENSPACEREFLECTIONRESOLUTIONPARAMETER_TC897149ADF64CB366527300D8A12FE2E5AE8B943_H
#define SCREENSPACEREFLECTIONRESOLUTIONPARAMETER_TC897149ADF64CB366527300D8A12FE2E5AE8B943_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionResolutionParameter
struct  ScreenSpaceReflectionResolutionParameter_tC897149ADF64CB366527300D8A12FE2E5AE8B943  : public ParameterOverride_1_tE418605CA828846D2305A280E722546913E5E69E
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SCREENSPACEREFLECTIONRESOLUTIONPARAMETER_TC897149ADF64CB366527300D8A12FE2E5AE8B943_H
#ifndef TONEMAPPERPARAMETER_TAE067595EA8479188AA91EC38AD4BBA34CF2DA3B_H
#define TONEMAPPERPARAMETER_TAE067595EA8479188AA91EC38AD4BBA34CF2DA3B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.TonemapperParameter
struct  TonemapperParameter_tAE067595EA8479188AA91EC38AD4BBA34CF2DA3B  : public ParameterOverride_1_t905B62F3EA7EFB634F571C82F5194443F5E8136E
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TONEMAPPERPARAMETER_TAE067595EA8479188AA91EC38AD4BBA34CF2DA3B_H
#ifndef VIGNETTEMODEPARAMETER_T0853E96B549BCF8765CE8FEB6B50EB78706645A6_H
#define VIGNETTEMODEPARAMETER_T0853E96B549BCF8765CE8FEB6B50EB78706645A6_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.VignetteModeParameter
struct  VignetteModeParameter_t0853E96B549BCF8765CE8FEB6B50EB78706645A6  : public ParameterOverride_1_tA4004F5877059FDCF0352DAB8D9B022E211CE6C5
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIGNETTEMODEPARAMETER_T0853E96B549BCF8765CE8FEB6B50EB78706645A6_H
#ifndef MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#define MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.MonoBehaviour
struct  MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429  : public Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#ifndef AMBIENTOCCLUSION_TFDCFB4EE09E8B263719F8CF50EC91915D78B1A88_H
#define AMBIENTOCCLUSION_TFDCFB4EE09E8B263719F8CF50EC91915D78B1A88_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.AmbientOcclusion
struct  AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88  : public PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E
{
public:
	// UnityEngine.Rendering.PostProcessing.AmbientOcclusionModeParameter UnityEngine.Rendering.PostProcessing.AmbientOcclusion::mode
	AmbientOcclusionModeParameter_t79A104721D47E98613437F7F1A355695C397DDEF * ___mode_7;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.AmbientOcclusion::intensity
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___intensity_8;
	// UnityEngine.Rendering.PostProcessing.ColorParameter UnityEngine.Rendering.PostProcessing.AmbientOcclusion::color
	ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85 * ___color_9;
	// UnityEngine.Rendering.PostProcessing.BoolParameter UnityEngine.Rendering.PostProcessing.AmbientOcclusion::ambientOnly
	BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * ___ambientOnly_10;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.AmbientOcclusion::noiseFilterTolerance
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___noiseFilterTolerance_11;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.AmbientOcclusion::blurTolerance
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___blurTolerance_12;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.AmbientOcclusion::upsampleTolerance
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___upsampleTolerance_13;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.AmbientOcclusion::thicknessModifier
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___thicknessModifier_14;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.AmbientOcclusion::directLightingStrength
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___directLightingStrength_15;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.AmbientOcclusion::radius
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___radius_16;
	// UnityEngine.Rendering.PostProcessing.AmbientOcclusionQualityParameter UnityEngine.Rendering.PostProcessing.AmbientOcclusion::quality
	AmbientOcclusionQualityParameter_tE18805DEFF6A5466E44B02E6D820336B9EA0E2FD * ___quality_17;

public:
	inline static int32_t get_offset_of_mode_7() { return static_cast<int32_t>(offsetof(AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88, ___mode_7)); }
	inline AmbientOcclusionModeParameter_t79A104721D47E98613437F7F1A355695C397DDEF * get_mode_7() const { return ___mode_7; }
	inline AmbientOcclusionModeParameter_t79A104721D47E98613437F7F1A355695C397DDEF ** get_address_of_mode_7() { return &___mode_7; }
	inline void set_mode_7(AmbientOcclusionModeParameter_t79A104721D47E98613437F7F1A355695C397DDEF * value)
	{
		___mode_7 = value;
		Il2CppCodeGenWriteBarrier((&___mode_7), value);
	}

	inline static int32_t get_offset_of_intensity_8() { return static_cast<int32_t>(offsetof(AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88, ___intensity_8)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_intensity_8() const { return ___intensity_8; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_intensity_8() { return &___intensity_8; }
	inline void set_intensity_8(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___intensity_8 = value;
		Il2CppCodeGenWriteBarrier((&___intensity_8), value);
	}

	inline static int32_t get_offset_of_color_9() { return static_cast<int32_t>(offsetof(AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88, ___color_9)); }
	inline ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85 * get_color_9() const { return ___color_9; }
	inline ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85 ** get_address_of_color_9() { return &___color_9; }
	inline void set_color_9(ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85 * value)
	{
		___color_9 = value;
		Il2CppCodeGenWriteBarrier((&___color_9), value);
	}

	inline static int32_t get_offset_of_ambientOnly_10() { return static_cast<int32_t>(offsetof(AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88, ___ambientOnly_10)); }
	inline BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * get_ambientOnly_10() const { return ___ambientOnly_10; }
	inline BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 ** get_address_of_ambientOnly_10() { return &___ambientOnly_10; }
	inline void set_ambientOnly_10(BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * value)
	{
		___ambientOnly_10 = value;
		Il2CppCodeGenWriteBarrier((&___ambientOnly_10), value);
	}

	inline static int32_t get_offset_of_noiseFilterTolerance_11() { return static_cast<int32_t>(offsetof(AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88, ___noiseFilterTolerance_11)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_noiseFilterTolerance_11() const { return ___noiseFilterTolerance_11; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_noiseFilterTolerance_11() { return &___noiseFilterTolerance_11; }
	inline void set_noiseFilterTolerance_11(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___noiseFilterTolerance_11 = value;
		Il2CppCodeGenWriteBarrier((&___noiseFilterTolerance_11), value);
	}

	inline static int32_t get_offset_of_blurTolerance_12() { return static_cast<int32_t>(offsetof(AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88, ___blurTolerance_12)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_blurTolerance_12() const { return ___blurTolerance_12; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_blurTolerance_12() { return &___blurTolerance_12; }
	inline void set_blurTolerance_12(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___blurTolerance_12 = value;
		Il2CppCodeGenWriteBarrier((&___blurTolerance_12), value);
	}

	inline static int32_t get_offset_of_upsampleTolerance_13() { return static_cast<int32_t>(offsetof(AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88, ___upsampleTolerance_13)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_upsampleTolerance_13() const { return ___upsampleTolerance_13; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_upsampleTolerance_13() { return &___upsampleTolerance_13; }
	inline void set_upsampleTolerance_13(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___upsampleTolerance_13 = value;
		Il2CppCodeGenWriteBarrier((&___upsampleTolerance_13), value);
	}

	inline static int32_t get_offset_of_thicknessModifier_14() { return static_cast<int32_t>(offsetof(AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88, ___thicknessModifier_14)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_thicknessModifier_14() const { return ___thicknessModifier_14; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_thicknessModifier_14() { return &___thicknessModifier_14; }
	inline void set_thicknessModifier_14(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___thicknessModifier_14 = value;
		Il2CppCodeGenWriteBarrier((&___thicknessModifier_14), value);
	}

	inline static int32_t get_offset_of_directLightingStrength_15() { return static_cast<int32_t>(offsetof(AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88, ___directLightingStrength_15)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_directLightingStrength_15() const { return ___directLightingStrength_15; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_directLightingStrength_15() { return &___directLightingStrength_15; }
	inline void set_directLightingStrength_15(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___directLightingStrength_15 = value;
		Il2CppCodeGenWriteBarrier((&___directLightingStrength_15), value);
	}

	inline static int32_t get_offset_of_radius_16() { return static_cast<int32_t>(offsetof(AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88, ___radius_16)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_radius_16() const { return ___radius_16; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_radius_16() { return &___radius_16; }
	inline void set_radius_16(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___radius_16 = value;
		Il2CppCodeGenWriteBarrier((&___radius_16), value);
	}

	inline static int32_t get_offset_of_quality_17() { return static_cast<int32_t>(offsetof(AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88, ___quality_17)); }
	inline AmbientOcclusionQualityParameter_tE18805DEFF6A5466E44B02E6D820336B9EA0E2FD * get_quality_17() const { return ___quality_17; }
	inline AmbientOcclusionQualityParameter_tE18805DEFF6A5466E44B02E6D820336B9EA0E2FD ** get_address_of_quality_17() { return &___quality_17; }
	inline void set_quality_17(AmbientOcclusionQualityParameter_tE18805DEFF6A5466E44B02E6D820336B9EA0E2FD * value)
	{
		___quality_17 = value;
		Il2CppCodeGenWriteBarrier((&___quality_17), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AMBIENTOCCLUSION_TFDCFB4EE09E8B263719F8CF50EC91915D78B1A88_H
#ifndef AUTOEXPOSURE_TFF4D354ADDD055C0C9E758B6150353B9B753A97C_H
#define AUTOEXPOSURE_TFF4D354ADDD055C0C9E758B6150353B9B753A97C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.AutoExposure
struct  AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C  : public PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E
{
public:
	// UnityEngine.Rendering.PostProcessing.Vector2Parameter UnityEngine.Rendering.PostProcessing.AutoExposure::filtering
	Vector2Parameter_t2138DCE95841B6A479E95D93280273119FCB0686 * ___filtering_7;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.AutoExposure::minLuminance
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___minLuminance_8;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.AutoExposure::maxLuminance
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___maxLuminance_9;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.AutoExposure::keyValue
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___keyValue_10;
	// UnityEngine.Rendering.PostProcessing.EyeAdaptationParameter UnityEngine.Rendering.PostProcessing.AutoExposure::eyeAdaptation
	EyeAdaptationParameter_t7AC22D9A78944F2CA208B5E2FDB40BD76B1C0B70 * ___eyeAdaptation_11;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.AutoExposure::speedUp
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___speedUp_12;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.AutoExposure::speedDown
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___speedDown_13;

public:
	inline static int32_t get_offset_of_filtering_7() { return static_cast<int32_t>(offsetof(AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C, ___filtering_7)); }
	inline Vector2Parameter_t2138DCE95841B6A479E95D93280273119FCB0686 * get_filtering_7() const { return ___filtering_7; }
	inline Vector2Parameter_t2138DCE95841B6A479E95D93280273119FCB0686 ** get_address_of_filtering_7() { return &___filtering_7; }
	inline void set_filtering_7(Vector2Parameter_t2138DCE95841B6A479E95D93280273119FCB0686 * value)
	{
		___filtering_7 = value;
		Il2CppCodeGenWriteBarrier((&___filtering_7), value);
	}

	inline static int32_t get_offset_of_minLuminance_8() { return static_cast<int32_t>(offsetof(AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C, ___minLuminance_8)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_minLuminance_8() const { return ___minLuminance_8; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_minLuminance_8() { return &___minLuminance_8; }
	inline void set_minLuminance_8(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___minLuminance_8 = value;
		Il2CppCodeGenWriteBarrier((&___minLuminance_8), value);
	}

	inline static int32_t get_offset_of_maxLuminance_9() { return static_cast<int32_t>(offsetof(AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C, ___maxLuminance_9)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_maxLuminance_9() const { return ___maxLuminance_9; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_maxLuminance_9() { return &___maxLuminance_9; }
	inline void set_maxLuminance_9(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___maxLuminance_9 = value;
		Il2CppCodeGenWriteBarrier((&___maxLuminance_9), value);
	}

	inline static int32_t get_offset_of_keyValue_10() { return static_cast<int32_t>(offsetof(AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C, ___keyValue_10)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_keyValue_10() const { return ___keyValue_10; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_keyValue_10() { return &___keyValue_10; }
	inline void set_keyValue_10(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___keyValue_10 = value;
		Il2CppCodeGenWriteBarrier((&___keyValue_10), value);
	}

	inline static int32_t get_offset_of_eyeAdaptation_11() { return static_cast<int32_t>(offsetof(AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C, ___eyeAdaptation_11)); }
	inline EyeAdaptationParameter_t7AC22D9A78944F2CA208B5E2FDB40BD76B1C0B70 * get_eyeAdaptation_11() const { return ___eyeAdaptation_11; }
	inline EyeAdaptationParameter_t7AC22D9A78944F2CA208B5E2FDB40BD76B1C0B70 ** get_address_of_eyeAdaptation_11() { return &___eyeAdaptation_11; }
	inline void set_eyeAdaptation_11(EyeAdaptationParameter_t7AC22D9A78944F2CA208B5E2FDB40BD76B1C0B70 * value)
	{
		___eyeAdaptation_11 = value;
		Il2CppCodeGenWriteBarrier((&___eyeAdaptation_11), value);
	}

	inline static int32_t get_offset_of_speedUp_12() { return static_cast<int32_t>(offsetof(AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C, ___speedUp_12)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_speedUp_12() const { return ___speedUp_12; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_speedUp_12() { return &___speedUp_12; }
	inline void set_speedUp_12(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___speedUp_12 = value;
		Il2CppCodeGenWriteBarrier((&___speedUp_12), value);
	}

	inline static int32_t get_offset_of_speedDown_13() { return static_cast<int32_t>(offsetof(AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C, ___speedDown_13)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_speedDown_13() const { return ___speedDown_13; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_speedDown_13() { return &___speedDown_13; }
	inline void set_speedDown_13(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___speedDown_13 = value;
		Il2CppCodeGenWriteBarrier((&___speedDown_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // AUTOEXPOSURE_TFF4D354ADDD055C0C9E758B6150353B9B753A97C_H
#ifndef BLOOM_T366FA2D84798539D570B23E02789925E1079B3DD_H
#define BLOOM_T366FA2D84798539D570B23E02789925E1079B3DD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.Bloom
struct  Bloom_t366FA2D84798539D570B23E02789925E1079B3DD  : public PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E
{
public:
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.Bloom::intensity
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___intensity_7;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.Bloom::threshold
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___threshold_8;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.Bloom::softKnee
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___softKnee_9;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.Bloom::clamp
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___clamp_10;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.Bloom::diffusion
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___diffusion_11;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.Bloom::anamorphicRatio
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___anamorphicRatio_12;
	// UnityEngine.Rendering.PostProcessing.ColorParameter UnityEngine.Rendering.PostProcessing.Bloom::color
	ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85 * ___color_13;
	// UnityEngine.Rendering.PostProcessing.BoolParameter UnityEngine.Rendering.PostProcessing.Bloom::fastMode
	BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * ___fastMode_14;
	// UnityEngine.Rendering.PostProcessing.TextureParameter UnityEngine.Rendering.PostProcessing.Bloom::dirtTexture
	TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 * ___dirtTexture_15;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.Bloom::dirtIntensity
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___dirtIntensity_16;

public:
	inline static int32_t get_offset_of_intensity_7() { return static_cast<int32_t>(offsetof(Bloom_t366FA2D84798539D570B23E02789925E1079B3DD, ___intensity_7)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_intensity_7() const { return ___intensity_7; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_intensity_7() { return &___intensity_7; }
	inline void set_intensity_7(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___intensity_7 = value;
		Il2CppCodeGenWriteBarrier((&___intensity_7), value);
	}

	inline static int32_t get_offset_of_threshold_8() { return static_cast<int32_t>(offsetof(Bloom_t366FA2D84798539D570B23E02789925E1079B3DD, ___threshold_8)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_threshold_8() const { return ___threshold_8; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_threshold_8() { return &___threshold_8; }
	inline void set_threshold_8(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___threshold_8 = value;
		Il2CppCodeGenWriteBarrier((&___threshold_8), value);
	}

	inline static int32_t get_offset_of_softKnee_9() { return static_cast<int32_t>(offsetof(Bloom_t366FA2D84798539D570B23E02789925E1079B3DD, ___softKnee_9)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_softKnee_9() const { return ___softKnee_9; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_softKnee_9() { return &___softKnee_9; }
	inline void set_softKnee_9(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___softKnee_9 = value;
		Il2CppCodeGenWriteBarrier((&___softKnee_9), value);
	}

	inline static int32_t get_offset_of_clamp_10() { return static_cast<int32_t>(offsetof(Bloom_t366FA2D84798539D570B23E02789925E1079B3DD, ___clamp_10)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_clamp_10() const { return ___clamp_10; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_clamp_10() { return &___clamp_10; }
	inline void set_clamp_10(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___clamp_10 = value;
		Il2CppCodeGenWriteBarrier((&___clamp_10), value);
	}

	inline static int32_t get_offset_of_diffusion_11() { return static_cast<int32_t>(offsetof(Bloom_t366FA2D84798539D570B23E02789925E1079B3DD, ___diffusion_11)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_diffusion_11() const { return ___diffusion_11; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_diffusion_11() { return &___diffusion_11; }
	inline void set_diffusion_11(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___diffusion_11 = value;
		Il2CppCodeGenWriteBarrier((&___diffusion_11), value);
	}

	inline static int32_t get_offset_of_anamorphicRatio_12() { return static_cast<int32_t>(offsetof(Bloom_t366FA2D84798539D570B23E02789925E1079B3DD, ___anamorphicRatio_12)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_anamorphicRatio_12() const { return ___anamorphicRatio_12; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_anamorphicRatio_12() { return &___anamorphicRatio_12; }
	inline void set_anamorphicRatio_12(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___anamorphicRatio_12 = value;
		Il2CppCodeGenWriteBarrier((&___anamorphicRatio_12), value);
	}

	inline static int32_t get_offset_of_color_13() { return static_cast<int32_t>(offsetof(Bloom_t366FA2D84798539D570B23E02789925E1079B3DD, ___color_13)); }
	inline ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85 * get_color_13() const { return ___color_13; }
	inline ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85 ** get_address_of_color_13() { return &___color_13; }
	inline void set_color_13(ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85 * value)
	{
		___color_13 = value;
		Il2CppCodeGenWriteBarrier((&___color_13), value);
	}

	inline static int32_t get_offset_of_fastMode_14() { return static_cast<int32_t>(offsetof(Bloom_t366FA2D84798539D570B23E02789925E1079B3DD, ___fastMode_14)); }
	inline BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * get_fastMode_14() const { return ___fastMode_14; }
	inline BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 ** get_address_of_fastMode_14() { return &___fastMode_14; }
	inline void set_fastMode_14(BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * value)
	{
		___fastMode_14 = value;
		Il2CppCodeGenWriteBarrier((&___fastMode_14), value);
	}

	inline static int32_t get_offset_of_dirtTexture_15() { return static_cast<int32_t>(offsetof(Bloom_t366FA2D84798539D570B23E02789925E1079B3DD, ___dirtTexture_15)); }
	inline TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 * get_dirtTexture_15() const { return ___dirtTexture_15; }
	inline TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 ** get_address_of_dirtTexture_15() { return &___dirtTexture_15; }
	inline void set_dirtTexture_15(TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 * value)
	{
		___dirtTexture_15 = value;
		Il2CppCodeGenWriteBarrier((&___dirtTexture_15), value);
	}

	inline static int32_t get_offset_of_dirtIntensity_16() { return static_cast<int32_t>(offsetof(Bloom_t366FA2D84798539D570B23E02789925E1079B3DD, ___dirtIntensity_16)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_dirtIntensity_16() const { return ___dirtIntensity_16; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_dirtIntensity_16() { return &___dirtIntensity_16; }
	inline void set_dirtIntensity_16(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___dirtIntensity_16 = value;
		Il2CppCodeGenWriteBarrier((&___dirtIntensity_16), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BLOOM_T366FA2D84798539D570B23E02789925E1079B3DD_H
#ifndef CHROMATICABERRATION_T78EC7F7C23F37A371DD46BB3F1631FEFF046400F_H
#define CHROMATICABERRATION_T78EC7F7C23F37A371DD46BB3F1631FEFF046400F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ChromaticAberration
struct  ChromaticAberration_t78EC7F7C23F37A371DD46BB3F1631FEFF046400F  : public PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E
{
public:
	// UnityEngine.Rendering.PostProcessing.TextureParameter UnityEngine.Rendering.PostProcessing.ChromaticAberration::spectralLut
	TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 * ___spectralLut_7;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ChromaticAberration::intensity
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___intensity_8;
	// UnityEngine.Rendering.PostProcessing.BoolParameter UnityEngine.Rendering.PostProcessing.ChromaticAberration::fastMode
	BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * ___fastMode_9;

public:
	inline static int32_t get_offset_of_spectralLut_7() { return static_cast<int32_t>(offsetof(ChromaticAberration_t78EC7F7C23F37A371DD46BB3F1631FEFF046400F, ___spectralLut_7)); }
	inline TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 * get_spectralLut_7() const { return ___spectralLut_7; }
	inline TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 ** get_address_of_spectralLut_7() { return &___spectralLut_7; }
	inline void set_spectralLut_7(TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 * value)
	{
		___spectralLut_7 = value;
		Il2CppCodeGenWriteBarrier((&___spectralLut_7), value);
	}

	inline static int32_t get_offset_of_intensity_8() { return static_cast<int32_t>(offsetof(ChromaticAberration_t78EC7F7C23F37A371DD46BB3F1631FEFF046400F, ___intensity_8)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_intensity_8() const { return ___intensity_8; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_intensity_8() { return &___intensity_8; }
	inline void set_intensity_8(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___intensity_8 = value;
		Il2CppCodeGenWriteBarrier((&___intensity_8), value);
	}

	inline static int32_t get_offset_of_fastMode_9() { return static_cast<int32_t>(offsetof(ChromaticAberration_t78EC7F7C23F37A371DD46BB3F1631FEFF046400F, ___fastMode_9)); }
	inline BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * get_fastMode_9() const { return ___fastMode_9; }
	inline BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 ** get_address_of_fastMode_9() { return &___fastMode_9; }
	inline void set_fastMode_9(BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * value)
	{
		___fastMode_9 = value;
		Il2CppCodeGenWriteBarrier((&___fastMode_9), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CHROMATICABERRATION_T78EC7F7C23F37A371DD46BB3F1631FEFF046400F_H
#ifndef COLORGRADING_T803342E88EC2C759690B13CC2F97DE2430120206_H
#define COLORGRADING_T803342E88EC2C759690B13CC2F97DE2430120206_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ColorGrading
struct  ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206  : public PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E
{
public:
	// UnityEngine.Rendering.PostProcessing.GradingModeParameter UnityEngine.Rendering.PostProcessing.ColorGrading::gradingMode
	GradingModeParameter_t30B66E571092CDA4D03618D02C0D71D84A7D9FA7 * ___gradingMode_7;
	// UnityEngine.Rendering.PostProcessing.TextureParameter UnityEngine.Rendering.PostProcessing.ColorGrading::externalLut
	TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 * ___externalLut_8;
	// UnityEngine.Rendering.PostProcessing.TonemapperParameter UnityEngine.Rendering.PostProcessing.ColorGrading::tonemapper
	TonemapperParameter_tAE067595EA8479188AA91EC38AD4BBA34CF2DA3B * ___tonemapper_9;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::toneCurveToeStrength
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___toneCurveToeStrength_10;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::toneCurveToeLength
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___toneCurveToeLength_11;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::toneCurveShoulderStrength
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___toneCurveShoulderStrength_12;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::toneCurveShoulderLength
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___toneCurveShoulderLength_13;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::toneCurveShoulderAngle
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___toneCurveShoulderAngle_14;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::toneCurveGamma
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___toneCurveGamma_15;
	// UnityEngine.Rendering.PostProcessing.TextureParameter UnityEngine.Rendering.PostProcessing.ColorGrading::ldrLut
	TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 * ___ldrLut_16;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::ldrLutContribution
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___ldrLutContribution_17;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::temperature
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___temperature_18;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::tint
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___tint_19;
	// UnityEngine.Rendering.PostProcessing.ColorParameter UnityEngine.Rendering.PostProcessing.ColorGrading::colorFilter
	ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85 * ___colorFilter_20;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::hueShift
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___hueShift_21;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::saturation
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___saturation_22;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::brightness
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___brightness_23;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::postExposure
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___postExposure_24;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::contrast
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___contrast_25;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::mixerRedOutRedIn
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___mixerRedOutRedIn_26;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::mixerRedOutGreenIn
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___mixerRedOutGreenIn_27;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::mixerRedOutBlueIn
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___mixerRedOutBlueIn_28;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::mixerGreenOutRedIn
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___mixerGreenOutRedIn_29;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::mixerGreenOutGreenIn
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___mixerGreenOutGreenIn_30;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::mixerGreenOutBlueIn
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___mixerGreenOutBlueIn_31;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::mixerBlueOutRedIn
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___mixerBlueOutRedIn_32;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::mixerBlueOutGreenIn
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___mixerBlueOutGreenIn_33;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ColorGrading::mixerBlueOutBlueIn
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___mixerBlueOutBlueIn_34;
	// UnityEngine.Rendering.PostProcessing.Vector4Parameter UnityEngine.Rendering.PostProcessing.ColorGrading::lift
	Vector4Parameter_t71A23EBB58A01E0FF756B1D104B8DE37F772E2F1 * ___lift_35;
	// UnityEngine.Rendering.PostProcessing.Vector4Parameter UnityEngine.Rendering.PostProcessing.ColorGrading::gamma
	Vector4Parameter_t71A23EBB58A01E0FF756B1D104B8DE37F772E2F1 * ___gamma_36;
	// UnityEngine.Rendering.PostProcessing.Vector4Parameter UnityEngine.Rendering.PostProcessing.ColorGrading::gain
	Vector4Parameter_t71A23EBB58A01E0FF756B1D104B8DE37F772E2F1 * ___gain_37;
	// UnityEngine.Rendering.PostProcessing.SplineParameter UnityEngine.Rendering.PostProcessing.ColorGrading::masterCurve
	SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * ___masterCurve_38;
	// UnityEngine.Rendering.PostProcessing.SplineParameter UnityEngine.Rendering.PostProcessing.ColorGrading::redCurve
	SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * ___redCurve_39;
	// UnityEngine.Rendering.PostProcessing.SplineParameter UnityEngine.Rendering.PostProcessing.ColorGrading::greenCurve
	SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * ___greenCurve_40;
	// UnityEngine.Rendering.PostProcessing.SplineParameter UnityEngine.Rendering.PostProcessing.ColorGrading::blueCurve
	SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * ___blueCurve_41;
	// UnityEngine.Rendering.PostProcessing.SplineParameter UnityEngine.Rendering.PostProcessing.ColorGrading::hueVsHueCurve
	SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * ___hueVsHueCurve_42;
	// UnityEngine.Rendering.PostProcessing.SplineParameter UnityEngine.Rendering.PostProcessing.ColorGrading::hueVsSatCurve
	SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * ___hueVsSatCurve_43;
	// UnityEngine.Rendering.PostProcessing.SplineParameter UnityEngine.Rendering.PostProcessing.ColorGrading::satVsSatCurve
	SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * ___satVsSatCurve_44;
	// UnityEngine.Rendering.PostProcessing.SplineParameter UnityEngine.Rendering.PostProcessing.ColorGrading::lumVsSatCurve
	SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * ___lumVsSatCurve_45;

public:
	inline static int32_t get_offset_of_gradingMode_7() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___gradingMode_7)); }
	inline GradingModeParameter_t30B66E571092CDA4D03618D02C0D71D84A7D9FA7 * get_gradingMode_7() const { return ___gradingMode_7; }
	inline GradingModeParameter_t30B66E571092CDA4D03618D02C0D71D84A7D9FA7 ** get_address_of_gradingMode_7() { return &___gradingMode_7; }
	inline void set_gradingMode_7(GradingModeParameter_t30B66E571092CDA4D03618D02C0D71D84A7D9FA7 * value)
	{
		___gradingMode_7 = value;
		Il2CppCodeGenWriteBarrier((&___gradingMode_7), value);
	}

	inline static int32_t get_offset_of_externalLut_8() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___externalLut_8)); }
	inline TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 * get_externalLut_8() const { return ___externalLut_8; }
	inline TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 ** get_address_of_externalLut_8() { return &___externalLut_8; }
	inline void set_externalLut_8(TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 * value)
	{
		___externalLut_8 = value;
		Il2CppCodeGenWriteBarrier((&___externalLut_8), value);
	}

	inline static int32_t get_offset_of_tonemapper_9() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___tonemapper_9)); }
	inline TonemapperParameter_tAE067595EA8479188AA91EC38AD4BBA34CF2DA3B * get_tonemapper_9() const { return ___tonemapper_9; }
	inline TonemapperParameter_tAE067595EA8479188AA91EC38AD4BBA34CF2DA3B ** get_address_of_tonemapper_9() { return &___tonemapper_9; }
	inline void set_tonemapper_9(TonemapperParameter_tAE067595EA8479188AA91EC38AD4BBA34CF2DA3B * value)
	{
		___tonemapper_9 = value;
		Il2CppCodeGenWriteBarrier((&___tonemapper_9), value);
	}

	inline static int32_t get_offset_of_toneCurveToeStrength_10() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___toneCurveToeStrength_10)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_toneCurveToeStrength_10() const { return ___toneCurveToeStrength_10; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_toneCurveToeStrength_10() { return &___toneCurveToeStrength_10; }
	inline void set_toneCurveToeStrength_10(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___toneCurveToeStrength_10 = value;
		Il2CppCodeGenWriteBarrier((&___toneCurveToeStrength_10), value);
	}

	inline static int32_t get_offset_of_toneCurveToeLength_11() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___toneCurveToeLength_11)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_toneCurveToeLength_11() const { return ___toneCurveToeLength_11; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_toneCurveToeLength_11() { return &___toneCurveToeLength_11; }
	inline void set_toneCurveToeLength_11(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___toneCurveToeLength_11 = value;
		Il2CppCodeGenWriteBarrier((&___toneCurveToeLength_11), value);
	}

	inline static int32_t get_offset_of_toneCurveShoulderStrength_12() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___toneCurveShoulderStrength_12)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_toneCurveShoulderStrength_12() const { return ___toneCurveShoulderStrength_12; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_toneCurveShoulderStrength_12() { return &___toneCurveShoulderStrength_12; }
	inline void set_toneCurveShoulderStrength_12(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___toneCurveShoulderStrength_12 = value;
		Il2CppCodeGenWriteBarrier((&___toneCurveShoulderStrength_12), value);
	}

	inline static int32_t get_offset_of_toneCurveShoulderLength_13() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___toneCurveShoulderLength_13)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_toneCurveShoulderLength_13() const { return ___toneCurveShoulderLength_13; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_toneCurveShoulderLength_13() { return &___toneCurveShoulderLength_13; }
	inline void set_toneCurveShoulderLength_13(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___toneCurveShoulderLength_13 = value;
		Il2CppCodeGenWriteBarrier((&___toneCurveShoulderLength_13), value);
	}

	inline static int32_t get_offset_of_toneCurveShoulderAngle_14() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___toneCurveShoulderAngle_14)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_toneCurveShoulderAngle_14() const { return ___toneCurveShoulderAngle_14; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_toneCurveShoulderAngle_14() { return &___toneCurveShoulderAngle_14; }
	inline void set_toneCurveShoulderAngle_14(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___toneCurveShoulderAngle_14 = value;
		Il2CppCodeGenWriteBarrier((&___toneCurveShoulderAngle_14), value);
	}

	inline static int32_t get_offset_of_toneCurveGamma_15() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___toneCurveGamma_15)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_toneCurveGamma_15() const { return ___toneCurveGamma_15; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_toneCurveGamma_15() { return &___toneCurveGamma_15; }
	inline void set_toneCurveGamma_15(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___toneCurveGamma_15 = value;
		Il2CppCodeGenWriteBarrier((&___toneCurveGamma_15), value);
	}

	inline static int32_t get_offset_of_ldrLut_16() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___ldrLut_16)); }
	inline TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 * get_ldrLut_16() const { return ___ldrLut_16; }
	inline TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 ** get_address_of_ldrLut_16() { return &___ldrLut_16; }
	inline void set_ldrLut_16(TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 * value)
	{
		___ldrLut_16 = value;
		Il2CppCodeGenWriteBarrier((&___ldrLut_16), value);
	}

	inline static int32_t get_offset_of_ldrLutContribution_17() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___ldrLutContribution_17)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_ldrLutContribution_17() const { return ___ldrLutContribution_17; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_ldrLutContribution_17() { return &___ldrLutContribution_17; }
	inline void set_ldrLutContribution_17(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___ldrLutContribution_17 = value;
		Il2CppCodeGenWriteBarrier((&___ldrLutContribution_17), value);
	}

	inline static int32_t get_offset_of_temperature_18() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___temperature_18)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_temperature_18() const { return ___temperature_18; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_temperature_18() { return &___temperature_18; }
	inline void set_temperature_18(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___temperature_18 = value;
		Il2CppCodeGenWriteBarrier((&___temperature_18), value);
	}

	inline static int32_t get_offset_of_tint_19() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___tint_19)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_tint_19() const { return ___tint_19; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_tint_19() { return &___tint_19; }
	inline void set_tint_19(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___tint_19 = value;
		Il2CppCodeGenWriteBarrier((&___tint_19), value);
	}

	inline static int32_t get_offset_of_colorFilter_20() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___colorFilter_20)); }
	inline ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85 * get_colorFilter_20() const { return ___colorFilter_20; }
	inline ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85 ** get_address_of_colorFilter_20() { return &___colorFilter_20; }
	inline void set_colorFilter_20(ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85 * value)
	{
		___colorFilter_20 = value;
		Il2CppCodeGenWriteBarrier((&___colorFilter_20), value);
	}

	inline static int32_t get_offset_of_hueShift_21() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___hueShift_21)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_hueShift_21() const { return ___hueShift_21; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_hueShift_21() { return &___hueShift_21; }
	inline void set_hueShift_21(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___hueShift_21 = value;
		Il2CppCodeGenWriteBarrier((&___hueShift_21), value);
	}

	inline static int32_t get_offset_of_saturation_22() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___saturation_22)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_saturation_22() const { return ___saturation_22; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_saturation_22() { return &___saturation_22; }
	inline void set_saturation_22(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___saturation_22 = value;
		Il2CppCodeGenWriteBarrier((&___saturation_22), value);
	}

	inline static int32_t get_offset_of_brightness_23() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___brightness_23)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_brightness_23() const { return ___brightness_23; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_brightness_23() { return &___brightness_23; }
	inline void set_brightness_23(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___brightness_23 = value;
		Il2CppCodeGenWriteBarrier((&___brightness_23), value);
	}

	inline static int32_t get_offset_of_postExposure_24() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___postExposure_24)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_postExposure_24() const { return ___postExposure_24; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_postExposure_24() { return &___postExposure_24; }
	inline void set_postExposure_24(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___postExposure_24 = value;
		Il2CppCodeGenWriteBarrier((&___postExposure_24), value);
	}

	inline static int32_t get_offset_of_contrast_25() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___contrast_25)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_contrast_25() const { return ___contrast_25; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_contrast_25() { return &___contrast_25; }
	inline void set_contrast_25(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___contrast_25 = value;
		Il2CppCodeGenWriteBarrier((&___contrast_25), value);
	}

	inline static int32_t get_offset_of_mixerRedOutRedIn_26() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___mixerRedOutRedIn_26)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_mixerRedOutRedIn_26() const { return ___mixerRedOutRedIn_26; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_mixerRedOutRedIn_26() { return &___mixerRedOutRedIn_26; }
	inline void set_mixerRedOutRedIn_26(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___mixerRedOutRedIn_26 = value;
		Il2CppCodeGenWriteBarrier((&___mixerRedOutRedIn_26), value);
	}

	inline static int32_t get_offset_of_mixerRedOutGreenIn_27() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___mixerRedOutGreenIn_27)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_mixerRedOutGreenIn_27() const { return ___mixerRedOutGreenIn_27; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_mixerRedOutGreenIn_27() { return &___mixerRedOutGreenIn_27; }
	inline void set_mixerRedOutGreenIn_27(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___mixerRedOutGreenIn_27 = value;
		Il2CppCodeGenWriteBarrier((&___mixerRedOutGreenIn_27), value);
	}

	inline static int32_t get_offset_of_mixerRedOutBlueIn_28() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___mixerRedOutBlueIn_28)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_mixerRedOutBlueIn_28() const { return ___mixerRedOutBlueIn_28; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_mixerRedOutBlueIn_28() { return &___mixerRedOutBlueIn_28; }
	inline void set_mixerRedOutBlueIn_28(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___mixerRedOutBlueIn_28 = value;
		Il2CppCodeGenWriteBarrier((&___mixerRedOutBlueIn_28), value);
	}

	inline static int32_t get_offset_of_mixerGreenOutRedIn_29() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___mixerGreenOutRedIn_29)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_mixerGreenOutRedIn_29() const { return ___mixerGreenOutRedIn_29; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_mixerGreenOutRedIn_29() { return &___mixerGreenOutRedIn_29; }
	inline void set_mixerGreenOutRedIn_29(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___mixerGreenOutRedIn_29 = value;
		Il2CppCodeGenWriteBarrier((&___mixerGreenOutRedIn_29), value);
	}

	inline static int32_t get_offset_of_mixerGreenOutGreenIn_30() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___mixerGreenOutGreenIn_30)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_mixerGreenOutGreenIn_30() const { return ___mixerGreenOutGreenIn_30; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_mixerGreenOutGreenIn_30() { return &___mixerGreenOutGreenIn_30; }
	inline void set_mixerGreenOutGreenIn_30(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___mixerGreenOutGreenIn_30 = value;
		Il2CppCodeGenWriteBarrier((&___mixerGreenOutGreenIn_30), value);
	}

	inline static int32_t get_offset_of_mixerGreenOutBlueIn_31() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___mixerGreenOutBlueIn_31)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_mixerGreenOutBlueIn_31() const { return ___mixerGreenOutBlueIn_31; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_mixerGreenOutBlueIn_31() { return &___mixerGreenOutBlueIn_31; }
	inline void set_mixerGreenOutBlueIn_31(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___mixerGreenOutBlueIn_31 = value;
		Il2CppCodeGenWriteBarrier((&___mixerGreenOutBlueIn_31), value);
	}

	inline static int32_t get_offset_of_mixerBlueOutRedIn_32() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___mixerBlueOutRedIn_32)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_mixerBlueOutRedIn_32() const { return ___mixerBlueOutRedIn_32; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_mixerBlueOutRedIn_32() { return &___mixerBlueOutRedIn_32; }
	inline void set_mixerBlueOutRedIn_32(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___mixerBlueOutRedIn_32 = value;
		Il2CppCodeGenWriteBarrier((&___mixerBlueOutRedIn_32), value);
	}

	inline static int32_t get_offset_of_mixerBlueOutGreenIn_33() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___mixerBlueOutGreenIn_33)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_mixerBlueOutGreenIn_33() const { return ___mixerBlueOutGreenIn_33; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_mixerBlueOutGreenIn_33() { return &___mixerBlueOutGreenIn_33; }
	inline void set_mixerBlueOutGreenIn_33(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___mixerBlueOutGreenIn_33 = value;
		Il2CppCodeGenWriteBarrier((&___mixerBlueOutGreenIn_33), value);
	}

	inline static int32_t get_offset_of_mixerBlueOutBlueIn_34() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___mixerBlueOutBlueIn_34)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_mixerBlueOutBlueIn_34() const { return ___mixerBlueOutBlueIn_34; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_mixerBlueOutBlueIn_34() { return &___mixerBlueOutBlueIn_34; }
	inline void set_mixerBlueOutBlueIn_34(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___mixerBlueOutBlueIn_34 = value;
		Il2CppCodeGenWriteBarrier((&___mixerBlueOutBlueIn_34), value);
	}

	inline static int32_t get_offset_of_lift_35() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___lift_35)); }
	inline Vector4Parameter_t71A23EBB58A01E0FF756B1D104B8DE37F772E2F1 * get_lift_35() const { return ___lift_35; }
	inline Vector4Parameter_t71A23EBB58A01E0FF756B1D104B8DE37F772E2F1 ** get_address_of_lift_35() { return &___lift_35; }
	inline void set_lift_35(Vector4Parameter_t71A23EBB58A01E0FF756B1D104B8DE37F772E2F1 * value)
	{
		___lift_35 = value;
		Il2CppCodeGenWriteBarrier((&___lift_35), value);
	}

	inline static int32_t get_offset_of_gamma_36() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___gamma_36)); }
	inline Vector4Parameter_t71A23EBB58A01E0FF756B1D104B8DE37F772E2F1 * get_gamma_36() const { return ___gamma_36; }
	inline Vector4Parameter_t71A23EBB58A01E0FF756B1D104B8DE37F772E2F1 ** get_address_of_gamma_36() { return &___gamma_36; }
	inline void set_gamma_36(Vector4Parameter_t71A23EBB58A01E0FF756B1D104B8DE37F772E2F1 * value)
	{
		___gamma_36 = value;
		Il2CppCodeGenWriteBarrier((&___gamma_36), value);
	}

	inline static int32_t get_offset_of_gain_37() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___gain_37)); }
	inline Vector4Parameter_t71A23EBB58A01E0FF756B1D104B8DE37F772E2F1 * get_gain_37() const { return ___gain_37; }
	inline Vector4Parameter_t71A23EBB58A01E0FF756B1D104B8DE37F772E2F1 ** get_address_of_gain_37() { return &___gain_37; }
	inline void set_gain_37(Vector4Parameter_t71A23EBB58A01E0FF756B1D104B8DE37F772E2F1 * value)
	{
		___gain_37 = value;
		Il2CppCodeGenWriteBarrier((&___gain_37), value);
	}

	inline static int32_t get_offset_of_masterCurve_38() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___masterCurve_38)); }
	inline SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * get_masterCurve_38() const { return ___masterCurve_38; }
	inline SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F ** get_address_of_masterCurve_38() { return &___masterCurve_38; }
	inline void set_masterCurve_38(SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * value)
	{
		___masterCurve_38 = value;
		Il2CppCodeGenWriteBarrier((&___masterCurve_38), value);
	}

	inline static int32_t get_offset_of_redCurve_39() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___redCurve_39)); }
	inline SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * get_redCurve_39() const { return ___redCurve_39; }
	inline SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F ** get_address_of_redCurve_39() { return &___redCurve_39; }
	inline void set_redCurve_39(SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * value)
	{
		___redCurve_39 = value;
		Il2CppCodeGenWriteBarrier((&___redCurve_39), value);
	}

	inline static int32_t get_offset_of_greenCurve_40() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___greenCurve_40)); }
	inline SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * get_greenCurve_40() const { return ___greenCurve_40; }
	inline SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F ** get_address_of_greenCurve_40() { return &___greenCurve_40; }
	inline void set_greenCurve_40(SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * value)
	{
		___greenCurve_40 = value;
		Il2CppCodeGenWriteBarrier((&___greenCurve_40), value);
	}

	inline static int32_t get_offset_of_blueCurve_41() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___blueCurve_41)); }
	inline SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * get_blueCurve_41() const { return ___blueCurve_41; }
	inline SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F ** get_address_of_blueCurve_41() { return &___blueCurve_41; }
	inline void set_blueCurve_41(SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * value)
	{
		___blueCurve_41 = value;
		Il2CppCodeGenWriteBarrier((&___blueCurve_41), value);
	}

	inline static int32_t get_offset_of_hueVsHueCurve_42() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___hueVsHueCurve_42)); }
	inline SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * get_hueVsHueCurve_42() const { return ___hueVsHueCurve_42; }
	inline SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F ** get_address_of_hueVsHueCurve_42() { return &___hueVsHueCurve_42; }
	inline void set_hueVsHueCurve_42(SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * value)
	{
		___hueVsHueCurve_42 = value;
		Il2CppCodeGenWriteBarrier((&___hueVsHueCurve_42), value);
	}

	inline static int32_t get_offset_of_hueVsSatCurve_43() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___hueVsSatCurve_43)); }
	inline SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * get_hueVsSatCurve_43() const { return ___hueVsSatCurve_43; }
	inline SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F ** get_address_of_hueVsSatCurve_43() { return &___hueVsSatCurve_43; }
	inline void set_hueVsSatCurve_43(SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * value)
	{
		___hueVsSatCurve_43 = value;
		Il2CppCodeGenWriteBarrier((&___hueVsSatCurve_43), value);
	}

	inline static int32_t get_offset_of_satVsSatCurve_44() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___satVsSatCurve_44)); }
	inline SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * get_satVsSatCurve_44() const { return ___satVsSatCurve_44; }
	inline SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F ** get_address_of_satVsSatCurve_44() { return &___satVsSatCurve_44; }
	inline void set_satVsSatCurve_44(SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * value)
	{
		___satVsSatCurve_44 = value;
		Il2CppCodeGenWriteBarrier((&___satVsSatCurve_44), value);
	}

	inline static int32_t get_offset_of_lumVsSatCurve_45() { return static_cast<int32_t>(offsetof(ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206, ___lumVsSatCurve_45)); }
	inline SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * get_lumVsSatCurve_45() const { return ___lumVsSatCurve_45; }
	inline SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F ** get_address_of_lumVsSatCurve_45() { return &___lumVsSatCurve_45; }
	inline void set_lumVsSatCurve_45(SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F * value)
	{
		___lumVsSatCurve_45 = value;
		Il2CppCodeGenWriteBarrier((&___lumVsSatCurve_45), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLORGRADING_T803342E88EC2C759690B13CC2F97DE2430120206_H
#ifndef DEPTHOFFIELD_T153113647F5C0209F97AA72B1C0FF6CC7A9E5F88_H
#define DEPTHOFFIELD_T153113647F5C0209F97AA72B1C0FF6CC7A9E5F88_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.DepthOfField
struct  DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88  : public PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E
{
public:
	// UnityEngine.Rendering.PostProcessing.BoolParameter UnityEngine.Rendering.PostProcessing.DepthOfField::holoplayDrivenFocus
	BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * ___holoplayDrivenFocus_7;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.DepthOfField::holoplayIntensity
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___holoplayIntensity_8;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.DepthOfField::focusDistance
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___focusDistance_9;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.DepthOfField::aperture
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___aperture_10;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.DepthOfField::focalLength
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___focalLength_11;
	// UnityEngine.Rendering.PostProcessing.KernelSizeParameter UnityEngine.Rendering.PostProcessing.DepthOfField::kernelSize
	KernelSizeParameter_t1290513B86C15182AD770816459A5398322F6642 * ___kernelSize_12;

public:
	inline static int32_t get_offset_of_holoplayDrivenFocus_7() { return static_cast<int32_t>(offsetof(DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88, ___holoplayDrivenFocus_7)); }
	inline BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * get_holoplayDrivenFocus_7() const { return ___holoplayDrivenFocus_7; }
	inline BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 ** get_address_of_holoplayDrivenFocus_7() { return &___holoplayDrivenFocus_7; }
	inline void set_holoplayDrivenFocus_7(BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * value)
	{
		___holoplayDrivenFocus_7 = value;
		Il2CppCodeGenWriteBarrier((&___holoplayDrivenFocus_7), value);
	}

	inline static int32_t get_offset_of_holoplayIntensity_8() { return static_cast<int32_t>(offsetof(DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88, ___holoplayIntensity_8)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_holoplayIntensity_8() const { return ___holoplayIntensity_8; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_holoplayIntensity_8() { return &___holoplayIntensity_8; }
	inline void set_holoplayIntensity_8(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___holoplayIntensity_8 = value;
		Il2CppCodeGenWriteBarrier((&___holoplayIntensity_8), value);
	}

	inline static int32_t get_offset_of_focusDistance_9() { return static_cast<int32_t>(offsetof(DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88, ___focusDistance_9)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_focusDistance_9() const { return ___focusDistance_9; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_focusDistance_9() { return &___focusDistance_9; }
	inline void set_focusDistance_9(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___focusDistance_9 = value;
		Il2CppCodeGenWriteBarrier((&___focusDistance_9), value);
	}

	inline static int32_t get_offset_of_aperture_10() { return static_cast<int32_t>(offsetof(DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88, ___aperture_10)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_aperture_10() const { return ___aperture_10; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_aperture_10() { return &___aperture_10; }
	inline void set_aperture_10(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___aperture_10 = value;
		Il2CppCodeGenWriteBarrier((&___aperture_10), value);
	}

	inline static int32_t get_offset_of_focalLength_11() { return static_cast<int32_t>(offsetof(DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88, ___focalLength_11)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_focalLength_11() const { return ___focalLength_11; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_focalLength_11() { return &___focalLength_11; }
	inline void set_focalLength_11(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___focalLength_11 = value;
		Il2CppCodeGenWriteBarrier((&___focalLength_11), value);
	}

	inline static int32_t get_offset_of_kernelSize_12() { return static_cast<int32_t>(offsetof(DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88, ___kernelSize_12)); }
	inline KernelSizeParameter_t1290513B86C15182AD770816459A5398322F6642 * get_kernelSize_12() const { return ___kernelSize_12; }
	inline KernelSizeParameter_t1290513B86C15182AD770816459A5398322F6642 ** get_address_of_kernelSize_12() { return &___kernelSize_12; }
	inline void set_kernelSize_12(KernelSizeParameter_t1290513B86C15182AD770816459A5398322F6642 * value)
	{
		___kernelSize_12 = value;
		Il2CppCodeGenWriteBarrier((&___kernelSize_12), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEPTHOFFIELD_T153113647F5C0209F97AA72B1C0FF6CC7A9E5F88_H
#ifndef GRAIN_T0ECCE83708F627DD09B42C375C38AC7387407A66_H
#define GRAIN_T0ECCE83708F627DD09B42C375C38AC7387407A66_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.Grain
struct  Grain_t0ECCE83708F627DD09B42C375C38AC7387407A66  : public PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E
{
public:
	// UnityEngine.Rendering.PostProcessing.BoolParameter UnityEngine.Rendering.PostProcessing.Grain::colored
	BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * ___colored_7;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.Grain::intensity
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___intensity_8;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.Grain::size
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___size_9;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.Grain::lumContrib
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___lumContrib_10;

public:
	inline static int32_t get_offset_of_colored_7() { return static_cast<int32_t>(offsetof(Grain_t0ECCE83708F627DD09B42C375C38AC7387407A66, ___colored_7)); }
	inline BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * get_colored_7() const { return ___colored_7; }
	inline BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 ** get_address_of_colored_7() { return &___colored_7; }
	inline void set_colored_7(BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * value)
	{
		___colored_7 = value;
		Il2CppCodeGenWriteBarrier((&___colored_7), value);
	}

	inline static int32_t get_offset_of_intensity_8() { return static_cast<int32_t>(offsetof(Grain_t0ECCE83708F627DD09B42C375C38AC7387407A66, ___intensity_8)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_intensity_8() const { return ___intensity_8; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_intensity_8() { return &___intensity_8; }
	inline void set_intensity_8(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___intensity_8 = value;
		Il2CppCodeGenWriteBarrier((&___intensity_8), value);
	}

	inline static int32_t get_offset_of_size_9() { return static_cast<int32_t>(offsetof(Grain_t0ECCE83708F627DD09B42C375C38AC7387407A66, ___size_9)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_size_9() const { return ___size_9; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_size_9() { return &___size_9; }
	inline void set_size_9(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___size_9 = value;
		Il2CppCodeGenWriteBarrier((&___size_9), value);
	}

	inline static int32_t get_offset_of_lumContrib_10() { return static_cast<int32_t>(offsetof(Grain_t0ECCE83708F627DD09B42C375C38AC7387407A66, ___lumContrib_10)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_lumContrib_10() const { return ___lumContrib_10; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_lumContrib_10() { return &___lumContrib_10; }
	inline void set_lumContrib_10(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___lumContrib_10 = value;
		Il2CppCodeGenWriteBarrier((&___lumContrib_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GRAIN_T0ECCE83708F627DD09B42C375C38AC7387407A66_H
#ifndef LENSDISTORTION_TE1D636EFC5BE460C031CB06010B2E5253FBDBDBB_H
#define LENSDISTORTION_TE1D636EFC5BE460C031CB06010B2E5253FBDBDBB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.LensDistortion
struct  LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB  : public PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E
{
public:
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.LensDistortion::intensity
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___intensity_7;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.LensDistortion::intensityX
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___intensityX_8;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.LensDistortion::intensityY
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___intensityY_9;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.LensDistortion::centerX
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___centerX_10;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.LensDistortion::centerY
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___centerY_11;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.LensDistortion::scale
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___scale_12;

public:
	inline static int32_t get_offset_of_intensity_7() { return static_cast<int32_t>(offsetof(LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB, ___intensity_7)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_intensity_7() const { return ___intensity_7; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_intensity_7() { return &___intensity_7; }
	inline void set_intensity_7(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___intensity_7 = value;
		Il2CppCodeGenWriteBarrier((&___intensity_7), value);
	}

	inline static int32_t get_offset_of_intensityX_8() { return static_cast<int32_t>(offsetof(LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB, ___intensityX_8)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_intensityX_8() const { return ___intensityX_8; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_intensityX_8() { return &___intensityX_8; }
	inline void set_intensityX_8(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___intensityX_8 = value;
		Il2CppCodeGenWriteBarrier((&___intensityX_8), value);
	}

	inline static int32_t get_offset_of_intensityY_9() { return static_cast<int32_t>(offsetof(LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB, ___intensityY_9)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_intensityY_9() const { return ___intensityY_9; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_intensityY_9() { return &___intensityY_9; }
	inline void set_intensityY_9(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___intensityY_9 = value;
		Il2CppCodeGenWriteBarrier((&___intensityY_9), value);
	}

	inline static int32_t get_offset_of_centerX_10() { return static_cast<int32_t>(offsetof(LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB, ___centerX_10)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_centerX_10() const { return ___centerX_10; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_centerX_10() { return &___centerX_10; }
	inline void set_centerX_10(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___centerX_10 = value;
		Il2CppCodeGenWriteBarrier((&___centerX_10), value);
	}

	inline static int32_t get_offset_of_centerY_11() { return static_cast<int32_t>(offsetof(LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB, ___centerY_11)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_centerY_11() const { return ___centerY_11; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_centerY_11() { return &___centerY_11; }
	inline void set_centerY_11(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___centerY_11 = value;
		Il2CppCodeGenWriteBarrier((&___centerY_11), value);
	}

	inline static int32_t get_offset_of_scale_12() { return static_cast<int32_t>(offsetof(LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB, ___scale_12)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_scale_12() const { return ___scale_12; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_scale_12() { return &___scale_12; }
	inline void set_scale_12(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___scale_12 = value;
		Il2CppCodeGenWriteBarrier((&___scale_12), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LENSDISTORTION_TE1D636EFC5BE460C031CB06010B2E5253FBDBDBB_H
#ifndef MOTIONBLUR_TC78F5B6F7B956D0BF4AE2E40BB2917C4FDB95D63_H
#define MOTIONBLUR_TC78F5B6F7B956D0BF4AE2E40BB2917C4FDB95D63_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.MotionBlur
struct  MotionBlur_tC78F5B6F7B956D0BF4AE2E40BB2917C4FDB95D63  : public PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E
{
public:
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.MotionBlur::shutterAngle
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___shutterAngle_7;
	// UnityEngine.Rendering.PostProcessing.IntParameter UnityEngine.Rendering.PostProcessing.MotionBlur::sampleCount
	IntParameter_tF314047E8059BF20F34E4202ACA31C6EAF8D7390 * ___sampleCount_8;

public:
	inline static int32_t get_offset_of_shutterAngle_7() { return static_cast<int32_t>(offsetof(MotionBlur_tC78F5B6F7B956D0BF4AE2E40BB2917C4FDB95D63, ___shutterAngle_7)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_shutterAngle_7() const { return ___shutterAngle_7; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_shutterAngle_7() { return &___shutterAngle_7; }
	inline void set_shutterAngle_7(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___shutterAngle_7 = value;
		Il2CppCodeGenWriteBarrier((&___shutterAngle_7), value);
	}

	inline static int32_t get_offset_of_sampleCount_8() { return static_cast<int32_t>(offsetof(MotionBlur_tC78F5B6F7B956D0BF4AE2E40BB2917C4FDB95D63, ___sampleCount_8)); }
	inline IntParameter_tF314047E8059BF20F34E4202ACA31C6EAF8D7390 * get_sampleCount_8() const { return ___sampleCount_8; }
	inline IntParameter_tF314047E8059BF20F34E4202ACA31C6EAF8D7390 ** get_address_of_sampleCount_8() { return &___sampleCount_8; }
	inline void set_sampleCount_8(IntParameter_tF314047E8059BF20F34E4202ACA31C6EAF8D7390 * value)
	{
		___sampleCount_8 = value;
		Il2CppCodeGenWriteBarrier((&___sampleCount_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MOTIONBLUR_TC78F5B6F7B956D0BF4AE2E40BB2917C4FDB95D63_H
#ifndef SCREENSPACEREFLECTIONS_TB82C51923CF234866D929319097853E840F53BE5_H
#define SCREENSPACEREFLECTIONS_TB82C51923CF234866D929319097853E840F53BE5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ScreenSpaceReflections
struct  ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5  : public PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E
{
public:
	// UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionPresetParameter UnityEngine.Rendering.PostProcessing.ScreenSpaceReflections::preset
	ScreenSpaceReflectionPresetParameter_t268DBDBDBA87C22733B30A3E3587B328E7F834E4 * ___preset_7;
	// UnityEngine.Rendering.PostProcessing.IntParameter UnityEngine.Rendering.PostProcessing.ScreenSpaceReflections::maximumIterationCount
	IntParameter_tF314047E8059BF20F34E4202ACA31C6EAF8D7390 * ___maximumIterationCount_8;
	// UnityEngine.Rendering.PostProcessing.ScreenSpaceReflectionResolutionParameter UnityEngine.Rendering.PostProcessing.ScreenSpaceReflections::resolution
	ScreenSpaceReflectionResolutionParameter_tC897149ADF64CB366527300D8A12FE2E5AE8B943 * ___resolution_9;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ScreenSpaceReflections::thickness
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___thickness_10;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ScreenSpaceReflections::maximumMarchDistance
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___maximumMarchDistance_11;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ScreenSpaceReflections::distanceFade
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___distanceFade_12;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.ScreenSpaceReflections::vignette
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___vignette_13;

public:
	inline static int32_t get_offset_of_preset_7() { return static_cast<int32_t>(offsetof(ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5, ___preset_7)); }
	inline ScreenSpaceReflectionPresetParameter_t268DBDBDBA87C22733B30A3E3587B328E7F834E4 * get_preset_7() const { return ___preset_7; }
	inline ScreenSpaceReflectionPresetParameter_t268DBDBDBA87C22733B30A3E3587B328E7F834E4 ** get_address_of_preset_7() { return &___preset_7; }
	inline void set_preset_7(ScreenSpaceReflectionPresetParameter_t268DBDBDBA87C22733B30A3E3587B328E7F834E4 * value)
	{
		___preset_7 = value;
		Il2CppCodeGenWriteBarrier((&___preset_7), value);
	}

	inline static int32_t get_offset_of_maximumIterationCount_8() { return static_cast<int32_t>(offsetof(ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5, ___maximumIterationCount_8)); }
	inline IntParameter_tF314047E8059BF20F34E4202ACA31C6EAF8D7390 * get_maximumIterationCount_8() const { return ___maximumIterationCount_8; }
	inline IntParameter_tF314047E8059BF20F34E4202ACA31C6EAF8D7390 ** get_address_of_maximumIterationCount_8() { return &___maximumIterationCount_8; }
	inline void set_maximumIterationCount_8(IntParameter_tF314047E8059BF20F34E4202ACA31C6EAF8D7390 * value)
	{
		___maximumIterationCount_8 = value;
		Il2CppCodeGenWriteBarrier((&___maximumIterationCount_8), value);
	}

	inline static int32_t get_offset_of_resolution_9() { return static_cast<int32_t>(offsetof(ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5, ___resolution_9)); }
	inline ScreenSpaceReflectionResolutionParameter_tC897149ADF64CB366527300D8A12FE2E5AE8B943 * get_resolution_9() const { return ___resolution_9; }
	inline ScreenSpaceReflectionResolutionParameter_tC897149ADF64CB366527300D8A12FE2E5AE8B943 ** get_address_of_resolution_9() { return &___resolution_9; }
	inline void set_resolution_9(ScreenSpaceReflectionResolutionParameter_tC897149ADF64CB366527300D8A12FE2E5AE8B943 * value)
	{
		___resolution_9 = value;
		Il2CppCodeGenWriteBarrier((&___resolution_9), value);
	}

	inline static int32_t get_offset_of_thickness_10() { return static_cast<int32_t>(offsetof(ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5, ___thickness_10)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_thickness_10() const { return ___thickness_10; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_thickness_10() { return &___thickness_10; }
	inline void set_thickness_10(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___thickness_10 = value;
		Il2CppCodeGenWriteBarrier((&___thickness_10), value);
	}

	inline static int32_t get_offset_of_maximumMarchDistance_11() { return static_cast<int32_t>(offsetof(ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5, ___maximumMarchDistance_11)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_maximumMarchDistance_11() const { return ___maximumMarchDistance_11; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_maximumMarchDistance_11() { return &___maximumMarchDistance_11; }
	inline void set_maximumMarchDistance_11(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___maximumMarchDistance_11 = value;
		Il2CppCodeGenWriteBarrier((&___maximumMarchDistance_11), value);
	}

	inline static int32_t get_offset_of_distanceFade_12() { return static_cast<int32_t>(offsetof(ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5, ___distanceFade_12)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_distanceFade_12() const { return ___distanceFade_12; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_distanceFade_12() { return &___distanceFade_12; }
	inline void set_distanceFade_12(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___distanceFade_12 = value;
		Il2CppCodeGenWriteBarrier((&___distanceFade_12), value);
	}

	inline static int32_t get_offset_of_vignette_13() { return static_cast<int32_t>(offsetof(ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5, ___vignette_13)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_vignette_13() const { return ___vignette_13; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_vignette_13() { return &___vignette_13; }
	inline void set_vignette_13(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___vignette_13 = value;
		Il2CppCodeGenWriteBarrier((&___vignette_13), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SCREENSPACEREFLECTIONS_TB82C51923CF234866D929319097853E840F53BE5_H
#ifndef VIGNETTE_T46590867E1C0E87B27698ADF0C5FEA776535002E_H
#define VIGNETTE_T46590867E1C0E87B27698ADF0C5FEA776535002E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.Vignette
struct  Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E  : public PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E
{
public:
	// UnityEngine.Rendering.PostProcessing.VignetteModeParameter UnityEngine.Rendering.PostProcessing.Vignette::mode
	VignetteModeParameter_t0853E96B549BCF8765CE8FEB6B50EB78706645A6 * ___mode_7;
	// UnityEngine.Rendering.PostProcessing.ColorParameter UnityEngine.Rendering.PostProcessing.Vignette::color
	ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85 * ___color_8;
	// UnityEngine.Rendering.PostProcessing.Vector2Parameter UnityEngine.Rendering.PostProcessing.Vignette::center
	Vector2Parameter_t2138DCE95841B6A479E95D93280273119FCB0686 * ___center_9;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.Vignette::intensity
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___intensity_10;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.Vignette::smoothness
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___smoothness_11;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.Vignette::roundness
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___roundness_12;
	// UnityEngine.Rendering.PostProcessing.BoolParameter UnityEngine.Rendering.PostProcessing.Vignette::rounded
	BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * ___rounded_13;
	// UnityEngine.Rendering.PostProcessing.TextureParameter UnityEngine.Rendering.PostProcessing.Vignette::mask
	TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 * ___mask_14;
	// UnityEngine.Rendering.PostProcessing.FloatParameter UnityEngine.Rendering.PostProcessing.Vignette::opacity
	FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * ___opacity_15;

public:
	inline static int32_t get_offset_of_mode_7() { return static_cast<int32_t>(offsetof(Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E, ___mode_7)); }
	inline VignetteModeParameter_t0853E96B549BCF8765CE8FEB6B50EB78706645A6 * get_mode_7() const { return ___mode_7; }
	inline VignetteModeParameter_t0853E96B549BCF8765CE8FEB6B50EB78706645A6 ** get_address_of_mode_7() { return &___mode_7; }
	inline void set_mode_7(VignetteModeParameter_t0853E96B549BCF8765CE8FEB6B50EB78706645A6 * value)
	{
		___mode_7 = value;
		Il2CppCodeGenWriteBarrier((&___mode_7), value);
	}

	inline static int32_t get_offset_of_color_8() { return static_cast<int32_t>(offsetof(Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E, ___color_8)); }
	inline ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85 * get_color_8() const { return ___color_8; }
	inline ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85 ** get_address_of_color_8() { return &___color_8; }
	inline void set_color_8(ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85 * value)
	{
		___color_8 = value;
		Il2CppCodeGenWriteBarrier((&___color_8), value);
	}

	inline static int32_t get_offset_of_center_9() { return static_cast<int32_t>(offsetof(Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E, ___center_9)); }
	inline Vector2Parameter_t2138DCE95841B6A479E95D93280273119FCB0686 * get_center_9() const { return ___center_9; }
	inline Vector2Parameter_t2138DCE95841B6A479E95D93280273119FCB0686 ** get_address_of_center_9() { return &___center_9; }
	inline void set_center_9(Vector2Parameter_t2138DCE95841B6A479E95D93280273119FCB0686 * value)
	{
		___center_9 = value;
		Il2CppCodeGenWriteBarrier((&___center_9), value);
	}

	inline static int32_t get_offset_of_intensity_10() { return static_cast<int32_t>(offsetof(Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E, ___intensity_10)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_intensity_10() const { return ___intensity_10; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_intensity_10() { return &___intensity_10; }
	inline void set_intensity_10(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___intensity_10 = value;
		Il2CppCodeGenWriteBarrier((&___intensity_10), value);
	}

	inline static int32_t get_offset_of_smoothness_11() { return static_cast<int32_t>(offsetof(Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E, ___smoothness_11)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_smoothness_11() const { return ___smoothness_11; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_smoothness_11() { return &___smoothness_11; }
	inline void set_smoothness_11(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___smoothness_11 = value;
		Il2CppCodeGenWriteBarrier((&___smoothness_11), value);
	}

	inline static int32_t get_offset_of_roundness_12() { return static_cast<int32_t>(offsetof(Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E, ___roundness_12)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_roundness_12() const { return ___roundness_12; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_roundness_12() { return &___roundness_12; }
	inline void set_roundness_12(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___roundness_12 = value;
		Il2CppCodeGenWriteBarrier((&___roundness_12), value);
	}

	inline static int32_t get_offset_of_rounded_13() { return static_cast<int32_t>(offsetof(Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E, ___rounded_13)); }
	inline BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * get_rounded_13() const { return ___rounded_13; }
	inline BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 ** get_address_of_rounded_13() { return &___rounded_13; }
	inline void set_rounded_13(BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * value)
	{
		___rounded_13 = value;
		Il2CppCodeGenWriteBarrier((&___rounded_13), value);
	}

	inline static int32_t get_offset_of_mask_14() { return static_cast<int32_t>(offsetof(Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E, ___mask_14)); }
	inline TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 * get_mask_14() const { return ___mask_14; }
	inline TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 ** get_address_of_mask_14() { return &___mask_14; }
	inline void set_mask_14(TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720 * value)
	{
		___mask_14 = value;
		Il2CppCodeGenWriteBarrier((&___mask_14), value);
	}

	inline static int32_t get_offset_of_opacity_15() { return static_cast<int32_t>(offsetof(Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E, ___opacity_15)); }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * get_opacity_15() const { return ___opacity_15; }
	inline FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 ** get_address_of_opacity_15() { return &___opacity_15; }
	inline void set_opacity_15(FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703 * value)
	{
		___opacity_15 = value;
		Il2CppCodeGenWriteBarrier((&___opacity_15), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIGNETTE_T46590867E1C0E87B27698ADF0C5FEA776535002E_H
#ifndef DEMOBLURUNBLUR_TDBB3258EA70203A9BF510F319F3BB71AA0197386_H
#define DEMOBLURUNBLUR_TDBB3258EA70203A9BF510F319F3BB71AA0197386_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Demos.DemoBlurUnblur
struct  DemoBlurUnblur_tDBB3258EA70203A9BF510F319F3BB71AA0197386  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Rendering.PostProcessing.PostProcessVolume LookingGlass.Demos.DemoBlurUnblur::postProcessingVolume
	PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3 * ___postProcessingVolume_4;
	// UnityEngine.UI.Text LookingGlass.Demos.DemoBlurUnblur::label
	Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * ___label_5;
	// System.Boolean LookingGlass.Demos.DemoBlurUnblur::enablePostProcessing
	bool ___enablePostProcessing_6;

public:
	inline static int32_t get_offset_of_postProcessingVolume_4() { return static_cast<int32_t>(offsetof(DemoBlurUnblur_tDBB3258EA70203A9BF510F319F3BB71AA0197386, ___postProcessingVolume_4)); }
	inline PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3 * get_postProcessingVolume_4() const { return ___postProcessingVolume_4; }
	inline PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3 ** get_address_of_postProcessingVolume_4() { return &___postProcessingVolume_4; }
	inline void set_postProcessingVolume_4(PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3 * value)
	{
		___postProcessingVolume_4 = value;
		Il2CppCodeGenWriteBarrier((&___postProcessingVolume_4), value);
	}

	inline static int32_t get_offset_of_label_5() { return static_cast<int32_t>(offsetof(DemoBlurUnblur_tDBB3258EA70203A9BF510F319F3BB71AA0197386, ___label_5)); }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * get_label_5() const { return ___label_5; }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 ** get_address_of_label_5() { return &___label_5; }
	inline void set_label_5(Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * value)
	{
		___label_5 = value;
		Il2CppCodeGenWriteBarrier((&___label_5), value);
	}

	inline static int32_t get_offset_of_enablePostProcessing_6() { return static_cast<int32_t>(offsetof(DemoBlurUnblur_tDBB3258EA70203A9BF510F319F3BB71AA0197386, ___enablePostProcessing_6)); }
	inline bool get_enablePostProcessing_6() const { return ___enablePostProcessing_6; }
	inline bool* get_address_of_enablePostProcessing_6() { return &___enablePostProcessing_6; }
	inline void set_enablePostProcessing_6(bool value)
	{
		___enablePostProcessing_6 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEMOBLURUNBLUR_TDBB3258EA70203A9BF510F319F3BB71AA0197386_H
#ifndef DEMOCAPTUREANIMATOR_T1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4_H
#define DEMOCAPTUREANIMATOR_T1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Demos.DemoCaptureAnimator
struct  DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// LookingGlass.Holoplay LookingGlass.Demos.DemoCaptureAnimator::holoplay
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * ___holoplay_4;
	// System.Boolean LookingGlass.Demos.DemoCaptureAnimator::animatePosition
	bool ___animatePosition_5;
	// System.Boolean LookingGlass.Demos.DemoCaptureAnimator::animateScale
	bool ___animateScale_6;
	// System.Boolean LookingGlass.Demos.DemoCaptureAnimator::animateRotation
	bool ___animateRotation_7;
	// System.Boolean LookingGlass.Demos.DemoCaptureAnimator::animateClippingPlane
	bool ___animateClippingPlane_8;
	// System.Boolean LookingGlass.Demos.DemoCaptureAnimator::animateFOV
	bool ___animateFOV_9;
	// UnityEngine.Vector3 LookingGlass.Demos.DemoCaptureAnimator::positionDirection
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___positionDirection_10;
	// System.Single LookingGlass.Demos.DemoCaptureAnimator::scaleDirection
	float ___scaleDirection_11;
	// System.Single LookingGlass.Demos.DemoCaptureAnimator::twistAmount
	float ___twistAmount_12;
	// System.Single LookingGlass.Demos.DemoCaptureAnimator::twistDirection
	float ___twistDirection_13;
	// System.Single LookingGlass.Demos.DemoCaptureAnimator::clippingPlaneDirection
	float ___clippingPlaneDirection_14;
	// System.Single LookingGlass.Demos.DemoCaptureAnimator::FOVAnimationDirection
	float ___FOVAnimationDirection_15;

public:
	inline static int32_t get_offset_of_holoplay_4() { return static_cast<int32_t>(offsetof(DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4, ___holoplay_4)); }
	inline Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * get_holoplay_4() const { return ___holoplay_4; }
	inline Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A ** get_address_of_holoplay_4() { return &___holoplay_4; }
	inline void set_holoplay_4(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * value)
	{
		___holoplay_4 = value;
		Il2CppCodeGenWriteBarrier((&___holoplay_4), value);
	}

	inline static int32_t get_offset_of_animatePosition_5() { return static_cast<int32_t>(offsetof(DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4, ___animatePosition_5)); }
	inline bool get_animatePosition_5() const { return ___animatePosition_5; }
	inline bool* get_address_of_animatePosition_5() { return &___animatePosition_5; }
	inline void set_animatePosition_5(bool value)
	{
		___animatePosition_5 = value;
	}

	inline static int32_t get_offset_of_animateScale_6() { return static_cast<int32_t>(offsetof(DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4, ___animateScale_6)); }
	inline bool get_animateScale_6() const { return ___animateScale_6; }
	inline bool* get_address_of_animateScale_6() { return &___animateScale_6; }
	inline void set_animateScale_6(bool value)
	{
		___animateScale_6 = value;
	}

	inline static int32_t get_offset_of_animateRotation_7() { return static_cast<int32_t>(offsetof(DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4, ___animateRotation_7)); }
	inline bool get_animateRotation_7() const { return ___animateRotation_7; }
	inline bool* get_address_of_animateRotation_7() { return &___animateRotation_7; }
	inline void set_animateRotation_7(bool value)
	{
		___animateRotation_7 = value;
	}

	inline static int32_t get_offset_of_animateClippingPlane_8() { return static_cast<int32_t>(offsetof(DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4, ___animateClippingPlane_8)); }
	inline bool get_animateClippingPlane_8() const { return ___animateClippingPlane_8; }
	inline bool* get_address_of_animateClippingPlane_8() { return &___animateClippingPlane_8; }
	inline void set_animateClippingPlane_8(bool value)
	{
		___animateClippingPlane_8 = value;
	}

	inline static int32_t get_offset_of_animateFOV_9() { return static_cast<int32_t>(offsetof(DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4, ___animateFOV_9)); }
	inline bool get_animateFOV_9() const { return ___animateFOV_9; }
	inline bool* get_address_of_animateFOV_9() { return &___animateFOV_9; }
	inline void set_animateFOV_9(bool value)
	{
		___animateFOV_9 = value;
	}

	inline static int32_t get_offset_of_positionDirection_10() { return static_cast<int32_t>(offsetof(DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4, ___positionDirection_10)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_positionDirection_10() const { return ___positionDirection_10; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_positionDirection_10() { return &___positionDirection_10; }
	inline void set_positionDirection_10(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___positionDirection_10 = value;
	}

	inline static int32_t get_offset_of_scaleDirection_11() { return static_cast<int32_t>(offsetof(DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4, ___scaleDirection_11)); }
	inline float get_scaleDirection_11() const { return ___scaleDirection_11; }
	inline float* get_address_of_scaleDirection_11() { return &___scaleDirection_11; }
	inline void set_scaleDirection_11(float value)
	{
		___scaleDirection_11 = value;
	}

	inline static int32_t get_offset_of_twistAmount_12() { return static_cast<int32_t>(offsetof(DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4, ___twistAmount_12)); }
	inline float get_twistAmount_12() const { return ___twistAmount_12; }
	inline float* get_address_of_twistAmount_12() { return &___twistAmount_12; }
	inline void set_twistAmount_12(float value)
	{
		___twistAmount_12 = value;
	}

	inline static int32_t get_offset_of_twistDirection_13() { return static_cast<int32_t>(offsetof(DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4, ___twistDirection_13)); }
	inline float get_twistDirection_13() const { return ___twistDirection_13; }
	inline float* get_address_of_twistDirection_13() { return &___twistDirection_13; }
	inline void set_twistDirection_13(float value)
	{
		___twistDirection_13 = value;
	}

	inline static int32_t get_offset_of_clippingPlaneDirection_14() { return static_cast<int32_t>(offsetof(DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4, ___clippingPlaneDirection_14)); }
	inline float get_clippingPlaneDirection_14() const { return ___clippingPlaneDirection_14; }
	inline float* get_address_of_clippingPlaneDirection_14() { return &___clippingPlaneDirection_14; }
	inline void set_clippingPlaneDirection_14(float value)
	{
		___clippingPlaneDirection_14 = value;
	}

	inline static int32_t get_offset_of_FOVAnimationDirection_15() { return static_cast<int32_t>(offsetof(DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4, ___FOVAnimationDirection_15)); }
	inline float get_FOVAnimationDirection_15() const { return ___FOVAnimationDirection_15; }
	inline float* get_address_of_FOVAnimationDirection_15() { return &___FOVAnimationDirection_15; }
	inline void set_FOVAnimationDirection_15(float value)
	{
		___FOVAnimationDirection_15 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEMOCAPTUREANIMATOR_T1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4_H
#ifndef DEMOCURSORINTERACTION_TFE7DC2F8B0B80E0307CA639719808D76B93163F2_H
#define DEMOCURSORINTERACTION_TFE7DC2F8B0B80E0307CA639719808D76B93163F2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Demos.DemoCursorInteraction
struct  DemoCursorInteraction_tFE7DC2F8B0B80E0307CA639719808D76B93163F2  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject LookingGlass.Demos.DemoCursorInteraction::holoplay
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___holoplay_4;
	// LookingGlass.Cursor3D LookingGlass.Demos.DemoCursorInteraction::cursor
	Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6 * ___cursor_5;
	// UnityEngine.Vector3 LookingGlass.Demos.DemoCursorInteraction::nextPosition
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___nextPosition_6;

public:
	inline static int32_t get_offset_of_holoplay_4() { return static_cast<int32_t>(offsetof(DemoCursorInteraction_tFE7DC2F8B0B80E0307CA639719808D76B93163F2, ___holoplay_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_holoplay_4() const { return ___holoplay_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_holoplay_4() { return &___holoplay_4; }
	inline void set_holoplay_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___holoplay_4 = value;
		Il2CppCodeGenWriteBarrier((&___holoplay_4), value);
	}

	inline static int32_t get_offset_of_cursor_5() { return static_cast<int32_t>(offsetof(DemoCursorInteraction_tFE7DC2F8B0B80E0307CA639719808D76B93163F2, ___cursor_5)); }
	inline Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6 * get_cursor_5() const { return ___cursor_5; }
	inline Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6 ** get_address_of_cursor_5() { return &___cursor_5; }
	inline void set_cursor_5(Cursor3D_tF4009A33E3994048D1FEE399C55AB2DF046900C6 * value)
	{
		___cursor_5 = value;
		Il2CppCodeGenWriteBarrier((&___cursor_5), value);
	}

	inline static int32_t get_offset_of_nextPosition_6() { return static_cast<int32_t>(offsetof(DemoCursorInteraction_tFE7DC2F8B0B80E0307CA639719808D76B93163F2, ___nextPosition_6)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_nextPosition_6() const { return ___nextPosition_6; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_nextPosition_6() { return &___nextPosition_6; }
	inline void set_nextPosition_6(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___nextPosition_6 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEMOCURSORINTERACTION_TFE7DC2F8B0B80E0307CA639719808D76B93163F2_H
#ifndef DEMOMOVETEXT_T4389265A71C9E789AB437D9AA84500A99B6D699E_H
#define DEMOMOVETEXT_T4389265A71C9E789AB437D9AA84500A99B6D699E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Demos.DemoMoveText
struct  DemoMoveText_t4389265A71C9E789AB437D9AA84500A99B6D699E  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// LookingGlass.Holoplay LookingGlass.Demos.DemoMoveText::holoplay
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * ___holoplay_4;
	// UnityEngine.TextMesh LookingGlass.Demos.DemoMoveText::label
	TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A * ___label_5;
	// UnityEngine.TextMesh LookingGlass.Demos.DemoMoveText::textThatMoves
	TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A * ___textThatMoves_6;
	// System.Single LookingGlass.Demos.DemoMoveText::whenToStartAutomating
	float ___whenToStartAutomating_7;
	// System.Single LookingGlass.Demos.DemoMoveText::amountForward
	float ___amountForward_8;

public:
	inline static int32_t get_offset_of_holoplay_4() { return static_cast<int32_t>(offsetof(DemoMoveText_t4389265A71C9E789AB437D9AA84500A99B6D699E, ___holoplay_4)); }
	inline Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * get_holoplay_4() const { return ___holoplay_4; }
	inline Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A ** get_address_of_holoplay_4() { return &___holoplay_4; }
	inline void set_holoplay_4(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * value)
	{
		___holoplay_4 = value;
		Il2CppCodeGenWriteBarrier((&___holoplay_4), value);
	}

	inline static int32_t get_offset_of_label_5() { return static_cast<int32_t>(offsetof(DemoMoveText_t4389265A71C9E789AB437D9AA84500A99B6D699E, ___label_5)); }
	inline TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A * get_label_5() const { return ___label_5; }
	inline TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A ** get_address_of_label_5() { return &___label_5; }
	inline void set_label_5(TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A * value)
	{
		___label_5 = value;
		Il2CppCodeGenWriteBarrier((&___label_5), value);
	}

	inline static int32_t get_offset_of_textThatMoves_6() { return static_cast<int32_t>(offsetof(DemoMoveText_t4389265A71C9E789AB437D9AA84500A99B6D699E, ___textThatMoves_6)); }
	inline TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A * get_textThatMoves_6() const { return ___textThatMoves_6; }
	inline TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A ** get_address_of_textThatMoves_6() { return &___textThatMoves_6; }
	inline void set_textThatMoves_6(TextMesh_t327D0DAFEF431170D8C2882083D442AF4D4A0E4A * value)
	{
		___textThatMoves_6 = value;
		Il2CppCodeGenWriteBarrier((&___textThatMoves_6), value);
	}

	inline static int32_t get_offset_of_whenToStartAutomating_7() { return static_cast<int32_t>(offsetof(DemoMoveText_t4389265A71C9E789AB437D9AA84500A99B6D699E, ___whenToStartAutomating_7)); }
	inline float get_whenToStartAutomating_7() const { return ___whenToStartAutomating_7; }
	inline float* get_address_of_whenToStartAutomating_7() { return &___whenToStartAutomating_7; }
	inline void set_whenToStartAutomating_7(float value)
	{
		___whenToStartAutomating_7 = value;
	}

	inline static int32_t get_offset_of_amountForward_8() { return static_cast<int32_t>(offsetof(DemoMoveText_t4389265A71C9E789AB437D9AA84500A99B6D699E, ___amountForward_8)); }
	inline float get_amountForward_8() const { return ___amountForward_8; }
	inline float* get_address_of_amountForward_8() { return &___amountForward_8; }
	inline void set_amountForward_8(float value)
	{
		___amountForward_8 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEMOMOVETEXT_T4389265A71C9E789AB437D9AA84500A99B6D699E_H
#ifndef DEMOMULTIPLEXSWITCHER_TB58FC84AB9BA3F1467B4702F7C9FCD6944D054D1_H
#define DEMOMULTIPLEXSWITCHER_TB58FC84AB9BA3F1467B4702F7C9FCD6944D054D1_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Demos.DemoMultiplexSwitcher
struct  DemoMultiplexSwitcher_tB58FC84AB9BA3F1467B4702F7C9FCD6944D054D1  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// LookingGlass.Multiplex LookingGlass.Demos.DemoMultiplexSwitcher::multiplexer
	Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F * ___multiplexer_4;
	// System.Boolean LookingGlass.Demos.DemoMultiplexSwitcher::swapDisplays
	bool ___swapDisplays_5;
	// System.Boolean LookingGlass.Demos.DemoMultiplexSwitcher::lastToggleState
	bool ___lastToggleState_6;

public:
	inline static int32_t get_offset_of_multiplexer_4() { return static_cast<int32_t>(offsetof(DemoMultiplexSwitcher_tB58FC84AB9BA3F1467B4702F7C9FCD6944D054D1, ___multiplexer_4)); }
	inline Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F * get_multiplexer_4() const { return ___multiplexer_4; }
	inline Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F ** get_address_of_multiplexer_4() { return &___multiplexer_4; }
	inline void set_multiplexer_4(Multiplex_t3E93A908DD482C9CF94DEB9AA50C7E9DC575732F * value)
	{
		___multiplexer_4 = value;
		Il2CppCodeGenWriteBarrier((&___multiplexer_4), value);
	}

	inline static int32_t get_offset_of_swapDisplays_5() { return static_cast<int32_t>(offsetof(DemoMultiplexSwitcher_tB58FC84AB9BA3F1467B4702F7C9FCD6944D054D1, ___swapDisplays_5)); }
	inline bool get_swapDisplays_5() const { return ___swapDisplays_5; }
	inline bool* get_address_of_swapDisplays_5() { return &___swapDisplays_5; }
	inline void set_swapDisplays_5(bool value)
	{
		___swapDisplays_5 = value;
	}

	inline static int32_t get_offset_of_lastToggleState_6() { return static_cast<int32_t>(offsetof(DemoMultiplexSwitcher_tB58FC84AB9BA3F1467B4702F7C9FCD6944D054D1, ___lastToggleState_6)); }
	inline bool get_lastToggleState_6() const { return ___lastToggleState_6; }
	inline bool* get_address_of_lastToggleState_6() { return &___lastToggleState_6; }
	inline void set_lastToggleState_6(bool value)
	{
		___lastToggleState_6 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEMOMULTIPLEXSWITCHER_TB58FC84AB9BA3F1467B4702F7C9FCD6944D054D1_H
#ifndef DEMOQUILTTOGGLE_TAF5F8ACF1353E89B717ED4A7E0EF5C6E7D619935_H
#define DEMOQUILTTOGGLE_TAF5F8ACF1353E89B717ED4A7E0EF5C6E7D619935_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Demos.DemoQuiltToggle
struct  DemoQuiltToggle_tAF5F8ACF1353E89B717ED4A7E0EF5C6E7D619935  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// LookingGlass.Holoplay LookingGlass.Demos.DemoQuiltToggle::holoplay
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * ___holoplay_4;
	// UnityEngine.Texture2D LookingGlass.Demos.DemoQuiltToggle::quiltToOverrideWith
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___quiltToOverrideWith_5;
	// LookingGlass.Demos.DemoQuiltToggle_WhatToShow LookingGlass.Demos.DemoQuiltToggle::whatToShow
	int32_t ___whatToShow_6;
	// LookingGlass.Demos.DemoQuiltToggle_WhatToShow LookingGlass.Demos.DemoQuiltToggle::lastFrame
	int32_t ___lastFrame_7;

public:
	inline static int32_t get_offset_of_holoplay_4() { return static_cast<int32_t>(offsetof(DemoQuiltToggle_tAF5F8ACF1353E89B717ED4A7E0EF5C6E7D619935, ___holoplay_4)); }
	inline Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * get_holoplay_4() const { return ___holoplay_4; }
	inline Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A ** get_address_of_holoplay_4() { return &___holoplay_4; }
	inline void set_holoplay_4(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * value)
	{
		___holoplay_4 = value;
		Il2CppCodeGenWriteBarrier((&___holoplay_4), value);
	}

	inline static int32_t get_offset_of_quiltToOverrideWith_5() { return static_cast<int32_t>(offsetof(DemoQuiltToggle_tAF5F8ACF1353E89B717ED4A7E0EF5C6E7D619935, ___quiltToOverrideWith_5)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_quiltToOverrideWith_5() const { return ___quiltToOverrideWith_5; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_quiltToOverrideWith_5() { return &___quiltToOverrideWith_5; }
	inline void set_quiltToOverrideWith_5(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___quiltToOverrideWith_5 = value;
		Il2CppCodeGenWriteBarrier((&___quiltToOverrideWith_5), value);
	}

	inline static int32_t get_offset_of_whatToShow_6() { return static_cast<int32_t>(offsetof(DemoQuiltToggle_tAF5F8ACF1353E89B717ED4A7E0EF5C6E7D619935, ___whatToShow_6)); }
	inline int32_t get_whatToShow_6() const { return ___whatToShow_6; }
	inline int32_t* get_address_of_whatToShow_6() { return &___whatToShow_6; }
	inline void set_whatToShow_6(int32_t value)
	{
		___whatToShow_6 = value;
	}

	inline static int32_t get_offset_of_lastFrame_7() { return static_cast<int32_t>(offsetof(DemoQuiltToggle_tAF5F8ACF1353E89B717ED4A7E0EF5C6E7D619935, ___lastFrame_7)); }
	inline int32_t get_lastFrame_7() const { return ___lastFrame_7; }
	inline int32_t* get_address_of_lastFrame_7() { return &___lastFrame_7; }
	inline void set_lastFrame_7(int32_t value)
	{
		___lastFrame_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEMOQUILTTOGGLE_TAF5F8ACF1353E89B717ED4A7E0EF5C6E7D619935_H
#ifndef LIGHTFLICKER_T93769C9D1337975AB7AB0BB10BEC584265B5A03E_H
#define LIGHTFLICKER_T93769C9D1337975AB7AB0BB10BEC584265B5A03E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Extras.lightFlicker
struct  lightFlicker_t93769C9D1337975AB7AB0BB10BEC584265B5A03E  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Color LookingGlass.Extras.lightFlicker::A
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___A_4;
	// UnityEngine.Color LookingGlass.Extras.lightFlicker::B
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___B_5;
	// UnityEngine.Light LookingGlass.Extras.lightFlicker::flickerLight
	Light_tFDE490EADBC7E080F74CA804929513AF07C31A6C * ___flickerLight_6;

public:
	inline static int32_t get_offset_of_A_4() { return static_cast<int32_t>(offsetof(lightFlicker_t93769C9D1337975AB7AB0BB10BEC584265B5A03E, ___A_4)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_A_4() const { return ___A_4; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_A_4() { return &___A_4; }
	inline void set_A_4(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___A_4 = value;
	}

	inline static int32_t get_offset_of_B_5() { return static_cast<int32_t>(offsetof(lightFlicker_t93769C9D1337975AB7AB0BB10BEC584265B5A03E, ___B_5)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_B_5() const { return ___B_5; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_B_5() { return &___B_5; }
	inline void set_B_5(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___B_5 = value;
	}

	inline static int32_t get_offset_of_flickerLight_6() { return static_cast<int32_t>(offsetof(lightFlicker_t93769C9D1337975AB7AB0BB10BEC584265B5A03E, ___flickerLight_6)); }
	inline Light_tFDE490EADBC7E080F74CA804929513AF07C31A6C * get_flickerLight_6() const { return ___flickerLight_6; }
	inline Light_tFDE490EADBC7E080F74CA804929513AF07C31A6C ** get_address_of_flickerLight_6() { return &___flickerLight_6; }
	inline void set_flickerLight_6(Light_tFDE490EADBC7E080F74CA804929513AF07C31A6C * value)
	{
		___flickerLight_6 = value;
		Il2CppCodeGenWriteBarrier((&___flickerLight_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LIGHTFLICKER_T93769C9D1337975AB7AB0BB10BEC584265B5A03E_H
#ifndef PROWORKSTATIONBASEIPC_T1EC245A931FACC8C87DCE5A18B56CD6591C8CEC5_H
#define PROWORKSTATIONBASEIPC_T1EC245A931FACC8C87DCE5A18B56CD6591C8CEC5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.ProWorkstation.ProWorkstationBaseIPC
struct  ProWorkstationBaseIPC_t1EC245A931FACC8C87DCE5A18B56CD6591C8CEC5  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// LookingGlass.ProWorkstation.ProWorkstationDisplay LookingGlass.ProWorkstation.ProWorkstationBaseIPC::display
	int32_t ___display_4;
	// System.Boolean LookingGlass.ProWorkstation.ProWorkstationBaseIPC::automaticallyHandleIPC
	bool ___automaticallyHandleIPC_5;
	// InterProcessCommunicator LookingGlass.ProWorkstation.ProWorkstationBaseIPC::ipc
	InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019 * ___ipc_6;

public:
	inline static int32_t get_offset_of_display_4() { return static_cast<int32_t>(offsetof(ProWorkstationBaseIPC_t1EC245A931FACC8C87DCE5A18B56CD6591C8CEC5, ___display_4)); }
	inline int32_t get_display_4() const { return ___display_4; }
	inline int32_t* get_address_of_display_4() { return &___display_4; }
	inline void set_display_4(int32_t value)
	{
		___display_4 = value;
	}

	inline static int32_t get_offset_of_automaticallyHandleIPC_5() { return static_cast<int32_t>(offsetof(ProWorkstationBaseIPC_t1EC245A931FACC8C87DCE5A18B56CD6591C8CEC5, ___automaticallyHandleIPC_5)); }
	inline bool get_automaticallyHandleIPC_5() const { return ___automaticallyHandleIPC_5; }
	inline bool* get_address_of_automaticallyHandleIPC_5() { return &___automaticallyHandleIPC_5; }
	inline void set_automaticallyHandleIPC_5(bool value)
	{
		___automaticallyHandleIPC_5 = value;
	}

	inline static int32_t get_offset_of_ipc_6() { return static_cast<int32_t>(offsetof(ProWorkstationBaseIPC_t1EC245A931FACC8C87DCE5A18B56CD6591C8CEC5, ___ipc_6)); }
	inline InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019 * get_ipc_6() const { return ___ipc_6; }
	inline InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019 ** get_address_of_ipc_6() { return &___ipc_6; }
	inline void set_ipc_6(InterProcessCommunicator_tC57C16C709EAB83416D28F1855D4860758C35019 * value)
	{
		___ipc_6 = value;
		Il2CppCodeGenWriteBarrier((&___ipc_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PROWORKSTATIONBASEIPC_T1EC245A931FACC8C87DCE5A18B56CD6591C8CEC5_H
#ifndef PROWORKSTATIONMANAGER_T19009075A1FE396B246986282D275010E752FC8D_H
#define PROWORKSTATIONMANAGER_T19009075A1FE396B246986282D275010E752FC8D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.ProWorkstation.ProWorkstationManager
struct  ProWorkstationManager_t19009075A1FE396B246986282D275010E752FC8D  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// LookingGlass.ProWorkstation.ProWorkstationDisplay LookingGlass.ProWorkstation.ProWorkstationManager::display
	int32_t ___display_5;
	// System.Diagnostics.Process LookingGlass.ProWorkstation.ProWorkstationManager::process
	Process_t7F28AE318E6CCF89716D05E78E2CBD669767D6A1 * ___process_6;

public:
	inline static int32_t get_offset_of_display_5() { return static_cast<int32_t>(offsetof(ProWorkstationManager_t19009075A1FE396B246986282D275010E752FC8D, ___display_5)); }
	inline int32_t get_display_5() const { return ___display_5; }
	inline int32_t* get_address_of_display_5() { return &___display_5; }
	inline void set_display_5(int32_t value)
	{
		___display_5 = value;
	}

	inline static int32_t get_offset_of_process_6() { return static_cast<int32_t>(offsetof(ProWorkstationManager_t19009075A1FE396B246986282D275010E752FC8D, ___process_6)); }
	inline Process_t7F28AE318E6CCF89716D05E78E2CBD669767D6A1 * get_process_6() const { return ___process_6; }
	inline Process_t7F28AE318E6CCF89716D05E78E2CBD669767D6A1 ** get_address_of_process_6() { return &___process_6; }
	inline void set_process_6(Process_t7F28AE318E6CCF89716D05E78E2CBD669767D6A1 * value)
	{
		___process_6 = value;
		Il2CppCodeGenWriteBarrier((&___process_6), value);
	}
};

struct ProWorkstationManager_t19009075A1FE396B246986282D275010E752FC8D_StaticFields
{
public:
	// LookingGlass.ProWorkstation.ProWorkstationManager LookingGlass.ProWorkstation.ProWorkstationManager::instance
	ProWorkstationManager_t19009075A1FE396B246986282D275010E752FC8D * ___instance_7;

public:
	inline static int32_t get_offset_of_instance_7() { return static_cast<int32_t>(offsetof(ProWorkstationManager_t19009075A1FE396B246986282D275010E752FC8D_StaticFields, ___instance_7)); }
	inline ProWorkstationManager_t19009075A1FE396B246986282D275010E752FC8D * get_instance_7() const { return ___instance_7; }
	inline ProWorkstationManager_t19009075A1FE396B246986282D275010E752FC8D ** get_address_of_instance_7() { return &___instance_7; }
	inline void set_instance_7(ProWorkstationManager_t19009075A1FE396B246986282D275010E752FC8D * value)
	{
		___instance_7 = value;
		Il2CppCodeGenWriteBarrier((&___instance_7), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PROWORKSTATIONMANAGER_T19009075A1FE396B246986282D275010E752FC8D_H
#ifndef SIMPLEDOF_T90F40269D6F71B745708A018C3CEDDF4932723D9_H
#define SIMPLEDOF_T90F40269D6F71B745708A018C3CEDDF4932723D9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.SimpleDOF
struct  SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// LookingGlass.Holoplay LookingGlass.SimpleDOF::holoplay
	Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * ___holoplay_4;
	// System.Single LookingGlass.SimpleDOF::start
	float ___start_5;
	// System.Single LookingGlass.SimpleDOF::dip
	float ___dip_6;
	// System.Single LookingGlass.SimpleDOF::rise
	float ___rise_7;
	// System.Single LookingGlass.SimpleDOF::end
	float ___end_8;
	// System.Single LookingGlass.SimpleDOF::blurSize
	float ___blurSize_9;
	// System.Boolean LookingGlass.SimpleDOF::horizontalOnly
	bool ___horizontalOnly_10;
	// System.Boolean LookingGlass.SimpleDOF::testFocus
	bool ___testFocus_11;
	// UnityEngine.Material LookingGlass.SimpleDOF::passdepthMat
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___passdepthMat_12;
	// UnityEngine.Material LookingGlass.SimpleDOF::boxBlurMat
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___boxBlurMat_13;
	// UnityEngine.Material LookingGlass.SimpleDOF::finalpassMat
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___finalpassMat_14;

public:
	inline static int32_t get_offset_of_holoplay_4() { return static_cast<int32_t>(offsetof(SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9, ___holoplay_4)); }
	inline Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * get_holoplay_4() const { return ___holoplay_4; }
	inline Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A ** get_address_of_holoplay_4() { return &___holoplay_4; }
	inline void set_holoplay_4(Holoplay_tE1D6BDF468D366341C53CDEAB3828B4ADF11A98A * value)
	{
		___holoplay_4 = value;
		Il2CppCodeGenWriteBarrier((&___holoplay_4), value);
	}

	inline static int32_t get_offset_of_start_5() { return static_cast<int32_t>(offsetof(SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9, ___start_5)); }
	inline float get_start_5() const { return ___start_5; }
	inline float* get_address_of_start_5() { return &___start_5; }
	inline void set_start_5(float value)
	{
		___start_5 = value;
	}

	inline static int32_t get_offset_of_dip_6() { return static_cast<int32_t>(offsetof(SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9, ___dip_6)); }
	inline float get_dip_6() const { return ___dip_6; }
	inline float* get_address_of_dip_6() { return &___dip_6; }
	inline void set_dip_6(float value)
	{
		___dip_6 = value;
	}

	inline static int32_t get_offset_of_rise_7() { return static_cast<int32_t>(offsetof(SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9, ___rise_7)); }
	inline float get_rise_7() const { return ___rise_7; }
	inline float* get_address_of_rise_7() { return &___rise_7; }
	inline void set_rise_7(float value)
	{
		___rise_7 = value;
	}

	inline static int32_t get_offset_of_end_8() { return static_cast<int32_t>(offsetof(SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9, ___end_8)); }
	inline float get_end_8() const { return ___end_8; }
	inline float* get_address_of_end_8() { return &___end_8; }
	inline void set_end_8(float value)
	{
		___end_8 = value;
	}

	inline static int32_t get_offset_of_blurSize_9() { return static_cast<int32_t>(offsetof(SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9, ___blurSize_9)); }
	inline float get_blurSize_9() const { return ___blurSize_9; }
	inline float* get_address_of_blurSize_9() { return &___blurSize_9; }
	inline void set_blurSize_9(float value)
	{
		___blurSize_9 = value;
	}

	inline static int32_t get_offset_of_horizontalOnly_10() { return static_cast<int32_t>(offsetof(SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9, ___horizontalOnly_10)); }
	inline bool get_horizontalOnly_10() const { return ___horizontalOnly_10; }
	inline bool* get_address_of_horizontalOnly_10() { return &___horizontalOnly_10; }
	inline void set_horizontalOnly_10(bool value)
	{
		___horizontalOnly_10 = value;
	}

	inline static int32_t get_offset_of_testFocus_11() { return static_cast<int32_t>(offsetof(SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9, ___testFocus_11)); }
	inline bool get_testFocus_11() const { return ___testFocus_11; }
	inline bool* get_address_of_testFocus_11() { return &___testFocus_11; }
	inline void set_testFocus_11(bool value)
	{
		___testFocus_11 = value;
	}

	inline static int32_t get_offset_of_passdepthMat_12() { return static_cast<int32_t>(offsetof(SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9, ___passdepthMat_12)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_passdepthMat_12() const { return ___passdepthMat_12; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_passdepthMat_12() { return &___passdepthMat_12; }
	inline void set_passdepthMat_12(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___passdepthMat_12 = value;
		Il2CppCodeGenWriteBarrier((&___passdepthMat_12), value);
	}

	inline static int32_t get_offset_of_boxBlurMat_13() { return static_cast<int32_t>(offsetof(SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9, ___boxBlurMat_13)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_boxBlurMat_13() const { return ___boxBlurMat_13; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_boxBlurMat_13() { return &___boxBlurMat_13; }
	inline void set_boxBlurMat_13(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___boxBlurMat_13 = value;
		Il2CppCodeGenWriteBarrier((&___boxBlurMat_13), value);
	}

	inline static int32_t get_offset_of_finalpassMat_14() { return static_cast<int32_t>(offsetof(SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9, ___finalpassMat_14)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_finalpassMat_14() const { return ___finalpassMat_14; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_finalpassMat_14() { return &___finalpassMat_14; }
	inline void set_finalpassMat_14(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___finalpassMat_14 = value;
		Il2CppCodeGenWriteBarrier((&___finalpassMat_14), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SIMPLEDOF_T90F40269D6F71B745708A018C3CEDDF4932723D9_H
#ifndef DEMOPROWORKSTATIONIPC_T7095278B75809BC2A85FA4071C414BBF25157B87_H
#define DEMOPROWORKSTATIONIPC_T7095278B75809BC2A85FA4071C414BBF25157B87_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// LookingGlass.Demos.DemoProWorkstationIPC
struct  DemoProWorkstationIPC_t7095278B75809BC2A85FA4071C414BBF25157B87  : public ProWorkstationBaseIPC_t1EC245A931FACC8C87DCE5A18B56CD6591C8CEC5
{
public:
	// UnityEngine.Transform LookingGlass.Demos.DemoProWorkstationIPC::cubeTransform
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___cubeTransform_7;
	// UnityEngine.UI.Text LookingGlass.Demos.DemoProWorkstationIPC::rotationText
	Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * ___rotationText_8;

public:
	inline static int32_t get_offset_of_cubeTransform_7() { return static_cast<int32_t>(offsetof(DemoProWorkstationIPC_t7095278B75809BC2A85FA4071C414BBF25157B87, ___cubeTransform_7)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_cubeTransform_7() const { return ___cubeTransform_7; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_cubeTransform_7() { return &___cubeTransform_7; }
	inline void set_cubeTransform_7(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___cubeTransform_7 = value;
		Il2CppCodeGenWriteBarrier((&___cubeTransform_7), value);
	}

	inline static int32_t get_offset_of_rotationText_8() { return static_cast<int32_t>(offsetof(DemoProWorkstationIPC_t7095278B75809BC2A85FA4071C414BBF25157B87, ___rotationText_8)); }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * get_rotationText_8() const { return ___rotationText_8; }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 ** get_address_of_rotationText_8() { return &___rotationText_8; }
	inline void set_rotationText_8(Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * value)
	{
		___rotationText_8 = value;
		Il2CppCodeGenWriteBarrier((&___rotationText_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEMOPROWORKSTATIONIPC_T7095278B75809BC2A85FA4071C414BBF25157B87_H





#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3500 = { sizeof (Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46)+ sizeof (RuntimeObject), sizeof(Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable3500[13] = 
{
	Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46::get_offset_of_quiltWidth_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46::get_offset_of_quiltHeight_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46::get_offset_of_viewColumns_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46::get_offset_of_viewRows_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46::get_offset_of_numViews_4() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46::get_offset_of_viewWidth_5() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46::get_offset_of_viewHeight_6() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46::get_offset_of_paddingHorizontal_7() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46::get_offset_of_paddingVertical_8() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46::get_offset_of_viewPortionHorizontal_9() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46::get_offset_of_viewPortionVertical_10() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46::get_offset_of_aspect_11() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t66035998D175B806D5716B35A62E2BCA7FC51F46::get_offset_of_overscan_12() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3501 = { sizeof (Preset_t27691E17FCF96CC5B8FEA0D1EE87E5ECAD724C86)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3501[8] = 
{
	Preset_t27691E17FCF96CC5B8FEA0D1EE87E5ECAD724C86::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3502 = { sizeof (SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3502[11] = 
{
	SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9::get_offset_of_holoplay_4(),
	SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9::get_offset_of_start_5(),
	SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9::get_offset_of_dip_6(),
	SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9::get_offset_of_rise_7(),
	SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9::get_offset_of_end_8(),
	SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9::get_offset_of_blurSize_9(),
	SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9::get_offset_of_horizontalOnly_10(),
	SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9::get_offset_of_testFocus_11(),
	SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9::get_offset_of_passdepthMat_12(),
	SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9::get_offset_of_boxBlurMat_13(),
	SimpleDOF_t90F40269D6F71B745708A018C3CEDDF4932723D9::get_offset_of_finalpassMat_14(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3503 = { sizeof (ProWorkstationBaseIPC_t1EC245A931FACC8C87DCE5A18B56CD6591C8CEC5), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3503[3] = 
{
	ProWorkstationBaseIPC_t1EC245A931FACC8C87DCE5A18B56CD6591C8CEC5::get_offset_of_display_4(),
	ProWorkstationBaseIPC_t1EC245A931FACC8C87DCE5A18B56CD6591C8CEC5::get_offset_of_automaticallyHandleIPC_5(),
	ProWorkstationBaseIPC_t1EC245A931FACC8C87DCE5A18B56CD6591C8CEC5::get_offset_of_ipc_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3504 = { sizeof (ProWorkstationDisplay_t97FAAFFA6708F832EB706D8CD1C32B67C4FD6303)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3504[3] = 
{
	ProWorkstationDisplay_t97FAAFFA6708F832EB706D8CD1C32B67C4FD6303::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3505 = { sizeof (ProWorkstationManager_t19009075A1FE396B246986282D275010E752FC8D), -1, sizeof(ProWorkstationManager_t19009075A1FE396B246986282D275010E752FC8D_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3505[8] = 
{
	0,
	ProWorkstationManager_t19009075A1FE396B246986282D275010E752FC8D::get_offset_of_display_5(),
	ProWorkstationManager_t19009075A1FE396B246986282D275010E752FC8D::get_offset_of_process_6(),
	ProWorkstationManager_t19009075A1FE396B246986282D275010E752FC8D_StaticFields::get_offset_of_instance_7(),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3506 = { sizeof (lightFlicker_t93769C9D1337975AB7AB0BB10BEC584265B5A03E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3506[3] = 
{
	lightFlicker_t93769C9D1337975AB7AB0BB10BEC584265B5A03E::get_offset_of_A_4(),
	lightFlicker_t93769C9D1337975AB7AB0BB10BEC584265B5A03E::get_offset_of_B_5(),
	lightFlicker_t93769C9D1337975AB7AB0BB10BEC584265B5A03E::get_offset_of_flickerLight_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3507 = { sizeof (DemoBlurUnblur_tDBB3258EA70203A9BF510F319F3BB71AA0197386), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3507[3] = 
{
	DemoBlurUnblur_tDBB3258EA70203A9BF510F319F3BB71AA0197386::get_offset_of_postProcessingVolume_4(),
	DemoBlurUnblur_tDBB3258EA70203A9BF510F319F3BB71AA0197386::get_offset_of_label_5(),
	DemoBlurUnblur_tDBB3258EA70203A9BF510F319F3BB71AA0197386::get_offset_of_enablePostProcessing_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3508 = { sizeof (DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3508[12] = 
{
	DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4::get_offset_of_holoplay_4(),
	DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4::get_offset_of_animatePosition_5(),
	DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4::get_offset_of_animateScale_6(),
	DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4::get_offset_of_animateRotation_7(),
	DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4::get_offset_of_animateClippingPlane_8(),
	DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4::get_offset_of_animateFOV_9(),
	DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4::get_offset_of_positionDirection_10(),
	DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4::get_offset_of_scaleDirection_11(),
	DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4::get_offset_of_twistAmount_12(),
	DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4::get_offset_of_twistDirection_13(),
	DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4::get_offset_of_clippingPlaneDirection_14(),
	DemoCaptureAnimator_t1A19B4DECEFB1783D0E4DCE2D4D59899FE9D53C4::get_offset_of_FOVAnimationDirection_15(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3509 = { sizeof (DemoCursorInteraction_tFE7DC2F8B0B80E0307CA639719808D76B93163F2), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3509[3] = 
{
	DemoCursorInteraction_tFE7DC2F8B0B80E0307CA639719808D76B93163F2::get_offset_of_holoplay_4(),
	DemoCursorInteraction_tFE7DC2F8B0B80E0307CA639719808D76B93163F2::get_offset_of_cursor_5(),
	DemoCursorInteraction_tFE7DC2F8B0B80E0307CA639719808D76B93163F2::get_offset_of_nextPosition_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3510 = { sizeof (DemoMoveText_t4389265A71C9E789AB437D9AA84500A99B6D699E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3510[5] = 
{
	DemoMoveText_t4389265A71C9E789AB437D9AA84500A99B6D699E::get_offset_of_holoplay_4(),
	DemoMoveText_t4389265A71C9E789AB437D9AA84500A99B6D699E::get_offset_of_label_5(),
	DemoMoveText_t4389265A71C9E789AB437D9AA84500A99B6D699E::get_offset_of_textThatMoves_6(),
	DemoMoveText_t4389265A71C9E789AB437D9AA84500A99B6D699E::get_offset_of_whenToStartAutomating_7(),
	DemoMoveText_t4389265A71C9E789AB437D9AA84500A99B6D699E::get_offset_of_amountForward_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3511 = { sizeof (DemoMultiplexSwitcher_tB58FC84AB9BA3F1467B4702F7C9FCD6944D054D1), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3511[3] = 
{
	DemoMultiplexSwitcher_tB58FC84AB9BA3F1467B4702F7C9FCD6944D054D1::get_offset_of_multiplexer_4(),
	DemoMultiplexSwitcher_tB58FC84AB9BA3F1467B4702F7C9FCD6944D054D1::get_offset_of_swapDisplays_5(),
	DemoMultiplexSwitcher_tB58FC84AB9BA3F1467B4702F7C9FCD6944D054D1::get_offset_of_lastToggleState_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3512 = { sizeof (DemoProWorkstationIPC_t7095278B75809BC2A85FA4071C414BBF25157B87), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3512[2] = 
{
	DemoProWorkstationIPC_t7095278B75809BC2A85FA4071C414BBF25157B87::get_offset_of_cubeTransform_7(),
	DemoProWorkstationIPC_t7095278B75809BC2A85FA4071C414BBF25157B87::get_offset_of_rotationText_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3513 = { sizeof (DemoQuiltToggle_tAF5F8ACF1353E89B717ED4A7E0EF5C6E7D619935), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3513[4] = 
{
	DemoQuiltToggle_tAF5F8ACF1353E89B717ED4A7E0EF5C6E7D619935::get_offset_of_holoplay_4(),
	DemoQuiltToggle_tAF5F8ACF1353E89B717ED4A7E0EF5C6E7D619935::get_offset_of_quiltToOverrideWith_5(),
	DemoQuiltToggle_tAF5F8ACF1353E89B717ED4A7E0EF5C6E7D619935::get_offset_of_whatToShow_6(),
	DemoQuiltToggle_tAF5F8ACF1353E89B717ED4A7E0EF5C6E7D619935::get_offset_of_lastFrame_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3514 = { sizeof (WhatToShow_tDB67EDA2591419EEE6AB54DC0713AD548BD8CD39)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3514[4] = 
{
	WhatToShow_tDB67EDA2591419EEE6AB54DC0713AD548BD8CD39::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3515 = { sizeof (DisplayNameAttribute_tFC24645A823EED0DE46DF51BCAFC54E78080B0CD), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3515[1] = 
{
	DisplayNameAttribute_tFC24645A823EED0DE46DF51BCAFC54E78080B0CD::get_offset_of_displayName_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3516 = { sizeof (MaxAttribute_t286062821EC77935B79E0412828BC70BAA854CB1), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3516[1] = 
{
	MaxAttribute_t286062821EC77935B79E0412828BC70BAA854CB1::get_offset_of_max_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3517 = { sizeof (MinAttribute_t31D810015C891DCB1E4CDCF4F5F150A80B341A56), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3517[1] = 
{
	MinAttribute_t31D810015C891DCB1E4CDCF4F5F150A80B341A56::get_offset_of_min_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3518 = { sizeof (MinMaxAttribute_t1B75CAA0E8D21C67E1325ED64644644ECBD2383E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3518[2] = 
{
	MinMaxAttribute_t1B75CAA0E8D21C67E1325ED64644644ECBD2383E::get_offset_of_min_0(),
	MinMaxAttribute_t1B75CAA0E8D21C67E1325ED64644644ECBD2383E::get_offset_of_max_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3519 = { sizeof (PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3519[5] = 
{
	PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54::get_offset_of_renderer_0(),
	PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54::get_offset_of_eventType_1(),
	PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54::get_offset_of_menuItem_2(),
	PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54::get_offset_of_allowInSceneView_3(),
	PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54::get_offset_of_builtinEffect_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3520 = { sizeof (TrackballAttribute_t8D831ADAC589D7DAA910878C85236E7C53A9FE33), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3520[1] = 
{
	TrackballAttribute_t8D831ADAC589D7DAA910878C85236E7C53A9FE33::get_offset_of_mode_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3521 = { sizeof (Mode_t9A2CFAD08E18EF76BAA8714445F27F45F8F601ED)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3521[5] = 
{
	Mode_t9A2CFAD08E18EF76BAA8714445F27F45F8F601ED::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3522 = { sizeof (AmbientOcclusionMode_tBAA58AC8FBA3590D5188DCFD19449343CCDF6CA7)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3522[3] = 
{
	AmbientOcclusionMode_tBAA58AC8FBA3590D5188DCFD19449343CCDF6CA7::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3523 = { sizeof (AmbientOcclusionQuality_tB54DB359F384B4A00DFD26DCA99C2BD9CABB9B6B)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3523[6] = 
{
	AmbientOcclusionQuality_tB54DB359F384B4A00DFD26DCA99C2BD9CABB9B6B::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3524 = { sizeof (AmbientOcclusionModeParameter_t79A104721D47E98613437F7F1A355695C397DDEF), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3525 = { sizeof (AmbientOcclusionQualityParameter_tE18805DEFF6A5466E44B02E6D820336B9EA0E2FD), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3526 = { sizeof (AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3526[11] = 
{
	AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88::get_offset_of_mode_7(),
	AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88::get_offset_of_intensity_8(),
	AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88::get_offset_of_color_9(),
	AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88::get_offset_of_ambientOnly_10(),
	AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88::get_offset_of_noiseFilterTolerance_11(),
	AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88::get_offset_of_blurTolerance_12(),
	AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88::get_offset_of_upsampleTolerance_13(),
	AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88::get_offset_of_thicknessModifier_14(),
	AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88::get_offset_of_directLightingStrength_15(),
	AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88::get_offset_of_radius_16(),
	AmbientOcclusion_tFDCFB4EE09E8B263719F8CF50EC91915D78B1A88::get_offset_of_quality_17(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3527 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3528 = { sizeof (AmbientOcclusionRenderer_t530B3D3BA9E89BD4E2D39A987F6BF2D06FF5E948), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3528[1] = 
{
	AmbientOcclusionRenderer_t530B3D3BA9E89BD4E2D39A987F6BF2D06FF5E948::get_offset_of_m_Methods_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3529 = { sizeof (EyeAdaptation_t933C17351A512F83920EFA56D30DB2B3CD474793)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3529[3] = 
{
	EyeAdaptation_t933C17351A512F83920EFA56D30DB2B3CD474793::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3530 = { sizeof (EyeAdaptationParameter_t7AC22D9A78944F2CA208B5E2FDB40BD76B1C0B70), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3531 = { sizeof (AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3531[7] = 
{
	AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C::get_offset_of_filtering_7(),
	AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C::get_offset_of_minLuminance_8(),
	AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C::get_offset_of_maxLuminance_9(),
	AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C::get_offset_of_keyValue_10(),
	AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C::get_offset_of_eyeAdaptation_11(),
	AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C::get_offset_of_speedUp_12(),
	AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C::get_offset_of_speedDown_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3532 = { sizeof (AutoExposureRenderer_t76625B37271B0D13CEA54C8E4C35540F4F7CBC6B), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3532[5] = 
{
	0,
	0,
	AutoExposureRenderer_t76625B37271B0D13CEA54C8E4C35540F4F7CBC6B::get_offset_of_m_AutoExposurePool_4(),
	AutoExposureRenderer_t76625B37271B0D13CEA54C8E4C35540F4F7CBC6B::get_offset_of_m_AutoExposurePingPong_5(),
	AutoExposureRenderer_t76625B37271B0D13CEA54C8E4C35540F4F7CBC6B::get_offset_of_m_CurrentAutoExposure_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3533 = { sizeof (Bloom_t366FA2D84798539D570B23E02789925E1079B3DD), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3533[10] = 
{
	Bloom_t366FA2D84798539D570B23E02789925E1079B3DD::get_offset_of_intensity_7(),
	Bloom_t366FA2D84798539D570B23E02789925E1079B3DD::get_offset_of_threshold_8(),
	Bloom_t366FA2D84798539D570B23E02789925E1079B3DD::get_offset_of_softKnee_9(),
	Bloom_t366FA2D84798539D570B23E02789925E1079B3DD::get_offset_of_clamp_10(),
	Bloom_t366FA2D84798539D570B23E02789925E1079B3DD::get_offset_of_diffusion_11(),
	Bloom_t366FA2D84798539D570B23E02789925E1079B3DD::get_offset_of_anamorphicRatio_12(),
	Bloom_t366FA2D84798539D570B23E02789925E1079B3DD::get_offset_of_color_13(),
	Bloom_t366FA2D84798539D570B23E02789925E1079B3DD::get_offset_of_fastMode_14(),
	Bloom_t366FA2D84798539D570B23E02789925E1079B3DD::get_offset_of_dirtTexture_15(),
	Bloom_t366FA2D84798539D570B23E02789925E1079B3DD::get_offset_of_dirtIntensity_16(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3534 = { sizeof (BloomRenderer_tBC3F0FE4E43AD0A3E8552E923D239A8514A31FE9), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3534[2] = 
{
	BloomRenderer_tBC3F0FE4E43AD0A3E8552E923D239A8514A31FE9::get_offset_of_m_Pyramid_2(),
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3535 = { sizeof (Pass_tE2091DA72BF7C28286D2262969C7370D682E9C83)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3535[10] = 
{
	Pass_tE2091DA72BF7C28286D2262969C7370D682E9C83::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3536 = { sizeof (Level_tE2980211EF4547353F9E222FF0F8C8DC9B7D18BC)+ sizeof (RuntimeObject), sizeof(Level_tE2980211EF4547353F9E222FF0F8C8DC9B7D18BC ), 0, 0 };
extern const int32_t g_FieldOffsetTable3536[2] = 
{
	Level_tE2980211EF4547353F9E222FF0F8C8DC9B7D18BC::get_offset_of_down_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Level_tE2980211EF4547353F9E222FF0F8C8DC9B7D18BC::get_offset_of_up_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3537 = { sizeof (ChromaticAberration_t78EC7F7C23F37A371DD46BB3F1631FEFF046400F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3537[3] = 
{
	ChromaticAberration_t78EC7F7C23F37A371DD46BB3F1631FEFF046400F::get_offset_of_spectralLut_7(),
	ChromaticAberration_t78EC7F7C23F37A371DD46BB3F1631FEFF046400F::get_offset_of_intensity_8(),
	ChromaticAberration_t78EC7F7C23F37A371DD46BB3F1631FEFF046400F::get_offset_of_fastMode_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3538 = { sizeof (ChromaticAberrationRenderer_tD640E75AAD5381FDB96653920F4270F3D1FB13A4), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3538[1] = 
{
	ChromaticAberrationRenderer_tD640E75AAD5381FDB96653920F4270F3D1FB13A4::get_offset_of_m_InternalSpectralLut_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3539 = { sizeof (GradingMode_t26234A50CAEB0E6E2A69683474CA2052461265C9)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3539[4] = 
{
	GradingMode_t26234A50CAEB0E6E2A69683474CA2052461265C9::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3540 = { sizeof (Tonemapper_tADC047088F116B3047D90BB3CFCB022E09F2EFC8)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3540[5] = 
{
	Tonemapper_tADC047088F116B3047D90BB3CFCB022E09F2EFC8::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3541 = { sizeof (GradingModeParameter_t30B66E571092CDA4D03618D02C0D71D84A7D9FA7), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3542 = { sizeof (TonemapperParameter_tAE067595EA8479188AA91EC38AD4BBA34CF2DA3B), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3543 = { sizeof (ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3543[39] = 
{
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_gradingMode_7(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_externalLut_8(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_tonemapper_9(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_toneCurveToeStrength_10(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_toneCurveToeLength_11(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_toneCurveShoulderStrength_12(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_toneCurveShoulderLength_13(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_toneCurveShoulderAngle_14(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_toneCurveGamma_15(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_ldrLut_16(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_ldrLutContribution_17(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_temperature_18(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_tint_19(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_colorFilter_20(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_hueShift_21(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_saturation_22(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_brightness_23(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_postExposure_24(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_contrast_25(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_mixerRedOutRedIn_26(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_mixerRedOutGreenIn_27(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_mixerRedOutBlueIn_28(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_mixerGreenOutRedIn_29(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_mixerGreenOutGreenIn_30(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_mixerGreenOutBlueIn_31(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_mixerBlueOutRedIn_32(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_mixerBlueOutGreenIn_33(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_mixerBlueOutBlueIn_34(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_lift_35(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_gamma_36(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_gain_37(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_masterCurve_38(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_redCurve_39(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_greenCurve_40(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_blueCurve_41(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_hueVsHueCurve_42(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_hueVsSatCurve_43(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_satVsSatCurve_44(),
	ColorGrading_t803342E88EC2C759690B13CC2F97DE2430120206::get_offset_of_lumVsSatCurve_45(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3544 = { sizeof (ColorGradingRenderer_t5FCD2E275CDA37CB4EF2596896191C5E52DF0D0D), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3544[7] = 
{
	ColorGradingRenderer_t5FCD2E275CDA37CB4EF2596896191C5E52DF0D0D::get_offset_of_m_GradingCurves_2(),
	ColorGradingRenderer_t5FCD2E275CDA37CB4EF2596896191C5E52DF0D0D::get_offset_of_m_Pixels_3(),
	ColorGradingRenderer_t5FCD2E275CDA37CB4EF2596896191C5E52DF0D0D::get_offset_of_m_InternalLdrLut_4(),
	ColorGradingRenderer_t5FCD2E275CDA37CB4EF2596896191C5E52DF0D0D::get_offset_of_m_InternalLogLut_5(),
	0,
	0,
	ColorGradingRenderer_t5FCD2E275CDA37CB4EF2596896191C5E52DF0D0D::get_offset_of_m_HableCurve_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3545 = { sizeof (Pass_t7529527D523DA94869CE9CF13B00549DBAB898E5)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3545[4] = 
{
	Pass_t7529527D523DA94869CE9CF13B00549DBAB898E5::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3546 = { sizeof (KernelSize_t4924DA4E775CBA62B19F6E8482147AA9716A2E2C)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3546[5] = 
{
	KernelSize_t4924DA4E775CBA62B19F6E8482147AA9716A2E2C::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3547 = { sizeof (KernelSizeParameter_t1290513B86C15182AD770816459A5398322F6642), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3548 = { sizeof (DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3548[6] = 
{
	DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88::get_offset_of_holoplayDrivenFocus_7(),
	DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88::get_offset_of_holoplayIntensity_8(),
	DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88::get_offset_of_focusDistance_9(),
	DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88::get_offset_of_aperture_10(),
	DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88::get_offset_of_focalLength_11(),
	DepthOfField_t153113647F5C0209F97AA72B1C0FF6CC7A9E5F88::get_offset_of_kernelSize_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3549 = { sizeof (DepthOfFieldRenderer_tB1D8D006ED9B295629DFEC92124C404AE2CD31EE), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3549[5] = 
{
	0,
	0,
	DepthOfFieldRenderer_tB1D8D006ED9B295629DFEC92124C404AE2CD31EE::get_offset_of_m_CoCHistoryTextures_4(),
	DepthOfFieldRenderer_tB1D8D006ED9B295629DFEC92124C404AE2CD31EE::get_offset_of_m_HistoryPingPong_5(),
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3550 = { sizeof (Pass_t58D979E9324109771CB3BD763C13E631ABA84032)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3550[11] = 
{
	Pass_t58D979E9324109771CB3BD763C13E631ABA84032::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3551 = { sizeof (Dithering_t742ED682E1E94CAE24122F5E89ED166A97DCB547), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3551[2] = 
{
	Dithering_t742ED682E1E94CAE24122F5E89ED166A97DCB547::get_offset_of_m_NoiseTextureIndex_0(),
	Dithering_t742ED682E1E94CAE24122F5E89ED166A97DCB547::get_offset_of_m_Random_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3552 = { sizeof (FastApproximateAntialiasing_tDE38094B4113793694F81B6D782FA1D6F36768CD), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3552[2] = 
{
	FastApproximateAntialiasing_tDE38094B4113793694F81B6D782FA1D6F36768CD::get_offset_of_fastMode_0(),
	FastApproximateAntialiasing_tDE38094B4113793694F81B6D782FA1D6F36768CD::get_offset_of_keepAlpha_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3553 = { sizeof (Fog_tBCD51987A95009EBAB4ED7B98933E1B5A0A00196), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3553[2] = 
{
	Fog_tBCD51987A95009EBAB4ED7B98933E1B5A0A00196::get_offset_of_enabled_0(),
	Fog_tBCD51987A95009EBAB4ED7B98933E1B5A0A00196::get_offset_of_excludeSkybox_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3554 = { sizeof (Grain_t0ECCE83708F627DD09B42C375C38AC7387407A66), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3554[4] = 
{
	Grain_t0ECCE83708F627DD09B42C375C38AC7387407A66::get_offset_of_colored_7(),
	Grain_t0ECCE83708F627DD09B42C375C38AC7387407A66::get_offset_of_intensity_8(),
	Grain_t0ECCE83708F627DD09B42C375C38AC7387407A66::get_offset_of_size_9(),
	Grain_t0ECCE83708F627DD09B42C375C38AC7387407A66::get_offset_of_lumContrib_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3555 = { sizeof (GrainRenderer_tD2C170FF4FAEAEBAF2835B13F8E16F3A22547EF6), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3555[3] = 
{
	GrainRenderer_tD2C170FF4FAEAEBAF2835B13F8E16F3A22547EF6::get_offset_of_m_GrainLookupRT_2(),
	0,
	GrainRenderer_tD2C170FF4FAEAEBAF2835B13F8E16F3A22547EF6::get_offset_of_m_SampleIndex_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3556 = { sizeof (LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3556[6] = 
{
	LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB::get_offset_of_intensity_7(),
	LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB::get_offset_of_intensityX_8(),
	LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB::get_offset_of_intensityY_9(),
	LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB::get_offset_of_centerX_10(),
	LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB::get_offset_of_centerY_11(),
	LensDistortion_tE1D636EFC5BE460C031CB06010B2E5253FBDBDBB::get_offset_of_scale_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3557 = { sizeof (LensDistortionRenderer_t8B185A86C3562080F78F8C39179894AC0B8D633D), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3558 = { sizeof (MotionBlur_tC78F5B6F7B956D0BF4AE2E40BB2917C4FDB95D63), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3558[2] = 
{
	MotionBlur_tC78F5B6F7B956D0BF4AE2E40BB2917C4FDB95D63::get_offset_of_shutterAngle_7(),
	MotionBlur_tC78F5B6F7B956D0BF4AE2E40BB2917C4FDB95D63::get_offset_of_sampleCount_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3559 = { sizeof (MotionBlurRenderer_t52EBEFE0D8A92188ADC2AEA259E96017D06334C3), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3560 = { sizeof (Pass_tDA1E60CC2E7998A18F47C250C046B72ECC1ECCFA)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3560[7] = 
{
	Pass_tDA1E60CC2E7998A18F47C250C046B72ECC1ECCFA::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3561 = { sizeof (MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3561[10] = 
{
	MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44::get_offset_of_m_SampleThickness_0(),
	MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44::get_offset_of_m_InvThicknessTable_1(),
	MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44::get_offset_of_m_SampleWeightTable_2(),
	MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44::get_offset_of_m_Widths_3(),
	MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44::get_offset_of_m_Heights_4(),
	MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44::get_offset_of_m_Settings_5(),
	MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44::get_offset_of_m_PropertySheet_6(),
	MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44::get_offset_of_m_Resources_7(),
	MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44::get_offset_of_m_AmbientOnlyAO_8(),
	MultiScaleVO_t72BE3B27E520D5E61AD22146EBA6AF504013DF44::get_offset_of_m_MRT_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3562 = { sizeof (MipLevel_t734F1C34D089FFDC34DCB9DD7C7AE04BD9BBFDCF)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3562[8] = 
{
	MipLevel_t734F1C34D089FFDC34DCB9DD7C7AE04BD9BBFDCF::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3563 = { sizeof (Pass_t38D6CABA9D11CA7A8E6AD93707DCC32D86530638)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3563[5] = 
{
	Pass_t38D6CABA9D11CA7A8E6AD93707DCC32D86530638::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3564 = { sizeof (ScalableAO_t80A96F6B497216939B5D65393ABFF12B70F26A4B), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3564[5] = 
{
	ScalableAO_t80A96F6B497216939B5D65393ABFF12B70F26A4B::get_offset_of_m_Result_0(),
	ScalableAO_t80A96F6B497216939B5D65393ABFF12B70F26A4B::get_offset_of_m_PropertySheet_1(),
	ScalableAO_t80A96F6B497216939B5D65393ABFF12B70F26A4B::get_offset_of_m_Settings_2(),
	ScalableAO_t80A96F6B497216939B5D65393ABFF12B70F26A4B::get_offset_of_m_MRT_3(),
	ScalableAO_t80A96F6B497216939B5D65393ABFF12B70F26A4B::get_offset_of_m_SampleCount_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3565 = { sizeof (Pass_tE70B7AA76B7B31510FE879A49B695B5E845737F3)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3565[9] = 
{
	Pass_tE70B7AA76B7B31510FE879A49B695B5E845737F3::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3566 = { sizeof (ScreenSpaceReflectionPreset_t08B6AB6E6AA127256D37FEC1C16A890A17661F6C)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3566[9] = 
{
	ScreenSpaceReflectionPreset_t08B6AB6E6AA127256D37FEC1C16A890A17661F6C::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3567 = { sizeof (ScreenSpaceReflectionResolution_tE69E1FAD4252F2175F2B4C59C8C82F6EDA429164)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3567[4] = 
{
	ScreenSpaceReflectionResolution_tE69E1FAD4252F2175F2B4C59C8C82F6EDA429164::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3568 = { sizeof (ScreenSpaceReflectionPresetParameter_t268DBDBDBA87C22733B30A3E3587B328E7F834E4), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3569 = { sizeof (ScreenSpaceReflectionResolutionParameter_tC897149ADF64CB366527300D8A12FE2E5AE8B943), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3570 = { sizeof (ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3570[7] = 
{
	ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5::get_offset_of_preset_7(),
	ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5::get_offset_of_maximumIterationCount_8(),
	ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5::get_offset_of_resolution_9(),
	ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5::get_offset_of_thickness_10(),
	ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5::get_offset_of_maximumMarchDistance_11(),
	ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5::get_offset_of_distanceFade_12(),
	ScreenSpaceReflections_tB82C51923CF234866D929319097853E840F53BE5::get_offset_of_vignette_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3571 = { sizeof (ScreenSpaceReflectionsRenderer_tC2E6E485E1A1967D6C8641AF66376BD42CA6E79F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3571[4] = 
{
	ScreenSpaceReflectionsRenderer_tC2E6E485E1A1967D6C8641AF66376BD42CA6E79F::get_offset_of_m_Resolve_2(),
	ScreenSpaceReflectionsRenderer_tC2E6E485E1A1967D6C8641AF66376BD42CA6E79F::get_offset_of_m_History_3(),
	ScreenSpaceReflectionsRenderer_tC2E6E485E1A1967D6C8641AF66376BD42CA6E79F::get_offset_of_m_MipIDs_4(),
	ScreenSpaceReflectionsRenderer_tC2E6E485E1A1967D6C8641AF66376BD42CA6E79F::get_offset_of_m_Presets_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3572 = { sizeof (QualityPreset_tD633200BBFFD7F29AC915A1D5FA1D361BC15AA17), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3572[3] = 
{
	QualityPreset_tD633200BBFFD7F29AC915A1D5FA1D361BC15AA17::get_offset_of_maximumIterationCount_0(),
	QualityPreset_tD633200BBFFD7F29AC915A1D5FA1D361BC15AA17::get_offset_of_thickness_1(),
	QualityPreset_tD633200BBFFD7F29AC915A1D5FA1D361BC15AA17::get_offset_of_downsampling_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3573 = { sizeof (Pass_t5719EC3281C9B370C5054228F003B08CEA69CCA6)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3573[5] = 
{
	Pass_t5719EC3281C9B370C5054228F003B08CEA69CCA6::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3574 = { sizeof (SubpixelMorphologicalAntialiasing_t79DFA0E989BC5D03E07D5A9E5DFC9E7170B0CB3A), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3574[1] = 
{
	SubpixelMorphologicalAntialiasing_t79DFA0E989BC5D03E07D5A9E5DFC9E7170B0CB3A::get_offset_of_quality_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3575 = { sizeof (Pass_tE189D8DA92AFBBD1C9D9A495E15885B842FB80AA)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3575[4] = 
{
	Pass_tE189D8DA92AFBBD1C9D9A495E15885B842FB80AA::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3576 = { sizeof (Quality_t47754692CA99716F6403286C22B367747A7F3C4D)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3576[4] = 
{
	Quality_t47754692CA99716F6403286C22B367747A7F3C4D::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3577 = { sizeof (TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3577[14] = 
{
	TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B::get_offset_of_jitterSpread_0(),
	TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B::get_offset_of_sharpness_1(),
	TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B::get_offset_of_stationaryBlending_2(),
	TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B::get_offset_of_motionBlending_3(),
	TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B::get_offset_of_jitteredMatrixFunc_4(),
	TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B::get_offset_of_U3CjitterU3Ek__BackingField_5(),
	TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B::get_offset_of_m_Mrt_6(),
	TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B::get_offset_of_m_ResetHistory_7(),
	0,
	TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B::get_offset_of_U3CsampleIndexU3Ek__BackingField_9(),
	0,
	0,
	TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B::get_offset_of_m_HistoryTextures_12(),
	TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B::get_offset_of_m_HistoryPingPong_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3578 = { sizeof (Pass_t283EA1DF1922B3E29857B5F4D7A7EC89A432EB4F)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3578[3] = 
{
	Pass_t283EA1DF1922B3E29857B5F4D7A7EC89A432EB4F::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3579 = { sizeof (VignetteMode_tC4E66BF0248EBE1B64A87D2ECE33BC5081CE5809)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3579[3] = 
{
	VignetteMode_tC4E66BF0248EBE1B64A87D2ECE33BC5081CE5809::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3580 = { sizeof (VignetteModeParameter_t0853E96B549BCF8765CE8FEB6B50EB78706645A6), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3581 = { sizeof (Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3581[9] = 
{
	Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E::get_offset_of_mode_7(),
	Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E::get_offset_of_color_8(),
	Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E::get_offset_of_center_9(),
	Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E::get_offset_of_intensity_10(),
	Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E::get_offset_of_smoothness_11(),
	Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E::get_offset_of_roundness_12(),
	Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E::get_offset_of_rounded_13(),
	Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E::get_offset_of_mask_14(),
	Vignette_t46590867E1C0E87B27698ADF0C5FEA776535002E::get_offset_of_opacity_15(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3582 = { sizeof (VignetteRenderer_t601587477A5F76F63577992A1C9317ADB07697DE), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3583 = { sizeof (HistogramMonitor_t682E9ACE9C9874B0230608D0A1C1382307907D87), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3583[7] = 
{
	HistogramMonitor_t682E9ACE9C9874B0230608D0A1C1382307907D87::get_offset_of_width_2(),
	HistogramMonitor_t682E9ACE9C9874B0230608D0A1C1382307907D87::get_offset_of_height_3(),
	HistogramMonitor_t682E9ACE9C9874B0230608D0A1C1382307907D87::get_offset_of_channel_4(),
	HistogramMonitor_t682E9ACE9C9874B0230608D0A1C1382307907D87::get_offset_of_m_Data_5(),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3584 = { sizeof (Channel_t83BA5F9DFDAD22C6DF638E04B10B63CBDDBE4A39)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3584[5] = 
{
	Channel_t83BA5F9DFDAD22C6DF638E04B10B63CBDDBE4A39::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3585 = { sizeof (LightMeterMonitor_t103A765AA459E486B43DFDD70451D3692977A684), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3585[3] = 
{
	LightMeterMonitor_t103A765AA459E486B43DFDD70451D3692977A684::get_offset_of_width_2(),
	LightMeterMonitor_t103A765AA459E486B43DFDD70451D3692977A684::get_offset_of_height_3(),
	LightMeterMonitor_t103A765AA459E486B43DFDD70451D3692977A684::get_offset_of_showCurves_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3586 = { sizeof (MonitorType_tD794EA77396E262DC8289139BA16B0FBC3768330)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3586[5] = 
{
	MonitorType_tD794EA77396E262DC8289139BA16B0FBC3768330::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3587 = { sizeof (Monitor_tE317BECFE50FD51B2BBC2609C33E6ABE76A6338E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3587[2] = 
{
	Monitor_tE317BECFE50FD51B2BBC2609C33E6ABE76A6338E::get_offset_of_U3CoutputU3Ek__BackingField_0(),
	Monitor_tE317BECFE50FD51B2BBC2609C33E6ABE76A6338E::get_offset_of_requested_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3588 = { sizeof (VectorscopeMonitor_tC3774A687F71D73031BC417A080D6C6BC9C519EA), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3588[5] = 
{
	VectorscopeMonitor_tC3774A687F71D73031BC417A080D6C6BC9C519EA::get_offset_of_size_2(),
	VectorscopeMonitor_tC3774A687F71D73031BC417A080D6C6BC9C519EA::get_offset_of_exposure_3(),
	VectorscopeMonitor_tC3774A687F71D73031BC417A080D6C6BC9C519EA::get_offset_of_m_Data_4(),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3589 = { sizeof (WaveformMonitor_tFB0CBA9B59F081E6C36547430F4E417133968CA8), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3589[6] = 
{
	WaveformMonitor_tFB0CBA9B59F081E6C36547430F4E417133968CA8::get_offset_of_exposure_2(),
	WaveformMonitor_tFB0CBA9B59F081E6C36547430F4E417133968CA8::get_offset_of_height_3(),
	WaveformMonitor_tFB0CBA9B59F081E6C36547430F4E417133968CA8::get_offset_of_m_Data_4(),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3590 = { sizeof (ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3590[1] = 
{
	ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F::get_offset_of_overrideState_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3591 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable3591[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3592 = { sizeof (FloatParameter_t9009F81EB449255B9AE9F90F007F91F343437703), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3593 = { sizeof (IntParameter_tF314047E8059BF20F34E4202ACA31C6EAF8D7390), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3594 = { sizeof (BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3595 = { sizeof (ColorParameter_tC6DED9B62CC1066E49029ECB8152FBE78DC05D85), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3596 = { sizeof (Vector2Parameter_t2138DCE95841B6A479E95D93280273119FCB0686), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3597 = { sizeof (Vector3Parameter_tA5890D7B9F137A9F6400D41814891154F7FA26D2), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3598 = { sizeof (Vector4Parameter_t71A23EBB58A01E0FF756B1D104B8DE37F772E2F1), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3599 = { sizeof (SplineParameter_t70C9BA684726F930046ADF7D5509E44F0E8F860F), -1, 0, 0 };
#ifdef __clang__
#pragma clang diagnostic pop
#endif
