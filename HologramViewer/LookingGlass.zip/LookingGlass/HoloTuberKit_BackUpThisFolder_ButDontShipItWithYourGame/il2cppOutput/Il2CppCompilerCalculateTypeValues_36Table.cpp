﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "il2cpp-class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"


// System.Char[]
struct CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2;
// System.Collections.Generic.Dictionary`2<System.Int32,System.Boolean>
struct Dictionary_2_t2258334B2FD1F225C68C5C4869898F9DF49998FB;
// System.Collections.Generic.Dictionary`2<System.Int32,System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessVolume>>
struct Dictionary_2_tED9592904E54FB90363D1C8E916DB04AEF6AC85D;
// System.Collections.Generic.Dictionary`2<System.Int32,UnityEngine.RenderTextureFormat>
struct Dictionary_2_tA708463063DFE4270DCCBFFEFBB60592CA2C5EEB;
// System.Collections.Generic.Dictionary`2<System.Int32,UnityEngine.Texture2D>
struct Dictionary_2_t131B71940600DB8DE4DADE6242CE6287DEB55A04;
// System.Collections.Generic.Dictionary`2<System.String,System.Object>
struct Dictionary_2_t9140A71329927AE4FD0F3CF4D4D66668EBE151EA;
// System.Collections.Generic.Dictionary`2<System.Type,UnityEngine.PrimitiveType>
struct Dictionary_2_tA5AF75D98C83F4AC1B1B6DD242E24740B5FFB2D7;
// System.Collections.Generic.Dictionary`2<System.Type,UnityEngine.Rendering.PostProcessing.PostProcessAttribute>
struct Dictionary_2_t0EDE3B40268AF2A908B7F215F87FE5683E7635B4;
// System.Collections.Generic.Dictionary`2<System.Type,UnityEngine.Rendering.PostProcessing.PostProcessBundle>
struct Dictionary_2_t68B279040CF6AAD367F60332F7BF6E5D55E2CE4D;
// System.Collections.Generic.Dictionary`2<UnityEngine.PrimitiveType,UnityEngine.Mesh>
struct Dictionary_2_tAAA2EDB4169295147B06EBA53CB396AB1892A1FC;
// System.Collections.Generic.Dictionary`2<UnityEngine.Rendering.PostProcessing.MonitorType,UnityEngine.Rendering.PostProcessing.Monitor>
struct Dictionary_2_tCA20F7F0C3B4446646E7C8E9AD388569634F963F;
// System.Collections.Generic.Dictionary`2<UnityEngine.Rendering.PostProcessing.PostProcessEvent,System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessLayer/SerializedBundleRef>>
struct Dictionary_2_t735D27E8C6C69460DB345B1E0430D9E7DC2027EE;
// System.Collections.Generic.Dictionary`2<UnityEngine.Shader,UnityEngine.Rendering.PostProcessing.PropertySheet>
struct Dictionary_2_t3B983DCBB826C3BCDD4CB9A885C115474EC7FACA;
// System.Collections.Generic.IEnumerable`1<System.Type>
struct IEnumerable_1_tF9225691990EF9799D9F4B64E4063CA0D1DF03CA;
// System.Collections.Generic.List`1<System.Int32>
struct List_1_tE1526161A558A17A39A8B69D8EEF3801393B6226;
// System.Collections.Generic.List`1<UnityEngine.Collider>
struct List_1_t88DF1A02CCDD1766DB310B8D72B1F2145D775432;
// System.Collections.Generic.List`1<UnityEngine.RenderTexture>
struct List_1_t38DC6F3924A2FB1303F0D1993418D258B3AB7F37;
// System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessBundle>
struct List_1_tE71CBA0FB123ABF538C109CB3D91034AC3638455;
// System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer>
struct List_1_t8C4F4E7CB77FE645C18D117A237E828F791B429C;
// System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings>
struct List_1_tC82B3FE12BB2B40AE4E4672E4302D78EB191BADC;
// System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessLayer/SerializedBundleRef>
struct List_1_tF416F8C7834DED71BB1CC8D74D1631D28ABC2A6B;
// System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessVolume>
struct List_1_tD3BC8DD5F7F747B9381C5279C6B3CCDEB921CE0F;
// System.Collections.Generic.List`1<UnityEngine.Rendering.RenderTargetIdentifier>
struct List_1_t1E97ED90DF19DF61851FF18897CC04F01185E918;
// System.Collections.ObjectModel.ReadOnlyCollection`1<UnityEngine.Rendering.PostProcessing.ParameterOverride>
struct ReadOnlyCollection_1_t09ED47FDFC3DF44855A0AECF526E54628E99D966;
// System.Func`2<System.Collections.Generic.KeyValuePair`2<System.Type,UnityEngine.Rendering.PostProcessing.PostProcessBundle>,UnityEngine.Rendering.PostProcessing.PostProcessBundle>
struct Func_2_t787140437793AD35F7E99517DB0FB2B94F4C7B7B;
// System.Func`2<System.Reflection.Assembly,System.Collections.Generic.IEnumerable`1<System.Type>>
struct Func_2_t1DB78001C40A03A303D41DD7A89698AFAC67B86D;
// System.Func`2<System.Reflection.FieldInfo,System.Boolean>
struct Func_2_tAEF6BFDF029DC25672CC4AAF7D3E000F583BDF5C;
// System.Func`2<System.Reflection.FieldInfo,System.Int32>
struct Func_2_t189EF4BEEE3256E5ECE9D578D095B8EAD00D467E;
// System.Func`2<System.Type,System.Boolean>
struct Func_2_tF531BD8DCA90022059CF63DD5140CEA803AC1091;
// System.Int32[]
struct Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83;
// System.Predicate`1<UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings>
struct Predicate_1_t600D4636D1F7216584932BF1CC7965FF5D254AD9;
// System.Single[]
struct SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5;
// System.String
struct String_t;
// System.Void
struct Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017;
// UnityEngine.AnimationCurve
struct AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C;
// UnityEngine.Camera
struct Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34;
// UnityEngine.ComputeBuffer
struct ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5;
// UnityEngine.ComputeShader
struct ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A;
// UnityEngine.Material
struct Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598;
// UnityEngine.MaterialPropertyBlock
struct MaterialPropertyBlock_t72A481768111C6F11DCDCD44F0C7F99F1CA79E13;
// UnityEngine.Mesh
struct Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C;
// UnityEngine.RenderTexture
struct RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6;
// UnityEngine.Rendering.CommandBuffer
struct CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD;
// UnityEngine.Rendering.PostProcessing.AutoExposure
struct AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C;
// UnityEngine.Rendering.PostProcessing.BoolParameter
struct BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32;
// UnityEngine.Rendering.PostProcessing.Dithering
struct Dithering_t742ED682E1E94CAE24122F5E89ED166A97DCB547;
// UnityEngine.Rendering.PostProcessing.FastApproximateAntialiasing
struct FastApproximateAntialiasing_tDE38094B4113793694F81B6D782FA1D6F36768CD;
// UnityEngine.Rendering.PostProcessing.Fog
struct Fog_tBCD51987A95009EBAB4ED7B98933E1B5A0A00196;
// UnityEngine.Rendering.PostProcessing.HableCurve
struct HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78;
// UnityEngine.Rendering.PostProcessing.HableCurve/Segment[]
struct SegmentU5BU5D_t014E61C36BB2590A9CE4AFC113EF1161A7E579FC;
// UnityEngine.Rendering.PostProcessing.HableCurve/Uniforms
struct Uniforms_t6CD449DACCAE348F7E606DBACF2481FA9BCDF2AF;
// UnityEngine.Rendering.PostProcessing.HistogramMonitor
struct HistogramMonitor_t682E9ACE9C9874B0230608D0A1C1382307907D87;
// UnityEngine.Rendering.PostProcessing.LightMeterMonitor
struct LightMeterMonitor_t103A765AA459E486B43DFDD70451D3692977A684;
// UnityEngine.Rendering.PostProcessing.LogHistogram
struct LogHistogram_t047FFE5627C5FCEF5FFB5DBCCAEC406DA7F07AB8;
// UnityEngine.Rendering.PostProcessing.PostProcessAttribute
struct PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54;
// UnityEngine.Rendering.PostProcessing.PostProcessBundle
struct PostProcessBundle_t73C3A7D8C55E7C976045DC08CF6FBD8F2AE3450F;
// UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer
struct PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75;
// UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer/OverlaySettings
struct OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12;
// UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer
struct PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C;
// UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings
struct PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E;
// UnityEngine.Rendering.PostProcessing.PostProcessLayer
struct PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08;
// UnityEngine.Rendering.PostProcessing.PostProcessProfile
struct PostProcessProfile_t8C94889A4E09E180663F26AB74D53B1E98D8C45F;
// UnityEngine.Rendering.PostProcessing.PostProcessRenderContext
struct PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18;
// UnityEngine.Rendering.PostProcessing.PostProcessResources
struct PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98;
// UnityEngine.Rendering.PostProcessing.PostProcessResources/ComputeShaders
struct ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2;
// UnityEngine.Rendering.PostProcessing.PostProcessResources/SMAALuts
struct SMAALuts_t4E0EB2F1BAD60C948B7153C88F485EE928445519;
// UnityEngine.Rendering.PostProcessing.PostProcessResources/Shaders
struct Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510;
// UnityEngine.Rendering.PostProcessing.PropertySheet
struct PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212;
// UnityEngine.Rendering.PostProcessing.PropertySheetFactory
struct PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68;
// UnityEngine.Rendering.PostProcessing.SubpixelMorphologicalAntialiasing
struct SubpixelMorphologicalAntialiasing_t79DFA0E989BC5D03E07D5A9E5DFC9E7170B0CB3A;
// UnityEngine.Rendering.PostProcessing.TargetPool
struct TargetPool_t284FB269C2EF33308F1CFC69124C115985AEA7E4;
// UnityEngine.Rendering.PostProcessing.TemporalAntialiasing
struct TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B;
// UnityEngine.Rendering.PostProcessing.VectorscopeMonitor
struct VectorscopeMonitor_tC3774A687F71D73031BC417A080D6C6BC9C519EA;
// UnityEngine.Rendering.PostProcessing.WaveformMonitor
struct WaveformMonitor_tFB0CBA9B59F081E6C36547430F4E417133968CA8;
// UnityEngine.Shader
struct Shader_tE2731FF351B74AB4186897484FB01E000C1160CA;
// UnityEngine.Texture
struct Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4;
// UnityEngine.Texture2D
struct Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C;
// UnityEngine.Texture2D[]
struct Texture2DU5BU5D_tCAC03055C735C020BAFC218D55183CF03E74C1C9;
// UnityEngine.Texture3D
struct Texture3D_t041D3C554E80910E92D1EAAA85E0F70655FD66B4;
// UnityEngine.Transform
struct Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA;




#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
#ifndef VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#define VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_com
{
};
#endif // VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#ifndef COLORUTILITIES_TF84C1711080D0558866FCCF002017078DBD20F8C_H
#define COLORUTILITIES_TF84C1711080D0558866FCCF002017078DBD20F8C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ColorUtilities
struct  ColorUtilities_tF84C1711080D0558866FCCF002017078DBD20F8C  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLORUTILITIES_TF84C1711080D0558866FCCF002017078DBD20F8C_H
#ifndef HABLECURVE_TB007C0ED54E49D4837CAE21029C1C6663461AC78_H
#define HABLECURVE_TB007C0ED54E49D4837CAE21029C1C6663461AC78_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.HableCurve
struct  HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78  : public RuntimeObject
{
public:
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve::<whitePoint>k__BackingField
	float ___U3CwhitePointU3Ek__BackingField_0;
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve::<inverseWhitePoint>k__BackingField
	float ___U3CinverseWhitePointU3Ek__BackingField_1;
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve::<x0>k__BackingField
	float ___U3Cx0U3Ek__BackingField_2;
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve::<x1>k__BackingField
	float ___U3Cx1U3Ek__BackingField_3;
	// UnityEngine.Rendering.PostProcessing.HableCurve_Segment[] UnityEngine.Rendering.PostProcessing.HableCurve::m_Segments
	SegmentU5BU5D_t014E61C36BB2590A9CE4AFC113EF1161A7E579FC* ___m_Segments_4;
	// UnityEngine.Rendering.PostProcessing.HableCurve_Uniforms UnityEngine.Rendering.PostProcessing.HableCurve::uniforms
	Uniforms_t6CD449DACCAE348F7E606DBACF2481FA9BCDF2AF * ___uniforms_5;

public:
	inline static int32_t get_offset_of_U3CwhitePointU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78, ___U3CwhitePointU3Ek__BackingField_0)); }
	inline float get_U3CwhitePointU3Ek__BackingField_0() const { return ___U3CwhitePointU3Ek__BackingField_0; }
	inline float* get_address_of_U3CwhitePointU3Ek__BackingField_0() { return &___U3CwhitePointU3Ek__BackingField_0; }
	inline void set_U3CwhitePointU3Ek__BackingField_0(float value)
	{
		___U3CwhitePointU3Ek__BackingField_0 = value;
	}

	inline static int32_t get_offset_of_U3CinverseWhitePointU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78, ___U3CinverseWhitePointU3Ek__BackingField_1)); }
	inline float get_U3CinverseWhitePointU3Ek__BackingField_1() const { return ___U3CinverseWhitePointU3Ek__BackingField_1; }
	inline float* get_address_of_U3CinverseWhitePointU3Ek__BackingField_1() { return &___U3CinverseWhitePointU3Ek__BackingField_1; }
	inline void set_U3CinverseWhitePointU3Ek__BackingField_1(float value)
	{
		___U3CinverseWhitePointU3Ek__BackingField_1 = value;
	}

	inline static int32_t get_offset_of_U3Cx0U3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78, ___U3Cx0U3Ek__BackingField_2)); }
	inline float get_U3Cx0U3Ek__BackingField_2() const { return ___U3Cx0U3Ek__BackingField_2; }
	inline float* get_address_of_U3Cx0U3Ek__BackingField_2() { return &___U3Cx0U3Ek__BackingField_2; }
	inline void set_U3Cx0U3Ek__BackingField_2(float value)
	{
		___U3Cx0U3Ek__BackingField_2 = value;
	}

	inline static int32_t get_offset_of_U3Cx1U3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78, ___U3Cx1U3Ek__BackingField_3)); }
	inline float get_U3Cx1U3Ek__BackingField_3() const { return ___U3Cx1U3Ek__BackingField_3; }
	inline float* get_address_of_U3Cx1U3Ek__BackingField_3() { return &___U3Cx1U3Ek__BackingField_3; }
	inline void set_U3Cx1U3Ek__BackingField_3(float value)
	{
		___U3Cx1U3Ek__BackingField_3 = value;
	}

	inline static int32_t get_offset_of_m_Segments_4() { return static_cast<int32_t>(offsetof(HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78, ___m_Segments_4)); }
	inline SegmentU5BU5D_t014E61C36BB2590A9CE4AFC113EF1161A7E579FC* get_m_Segments_4() const { return ___m_Segments_4; }
	inline SegmentU5BU5D_t014E61C36BB2590A9CE4AFC113EF1161A7E579FC** get_address_of_m_Segments_4() { return &___m_Segments_4; }
	inline void set_m_Segments_4(SegmentU5BU5D_t014E61C36BB2590A9CE4AFC113EF1161A7E579FC* value)
	{
		___m_Segments_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_Segments_4), value);
	}

	inline static int32_t get_offset_of_uniforms_5() { return static_cast<int32_t>(offsetof(HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78, ___uniforms_5)); }
	inline Uniforms_t6CD449DACCAE348F7E606DBACF2481FA9BCDF2AF * get_uniforms_5() const { return ___uniforms_5; }
	inline Uniforms_t6CD449DACCAE348F7E606DBACF2481FA9BCDF2AF ** get_address_of_uniforms_5() { return &___uniforms_5; }
	inline void set_uniforms_5(Uniforms_t6CD449DACCAE348F7E606DBACF2481FA9BCDF2AF * value)
	{
		___uniforms_5 = value;
		Il2CppCodeGenWriteBarrier((&___uniforms_5), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HABLECURVE_TB007C0ED54E49D4837CAE21029C1C6663461AC78_H
#ifndef SEGMENT_T1B591F583A7B52D1BC04C0669068E1D19E592065_H
#define SEGMENT_T1B591F583A7B52D1BC04C0669068E1D19E592065_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.HableCurve_Segment
struct  Segment_t1B591F583A7B52D1BC04C0669068E1D19E592065  : public RuntimeObject
{
public:
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve_Segment::offsetX
	float ___offsetX_0;
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve_Segment::offsetY
	float ___offsetY_1;
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve_Segment::scaleX
	float ___scaleX_2;
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve_Segment::scaleY
	float ___scaleY_3;
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve_Segment::lnA
	float ___lnA_4;
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve_Segment::B
	float ___B_5;

public:
	inline static int32_t get_offset_of_offsetX_0() { return static_cast<int32_t>(offsetof(Segment_t1B591F583A7B52D1BC04C0669068E1D19E592065, ___offsetX_0)); }
	inline float get_offsetX_0() const { return ___offsetX_0; }
	inline float* get_address_of_offsetX_0() { return &___offsetX_0; }
	inline void set_offsetX_0(float value)
	{
		___offsetX_0 = value;
	}

	inline static int32_t get_offset_of_offsetY_1() { return static_cast<int32_t>(offsetof(Segment_t1B591F583A7B52D1BC04C0669068E1D19E592065, ___offsetY_1)); }
	inline float get_offsetY_1() const { return ___offsetY_1; }
	inline float* get_address_of_offsetY_1() { return &___offsetY_1; }
	inline void set_offsetY_1(float value)
	{
		___offsetY_1 = value;
	}

	inline static int32_t get_offset_of_scaleX_2() { return static_cast<int32_t>(offsetof(Segment_t1B591F583A7B52D1BC04C0669068E1D19E592065, ___scaleX_2)); }
	inline float get_scaleX_2() const { return ___scaleX_2; }
	inline float* get_address_of_scaleX_2() { return &___scaleX_2; }
	inline void set_scaleX_2(float value)
	{
		___scaleX_2 = value;
	}

	inline static int32_t get_offset_of_scaleY_3() { return static_cast<int32_t>(offsetof(Segment_t1B591F583A7B52D1BC04C0669068E1D19E592065, ___scaleY_3)); }
	inline float get_scaleY_3() const { return ___scaleY_3; }
	inline float* get_address_of_scaleY_3() { return &___scaleY_3; }
	inline void set_scaleY_3(float value)
	{
		___scaleY_3 = value;
	}

	inline static int32_t get_offset_of_lnA_4() { return static_cast<int32_t>(offsetof(Segment_t1B591F583A7B52D1BC04C0669068E1D19E592065, ___lnA_4)); }
	inline float get_lnA_4() const { return ___lnA_4; }
	inline float* get_address_of_lnA_4() { return &___lnA_4; }
	inline void set_lnA_4(float value)
	{
		___lnA_4 = value;
	}

	inline static int32_t get_offset_of_B_5() { return static_cast<int32_t>(offsetof(Segment_t1B591F583A7B52D1BC04C0669068E1D19E592065, ___B_5)); }
	inline float get_B_5() const { return ___B_5; }
	inline float* get_address_of_B_5() { return &___B_5; }
	inline void set_B_5(float value)
	{
		___B_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SEGMENT_T1B591F583A7B52D1BC04C0669068E1D19E592065_H
#ifndef UNIFORMS_T6CD449DACCAE348F7E606DBACF2481FA9BCDF2AF_H
#define UNIFORMS_T6CD449DACCAE348F7E606DBACF2481FA9BCDF2AF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.HableCurve_Uniforms
struct  Uniforms_t6CD449DACCAE348F7E606DBACF2481FA9BCDF2AF  : public RuntimeObject
{
public:
	// UnityEngine.Rendering.PostProcessing.HableCurve UnityEngine.Rendering.PostProcessing.HableCurve_Uniforms::parent
	HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78 * ___parent_0;

public:
	inline static int32_t get_offset_of_parent_0() { return static_cast<int32_t>(offsetof(Uniforms_t6CD449DACCAE348F7E606DBACF2481FA9BCDF2AF, ___parent_0)); }
	inline HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78 * get_parent_0() const { return ___parent_0; }
	inline HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78 ** get_address_of_parent_0() { return &___parent_0; }
	inline void set_parent_0(HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78 * value)
	{
		___parent_0 = value;
		Il2CppCodeGenWriteBarrier((&___parent_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // UNIFORMS_T6CD449DACCAE348F7E606DBACF2481FA9BCDF2AF_H
#ifndef HALTONSEQ_TEC1E3058C08C10B5FA48B5084B2FCFA4135C7682_H
#define HALTONSEQ_TEC1E3058C08C10B5FA48B5084B2FCFA4135C7682_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.HaltonSeq
struct  HaltonSeq_tEC1E3058C08C10B5FA48B5084B2FCFA4135C7682  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // HALTONSEQ_TEC1E3058C08C10B5FA48B5084B2FCFA4135C7682_H
#ifndef LOGHISTOGRAM_T047FFE5627C5FCEF5FFB5DBCCAEC406DA7F07AB8_H
#define LOGHISTOGRAM_T047FFE5627C5FCEF5FFB5DBCCAEC406DA7F07AB8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.LogHistogram
struct  LogHistogram_t047FFE5627C5FCEF5FFB5DBCCAEC406DA7F07AB8  : public RuntimeObject
{
public:
	// UnityEngine.ComputeBuffer UnityEngine.Rendering.PostProcessing.LogHistogram::<data>k__BackingField
	ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5 * ___U3CdataU3Ek__BackingField_3;

public:
	inline static int32_t get_offset_of_U3CdataU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(LogHistogram_t047FFE5627C5FCEF5FFB5DBCCAEC406DA7F07AB8, ___U3CdataU3Ek__BackingField_3)); }
	inline ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5 * get_U3CdataU3Ek__BackingField_3() const { return ___U3CdataU3Ek__BackingField_3; }
	inline ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5 ** get_address_of_U3CdataU3Ek__BackingField_3() { return &___U3CdataU3Ek__BackingField_3; }
	inline void set_U3CdataU3Ek__BackingField_3(ComputeBuffer_t52D8926E1D54293AD28F4C29FE3F5363749B0FE5 * value)
	{
		___U3CdataU3Ek__BackingField_3 = value;
		Il2CppCodeGenWriteBarrier((&___U3CdataU3Ek__BackingField_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOGHISTOGRAM_T047FFE5627C5FCEF5FFB5DBCCAEC406DA7F07AB8_H
#ifndef MESHUTILITIES_T1789BBBAF048DEB18CBADF1446C7367C805C6127_H
#define MESHUTILITIES_T1789BBBAF048DEB18CBADF1446C7367C805C6127_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.MeshUtilities
struct  MeshUtilities_t1789BBBAF048DEB18CBADF1446C7367C805C6127  : public RuntimeObject
{
public:

public:
};

struct MeshUtilities_t1789BBBAF048DEB18CBADF1446C7367C805C6127_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2<UnityEngine.PrimitiveType,UnityEngine.Mesh> UnityEngine.Rendering.PostProcessing.MeshUtilities::s_Primitives
	Dictionary_2_tAAA2EDB4169295147B06EBA53CB396AB1892A1FC * ___s_Primitives_0;
	// System.Collections.Generic.Dictionary`2<System.Type,UnityEngine.PrimitiveType> UnityEngine.Rendering.PostProcessing.MeshUtilities::s_ColliderPrimitives
	Dictionary_2_tA5AF75D98C83F4AC1B1B6DD242E24740B5FFB2D7 * ___s_ColliderPrimitives_1;

public:
	inline static int32_t get_offset_of_s_Primitives_0() { return static_cast<int32_t>(offsetof(MeshUtilities_t1789BBBAF048DEB18CBADF1446C7367C805C6127_StaticFields, ___s_Primitives_0)); }
	inline Dictionary_2_tAAA2EDB4169295147B06EBA53CB396AB1892A1FC * get_s_Primitives_0() const { return ___s_Primitives_0; }
	inline Dictionary_2_tAAA2EDB4169295147B06EBA53CB396AB1892A1FC ** get_address_of_s_Primitives_0() { return &___s_Primitives_0; }
	inline void set_s_Primitives_0(Dictionary_2_tAAA2EDB4169295147B06EBA53CB396AB1892A1FC * value)
	{
		___s_Primitives_0 = value;
		Il2CppCodeGenWriteBarrier((&___s_Primitives_0), value);
	}

	inline static int32_t get_offset_of_s_ColliderPrimitives_1() { return static_cast<int32_t>(offsetof(MeshUtilities_t1789BBBAF048DEB18CBADF1446C7367C805C6127_StaticFields, ___s_ColliderPrimitives_1)); }
	inline Dictionary_2_tA5AF75D98C83F4AC1B1B6DD242E24740B5FFB2D7 * get_s_ColliderPrimitives_1() const { return ___s_ColliderPrimitives_1; }
	inline Dictionary_2_tA5AF75D98C83F4AC1B1B6DD242E24740B5FFB2D7 ** get_address_of_s_ColliderPrimitives_1() { return &___s_ColliderPrimitives_1; }
	inline void set_s_ColliderPrimitives_1(Dictionary_2_tA5AF75D98C83F4AC1B1B6DD242E24740B5FFB2D7 * value)
	{
		___s_ColliderPrimitives_1 = value;
		Il2CppCodeGenWriteBarrier((&___s_ColliderPrimitives_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MESHUTILITIES_T1789BBBAF048DEB18CBADF1446C7367C805C6127_H
#ifndef PARAMETEROVERRIDE_T33733D55B6D63C97BF769220036767852B4AFB5F_H
#define PARAMETEROVERRIDE_T33733D55B6D63C97BF769220036767852B4AFB5F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride
struct  ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F  : public RuntimeObject
{
public:
	// System.Boolean UnityEngine.Rendering.PostProcessing.ParameterOverride::overrideState
	bool ___overrideState_0;

public:
	inline static int32_t get_offset_of_overrideState_0() { return static_cast<int32_t>(offsetof(ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F, ___overrideState_0)); }
	inline bool get_overrideState_0() const { return ___overrideState_0; }
	inline bool* get_address_of_overrideState_0() { return &___overrideState_0; }
	inline void set_overrideState_0(bool value)
	{
		___overrideState_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_T33733D55B6D63C97BF769220036767852B4AFB5F_H
#ifndef POSTPROCESSBUNDLE_T73C3A7D8C55E7C976045DC08CF6FBD8F2AE3450F_H
#define POSTPROCESSBUNDLE_T73C3A7D8C55E7C976045DC08CF6FBD8F2AE3450F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessBundle
struct  PostProcessBundle_t73C3A7D8C55E7C976045DC08CF6FBD8F2AE3450F  : public RuntimeObject
{
public:
	// UnityEngine.Rendering.PostProcessing.PostProcessAttribute UnityEngine.Rendering.PostProcessing.PostProcessBundle::<attribute>k__BackingField
	PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54 * ___U3CattributeU3Ek__BackingField_0;
	// UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings UnityEngine.Rendering.PostProcessing.PostProcessBundle::<settings>k__BackingField
	PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E * ___U3CsettingsU3Ek__BackingField_1;
	// UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer UnityEngine.Rendering.PostProcessing.PostProcessBundle::m_Renderer
	PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C * ___m_Renderer_2;

public:
	inline static int32_t get_offset_of_U3CattributeU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(PostProcessBundle_t73C3A7D8C55E7C976045DC08CF6FBD8F2AE3450F, ___U3CattributeU3Ek__BackingField_0)); }
	inline PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54 * get_U3CattributeU3Ek__BackingField_0() const { return ___U3CattributeU3Ek__BackingField_0; }
	inline PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54 ** get_address_of_U3CattributeU3Ek__BackingField_0() { return &___U3CattributeU3Ek__BackingField_0; }
	inline void set_U3CattributeU3Ek__BackingField_0(PostProcessAttribute_t795817D592C782B0F5E50962B2525AE1A4D92F54 * value)
	{
		___U3CattributeU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CattributeU3Ek__BackingField_0), value);
	}

	inline static int32_t get_offset_of_U3CsettingsU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PostProcessBundle_t73C3A7D8C55E7C976045DC08CF6FBD8F2AE3450F, ___U3CsettingsU3Ek__BackingField_1)); }
	inline PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E * get_U3CsettingsU3Ek__BackingField_1() const { return ___U3CsettingsU3Ek__BackingField_1; }
	inline PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E ** get_address_of_U3CsettingsU3Ek__BackingField_1() { return &___U3CsettingsU3Ek__BackingField_1; }
	inline void set_U3CsettingsU3Ek__BackingField_1(PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E * value)
	{
		___U3CsettingsU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CsettingsU3Ek__BackingField_1), value);
	}

	inline static int32_t get_offset_of_m_Renderer_2() { return static_cast<int32_t>(offsetof(PostProcessBundle_t73C3A7D8C55E7C976045DC08CF6FBD8F2AE3450F, ___m_Renderer_2)); }
	inline PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C * get_m_Renderer_2() const { return ___m_Renderer_2; }
	inline PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C ** get_address_of_m_Renderer_2() { return &___m_Renderer_2; }
	inline void set_m_Renderer_2(PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C * value)
	{
		___m_Renderer_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_Renderer_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSBUNDLE_T73C3A7D8C55E7C976045DC08CF6FBD8F2AE3450F_H
#ifndef POSTPROCESSEFFECTRENDERER_T790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C_H
#define POSTPROCESSEFFECTRENDERER_T790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer
struct  PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C  : public RuntimeObject
{
public:
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer::m_ResetHistory
	bool ___m_ResetHistory_0;

public:
	inline static int32_t get_offset_of_m_ResetHistory_0() { return static_cast<int32_t>(offsetof(PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C, ___m_ResetHistory_0)); }
	inline bool get_m_ResetHistory_0() const { return ___m_ResetHistory_0; }
	inline bool* get_address_of_m_ResetHistory_0() { return &___m_ResetHistory_0; }
	inline void set_m_ResetHistory_0(bool value)
	{
		___m_ResetHistory_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEFFECTRENDERER_T790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C_H
#ifndef U3CU3EC_T7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259_H
#define U3CU3EC_T7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings_<>c
struct  U3CU3Ec_t7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_t7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259_StaticFields
{
public:
	// UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings_<>c UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings_<>c::<>9
	U3CU3Ec_t7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259 * ___U3CU3E9_0;
	// System.Func`2<System.Reflection.FieldInfo,System.Boolean> UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings_<>c::<>9__3_0
	Func_2_tAEF6BFDF029DC25672CC4AAF7D3E000F583BDF5C * ___U3CU3E9__3_0_1;
	// System.Func`2<System.Reflection.FieldInfo,System.Int32> UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings_<>c::<>9__3_1
	Func_2_t189EF4BEEE3256E5ECE9D578D095B8EAD00D467E * ___U3CU3E9__3_1_2;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_t7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_t7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259 * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_t7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259 ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_t7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259 * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9_0), value);
	}

	inline static int32_t get_offset_of_U3CU3E9__3_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_t7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259_StaticFields, ___U3CU3E9__3_0_1)); }
	inline Func_2_tAEF6BFDF029DC25672CC4AAF7D3E000F583BDF5C * get_U3CU3E9__3_0_1() const { return ___U3CU3E9__3_0_1; }
	inline Func_2_tAEF6BFDF029DC25672CC4AAF7D3E000F583BDF5C ** get_address_of_U3CU3E9__3_0_1() { return &___U3CU3E9__3_0_1; }
	inline void set_U3CU3E9__3_0_1(Func_2_tAEF6BFDF029DC25672CC4AAF7D3E000F583BDF5C * value)
	{
		___U3CU3E9__3_0_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9__3_0_1), value);
	}

	inline static int32_t get_offset_of_U3CU3E9__3_1_2() { return static_cast<int32_t>(offsetof(U3CU3Ec_t7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259_StaticFields, ___U3CU3E9__3_1_2)); }
	inline Func_2_t189EF4BEEE3256E5ECE9D578D095B8EAD00D467E * get_U3CU3E9__3_1_2() const { return ___U3CU3E9__3_1_2; }
	inline Func_2_t189EF4BEEE3256E5ECE9D578D095B8EAD00D467E ** get_address_of_U3CU3E9__3_1_2() { return &___U3CU3E9__3_1_2; }
	inline void set_U3CU3E9__3_1_2(Func_2_t189EF4BEEE3256E5ECE9D578D095B8EAD00D467E * value)
	{
		___U3CU3E9__3_1_2 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9__3_1_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC_T7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259_H
#ifndef U3CU3EC_T2977F22C91A261508C6D6D65BBDB8A5D4A504EEC_H
#define U3CU3EC_T2977F22C91A261508C6D6D65BBDB8A5D4A504EEC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessLayer_<>c
struct  U3CU3Ec_t2977F22C91A261508C6D6D65BBDB8A5D4A504EEC  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_t2977F22C91A261508C6D6D65BBDB8A5D4A504EEC_StaticFields
{
public:
	// UnityEngine.Rendering.PostProcessing.PostProcessLayer_<>c UnityEngine.Rendering.PostProcessing.PostProcessLayer_<>c::<>9
	U3CU3Ec_t2977F22C91A261508C6D6D65BBDB8A5D4A504EEC * ___U3CU3E9_0;
	// System.Func`2<System.Collections.Generic.KeyValuePair`2<System.Type,UnityEngine.Rendering.PostProcessing.PostProcessBundle>,UnityEngine.Rendering.PostProcessing.PostProcessBundle> UnityEngine.Rendering.PostProcessing.PostProcessLayer_<>c::<>9__51_1
	Func_2_t787140437793AD35F7E99517DB0FB2B94F4C7B7B * ___U3CU3E9__51_1_1;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_t2977F22C91A261508C6D6D65BBDB8A5D4A504EEC_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_t2977F22C91A261508C6D6D65BBDB8A5D4A504EEC * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_t2977F22C91A261508C6D6D65BBDB8A5D4A504EEC ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_t2977F22C91A261508C6D6D65BBDB8A5D4A504EEC * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9_0), value);
	}

	inline static int32_t get_offset_of_U3CU3E9__51_1_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_t2977F22C91A261508C6D6D65BBDB8A5D4A504EEC_StaticFields, ___U3CU3E9__51_1_1)); }
	inline Func_2_t787140437793AD35F7E99517DB0FB2B94F4C7B7B * get_U3CU3E9__51_1_1() const { return ___U3CU3E9__51_1_1; }
	inline Func_2_t787140437793AD35F7E99517DB0FB2B94F4C7B7B ** get_address_of_U3CU3E9__51_1_1() { return &___U3CU3E9__51_1_1; }
	inline void set_U3CU3E9__51_1_1(Func_2_t787140437793AD35F7E99517DB0FB2B94F4C7B7B * value)
	{
		___U3CU3E9__51_1_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9__51_1_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC_T2977F22C91A261508C6D6D65BBDB8A5D4A504EEC_H
#ifndef U3CU3EC__DISPLAYCLASS51_1_TDFC3417FA4C71D48EB9BB0B0E6BAE5833C5802E3_H
#define U3CU3EC__DISPLAYCLASS51_1_TDFC3417FA4C71D48EB9BB0B0E6BAE5833C5802E3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessLayer_<>c__DisplayClass51_1
struct  U3CU3Ec__DisplayClass51_1_tDFC3417FA4C71D48EB9BB0B0E6BAE5833C5802E3  : public RuntimeObject
{
public:
	// System.String UnityEngine.Rendering.PostProcessing.PostProcessLayer_<>c__DisplayClass51_1::searchStr
	String_t* ___searchStr_0;

public:
	inline static int32_t get_offset_of_searchStr_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass51_1_tDFC3417FA4C71D48EB9BB0B0E6BAE5833C5802E3, ___searchStr_0)); }
	inline String_t* get_searchStr_0() const { return ___searchStr_0; }
	inline String_t** get_address_of_searchStr_0() { return &___searchStr_0; }
	inline void set_searchStr_0(String_t* value)
	{
		___searchStr_0 = value;
		Il2CppCodeGenWriteBarrier((&___searchStr_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC__DISPLAYCLASS51_1_TDFC3417FA4C71D48EB9BB0B0E6BAE5833C5802E3_H
#ifndef U3CU3EC__DISPLAYCLASS51_2_T6A295F3472A366F5169B8AB8EC6EE16C4A92F7FB_H
#define U3CU3EC__DISPLAYCLASS51_2_T6A295F3472A366F5169B8AB8EC6EE16C4A92F7FB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessLayer_<>c__DisplayClass51_2
struct  U3CU3Ec__DisplayClass51_2_t6A295F3472A366F5169B8AB8EC6EE16C4A92F7FB  : public RuntimeObject
{
public:
	// System.String UnityEngine.Rendering.PostProcessing.PostProcessLayer_<>c__DisplayClass51_2::typeName
	String_t* ___typeName_0;

public:
	inline static int32_t get_offset_of_typeName_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass51_2_t6A295F3472A366F5169B8AB8EC6EE16C4A92F7FB, ___typeName_0)); }
	inline String_t* get_typeName_0() const { return ___typeName_0; }
	inline String_t** get_address_of_typeName_0() { return &___typeName_0; }
	inline void set_typeName_0(String_t* value)
	{
		___typeName_0 = value;
		Il2CppCodeGenWriteBarrier((&___typeName_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC__DISPLAYCLASS51_2_T6A295F3472A366F5169B8AB8EC6EE16C4A92F7FB_H
#ifndef U3CU3EC__DISPLAYCLASS51_3_T3226CA30517840AD21DEDB488DDEF96FC56504FA_H
#define U3CU3EC__DISPLAYCLASS51_3_T3226CA30517840AD21DEDB488DDEF96FC56504FA_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessLayer_<>c__DisplayClass51_3
struct  U3CU3Ec__DisplayClass51_3_t3226CA30517840AD21DEDB488DDEF96FC56504FA  : public RuntimeObject
{
public:
	// System.String UnityEngine.Rendering.PostProcessing.PostProcessLayer_<>c__DisplayClass51_3::typeName
	String_t* ___typeName_0;

public:
	inline static int32_t get_offset_of_typeName_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass51_3_t3226CA30517840AD21DEDB488DDEF96FC56504FA, ___typeName_0)); }
	inline String_t* get_typeName_0() const { return ___typeName_0; }
	inline String_t** get_address_of_typeName_0() { return &___typeName_0; }
	inline void set_typeName_0(String_t* value)
	{
		___typeName_0 = value;
		Il2CppCodeGenWriteBarrier((&___typeName_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC__DISPLAYCLASS51_3_T3226CA30517840AD21DEDB488DDEF96FC56504FA_H
#ifndef SERIALIZEDBUNDLEREF_T6EBF67645AD3B5BD0BEE52333F201406A72DAD4D_H
#define SERIALIZEDBUNDLEREF_T6EBF67645AD3B5BD0BEE52333F201406A72DAD4D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessLayer_SerializedBundleRef
struct  SerializedBundleRef_t6EBF67645AD3B5BD0BEE52333F201406A72DAD4D  : public RuntimeObject
{
public:
	// System.String UnityEngine.Rendering.PostProcessing.PostProcessLayer_SerializedBundleRef::assemblyQualifiedName
	String_t* ___assemblyQualifiedName_0;
	// UnityEngine.Rendering.PostProcessing.PostProcessBundle UnityEngine.Rendering.PostProcessing.PostProcessLayer_SerializedBundleRef::bundle
	PostProcessBundle_t73C3A7D8C55E7C976045DC08CF6FBD8F2AE3450F * ___bundle_1;

public:
	inline static int32_t get_offset_of_assemblyQualifiedName_0() { return static_cast<int32_t>(offsetof(SerializedBundleRef_t6EBF67645AD3B5BD0BEE52333F201406A72DAD4D, ___assemblyQualifiedName_0)); }
	inline String_t* get_assemblyQualifiedName_0() const { return ___assemblyQualifiedName_0; }
	inline String_t** get_address_of_assemblyQualifiedName_0() { return &___assemblyQualifiedName_0; }
	inline void set_assemblyQualifiedName_0(String_t* value)
	{
		___assemblyQualifiedName_0 = value;
		Il2CppCodeGenWriteBarrier((&___assemblyQualifiedName_0), value);
	}

	inline static int32_t get_offset_of_bundle_1() { return static_cast<int32_t>(offsetof(SerializedBundleRef_t6EBF67645AD3B5BD0BEE52333F201406A72DAD4D, ___bundle_1)); }
	inline PostProcessBundle_t73C3A7D8C55E7C976045DC08CF6FBD8F2AE3450F * get_bundle_1() const { return ___bundle_1; }
	inline PostProcessBundle_t73C3A7D8C55E7C976045DC08CF6FBD8F2AE3450F ** get_address_of_bundle_1() { return &___bundle_1; }
	inline void set_bundle_1(PostProcessBundle_t73C3A7D8C55E7C976045DC08CF6FBD8F2AE3450F * value)
	{
		___bundle_1 = value;
		Il2CppCodeGenWriteBarrier((&___bundle_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SERIALIZEDBUNDLEREF_T6EBF67645AD3B5BD0BEE52333F201406A72DAD4D_H
#ifndef POSTPROCESSMANAGER_TFC810FE0B8D374295EA43955753CF7128E987399_H
#define POSTPROCESSMANAGER_TFC810FE0B8D374295EA43955753CF7128E987399_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessManager
struct  PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399  : public RuntimeObject
{
public:
	// System.Collections.Generic.Dictionary`2<System.Int32,System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessVolume>> UnityEngine.Rendering.PostProcessing.PostProcessManager::m_SortedVolumes
	Dictionary_2_tED9592904E54FB90363D1C8E916DB04AEF6AC85D * ___m_SortedVolumes_2;
	// System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessVolume> UnityEngine.Rendering.PostProcessing.PostProcessManager::m_Volumes
	List_1_tD3BC8DD5F7F747B9381C5279C6B3CCDEB921CE0F * ___m_Volumes_3;
	// System.Collections.Generic.Dictionary`2<System.Int32,System.Boolean> UnityEngine.Rendering.PostProcessing.PostProcessManager::m_SortNeeded
	Dictionary_2_t2258334B2FD1F225C68C5C4869898F9DF49998FB * ___m_SortNeeded_4;
	// System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings> UnityEngine.Rendering.PostProcessing.PostProcessManager::m_BaseSettings
	List_1_tC82B3FE12BB2B40AE4E4672E4302D78EB191BADC * ___m_BaseSettings_5;
	// System.Collections.Generic.List`1<UnityEngine.Collider> UnityEngine.Rendering.PostProcessing.PostProcessManager::m_TempColliders
	List_1_t88DF1A02CCDD1766DB310B8D72B1F2145D775432 * ___m_TempColliders_6;
	// System.Collections.Generic.Dictionary`2<System.Type,UnityEngine.Rendering.PostProcessing.PostProcessAttribute> UnityEngine.Rendering.PostProcessing.PostProcessManager::settingsTypes
	Dictionary_2_t0EDE3B40268AF2A908B7F215F87FE5683E7635B4 * ___settingsTypes_7;

public:
	inline static int32_t get_offset_of_m_SortedVolumes_2() { return static_cast<int32_t>(offsetof(PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399, ___m_SortedVolumes_2)); }
	inline Dictionary_2_tED9592904E54FB90363D1C8E916DB04AEF6AC85D * get_m_SortedVolumes_2() const { return ___m_SortedVolumes_2; }
	inline Dictionary_2_tED9592904E54FB90363D1C8E916DB04AEF6AC85D ** get_address_of_m_SortedVolumes_2() { return &___m_SortedVolumes_2; }
	inline void set_m_SortedVolumes_2(Dictionary_2_tED9592904E54FB90363D1C8E916DB04AEF6AC85D * value)
	{
		___m_SortedVolumes_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_SortedVolumes_2), value);
	}

	inline static int32_t get_offset_of_m_Volumes_3() { return static_cast<int32_t>(offsetof(PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399, ___m_Volumes_3)); }
	inline List_1_tD3BC8DD5F7F747B9381C5279C6B3CCDEB921CE0F * get_m_Volumes_3() const { return ___m_Volumes_3; }
	inline List_1_tD3BC8DD5F7F747B9381C5279C6B3CCDEB921CE0F ** get_address_of_m_Volumes_3() { return &___m_Volumes_3; }
	inline void set_m_Volumes_3(List_1_tD3BC8DD5F7F747B9381C5279C6B3CCDEB921CE0F * value)
	{
		___m_Volumes_3 = value;
		Il2CppCodeGenWriteBarrier((&___m_Volumes_3), value);
	}

	inline static int32_t get_offset_of_m_SortNeeded_4() { return static_cast<int32_t>(offsetof(PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399, ___m_SortNeeded_4)); }
	inline Dictionary_2_t2258334B2FD1F225C68C5C4869898F9DF49998FB * get_m_SortNeeded_4() const { return ___m_SortNeeded_4; }
	inline Dictionary_2_t2258334B2FD1F225C68C5C4869898F9DF49998FB ** get_address_of_m_SortNeeded_4() { return &___m_SortNeeded_4; }
	inline void set_m_SortNeeded_4(Dictionary_2_t2258334B2FD1F225C68C5C4869898F9DF49998FB * value)
	{
		___m_SortNeeded_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_SortNeeded_4), value);
	}

	inline static int32_t get_offset_of_m_BaseSettings_5() { return static_cast<int32_t>(offsetof(PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399, ___m_BaseSettings_5)); }
	inline List_1_tC82B3FE12BB2B40AE4E4672E4302D78EB191BADC * get_m_BaseSettings_5() const { return ___m_BaseSettings_5; }
	inline List_1_tC82B3FE12BB2B40AE4E4672E4302D78EB191BADC ** get_address_of_m_BaseSettings_5() { return &___m_BaseSettings_5; }
	inline void set_m_BaseSettings_5(List_1_tC82B3FE12BB2B40AE4E4672E4302D78EB191BADC * value)
	{
		___m_BaseSettings_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_BaseSettings_5), value);
	}

	inline static int32_t get_offset_of_m_TempColliders_6() { return static_cast<int32_t>(offsetof(PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399, ___m_TempColliders_6)); }
	inline List_1_t88DF1A02CCDD1766DB310B8D72B1F2145D775432 * get_m_TempColliders_6() const { return ___m_TempColliders_6; }
	inline List_1_t88DF1A02CCDD1766DB310B8D72B1F2145D775432 ** get_address_of_m_TempColliders_6() { return &___m_TempColliders_6; }
	inline void set_m_TempColliders_6(List_1_t88DF1A02CCDD1766DB310B8D72B1F2145D775432 * value)
	{
		___m_TempColliders_6 = value;
		Il2CppCodeGenWriteBarrier((&___m_TempColliders_6), value);
	}

	inline static int32_t get_offset_of_settingsTypes_7() { return static_cast<int32_t>(offsetof(PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399, ___settingsTypes_7)); }
	inline Dictionary_2_t0EDE3B40268AF2A908B7F215F87FE5683E7635B4 * get_settingsTypes_7() const { return ___settingsTypes_7; }
	inline Dictionary_2_t0EDE3B40268AF2A908B7F215F87FE5683E7635B4 ** get_address_of_settingsTypes_7() { return &___settingsTypes_7; }
	inline void set_settingsTypes_7(Dictionary_2_t0EDE3B40268AF2A908B7F215F87FE5683E7635B4 * value)
	{
		___settingsTypes_7 = value;
		Il2CppCodeGenWriteBarrier((&___settingsTypes_7), value);
	}
};

struct PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399_StaticFields
{
public:
	// UnityEngine.Rendering.PostProcessing.PostProcessManager UnityEngine.Rendering.PostProcessing.PostProcessManager::s_Instance
	PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399 * ___s_Instance_0;

public:
	inline static int32_t get_offset_of_s_Instance_0() { return static_cast<int32_t>(offsetof(PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399_StaticFields, ___s_Instance_0)); }
	inline PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399 * get_s_Instance_0() const { return ___s_Instance_0; }
	inline PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399 ** get_address_of_s_Instance_0() { return &___s_Instance_0; }
	inline void set_s_Instance_0(PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399 * value)
	{
		___s_Instance_0 = value;
		Il2CppCodeGenWriteBarrier((&___s_Instance_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSMANAGER_TFC810FE0B8D374295EA43955753CF7128E987399_H
#ifndef U3CU3EC_TC99B445AA5A4C0EA4158842F9AD8C3A013A0503C_H
#define U3CU3EC_TC99B445AA5A4C0EA4158842F9AD8C3A013A0503C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessManager_<>c
struct  U3CU3Ec_tC99B445AA5A4C0EA4158842F9AD8C3A013A0503C  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_tC99B445AA5A4C0EA4158842F9AD8C3A013A0503C_StaticFields
{
public:
	// UnityEngine.Rendering.PostProcessing.PostProcessManager_<>c UnityEngine.Rendering.PostProcessing.PostProcessManager_<>c::<>9
	U3CU3Ec_tC99B445AA5A4C0EA4158842F9AD8C3A013A0503C * ___U3CU3E9_0;
	// System.Func`2<System.Type,System.Boolean> UnityEngine.Rendering.PostProcessing.PostProcessManager_<>c::<>9__12_0
	Func_2_tF531BD8DCA90022059CF63DD5140CEA803AC1091 * ___U3CU3E9__12_0_1;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_tC99B445AA5A4C0EA4158842F9AD8C3A013A0503C_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_tC99B445AA5A4C0EA4158842F9AD8C3A013A0503C * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_tC99B445AA5A4C0EA4158842F9AD8C3A013A0503C ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_tC99B445AA5A4C0EA4158842F9AD8C3A013A0503C * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9_0), value);
	}

	inline static int32_t get_offset_of_U3CU3E9__12_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_tC99B445AA5A4C0EA4158842F9AD8C3A013A0503C_StaticFields, ___U3CU3E9__12_0_1)); }
	inline Func_2_tF531BD8DCA90022059CF63DD5140CEA803AC1091 * get_U3CU3E9__12_0_1() const { return ___U3CU3E9__12_0_1; }
	inline Func_2_tF531BD8DCA90022059CF63DD5140CEA803AC1091 ** get_address_of_U3CU3E9__12_0_1() { return &___U3CU3E9__12_0_1; }
	inline void set_U3CU3E9__12_0_1(Func_2_tF531BD8DCA90022059CF63DD5140CEA803AC1091 * value)
	{
		___U3CU3E9__12_0_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9__12_0_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC_TC99B445AA5A4C0EA4158842F9AD8C3A013A0503C_H
#ifndef U3CU3EC_TC57F65B5DBD077E50FD91FE1F471440D65CE6818_H
#define U3CU3EC_TC57F65B5DBD077E50FD91FE1F471440D65CE6818_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessProfile_<>c
struct  U3CU3Ec_tC57F65B5DBD077E50FD91FE1F471440D65CE6818  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_tC57F65B5DBD077E50FD91FE1F471440D65CE6818_StaticFields
{
public:
	// UnityEngine.Rendering.PostProcessing.PostProcessProfile_<>c UnityEngine.Rendering.PostProcessing.PostProcessProfile_<>c::<>9
	U3CU3Ec_tC57F65B5DBD077E50FD91FE1F471440D65CE6818 * ___U3CU3E9_0;
	// System.Predicate`1<UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings> UnityEngine.Rendering.PostProcessing.PostProcessProfile_<>c::<>9__2_0
	Predicate_1_t600D4636D1F7216584932BF1CC7965FF5D254AD9 * ___U3CU3E9__2_0_1;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_tC57F65B5DBD077E50FD91FE1F471440D65CE6818_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_tC57F65B5DBD077E50FD91FE1F471440D65CE6818 * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_tC57F65B5DBD077E50FD91FE1F471440D65CE6818 ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_tC57F65B5DBD077E50FD91FE1F471440D65CE6818 * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9_0), value);
	}

	inline static int32_t get_offset_of_U3CU3E9__2_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_tC57F65B5DBD077E50FD91FE1F471440D65CE6818_StaticFields, ___U3CU3E9__2_0_1)); }
	inline Predicate_1_t600D4636D1F7216584932BF1CC7965FF5D254AD9 * get_U3CU3E9__2_0_1() const { return ___U3CU3E9__2_0_1; }
	inline Predicate_1_t600D4636D1F7216584932BF1CC7965FF5D254AD9 ** get_address_of_U3CU3E9__2_0_1() { return &___U3CU3E9__2_0_1; }
	inline void set_U3CU3E9__2_0_1(Predicate_1_t600D4636D1F7216584932BF1CC7965FF5D254AD9 * value)
	{
		___U3CU3E9__2_0_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9__2_0_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC_TC57F65B5DBD077E50FD91FE1F471440D65CE6818_H
#ifndef COMPUTESHADERS_T1889552AF93D82A2D22F9779BC3BC8B133299EE2_H
#define COMPUTESHADERS_T1889552AF93D82A2D22F9779BC3BC8B133299EE2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessResources_ComputeShaders
struct  ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2  : public RuntimeObject
{
public:
	// UnityEngine.ComputeShader UnityEngine.Rendering.PostProcessing.PostProcessResources_ComputeShaders::autoExposure
	ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * ___autoExposure_0;
	// UnityEngine.ComputeShader UnityEngine.Rendering.PostProcessing.PostProcessResources_ComputeShaders::exposureHistogram
	ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * ___exposureHistogram_1;
	// UnityEngine.ComputeShader UnityEngine.Rendering.PostProcessing.PostProcessResources_ComputeShaders::lut3DBaker
	ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * ___lut3DBaker_2;
	// UnityEngine.ComputeShader UnityEngine.Rendering.PostProcessing.PostProcessResources_ComputeShaders::texture3dLerp
	ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * ___texture3dLerp_3;
	// UnityEngine.ComputeShader UnityEngine.Rendering.PostProcessing.PostProcessResources_ComputeShaders::gammaHistogram
	ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * ___gammaHistogram_4;
	// UnityEngine.ComputeShader UnityEngine.Rendering.PostProcessing.PostProcessResources_ComputeShaders::waveform
	ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * ___waveform_5;
	// UnityEngine.ComputeShader UnityEngine.Rendering.PostProcessing.PostProcessResources_ComputeShaders::vectorscope
	ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * ___vectorscope_6;
	// UnityEngine.ComputeShader UnityEngine.Rendering.PostProcessing.PostProcessResources_ComputeShaders::multiScaleAODownsample1
	ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * ___multiScaleAODownsample1_7;
	// UnityEngine.ComputeShader UnityEngine.Rendering.PostProcessing.PostProcessResources_ComputeShaders::multiScaleAODownsample2
	ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * ___multiScaleAODownsample2_8;
	// UnityEngine.ComputeShader UnityEngine.Rendering.PostProcessing.PostProcessResources_ComputeShaders::multiScaleAORender
	ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * ___multiScaleAORender_9;
	// UnityEngine.ComputeShader UnityEngine.Rendering.PostProcessing.PostProcessResources_ComputeShaders::multiScaleAOUpsample
	ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * ___multiScaleAOUpsample_10;
	// UnityEngine.ComputeShader UnityEngine.Rendering.PostProcessing.PostProcessResources_ComputeShaders::gaussianDownsample
	ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * ___gaussianDownsample_11;

public:
	inline static int32_t get_offset_of_autoExposure_0() { return static_cast<int32_t>(offsetof(ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2, ___autoExposure_0)); }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * get_autoExposure_0() const { return ___autoExposure_0; }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A ** get_address_of_autoExposure_0() { return &___autoExposure_0; }
	inline void set_autoExposure_0(ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * value)
	{
		___autoExposure_0 = value;
		Il2CppCodeGenWriteBarrier((&___autoExposure_0), value);
	}

	inline static int32_t get_offset_of_exposureHistogram_1() { return static_cast<int32_t>(offsetof(ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2, ___exposureHistogram_1)); }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * get_exposureHistogram_1() const { return ___exposureHistogram_1; }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A ** get_address_of_exposureHistogram_1() { return &___exposureHistogram_1; }
	inline void set_exposureHistogram_1(ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * value)
	{
		___exposureHistogram_1 = value;
		Il2CppCodeGenWriteBarrier((&___exposureHistogram_1), value);
	}

	inline static int32_t get_offset_of_lut3DBaker_2() { return static_cast<int32_t>(offsetof(ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2, ___lut3DBaker_2)); }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * get_lut3DBaker_2() const { return ___lut3DBaker_2; }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A ** get_address_of_lut3DBaker_2() { return &___lut3DBaker_2; }
	inline void set_lut3DBaker_2(ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * value)
	{
		___lut3DBaker_2 = value;
		Il2CppCodeGenWriteBarrier((&___lut3DBaker_2), value);
	}

	inline static int32_t get_offset_of_texture3dLerp_3() { return static_cast<int32_t>(offsetof(ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2, ___texture3dLerp_3)); }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * get_texture3dLerp_3() const { return ___texture3dLerp_3; }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A ** get_address_of_texture3dLerp_3() { return &___texture3dLerp_3; }
	inline void set_texture3dLerp_3(ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * value)
	{
		___texture3dLerp_3 = value;
		Il2CppCodeGenWriteBarrier((&___texture3dLerp_3), value);
	}

	inline static int32_t get_offset_of_gammaHistogram_4() { return static_cast<int32_t>(offsetof(ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2, ___gammaHistogram_4)); }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * get_gammaHistogram_4() const { return ___gammaHistogram_4; }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A ** get_address_of_gammaHistogram_4() { return &___gammaHistogram_4; }
	inline void set_gammaHistogram_4(ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * value)
	{
		___gammaHistogram_4 = value;
		Il2CppCodeGenWriteBarrier((&___gammaHistogram_4), value);
	}

	inline static int32_t get_offset_of_waveform_5() { return static_cast<int32_t>(offsetof(ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2, ___waveform_5)); }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * get_waveform_5() const { return ___waveform_5; }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A ** get_address_of_waveform_5() { return &___waveform_5; }
	inline void set_waveform_5(ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * value)
	{
		___waveform_5 = value;
		Il2CppCodeGenWriteBarrier((&___waveform_5), value);
	}

	inline static int32_t get_offset_of_vectorscope_6() { return static_cast<int32_t>(offsetof(ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2, ___vectorscope_6)); }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * get_vectorscope_6() const { return ___vectorscope_6; }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A ** get_address_of_vectorscope_6() { return &___vectorscope_6; }
	inline void set_vectorscope_6(ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * value)
	{
		___vectorscope_6 = value;
		Il2CppCodeGenWriteBarrier((&___vectorscope_6), value);
	}

	inline static int32_t get_offset_of_multiScaleAODownsample1_7() { return static_cast<int32_t>(offsetof(ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2, ___multiScaleAODownsample1_7)); }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * get_multiScaleAODownsample1_7() const { return ___multiScaleAODownsample1_7; }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A ** get_address_of_multiScaleAODownsample1_7() { return &___multiScaleAODownsample1_7; }
	inline void set_multiScaleAODownsample1_7(ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * value)
	{
		___multiScaleAODownsample1_7 = value;
		Il2CppCodeGenWriteBarrier((&___multiScaleAODownsample1_7), value);
	}

	inline static int32_t get_offset_of_multiScaleAODownsample2_8() { return static_cast<int32_t>(offsetof(ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2, ___multiScaleAODownsample2_8)); }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * get_multiScaleAODownsample2_8() const { return ___multiScaleAODownsample2_8; }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A ** get_address_of_multiScaleAODownsample2_8() { return &___multiScaleAODownsample2_8; }
	inline void set_multiScaleAODownsample2_8(ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * value)
	{
		___multiScaleAODownsample2_8 = value;
		Il2CppCodeGenWriteBarrier((&___multiScaleAODownsample2_8), value);
	}

	inline static int32_t get_offset_of_multiScaleAORender_9() { return static_cast<int32_t>(offsetof(ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2, ___multiScaleAORender_9)); }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * get_multiScaleAORender_9() const { return ___multiScaleAORender_9; }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A ** get_address_of_multiScaleAORender_9() { return &___multiScaleAORender_9; }
	inline void set_multiScaleAORender_9(ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * value)
	{
		___multiScaleAORender_9 = value;
		Il2CppCodeGenWriteBarrier((&___multiScaleAORender_9), value);
	}

	inline static int32_t get_offset_of_multiScaleAOUpsample_10() { return static_cast<int32_t>(offsetof(ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2, ___multiScaleAOUpsample_10)); }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * get_multiScaleAOUpsample_10() const { return ___multiScaleAOUpsample_10; }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A ** get_address_of_multiScaleAOUpsample_10() { return &___multiScaleAOUpsample_10; }
	inline void set_multiScaleAOUpsample_10(ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * value)
	{
		___multiScaleAOUpsample_10 = value;
		Il2CppCodeGenWriteBarrier((&___multiScaleAOUpsample_10), value);
	}

	inline static int32_t get_offset_of_gaussianDownsample_11() { return static_cast<int32_t>(offsetof(ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2, ___gaussianDownsample_11)); }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * get_gaussianDownsample_11() const { return ___gaussianDownsample_11; }
	inline ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A ** get_address_of_gaussianDownsample_11() { return &___gaussianDownsample_11; }
	inline void set_gaussianDownsample_11(ComputeShader_tF8B65214DC8C7C124C01984EB5CCD28F55C85B2A * value)
	{
		___gaussianDownsample_11 = value;
		Il2CppCodeGenWriteBarrier((&___gaussianDownsample_11), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPUTESHADERS_T1889552AF93D82A2D22F9779BC3BC8B133299EE2_H
#ifndef SMAALUTS_T4E0EB2F1BAD60C948B7153C88F485EE928445519_H
#define SMAALUTS_T4E0EB2F1BAD60C948B7153C88F485EE928445519_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessResources_SMAALuts
struct  SMAALuts_t4E0EB2F1BAD60C948B7153C88F485EE928445519  : public RuntimeObject
{
public:
	// UnityEngine.Texture2D UnityEngine.Rendering.PostProcessing.PostProcessResources_SMAALuts::area
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___area_0;
	// UnityEngine.Texture2D UnityEngine.Rendering.PostProcessing.PostProcessResources_SMAALuts::search
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___search_1;

public:
	inline static int32_t get_offset_of_area_0() { return static_cast<int32_t>(offsetof(SMAALuts_t4E0EB2F1BAD60C948B7153C88F485EE928445519, ___area_0)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_area_0() const { return ___area_0; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_area_0() { return &___area_0; }
	inline void set_area_0(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___area_0 = value;
		Il2CppCodeGenWriteBarrier((&___area_0), value);
	}

	inline static int32_t get_offset_of_search_1() { return static_cast<int32_t>(offsetof(SMAALuts_t4E0EB2F1BAD60C948B7153C88F485EE928445519, ___search_1)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_search_1() const { return ___search_1; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_search_1() { return &___search_1; }
	inline void set_search_1(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___search_1 = value;
		Il2CppCodeGenWriteBarrier((&___search_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SMAALUTS_T4E0EB2F1BAD60C948B7153C88F485EE928445519_H
#ifndef SHADERS_T15D6AD5C461051D7B09E20AEBE06E168CD133510_H
#define SHADERS_T15D6AD5C461051D7B09E20AEBE06E168CD133510_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders
struct  Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510  : public RuntimeObject
{
public:
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::bloom
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___bloom_0;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::copy
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___copy_1;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::copyStd
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___copyStd_2;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::copyStdFromTexArray
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___copyStdFromTexArray_3;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::copyStdFromDoubleWide
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___copyStdFromDoubleWide_4;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::discardAlpha
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___discardAlpha_5;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::depthOfField
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___depthOfField_6;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::finalPass
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___finalPass_7;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::grainBaker
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___grainBaker_8;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::motionBlur
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___motionBlur_9;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::temporalAntialiasing
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___temporalAntialiasing_10;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::subpixelMorphologicalAntialiasing
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___subpixelMorphologicalAntialiasing_11;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::texture2dLerp
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___texture2dLerp_12;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::uber
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___uber_13;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::lut2DBaker
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___lut2DBaker_14;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::lightMeter
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___lightMeter_15;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::gammaHistogram
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___gammaHistogram_16;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::waveform
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___waveform_17;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::vectorscope
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___vectorscope_18;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::debugOverlays
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___debugOverlays_19;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::deferredFog
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___deferredFog_20;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::scalableAO
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___scalableAO_21;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::multiScaleAO
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___multiScaleAO_22;
	// UnityEngine.Shader UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders::screenSpaceReflections
	Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * ___screenSpaceReflections_23;

public:
	inline static int32_t get_offset_of_bloom_0() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___bloom_0)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_bloom_0() const { return ___bloom_0; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_bloom_0() { return &___bloom_0; }
	inline void set_bloom_0(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___bloom_0 = value;
		Il2CppCodeGenWriteBarrier((&___bloom_0), value);
	}

	inline static int32_t get_offset_of_copy_1() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___copy_1)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_copy_1() const { return ___copy_1; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_copy_1() { return &___copy_1; }
	inline void set_copy_1(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___copy_1 = value;
		Il2CppCodeGenWriteBarrier((&___copy_1), value);
	}

	inline static int32_t get_offset_of_copyStd_2() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___copyStd_2)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_copyStd_2() const { return ___copyStd_2; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_copyStd_2() { return &___copyStd_2; }
	inline void set_copyStd_2(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___copyStd_2 = value;
		Il2CppCodeGenWriteBarrier((&___copyStd_2), value);
	}

	inline static int32_t get_offset_of_copyStdFromTexArray_3() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___copyStdFromTexArray_3)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_copyStdFromTexArray_3() const { return ___copyStdFromTexArray_3; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_copyStdFromTexArray_3() { return &___copyStdFromTexArray_3; }
	inline void set_copyStdFromTexArray_3(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___copyStdFromTexArray_3 = value;
		Il2CppCodeGenWriteBarrier((&___copyStdFromTexArray_3), value);
	}

	inline static int32_t get_offset_of_copyStdFromDoubleWide_4() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___copyStdFromDoubleWide_4)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_copyStdFromDoubleWide_4() const { return ___copyStdFromDoubleWide_4; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_copyStdFromDoubleWide_4() { return &___copyStdFromDoubleWide_4; }
	inline void set_copyStdFromDoubleWide_4(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___copyStdFromDoubleWide_4 = value;
		Il2CppCodeGenWriteBarrier((&___copyStdFromDoubleWide_4), value);
	}

	inline static int32_t get_offset_of_discardAlpha_5() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___discardAlpha_5)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_discardAlpha_5() const { return ___discardAlpha_5; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_discardAlpha_5() { return &___discardAlpha_5; }
	inline void set_discardAlpha_5(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___discardAlpha_5 = value;
		Il2CppCodeGenWriteBarrier((&___discardAlpha_5), value);
	}

	inline static int32_t get_offset_of_depthOfField_6() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___depthOfField_6)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_depthOfField_6() const { return ___depthOfField_6; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_depthOfField_6() { return &___depthOfField_6; }
	inline void set_depthOfField_6(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___depthOfField_6 = value;
		Il2CppCodeGenWriteBarrier((&___depthOfField_6), value);
	}

	inline static int32_t get_offset_of_finalPass_7() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___finalPass_7)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_finalPass_7() const { return ___finalPass_7; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_finalPass_7() { return &___finalPass_7; }
	inline void set_finalPass_7(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___finalPass_7 = value;
		Il2CppCodeGenWriteBarrier((&___finalPass_7), value);
	}

	inline static int32_t get_offset_of_grainBaker_8() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___grainBaker_8)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_grainBaker_8() const { return ___grainBaker_8; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_grainBaker_8() { return &___grainBaker_8; }
	inline void set_grainBaker_8(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___grainBaker_8 = value;
		Il2CppCodeGenWriteBarrier((&___grainBaker_8), value);
	}

	inline static int32_t get_offset_of_motionBlur_9() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___motionBlur_9)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_motionBlur_9() const { return ___motionBlur_9; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_motionBlur_9() { return &___motionBlur_9; }
	inline void set_motionBlur_9(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___motionBlur_9 = value;
		Il2CppCodeGenWriteBarrier((&___motionBlur_9), value);
	}

	inline static int32_t get_offset_of_temporalAntialiasing_10() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___temporalAntialiasing_10)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_temporalAntialiasing_10() const { return ___temporalAntialiasing_10; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_temporalAntialiasing_10() { return &___temporalAntialiasing_10; }
	inline void set_temporalAntialiasing_10(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___temporalAntialiasing_10 = value;
		Il2CppCodeGenWriteBarrier((&___temporalAntialiasing_10), value);
	}

	inline static int32_t get_offset_of_subpixelMorphologicalAntialiasing_11() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___subpixelMorphologicalAntialiasing_11)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_subpixelMorphologicalAntialiasing_11() const { return ___subpixelMorphologicalAntialiasing_11; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_subpixelMorphologicalAntialiasing_11() { return &___subpixelMorphologicalAntialiasing_11; }
	inline void set_subpixelMorphologicalAntialiasing_11(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___subpixelMorphologicalAntialiasing_11 = value;
		Il2CppCodeGenWriteBarrier((&___subpixelMorphologicalAntialiasing_11), value);
	}

	inline static int32_t get_offset_of_texture2dLerp_12() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___texture2dLerp_12)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_texture2dLerp_12() const { return ___texture2dLerp_12; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_texture2dLerp_12() { return &___texture2dLerp_12; }
	inline void set_texture2dLerp_12(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___texture2dLerp_12 = value;
		Il2CppCodeGenWriteBarrier((&___texture2dLerp_12), value);
	}

	inline static int32_t get_offset_of_uber_13() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___uber_13)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_uber_13() const { return ___uber_13; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_uber_13() { return &___uber_13; }
	inline void set_uber_13(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___uber_13 = value;
		Il2CppCodeGenWriteBarrier((&___uber_13), value);
	}

	inline static int32_t get_offset_of_lut2DBaker_14() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___lut2DBaker_14)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_lut2DBaker_14() const { return ___lut2DBaker_14; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_lut2DBaker_14() { return &___lut2DBaker_14; }
	inline void set_lut2DBaker_14(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___lut2DBaker_14 = value;
		Il2CppCodeGenWriteBarrier((&___lut2DBaker_14), value);
	}

	inline static int32_t get_offset_of_lightMeter_15() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___lightMeter_15)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_lightMeter_15() const { return ___lightMeter_15; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_lightMeter_15() { return &___lightMeter_15; }
	inline void set_lightMeter_15(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___lightMeter_15 = value;
		Il2CppCodeGenWriteBarrier((&___lightMeter_15), value);
	}

	inline static int32_t get_offset_of_gammaHistogram_16() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___gammaHistogram_16)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_gammaHistogram_16() const { return ___gammaHistogram_16; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_gammaHistogram_16() { return &___gammaHistogram_16; }
	inline void set_gammaHistogram_16(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___gammaHistogram_16 = value;
		Il2CppCodeGenWriteBarrier((&___gammaHistogram_16), value);
	}

	inline static int32_t get_offset_of_waveform_17() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___waveform_17)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_waveform_17() const { return ___waveform_17; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_waveform_17() { return &___waveform_17; }
	inline void set_waveform_17(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___waveform_17 = value;
		Il2CppCodeGenWriteBarrier((&___waveform_17), value);
	}

	inline static int32_t get_offset_of_vectorscope_18() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___vectorscope_18)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_vectorscope_18() const { return ___vectorscope_18; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_vectorscope_18() { return &___vectorscope_18; }
	inline void set_vectorscope_18(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___vectorscope_18 = value;
		Il2CppCodeGenWriteBarrier((&___vectorscope_18), value);
	}

	inline static int32_t get_offset_of_debugOverlays_19() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___debugOverlays_19)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_debugOverlays_19() const { return ___debugOverlays_19; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_debugOverlays_19() { return &___debugOverlays_19; }
	inline void set_debugOverlays_19(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___debugOverlays_19 = value;
		Il2CppCodeGenWriteBarrier((&___debugOverlays_19), value);
	}

	inline static int32_t get_offset_of_deferredFog_20() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___deferredFog_20)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_deferredFog_20() const { return ___deferredFog_20; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_deferredFog_20() { return &___deferredFog_20; }
	inline void set_deferredFog_20(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___deferredFog_20 = value;
		Il2CppCodeGenWriteBarrier((&___deferredFog_20), value);
	}

	inline static int32_t get_offset_of_scalableAO_21() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___scalableAO_21)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_scalableAO_21() const { return ___scalableAO_21; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_scalableAO_21() { return &___scalableAO_21; }
	inline void set_scalableAO_21(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___scalableAO_21 = value;
		Il2CppCodeGenWriteBarrier((&___scalableAO_21), value);
	}

	inline static int32_t get_offset_of_multiScaleAO_22() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___multiScaleAO_22)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_multiScaleAO_22() const { return ___multiScaleAO_22; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_multiScaleAO_22() { return &___multiScaleAO_22; }
	inline void set_multiScaleAO_22(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___multiScaleAO_22 = value;
		Il2CppCodeGenWriteBarrier((&___multiScaleAO_22), value);
	}

	inline static int32_t get_offset_of_screenSpaceReflections_23() { return static_cast<int32_t>(offsetof(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510, ___screenSpaceReflections_23)); }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * get_screenSpaceReflections_23() const { return ___screenSpaceReflections_23; }
	inline Shader_tE2731FF351B74AB4186897484FB01E000C1160CA ** get_address_of_screenSpaceReflections_23() { return &___screenSpaceReflections_23; }
	inline void set_screenSpaceReflections_23(Shader_tE2731FF351B74AB4186897484FB01E000C1160CA * value)
	{
		___screenSpaceReflections_23 = value;
		Il2CppCodeGenWriteBarrier((&___screenSpaceReflections_23), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SHADERS_T15D6AD5C461051D7B09E20AEBE06E168CD133510_H
#ifndef PROPERTYSHEET_T24C92FDC502E601797E65D23B427D05B15840212_H
#define PROPERTYSHEET_T24C92FDC502E601797E65D23B427D05B15840212_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PropertySheet
struct  PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212  : public RuntimeObject
{
public:
	// UnityEngine.MaterialPropertyBlock UnityEngine.Rendering.PostProcessing.PropertySheet::<properties>k__BackingField
	MaterialPropertyBlock_t72A481768111C6F11DCDCD44F0C7F99F1CA79E13 * ___U3CpropertiesU3Ek__BackingField_0;
	// UnityEngine.Material UnityEngine.Rendering.PostProcessing.PropertySheet::<material>k__BackingField
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___U3CmaterialU3Ek__BackingField_1;

public:
	inline static int32_t get_offset_of_U3CpropertiesU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212, ___U3CpropertiesU3Ek__BackingField_0)); }
	inline MaterialPropertyBlock_t72A481768111C6F11DCDCD44F0C7F99F1CA79E13 * get_U3CpropertiesU3Ek__BackingField_0() const { return ___U3CpropertiesU3Ek__BackingField_0; }
	inline MaterialPropertyBlock_t72A481768111C6F11DCDCD44F0C7F99F1CA79E13 ** get_address_of_U3CpropertiesU3Ek__BackingField_0() { return &___U3CpropertiesU3Ek__BackingField_0; }
	inline void set_U3CpropertiesU3Ek__BackingField_0(MaterialPropertyBlock_t72A481768111C6F11DCDCD44F0C7F99F1CA79E13 * value)
	{
		___U3CpropertiesU3Ek__BackingField_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CpropertiesU3Ek__BackingField_0), value);
	}

	inline static int32_t get_offset_of_U3CmaterialU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212, ___U3CmaterialU3Ek__BackingField_1)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_U3CmaterialU3Ek__BackingField_1() const { return ___U3CmaterialU3Ek__BackingField_1; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_U3CmaterialU3Ek__BackingField_1() { return &___U3CmaterialU3Ek__BackingField_1; }
	inline void set_U3CmaterialU3Ek__BackingField_1(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___U3CmaterialU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CmaterialU3Ek__BackingField_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PROPERTYSHEET_T24C92FDC502E601797E65D23B427D05B15840212_H
#ifndef PROPERTYSHEETFACTORY_T50203E3FC9B139F932F1F4A135A9C64D954B2F68_H
#define PROPERTYSHEETFACTORY_T50203E3FC9B139F932F1F4A135A9C64D954B2F68_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PropertySheetFactory
struct  PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68  : public RuntimeObject
{
public:
	// System.Collections.Generic.Dictionary`2<UnityEngine.Shader,UnityEngine.Rendering.PostProcessing.PropertySheet> UnityEngine.Rendering.PostProcessing.PropertySheetFactory::m_Sheets
	Dictionary_2_t3B983DCBB826C3BCDD4CB9A885C115474EC7FACA * ___m_Sheets_0;

public:
	inline static int32_t get_offset_of_m_Sheets_0() { return static_cast<int32_t>(offsetof(PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68, ___m_Sheets_0)); }
	inline Dictionary_2_t3B983DCBB826C3BCDD4CB9A885C115474EC7FACA * get_m_Sheets_0() const { return ___m_Sheets_0; }
	inline Dictionary_2_t3B983DCBB826C3BCDD4CB9A885C115474EC7FACA ** get_address_of_m_Sheets_0() { return &___m_Sheets_0; }
	inline void set_m_Sheets_0(Dictionary_2_t3B983DCBB826C3BCDD4CB9A885C115474EC7FACA * value)
	{
		___m_Sheets_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_Sheets_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PROPERTYSHEETFACTORY_T50203E3FC9B139F932F1F4A135A9C64D954B2F68_H
#ifndef RUNTIMEUTILITIES_T9998328C3C1997217B0442B08ABE0A0122481C63_H
#define RUNTIMEUTILITIES_T9998328C3C1997217B0442B08ABE0A0122481C63_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.RuntimeUtilities
struct  RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63  : public RuntimeObject
{
public:

public:
};

struct RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields
{
public:
	// UnityEngine.Texture2D UnityEngine.Rendering.PostProcessing.RuntimeUtilities::m_WhiteTexture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___m_WhiteTexture_0;
	// UnityEngine.Texture3D UnityEngine.Rendering.PostProcessing.RuntimeUtilities::m_WhiteTexture3D
	Texture3D_t041D3C554E80910E92D1EAAA85E0F70655FD66B4 * ___m_WhiteTexture3D_1;
	// UnityEngine.Texture2D UnityEngine.Rendering.PostProcessing.RuntimeUtilities::m_BlackTexture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___m_BlackTexture_2;
	// UnityEngine.Texture3D UnityEngine.Rendering.PostProcessing.RuntimeUtilities::m_BlackTexture3D
	Texture3D_t041D3C554E80910E92D1EAAA85E0F70655FD66B4 * ___m_BlackTexture3D_3;
	// UnityEngine.Texture2D UnityEngine.Rendering.PostProcessing.RuntimeUtilities::m_TransparentTexture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___m_TransparentTexture_4;
	// UnityEngine.Texture3D UnityEngine.Rendering.PostProcessing.RuntimeUtilities::m_TransparentTexture3D
	Texture3D_t041D3C554E80910E92D1EAAA85E0F70655FD66B4 * ___m_TransparentTexture3D_5;
	// System.Collections.Generic.Dictionary`2<System.Int32,UnityEngine.Texture2D> UnityEngine.Rendering.PostProcessing.RuntimeUtilities::m_LutStrips
	Dictionary_2_t131B71940600DB8DE4DADE6242CE6287DEB55A04 * ___m_LutStrips_6;
	// UnityEngine.Rendering.PostProcessing.PostProcessResources UnityEngine.Rendering.PostProcessing.RuntimeUtilities::s_Resources
	PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 * ___s_Resources_7;
	// UnityEngine.Mesh UnityEngine.Rendering.PostProcessing.RuntimeUtilities::s_FullscreenTriangle
	Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * ___s_FullscreenTriangle_8;
	// UnityEngine.Material UnityEngine.Rendering.PostProcessing.RuntimeUtilities::s_CopyStdMaterial
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___s_CopyStdMaterial_9;
	// UnityEngine.Material UnityEngine.Rendering.PostProcessing.RuntimeUtilities::s_CopyStdFromDoubleWideMaterial
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___s_CopyStdFromDoubleWideMaterial_10;
	// UnityEngine.Material UnityEngine.Rendering.PostProcessing.RuntimeUtilities::s_CopyMaterial
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___s_CopyMaterial_11;
	// UnityEngine.Material UnityEngine.Rendering.PostProcessing.RuntimeUtilities::s_CopyFromTexArrayMaterial
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___s_CopyFromTexArrayMaterial_12;
	// UnityEngine.Rendering.PostProcessing.PropertySheet UnityEngine.Rendering.PostProcessing.RuntimeUtilities::s_CopySheet
	PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 * ___s_CopySheet_13;
	// UnityEngine.Rendering.PostProcessing.PropertySheet UnityEngine.Rendering.PostProcessing.RuntimeUtilities::s_CopyFromTexArraySheet
	PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 * ___s_CopyFromTexArraySheet_14;
	// System.Collections.Generic.IEnumerable`1<System.Type> UnityEngine.Rendering.PostProcessing.RuntimeUtilities::m_AssemblyTypes
	RuntimeObject* ___m_AssemblyTypes_15;

public:
	inline static int32_t get_offset_of_m_WhiteTexture_0() { return static_cast<int32_t>(offsetof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields, ___m_WhiteTexture_0)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_m_WhiteTexture_0() const { return ___m_WhiteTexture_0; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_m_WhiteTexture_0() { return &___m_WhiteTexture_0; }
	inline void set_m_WhiteTexture_0(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___m_WhiteTexture_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_WhiteTexture_0), value);
	}

	inline static int32_t get_offset_of_m_WhiteTexture3D_1() { return static_cast<int32_t>(offsetof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields, ___m_WhiteTexture3D_1)); }
	inline Texture3D_t041D3C554E80910E92D1EAAA85E0F70655FD66B4 * get_m_WhiteTexture3D_1() const { return ___m_WhiteTexture3D_1; }
	inline Texture3D_t041D3C554E80910E92D1EAAA85E0F70655FD66B4 ** get_address_of_m_WhiteTexture3D_1() { return &___m_WhiteTexture3D_1; }
	inline void set_m_WhiteTexture3D_1(Texture3D_t041D3C554E80910E92D1EAAA85E0F70655FD66B4 * value)
	{
		___m_WhiteTexture3D_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_WhiteTexture3D_1), value);
	}

	inline static int32_t get_offset_of_m_BlackTexture_2() { return static_cast<int32_t>(offsetof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields, ___m_BlackTexture_2)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_m_BlackTexture_2() const { return ___m_BlackTexture_2; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_m_BlackTexture_2() { return &___m_BlackTexture_2; }
	inline void set_m_BlackTexture_2(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___m_BlackTexture_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_BlackTexture_2), value);
	}

	inline static int32_t get_offset_of_m_BlackTexture3D_3() { return static_cast<int32_t>(offsetof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields, ___m_BlackTexture3D_3)); }
	inline Texture3D_t041D3C554E80910E92D1EAAA85E0F70655FD66B4 * get_m_BlackTexture3D_3() const { return ___m_BlackTexture3D_3; }
	inline Texture3D_t041D3C554E80910E92D1EAAA85E0F70655FD66B4 ** get_address_of_m_BlackTexture3D_3() { return &___m_BlackTexture3D_3; }
	inline void set_m_BlackTexture3D_3(Texture3D_t041D3C554E80910E92D1EAAA85E0F70655FD66B4 * value)
	{
		___m_BlackTexture3D_3 = value;
		Il2CppCodeGenWriteBarrier((&___m_BlackTexture3D_3), value);
	}

	inline static int32_t get_offset_of_m_TransparentTexture_4() { return static_cast<int32_t>(offsetof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields, ___m_TransparentTexture_4)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_m_TransparentTexture_4() const { return ___m_TransparentTexture_4; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_m_TransparentTexture_4() { return &___m_TransparentTexture_4; }
	inline void set_m_TransparentTexture_4(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___m_TransparentTexture_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_TransparentTexture_4), value);
	}

	inline static int32_t get_offset_of_m_TransparentTexture3D_5() { return static_cast<int32_t>(offsetof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields, ___m_TransparentTexture3D_5)); }
	inline Texture3D_t041D3C554E80910E92D1EAAA85E0F70655FD66B4 * get_m_TransparentTexture3D_5() const { return ___m_TransparentTexture3D_5; }
	inline Texture3D_t041D3C554E80910E92D1EAAA85E0F70655FD66B4 ** get_address_of_m_TransparentTexture3D_5() { return &___m_TransparentTexture3D_5; }
	inline void set_m_TransparentTexture3D_5(Texture3D_t041D3C554E80910E92D1EAAA85E0F70655FD66B4 * value)
	{
		___m_TransparentTexture3D_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_TransparentTexture3D_5), value);
	}

	inline static int32_t get_offset_of_m_LutStrips_6() { return static_cast<int32_t>(offsetof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields, ___m_LutStrips_6)); }
	inline Dictionary_2_t131B71940600DB8DE4DADE6242CE6287DEB55A04 * get_m_LutStrips_6() const { return ___m_LutStrips_6; }
	inline Dictionary_2_t131B71940600DB8DE4DADE6242CE6287DEB55A04 ** get_address_of_m_LutStrips_6() { return &___m_LutStrips_6; }
	inline void set_m_LutStrips_6(Dictionary_2_t131B71940600DB8DE4DADE6242CE6287DEB55A04 * value)
	{
		___m_LutStrips_6 = value;
		Il2CppCodeGenWriteBarrier((&___m_LutStrips_6), value);
	}

	inline static int32_t get_offset_of_s_Resources_7() { return static_cast<int32_t>(offsetof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields, ___s_Resources_7)); }
	inline PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 * get_s_Resources_7() const { return ___s_Resources_7; }
	inline PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 ** get_address_of_s_Resources_7() { return &___s_Resources_7; }
	inline void set_s_Resources_7(PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 * value)
	{
		___s_Resources_7 = value;
		Il2CppCodeGenWriteBarrier((&___s_Resources_7), value);
	}

	inline static int32_t get_offset_of_s_FullscreenTriangle_8() { return static_cast<int32_t>(offsetof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields, ___s_FullscreenTriangle_8)); }
	inline Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * get_s_FullscreenTriangle_8() const { return ___s_FullscreenTriangle_8; }
	inline Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C ** get_address_of_s_FullscreenTriangle_8() { return &___s_FullscreenTriangle_8; }
	inline void set_s_FullscreenTriangle_8(Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * value)
	{
		___s_FullscreenTriangle_8 = value;
		Il2CppCodeGenWriteBarrier((&___s_FullscreenTriangle_8), value);
	}

	inline static int32_t get_offset_of_s_CopyStdMaterial_9() { return static_cast<int32_t>(offsetof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields, ___s_CopyStdMaterial_9)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_s_CopyStdMaterial_9() const { return ___s_CopyStdMaterial_9; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_s_CopyStdMaterial_9() { return &___s_CopyStdMaterial_9; }
	inline void set_s_CopyStdMaterial_9(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___s_CopyStdMaterial_9 = value;
		Il2CppCodeGenWriteBarrier((&___s_CopyStdMaterial_9), value);
	}

	inline static int32_t get_offset_of_s_CopyStdFromDoubleWideMaterial_10() { return static_cast<int32_t>(offsetof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields, ___s_CopyStdFromDoubleWideMaterial_10)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_s_CopyStdFromDoubleWideMaterial_10() const { return ___s_CopyStdFromDoubleWideMaterial_10; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_s_CopyStdFromDoubleWideMaterial_10() { return &___s_CopyStdFromDoubleWideMaterial_10; }
	inline void set_s_CopyStdFromDoubleWideMaterial_10(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___s_CopyStdFromDoubleWideMaterial_10 = value;
		Il2CppCodeGenWriteBarrier((&___s_CopyStdFromDoubleWideMaterial_10), value);
	}

	inline static int32_t get_offset_of_s_CopyMaterial_11() { return static_cast<int32_t>(offsetof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields, ___s_CopyMaterial_11)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_s_CopyMaterial_11() const { return ___s_CopyMaterial_11; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_s_CopyMaterial_11() { return &___s_CopyMaterial_11; }
	inline void set_s_CopyMaterial_11(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___s_CopyMaterial_11 = value;
		Il2CppCodeGenWriteBarrier((&___s_CopyMaterial_11), value);
	}

	inline static int32_t get_offset_of_s_CopyFromTexArrayMaterial_12() { return static_cast<int32_t>(offsetof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields, ___s_CopyFromTexArrayMaterial_12)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_s_CopyFromTexArrayMaterial_12() const { return ___s_CopyFromTexArrayMaterial_12; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_s_CopyFromTexArrayMaterial_12() { return &___s_CopyFromTexArrayMaterial_12; }
	inline void set_s_CopyFromTexArrayMaterial_12(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___s_CopyFromTexArrayMaterial_12 = value;
		Il2CppCodeGenWriteBarrier((&___s_CopyFromTexArrayMaterial_12), value);
	}

	inline static int32_t get_offset_of_s_CopySheet_13() { return static_cast<int32_t>(offsetof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields, ___s_CopySheet_13)); }
	inline PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 * get_s_CopySheet_13() const { return ___s_CopySheet_13; }
	inline PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 ** get_address_of_s_CopySheet_13() { return &___s_CopySheet_13; }
	inline void set_s_CopySheet_13(PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 * value)
	{
		___s_CopySheet_13 = value;
		Il2CppCodeGenWriteBarrier((&___s_CopySheet_13), value);
	}

	inline static int32_t get_offset_of_s_CopyFromTexArraySheet_14() { return static_cast<int32_t>(offsetof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields, ___s_CopyFromTexArraySheet_14)); }
	inline PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 * get_s_CopyFromTexArraySheet_14() const { return ___s_CopyFromTexArraySheet_14; }
	inline PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 ** get_address_of_s_CopyFromTexArraySheet_14() { return &___s_CopyFromTexArraySheet_14; }
	inline void set_s_CopyFromTexArraySheet_14(PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 * value)
	{
		___s_CopyFromTexArraySheet_14 = value;
		Il2CppCodeGenWriteBarrier((&___s_CopyFromTexArraySheet_14), value);
	}

	inline static int32_t get_offset_of_m_AssemblyTypes_15() { return static_cast<int32_t>(offsetof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields, ___m_AssemblyTypes_15)); }
	inline RuntimeObject* get_m_AssemblyTypes_15() const { return ___m_AssemblyTypes_15; }
	inline RuntimeObject** get_address_of_m_AssemblyTypes_15() { return &___m_AssemblyTypes_15; }
	inline void set_m_AssemblyTypes_15(RuntimeObject* value)
	{
		___m_AssemblyTypes_15 = value;
		Il2CppCodeGenWriteBarrier((&___m_AssemblyTypes_15), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEUTILITIES_T9998328C3C1997217B0442B08ABE0A0122481C63_H
#ifndef U3CU3EC_T44F15B9D7FCBEA92C1FA19C255E68AB99C127FD8_H
#define U3CU3EC_T44F15B9D7FCBEA92C1FA19C255E68AB99C127FD8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.RuntimeUtilities_<>c
struct  U3CU3Ec_t44F15B9D7FCBEA92C1FA19C255E68AB99C127FD8  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_t44F15B9D7FCBEA92C1FA19C255E68AB99C127FD8_StaticFields
{
public:
	// UnityEngine.Rendering.PostProcessing.RuntimeUtilities_<>c UnityEngine.Rendering.PostProcessing.RuntimeUtilities_<>c::<>9
	U3CU3Ec_t44F15B9D7FCBEA92C1FA19C255E68AB99C127FD8 * ___U3CU3E9_0;
	// System.Func`2<System.Reflection.Assembly,System.Collections.Generic.IEnumerable`1<System.Type>> UnityEngine.Rendering.PostProcessing.RuntimeUtilities_<>c::<>9__87_0
	Func_2_t1DB78001C40A03A303D41DD7A89698AFAC67B86D * ___U3CU3E9__87_0_1;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_t44F15B9D7FCBEA92C1FA19C255E68AB99C127FD8_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_t44F15B9D7FCBEA92C1FA19C255E68AB99C127FD8 * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_t44F15B9D7FCBEA92C1FA19C255E68AB99C127FD8 ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_t44F15B9D7FCBEA92C1FA19C255E68AB99C127FD8 * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9_0), value);
	}

	inline static int32_t get_offset_of_U3CU3E9__87_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_t44F15B9D7FCBEA92C1FA19C255E68AB99C127FD8_StaticFields, ___U3CU3E9__87_0_1)); }
	inline Func_2_t1DB78001C40A03A303D41DD7A89698AFAC67B86D * get_U3CU3E9__87_0_1() const { return ___U3CU3E9__87_0_1; }
	inline Func_2_t1DB78001C40A03A303D41DD7A89698AFAC67B86D ** get_address_of_U3CU3E9__87_0_1() { return &___U3CU3E9__87_0_1; }
	inline void set_U3CU3E9__87_0_1(Func_2_t1DB78001C40A03A303D41DD7A89698AFAC67B86D * value)
	{
		___U3CU3E9__87_0_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CU3E9__87_0_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC_T44F15B9D7FCBEA92C1FA19C255E68AB99C127FD8_H
#ifndef SHADERIDS_T50801F2461934475540F10C0595A9C3AF7459A22_H
#define SHADERIDS_T50801F2461934475540F10C0595A9C3AF7459A22_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ShaderIDs
struct  ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22  : public RuntimeObject
{
public:

public:
};

struct ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::MainTex
	int32_t ___MainTex_0;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Jitter
	int32_t ___Jitter_1;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Sharpness
	int32_t ___Sharpness_2;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::FinalBlendParameters
	int32_t ___FinalBlendParameters_3;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::HistoryTex
	int32_t ___HistoryTex_4;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::SMAA_Flip
	int32_t ___SMAA_Flip_5;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::SMAA_Flop
	int32_t ___SMAA_Flop_6;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::AOParams
	int32_t ___AOParams_7;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::AOColor
	int32_t ___AOColor_8;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::OcclusionTexture1
	int32_t ___OcclusionTexture1_9;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::OcclusionTexture2
	int32_t ___OcclusionTexture2_10;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::SAOcclusionTexture
	int32_t ___SAOcclusionTexture_11;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::MSVOcclusionTexture
	int32_t ___MSVOcclusionTexture_12;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::DepthCopy
	int32_t ___DepthCopy_13;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::LinearDepth
	int32_t ___LinearDepth_14;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::LowDepth1
	int32_t ___LowDepth1_15;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::LowDepth2
	int32_t ___LowDepth2_16;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::LowDepth3
	int32_t ___LowDepth3_17;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::LowDepth4
	int32_t ___LowDepth4_18;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::TiledDepth1
	int32_t ___TiledDepth1_19;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::TiledDepth2
	int32_t ___TiledDepth2_20;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::TiledDepth3
	int32_t ___TiledDepth3_21;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::TiledDepth4
	int32_t ___TiledDepth4_22;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Occlusion1
	int32_t ___Occlusion1_23;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Occlusion2
	int32_t ___Occlusion2_24;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Occlusion3
	int32_t ___Occlusion3_25;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Occlusion4
	int32_t ___Occlusion4_26;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Combined1
	int32_t ___Combined1_27;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Combined2
	int32_t ___Combined2_28;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Combined3
	int32_t ___Combined3_29;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::SSRResolveTemp
	int32_t ___SSRResolveTemp_30;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Noise
	int32_t ___Noise_31;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Test
	int32_t ___Test_32;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Resolve
	int32_t ___Resolve_33;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::History
	int32_t ___History_34;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::ViewMatrix
	int32_t ___ViewMatrix_35;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::InverseViewMatrix
	int32_t ___InverseViewMatrix_36;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::InverseProjectionMatrix
	int32_t ___InverseProjectionMatrix_37;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::ScreenSpaceProjectionMatrix
	int32_t ___ScreenSpaceProjectionMatrix_38;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Params2
	int32_t ___Params2_39;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::FogColor
	int32_t ___FogColor_40;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::FogParams
	int32_t ___FogParams_41;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::VelocityScale
	int32_t ___VelocityScale_42;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::MaxBlurRadius
	int32_t ___MaxBlurRadius_43;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::RcpMaxBlurRadius
	int32_t ___RcpMaxBlurRadius_44;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::VelocityTex
	int32_t ___VelocityTex_45;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Tile2RT
	int32_t ___Tile2RT_46;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Tile4RT
	int32_t ___Tile4RT_47;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Tile8RT
	int32_t ___Tile8RT_48;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::TileMaxOffs
	int32_t ___TileMaxOffs_49;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::TileMaxLoop
	int32_t ___TileMaxLoop_50;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::TileVRT
	int32_t ___TileVRT_51;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::NeighborMaxTex
	int32_t ___NeighborMaxTex_52;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::LoopCount
	int32_t ___LoopCount_53;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::DepthOfFieldTemp
	int32_t ___DepthOfFieldTemp_54;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::DepthOfFieldTex
	int32_t ___DepthOfFieldTex_55;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Distance
	int32_t ___Distance_56;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::LensCoeff
	int32_t ___LensCoeff_57;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::MaxCoC
	int32_t ___MaxCoC_58;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::RcpMaxCoC
	int32_t ___RcpMaxCoC_59;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::RcpAspect
	int32_t ___RcpAspect_60;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::CoCTex
	int32_t ___CoCTex_61;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::TaaParams
	int32_t ___TaaParams_62;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::AutoExposureTex
	int32_t ___AutoExposureTex_63;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::HistogramBuffer
	int32_t ___HistogramBuffer_64;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Params
	int32_t ___Params_65;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::ScaleOffsetRes
	int32_t ___ScaleOffsetRes_66;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::BloomTex
	int32_t ___BloomTex_67;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::SampleScale
	int32_t ___SampleScale_68;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Threshold
	int32_t ___Threshold_69;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::ColorIntensity
	int32_t ___ColorIntensity_70;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Bloom_DirtTex
	int32_t ___Bloom_DirtTex_71;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Bloom_Settings
	int32_t ___Bloom_Settings_72;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Bloom_Color
	int32_t ___Bloom_Color_73;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Bloom_DirtTileOffset
	int32_t ___Bloom_DirtTileOffset_74;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::ChromaticAberration_Amount
	int32_t ___ChromaticAberration_Amount_75;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::ChromaticAberration_SpectralLut
	int32_t ___ChromaticAberration_SpectralLut_76;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Distortion_CenterScale
	int32_t ___Distortion_CenterScale_77;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Distortion_Amount
	int32_t ___Distortion_Amount_78;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Lut2D
	int32_t ___Lut2D_79;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Lut3D
	int32_t ___Lut3D_80;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Lut3D_Params
	int32_t ___Lut3D_Params_81;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Lut2D_Params
	int32_t ___Lut2D_Params_82;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::UserLut2D_Params
	int32_t ___UserLut2D_Params_83;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::PostExposure
	int32_t ___PostExposure_84;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::ColorBalance
	int32_t ___ColorBalance_85;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::ColorFilter
	int32_t ___ColorFilter_86;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::HueSatCon
	int32_t ___HueSatCon_87;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Brightness
	int32_t ___Brightness_88;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::ChannelMixerRed
	int32_t ___ChannelMixerRed_89;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::ChannelMixerGreen
	int32_t ___ChannelMixerGreen_90;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::ChannelMixerBlue
	int32_t ___ChannelMixerBlue_91;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Lift
	int32_t ___Lift_92;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::InvGamma
	int32_t ___InvGamma_93;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Gain
	int32_t ___Gain_94;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Curves
	int32_t ___Curves_95;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::CustomToneCurve
	int32_t ___CustomToneCurve_96;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::ToeSegmentA
	int32_t ___ToeSegmentA_97;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::ToeSegmentB
	int32_t ___ToeSegmentB_98;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::MidSegmentA
	int32_t ___MidSegmentA_99;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::MidSegmentB
	int32_t ___MidSegmentB_100;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::ShoSegmentA
	int32_t ___ShoSegmentA_101;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::ShoSegmentB
	int32_t ___ShoSegmentB_102;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Vignette_Color
	int32_t ___Vignette_Color_103;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Vignette_Center
	int32_t ___Vignette_Center_104;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Vignette_Settings
	int32_t ___Vignette_Settings_105;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Vignette_Mask
	int32_t ___Vignette_Mask_106;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Vignette_Opacity
	int32_t ___Vignette_Opacity_107;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Vignette_Mode
	int32_t ___Vignette_Mode_108;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Grain_Params1
	int32_t ___Grain_Params1_109;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Grain_Params2
	int32_t ___Grain_Params2_110;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::GrainTex
	int32_t ___GrainTex_111;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Phase
	int32_t ___Phase_112;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::GrainNoiseParameters
	int32_t ___GrainNoiseParameters_113;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::LumaInAlpha
	int32_t ___LumaInAlpha_114;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::DitheringTex
	int32_t ___DitheringTex_115;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Dithering_Coords
	int32_t ___Dithering_Coords_116;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::From
	int32_t ___From_117;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::To
	int32_t ___To_118;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::Interp
	int32_t ___Interp_119;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::TargetColor
	int32_t ___TargetColor_120;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::HalfResFinalCopy
	int32_t ___HalfResFinalCopy_121;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::WaveformSource
	int32_t ___WaveformSource_122;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::WaveformBuffer
	int32_t ___WaveformBuffer_123;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::VectorscopeBuffer
	int32_t ___VectorscopeBuffer_124;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::RenderViewportScaleFactor
	int32_t ___RenderViewportScaleFactor_125;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::UVTransform
	int32_t ___UVTransform_126;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::DepthSlice
	int32_t ___DepthSlice_127;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::UVScaleOffset
	int32_t ___UVScaleOffset_128;
	// System.Int32 UnityEngine.Rendering.PostProcessing.ShaderIDs::PosScaleOffset
	int32_t ___PosScaleOffset_129;

public:
	inline static int32_t get_offset_of_MainTex_0() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___MainTex_0)); }
	inline int32_t get_MainTex_0() const { return ___MainTex_0; }
	inline int32_t* get_address_of_MainTex_0() { return &___MainTex_0; }
	inline void set_MainTex_0(int32_t value)
	{
		___MainTex_0 = value;
	}

	inline static int32_t get_offset_of_Jitter_1() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Jitter_1)); }
	inline int32_t get_Jitter_1() const { return ___Jitter_1; }
	inline int32_t* get_address_of_Jitter_1() { return &___Jitter_1; }
	inline void set_Jitter_1(int32_t value)
	{
		___Jitter_1 = value;
	}

	inline static int32_t get_offset_of_Sharpness_2() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Sharpness_2)); }
	inline int32_t get_Sharpness_2() const { return ___Sharpness_2; }
	inline int32_t* get_address_of_Sharpness_2() { return &___Sharpness_2; }
	inline void set_Sharpness_2(int32_t value)
	{
		___Sharpness_2 = value;
	}

	inline static int32_t get_offset_of_FinalBlendParameters_3() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___FinalBlendParameters_3)); }
	inline int32_t get_FinalBlendParameters_3() const { return ___FinalBlendParameters_3; }
	inline int32_t* get_address_of_FinalBlendParameters_3() { return &___FinalBlendParameters_3; }
	inline void set_FinalBlendParameters_3(int32_t value)
	{
		___FinalBlendParameters_3 = value;
	}

	inline static int32_t get_offset_of_HistoryTex_4() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___HistoryTex_4)); }
	inline int32_t get_HistoryTex_4() const { return ___HistoryTex_4; }
	inline int32_t* get_address_of_HistoryTex_4() { return &___HistoryTex_4; }
	inline void set_HistoryTex_4(int32_t value)
	{
		___HistoryTex_4 = value;
	}

	inline static int32_t get_offset_of_SMAA_Flip_5() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___SMAA_Flip_5)); }
	inline int32_t get_SMAA_Flip_5() const { return ___SMAA_Flip_5; }
	inline int32_t* get_address_of_SMAA_Flip_5() { return &___SMAA_Flip_5; }
	inline void set_SMAA_Flip_5(int32_t value)
	{
		___SMAA_Flip_5 = value;
	}

	inline static int32_t get_offset_of_SMAA_Flop_6() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___SMAA_Flop_6)); }
	inline int32_t get_SMAA_Flop_6() const { return ___SMAA_Flop_6; }
	inline int32_t* get_address_of_SMAA_Flop_6() { return &___SMAA_Flop_6; }
	inline void set_SMAA_Flop_6(int32_t value)
	{
		___SMAA_Flop_6 = value;
	}

	inline static int32_t get_offset_of_AOParams_7() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___AOParams_7)); }
	inline int32_t get_AOParams_7() const { return ___AOParams_7; }
	inline int32_t* get_address_of_AOParams_7() { return &___AOParams_7; }
	inline void set_AOParams_7(int32_t value)
	{
		___AOParams_7 = value;
	}

	inline static int32_t get_offset_of_AOColor_8() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___AOColor_8)); }
	inline int32_t get_AOColor_8() const { return ___AOColor_8; }
	inline int32_t* get_address_of_AOColor_8() { return &___AOColor_8; }
	inline void set_AOColor_8(int32_t value)
	{
		___AOColor_8 = value;
	}

	inline static int32_t get_offset_of_OcclusionTexture1_9() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___OcclusionTexture1_9)); }
	inline int32_t get_OcclusionTexture1_9() const { return ___OcclusionTexture1_9; }
	inline int32_t* get_address_of_OcclusionTexture1_9() { return &___OcclusionTexture1_9; }
	inline void set_OcclusionTexture1_9(int32_t value)
	{
		___OcclusionTexture1_9 = value;
	}

	inline static int32_t get_offset_of_OcclusionTexture2_10() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___OcclusionTexture2_10)); }
	inline int32_t get_OcclusionTexture2_10() const { return ___OcclusionTexture2_10; }
	inline int32_t* get_address_of_OcclusionTexture2_10() { return &___OcclusionTexture2_10; }
	inline void set_OcclusionTexture2_10(int32_t value)
	{
		___OcclusionTexture2_10 = value;
	}

	inline static int32_t get_offset_of_SAOcclusionTexture_11() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___SAOcclusionTexture_11)); }
	inline int32_t get_SAOcclusionTexture_11() const { return ___SAOcclusionTexture_11; }
	inline int32_t* get_address_of_SAOcclusionTexture_11() { return &___SAOcclusionTexture_11; }
	inline void set_SAOcclusionTexture_11(int32_t value)
	{
		___SAOcclusionTexture_11 = value;
	}

	inline static int32_t get_offset_of_MSVOcclusionTexture_12() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___MSVOcclusionTexture_12)); }
	inline int32_t get_MSVOcclusionTexture_12() const { return ___MSVOcclusionTexture_12; }
	inline int32_t* get_address_of_MSVOcclusionTexture_12() { return &___MSVOcclusionTexture_12; }
	inline void set_MSVOcclusionTexture_12(int32_t value)
	{
		___MSVOcclusionTexture_12 = value;
	}

	inline static int32_t get_offset_of_DepthCopy_13() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___DepthCopy_13)); }
	inline int32_t get_DepthCopy_13() const { return ___DepthCopy_13; }
	inline int32_t* get_address_of_DepthCopy_13() { return &___DepthCopy_13; }
	inline void set_DepthCopy_13(int32_t value)
	{
		___DepthCopy_13 = value;
	}

	inline static int32_t get_offset_of_LinearDepth_14() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___LinearDepth_14)); }
	inline int32_t get_LinearDepth_14() const { return ___LinearDepth_14; }
	inline int32_t* get_address_of_LinearDepth_14() { return &___LinearDepth_14; }
	inline void set_LinearDepth_14(int32_t value)
	{
		___LinearDepth_14 = value;
	}

	inline static int32_t get_offset_of_LowDepth1_15() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___LowDepth1_15)); }
	inline int32_t get_LowDepth1_15() const { return ___LowDepth1_15; }
	inline int32_t* get_address_of_LowDepth1_15() { return &___LowDepth1_15; }
	inline void set_LowDepth1_15(int32_t value)
	{
		___LowDepth1_15 = value;
	}

	inline static int32_t get_offset_of_LowDepth2_16() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___LowDepth2_16)); }
	inline int32_t get_LowDepth2_16() const { return ___LowDepth2_16; }
	inline int32_t* get_address_of_LowDepth2_16() { return &___LowDepth2_16; }
	inline void set_LowDepth2_16(int32_t value)
	{
		___LowDepth2_16 = value;
	}

	inline static int32_t get_offset_of_LowDepth3_17() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___LowDepth3_17)); }
	inline int32_t get_LowDepth3_17() const { return ___LowDepth3_17; }
	inline int32_t* get_address_of_LowDepth3_17() { return &___LowDepth3_17; }
	inline void set_LowDepth3_17(int32_t value)
	{
		___LowDepth3_17 = value;
	}

	inline static int32_t get_offset_of_LowDepth4_18() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___LowDepth4_18)); }
	inline int32_t get_LowDepth4_18() const { return ___LowDepth4_18; }
	inline int32_t* get_address_of_LowDepth4_18() { return &___LowDepth4_18; }
	inline void set_LowDepth4_18(int32_t value)
	{
		___LowDepth4_18 = value;
	}

	inline static int32_t get_offset_of_TiledDepth1_19() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___TiledDepth1_19)); }
	inline int32_t get_TiledDepth1_19() const { return ___TiledDepth1_19; }
	inline int32_t* get_address_of_TiledDepth1_19() { return &___TiledDepth1_19; }
	inline void set_TiledDepth1_19(int32_t value)
	{
		___TiledDepth1_19 = value;
	}

	inline static int32_t get_offset_of_TiledDepth2_20() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___TiledDepth2_20)); }
	inline int32_t get_TiledDepth2_20() const { return ___TiledDepth2_20; }
	inline int32_t* get_address_of_TiledDepth2_20() { return &___TiledDepth2_20; }
	inline void set_TiledDepth2_20(int32_t value)
	{
		___TiledDepth2_20 = value;
	}

	inline static int32_t get_offset_of_TiledDepth3_21() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___TiledDepth3_21)); }
	inline int32_t get_TiledDepth3_21() const { return ___TiledDepth3_21; }
	inline int32_t* get_address_of_TiledDepth3_21() { return &___TiledDepth3_21; }
	inline void set_TiledDepth3_21(int32_t value)
	{
		___TiledDepth3_21 = value;
	}

	inline static int32_t get_offset_of_TiledDepth4_22() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___TiledDepth4_22)); }
	inline int32_t get_TiledDepth4_22() const { return ___TiledDepth4_22; }
	inline int32_t* get_address_of_TiledDepth4_22() { return &___TiledDepth4_22; }
	inline void set_TiledDepth4_22(int32_t value)
	{
		___TiledDepth4_22 = value;
	}

	inline static int32_t get_offset_of_Occlusion1_23() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Occlusion1_23)); }
	inline int32_t get_Occlusion1_23() const { return ___Occlusion1_23; }
	inline int32_t* get_address_of_Occlusion1_23() { return &___Occlusion1_23; }
	inline void set_Occlusion1_23(int32_t value)
	{
		___Occlusion1_23 = value;
	}

	inline static int32_t get_offset_of_Occlusion2_24() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Occlusion2_24)); }
	inline int32_t get_Occlusion2_24() const { return ___Occlusion2_24; }
	inline int32_t* get_address_of_Occlusion2_24() { return &___Occlusion2_24; }
	inline void set_Occlusion2_24(int32_t value)
	{
		___Occlusion2_24 = value;
	}

	inline static int32_t get_offset_of_Occlusion3_25() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Occlusion3_25)); }
	inline int32_t get_Occlusion3_25() const { return ___Occlusion3_25; }
	inline int32_t* get_address_of_Occlusion3_25() { return &___Occlusion3_25; }
	inline void set_Occlusion3_25(int32_t value)
	{
		___Occlusion3_25 = value;
	}

	inline static int32_t get_offset_of_Occlusion4_26() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Occlusion4_26)); }
	inline int32_t get_Occlusion4_26() const { return ___Occlusion4_26; }
	inline int32_t* get_address_of_Occlusion4_26() { return &___Occlusion4_26; }
	inline void set_Occlusion4_26(int32_t value)
	{
		___Occlusion4_26 = value;
	}

	inline static int32_t get_offset_of_Combined1_27() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Combined1_27)); }
	inline int32_t get_Combined1_27() const { return ___Combined1_27; }
	inline int32_t* get_address_of_Combined1_27() { return &___Combined1_27; }
	inline void set_Combined1_27(int32_t value)
	{
		___Combined1_27 = value;
	}

	inline static int32_t get_offset_of_Combined2_28() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Combined2_28)); }
	inline int32_t get_Combined2_28() const { return ___Combined2_28; }
	inline int32_t* get_address_of_Combined2_28() { return &___Combined2_28; }
	inline void set_Combined2_28(int32_t value)
	{
		___Combined2_28 = value;
	}

	inline static int32_t get_offset_of_Combined3_29() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Combined3_29)); }
	inline int32_t get_Combined3_29() const { return ___Combined3_29; }
	inline int32_t* get_address_of_Combined3_29() { return &___Combined3_29; }
	inline void set_Combined3_29(int32_t value)
	{
		___Combined3_29 = value;
	}

	inline static int32_t get_offset_of_SSRResolveTemp_30() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___SSRResolveTemp_30)); }
	inline int32_t get_SSRResolveTemp_30() const { return ___SSRResolveTemp_30; }
	inline int32_t* get_address_of_SSRResolveTemp_30() { return &___SSRResolveTemp_30; }
	inline void set_SSRResolveTemp_30(int32_t value)
	{
		___SSRResolveTemp_30 = value;
	}

	inline static int32_t get_offset_of_Noise_31() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Noise_31)); }
	inline int32_t get_Noise_31() const { return ___Noise_31; }
	inline int32_t* get_address_of_Noise_31() { return &___Noise_31; }
	inline void set_Noise_31(int32_t value)
	{
		___Noise_31 = value;
	}

	inline static int32_t get_offset_of_Test_32() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Test_32)); }
	inline int32_t get_Test_32() const { return ___Test_32; }
	inline int32_t* get_address_of_Test_32() { return &___Test_32; }
	inline void set_Test_32(int32_t value)
	{
		___Test_32 = value;
	}

	inline static int32_t get_offset_of_Resolve_33() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Resolve_33)); }
	inline int32_t get_Resolve_33() const { return ___Resolve_33; }
	inline int32_t* get_address_of_Resolve_33() { return &___Resolve_33; }
	inline void set_Resolve_33(int32_t value)
	{
		___Resolve_33 = value;
	}

	inline static int32_t get_offset_of_History_34() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___History_34)); }
	inline int32_t get_History_34() const { return ___History_34; }
	inline int32_t* get_address_of_History_34() { return &___History_34; }
	inline void set_History_34(int32_t value)
	{
		___History_34 = value;
	}

	inline static int32_t get_offset_of_ViewMatrix_35() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___ViewMatrix_35)); }
	inline int32_t get_ViewMatrix_35() const { return ___ViewMatrix_35; }
	inline int32_t* get_address_of_ViewMatrix_35() { return &___ViewMatrix_35; }
	inline void set_ViewMatrix_35(int32_t value)
	{
		___ViewMatrix_35 = value;
	}

	inline static int32_t get_offset_of_InverseViewMatrix_36() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___InverseViewMatrix_36)); }
	inline int32_t get_InverseViewMatrix_36() const { return ___InverseViewMatrix_36; }
	inline int32_t* get_address_of_InverseViewMatrix_36() { return &___InverseViewMatrix_36; }
	inline void set_InverseViewMatrix_36(int32_t value)
	{
		___InverseViewMatrix_36 = value;
	}

	inline static int32_t get_offset_of_InverseProjectionMatrix_37() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___InverseProjectionMatrix_37)); }
	inline int32_t get_InverseProjectionMatrix_37() const { return ___InverseProjectionMatrix_37; }
	inline int32_t* get_address_of_InverseProjectionMatrix_37() { return &___InverseProjectionMatrix_37; }
	inline void set_InverseProjectionMatrix_37(int32_t value)
	{
		___InverseProjectionMatrix_37 = value;
	}

	inline static int32_t get_offset_of_ScreenSpaceProjectionMatrix_38() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___ScreenSpaceProjectionMatrix_38)); }
	inline int32_t get_ScreenSpaceProjectionMatrix_38() const { return ___ScreenSpaceProjectionMatrix_38; }
	inline int32_t* get_address_of_ScreenSpaceProjectionMatrix_38() { return &___ScreenSpaceProjectionMatrix_38; }
	inline void set_ScreenSpaceProjectionMatrix_38(int32_t value)
	{
		___ScreenSpaceProjectionMatrix_38 = value;
	}

	inline static int32_t get_offset_of_Params2_39() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Params2_39)); }
	inline int32_t get_Params2_39() const { return ___Params2_39; }
	inline int32_t* get_address_of_Params2_39() { return &___Params2_39; }
	inline void set_Params2_39(int32_t value)
	{
		___Params2_39 = value;
	}

	inline static int32_t get_offset_of_FogColor_40() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___FogColor_40)); }
	inline int32_t get_FogColor_40() const { return ___FogColor_40; }
	inline int32_t* get_address_of_FogColor_40() { return &___FogColor_40; }
	inline void set_FogColor_40(int32_t value)
	{
		___FogColor_40 = value;
	}

	inline static int32_t get_offset_of_FogParams_41() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___FogParams_41)); }
	inline int32_t get_FogParams_41() const { return ___FogParams_41; }
	inline int32_t* get_address_of_FogParams_41() { return &___FogParams_41; }
	inline void set_FogParams_41(int32_t value)
	{
		___FogParams_41 = value;
	}

	inline static int32_t get_offset_of_VelocityScale_42() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___VelocityScale_42)); }
	inline int32_t get_VelocityScale_42() const { return ___VelocityScale_42; }
	inline int32_t* get_address_of_VelocityScale_42() { return &___VelocityScale_42; }
	inline void set_VelocityScale_42(int32_t value)
	{
		___VelocityScale_42 = value;
	}

	inline static int32_t get_offset_of_MaxBlurRadius_43() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___MaxBlurRadius_43)); }
	inline int32_t get_MaxBlurRadius_43() const { return ___MaxBlurRadius_43; }
	inline int32_t* get_address_of_MaxBlurRadius_43() { return &___MaxBlurRadius_43; }
	inline void set_MaxBlurRadius_43(int32_t value)
	{
		___MaxBlurRadius_43 = value;
	}

	inline static int32_t get_offset_of_RcpMaxBlurRadius_44() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___RcpMaxBlurRadius_44)); }
	inline int32_t get_RcpMaxBlurRadius_44() const { return ___RcpMaxBlurRadius_44; }
	inline int32_t* get_address_of_RcpMaxBlurRadius_44() { return &___RcpMaxBlurRadius_44; }
	inline void set_RcpMaxBlurRadius_44(int32_t value)
	{
		___RcpMaxBlurRadius_44 = value;
	}

	inline static int32_t get_offset_of_VelocityTex_45() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___VelocityTex_45)); }
	inline int32_t get_VelocityTex_45() const { return ___VelocityTex_45; }
	inline int32_t* get_address_of_VelocityTex_45() { return &___VelocityTex_45; }
	inline void set_VelocityTex_45(int32_t value)
	{
		___VelocityTex_45 = value;
	}

	inline static int32_t get_offset_of_Tile2RT_46() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Tile2RT_46)); }
	inline int32_t get_Tile2RT_46() const { return ___Tile2RT_46; }
	inline int32_t* get_address_of_Tile2RT_46() { return &___Tile2RT_46; }
	inline void set_Tile2RT_46(int32_t value)
	{
		___Tile2RT_46 = value;
	}

	inline static int32_t get_offset_of_Tile4RT_47() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Tile4RT_47)); }
	inline int32_t get_Tile4RT_47() const { return ___Tile4RT_47; }
	inline int32_t* get_address_of_Tile4RT_47() { return &___Tile4RT_47; }
	inline void set_Tile4RT_47(int32_t value)
	{
		___Tile4RT_47 = value;
	}

	inline static int32_t get_offset_of_Tile8RT_48() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Tile8RT_48)); }
	inline int32_t get_Tile8RT_48() const { return ___Tile8RT_48; }
	inline int32_t* get_address_of_Tile8RT_48() { return &___Tile8RT_48; }
	inline void set_Tile8RT_48(int32_t value)
	{
		___Tile8RT_48 = value;
	}

	inline static int32_t get_offset_of_TileMaxOffs_49() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___TileMaxOffs_49)); }
	inline int32_t get_TileMaxOffs_49() const { return ___TileMaxOffs_49; }
	inline int32_t* get_address_of_TileMaxOffs_49() { return &___TileMaxOffs_49; }
	inline void set_TileMaxOffs_49(int32_t value)
	{
		___TileMaxOffs_49 = value;
	}

	inline static int32_t get_offset_of_TileMaxLoop_50() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___TileMaxLoop_50)); }
	inline int32_t get_TileMaxLoop_50() const { return ___TileMaxLoop_50; }
	inline int32_t* get_address_of_TileMaxLoop_50() { return &___TileMaxLoop_50; }
	inline void set_TileMaxLoop_50(int32_t value)
	{
		___TileMaxLoop_50 = value;
	}

	inline static int32_t get_offset_of_TileVRT_51() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___TileVRT_51)); }
	inline int32_t get_TileVRT_51() const { return ___TileVRT_51; }
	inline int32_t* get_address_of_TileVRT_51() { return &___TileVRT_51; }
	inline void set_TileVRT_51(int32_t value)
	{
		___TileVRT_51 = value;
	}

	inline static int32_t get_offset_of_NeighborMaxTex_52() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___NeighborMaxTex_52)); }
	inline int32_t get_NeighborMaxTex_52() const { return ___NeighborMaxTex_52; }
	inline int32_t* get_address_of_NeighborMaxTex_52() { return &___NeighborMaxTex_52; }
	inline void set_NeighborMaxTex_52(int32_t value)
	{
		___NeighborMaxTex_52 = value;
	}

	inline static int32_t get_offset_of_LoopCount_53() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___LoopCount_53)); }
	inline int32_t get_LoopCount_53() const { return ___LoopCount_53; }
	inline int32_t* get_address_of_LoopCount_53() { return &___LoopCount_53; }
	inline void set_LoopCount_53(int32_t value)
	{
		___LoopCount_53 = value;
	}

	inline static int32_t get_offset_of_DepthOfFieldTemp_54() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___DepthOfFieldTemp_54)); }
	inline int32_t get_DepthOfFieldTemp_54() const { return ___DepthOfFieldTemp_54; }
	inline int32_t* get_address_of_DepthOfFieldTemp_54() { return &___DepthOfFieldTemp_54; }
	inline void set_DepthOfFieldTemp_54(int32_t value)
	{
		___DepthOfFieldTemp_54 = value;
	}

	inline static int32_t get_offset_of_DepthOfFieldTex_55() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___DepthOfFieldTex_55)); }
	inline int32_t get_DepthOfFieldTex_55() const { return ___DepthOfFieldTex_55; }
	inline int32_t* get_address_of_DepthOfFieldTex_55() { return &___DepthOfFieldTex_55; }
	inline void set_DepthOfFieldTex_55(int32_t value)
	{
		___DepthOfFieldTex_55 = value;
	}

	inline static int32_t get_offset_of_Distance_56() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Distance_56)); }
	inline int32_t get_Distance_56() const { return ___Distance_56; }
	inline int32_t* get_address_of_Distance_56() { return &___Distance_56; }
	inline void set_Distance_56(int32_t value)
	{
		___Distance_56 = value;
	}

	inline static int32_t get_offset_of_LensCoeff_57() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___LensCoeff_57)); }
	inline int32_t get_LensCoeff_57() const { return ___LensCoeff_57; }
	inline int32_t* get_address_of_LensCoeff_57() { return &___LensCoeff_57; }
	inline void set_LensCoeff_57(int32_t value)
	{
		___LensCoeff_57 = value;
	}

	inline static int32_t get_offset_of_MaxCoC_58() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___MaxCoC_58)); }
	inline int32_t get_MaxCoC_58() const { return ___MaxCoC_58; }
	inline int32_t* get_address_of_MaxCoC_58() { return &___MaxCoC_58; }
	inline void set_MaxCoC_58(int32_t value)
	{
		___MaxCoC_58 = value;
	}

	inline static int32_t get_offset_of_RcpMaxCoC_59() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___RcpMaxCoC_59)); }
	inline int32_t get_RcpMaxCoC_59() const { return ___RcpMaxCoC_59; }
	inline int32_t* get_address_of_RcpMaxCoC_59() { return &___RcpMaxCoC_59; }
	inline void set_RcpMaxCoC_59(int32_t value)
	{
		___RcpMaxCoC_59 = value;
	}

	inline static int32_t get_offset_of_RcpAspect_60() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___RcpAspect_60)); }
	inline int32_t get_RcpAspect_60() const { return ___RcpAspect_60; }
	inline int32_t* get_address_of_RcpAspect_60() { return &___RcpAspect_60; }
	inline void set_RcpAspect_60(int32_t value)
	{
		___RcpAspect_60 = value;
	}

	inline static int32_t get_offset_of_CoCTex_61() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___CoCTex_61)); }
	inline int32_t get_CoCTex_61() const { return ___CoCTex_61; }
	inline int32_t* get_address_of_CoCTex_61() { return &___CoCTex_61; }
	inline void set_CoCTex_61(int32_t value)
	{
		___CoCTex_61 = value;
	}

	inline static int32_t get_offset_of_TaaParams_62() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___TaaParams_62)); }
	inline int32_t get_TaaParams_62() const { return ___TaaParams_62; }
	inline int32_t* get_address_of_TaaParams_62() { return &___TaaParams_62; }
	inline void set_TaaParams_62(int32_t value)
	{
		___TaaParams_62 = value;
	}

	inline static int32_t get_offset_of_AutoExposureTex_63() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___AutoExposureTex_63)); }
	inline int32_t get_AutoExposureTex_63() const { return ___AutoExposureTex_63; }
	inline int32_t* get_address_of_AutoExposureTex_63() { return &___AutoExposureTex_63; }
	inline void set_AutoExposureTex_63(int32_t value)
	{
		___AutoExposureTex_63 = value;
	}

	inline static int32_t get_offset_of_HistogramBuffer_64() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___HistogramBuffer_64)); }
	inline int32_t get_HistogramBuffer_64() const { return ___HistogramBuffer_64; }
	inline int32_t* get_address_of_HistogramBuffer_64() { return &___HistogramBuffer_64; }
	inline void set_HistogramBuffer_64(int32_t value)
	{
		___HistogramBuffer_64 = value;
	}

	inline static int32_t get_offset_of_Params_65() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Params_65)); }
	inline int32_t get_Params_65() const { return ___Params_65; }
	inline int32_t* get_address_of_Params_65() { return &___Params_65; }
	inline void set_Params_65(int32_t value)
	{
		___Params_65 = value;
	}

	inline static int32_t get_offset_of_ScaleOffsetRes_66() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___ScaleOffsetRes_66)); }
	inline int32_t get_ScaleOffsetRes_66() const { return ___ScaleOffsetRes_66; }
	inline int32_t* get_address_of_ScaleOffsetRes_66() { return &___ScaleOffsetRes_66; }
	inline void set_ScaleOffsetRes_66(int32_t value)
	{
		___ScaleOffsetRes_66 = value;
	}

	inline static int32_t get_offset_of_BloomTex_67() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___BloomTex_67)); }
	inline int32_t get_BloomTex_67() const { return ___BloomTex_67; }
	inline int32_t* get_address_of_BloomTex_67() { return &___BloomTex_67; }
	inline void set_BloomTex_67(int32_t value)
	{
		___BloomTex_67 = value;
	}

	inline static int32_t get_offset_of_SampleScale_68() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___SampleScale_68)); }
	inline int32_t get_SampleScale_68() const { return ___SampleScale_68; }
	inline int32_t* get_address_of_SampleScale_68() { return &___SampleScale_68; }
	inline void set_SampleScale_68(int32_t value)
	{
		___SampleScale_68 = value;
	}

	inline static int32_t get_offset_of_Threshold_69() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Threshold_69)); }
	inline int32_t get_Threshold_69() const { return ___Threshold_69; }
	inline int32_t* get_address_of_Threshold_69() { return &___Threshold_69; }
	inline void set_Threshold_69(int32_t value)
	{
		___Threshold_69 = value;
	}

	inline static int32_t get_offset_of_ColorIntensity_70() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___ColorIntensity_70)); }
	inline int32_t get_ColorIntensity_70() const { return ___ColorIntensity_70; }
	inline int32_t* get_address_of_ColorIntensity_70() { return &___ColorIntensity_70; }
	inline void set_ColorIntensity_70(int32_t value)
	{
		___ColorIntensity_70 = value;
	}

	inline static int32_t get_offset_of_Bloom_DirtTex_71() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Bloom_DirtTex_71)); }
	inline int32_t get_Bloom_DirtTex_71() const { return ___Bloom_DirtTex_71; }
	inline int32_t* get_address_of_Bloom_DirtTex_71() { return &___Bloom_DirtTex_71; }
	inline void set_Bloom_DirtTex_71(int32_t value)
	{
		___Bloom_DirtTex_71 = value;
	}

	inline static int32_t get_offset_of_Bloom_Settings_72() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Bloom_Settings_72)); }
	inline int32_t get_Bloom_Settings_72() const { return ___Bloom_Settings_72; }
	inline int32_t* get_address_of_Bloom_Settings_72() { return &___Bloom_Settings_72; }
	inline void set_Bloom_Settings_72(int32_t value)
	{
		___Bloom_Settings_72 = value;
	}

	inline static int32_t get_offset_of_Bloom_Color_73() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Bloom_Color_73)); }
	inline int32_t get_Bloom_Color_73() const { return ___Bloom_Color_73; }
	inline int32_t* get_address_of_Bloom_Color_73() { return &___Bloom_Color_73; }
	inline void set_Bloom_Color_73(int32_t value)
	{
		___Bloom_Color_73 = value;
	}

	inline static int32_t get_offset_of_Bloom_DirtTileOffset_74() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Bloom_DirtTileOffset_74)); }
	inline int32_t get_Bloom_DirtTileOffset_74() const { return ___Bloom_DirtTileOffset_74; }
	inline int32_t* get_address_of_Bloom_DirtTileOffset_74() { return &___Bloom_DirtTileOffset_74; }
	inline void set_Bloom_DirtTileOffset_74(int32_t value)
	{
		___Bloom_DirtTileOffset_74 = value;
	}

	inline static int32_t get_offset_of_ChromaticAberration_Amount_75() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___ChromaticAberration_Amount_75)); }
	inline int32_t get_ChromaticAberration_Amount_75() const { return ___ChromaticAberration_Amount_75; }
	inline int32_t* get_address_of_ChromaticAberration_Amount_75() { return &___ChromaticAberration_Amount_75; }
	inline void set_ChromaticAberration_Amount_75(int32_t value)
	{
		___ChromaticAberration_Amount_75 = value;
	}

	inline static int32_t get_offset_of_ChromaticAberration_SpectralLut_76() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___ChromaticAberration_SpectralLut_76)); }
	inline int32_t get_ChromaticAberration_SpectralLut_76() const { return ___ChromaticAberration_SpectralLut_76; }
	inline int32_t* get_address_of_ChromaticAberration_SpectralLut_76() { return &___ChromaticAberration_SpectralLut_76; }
	inline void set_ChromaticAberration_SpectralLut_76(int32_t value)
	{
		___ChromaticAberration_SpectralLut_76 = value;
	}

	inline static int32_t get_offset_of_Distortion_CenterScale_77() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Distortion_CenterScale_77)); }
	inline int32_t get_Distortion_CenterScale_77() const { return ___Distortion_CenterScale_77; }
	inline int32_t* get_address_of_Distortion_CenterScale_77() { return &___Distortion_CenterScale_77; }
	inline void set_Distortion_CenterScale_77(int32_t value)
	{
		___Distortion_CenterScale_77 = value;
	}

	inline static int32_t get_offset_of_Distortion_Amount_78() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Distortion_Amount_78)); }
	inline int32_t get_Distortion_Amount_78() const { return ___Distortion_Amount_78; }
	inline int32_t* get_address_of_Distortion_Amount_78() { return &___Distortion_Amount_78; }
	inline void set_Distortion_Amount_78(int32_t value)
	{
		___Distortion_Amount_78 = value;
	}

	inline static int32_t get_offset_of_Lut2D_79() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Lut2D_79)); }
	inline int32_t get_Lut2D_79() const { return ___Lut2D_79; }
	inline int32_t* get_address_of_Lut2D_79() { return &___Lut2D_79; }
	inline void set_Lut2D_79(int32_t value)
	{
		___Lut2D_79 = value;
	}

	inline static int32_t get_offset_of_Lut3D_80() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Lut3D_80)); }
	inline int32_t get_Lut3D_80() const { return ___Lut3D_80; }
	inline int32_t* get_address_of_Lut3D_80() { return &___Lut3D_80; }
	inline void set_Lut3D_80(int32_t value)
	{
		___Lut3D_80 = value;
	}

	inline static int32_t get_offset_of_Lut3D_Params_81() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Lut3D_Params_81)); }
	inline int32_t get_Lut3D_Params_81() const { return ___Lut3D_Params_81; }
	inline int32_t* get_address_of_Lut3D_Params_81() { return &___Lut3D_Params_81; }
	inline void set_Lut3D_Params_81(int32_t value)
	{
		___Lut3D_Params_81 = value;
	}

	inline static int32_t get_offset_of_Lut2D_Params_82() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Lut2D_Params_82)); }
	inline int32_t get_Lut2D_Params_82() const { return ___Lut2D_Params_82; }
	inline int32_t* get_address_of_Lut2D_Params_82() { return &___Lut2D_Params_82; }
	inline void set_Lut2D_Params_82(int32_t value)
	{
		___Lut2D_Params_82 = value;
	}

	inline static int32_t get_offset_of_UserLut2D_Params_83() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___UserLut2D_Params_83)); }
	inline int32_t get_UserLut2D_Params_83() const { return ___UserLut2D_Params_83; }
	inline int32_t* get_address_of_UserLut2D_Params_83() { return &___UserLut2D_Params_83; }
	inline void set_UserLut2D_Params_83(int32_t value)
	{
		___UserLut2D_Params_83 = value;
	}

	inline static int32_t get_offset_of_PostExposure_84() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___PostExposure_84)); }
	inline int32_t get_PostExposure_84() const { return ___PostExposure_84; }
	inline int32_t* get_address_of_PostExposure_84() { return &___PostExposure_84; }
	inline void set_PostExposure_84(int32_t value)
	{
		___PostExposure_84 = value;
	}

	inline static int32_t get_offset_of_ColorBalance_85() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___ColorBalance_85)); }
	inline int32_t get_ColorBalance_85() const { return ___ColorBalance_85; }
	inline int32_t* get_address_of_ColorBalance_85() { return &___ColorBalance_85; }
	inline void set_ColorBalance_85(int32_t value)
	{
		___ColorBalance_85 = value;
	}

	inline static int32_t get_offset_of_ColorFilter_86() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___ColorFilter_86)); }
	inline int32_t get_ColorFilter_86() const { return ___ColorFilter_86; }
	inline int32_t* get_address_of_ColorFilter_86() { return &___ColorFilter_86; }
	inline void set_ColorFilter_86(int32_t value)
	{
		___ColorFilter_86 = value;
	}

	inline static int32_t get_offset_of_HueSatCon_87() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___HueSatCon_87)); }
	inline int32_t get_HueSatCon_87() const { return ___HueSatCon_87; }
	inline int32_t* get_address_of_HueSatCon_87() { return &___HueSatCon_87; }
	inline void set_HueSatCon_87(int32_t value)
	{
		___HueSatCon_87 = value;
	}

	inline static int32_t get_offset_of_Brightness_88() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Brightness_88)); }
	inline int32_t get_Brightness_88() const { return ___Brightness_88; }
	inline int32_t* get_address_of_Brightness_88() { return &___Brightness_88; }
	inline void set_Brightness_88(int32_t value)
	{
		___Brightness_88 = value;
	}

	inline static int32_t get_offset_of_ChannelMixerRed_89() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___ChannelMixerRed_89)); }
	inline int32_t get_ChannelMixerRed_89() const { return ___ChannelMixerRed_89; }
	inline int32_t* get_address_of_ChannelMixerRed_89() { return &___ChannelMixerRed_89; }
	inline void set_ChannelMixerRed_89(int32_t value)
	{
		___ChannelMixerRed_89 = value;
	}

	inline static int32_t get_offset_of_ChannelMixerGreen_90() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___ChannelMixerGreen_90)); }
	inline int32_t get_ChannelMixerGreen_90() const { return ___ChannelMixerGreen_90; }
	inline int32_t* get_address_of_ChannelMixerGreen_90() { return &___ChannelMixerGreen_90; }
	inline void set_ChannelMixerGreen_90(int32_t value)
	{
		___ChannelMixerGreen_90 = value;
	}

	inline static int32_t get_offset_of_ChannelMixerBlue_91() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___ChannelMixerBlue_91)); }
	inline int32_t get_ChannelMixerBlue_91() const { return ___ChannelMixerBlue_91; }
	inline int32_t* get_address_of_ChannelMixerBlue_91() { return &___ChannelMixerBlue_91; }
	inline void set_ChannelMixerBlue_91(int32_t value)
	{
		___ChannelMixerBlue_91 = value;
	}

	inline static int32_t get_offset_of_Lift_92() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Lift_92)); }
	inline int32_t get_Lift_92() const { return ___Lift_92; }
	inline int32_t* get_address_of_Lift_92() { return &___Lift_92; }
	inline void set_Lift_92(int32_t value)
	{
		___Lift_92 = value;
	}

	inline static int32_t get_offset_of_InvGamma_93() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___InvGamma_93)); }
	inline int32_t get_InvGamma_93() const { return ___InvGamma_93; }
	inline int32_t* get_address_of_InvGamma_93() { return &___InvGamma_93; }
	inline void set_InvGamma_93(int32_t value)
	{
		___InvGamma_93 = value;
	}

	inline static int32_t get_offset_of_Gain_94() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Gain_94)); }
	inline int32_t get_Gain_94() const { return ___Gain_94; }
	inline int32_t* get_address_of_Gain_94() { return &___Gain_94; }
	inline void set_Gain_94(int32_t value)
	{
		___Gain_94 = value;
	}

	inline static int32_t get_offset_of_Curves_95() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Curves_95)); }
	inline int32_t get_Curves_95() const { return ___Curves_95; }
	inline int32_t* get_address_of_Curves_95() { return &___Curves_95; }
	inline void set_Curves_95(int32_t value)
	{
		___Curves_95 = value;
	}

	inline static int32_t get_offset_of_CustomToneCurve_96() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___CustomToneCurve_96)); }
	inline int32_t get_CustomToneCurve_96() const { return ___CustomToneCurve_96; }
	inline int32_t* get_address_of_CustomToneCurve_96() { return &___CustomToneCurve_96; }
	inline void set_CustomToneCurve_96(int32_t value)
	{
		___CustomToneCurve_96 = value;
	}

	inline static int32_t get_offset_of_ToeSegmentA_97() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___ToeSegmentA_97)); }
	inline int32_t get_ToeSegmentA_97() const { return ___ToeSegmentA_97; }
	inline int32_t* get_address_of_ToeSegmentA_97() { return &___ToeSegmentA_97; }
	inline void set_ToeSegmentA_97(int32_t value)
	{
		___ToeSegmentA_97 = value;
	}

	inline static int32_t get_offset_of_ToeSegmentB_98() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___ToeSegmentB_98)); }
	inline int32_t get_ToeSegmentB_98() const { return ___ToeSegmentB_98; }
	inline int32_t* get_address_of_ToeSegmentB_98() { return &___ToeSegmentB_98; }
	inline void set_ToeSegmentB_98(int32_t value)
	{
		___ToeSegmentB_98 = value;
	}

	inline static int32_t get_offset_of_MidSegmentA_99() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___MidSegmentA_99)); }
	inline int32_t get_MidSegmentA_99() const { return ___MidSegmentA_99; }
	inline int32_t* get_address_of_MidSegmentA_99() { return &___MidSegmentA_99; }
	inline void set_MidSegmentA_99(int32_t value)
	{
		___MidSegmentA_99 = value;
	}

	inline static int32_t get_offset_of_MidSegmentB_100() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___MidSegmentB_100)); }
	inline int32_t get_MidSegmentB_100() const { return ___MidSegmentB_100; }
	inline int32_t* get_address_of_MidSegmentB_100() { return &___MidSegmentB_100; }
	inline void set_MidSegmentB_100(int32_t value)
	{
		___MidSegmentB_100 = value;
	}

	inline static int32_t get_offset_of_ShoSegmentA_101() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___ShoSegmentA_101)); }
	inline int32_t get_ShoSegmentA_101() const { return ___ShoSegmentA_101; }
	inline int32_t* get_address_of_ShoSegmentA_101() { return &___ShoSegmentA_101; }
	inline void set_ShoSegmentA_101(int32_t value)
	{
		___ShoSegmentA_101 = value;
	}

	inline static int32_t get_offset_of_ShoSegmentB_102() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___ShoSegmentB_102)); }
	inline int32_t get_ShoSegmentB_102() const { return ___ShoSegmentB_102; }
	inline int32_t* get_address_of_ShoSegmentB_102() { return &___ShoSegmentB_102; }
	inline void set_ShoSegmentB_102(int32_t value)
	{
		___ShoSegmentB_102 = value;
	}

	inline static int32_t get_offset_of_Vignette_Color_103() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Vignette_Color_103)); }
	inline int32_t get_Vignette_Color_103() const { return ___Vignette_Color_103; }
	inline int32_t* get_address_of_Vignette_Color_103() { return &___Vignette_Color_103; }
	inline void set_Vignette_Color_103(int32_t value)
	{
		___Vignette_Color_103 = value;
	}

	inline static int32_t get_offset_of_Vignette_Center_104() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Vignette_Center_104)); }
	inline int32_t get_Vignette_Center_104() const { return ___Vignette_Center_104; }
	inline int32_t* get_address_of_Vignette_Center_104() { return &___Vignette_Center_104; }
	inline void set_Vignette_Center_104(int32_t value)
	{
		___Vignette_Center_104 = value;
	}

	inline static int32_t get_offset_of_Vignette_Settings_105() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Vignette_Settings_105)); }
	inline int32_t get_Vignette_Settings_105() const { return ___Vignette_Settings_105; }
	inline int32_t* get_address_of_Vignette_Settings_105() { return &___Vignette_Settings_105; }
	inline void set_Vignette_Settings_105(int32_t value)
	{
		___Vignette_Settings_105 = value;
	}

	inline static int32_t get_offset_of_Vignette_Mask_106() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Vignette_Mask_106)); }
	inline int32_t get_Vignette_Mask_106() const { return ___Vignette_Mask_106; }
	inline int32_t* get_address_of_Vignette_Mask_106() { return &___Vignette_Mask_106; }
	inline void set_Vignette_Mask_106(int32_t value)
	{
		___Vignette_Mask_106 = value;
	}

	inline static int32_t get_offset_of_Vignette_Opacity_107() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Vignette_Opacity_107)); }
	inline int32_t get_Vignette_Opacity_107() const { return ___Vignette_Opacity_107; }
	inline int32_t* get_address_of_Vignette_Opacity_107() { return &___Vignette_Opacity_107; }
	inline void set_Vignette_Opacity_107(int32_t value)
	{
		___Vignette_Opacity_107 = value;
	}

	inline static int32_t get_offset_of_Vignette_Mode_108() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Vignette_Mode_108)); }
	inline int32_t get_Vignette_Mode_108() const { return ___Vignette_Mode_108; }
	inline int32_t* get_address_of_Vignette_Mode_108() { return &___Vignette_Mode_108; }
	inline void set_Vignette_Mode_108(int32_t value)
	{
		___Vignette_Mode_108 = value;
	}

	inline static int32_t get_offset_of_Grain_Params1_109() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Grain_Params1_109)); }
	inline int32_t get_Grain_Params1_109() const { return ___Grain_Params1_109; }
	inline int32_t* get_address_of_Grain_Params1_109() { return &___Grain_Params1_109; }
	inline void set_Grain_Params1_109(int32_t value)
	{
		___Grain_Params1_109 = value;
	}

	inline static int32_t get_offset_of_Grain_Params2_110() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Grain_Params2_110)); }
	inline int32_t get_Grain_Params2_110() const { return ___Grain_Params2_110; }
	inline int32_t* get_address_of_Grain_Params2_110() { return &___Grain_Params2_110; }
	inline void set_Grain_Params2_110(int32_t value)
	{
		___Grain_Params2_110 = value;
	}

	inline static int32_t get_offset_of_GrainTex_111() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___GrainTex_111)); }
	inline int32_t get_GrainTex_111() const { return ___GrainTex_111; }
	inline int32_t* get_address_of_GrainTex_111() { return &___GrainTex_111; }
	inline void set_GrainTex_111(int32_t value)
	{
		___GrainTex_111 = value;
	}

	inline static int32_t get_offset_of_Phase_112() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Phase_112)); }
	inline int32_t get_Phase_112() const { return ___Phase_112; }
	inline int32_t* get_address_of_Phase_112() { return &___Phase_112; }
	inline void set_Phase_112(int32_t value)
	{
		___Phase_112 = value;
	}

	inline static int32_t get_offset_of_GrainNoiseParameters_113() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___GrainNoiseParameters_113)); }
	inline int32_t get_GrainNoiseParameters_113() const { return ___GrainNoiseParameters_113; }
	inline int32_t* get_address_of_GrainNoiseParameters_113() { return &___GrainNoiseParameters_113; }
	inline void set_GrainNoiseParameters_113(int32_t value)
	{
		___GrainNoiseParameters_113 = value;
	}

	inline static int32_t get_offset_of_LumaInAlpha_114() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___LumaInAlpha_114)); }
	inline int32_t get_LumaInAlpha_114() const { return ___LumaInAlpha_114; }
	inline int32_t* get_address_of_LumaInAlpha_114() { return &___LumaInAlpha_114; }
	inline void set_LumaInAlpha_114(int32_t value)
	{
		___LumaInAlpha_114 = value;
	}

	inline static int32_t get_offset_of_DitheringTex_115() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___DitheringTex_115)); }
	inline int32_t get_DitheringTex_115() const { return ___DitheringTex_115; }
	inline int32_t* get_address_of_DitheringTex_115() { return &___DitheringTex_115; }
	inline void set_DitheringTex_115(int32_t value)
	{
		___DitheringTex_115 = value;
	}

	inline static int32_t get_offset_of_Dithering_Coords_116() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Dithering_Coords_116)); }
	inline int32_t get_Dithering_Coords_116() const { return ___Dithering_Coords_116; }
	inline int32_t* get_address_of_Dithering_Coords_116() { return &___Dithering_Coords_116; }
	inline void set_Dithering_Coords_116(int32_t value)
	{
		___Dithering_Coords_116 = value;
	}

	inline static int32_t get_offset_of_From_117() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___From_117)); }
	inline int32_t get_From_117() const { return ___From_117; }
	inline int32_t* get_address_of_From_117() { return &___From_117; }
	inline void set_From_117(int32_t value)
	{
		___From_117 = value;
	}

	inline static int32_t get_offset_of_To_118() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___To_118)); }
	inline int32_t get_To_118() const { return ___To_118; }
	inline int32_t* get_address_of_To_118() { return &___To_118; }
	inline void set_To_118(int32_t value)
	{
		___To_118 = value;
	}

	inline static int32_t get_offset_of_Interp_119() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___Interp_119)); }
	inline int32_t get_Interp_119() const { return ___Interp_119; }
	inline int32_t* get_address_of_Interp_119() { return &___Interp_119; }
	inline void set_Interp_119(int32_t value)
	{
		___Interp_119 = value;
	}

	inline static int32_t get_offset_of_TargetColor_120() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___TargetColor_120)); }
	inline int32_t get_TargetColor_120() const { return ___TargetColor_120; }
	inline int32_t* get_address_of_TargetColor_120() { return &___TargetColor_120; }
	inline void set_TargetColor_120(int32_t value)
	{
		___TargetColor_120 = value;
	}

	inline static int32_t get_offset_of_HalfResFinalCopy_121() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___HalfResFinalCopy_121)); }
	inline int32_t get_HalfResFinalCopy_121() const { return ___HalfResFinalCopy_121; }
	inline int32_t* get_address_of_HalfResFinalCopy_121() { return &___HalfResFinalCopy_121; }
	inline void set_HalfResFinalCopy_121(int32_t value)
	{
		___HalfResFinalCopy_121 = value;
	}

	inline static int32_t get_offset_of_WaveformSource_122() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___WaveformSource_122)); }
	inline int32_t get_WaveformSource_122() const { return ___WaveformSource_122; }
	inline int32_t* get_address_of_WaveformSource_122() { return &___WaveformSource_122; }
	inline void set_WaveformSource_122(int32_t value)
	{
		___WaveformSource_122 = value;
	}

	inline static int32_t get_offset_of_WaveformBuffer_123() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___WaveformBuffer_123)); }
	inline int32_t get_WaveformBuffer_123() const { return ___WaveformBuffer_123; }
	inline int32_t* get_address_of_WaveformBuffer_123() { return &___WaveformBuffer_123; }
	inline void set_WaveformBuffer_123(int32_t value)
	{
		___WaveformBuffer_123 = value;
	}

	inline static int32_t get_offset_of_VectorscopeBuffer_124() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___VectorscopeBuffer_124)); }
	inline int32_t get_VectorscopeBuffer_124() const { return ___VectorscopeBuffer_124; }
	inline int32_t* get_address_of_VectorscopeBuffer_124() { return &___VectorscopeBuffer_124; }
	inline void set_VectorscopeBuffer_124(int32_t value)
	{
		___VectorscopeBuffer_124 = value;
	}

	inline static int32_t get_offset_of_RenderViewportScaleFactor_125() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___RenderViewportScaleFactor_125)); }
	inline int32_t get_RenderViewportScaleFactor_125() const { return ___RenderViewportScaleFactor_125; }
	inline int32_t* get_address_of_RenderViewportScaleFactor_125() { return &___RenderViewportScaleFactor_125; }
	inline void set_RenderViewportScaleFactor_125(int32_t value)
	{
		___RenderViewportScaleFactor_125 = value;
	}

	inline static int32_t get_offset_of_UVTransform_126() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___UVTransform_126)); }
	inline int32_t get_UVTransform_126() const { return ___UVTransform_126; }
	inline int32_t* get_address_of_UVTransform_126() { return &___UVTransform_126; }
	inline void set_UVTransform_126(int32_t value)
	{
		___UVTransform_126 = value;
	}

	inline static int32_t get_offset_of_DepthSlice_127() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___DepthSlice_127)); }
	inline int32_t get_DepthSlice_127() const { return ___DepthSlice_127; }
	inline int32_t* get_address_of_DepthSlice_127() { return &___DepthSlice_127; }
	inline void set_DepthSlice_127(int32_t value)
	{
		___DepthSlice_127 = value;
	}

	inline static int32_t get_offset_of_UVScaleOffset_128() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___UVScaleOffset_128)); }
	inline int32_t get_UVScaleOffset_128() const { return ___UVScaleOffset_128; }
	inline int32_t* get_address_of_UVScaleOffset_128() { return &___UVScaleOffset_128; }
	inline void set_UVScaleOffset_128(int32_t value)
	{
		___UVScaleOffset_128 = value;
	}

	inline static int32_t get_offset_of_PosScaleOffset_129() { return static_cast<int32_t>(offsetof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields, ___PosScaleOffset_129)); }
	inline int32_t get_PosScaleOffset_129() const { return ___PosScaleOffset_129; }
	inline int32_t* get_address_of_PosScaleOffset_129() { return &___PosScaleOffset_129; }
	inline void set_PosScaleOffset_129(int32_t value)
	{
		___PosScaleOffset_129 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SHADERIDS_T50801F2461934475540F10C0595A9C3AF7459A22_H
#ifndef SPLINE_TE37069226E0B86697627CCEA38297277E55030CD_H
#define SPLINE_TE37069226E0B86697627CCEA38297277E55030CD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.Spline
struct  Spline_tE37069226E0B86697627CCEA38297277E55030CD  : public RuntimeObject
{
public:
	// UnityEngine.AnimationCurve UnityEngine.Rendering.PostProcessing.Spline::curve
	AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * ___curve_2;
	// System.Boolean UnityEngine.Rendering.PostProcessing.Spline::m_Loop
	bool ___m_Loop_3;
	// System.Single UnityEngine.Rendering.PostProcessing.Spline::m_ZeroValue
	float ___m_ZeroValue_4;
	// System.Single UnityEngine.Rendering.PostProcessing.Spline::m_Range
	float ___m_Range_5;
	// UnityEngine.AnimationCurve UnityEngine.Rendering.PostProcessing.Spline::m_InternalLoopingCurve
	AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * ___m_InternalLoopingCurve_6;
	// System.Int32 UnityEngine.Rendering.PostProcessing.Spline::frameCount
	int32_t ___frameCount_7;
	// System.Single[] UnityEngine.Rendering.PostProcessing.Spline::cachedData
	SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* ___cachedData_8;

public:
	inline static int32_t get_offset_of_curve_2() { return static_cast<int32_t>(offsetof(Spline_tE37069226E0B86697627CCEA38297277E55030CD, ___curve_2)); }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * get_curve_2() const { return ___curve_2; }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C ** get_address_of_curve_2() { return &___curve_2; }
	inline void set_curve_2(AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * value)
	{
		___curve_2 = value;
		Il2CppCodeGenWriteBarrier((&___curve_2), value);
	}

	inline static int32_t get_offset_of_m_Loop_3() { return static_cast<int32_t>(offsetof(Spline_tE37069226E0B86697627CCEA38297277E55030CD, ___m_Loop_3)); }
	inline bool get_m_Loop_3() const { return ___m_Loop_3; }
	inline bool* get_address_of_m_Loop_3() { return &___m_Loop_3; }
	inline void set_m_Loop_3(bool value)
	{
		___m_Loop_3 = value;
	}

	inline static int32_t get_offset_of_m_ZeroValue_4() { return static_cast<int32_t>(offsetof(Spline_tE37069226E0B86697627CCEA38297277E55030CD, ___m_ZeroValue_4)); }
	inline float get_m_ZeroValue_4() const { return ___m_ZeroValue_4; }
	inline float* get_address_of_m_ZeroValue_4() { return &___m_ZeroValue_4; }
	inline void set_m_ZeroValue_4(float value)
	{
		___m_ZeroValue_4 = value;
	}

	inline static int32_t get_offset_of_m_Range_5() { return static_cast<int32_t>(offsetof(Spline_tE37069226E0B86697627CCEA38297277E55030CD, ___m_Range_5)); }
	inline float get_m_Range_5() const { return ___m_Range_5; }
	inline float* get_address_of_m_Range_5() { return &___m_Range_5; }
	inline void set_m_Range_5(float value)
	{
		___m_Range_5 = value;
	}

	inline static int32_t get_offset_of_m_InternalLoopingCurve_6() { return static_cast<int32_t>(offsetof(Spline_tE37069226E0B86697627CCEA38297277E55030CD, ___m_InternalLoopingCurve_6)); }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * get_m_InternalLoopingCurve_6() const { return ___m_InternalLoopingCurve_6; }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C ** get_address_of_m_InternalLoopingCurve_6() { return &___m_InternalLoopingCurve_6; }
	inline void set_m_InternalLoopingCurve_6(AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * value)
	{
		___m_InternalLoopingCurve_6 = value;
		Il2CppCodeGenWriteBarrier((&___m_InternalLoopingCurve_6), value);
	}

	inline static int32_t get_offset_of_frameCount_7() { return static_cast<int32_t>(offsetof(Spline_tE37069226E0B86697627CCEA38297277E55030CD, ___frameCount_7)); }
	inline int32_t get_frameCount_7() const { return ___frameCount_7; }
	inline int32_t* get_address_of_frameCount_7() { return &___frameCount_7; }
	inline void set_frameCount_7(int32_t value)
	{
		___frameCount_7 = value;
	}

	inline static int32_t get_offset_of_cachedData_8() { return static_cast<int32_t>(offsetof(Spline_tE37069226E0B86697627CCEA38297277E55030CD, ___cachedData_8)); }
	inline SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* get_cachedData_8() const { return ___cachedData_8; }
	inline SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5** get_address_of_cachedData_8() { return &___cachedData_8; }
	inline void set_cachedData_8(SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* value)
	{
		___cachedData_8 = value;
		Il2CppCodeGenWriteBarrier((&___cachedData_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SPLINE_TE37069226E0B86697627CCEA38297277E55030CD_H
#ifndef TARGETPOOL_T284FB269C2EF33308F1CFC69124C115985AEA7E4_H
#define TARGETPOOL_T284FB269C2EF33308F1CFC69124C115985AEA7E4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.TargetPool
struct  TargetPool_t284FB269C2EF33308F1CFC69124C115985AEA7E4  : public RuntimeObject
{
public:
	// System.Collections.Generic.List`1<System.Int32> UnityEngine.Rendering.PostProcessing.TargetPool::m_Pool
	List_1_tE1526161A558A17A39A8B69D8EEF3801393B6226 * ___m_Pool_0;
	// System.Int32 UnityEngine.Rendering.PostProcessing.TargetPool::m_Current
	int32_t ___m_Current_1;

public:
	inline static int32_t get_offset_of_m_Pool_0() { return static_cast<int32_t>(offsetof(TargetPool_t284FB269C2EF33308F1CFC69124C115985AEA7E4, ___m_Pool_0)); }
	inline List_1_tE1526161A558A17A39A8B69D8EEF3801393B6226 * get_m_Pool_0() const { return ___m_Pool_0; }
	inline List_1_tE1526161A558A17A39A8B69D8EEF3801393B6226 ** get_address_of_m_Pool_0() { return &___m_Pool_0; }
	inline void set_m_Pool_0(List_1_tE1526161A558A17A39A8B69D8EEF3801393B6226 * value)
	{
		___m_Pool_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_Pool_0), value);
	}

	inline static int32_t get_offset_of_m_Current_1() { return static_cast<int32_t>(offsetof(TargetPool_t284FB269C2EF33308F1CFC69124C115985AEA7E4, ___m_Current_1)); }
	inline int32_t get_m_Current_1() const { return ___m_Current_1; }
	inline int32_t* get_address_of_m_Current_1() { return &___m_Current_1; }
	inline void set_m_Current_1(int32_t value)
	{
		___m_Current_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TARGETPOOL_T284FB269C2EF33308F1CFC69124C115985AEA7E4_H
#ifndef TEXTUREFORMATUTILITIES_T1051A2979F6D9A38B36D87CDDDED9CAFC7DC4B97_H
#define TEXTUREFORMATUTILITIES_T1051A2979F6D9A38B36D87CDDDED9CAFC7DC4B97_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.TextureFormatUtilities
struct  TextureFormatUtilities_t1051A2979F6D9A38B36D87CDDDED9CAFC7DC4B97  : public RuntimeObject
{
public:

public:
};

struct TextureFormatUtilities_t1051A2979F6D9A38B36D87CDDDED9CAFC7DC4B97_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2<System.Int32,UnityEngine.RenderTextureFormat> UnityEngine.Rendering.PostProcessing.TextureFormatUtilities::s_FormatAliasMap
	Dictionary_2_tA708463063DFE4270DCCBFFEFBB60592CA2C5EEB * ___s_FormatAliasMap_0;
	// System.Collections.Generic.Dictionary`2<System.Int32,System.Boolean> UnityEngine.Rendering.PostProcessing.TextureFormatUtilities::s_SupportedRenderTextureFormats
	Dictionary_2_t2258334B2FD1F225C68C5C4869898F9DF49998FB * ___s_SupportedRenderTextureFormats_1;
	// System.Collections.Generic.Dictionary`2<System.Int32,System.Boolean> UnityEngine.Rendering.PostProcessing.TextureFormatUtilities::s_SupportedTextureFormats
	Dictionary_2_t2258334B2FD1F225C68C5C4869898F9DF49998FB * ___s_SupportedTextureFormats_2;

public:
	inline static int32_t get_offset_of_s_FormatAliasMap_0() { return static_cast<int32_t>(offsetof(TextureFormatUtilities_t1051A2979F6D9A38B36D87CDDDED9CAFC7DC4B97_StaticFields, ___s_FormatAliasMap_0)); }
	inline Dictionary_2_tA708463063DFE4270DCCBFFEFBB60592CA2C5EEB * get_s_FormatAliasMap_0() const { return ___s_FormatAliasMap_0; }
	inline Dictionary_2_tA708463063DFE4270DCCBFFEFBB60592CA2C5EEB ** get_address_of_s_FormatAliasMap_0() { return &___s_FormatAliasMap_0; }
	inline void set_s_FormatAliasMap_0(Dictionary_2_tA708463063DFE4270DCCBFFEFBB60592CA2C5EEB * value)
	{
		___s_FormatAliasMap_0 = value;
		Il2CppCodeGenWriteBarrier((&___s_FormatAliasMap_0), value);
	}

	inline static int32_t get_offset_of_s_SupportedRenderTextureFormats_1() { return static_cast<int32_t>(offsetof(TextureFormatUtilities_t1051A2979F6D9A38B36D87CDDDED9CAFC7DC4B97_StaticFields, ___s_SupportedRenderTextureFormats_1)); }
	inline Dictionary_2_t2258334B2FD1F225C68C5C4869898F9DF49998FB * get_s_SupportedRenderTextureFormats_1() const { return ___s_SupportedRenderTextureFormats_1; }
	inline Dictionary_2_t2258334B2FD1F225C68C5C4869898F9DF49998FB ** get_address_of_s_SupportedRenderTextureFormats_1() { return &___s_SupportedRenderTextureFormats_1; }
	inline void set_s_SupportedRenderTextureFormats_1(Dictionary_2_t2258334B2FD1F225C68C5C4869898F9DF49998FB * value)
	{
		___s_SupportedRenderTextureFormats_1 = value;
		Il2CppCodeGenWriteBarrier((&___s_SupportedRenderTextureFormats_1), value);
	}

	inline static int32_t get_offset_of_s_SupportedTextureFormats_2() { return static_cast<int32_t>(offsetof(TextureFormatUtilities_t1051A2979F6D9A38B36D87CDDDED9CAFC7DC4B97_StaticFields, ___s_SupportedTextureFormats_2)); }
	inline Dictionary_2_t2258334B2FD1F225C68C5C4869898F9DF49998FB * get_s_SupportedTextureFormats_2() const { return ___s_SupportedTextureFormats_2; }
	inline Dictionary_2_t2258334B2FD1F225C68C5C4869898F9DF49998FB ** get_address_of_s_SupportedTextureFormats_2() { return &___s_SupportedTextureFormats_2; }
	inline void set_s_SupportedTextureFormats_2(Dictionary_2_t2258334B2FD1F225C68C5C4869898F9DF49998FB * value)
	{
		___s_SupportedTextureFormats_2 = value;
		Il2CppCodeGenWriteBarrier((&___s_SupportedTextureFormats_2), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TEXTUREFORMATUTILITIES_T1051A2979F6D9A38B36D87CDDDED9CAFC7DC4B97_H
#ifndef TEXTURELERPER_TC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A_H
#define TEXTURELERPER_TC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.TextureLerper
struct  TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A  : public RuntimeObject
{
public:
	// UnityEngine.Rendering.CommandBuffer UnityEngine.Rendering.PostProcessing.TextureLerper::m_Command
	CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * ___m_Command_1;
	// UnityEngine.Rendering.PostProcessing.PropertySheetFactory UnityEngine.Rendering.PostProcessing.TextureLerper::m_PropertySheets
	PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68 * ___m_PropertySheets_2;
	// UnityEngine.Rendering.PostProcessing.PostProcessResources UnityEngine.Rendering.PostProcessing.TextureLerper::m_Resources
	PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 * ___m_Resources_3;
	// System.Collections.Generic.List`1<UnityEngine.RenderTexture> UnityEngine.Rendering.PostProcessing.TextureLerper::m_Recycled
	List_1_t38DC6F3924A2FB1303F0D1993418D258B3AB7F37 * ___m_Recycled_4;
	// System.Collections.Generic.List`1<UnityEngine.RenderTexture> UnityEngine.Rendering.PostProcessing.TextureLerper::m_Actives
	List_1_t38DC6F3924A2FB1303F0D1993418D258B3AB7F37 * ___m_Actives_5;

public:
	inline static int32_t get_offset_of_m_Command_1() { return static_cast<int32_t>(offsetof(TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A, ___m_Command_1)); }
	inline CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * get_m_Command_1() const { return ___m_Command_1; }
	inline CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD ** get_address_of_m_Command_1() { return &___m_Command_1; }
	inline void set_m_Command_1(CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * value)
	{
		___m_Command_1 = value;
		Il2CppCodeGenWriteBarrier((&___m_Command_1), value);
	}

	inline static int32_t get_offset_of_m_PropertySheets_2() { return static_cast<int32_t>(offsetof(TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A, ___m_PropertySheets_2)); }
	inline PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68 * get_m_PropertySheets_2() const { return ___m_PropertySheets_2; }
	inline PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68 ** get_address_of_m_PropertySheets_2() { return &___m_PropertySheets_2; }
	inline void set_m_PropertySheets_2(PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68 * value)
	{
		___m_PropertySheets_2 = value;
		Il2CppCodeGenWriteBarrier((&___m_PropertySheets_2), value);
	}

	inline static int32_t get_offset_of_m_Resources_3() { return static_cast<int32_t>(offsetof(TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A, ___m_Resources_3)); }
	inline PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 * get_m_Resources_3() const { return ___m_Resources_3; }
	inline PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 ** get_address_of_m_Resources_3() { return &___m_Resources_3; }
	inline void set_m_Resources_3(PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 * value)
	{
		___m_Resources_3 = value;
		Il2CppCodeGenWriteBarrier((&___m_Resources_3), value);
	}

	inline static int32_t get_offset_of_m_Recycled_4() { return static_cast<int32_t>(offsetof(TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A, ___m_Recycled_4)); }
	inline List_1_t38DC6F3924A2FB1303F0D1993418D258B3AB7F37 * get_m_Recycled_4() const { return ___m_Recycled_4; }
	inline List_1_t38DC6F3924A2FB1303F0D1993418D258B3AB7F37 ** get_address_of_m_Recycled_4() { return &___m_Recycled_4; }
	inline void set_m_Recycled_4(List_1_t38DC6F3924A2FB1303F0D1993418D258B3AB7F37 * value)
	{
		___m_Recycled_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_Recycled_4), value);
	}

	inline static int32_t get_offset_of_m_Actives_5() { return static_cast<int32_t>(offsetof(TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A, ___m_Actives_5)); }
	inline List_1_t38DC6F3924A2FB1303F0D1993418D258B3AB7F37 * get_m_Actives_5() const { return ___m_Actives_5; }
	inline List_1_t38DC6F3924A2FB1303F0D1993418D258B3AB7F37 ** get_address_of_m_Actives_5() { return &___m_Actives_5; }
	inline void set_m_Actives_5(List_1_t38DC6F3924A2FB1303F0D1993418D258B3AB7F37 * value)
	{
		___m_Actives_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_Actives_5), value);
	}
};

struct TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A_StaticFields
{
public:
	// UnityEngine.Rendering.PostProcessing.TextureLerper UnityEngine.Rendering.PostProcessing.TextureLerper::m_Instance
	TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A * ___m_Instance_0;

public:
	inline static int32_t get_offset_of_m_Instance_0() { return static_cast<int32_t>(offsetof(TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A_StaticFields, ___m_Instance_0)); }
	inline TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A * get_m_Instance_0() const { return ___m_Instance_0; }
	inline TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A ** get_address_of_m_Instance_0() { return &___m_Instance_0; }
	inline void set_m_Instance_0(TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A * value)
	{
		___m_Instance_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_Instance_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TEXTURELERPER_TC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A_H
#ifndef __STATICARRAYINITTYPESIZEU3D20_TD65589242911778C66D1E5AC9009597568746382_H
#define __STATICARRAYINITTYPESIZEU3D20_TD65589242911778C66D1E5AC9009597568746382_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>___StaticArrayInitTypeSizeU3D20
struct  __StaticArrayInitTypeSizeU3D20_tD65589242911778C66D1E5AC9009597568746382 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D20_tD65589242911778C66D1E5AC9009597568746382__padding[20];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // __STATICARRAYINITTYPESIZEU3D20_TD65589242911778C66D1E5AC9009597568746382_H
#ifndef ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#define ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t2AF27C02B8653AE29442467390005ABC74D8F521  : public ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF
{
public:

public:
};

struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((&___enumSeperatorCharArray_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_com
{
};
#endif // ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef LAYERMASK_TBB9173D8B6939D476E67E849280AC9F4EC4D93B0_H
#define LAYERMASK_TBB9173D8B6939D476E67E849280AC9F4EC4D93B0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.LayerMask
struct  LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0 
{
public:
	// System.Int32 UnityEngine.LayerMask::m_Mask
	int32_t ___m_Mask_0;

public:
	inline static int32_t get_offset_of_m_Mask_0() { return static_cast<int32_t>(offsetof(LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0, ___m_Mask_0)); }
	inline int32_t get_m_Mask_0() const { return ___m_Mask_0; }
	inline int32_t* get_address_of_m_Mask_0() { return &___m_Mask_0; }
	inline void set_m_Mask_0(int32_t value)
	{
		___m_Mask_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LAYERMASK_TBB9173D8B6939D476E67E849280AC9F4EC4D93B0_H
#ifndef DIRECTPARAMS_T51DA8B018065DC940CFA6E3920C8E686F422FE28_H
#define DIRECTPARAMS_T51DA8B018065DC940CFA6E3920C8E686F422FE28_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.HableCurve_DirectParams
struct  DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28 
{
public:
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve_DirectParams::x0
	float ___x0_0;
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve_DirectParams::y0
	float ___y0_1;
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve_DirectParams::x1
	float ___x1_2;
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve_DirectParams::y1
	float ___y1_3;
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve_DirectParams::W
	float ___W_4;
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve_DirectParams::overshootX
	float ___overshootX_5;
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve_DirectParams::overshootY
	float ___overshootY_6;
	// System.Single UnityEngine.Rendering.PostProcessing.HableCurve_DirectParams::gamma
	float ___gamma_7;

public:
	inline static int32_t get_offset_of_x0_0() { return static_cast<int32_t>(offsetof(DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28, ___x0_0)); }
	inline float get_x0_0() const { return ___x0_0; }
	inline float* get_address_of_x0_0() { return &___x0_0; }
	inline void set_x0_0(float value)
	{
		___x0_0 = value;
	}

	inline static int32_t get_offset_of_y0_1() { return static_cast<int32_t>(offsetof(DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28, ___y0_1)); }
	inline float get_y0_1() const { return ___y0_1; }
	inline float* get_address_of_y0_1() { return &___y0_1; }
	inline void set_y0_1(float value)
	{
		___y0_1 = value;
	}

	inline static int32_t get_offset_of_x1_2() { return static_cast<int32_t>(offsetof(DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28, ___x1_2)); }
	inline float get_x1_2() const { return ___x1_2; }
	inline float* get_address_of_x1_2() { return &___x1_2; }
	inline void set_x1_2(float value)
	{
		___x1_2 = value;
	}

	inline static int32_t get_offset_of_y1_3() { return static_cast<int32_t>(offsetof(DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28, ___y1_3)); }
	inline float get_y1_3() const { return ___y1_3; }
	inline float* get_address_of_y1_3() { return &___y1_3; }
	inline void set_y1_3(float value)
	{
		___y1_3 = value;
	}

	inline static int32_t get_offset_of_W_4() { return static_cast<int32_t>(offsetof(DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28, ___W_4)); }
	inline float get_W_4() const { return ___W_4; }
	inline float* get_address_of_W_4() { return &___W_4; }
	inline void set_W_4(float value)
	{
		___W_4 = value;
	}

	inline static int32_t get_offset_of_overshootX_5() { return static_cast<int32_t>(offsetof(DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28, ___overshootX_5)); }
	inline float get_overshootX_5() const { return ___overshootX_5; }
	inline float* get_address_of_overshootX_5() { return &___overshootX_5; }
	inline void set_overshootX_5(float value)
	{
		___overshootX_5 = value;
	}

	inline static int32_t get_offset_of_overshootY_6() { return static_cast<int32_t>(offsetof(DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28, ___overshootY_6)); }
	inline float get_overshootY_6() const { return ___overshootY_6; }
	inline float* get_address_of_overshootY_6() { return &___overshootY_6; }
	inline void set_overshootY_6(float value)
	{
		___overshootY_6 = value;
	}

	inline static int32_t get_offset_of_gamma_7() { return static_cast<int32_t>(offsetof(DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28, ___gamma_7)); }
	inline float get_gamma_7() const { return ___gamma_7; }
	inline float* get_address_of_gamma_7() { return &___gamma_7; }
	inline void set_gamma_7(float value)
	{
		___gamma_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DIRECTPARAMS_T51DA8B018065DC940CFA6E3920C8E686F422FE28_H
#ifndef PARAMETEROVERRIDE_1_T2B9AE4432721024285C22999291BF22050E54238_H
#define PARAMETEROVERRIDE_1_T2B9AE4432721024285C22999291BF22050E54238_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ParameterOverride`1<UnityEngine.Texture>
struct  ParameterOverride_1_t2B9AE4432721024285C22999291BF22050E54238  : public ParameterOverride_t33733D55B6D63C97BF769220036767852B4AFB5F
{
public:
	// T UnityEngine.Rendering.PostProcessing.ParameterOverride`1::value
	Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * ___value_1;

public:
	inline static int32_t get_offset_of_value_1() { return static_cast<int32_t>(offsetof(ParameterOverride_1_t2B9AE4432721024285C22999291BF22050E54238, ___value_1)); }
	inline Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * get_value_1() const { return ___value_1; }
	inline Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 ** get_address_of_value_1() { return &___value_1; }
	inline void set_value_1(Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * value)
	{
		___value_1 = value;
		Il2CppCodeGenWriteBarrier((&___value_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // PARAMETEROVERRIDE_1_T2B9AE4432721024285C22999291BF22050E54238_H
#ifndef POSTPROCESSEVENTCOMPARER_T943CF37B2BE35AAB0807B330F79E75FF4359088F_H
#define POSTPROCESSEVENTCOMPARER_T943CF37B2BE35AAB0807B330F79E75FF4359088F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEventComparer
struct  PostProcessEventComparer_t943CF37B2BE35AAB0807B330F79E75FF4359088F 
{
public:
	union
	{
		struct
		{
		};
		uint8_t PostProcessEventComparer_t943CF37B2BE35AAB0807B330F79E75FF4359088F__padding[1];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEVENTCOMPARER_T943CF37B2BE35AAB0807B330F79E75FF4359088F_H
#ifndef U3CPRIVATEIMPLEMENTATIONDETAILSU3E_T4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_H
#define U3CPRIVATEIMPLEMENTATIONDETAILSU3E_T4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>
struct  U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A  : public RuntimeObject
{
public:

public:
};

struct U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_StaticFields
{
public:
	// <PrivateImplementationDetails>___StaticArrayInitTypeSizeU3D20 <PrivateImplementationDetails>::0ED907628EE272F93737B500A23D77C9B1C88368
	__StaticArrayInitTypeSizeU3D20_tD65589242911778C66D1E5AC9009597568746382  ___0ED907628EE272F93737B500A23D77C9B1C88368_0;

public:
	inline static int32_t get_offset_of_U30ED907628EE272F93737B500A23D77C9B1C88368_0() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_StaticFields, ___0ED907628EE272F93737B500A23D77C9B1C88368_0)); }
	inline __StaticArrayInitTypeSizeU3D20_tD65589242911778C66D1E5AC9009597568746382  get_U30ED907628EE272F93737B500A23D77C9B1C88368_0() const { return ___0ED907628EE272F93737B500A23D77C9B1C88368_0; }
	inline __StaticArrayInitTypeSizeU3D20_tD65589242911778C66D1E5AC9009597568746382 * get_address_of_U30ED907628EE272F93737B500A23D77C9B1C88368_0() { return &___0ED907628EE272F93737B500A23D77C9B1C88368_0; }
	inline void set_U30ED907628EE272F93737B500A23D77C9B1C88368_0(__StaticArrayInitTypeSizeU3D20_tD65589242911778C66D1E5AC9009597568746382  value)
	{
		___0ED907628EE272F93737B500A23D77C9B1C88368_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CPRIVATEIMPLEMENTATIONDETAILSU3E_T4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_H
#ifndef CUBEMAPFACE_T74DD9C86D8A5E5F782F136F8753580668F96FFB9_H
#define CUBEMAPFACE_T74DD9C86D8A5E5F782F136F8753580668F96FFB9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.CubemapFace
struct  CubemapFace_t74DD9C86D8A5E5F782F136F8753580668F96FFB9 
{
public:
	// System.Int32 UnityEngine.CubemapFace::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(CubemapFace_t74DD9C86D8A5E5F782F136F8753580668F96FFB9, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CUBEMAPFACE_T74DD9C86D8A5E5F782F136F8753580668F96FFB9_H
#ifndef DEPTHTEXTUREMODE_T284833A8AB245ACA7E27BE611BE03B18B0249F01_H
#define DEPTHTEXTUREMODE_T284833A8AB245ACA7E27BE611BE03B18B0249F01_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.DepthTextureMode
struct  DepthTextureMode_t284833A8AB245ACA7E27BE611BE03B18B0249F01 
{
public:
	// System.Int32 UnityEngine.DepthTextureMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(DepthTextureMode_t284833A8AB245ACA7E27BE611BE03B18B0249F01, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEPTHTEXTUREMODE_T284833A8AB245ACA7E27BE611BE03B18B0249F01_H
#ifndef OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#define OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Object
struct  Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};
#endif // OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#ifndef RENDERTEXTURECREATIONFLAGS_TF63E06301E4BB4746F7E07759B359872BD4BFB1E_H
#define RENDERTEXTURECREATIONFLAGS_TF63E06301E4BB4746F7E07759B359872BD4BFB1E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RenderTextureCreationFlags
struct  RenderTextureCreationFlags_tF63E06301E4BB4746F7E07759B359872BD4BFB1E 
{
public:
	// System.Int32 UnityEngine.RenderTextureCreationFlags::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(RenderTextureCreationFlags_tF63E06301E4BB4746F7E07759B359872BD4BFB1E, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RENDERTEXTURECREATIONFLAGS_TF63E06301E4BB4746F7E07759B359872BD4BFB1E_H
#ifndef RENDERTEXTUREFORMAT_T2AB1B77FBD247648292FBBE1182F12B5FC47AF85_H
#define RENDERTEXTUREFORMAT_T2AB1B77FBD247648292FBBE1182F12B5FC47AF85_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RenderTextureFormat
struct  RenderTextureFormat_t2AB1B77FBD247648292FBBE1182F12B5FC47AF85 
{
public:
	// System.Int32 UnityEngine.RenderTextureFormat::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(RenderTextureFormat_t2AB1B77FBD247648292FBBE1182F12B5FC47AF85, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RENDERTEXTUREFORMAT_T2AB1B77FBD247648292FBBE1182F12B5FC47AF85_H
#ifndef RENDERTEXTUREMEMORYLESS_T19E37ADD57C1F00D67146A2BB4521D06F370D2E9_H
#define RENDERTEXTUREMEMORYLESS_T19E37ADD57C1F00D67146A2BB4521D06F370D2E9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RenderTextureMemoryless
struct  RenderTextureMemoryless_t19E37ADD57C1F00D67146A2BB4521D06F370D2E9 
{
public:
	// System.Int32 UnityEngine.RenderTextureMemoryless::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(RenderTextureMemoryless_t19E37ADD57C1F00D67146A2BB4521D06F370D2E9, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RENDERTEXTUREMEMORYLESS_T19E37ADD57C1F00D67146A2BB4521D06F370D2E9_H
#ifndef BUILTINRENDERTEXTURETYPE_T6ECEE9FF62E815D7ED640D057EEA84C0FD145D01_H
#define BUILTINRENDERTEXTURETYPE_T6ECEE9FF62E815D7ED640D057EEA84C0FD145D01_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.BuiltinRenderTextureType
struct  BuiltinRenderTextureType_t6ECEE9FF62E815D7ED640D057EEA84C0FD145D01 
{
public:
	// System.Int32 UnityEngine.Rendering.BuiltinRenderTextureType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(BuiltinRenderTextureType_t6ECEE9FF62E815D7ED640D057EEA84C0FD145D01, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BUILTINRENDERTEXTURETYPE_T6ECEE9FF62E815D7ED640D057EEA84C0FD145D01_H
#ifndef COLORBLINDNESSTYPE_T04F06730EA7A0D057F12E626AD2BD00B4BE473F9_H
#define COLORBLINDNESSTYPE_T04F06730EA7A0D057F12E626AD2BD00B4BE473F9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.ColorBlindnessType
struct  ColorBlindnessType_t04F06730EA7A0D057F12E626AD2BD00B4BE473F9 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.ColorBlindnessType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ColorBlindnessType_t04F06730EA7A0D057F12E626AD2BD00B4BE473F9, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLORBLINDNESSTYPE_T04F06730EA7A0D057F12E626AD2BD00B4BE473F9_H
#ifndef DEBUGOVERLAY_T74D1844AFC3A6FE3F324A07D4F140779D6F6E79C_H
#define DEBUGOVERLAY_T74D1844AFC3A6FE3F324A07D4F140779D6F6E79C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.DebugOverlay
struct  DebugOverlay_t74D1844AFC3A6FE3F324A07D4F140779D6F6E79C 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.DebugOverlay::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(DebugOverlay_t74D1844AFC3A6FE3F324A07D4F140779D6F6E79C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEBUGOVERLAY_T74D1844AFC3A6FE3F324A07D4F140779D6F6E79C_H
#ifndef POSTPROCESSEVENT_TB213B5070E972AC9A0D6983CF2686144655765D0_H
#define POSTPROCESSEVENT_TB213B5070E972AC9A0D6983CF2686144655765D0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEvent
struct  PostProcessEvent_tB213B5070E972AC9A0D6983CF2686144655765D0 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.PostProcessEvent::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(PostProcessEvent_tB213B5070E972AC9A0D6983CF2686144655765D0, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEVENT_TB213B5070E972AC9A0D6983CF2686144655765D0_H
#ifndef ANTIALIASING_TDAE4B0628ECF95DB3628B368E6E2BFA8B4E25CFC_H
#define ANTIALIASING_TDAE4B0628ECF95DB3628B368E6E2BFA8B4E25CFC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessLayer_Antialiasing
struct  Antialiasing_tDAE4B0628ECF95DB3628B368E6E2BFA8B4E25CFC 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.PostProcessLayer_Antialiasing::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Antialiasing_tDAE4B0628ECF95DB3628B368E6E2BFA8B4E25CFC, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // ANTIALIASING_TDAE4B0628ECF95DB3628B368E6E2BFA8B4E25CFC_H
#ifndef STEREORENDERINGMODE_T0875357164ABD8348545BC304C58EF81F44C78F3_H
#define STEREORENDERINGMODE_T0875357164ABD8348545BC304C58EF81F44C78F3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessRenderContext_StereoRenderingMode
struct  StereoRenderingMode_t0875357164ABD8348545BC304C58EF81F44C78F3 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.PostProcessRenderContext_StereoRenderingMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(StereoRenderingMode_t0875357164ABD8348545BC304C58EF81F44C78F3, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // STEREORENDERINGMODE_T0875357164ABD8348545BC304C58EF81F44C78F3_H
#ifndef TEXTUREPARAMETERDEFAULT_TC19C21E22B0FAAF2DC062C8383E59219360DA4FB_H
#define TEXTUREPARAMETERDEFAULT_TC19C21E22B0FAAF2DC062C8383E59219360DA4FB_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.TextureParameterDefault
struct  TextureParameterDefault_tC19C21E22B0FAAF2DC062C8383E59219360DA4FB 
{
public:
	// System.Int32 UnityEngine.Rendering.PostProcessing.TextureParameterDefault::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(TextureParameterDefault_tC19C21E22B0FAAF2DC062C8383E59219360DA4FB, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TEXTUREPARAMETERDEFAULT_TC19C21E22B0FAAF2DC062C8383E59219360DA4FB_H
#ifndef SHADOWSAMPLINGMODE_T585A9BDECAC505FF19FF785F55CDD403A2E5DA73_H
#define SHADOWSAMPLINGMODE_T585A9BDECAC505FF19FF785F55CDD403A2E5DA73_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.ShadowSamplingMode
struct  ShadowSamplingMode_t585A9BDECAC505FF19FF785F55CDD403A2E5DA73 
{
public:
	// System.Int32 UnityEngine.Rendering.ShadowSamplingMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ShadowSamplingMode_t585A9BDECAC505FF19FF785F55CDD403A2E5DA73, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SHADOWSAMPLINGMODE_T585A9BDECAC505FF19FF785F55CDD403A2E5DA73_H
#ifndef TEXTUREDIMENSION_T90D0E4110D3F4D062F3E8C0F69809BFBBDF8E19C_H
#define TEXTUREDIMENSION_T90D0E4110D3F4D062F3E8C0F69809BFBBDF8E19C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.TextureDimension
struct  TextureDimension_t90D0E4110D3F4D062F3E8C0F69809BFBBDF8E19C 
{
public:
	// System.Int32 UnityEngine.Rendering.TextureDimension::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(TextureDimension_t90D0E4110D3F4D062F3E8C0F69809BFBBDF8E19C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TEXTUREDIMENSION_T90D0E4110D3F4D062F3E8C0F69809BFBBDF8E19C_H
#ifndef VRTEXTUREUSAGE_T2D7C2397ABF03DD28086B969100F7D91DDD978A0_H
#define VRTEXTUREUSAGE_T2D7C2397ABF03DD28086B969100F7D91DDD978A0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.VRTextureUsage
struct  VRTextureUsage_t2D7C2397ABF03DD28086B969100F7D91DDD978A0 
{
public:
	// System.Int32 UnityEngine.VRTextureUsage::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(VRTextureUsage_t2D7C2397ABF03DD28086B969100F7D91DDD978A0, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VRTEXTUREUSAGE_T2D7C2397ABF03DD28086B969100F7D91DDD978A0_H
#ifndef COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#define COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Component
struct  Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#ifndef RENDERTEXTUREDESCRIPTOR_T74FEC57A54F89E11748E1865F7DCA3565BFAF58E_H
#define RENDERTEXTUREDESCRIPTOR_T74FEC57A54F89E11748E1865F7DCA3565BFAF58E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.RenderTextureDescriptor
struct  RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E 
{
public:
	// System.Int32 UnityEngine.RenderTextureDescriptor::<width>k__BackingField
	int32_t ___U3CwidthU3Ek__BackingField_0;
	// System.Int32 UnityEngine.RenderTextureDescriptor::<height>k__BackingField
	int32_t ___U3CheightU3Ek__BackingField_1;
	// System.Int32 UnityEngine.RenderTextureDescriptor::<msaaSamples>k__BackingField
	int32_t ___U3CmsaaSamplesU3Ek__BackingField_2;
	// System.Int32 UnityEngine.RenderTextureDescriptor::<volumeDepth>k__BackingField
	int32_t ___U3CvolumeDepthU3Ek__BackingField_3;
	// UnityEngine.RenderTextureFormat UnityEngine.RenderTextureDescriptor::<colorFormat>k__BackingField
	int32_t ___U3CcolorFormatU3Ek__BackingField_4;
	// System.Int32 UnityEngine.RenderTextureDescriptor::_depthBufferBits
	int32_t ____depthBufferBits_5;
	// UnityEngine.Rendering.TextureDimension UnityEngine.RenderTextureDescriptor::<dimension>k__BackingField
	int32_t ___U3CdimensionU3Ek__BackingField_7;
	// UnityEngine.Rendering.ShadowSamplingMode UnityEngine.RenderTextureDescriptor::<shadowSamplingMode>k__BackingField
	int32_t ___U3CshadowSamplingModeU3Ek__BackingField_8;
	// UnityEngine.VRTextureUsage UnityEngine.RenderTextureDescriptor::<vrUsage>k__BackingField
	int32_t ___U3CvrUsageU3Ek__BackingField_9;
	// UnityEngine.RenderTextureCreationFlags UnityEngine.RenderTextureDescriptor::_flags
	int32_t ____flags_10;
	// UnityEngine.RenderTextureMemoryless UnityEngine.RenderTextureDescriptor::<memoryless>k__BackingField
	int32_t ___U3CmemorylessU3Ek__BackingField_11;

public:
	inline static int32_t get_offset_of_U3CwidthU3Ek__BackingField_0() { return static_cast<int32_t>(offsetof(RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E, ___U3CwidthU3Ek__BackingField_0)); }
	inline int32_t get_U3CwidthU3Ek__BackingField_0() const { return ___U3CwidthU3Ek__BackingField_0; }
	inline int32_t* get_address_of_U3CwidthU3Ek__BackingField_0() { return &___U3CwidthU3Ek__BackingField_0; }
	inline void set_U3CwidthU3Ek__BackingField_0(int32_t value)
	{
		___U3CwidthU3Ek__BackingField_0 = value;
	}

	inline static int32_t get_offset_of_U3CheightU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E, ___U3CheightU3Ek__BackingField_1)); }
	inline int32_t get_U3CheightU3Ek__BackingField_1() const { return ___U3CheightU3Ek__BackingField_1; }
	inline int32_t* get_address_of_U3CheightU3Ek__BackingField_1() { return &___U3CheightU3Ek__BackingField_1; }
	inline void set_U3CheightU3Ek__BackingField_1(int32_t value)
	{
		___U3CheightU3Ek__BackingField_1 = value;
	}

	inline static int32_t get_offset_of_U3CmsaaSamplesU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E, ___U3CmsaaSamplesU3Ek__BackingField_2)); }
	inline int32_t get_U3CmsaaSamplesU3Ek__BackingField_2() const { return ___U3CmsaaSamplesU3Ek__BackingField_2; }
	inline int32_t* get_address_of_U3CmsaaSamplesU3Ek__BackingField_2() { return &___U3CmsaaSamplesU3Ek__BackingField_2; }
	inline void set_U3CmsaaSamplesU3Ek__BackingField_2(int32_t value)
	{
		___U3CmsaaSamplesU3Ek__BackingField_2 = value;
	}

	inline static int32_t get_offset_of_U3CvolumeDepthU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E, ___U3CvolumeDepthU3Ek__BackingField_3)); }
	inline int32_t get_U3CvolumeDepthU3Ek__BackingField_3() const { return ___U3CvolumeDepthU3Ek__BackingField_3; }
	inline int32_t* get_address_of_U3CvolumeDepthU3Ek__BackingField_3() { return &___U3CvolumeDepthU3Ek__BackingField_3; }
	inline void set_U3CvolumeDepthU3Ek__BackingField_3(int32_t value)
	{
		___U3CvolumeDepthU3Ek__BackingField_3 = value;
	}

	inline static int32_t get_offset_of_U3CcolorFormatU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E, ___U3CcolorFormatU3Ek__BackingField_4)); }
	inline int32_t get_U3CcolorFormatU3Ek__BackingField_4() const { return ___U3CcolorFormatU3Ek__BackingField_4; }
	inline int32_t* get_address_of_U3CcolorFormatU3Ek__BackingField_4() { return &___U3CcolorFormatU3Ek__BackingField_4; }
	inline void set_U3CcolorFormatU3Ek__BackingField_4(int32_t value)
	{
		___U3CcolorFormatU3Ek__BackingField_4 = value;
	}

	inline static int32_t get_offset_of__depthBufferBits_5() { return static_cast<int32_t>(offsetof(RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E, ____depthBufferBits_5)); }
	inline int32_t get__depthBufferBits_5() const { return ____depthBufferBits_5; }
	inline int32_t* get_address_of__depthBufferBits_5() { return &____depthBufferBits_5; }
	inline void set__depthBufferBits_5(int32_t value)
	{
		____depthBufferBits_5 = value;
	}

	inline static int32_t get_offset_of_U3CdimensionU3Ek__BackingField_7() { return static_cast<int32_t>(offsetof(RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E, ___U3CdimensionU3Ek__BackingField_7)); }
	inline int32_t get_U3CdimensionU3Ek__BackingField_7() const { return ___U3CdimensionU3Ek__BackingField_7; }
	inline int32_t* get_address_of_U3CdimensionU3Ek__BackingField_7() { return &___U3CdimensionU3Ek__BackingField_7; }
	inline void set_U3CdimensionU3Ek__BackingField_7(int32_t value)
	{
		___U3CdimensionU3Ek__BackingField_7 = value;
	}

	inline static int32_t get_offset_of_U3CshadowSamplingModeU3Ek__BackingField_8() { return static_cast<int32_t>(offsetof(RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E, ___U3CshadowSamplingModeU3Ek__BackingField_8)); }
	inline int32_t get_U3CshadowSamplingModeU3Ek__BackingField_8() const { return ___U3CshadowSamplingModeU3Ek__BackingField_8; }
	inline int32_t* get_address_of_U3CshadowSamplingModeU3Ek__BackingField_8() { return &___U3CshadowSamplingModeU3Ek__BackingField_8; }
	inline void set_U3CshadowSamplingModeU3Ek__BackingField_8(int32_t value)
	{
		___U3CshadowSamplingModeU3Ek__BackingField_8 = value;
	}

	inline static int32_t get_offset_of_U3CvrUsageU3Ek__BackingField_9() { return static_cast<int32_t>(offsetof(RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E, ___U3CvrUsageU3Ek__BackingField_9)); }
	inline int32_t get_U3CvrUsageU3Ek__BackingField_9() const { return ___U3CvrUsageU3Ek__BackingField_9; }
	inline int32_t* get_address_of_U3CvrUsageU3Ek__BackingField_9() { return &___U3CvrUsageU3Ek__BackingField_9; }
	inline void set_U3CvrUsageU3Ek__BackingField_9(int32_t value)
	{
		___U3CvrUsageU3Ek__BackingField_9 = value;
	}

	inline static int32_t get_offset_of__flags_10() { return static_cast<int32_t>(offsetof(RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E, ____flags_10)); }
	inline int32_t get__flags_10() const { return ____flags_10; }
	inline int32_t* get_address_of__flags_10() { return &____flags_10; }
	inline void set__flags_10(int32_t value)
	{
		____flags_10 = value;
	}

	inline static int32_t get_offset_of_U3CmemorylessU3Ek__BackingField_11() { return static_cast<int32_t>(offsetof(RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E, ___U3CmemorylessU3Ek__BackingField_11)); }
	inline int32_t get_U3CmemorylessU3Ek__BackingField_11() const { return ___U3CmemorylessU3Ek__BackingField_11; }
	inline int32_t* get_address_of_U3CmemorylessU3Ek__BackingField_11() { return &___U3CmemorylessU3Ek__BackingField_11; }
	inline void set_U3CmemorylessU3Ek__BackingField_11(int32_t value)
	{
		___U3CmemorylessU3Ek__BackingField_11 = value;
	}
};

struct RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E_StaticFields
{
public:
	// System.Int32[] UnityEngine.RenderTextureDescriptor::depthFormatBits
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___depthFormatBits_6;

public:
	inline static int32_t get_offset_of_depthFormatBits_6() { return static_cast<int32_t>(offsetof(RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E_StaticFields, ___depthFormatBits_6)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_depthFormatBits_6() const { return ___depthFormatBits_6; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_depthFormatBits_6() { return &___depthFormatBits_6; }
	inline void set_depthFormatBits_6(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___depthFormatBits_6 = value;
		Il2CppCodeGenWriteBarrier((&___depthFormatBits_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RENDERTEXTUREDESCRIPTOR_T74FEC57A54F89E11748E1865F7DCA3565BFAF58E_H
#ifndef POSTPROCESSDEBUGLAYER_TEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75_H
#define POSTPROCESSDEBUGLAYER_TEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer
struct  PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75  : public RuntimeObject
{
public:
	// UnityEngine.Rendering.PostProcessing.LightMeterMonitor UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer::lightMeter
	LightMeterMonitor_t103A765AA459E486B43DFDD70451D3692977A684 * ___lightMeter_0;
	// UnityEngine.Rendering.PostProcessing.HistogramMonitor UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer::histogram
	HistogramMonitor_t682E9ACE9C9874B0230608D0A1C1382307907D87 * ___histogram_1;
	// UnityEngine.Rendering.PostProcessing.WaveformMonitor UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer::waveform
	WaveformMonitor_tFB0CBA9B59F081E6C36547430F4E417133968CA8 * ___waveform_2;
	// UnityEngine.Rendering.PostProcessing.VectorscopeMonitor UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer::vectorscope
	VectorscopeMonitor_tC3774A687F71D73031BC417A080D6C6BC9C519EA * ___vectorscope_3;
	// System.Collections.Generic.Dictionary`2<UnityEngine.Rendering.PostProcessing.MonitorType,UnityEngine.Rendering.PostProcessing.Monitor> UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer::m_Monitors
	Dictionary_2_tCA20F7F0C3B4446646E7C8E9AD388569634F963F * ___m_Monitors_4;
	// System.Int32 UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer::frameWidth
	int32_t ___frameWidth_5;
	// System.Int32 UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer::frameHeight
	int32_t ___frameHeight_6;
	// UnityEngine.RenderTexture UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer::<debugOverlayTarget>k__BackingField
	RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * ___U3CdebugOverlayTargetU3Ek__BackingField_7;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer::<debugOverlayActive>k__BackingField
	bool ___U3CdebugOverlayActiveU3Ek__BackingField_8;
	// UnityEngine.Rendering.PostProcessing.DebugOverlay UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer::<debugOverlay>k__BackingField
	int32_t ___U3CdebugOverlayU3Ek__BackingField_9;
	// UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer_OverlaySettings UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer::overlaySettings
	OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12 * ___overlaySettings_10;

public:
	inline static int32_t get_offset_of_lightMeter_0() { return static_cast<int32_t>(offsetof(PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75, ___lightMeter_0)); }
	inline LightMeterMonitor_t103A765AA459E486B43DFDD70451D3692977A684 * get_lightMeter_0() const { return ___lightMeter_0; }
	inline LightMeterMonitor_t103A765AA459E486B43DFDD70451D3692977A684 ** get_address_of_lightMeter_0() { return &___lightMeter_0; }
	inline void set_lightMeter_0(LightMeterMonitor_t103A765AA459E486B43DFDD70451D3692977A684 * value)
	{
		___lightMeter_0 = value;
		Il2CppCodeGenWriteBarrier((&___lightMeter_0), value);
	}

	inline static int32_t get_offset_of_histogram_1() { return static_cast<int32_t>(offsetof(PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75, ___histogram_1)); }
	inline HistogramMonitor_t682E9ACE9C9874B0230608D0A1C1382307907D87 * get_histogram_1() const { return ___histogram_1; }
	inline HistogramMonitor_t682E9ACE9C9874B0230608D0A1C1382307907D87 ** get_address_of_histogram_1() { return &___histogram_1; }
	inline void set_histogram_1(HistogramMonitor_t682E9ACE9C9874B0230608D0A1C1382307907D87 * value)
	{
		___histogram_1 = value;
		Il2CppCodeGenWriteBarrier((&___histogram_1), value);
	}

	inline static int32_t get_offset_of_waveform_2() { return static_cast<int32_t>(offsetof(PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75, ___waveform_2)); }
	inline WaveformMonitor_tFB0CBA9B59F081E6C36547430F4E417133968CA8 * get_waveform_2() const { return ___waveform_2; }
	inline WaveformMonitor_tFB0CBA9B59F081E6C36547430F4E417133968CA8 ** get_address_of_waveform_2() { return &___waveform_2; }
	inline void set_waveform_2(WaveformMonitor_tFB0CBA9B59F081E6C36547430F4E417133968CA8 * value)
	{
		___waveform_2 = value;
		Il2CppCodeGenWriteBarrier((&___waveform_2), value);
	}

	inline static int32_t get_offset_of_vectorscope_3() { return static_cast<int32_t>(offsetof(PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75, ___vectorscope_3)); }
	inline VectorscopeMonitor_tC3774A687F71D73031BC417A080D6C6BC9C519EA * get_vectorscope_3() const { return ___vectorscope_3; }
	inline VectorscopeMonitor_tC3774A687F71D73031BC417A080D6C6BC9C519EA ** get_address_of_vectorscope_3() { return &___vectorscope_3; }
	inline void set_vectorscope_3(VectorscopeMonitor_tC3774A687F71D73031BC417A080D6C6BC9C519EA * value)
	{
		___vectorscope_3 = value;
		Il2CppCodeGenWriteBarrier((&___vectorscope_3), value);
	}

	inline static int32_t get_offset_of_m_Monitors_4() { return static_cast<int32_t>(offsetof(PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75, ___m_Monitors_4)); }
	inline Dictionary_2_tCA20F7F0C3B4446646E7C8E9AD388569634F963F * get_m_Monitors_4() const { return ___m_Monitors_4; }
	inline Dictionary_2_tCA20F7F0C3B4446646E7C8E9AD388569634F963F ** get_address_of_m_Monitors_4() { return &___m_Monitors_4; }
	inline void set_m_Monitors_4(Dictionary_2_tCA20F7F0C3B4446646E7C8E9AD388569634F963F * value)
	{
		___m_Monitors_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_Monitors_4), value);
	}

	inline static int32_t get_offset_of_frameWidth_5() { return static_cast<int32_t>(offsetof(PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75, ___frameWidth_5)); }
	inline int32_t get_frameWidth_5() const { return ___frameWidth_5; }
	inline int32_t* get_address_of_frameWidth_5() { return &___frameWidth_5; }
	inline void set_frameWidth_5(int32_t value)
	{
		___frameWidth_5 = value;
	}

	inline static int32_t get_offset_of_frameHeight_6() { return static_cast<int32_t>(offsetof(PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75, ___frameHeight_6)); }
	inline int32_t get_frameHeight_6() const { return ___frameHeight_6; }
	inline int32_t* get_address_of_frameHeight_6() { return &___frameHeight_6; }
	inline void set_frameHeight_6(int32_t value)
	{
		___frameHeight_6 = value;
	}

	inline static int32_t get_offset_of_U3CdebugOverlayTargetU3Ek__BackingField_7() { return static_cast<int32_t>(offsetof(PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75, ___U3CdebugOverlayTargetU3Ek__BackingField_7)); }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * get_U3CdebugOverlayTargetU3Ek__BackingField_7() const { return ___U3CdebugOverlayTargetU3Ek__BackingField_7; }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 ** get_address_of_U3CdebugOverlayTargetU3Ek__BackingField_7() { return &___U3CdebugOverlayTargetU3Ek__BackingField_7; }
	inline void set_U3CdebugOverlayTargetU3Ek__BackingField_7(RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * value)
	{
		___U3CdebugOverlayTargetU3Ek__BackingField_7 = value;
		Il2CppCodeGenWriteBarrier((&___U3CdebugOverlayTargetU3Ek__BackingField_7), value);
	}

	inline static int32_t get_offset_of_U3CdebugOverlayActiveU3Ek__BackingField_8() { return static_cast<int32_t>(offsetof(PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75, ___U3CdebugOverlayActiveU3Ek__BackingField_8)); }
	inline bool get_U3CdebugOverlayActiveU3Ek__BackingField_8() const { return ___U3CdebugOverlayActiveU3Ek__BackingField_8; }
	inline bool* get_address_of_U3CdebugOverlayActiveU3Ek__BackingField_8() { return &___U3CdebugOverlayActiveU3Ek__BackingField_8; }
	inline void set_U3CdebugOverlayActiveU3Ek__BackingField_8(bool value)
	{
		___U3CdebugOverlayActiveU3Ek__BackingField_8 = value;
	}

	inline static int32_t get_offset_of_U3CdebugOverlayU3Ek__BackingField_9() { return static_cast<int32_t>(offsetof(PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75, ___U3CdebugOverlayU3Ek__BackingField_9)); }
	inline int32_t get_U3CdebugOverlayU3Ek__BackingField_9() const { return ___U3CdebugOverlayU3Ek__BackingField_9; }
	inline int32_t* get_address_of_U3CdebugOverlayU3Ek__BackingField_9() { return &___U3CdebugOverlayU3Ek__BackingField_9; }
	inline void set_U3CdebugOverlayU3Ek__BackingField_9(int32_t value)
	{
		___U3CdebugOverlayU3Ek__BackingField_9 = value;
	}

	inline static int32_t get_offset_of_overlaySettings_10() { return static_cast<int32_t>(offsetof(PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75, ___overlaySettings_10)); }
	inline OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12 * get_overlaySettings_10() const { return ___overlaySettings_10; }
	inline OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12 ** get_address_of_overlaySettings_10() { return &___overlaySettings_10; }
	inline void set_overlaySettings_10(OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12 * value)
	{
		___overlaySettings_10 = value;
		Il2CppCodeGenWriteBarrier((&___overlaySettings_10), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSDEBUGLAYER_TEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75_H
#ifndef OVERLAYSETTINGS_TD34A529B9C063CED3074E5908BD4999FDF7C7F12_H
#define OVERLAYSETTINGS_TD34A529B9C063CED3074E5908BD4999FDF7C7F12_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer_OverlaySettings
struct  OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12  : public RuntimeObject
{
public:
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer_OverlaySettings::linearDepth
	bool ___linearDepth_0;
	// System.Single UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer_OverlaySettings::motionColorIntensity
	float ___motionColorIntensity_1;
	// System.Int32 UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer_OverlaySettings::motionGridSize
	int32_t ___motionGridSize_2;
	// UnityEngine.Rendering.PostProcessing.ColorBlindnessType UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer_OverlaySettings::colorBlindnessType
	int32_t ___colorBlindnessType_3;
	// System.Single UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer_OverlaySettings::colorBlindnessStrength
	float ___colorBlindnessStrength_4;

public:
	inline static int32_t get_offset_of_linearDepth_0() { return static_cast<int32_t>(offsetof(OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12, ___linearDepth_0)); }
	inline bool get_linearDepth_0() const { return ___linearDepth_0; }
	inline bool* get_address_of_linearDepth_0() { return &___linearDepth_0; }
	inline void set_linearDepth_0(bool value)
	{
		___linearDepth_0 = value;
	}

	inline static int32_t get_offset_of_motionColorIntensity_1() { return static_cast<int32_t>(offsetof(OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12, ___motionColorIntensity_1)); }
	inline float get_motionColorIntensity_1() const { return ___motionColorIntensity_1; }
	inline float* get_address_of_motionColorIntensity_1() { return &___motionColorIntensity_1; }
	inline void set_motionColorIntensity_1(float value)
	{
		___motionColorIntensity_1 = value;
	}

	inline static int32_t get_offset_of_motionGridSize_2() { return static_cast<int32_t>(offsetof(OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12, ___motionGridSize_2)); }
	inline int32_t get_motionGridSize_2() const { return ___motionGridSize_2; }
	inline int32_t* get_address_of_motionGridSize_2() { return &___motionGridSize_2; }
	inline void set_motionGridSize_2(int32_t value)
	{
		___motionGridSize_2 = value;
	}

	inline static int32_t get_offset_of_colorBlindnessType_3() { return static_cast<int32_t>(offsetof(OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12, ___colorBlindnessType_3)); }
	inline int32_t get_colorBlindnessType_3() const { return ___colorBlindnessType_3; }
	inline int32_t* get_address_of_colorBlindnessType_3() { return &___colorBlindnessType_3; }
	inline void set_colorBlindnessType_3(int32_t value)
	{
		___colorBlindnessType_3 = value;
	}

	inline static int32_t get_offset_of_colorBlindnessStrength_4() { return static_cast<int32_t>(offsetof(OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12, ___colorBlindnessStrength_4)); }
	inline float get_colorBlindnessStrength_4() const { return ___colorBlindnessStrength_4; }
	inline float* get_address_of_colorBlindnessStrength_4() { return &___colorBlindnessStrength_4; }
	inline void set_colorBlindnessStrength_4(float value)
	{
		___colorBlindnessStrength_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // OVERLAYSETTINGS_TD34A529B9C063CED3074E5908BD4999FDF7C7F12_H
#ifndef U3CU3EC__DISPLAYCLASS51_0_TA2801E966AB67197C58DAE39A9D974BEB417D698_H
#define U3CU3EC__DISPLAYCLASS51_0_TA2801E966AB67197C58DAE39A9D974BEB417D698_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessLayer_<>c__DisplayClass51_0
struct  U3CU3Ec__DisplayClass51_0_tA2801E966AB67197C58DAE39A9D974BEB417D698  : public RuntimeObject
{
public:
	// UnityEngine.Rendering.PostProcessing.PostProcessEvent UnityEngine.Rendering.PostProcessing.PostProcessLayer_<>c__DisplayClass51_0::evt
	int32_t ___evt_0;
	// System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessBundle> UnityEngine.Rendering.PostProcessing.PostProcessLayer_<>c__DisplayClass51_0::effects
	List_1_tE71CBA0FB123ABF538C109CB3D91034AC3638455 * ___effects_1;

public:
	inline static int32_t get_offset_of_evt_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass51_0_tA2801E966AB67197C58DAE39A9D974BEB417D698, ___evt_0)); }
	inline int32_t get_evt_0() const { return ___evt_0; }
	inline int32_t* get_address_of_evt_0() { return &___evt_0; }
	inline void set_evt_0(int32_t value)
	{
		___evt_0 = value;
	}

	inline static int32_t get_offset_of_effects_1() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass51_0_tA2801E966AB67197C58DAE39A9D974BEB417D698, ___effects_1)); }
	inline List_1_tE71CBA0FB123ABF538C109CB3D91034AC3638455 * get_effects_1() const { return ___effects_1; }
	inline List_1_tE71CBA0FB123ABF538C109CB3D91034AC3638455 ** get_address_of_effects_1() { return &___effects_1; }
	inline void set_effects_1(List_1_tE71CBA0FB123ABF538C109CB3D91034AC3638455 * value)
	{
		___effects_1 = value;
		Il2CppCodeGenWriteBarrier((&___effects_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CU3EC__DISPLAYCLASS51_0_TA2801E966AB67197C58DAE39A9D974BEB417D698_H
#ifndef TEXTUREPARAMETER_TFB7692FD3A530A9AFE6E16A4DE84C92161698720_H
#define TEXTUREPARAMETER_TFB7692FD3A530A9AFE6E16A4DE84C92161698720_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.TextureParameter
struct  TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720  : public ParameterOverride_1_t2B9AE4432721024285C22999291BF22050E54238
{
public:
	// UnityEngine.Rendering.PostProcessing.TextureParameterDefault UnityEngine.Rendering.PostProcessing.TextureParameter::defaultState
	int32_t ___defaultState_2;

public:
	inline static int32_t get_offset_of_defaultState_2() { return static_cast<int32_t>(offsetof(TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720, ___defaultState_2)); }
	inline int32_t get_defaultState_2() const { return ___defaultState_2; }
	inline int32_t* get_address_of_defaultState_2() { return &___defaultState_2; }
	inline void set_defaultState_2(int32_t value)
	{
		___defaultState_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TEXTUREPARAMETER_TFB7692FD3A530A9AFE6E16A4DE84C92161698720_H
#ifndef RENDERTARGETIDENTIFIER_TB7480EE944FC70E0AB7D499DB17D119EB65B0F5B_H
#define RENDERTARGETIDENTIFIER_TB7480EE944FC70E0AB7D499DB17D119EB65B0F5B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.RenderTargetIdentifier
struct  RenderTargetIdentifier_tB7480EE944FC70E0AB7D499DB17D119EB65B0F5B 
{
public:
	// UnityEngine.Rendering.BuiltinRenderTextureType UnityEngine.Rendering.RenderTargetIdentifier::m_Type
	int32_t ___m_Type_0;
	// System.Int32 UnityEngine.Rendering.RenderTargetIdentifier::m_NameID
	int32_t ___m_NameID_1;
	// System.Int32 UnityEngine.Rendering.RenderTargetIdentifier::m_InstanceID
	int32_t ___m_InstanceID_2;
	// System.IntPtr UnityEngine.Rendering.RenderTargetIdentifier::m_BufferPointer
	intptr_t ___m_BufferPointer_3;
	// System.Int32 UnityEngine.Rendering.RenderTargetIdentifier::m_MipLevel
	int32_t ___m_MipLevel_4;
	// UnityEngine.CubemapFace UnityEngine.Rendering.RenderTargetIdentifier::m_CubeFace
	int32_t ___m_CubeFace_5;
	// System.Int32 UnityEngine.Rendering.RenderTargetIdentifier::m_DepthSlice
	int32_t ___m_DepthSlice_6;

public:
	inline static int32_t get_offset_of_m_Type_0() { return static_cast<int32_t>(offsetof(RenderTargetIdentifier_tB7480EE944FC70E0AB7D499DB17D119EB65B0F5B, ___m_Type_0)); }
	inline int32_t get_m_Type_0() const { return ___m_Type_0; }
	inline int32_t* get_address_of_m_Type_0() { return &___m_Type_0; }
	inline void set_m_Type_0(int32_t value)
	{
		___m_Type_0 = value;
	}

	inline static int32_t get_offset_of_m_NameID_1() { return static_cast<int32_t>(offsetof(RenderTargetIdentifier_tB7480EE944FC70E0AB7D499DB17D119EB65B0F5B, ___m_NameID_1)); }
	inline int32_t get_m_NameID_1() const { return ___m_NameID_1; }
	inline int32_t* get_address_of_m_NameID_1() { return &___m_NameID_1; }
	inline void set_m_NameID_1(int32_t value)
	{
		___m_NameID_1 = value;
	}

	inline static int32_t get_offset_of_m_InstanceID_2() { return static_cast<int32_t>(offsetof(RenderTargetIdentifier_tB7480EE944FC70E0AB7D499DB17D119EB65B0F5B, ___m_InstanceID_2)); }
	inline int32_t get_m_InstanceID_2() const { return ___m_InstanceID_2; }
	inline int32_t* get_address_of_m_InstanceID_2() { return &___m_InstanceID_2; }
	inline void set_m_InstanceID_2(int32_t value)
	{
		___m_InstanceID_2 = value;
	}

	inline static int32_t get_offset_of_m_BufferPointer_3() { return static_cast<int32_t>(offsetof(RenderTargetIdentifier_tB7480EE944FC70E0AB7D499DB17D119EB65B0F5B, ___m_BufferPointer_3)); }
	inline intptr_t get_m_BufferPointer_3() const { return ___m_BufferPointer_3; }
	inline intptr_t* get_address_of_m_BufferPointer_3() { return &___m_BufferPointer_3; }
	inline void set_m_BufferPointer_3(intptr_t value)
	{
		___m_BufferPointer_3 = value;
	}

	inline static int32_t get_offset_of_m_MipLevel_4() { return static_cast<int32_t>(offsetof(RenderTargetIdentifier_tB7480EE944FC70E0AB7D499DB17D119EB65B0F5B, ___m_MipLevel_4)); }
	inline int32_t get_m_MipLevel_4() const { return ___m_MipLevel_4; }
	inline int32_t* get_address_of_m_MipLevel_4() { return &___m_MipLevel_4; }
	inline void set_m_MipLevel_4(int32_t value)
	{
		___m_MipLevel_4 = value;
	}

	inline static int32_t get_offset_of_m_CubeFace_5() { return static_cast<int32_t>(offsetof(RenderTargetIdentifier_tB7480EE944FC70E0AB7D499DB17D119EB65B0F5B, ___m_CubeFace_5)); }
	inline int32_t get_m_CubeFace_5() const { return ___m_CubeFace_5; }
	inline int32_t* get_address_of_m_CubeFace_5() { return &___m_CubeFace_5; }
	inline void set_m_CubeFace_5(int32_t value)
	{
		___m_CubeFace_5 = value;
	}

	inline static int32_t get_offset_of_m_DepthSlice_6() { return static_cast<int32_t>(offsetof(RenderTargetIdentifier_tB7480EE944FC70E0AB7D499DB17D119EB65B0F5B, ___m_DepthSlice_6)); }
	inline int32_t get_m_DepthSlice_6() const { return ___m_DepthSlice_6; }
	inline int32_t* get_address_of_m_DepthSlice_6() { return &___m_DepthSlice_6; }
	inline void set_m_DepthSlice_6(int32_t value)
	{
		___m_DepthSlice_6 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RENDERTARGETIDENTIFIER_TB7480EE944FC70E0AB7D499DB17D119EB65B0F5B_H
#ifndef SCRIPTABLEOBJECT_TAB015486CEAB714DA0D5C1BA389B84FB90427734_H
#define SCRIPTABLEOBJECT_TAB015486CEAB714DA0D5C1BA389B84FB90427734_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.ScriptableObject
struct  ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734_marshaled_pinvoke : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
};
// Native definition for COM marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734_marshaled_com : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
};
#endif // SCRIPTABLEOBJECT_TAB015486CEAB714DA0D5C1BA389B84FB90427734_H
#ifndef BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#define BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Behaviour
struct  Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8  : public Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#ifndef POSTPROCESSEFFECTSETTINGS_T52802C256968EC72036018D471331281EC46E56E_H
#define POSTPROCESSEFFECTSETTINGS_T52802C256968EC72036018D471331281EC46E56E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings
struct  PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E  : public ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734
{
public:
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings::active
	bool ___active_4;
	// UnityEngine.Rendering.PostProcessing.BoolParameter UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings::enabled
	BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * ___enabled_5;
	// System.Collections.ObjectModel.ReadOnlyCollection`1<UnityEngine.Rendering.PostProcessing.ParameterOverride> UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings::parameters
	ReadOnlyCollection_1_t09ED47FDFC3DF44855A0AECF526E54628E99D966 * ___parameters_6;

public:
	inline static int32_t get_offset_of_active_4() { return static_cast<int32_t>(offsetof(PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E, ___active_4)); }
	inline bool get_active_4() const { return ___active_4; }
	inline bool* get_address_of_active_4() { return &___active_4; }
	inline void set_active_4(bool value)
	{
		___active_4 = value;
	}

	inline static int32_t get_offset_of_enabled_5() { return static_cast<int32_t>(offsetof(PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E, ___enabled_5)); }
	inline BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * get_enabled_5() const { return ___enabled_5; }
	inline BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 ** get_address_of_enabled_5() { return &___enabled_5; }
	inline void set_enabled_5(BoolParameter_tE4336B5D1812A2D76EE6C9769F0EA15A36993A32 * value)
	{
		___enabled_5 = value;
		Il2CppCodeGenWriteBarrier((&___enabled_5), value);
	}

	inline static int32_t get_offset_of_parameters_6() { return static_cast<int32_t>(offsetof(PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E, ___parameters_6)); }
	inline ReadOnlyCollection_1_t09ED47FDFC3DF44855A0AECF526E54628E99D966 * get_parameters_6() const { return ___parameters_6; }
	inline ReadOnlyCollection_1_t09ED47FDFC3DF44855A0AECF526E54628E99D966 ** get_address_of_parameters_6() { return &___parameters_6; }
	inline void set_parameters_6(ReadOnlyCollection_1_t09ED47FDFC3DF44855A0AECF526E54628E99D966 * value)
	{
		___parameters_6 = value;
		Il2CppCodeGenWriteBarrier((&___parameters_6), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSEFFECTSETTINGS_T52802C256968EC72036018D471331281EC46E56E_H
#ifndef POSTPROCESSPROFILE_T8C94889A4E09E180663F26AB74D53B1E98D8C45F_H
#define POSTPROCESSPROFILE_T8C94889A4E09E180663F26AB74D53B1E98D8C45F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessProfile
struct  PostProcessProfile_t8C94889A4E09E180663F26AB74D53B1E98D8C45F  : public ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734
{
public:
	// System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessEffectSettings> UnityEngine.Rendering.PostProcessing.PostProcessProfile::settings
	List_1_tC82B3FE12BB2B40AE4E4672E4302D78EB191BADC * ___settings_4;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessProfile::isDirty
	bool ___isDirty_5;

public:
	inline static int32_t get_offset_of_settings_4() { return static_cast<int32_t>(offsetof(PostProcessProfile_t8C94889A4E09E180663F26AB74D53B1E98D8C45F, ___settings_4)); }
	inline List_1_tC82B3FE12BB2B40AE4E4672E4302D78EB191BADC * get_settings_4() const { return ___settings_4; }
	inline List_1_tC82B3FE12BB2B40AE4E4672E4302D78EB191BADC ** get_address_of_settings_4() { return &___settings_4; }
	inline void set_settings_4(List_1_tC82B3FE12BB2B40AE4E4672E4302D78EB191BADC * value)
	{
		___settings_4 = value;
		Il2CppCodeGenWriteBarrier((&___settings_4), value);
	}

	inline static int32_t get_offset_of_isDirty_5() { return static_cast<int32_t>(offsetof(PostProcessProfile_t8C94889A4E09E180663F26AB74D53B1E98D8C45F, ___isDirty_5)); }
	inline bool get_isDirty_5() const { return ___isDirty_5; }
	inline bool* get_address_of_isDirty_5() { return &___isDirty_5; }
	inline void set_isDirty_5(bool value)
	{
		___isDirty_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSPROFILE_T8C94889A4E09E180663F26AB74D53B1E98D8C45F_H
#ifndef POSTPROCESSRENDERCONTEXT_T601F1237B2FF9EFE88E3A15A0EFF801072474A18_H
#define POSTPROCESSRENDERCONTEXT_T601F1237B2FF9EFE88E3A15A0EFF801072474A18_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessRenderContext
struct  PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18  : public RuntimeObject
{
public:
	// UnityEngine.Camera UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::m_Camera
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ___m_Camera_0;
	// UnityEngine.Rendering.CommandBuffer UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<command>k__BackingField
	CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * ___U3CcommandU3Ek__BackingField_1;
	// UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<source>k__BackingField
	RenderTargetIdentifier_tB7480EE944FC70E0AB7D499DB17D119EB65B0F5B  ___U3CsourceU3Ek__BackingField_2;
	// UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<destination>k__BackingField
	RenderTargetIdentifier_tB7480EE944FC70E0AB7D499DB17D119EB65B0F5B  ___U3CdestinationU3Ek__BackingField_3;
	// UnityEngine.RenderTextureFormat UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<sourceFormat>k__BackingField
	int32_t ___U3CsourceFormatU3Ek__BackingField_4;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<flip>k__BackingField
	bool ___U3CflipU3Ek__BackingField_5;
	// UnityEngine.Rendering.PostProcessing.PostProcessResources UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<resources>k__BackingField
	PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 * ___U3CresourcesU3Ek__BackingField_6;
	// UnityEngine.Rendering.PostProcessing.PropertySheetFactory UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<propertySheets>k__BackingField
	PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68 * ___U3CpropertySheetsU3Ek__BackingField_7;
	// System.Collections.Generic.Dictionary`2<System.String,System.Object> UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<userData>k__BackingField
	Dictionary_2_t9140A71329927AE4FD0F3CF4D4D66668EBE151EA * ___U3CuserDataU3Ek__BackingField_8;
	// UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<debugLayer>k__BackingField
	PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75 * ___U3CdebugLayerU3Ek__BackingField_9;
	// System.Int32 UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<width>k__BackingField
	int32_t ___U3CwidthU3Ek__BackingField_10;
	// System.Int32 UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<height>k__BackingField
	int32_t ___U3CheightU3Ek__BackingField_11;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<stereoActive>k__BackingField
	bool ___U3CstereoActiveU3Ek__BackingField_12;
	// System.Int32 UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<xrActiveEye>k__BackingField
	int32_t ___U3CxrActiveEyeU3Ek__BackingField_13;
	// System.Int32 UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<numberOfEyes>k__BackingField
	int32_t ___U3CnumberOfEyesU3Ek__BackingField_14;
	// UnityEngine.Rendering.PostProcessing.PostProcessRenderContext_StereoRenderingMode UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<stereoRenderingMode>k__BackingField
	int32_t ___U3CstereoRenderingModeU3Ek__BackingField_15;
	// System.Int32 UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<screenWidth>k__BackingField
	int32_t ___U3CscreenWidthU3Ek__BackingField_16;
	// System.Int32 UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<screenHeight>k__BackingField
	int32_t ___U3CscreenHeightU3Ek__BackingField_17;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<isSceneView>k__BackingField
	bool ___U3CisSceneViewU3Ek__BackingField_18;
	// UnityEngine.Rendering.PostProcessing.PostProcessLayer_Antialiasing UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<antialiasing>k__BackingField
	int32_t ___U3CantialiasingU3Ek__BackingField_19;
	// UnityEngine.Rendering.PostProcessing.TemporalAntialiasing UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::<temporalAntialiasing>k__BackingField
	TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B * ___U3CtemporalAntialiasingU3Ek__BackingField_20;
	// UnityEngine.Rendering.PostProcessing.PropertySheet UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::uberSheet
	PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 * ___uberSheet_21;
	// UnityEngine.Texture UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::autoExposureTexture
	Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * ___autoExposureTexture_22;
	// UnityEngine.Rendering.PostProcessing.LogHistogram UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::logHistogram
	LogHistogram_t047FFE5627C5FCEF5FFB5DBCCAEC406DA7F07AB8 * ___logHistogram_23;
	// UnityEngine.Texture UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::logLut
	Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * ___logLut_24;
	// UnityEngine.Rendering.PostProcessing.AutoExposure UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::autoExposure
	AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C * ___autoExposure_25;
	// System.Int32 UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::bloomBufferNameID
	int32_t ___bloomBufferNameID_26;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::physicalCamera
	bool ___physicalCamera_27;
	// UnityEngine.RenderTextureDescriptor UnityEngine.Rendering.PostProcessing.PostProcessRenderContext::m_sourceDescriptor
	RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E  ___m_sourceDescriptor_28;

public:
	inline static int32_t get_offset_of_m_Camera_0() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___m_Camera_0)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get_m_Camera_0() const { return ___m_Camera_0; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of_m_Camera_0() { return &___m_Camera_0; }
	inline void set_m_Camera_0(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		___m_Camera_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_Camera_0), value);
	}

	inline static int32_t get_offset_of_U3CcommandU3Ek__BackingField_1() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CcommandU3Ek__BackingField_1)); }
	inline CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * get_U3CcommandU3Ek__BackingField_1() const { return ___U3CcommandU3Ek__BackingField_1; }
	inline CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD ** get_address_of_U3CcommandU3Ek__BackingField_1() { return &___U3CcommandU3Ek__BackingField_1; }
	inline void set_U3CcommandU3Ek__BackingField_1(CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * value)
	{
		___U3CcommandU3Ek__BackingField_1 = value;
		Il2CppCodeGenWriteBarrier((&___U3CcommandU3Ek__BackingField_1), value);
	}

	inline static int32_t get_offset_of_U3CsourceU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CsourceU3Ek__BackingField_2)); }
	inline RenderTargetIdentifier_tB7480EE944FC70E0AB7D499DB17D119EB65B0F5B  get_U3CsourceU3Ek__BackingField_2() const { return ___U3CsourceU3Ek__BackingField_2; }
	inline RenderTargetIdentifier_tB7480EE944FC70E0AB7D499DB17D119EB65B0F5B * get_address_of_U3CsourceU3Ek__BackingField_2() { return &___U3CsourceU3Ek__BackingField_2; }
	inline void set_U3CsourceU3Ek__BackingField_2(RenderTargetIdentifier_tB7480EE944FC70E0AB7D499DB17D119EB65B0F5B  value)
	{
		___U3CsourceU3Ek__BackingField_2 = value;
	}

	inline static int32_t get_offset_of_U3CdestinationU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CdestinationU3Ek__BackingField_3)); }
	inline RenderTargetIdentifier_tB7480EE944FC70E0AB7D499DB17D119EB65B0F5B  get_U3CdestinationU3Ek__BackingField_3() const { return ___U3CdestinationU3Ek__BackingField_3; }
	inline RenderTargetIdentifier_tB7480EE944FC70E0AB7D499DB17D119EB65B0F5B * get_address_of_U3CdestinationU3Ek__BackingField_3() { return &___U3CdestinationU3Ek__BackingField_3; }
	inline void set_U3CdestinationU3Ek__BackingField_3(RenderTargetIdentifier_tB7480EE944FC70E0AB7D499DB17D119EB65B0F5B  value)
	{
		___U3CdestinationU3Ek__BackingField_3 = value;
	}

	inline static int32_t get_offset_of_U3CsourceFormatU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CsourceFormatU3Ek__BackingField_4)); }
	inline int32_t get_U3CsourceFormatU3Ek__BackingField_4() const { return ___U3CsourceFormatU3Ek__BackingField_4; }
	inline int32_t* get_address_of_U3CsourceFormatU3Ek__BackingField_4() { return &___U3CsourceFormatU3Ek__BackingField_4; }
	inline void set_U3CsourceFormatU3Ek__BackingField_4(int32_t value)
	{
		___U3CsourceFormatU3Ek__BackingField_4 = value;
	}

	inline static int32_t get_offset_of_U3CflipU3Ek__BackingField_5() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CflipU3Ek__BackingField_5)); }
	inline bool get_U3CflipU3Ek__BackingField_5() const { return ___U3CflipU3Ek__BackingField_5; }
	inline bool* get_address_of_U3CflipU3Ek__BackingField_5() { return &___U3CflipU3Ek__BackingField_5; }
	inline void set_U3CflipU3Ek__BackingField_5(bool value)
	{
		___U3CflipU3Ek__BackingField_5 = value;
	}

	inline static int32_t get_offset_of_U3CresourcesU3Ek__BackingField_6() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CresourcesU3Ek__BackingField_6)); }
	inline PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 * get_U3CresourcesU3Ek__BackingField_6() const { return ___U3CresourcesU3Ek__BackingField_6; }
	inline PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 ** get_address_of_U3CresourcesU3Ek__BackingField_6() { return &___U3CresourcesU3Ek__BackingField_6; }
	inline void set_U3CresourcesU3Ek__BackingField_6(PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 * value)
	{
		___U3CresourcesU3Ek__BackingField_6 = value;
		Il2CppCodeGenWriteBarrier((&___U3CresourcesU3Ek__BackingField_6), value);
	}

	inline static int32_t get_offset_of_U3CpropertySheetsU3Ek__BackingField_7() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CpropertySheetsU3Ek__BackingField_7)); }
	inline PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68 * get_U3CpropertySheetsU3Ek__BackingField_7() const { return ___U3CpropertySheetsU3Ek__BackingField_7; }
	inline PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68 ** get_address_of_U3CpropertySheetsU3Ek__BackingField_7() { return &___U3CpropertySheetsU3Ek__BackingField_7; }
	inline void set_U3CpropertySheetsU3Ek__BackingField_7(PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68 * value)
	{
		___U3CpropertySheetsU3Ek__BackingField_7 = value;
		Il2CppCodeGenWriteBarrier((&___U3CpropertySheetsU3Ek__BackingField_7), value);
	}

	inline static int32_t get_offset_of_U3CuserDataU3Ek__BackingField_8() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CuserDataU3Ek__BackingField_8)); }
	inline Dictionary_2_t9140A71329927AE4FD0F3CF4D4D66668EBE151EA * get_U3CuserDataU3Ek__BackingField_8() const { return ___U3CuserDataU3Ek__BackingField_8; }
	inline Dictionary_2_t9140A71329927AE4FD0F3CF4D4D66668EBE151EA ** get_address_of_U3CuserDataU3Ek__BackingField_8() { return &___U3CuserDataU3Ek__BackingField_8; }
	inline void set_U3CuserDataU3Ek__BackingField_8(Dictionary_2_t9140A71329927AE4FD0F3CF4D4D66668EBE151EA * value)
	{
		___U3CuserDataU3Ek__BackingField_8 = value;
		Il2CppCodeGenWriteBarrier((&___U3CuserDataU3Ek__BackingField_8), value);
	}

	inline static int32_t get_offset_of_U3CdebugLayerU3Ek__BackingField_9() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CdebugLayerU3Ek__BackingField_9)); }
	inline PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75 * get_U3CdebugLayerU3Ek__BackingField_9() const { return ___U3CdebugLayerU3Ek__BackingField_9; }
	inline PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75 ** get_address_of_U3CdebugLayerU3Ek__BackingField_9() { return &___U3CdebugLayerU3Ek__BackingField_9; }
	inline void set_U3CdebugLayerU3Ek__BackingField_9(PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75 * value)
	{
		___U3CdebugLayerU3Ek__BackingField_9 = value;
		Il2CppCodeGenWriteBarrier((&___U3CdebugLayerU3Ek__BackingField_9), value);
	}

	inline static int32_t get_offset_of_U3CwidthU3Ek__BackingField_10() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CwidthU3Ek__BackingField_10)); }
	inline int32_t get_U3CwidthU3Ek__BackingField_10() const { return ___U3CwidthU3Ek__BackingField_10; }
	inline int32_t* get_address_of_U3CwidthU3Ek__BackingField_10() { return &___U3CwidthU3Ek__BackingField_10; }
	inline void set_U3CwidthU3Ek__BackingField_10(int32_t value)
	{
		___U3CwidthU3Ek__BackingField_10 = value;
	}

	inline static int32_t get_offset_of_U3CheightU3Ek__BackingField_11() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CheightU3Ek__BackingField_11)); }
	inline int32_t get_U3CheightU3Ek__BackingField_11() const { return ___U3CheightU3Ek__BackingField_11; }
	inline int32_t* get_address_of_U3CheightU3Ek__BackingField_11() { return &___U3CheightU3Ek__BackingField_11; }
	inline void set_U3CheightU3Ek__BackingField_11(int32_t value)
	{
		___U3CheightU3Ek__BackingField_11 = value;
	}

	inline static int32_t get_offset_of_U3CstereoActiveU3Ek__BackingField_12() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CstereoActiveU3Ek__BackingField_12)); }
	inline bool get_U3CstereoActiveU3Ek__BackingField_12() const { return ___U3CstereoActiveU3Ek__BackingField_12; }
	inline bool* get_address_of_U3CstereoActiveU3Ek__BackingField_12() { return &___U3CstereoActiveU3Ek__BackingField_12; }
	inline void set_U3CstereoActiveU3Ek__BackingField_12(bool value)
	{
		___U3CstereoActiveU3Ek__BackingField_12 = value;
	}

	inline static int32_t get_offset_of_U3CxrActiveEyeU3Ek__BackingField_13() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CxrActiveEyeU3Ek__BackingField_13)); }
	inline int32_t get_U3CxrActiveEyeU3Ek__BackingField_13() const { return ___U3CxrActiveEyeU3Ek__BackingField_13; }
	inline int32_t* get_address_of_U3CxrActiveEyeU3Ek__BackingField_13() { return &___U3CxrActiveEyeU3Ek__BackingField_13; }
	inline void set_U3CxrActiveEyeU3Ek__BackingField_13(int32_t value)
	{
		___U3CxrActiveEyeU3Ek__BackingField_13 = value;
	}

	inline static int32_t get_offset_of_U3CnumberOfEyesU3Ek__BackingField_14() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CnumberOfEyesU3Ek__BackingField_14)); }
	inline int32_t get_U3CnumberOfEyesU3Ek__BackingField_14() const { return ___U3CnumberOfEyesU3Ek__BackingField_14; }
	inline int32_t* get_address_of_U3CnumberOfEyesU3Ek__BackingField_14() { return &___U3CnumberOfEyesU3Ek__BackingField_14; }
	inline void set_U3CnumberOfEyesU3Ek__BackingField_14(int32_t value)
	{
		___U3CnumberOfEyesU3Ek__BackingField_14 = value;
	}

	inline static int32_t get_offset_of_U3CstereoRenderingModeU3Ek__BackingField_15() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CstereoRenderingModeU3Ek__BackingField_15)); }
	inline int32_t get_U3CstereoRenderingModeU3Ek__BackingField_15() const { return ___U3CstereoRenderingModeU3Ek__BackingField_15; }
	inline int32_t* get_address_of_U3CstereoRenderingModeU3Ek__BackingField_15() { return &___U3CstereoRenderingModeU3Ek__BackingField_15; }
	inline void set_U3CstereoRenderingModeU3Ek__BackingField_15(int32_t value)
	{
		___U3CstereoRenderingModeU3Ek__BackingField_15 = value;
	}

	inline static int32_t get_offset_of_U3CscreenWidthU3Ek__BackingField_16() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CscreenWidthU3Ek__BackingField_16)); }
	inline int32_t get_U3CscreenWidthU3Ek__BackingField_16() const { return ___U3CscreenWidthU3Ek__BackingField_16; }
	inline int32_t* get_address_of_U3CscreenWidthU3Ek__BackingField_16() { return &___U3CscreenWidthU3Ek__BackingField_16; }
	inline void set_U3CscreenWidthU3Ek__BackingField_16(int32_t value)
	{
		___U3CscreenWidthU3Ek__BackingField_16 = value;
	}

	inline static int32_t get_offset_of_U3CscreenHeightU3Ek__BackingField_17() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CscreenHeightU3Ek__BackingField_17)); }
	inline int32_t get_U3CscreenHeightU3Ek__BackingField_17() const { return ___U3CscreenHeightU3Ek__BackingField_17; }
	inline int32_t* get_address_of_U3CscreenHeightU3Ek__BackingField_17() { return &___U3CscreenHeightU3Ek__BackingField_17; }
	inline void set_U3CscreenHeightU3Ek__BackingField_17(int32_t value)
	{
		___U3CscreenHeightU3Ek__BackingField_17 = value;
	}

	inline static int32_t get_offset_of_U3CisSceneViewU3Ek__BackingField_18() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CisSceneViewU3Ek__BackingField_18)); }
	inline bool get_U3CisSceneViewU3Ek__BackingField_18() const { return ___U3CisSceneViewU3Ek__BackingField_18; }
	inline bool* get_address_of_U3CisSceneViewU3Ek__BackingField_18() { return &___U3CisSceneViewU3Ek__BackingField_18; }
	inline void set_U3CisSceneViewU3Ek__BackingField_18(bool value)
	{
		___U3CisSceneViewU3Ek__BackingField_18 = value;
	}

	inline static int32_t get_offset_of_U3CantialiasingU3Ek__BackingField_19() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CantialiasingU3Ek__BackingField_19)); }
	inline int32_t get_U3CantialiasingU3Ek__BackingField_19() const { return ___U3CantialiasingU3Ek__BackingField_19; }
	inline int32_t* get_address_of_U3CantialiasingU3Ek__BackingField_19() { return &___U3CantialiasingU3Ek__BackingField_19; }
	inline void set_U3CantialiasingU3Ek__BackingField_19(int32_t value)
	{
		___U3CantialiasingU3Ek__BackingField_19 = value;
	}

	inline static int32_t get_offset_of_U3CtemporalAntialiasingU3Ek__BackingField_20() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___U3CtemporalAntialiasingU3Ek__BackingField_20)); }
	inline TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B * get_U3CtemporalAntialiasingU3Ek__BackingField_20() const { return ___U3CtemporalAntialiasingU3Ek__BackingField_20; }
	inline TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B ** get_address_of_U3CtemporalAntialiasingU3Ek__BackingField_20() { return &___U3CtemporalAntialiasingU3Ek__BackingField_20; }
	inline void set_U3CtemporalAntialiasingU3Ek__BackingField_20(TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B * value)
	{
		___U3CtemporalAntialiasingU3Ek__BackingField_20 = value;
		Il2CppCodeGenWriteBarrier((&___U3CtemporalAntialiasingU3Ek__BackingField_20), value);
	}

	inline static int32_t get_offset_of_uberSheet_21() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___uberSheet_21)); }
	inline PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 * get_uberSheet_21() const { return ___uberSheet_21; }
	inline PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 ** get_address_of_uberSheet_21() { return &___uberSheet_21; }
	inline void set_uberSheet_21(PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212 * value)
	{
		___uberSheet_21 = value;
		Il2CppCodeGenWriteBarrier((&___uberSheet_21), value);
	}

	inline static int32_t get_offset_of_autoExposureTexture_22() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___autoExposureTexture_22)); }
	inline Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * get_autoExposureTexture_22() const { return ___autoExposureTexture_22; }
	inline Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 ** get_address_of_autoExposureTexture_22() { return &___autoExposureTexture_22; }
	inline void set_autoExposureTexture_22(Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * value)
	{
		___autoExposureTexture_22 = value;
		Il2CppCodeGenWriteBarrier((&___autoExposureTexture_22), value);
	}

	inline static int32_t get_offset_of_logHistogram_23() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___logHistogram_23)); }
	inline LogHistogram_t047FFE5627C5FCEF5FFB5DBCCAEC406DA7F07AB8 * get_logHistogram_23() const { return ___logHistogram_23; }
	inline LogHistogram_t047FFE5627C5FCEF5FFB5DBCCAEC406DA7F07AB8 ** get_address_of_logHistogram_23() { return &___logHistogram_23; }
	inline void set_logHistogram_23(LogHistogram_t047FFE5627C5FCEF5FFB5DBCCAEC406DA7F07AB8 * value)
	{
		___logHistogram_23 = value;
		Il2CppCodeGenWriteBarrier((&___logHistogram_23), value);
	}

	inline static int32_t get_offset_of_logLut_24() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___logLut_24)); }
	inline Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * get_logLut_24() const { return ___logLut_24; }
	inline Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 ** get_address_of_logLut_24() { return &___logLut_24; }
	inline void set_logLut_24(Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * value)
	{
		___logLut_24 = value;
		Il2CppCodeGenWriteBarrier((&___logLut_24), value);
	}

	inline static int32_t get_offset_of_autoExposure_25() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___autoExposure_25)); }
	inline AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C * get_autoExposure_25() const { return ___autoExposure_25; }
	inline AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C ** get_address_of_autoExposure_25() { return &___autoExposure_25; }
	inline void set_autoExposure_25(AutoExposure_tFF4D354ADDD055C0C9E758B6150353B9B753A97C * value)
	{
		___autoExposure_25 = value;
		Il2CppCodeGenWriteBarrier((&___autoExposure_25), value);
	}

	inline static int32_t get_offset_of_bloomBufferNameID_26() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___bloomBufferNameID_26)); }
	inline int32_t get_bloomBufferNameID_26() const { return ___bloomBufferNameID_26; }
	inline int32_t* get_address_of_bloomBufferNameID_26() { return &___bloomBufferNameID_26; }
	inline void set_bloomBufferNameID_26(int32_t value)
	{
		___bloomBufferNameID_26 = value;
	}

	inline static int32_t get_offset_of_physicalCamera_27() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___physicalCamera_27)); }
	inline bool get_physicalCamera_27() const { return ___physicalCamera_27; }
	inline bool* get_address_of_physicalCamera_27() { return &___physicalCamera_27; }
	inline void set_physicalCamera_27(bool value)
	{
		___physicalCamera_27 = value;
	}

	inline static int32_t get_offset_of_m_sourceDescriptor_28() { return static_cast<int32_t>(offsetof(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18, ___m_sourceDescriptor_28)); }
	inline RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E  get_m_sourceDescriptor_28() const { return ___m_sourceDescriptor_28; }
	inline RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E * get_address_of_m_sourceDescriptor_28() { return &___m_sourceDescriptor_28; }
	inline void set_m_sourceDescriptor_28(RenderTextureDescriptor_t74FEC57A54F89E11748E1865F7DCA3565BFAF58E  value)
	{
		___m_sourceDescriptor_28 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSRENDERCONTEXT_T601F1237B2FF9EFE88E3A15A0EFF801072474A18_H
#ifndef POSTPROCESSRESOURCES_T63243B16DDFD1A240B4AA1F69A063C2996E38B98_H
#define POSTPROCESSRESOURCES_T63243B16DDFD1A240B4AA1F69A063C2996E38B98_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessResources
struct  PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98  : public ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734
{
public:
	// UnityEngine.Texture2D[] UnityEngine.Rendering.PostProcessing.PostProcessResources::blueNoise64
	Texture2DU5BU5D_tCAC03055C735C020BAFC218D55183CF03E74C1C9* ___blueNoise64_4;
	// UnityEngine.Texture2D[] UnityEngine.Rendering.PostProcessing.PostProcessResources::blueNoise256
	Texture2DU5BU5D_tCAC03055C735C020BAFC218D55183CF03E74C1C9* ___blueNoise256_5;
	// UnityEngine.Rendering.PostProcessing.PostProcessResources_SMAALuts UnityEngine.Rendering.PostProcessing.PostProcessResources::smaaLuts
	SMAALuts_t4E0EB2F1BAD60C948B7153C88F485EE928445519 * ___smaaLuts_6;
	// UnityEngine.Rendering.PostProcessing.PostProcessResources_Shaders UnityEngine.Rendering.PostProcessing.PostProcessResources::shaders
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510 * ___shaders_7;
	// UnityEngine.Rendering.PostProcessing.PostProcessResources_ComputeShaders UnityEngine.Rendering.PostProcessing.PostProcessResources::computeShaders
	ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2 * ___computeShaders_8;

public:
	inline static int32_t get_offset_of_blueNoise64_4() { return static_cast<int32_t>(offsetof(PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98, ___blueNoise64_4)); }
	inline Texture2DU5BU5D_tCAC03055C735C020BAFC218D55183CF03E74C1C9* get_blueNoise64_4() const { return ___blueNoise64_4; }
	inline Texture2DU5BU5D_tCAC03055C735C020BAFC218D55183CF03E74C1C9** get_address_of_blueNoise64_4() { return &___blueNoise64_4; }
	inline void set_blueNoise64_4(Texture2DU5BU5D_tCAC03055C735C020BAFC218D55183CF03E74C1C9* value)
	{
		___blueNoise64_4 = value;
		Il2CppCodeGenWriteBarrier((&___blueNoise64_4), value);
	}

	inline static int32_t get_offset_of_blueNoise256_5() { return static_cast<int32_t>(offsetof(PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98, ___blueNoise256_5)); }
	inline Texture2DU5BU5D_tCAC03055C735C020BAFC218D55183CF03E74C1C9* get_blueNoise256_5() const { return ___blueNoise256_5; }
	inline Texture2DU5BU5D_tCAC03055C735C020BAFC218D55183CF03E74C1C9** get_address_of_blueNoise256_5() { return &___blueNoise256_5; }
	inline void set_blueNoise256_5(Texture2DU5BU5D_tCAC03055C735C020BAFC218D55183CF03E74C1C9* value)
	{
		___blueNoise256_5 = value;
		Il2CppCodeGenWriteBarrier((&___blueNoise256_5), value);
	}

	inline static int32_t get_offset_of_smaaLuts_6() { return static_cast<int32_t>(offsetof(PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98, ___smaaLuts_6)); }
	inline SMAALuts_t4E0EB2F1BAD60C948B7153C88F485EE928445519 * get_smaaLuts_6() const { return ___smaaLuts_6; }
	inline SMAALuts_t4E0EB2F1BAD60C948B7153C88F485EE928445519 ** get_address_of_smaaLuts_6() { return &___smaaLuts_6; }
	inline void set_smaaLuts_6(SMAALuts_t4E0EB2F1BAD60C948B7153C88F485EE928445519 * value)
	{
		___smaaLuts_6 = value;
		Il2CppCodeGenWriteBarrier((&___smaaLuts_6), value);
	}

	inline static int32_t get_offset_of_shaders_7() { return static_cast<int32_t>(offsetof(PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98, ___shaders_7)); }
	inline Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510 * get_shaders_7() const { return ___shaders_7; }
	inline Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510 ** get_address_of_shaders_7() { return &___shaders_7; }
	inline void set_shaders_7(Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510 * value)
	{
		___shaders_7 = value;
		Il2CppCodeGenWriteBarrier((&___shaders_7), value);
	}

	inline static int32_t get_offset_of_computeShaders_8() { return static_cast<int32_t>(offsetof(PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98, ___computeShaders_8)); }
	inline ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2 * get_computeShaders_8() const { return ___computeShaders_8; }
	inline ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2 ** get_address_of_computeShaders_8() { return &___computeShaders_8; }
	inline void set_computeShaders_8(ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2 * value)
	{
		___computeShaders_8 = value;
		Il2CppCodeGenWriteBarrier((&___computeShaders_8), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSRESOURCES_T63243B16DDFD1A240B4AA1F69A063C2996E38B98_H
#ifndef MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#define MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.MonoBehaviour
struct  MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429  : public Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#ifndef POSTPROCESSDEBUG_TD6DF94623717DA10547ADB59376E6725E137AA96_H
#define POSTPROCESSDEBUG_TD6DF94623717DA10547ADB59376E6725E137AA96_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessDebug
struct  PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Rendering.PostProcessing.PostProcessLayer UnityEngine.Rendering.PostProcessing.PostProcessDebug::postProcessLayer
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08 * ___postProcessLayer_4;
	// UnityEngine.Rendering.PostProcessing.PostProcessLayer UnityEngine.Rendering.PostProcessing.PostProcessDebug::m_PreviousPostProcessLayer
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08 * ___m_PreviousPostProcessLayer_5;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessDebug::lightMeter
	bool ___lightMeter_6;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessDebug::histogram
	bool ___histogram_7;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessDebug::waveform
	bool ___waveform_8;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessDebug::vectorscope
	bool ___vectorscope_9;
	// UnityEngine.Rendering.PostProcessing.DebugOverlay UnityEngine.Rendering.PostProcessing.PostProcessDebug::debugOverlay
	int32_t ___debugOverlay_10;
	// UnityEngine.Camera UnityEngine.Rendering.PostProcessing.PostProcessDebug::m_CurrentCamera
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ___m_CurrentCamera_11;
	// UnityEngine.Rendering.CommandBuffer UnityEngine.Rendering.PostProcessing.PostProcessDebug::m_CmdAfterEverything
	CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * ___m_CmdAfterEverything_12;

public:
	inline static int32_t get_offset_of_postProcessLayer_4() { return static_cast<int32_t>(offsetof(PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96, ___postProcessLayer_4)); }
	inline PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08 * get_postProcessLayer_4() const { return ___postProcessLayer_4; }
	inline PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08 ** get_address_of_postProcessLayer_4() { return &___postProcessLayer_4; }
	inline void set_postProcessLayer_4(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08 * value)
	{
		___postProcessLayer_4 = value;
		Il2CppCodeGenWriteBarrier((&___postProcessLayer_4), value);
	}

	inline static int32_t get_offset_of_m_PreviousPostProcessLayer_5() { return static_cast<int32_t>(offsetof(PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96, ___m_PreviousPostProcessLayer_5)); }
	inline PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08 * get_m_PreviousPostProcessLayer_5() const { return ___m_PreviousPostProcessLayer_5; }
	inline PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08 ** get_address_of_m_PreviousPostProcessLayer_5() { return &___m_PreviousPostProcessLayer_5; }
	inline void set_m_PreviousPostProcessLayer_5(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08 * value)
	{
		___m_PreviousPostProcessLayer_5 = value;
		Il2CppCodeGenWriteBarrier((&___m_PreviousPostProcessLayer_5), value);
	}

	inline static int32_t get_offset_of_lightMeter_6() { return static_cast<int32_t>(offsetof(PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96, ___lightMeter_6)); }
	inline bool get_lightMeter_6() const { return ___lightMeter_6; }
	inline bool* get_address_of_lightMeter_6() { return &___lightMeter_6; }
	inline void set_lightMeter_6(bool value)
	{
		___lightMeter_6 = value;
	}

	inline static int32_t get_offset_of_histogram_7() { return static_cast<int32_t>(offsetof(PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96, ___histogram_7)); }
	inline bool get_histogram_7() const { return ___histogram_7; }
	inline bool* get_address_of_histogram_7() { return &___histogram_7; }
	inline void set_histogram_7(bool value)
	{
		___histogram_7 = value;
	}

	inline static int32_t get_offset_of_waveform_8() { return static_cast<int32_t>(offsetof(PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96, ___waveform_8)); }
	inline bool get_waveform_8() const { return ___waveform_8; }
	inline bool* get_address_of_waveform_8() { return &___waveform_8; }
	inline void set_waveform_8(bool value)
	{
		___waveform_8 = value;
	}

	inline static int32_t get_offset_of_vectorscope_9() { return static_cast<int32_t>(offsetof(PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96, ___vectorscope_9)); }
	inline bool get_vectorscope_9() const { return ___vectorscope_9; }
	inline bool* get_address_of_vectorscope_9() { return &___vectorscope_9; }
	inline void set_vectorscope_9(bool value)
	{
		___vectorscope_9 = value;
	}

	inline static int32_t get_offset_of_debugOverlay_10() { return static_cast<int32_t>(offsetof(PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96, ___debugOverlay_10)); }
	inline int32_t get_debugOverlay_10() const { return ___debugOverlay_10; }
	inline int32_t* get_address_of_debugOverlay_10() { return &___debugOverlay_10; }
	inline void set_debugOverlay_10(int32_t value)
	{
		___debugOverlay_10 = value;
	}

	inline static int32_t get_offset_of_m_CurrentCamera_11() { return static_cast<int32_t>(offsetof(PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96, ___m_CurrentCamera_11)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get_m_CurrentCamera_11() const { return ___m_CurrentCamera_11; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of_m_CurrentCamera_11() { return &___m_CurrentCamera_11; }
	inline void set_m_CurrentCamera_11(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		___m_CurrentCamera_11 = value;
		Il2CppCodeGenWriteBarrier((&___m_CurrentCamera_11), value);
	}

	inline static int32_t get_offset_of_m_CmdAfterEverything_12() { return static_cast<int32_t>(offsetof(PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96, ___m_CmdAfterEverything_12)); }
	inline CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * get_m_CmdAfterEverything_12() const { return ___m_CmdAfterEverything_12; }
	inline CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD ** get_address_of_m_CmdAfterEverything_12() { return &___m_CmdAfterEverything_12; }
	inline void set_m_CmdAfterEverything_12(CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * value)
	{
		___m_CmdAfterEverything_12 = value;
		Il2CppCodeGenWriteBarrier((&___m_CmdAfterEverything_12), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSDEBUG_TD6DF94623717DA10547ADB59376E6725E137AA96_H
#ifndef POSTPROCESSLAYER_T7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08_H
#define POSTPROCESSLAYER_T7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessLayer
struct  PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Transform UnityEngine.Rendering.PostProcessing.PostProcessLayer::volumeTrigger
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___volumeTrigger_4;
	// UnityEngine.LayerMask UnityEngine.Rendering.PostProcessing.PostProcessLayer::volumeLayer
	LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0  ___volumeLayer_5;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessLayer::stopNaNPropagation
	bool ___stopNaNPropagation_6;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessLayer::finalBlitToCameraTarget
	bool ___finalBlitToCameraTarget_7;
	// UnityEngine.Rendering.PostProcessing.PostProcessLayer_Antialiasing UnityEngine.Rendering.PostProcessing.PostProcessLayer::antialiasingMode
	int32_t ___antialiasingMode_8;
	// UnityEngine.Rendering.PostProcessing.TemporalAntialiasing UnityEngine.Rendering.PostProcessing.PostProcessLayer::temporalAntialiasing
	TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B * ___temporalAntialiasing_9;
	// UnityEngine.Rendering.PostProcessing.SubpixelMorphologicalAntialiasing UnityEngine.Rendering.PostProcessing.PostProcessLayer::subpixelMorphologicalAntialiasing
	SubpixelMorphologicalAntialiasing_t79DFA0E989BC5D03E07D5A9E5DFC9E7170B0CB3A * ___subpixelMorphologicalAntialiasing_10;
	// UnityEngine.Rendering.PostProcessing.FastApproximateAntialiasing UnityEngine.Rendering.PostProcessing.PostProcessLayer::fastApproximateAntialiasing
	FastApproximateAntialiasing_tDE38094B4113793694F81B6D782FA1D6F36768CD * ___fastApproximateAntialiasing_11;
	// UnityEngine.Rendering.PostProcessing.Fog UnityEngine.Rendering.PostProcessing.PostProcessLayer::fog
	Fog_tBCD51987A95009EBAB4ED7B98933E1B5A0A00196 * ___fog_12;
	// UnityEngine.Rendering.PostProcessing.Dithering UnityEngine.Rendering.PostProcessing.PostProcessLayer::dithering
	Dithering_t742ED682E1E94CAE24122F5E89ED166A97DCB547 * ___dithering_13;
	// UnityEngine.Rendering.PostProcessing.PostProcessDebugLayer UnityEngine.Rendering.PostProcessing.PostProcessLayer::debugLayer
	PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75 * ___debugLayer_14;
	// UnityEngine.Rendering.PostProcessing.PostProcessResources UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_Resources
	PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 * ___m_Resources_15;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_ShowToolkit
	bool ___m_ShowToolkit_16;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_ShowCustomSorter
	bool ___m_ShowCustomSorter_17;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessLayer::breakBeforeColorGrading
	bool ___breakBeforeColorGrading_18;
	// System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessLayer_SerializedBundleRef> UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_BeforeTransparentBundles
	List_1_tF416F8C7834DED71BB1CC8D74D1631D28ABC2A6B * ___m_BeforeTransparentBundles_19;
	// System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessLayer_SerializedBundleRef> UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_BeforeStackBundles
	List_1_tF416F8C7834DED71BB1CC8D74D1631D28ABC2A6B * ___m_BeforeStackBundles_20;
	// System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessLayer_SerializedBundleRef> UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_AfterStackBundles
	List_1_tF416F8C7834DED71BB1CC8D74D1631D28ABC2A6B * ___m_AfterStackBundles_21;
	// System.Collections.Generic.Dictionary`2<UnityEngine.Rendering.PostProcessing.PostProcessEvent,System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessLayer_SerializedBundleRef>> UnityEngine.Rendering.PostProcessing.PostProcessLayer::<sortedBundles>k__BackingField
	Dictionary_2_t735D27E8C6C69460DB345B1E0430D9E7DC2027EE * ___U3CsortedBundlesU3Ek__BackingField_22;
	// UnityEngine.DepthTextureMode UnityEngine.Rendering.PostProcessing.PostProcessLayer::<cameraDepthFlags>k__BackingField
	int32_t ___U3CcameraDepthFlagsU3Ek__BackingField_23;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessLayer::<haveBundlesBeenInited>k__BackingField
	bool ___U3ChaveBundlesBeenInitedU3Ek__BackingField_24;
	// System.Collections.Generic.Dictionary`2<System.Type,UnityEngine.Rendering.PostProcessing.PostProcessBundle> UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_Bundles
	Dictionary_2_t68B279040CF6AAD367F60332F7BF6E5D55E2CE4D * ___m_Bundles_25;
	// UnityEngine.Rendering.PostProcessing.PropertySheetFactory UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_PropertySheetFactory
	PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68 * ___m_PropertySheetFactory_26;
	// UnityEngine.Rendering.CommandBuffer UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_LegacyCmdBufferBeforeReflections
	CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * ___m_LegacyCmdBufferBeforeReflections_27;
	// UnityEngine.Rendering.CommandBuffer UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_LegacyCmdBufferBeforeLighting
	CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * ___m_LegacyCmdBufferBeforeLighting_28;
	// UnityEngine.Rendering.CommandBuffer UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_LegacyCmdBufferOpaque
	CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * ___m_LegacyCmdBufferOpaque_29;
	// UnityEngine.Rendering.CommandBuffer UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_LegacyCmdBuffer
	CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * ___m_LegacyCmdBuffer_30;
	// UnityEngine.Camera UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_Camera
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ___m_Camera_31;
	// UnityEngine.Rendering.PostProcessing.PostProcessRenderContext UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_CurrentContext
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18 * ___m_CurrentContext_32;
	// UnityEngine.Rendering.PostProcessing.LogHistogram UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_LogHistogram
	LogHistogram_t047FFE5627C5FCEF5FFB5DBCCAEC406DA7F07AB8 * ___m_LogHistogram_33;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_SettingsUpdateNeeded
	bool ___m_SettingsUpdateNeeded_34;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_IsRenderingInSceneView
	bool ___m_IsRenderingInSceneView_35;
	// UnityEngine.Rendering.PostProcessing.TargetPool UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_TargetPool
	TargetPool_t284FB269C2EF33308F1CFC69124C115985AEA7E4 * ___m_TargetPool_36;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_NaNKilled
	bool ___m_NaNKilled_37;
	// System.Collections.Generic.List`1<UnityEngine.Rendering.PostProcessing.PostProcessEffectRenderer> UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_ActiveEffects
	List_1_t8C4F4E7CB77FE645C18D117A237E828F791B429C * ___m_ActiveEffects_38;
	// System.Collections.Generic.List`1<UnityEngine.Rendering.RenderTargetIdentifier> UnityEngine.Rendering.PostProcessing.PostProcessLayer::m_Targets
	List_1_t1E97ED90DF19DF61851FF18897CC04F01185E918 * ___m_Targets_39;

public:
	inline static int32_t get_offset_of_volumeTrigger_4() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___volumeTrigger_4)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_volumeTrigger_4() const { return ___volumeTrigger_4; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_volumeTrigger_4() { return &___volumeTrigger_4; }
	inline void set_volumeTrigger_4(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___volumeTrigger_4 = value;
		Il2CppCodeGenWriteBarrier((&___volumeTrigger_4), value);
	}

	inline static int32_t get_offset_of_volumeLayer_5() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___volumeLayer_5)); }
	inline LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0  get_volumeLayer_5() const { return ___volumeLayer_5; }
	inline LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0 * get_address_of_volumeLayer_5() { return &___volumeLayer_5; }
	inline void set_volumeLayer_5(LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0  value)
	{
		___volumeLayer_5 = value;
	}

	inline static int32_t get_offset_of_stopNaNPropagation_6() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___stopNaNPropagation_6)); }
	inline bool get_stopNaNPropagation_6() const { return ___stopNaNPropagation_6; }
	inline bool* get_address_of_stopNaNPropagation_6() { return &___stopNaNPropagation_6; }
	inline void set_stopNaNPropagation_6(bool value)
	{
		___stopNaNPropagation_6 = value;
	}

	inline static int32_t get_offset_of_finalBlitToCameraTarget_7() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___finalBlitToCameraTarget_7)); }
	inline bool get_finalBlitToCameraTarget_7() const { return ___finalBlitToCameraTarget_7; }
	inline bool* get_address_of_finalBlitToCameraTarget_7() { return &___finalBlitToCameraTarget_7; }
	inline void set_finalBlitToCameraTarget_7(bool value)
	{
		___finalBlitToCameraTarget_7 = value;
	}

	inline static int32_t get_offset_of_antialiasingMode_8() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___antialiasingMode_8)); }
	inline int32_t get_antialiasingMode_8() const { return ___antialiasingMode_8; }
	inline int32_t* get_address_of_antialiasingMode_8() { return &___antialiasingMode_8; }
	inline void set_antialiasingMode_8(int32_t value)
	{
		___antialiasingMode_8 = value;
	}

	inline static int32_t get_offset_of_temporalAntialiasing_9() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___temporalAntialiasing_9)); }
	inline TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B * get_temporalAntialiasing_9() const { return ___temporalAntialiasing_9; }
	inline TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B ** get_address_of_temporalAntialiasing_9() { return &___temporalAntialiasing_9; }
	inline void set_temporalAntialiasing_9(TemporalAntialiasing_tD4267BD257770578FA6003198771D631995A322B * value)
	{
		___temporalAntialiasing_9 = value;
		Il2CppCodeGenWriteBarrier((&___temporalAntialiasing_9), value);
	}

	inline static int32_t get_offset_of_subpixelMorphologicalAntialiasing_10() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___subpixelMorphologicalAntialiasing_10)); }
	inline SubpixelMorphologicalAntialiasing_t79DFA0E989BC5D03E07D5A9E5DFC9E7170B0CB3A * get_subpixelMorphologicalAntialiasing_10() const { return ___subpixelMorphologicalAntialiasing_10; }
	inline SubpixelMorphologicalAntialiasing_t79DFA0E989BC5D03E07D5A9E5DFC9E7170B0CB3A ** get_address_of_subpixelMorphologicalAntialiasing_10() { return &___subpixelMorphologicalAntialiasing_10; }
	inline void set_subpixelMorphologicalAntialiasing_10(SubpixelMorphologicalAntialiasing_t79DFA0E989BC5D03E07D5A9E5DFC9E7170B0CB3A * value)
	{
		___subpixelMorphologicalAntialiasing_10 = value;
		Il2CppCodeGenWriteBarrier((&___subpixelMorphologicalAntialiasing_10), value);
	}

	inline static int32_t get_offset_of_fastApproximateAntialiasing_11() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___fastApproximateAntialiasing_11)); }
	inline FastApproximateAntialiasing_tDE38094B4113793694F81B6D782FA1D6F36768CD * get_fastApproximateAntialiasing_11() const { return ___fastApproximateAntialiasing_11; }
	inline FastApproximateAntialiasing_tDE38094B4113793694F81B6D782FA1D6F36768CD ** get_address_of_fastApproximateAntialiasing_11() { return &___fastApproximateAntialiasing_11; }
	inline void set_fastApproximateAntialiasing_11(FastApproximateAntialiasing_tDE38094B4113793694F81B6D782FA1D6F36768CD * value)
	{
		___fastApproximateAntialiasing_11 = value;
		Il2CppCodeGenWriteBarrier((&___fastApproximateAntialiasing_11), value);
	}

	inline static int32_t get_offset_of_fog_12() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___fog_12)); }
	inline Fog_tBCD51987A95009EBAB4ED7B98933E1B5A0A00196 * get_fog_12() const { return ___fog_12; }
	inline Fog_tBCD51987A95009EBAB4ED7B98933E1B5A0A00196 ** get_address_of_fog_12() { return &___fog_12; }
	inline void set_fog_12(Fog_tBCD51987A95009EBAB4ED7B98933E1B5A0A00196 * value)
	{
		___fog_12 = value;
		Il2CppCodeGenWriteBarrier((&___fog_12), value);
	}

	inline static int32_t get_offset_of_dithering_13() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___dithering_13)); }
	inline Dithering_t742ED682E1E94CAE24122F5E89ED166A97DCB547 * get_dithering_13() const { return ___dithering_13; }
	inline Dithering_t742ED682E1E94CAE24122F5E89ED166A97DCB547 ** get_address_of_dithering_13() { return &___dithering_13; }
	inline void set_dithering_13(Dithering_t742ED682E1E94CAE24122F5E89ED166A97DCB547 * value)
	{
		___dithering_13 = value;
		Il2CppCodeGenWriteBarrier((&___dithering_13), value);
	}

	inline static int32_t get_offset_of_debugLayer_14() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___debugLayer_14)); }
	inline PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75 * get_debugLayer_14() const { return ___debugLayer_14; }
	inline PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75 ** get_address_of_debugLayer_14() { return &___debugLayer_14; }
	inline void set_debugLayer_14(PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75 * value)
	{
		___debugLayer_14 = value;
		Il2CppCodeGenWriteBarrier((&___debugLayer_14), value);
	}

	inline static int32_t get_offset_of_m_Resources_15() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_Resources_15)); }
	inline PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 * get_m_Resources_15() const { return ___m_Resources_15; }
	inline PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 ** get_address_of_m_Resources_15() { return &___m_Resources_15; }
	inline void set_m_Resources_15(PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98 * value)
	{
		___m_Resources_15 = value;
		Il2CppCodeGenWriteBarrier((&___m_Resources_15), value);
	}

	inline static int32_t get_offset_of_m_ShowToolkit_16() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_ShowToolkit_16)); }
	inline bool get_m_ShowToolkit_16() const { return ___m_ShowToolkit_16; }
	inline bool* get_address_of_m_ShowToolkit_16() { return &___m_ShowToolkit_16; }
	inline void set_m_ShowToolkit_16(bool value)
	{
		___m_ShowToolkit_16 = value;
	}

	inline static int32_t get_offset_of_m_ShowCustomSorter_17() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_ShowCustomSorter_17)); }
	inline bool get_m_ShowCustomSorter_17() const { return ___m_ShowCustomSorter_17; }
	inline bool* get_address_of_m_ShowCustomSorter_17() { return &___m_ShowCustomSorter_17; }
	inline void set_m_ShowCustomSorter_17(bool value)
	{
		___m_ShowCustomSorter_17 = value;
	}

	inline static int32_t get_offset_of_breakBeforeColorGrading_18() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___breakBeforeColorGrading_18)); }
	inline bool get_breakBeforeColorGrading_18() const { return ___breakBeforeColorGrading_18; }
	inline bool* get_address_of_breakBeforeColorGrading_18() { return &___breakBeforeColorGrading_18; }
	inline void set_breakBeforeColorGrading_18(bool value)
	{
		___breakBeforeColorGrading_18 = value;
	}

	inline static int32_t get_offset_of_m_BeforeTransparentBundles_19() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_BeforeTransparentBundles_19)); }
	inline List_1_tF416F8C7834DED71BB1CC8D74D1631D28ABC2A6B * get_m_BeforeTransparentBundles_19() const { return ___m_BeforeTransparentBundles_19; }
	inline List_1_tF416F8C7834DED71BB1CC8D74D1631D28ABC2A6B ** get_address_of_m_BeforeTransparentBundles_19() { return &___m_BeforeTransparentBundles_19; }
	inline void set_m_BeforeTransparentBundles_19(List_1_tF416F8C7834DED71BB1CC8D74D1631D28ABC2A6B * value)
	{
		___m_BeforeTransparentBundles_19 = value;
		Il2CppCodeGenWriteBarrier((&___m_BeforeTransparentBundles_19), value);
	}

	inline static int32_t get_offset_of_m_BeforeStackBundles_20() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_BeforeStackBundles_20)); }
	inline List_1_tF416F8C7834DED71BB1CC8D74D1631D28ABC2A6B * get_m_BeforeStackBundles_20() const { return ___m_BeforeStackBundles_20; }
	inline List_1_tF416F8C7834DED71BB1CC8D74D1631D28ABC2A6B ** get_address_of_m_BeforeStackBundles_20() { return &___m_BeforeStackBundles_20; }
	inline void set_m_BeforeStackBundles_20(List_1_tF416F8C7834DED71BB1CC8D74D1631D28ABC2A6B * value)
	{
		___m_BeforeStackBundles_20 = value;
		Il2CppCodeGenWriteBarrier((&___m_BeforeStackBundles_20), value);
	}

	inline static int32_t get_offset_of_m_AfterStackBundles_21() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_AfterStackBundles_21)); }
	inline List_1_tF416F8C7834DED71BB1CC8D74D1631D28ABC2A6B * get_m_AfterStackBundles_21() const { return ___m_AfterStackBundles_21; }
	inline List_1_tF416F8C7834DED71BB1CC8D74D1631D28ABC2A6B ** get_address_of_m_AfterStackBundles_21() { return &___m_AfterStackBundles_21; }
	inline void set_m_AfterStackBundles_21(List_1_tF416F8C7834DED71BB1CC8D74D1631D28ABC2A6B * value)
	{
		___m_AfterStackBundles_21 = value;
		Il2CppCodeGenWriteBarrier((&___m_AfterStackBundles_21), value);
	}

	inline static int32_t get_offset_of_U3CsortedBundlesU3Ek__BackingField_22() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___U3CsortedBundlesU3Ek__BackingField_22)); }
	inline Dictionary_2_t735D27E8C6C69460DB345B1E0430D9E7DC2027EE * get_U3CsortedBundlesU3Ek__BackingField_22() const { return ___U3CsortedBundlesU3Ek__BackingField_22; }
	inline Dictionary_2_t735D27E8C6C69460DB345B1E0430D9E7DC2027EE ** get_address_of_U3CsortedBundlesU3Ek__BackingField_22() { return &___U3CsortedBundlesU3Ek__BackingField_22; }
	inline void set_U3CsortedBundlesU3Ek__BackingField_22(Dictionary_2_t735D27E8C6C69460DB345B1E0430D9E7DC2027EE * value)
	{
		___U3CsortedBundlesU3Ek__BackingField_22 = value;
		Il2CppCodeGenWriteBarrier((&___U3CsortedBundlesU3Ek__BackingField_22), value);
	}

	inline static int32_t get_offset_of_U3CcameraDepthFlagsU3Ek__BackingField_23() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___U3CcameraDepthFlagsU3Ek__BackingField_23)); }
	inline int32_t get_U3CcameraDepthFlagsU3Ek__BackingField_23() const { return ___U3CcameraDepthFlagsU3Ek__BackingField_23; }
	inline int32_t* get_address_of_U3CcameraDepthFlagsU3Ek__BackingField_23() { return &___U3CcameraDepthFlagsU3Ek__BackingField_23; }
	inline void set_U3CcameraDepthFlagsU3Ek__BackingField_23(int32_t value)
	{
		___U3CcameraDepthFlagsU3Ek__BackingField_23 = value;
	}

	inline static int32_t get_offset_of_U3ChaveBundlesBeenInitedU3Ek__BackingField_24() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___U3ChaveBundlesBeenInitedU3Ek__BackingField_24)); }
	inline bool get_U3ChaveBundlesBeenInitedU3Ek__BackingField_24() const { return ___U3ChaveBundlesBeenInitedU3Ek__BackingField_24; }
	inline bool* get_address_of_U3ChaveBundlesBeenInitedU3Ek__BackingField_24() { return &___U3ChaveBundlesBeenInitedU3Ek__BackingField_24; }
	inline void set_U3ChaveBundlesBeenInitedU3Ek__BackingField_24(bool value)
	{
		___U3ChaveBundlesBeenInitedU3Ek__BackingField_24 = value;
	}

	inline static int32_t get_offset_of_m_Bundles_25() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_Bundles_25)); }
	inline Dictionary_2_t68B279040CF6AAD367F60332F7BF6E5D55E2CE4D * get_m_Bundles_25() const { return ___m_Bundles_25; }
	inline Dictionary_2_t68B279040CF6AAD367F60332F7BF6E5D55E2CE4D ** get_address_of_m_Bundles_25() { return &___m_Bundles_25; }
	inline void set_m_Bundles_25(Dictionary_2_t68B279040CF6AAD367F60332F7BF6E5D55E2CE4D * value)
	{
		___m_Bundles_25 = value;
		Il2CppCodeGenWriteBarrier((&___m_Bundles_25), value);
	}

	inline static int32_t get_offset_of_m_PropertySheetFactory_26() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_PropertySheetFactory_26)); }
	inline PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68 * get_m_PropertySheetFactory_26() const { return ___m_PropertySheetFactory_26; }
	inline PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68 ** get_address_of_m_PropertySheetFactory_26() { return &___m_PropertySheetFactory_26; }
	inline void set_m_PropertySheetFactory_26(PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68 * value)
	{
		___m_PropertySheetFactory_26 = value;
		Il2CppCodeGenWriteBarrier((&___m_PropertySheetFactory_26), value);
	}

	inline static int32_t get_offset_of_m_LegacyCmdBufferBeforeReflections_27() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_LegacyCmdBufferBeforeReflections_27)); }
	inline CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * get_m_LegacyCmdBufferBeforeReflections_27() const { return ___m_LegacyCmdBufferBeforeReflections_27; }
	inline CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD ** get_address_of_m_LegacyCmdBufferBeforeReflections_27() { return &___m_LegacyCmdBufferBeforeReflections_27; }
	inline void set_m_LegacyCmdBufferBeforeReflections_27(CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * value)
	{
		___m_LegacyCmdBufferBeforeReflections_27 = value;
		Il2CppCodeGenWriteBarrier((&___m_LegacyCmdBufferBeforeReflections_27), value);
	}

	inline static int32_t get_offset_of_m_LegacyCmdBufferBeforeLighting_28() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_LegacyCmdBufferBeforeLighting_28)); }
	inline CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * get_m_LegacyCmdBufferBeforeLighting_28() const { return ___m_LegacyCmdBufferBeforeLighting_28; }
	inline CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD ** get_address_of_m_LegacyCmdBufferBeforeLighting_28() { return &___m_LegacyCmdBufferBeforeLighting_28; }
	inline void set_m_LegacyCmdBufferBeforeLighting_28(CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * value)
	{
		___m_LegacyCmdBufferBeforeLighting_28 = value;
		Il2CppCodeGenWriteBarrier((&___m_LegacyCmdBufferBeforeLighting_28), value);
	}

	inline static int32_t get_offset_of_m_LegacyCmdBufferOpaque_29() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_LegacyCmdBufferOpaque_29)); }
	inline CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * get_m_LegacyCmdBufferOpaque_29() const { return ___m_LegacyCmdBufferOpaque_29; }
	inline CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD ** get_address_of_m_LegacyCmdBufferOpaque_29() { return &___m_LegacyCmdBufferOpaque_29; }
	inline void set_m_LegacyCmdBufferOpaque_29(CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * value)
	{
		___m_LegacyCmdBufferOpaque_29 = value;
		Il2CppCodeGenWriteBarrier((&___m_LegacyCmdBufferOpaque_29), value);
	}

	inline static int32_t get_offset_of_m_LegacyCmdBuffer_30() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_LegacyCmdBuffer_30)); }
	inline CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * get_m_LegacyCmdBuffer_30() const { return ___m_LegacyCmdBuffer_30; }
	inline CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD ** get_address_of_m_LegacyCmdBuffer_30() { return &___m_LegacyCmdBuffer_30; }
	inline void set_m_LegacyCmdBuffer_30(CommandBuffer_t70BF7D9D84C2AFA83559B45FAD5BEDA73DA617DD * value)
	{
		___m_LegacyCmdBuffer_30 = value;
		Il2CppCodeGenWriteBarrier((&___m_LegacyCmdBuffer_30), value);
	}

	inline static int32_t get_offset_of_m_Camera_31() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_Camera_31)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get_m_Camera_31() const { return ___m_Camera_31; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of_m_Camera_31() { return &___m_Camera_31; }
	inline void set_m_Camera_31(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		___m_Camera_31 = value;
		Il2CppCodeGenWriteBarrier((&___m_Camera_31), value);
	}

	inline static int32_t get_offset_of_m_CurrentContext_32() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_CurrentContext_32)); }
	inline PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18 * get_m_CurrentContext_32() const { return ___m_CurrentContext_32; }
	inline PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18 ** get_address_of_m_CurrentContext_32() { return &___m_CurrentContext_32; }
	inline void set_m_CurrentContext_32(PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18 * value)
	{
		___m_CurrentContext_32 = value;
		Il2CppCodeGenWriteBarrier((&___m_CurrentContext_32), value);
	}

	inline static int32_t get_offset_of_m_LogHistogram_33() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_LogHistogram_33)); }
	inline LogHistogram_t047FFE5627C5FCEF5FFB5DBCCAEC406DA7F07AB8 * get_m_LogHistogram_33() const { return ___m_LogHistogram_33; }
	inline LogHistogram_t047FFE5627C5FCEF5FFB5DBCCAEC406DA7F07AB8 ** get_address_of_m_LogHistogram_33() { return &___m_LogHistogram_33; }
	inline void set_m_LogHistogram_33(LogHistogram_t047FFE5627C5FCEF5FFB5DBCCAEC406DA7F07AB8 * value)
	{
		___m_LogHistogram_33 = value;
		Il2CppCodeGenWriteBarrier((&___m_LogHistogram_33), value);
	}

	inline static int32_t get_offset_of_m_SettingsUpdateNeeded_34() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_SettingsUpdateNeeded_34)); }
	inline bool get_m_SettingsUpdateNeeded_34() const { return ___m_SettingsUpdateNeeded_34; }
	inline bool* get_address_of_m_SettingsUpdateNeeded_34() { return &___m_SettingsUpdateNeeded_34; }
	inline void set_m_SettingsUpdateNeeded_34(bool value)
	{
		___m_SettingsUpdateNeeded_34 = value;
	}

	inline static int32_t get_offset_of_m_IsRenderingInSceneView_35() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_IsRenderingInSceneView_35)); }
	inline bool get_m_IsRenderingInSceneView_35() const { return ___m_IsRenderingInSceneView_35; }
	inline bool* get_address_of_m_IsRenderingInSceneView_35() { return &___m_IsRenderingInSceneView_35; }
	inline void set_m_IsRenderingInSceneView_35(bool value)
	{
		___m_IsRenderingInSceneView_35 = value;
	}

	inline static int32_t get_offset_of_m_TargetPool_36() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_TargetPool_36)); }
	inline TargetPool_t284FB269C2EF33308F1CFC69124C115985AEA7E4 * get_m_TargetPool_36() const { return ___m_TargetPool_36; }
	inline TargetPool_t284FB269C2EF33308F1CFC69124C115985AEA7E4 ** get_address_of_m_TargetPool_36() { return &___m_TargetPool_36; }
	inline void set_m_TargetPool_36(TargetPool_t284FB269C2EF33308F1CFC69124C115985AEA7E4 * value)
	{
		___m_TargetPool_36 = value;
		Il2CppCodeGenWriteBarrier((&___m_TargetPool_36), value);
	}

	inline static int32_t get_offset_of_m_NaNKilled_37() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_NaNKilled_37)); }
	inline bool get_m_NaNKilled_37() const { return ___m_NaNKilled_37; }
	inline bool* get_address_of_m_NaNKilled_37() { return &___m_NaNKilled_37; }
	inline void set_m_NaNKilled_37(bool value)
	{
		___m_NaNKilled_37 = value;
	}

	inline static int32_t get_offset_of_m_ActiveEffects_38() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_ActiveEffects_38)); }
	inline List_1_t8C4F4E7CB77FE645C18D117A237E828F791B429C * get_m_ActiveEffects_38() const { return ___m_ActiveEffects_38; }
	inline List_1_t8C4F4E7CB77FE645C18D117A237E828F791B429C ** get_address_of_m_ActiveEffects_38() { return &___m_ActiveEffects_38; }
	inline void set_m_ActiveEffects_38(List_1_t8C4F4E7CB77FE645C18D117A237E828F791B429C * value)
	{
		___m_ActiveEffects_38 = value;
		Il2CppCodeGenWriteBarrier((&___m_ActiveEffects_38), value);
	}

	inline static int32_t get_offset_of_m_Targets_39() { return static_cast<int32_t>(offsetof(PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08, ___m_Targets_39)); }
	inline List_1_t1E97ED90DF19DF61851FF18897CC04F01185E918 * get_m_Targets_39() const { return ___m_Targets_39; }
	inline List_1_t1E97ED90DF19DF61851FF18897CC04F01185E918 ** get_address_of_m_Targets_39() { return &___m_Targets_39; }
	inline void set_m_Targets_39(List_1_t1E97ED90DF19DF61851FF18897CC04F01185E918 * value)
	{
		___m_Targets_39 = value;
		Il2CppCodeGenWriteBarrier((&___m_Targets_39), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSLAYER_T7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08_H
#ifndef POSTPROCESSVOLUME_TDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3_H
#define POSTPROCESSVOLUME_TDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Rendering.PostProcessing.PostProcessVolume
struct  PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Rendering.PostProcessing.PostProcessProfile UnityEngine.Rendering.PostProcessing.PostProcessVolume::sharedProfile
	PostProcessProfile_t8C94889A4E09E180663F26AB74D53B1E98D8C45F * ___sharedProfile_4;
	// System.Boolean UnityEngine.Rendering.PostProcessing.PostProcessVolume::isGlobal
	bool ___isGlobal_5;
	// System.Single UnityEngine.Rendering.PostProcessing.PostProcessVolume::blendDistance
	float ___blendDistance_6;
	// System.Single UnityEngine.Rendering.PostProcessing.PostProcessVolume::weight
	float ___weight_7;
	// System.Single UnityEngine.Rendering.PostProcessing.PostProcessVolume::priority
	float ___priority_8;
	// System.Int32 UnityEngine.Rendering.PostProcessing.PostProcessVolume::m_PreviousLayer
	int32_t ___m_PreviousLayer_9;
	// System.Single UnityEngine.Rendering.PostProcessing.PostProcessVolume::m_PreviousPriority
	float ___m_PreviousPriority_10;
	// System.Collections.Generic.List`1<UnityEngine.Collider> UnityEngine.Rendering.PostProcessing.PostProcessVolume::m_TempColliders
	List_1_t88DF1A02CCDD1766DB310B8D72B1F2145D775432 * ___m_TempColliders_11;
	// UnityEngine.Rendering.PostProcessing.PostProcessProfile UnityEngine.Rendering.PostProcessing.PostProcessVolume::m_InternalProfile
	PostProcessProfile_t8C94889A4E09E180663F26AB74D53B1E98D8C45F * ___m_InternalProfile_12;

public:
	inline static int32_t get_offset_of_sharedProfile_4() { return static_cast<int32_t>(offsetof(PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3, ___sharedProfile_4)); }
	inline PostProcessProfile_t8C94889A4E09E180663F26AB74D53B1E98D8C45F * get_sharedProfile_4() const { return ___sharedProfile_4; }
	inline PostProcessProfile_t8C94889A4E09E180663F26AB74D53B1E98D8C45F ** get_address_of_sharedProfile_4() { return &___sharedProfile_4; }
	inline void set_sharedProfile_4(PostProcessProfile_t8C94889A4E09E180663F26AB74D53B1E98D8C45F * value)
	{
		___sharedProfile_4 = value;
		Il2CppCodeGenWriteBarrier((&___sharedProfile_4), value);
	}

	inline static int32_t get_offset_of_isGlobal_5() { return static_cast<int32_t>(offsetof(PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3, ___isGlobal_5)); }
	inline bool get_isGlobal_5() const { return ___isGlobal_5; }
	inline bool* get_address_of_isGlobal_5() { return &___isGlobal_5; }
	inline void set_isGlobal_5(bool value)
	{
		___isGlobal_5 = value;
	}

	inline static int32_t get_offset_of_blendDistance_6() { return static_cast<int32_t>(offsetof(PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3, ___blendDistance_6)); }
	inline float get_blendDistance_6() const { return ___blendDistance_6; }
	inline float* get_address_of_blendDistance_6() { return &___blendDistance_6; }
	inline void set_blendDistance_6(float value)
	{
		___blendDistance_6 = value;
	}

	inline static int32_t get_offset_of_weight_7() { return static_cast<int32_t>(offsetof(PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3, ___weight_7)); }
	inline float get_weight_7() const { return ___weight_7; }
	inline float* get_address_of_weight_7() { return &___weight_7; }
	inline void set_weight_7(float value)
	{
		___weight_7 = value;
	}

	inline static int32_t get_offset_of_priority_8() { return static_cast<int32_t>(offsetof(PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3, ___priority_8)); }
	inline float get_priority_8() const { return ___priority_8; }
	inline float* get_address_of_priority_8() { return &___priority_8; }
	inline void set_priority_8(float value)
	{
		___priority_8 = value;
	}

	inline static int32_t get_offset_of_m_PreviousLayer_9() { return static_cast<int32_t>(offsetof(PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3, ___m_PreviousLayer_9)); }
	inline int32_t get_m_PreviousLayer_9() const { return ___m_PreviousLayer_9; }
	inline int32_t* get_address_of_m_PreviousLayer_9() { return &___m_PreviousLayer_9; }
	inline void set_m_PreviousLayer_9(int32_t value)
	{
		___m_PreviousLayer_9 = value;
	}

	inline static int32_t get_offset_of_m_PreviousPriority_10() { return static_cast<int32_t>(offsetof(PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3, ___m_PreviousPriority_10)); }
	inline float get_m_PreviousPriority_10() const { return ___m_PreviousPriority_10; }
	inline float* get_address_of_m_PreviousPriority_10() { return &___m_PreviousPriority_10; }
	inline void set_m_PreviousPriority_10(float value)
	{
		___m_PreviousPriority_10 = value;
	}

	inline static int32_t get_offset_of_m_TempColliders_11() { return static_cast<int32_t>(offsetof(PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3, ___m_TempColliders_11)); }
	inline List_1_t88DF1A02CCDD1766DB310B8D72B1F2145D775432 * get_m_TempColliders_11() const { return ___m_TempColliders_11; }
	inline List_1_t88DF1A02CCDD1766DB310B8D72B1F2145D775432 ** get_address_of_m_TempColliders_11() { return &___m_TempColliders_11; }
	inline void set_m_TempColliders_11(List_1_t88DF1A02CCDD1766DB310B8D72B1F2145D775432 * value)
	{
		___m_TempColliders_11 = value;
		Il2CppCodeGenWriteBarrier((&___m_TempColliders_11), value);
	}

	inline static int32_t get_offset_of_m_InternalProfile_12() { return static_cast<int32_t>(offsetof(PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3, ___m_InternalProfile_12)); }
	inline PostProcessProfile_t8C94889A4E09E180663F26AB74D53B1E98D8C45F * get_m_InternalProfile_12() const { return ___m_InternalProfile_12; }
	inline PostProcessProfile_t8C94889A4E09E180663F26AB74D53B1E98D8C45F ** get_address_of_m_InternalProfile_12() { return &___m_InternalProfile_12; }
	inline void set_m_InternalProfile_12(PostProcessProfile_t8C94889A4E09E180663F26AB74D53B1E98D8C45F * value)
	{
		___m_InternalProfile_12 = value;
		Il2CppCodeGenWriteBarrier((&___m_InternalProfile_12), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSVOLUME_TDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3_H





#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3600 = { sizeof (TextureParameterDefault_tC19C21E22B0FAAF2DC062C8383E59219360DA4FB)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3600[6] = 
{
	TextureParameterDefault_tC19C21E22B0FAAF2DC062C8383E59219360DA4FB::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3601 = { sizeof (TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3601[1] = 
{
	TextureParameter_tFB7692FD3A530A9AFE6E16A4DE84C92161698720::get_offset_of_defaultState_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3602 = { sizeof (PostProcessBundle_t73C3A7D8C55E7C976045DC08CF6FBD8F2AE3450F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3602[3] = 
{
	PostProcessBundle_t73C3A7D8C55E7C976045DC08CF6FBD8F2AE3450F::get_offset_of_U3CattributeU3Ek__BackingField_0(),
	PostProcessBundle_t73C3A7D8C55E7C976045DC08CF6FBD8F2AE3450F::get_offset_of_U3CsettingsU3Ek__BackingField_1(),
	PostProcessBundle_t73C3A7D8C55E7C976045DC08CF6FBD8F2AE3450F::get_offset_of_m_Renderer_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3603 = { sizeof (PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3603[9] = 
{
	PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96::get_offset_of_postProcessLayer_4(),
	PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96::get_offset_of_m_PreviousPostProcessLayer_5(),
	PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96::get_offset_of_lightMeter_6(),
	PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96::get_offset_of_histogram_7(),
	PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96::get_offset_of_waveform_8(),
	PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96::get_offset_of_vectorscope_9(),
	PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96::get_offset_of_debugOverlay_10(),
	PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96::get_offset_of_m_CurrentCamera_11(),
	PostProcessDebug_tD6DF94623717DA10547ADB59376E6725E137AA96::get_offset_of_m_CmdAfterEverything_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3604 = { sizeof (DebugOverlay_t74D1844AFC3A6FE3F324A07D4F140779D6F6E79C)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3604[12] = 
{
	DebugOverlay_t74D1844AFC3A6FE3F324A07D4F140779D6F6E79C::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3605 = { sizeof (ColorBlindnessType_t04F06730EA7A0D057F12E626AD2BD00B4BE473F9)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3605[4] = 
{
	ColorBlindnessType_t04F06730EA7A0D057F12E626AD2BD00B4BE473F9::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3606 = { sizeof (PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3606[11] = 
{
	PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75::get_offset_of_lightMeter_0(),
	PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75::get_offset_of_histogram_1(),
	PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75::get_offset_of_waveform_2(),
	PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75::get_offset_of_vectorscope_3(),
	PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75::get_offset_of_m_Monitors_4(),
	PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75::get_offset_of_frameWidth_5(),
	PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75::get_offset_of_frameHeight_6(),
	PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75::get_offset_of_U3CdebugOverlayTargetU3Ek__BackingField_7(),
	PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75::get_offset_of_U3CdebugOverlayActiveU3Ek__BackingField_8(),
	PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75::get_offset_of_U3CdebugOverlayU3Ek__BackingField_9(),
	PostProcessDebugLayer_tEA0F1C41B1ED38E6A451EBBCD7DBDA08CD75BD75::get_offset_of_overlaySettings_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3607 = { sizeof (OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3607[5] = 
{
	OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12::get_offset_of_linearDepth_0(),
	OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12::get_offset_of_motionColorIntensity_1(),
	OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12::get_offset_of_motionGridSize_2(),
	OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12::get_offset_of_colorBlindnessType_3(),
	OverlaySettings_tD34A529B9C063CED3074E5908BD4999FDF7C7F12::get_offset_of_colorBlindnessStrength_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3608 = { sizeof (PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3608[1] = 
{
	PostProcessEffectRenderer_t790CC94313AEB9B2CAF0A5C437ECA3235E9E2F4C::get_offset_of_m_ResetHistory_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3609 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable3609[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3610 = { sizeof (PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3610[3] = 
{
	PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E::get_offset_of_active_4(),
	PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E::get_offset_of_enabled_5(),
	PostProcessEffectSettings_t52802C256968EC72036018D471331281EC46E56E::get_offset_of_parameters_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3611 = { sizeof (U3CU3Ec_t7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259), -1, sizeof(U3CU3Ec_t7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3611[3] = 
{
	U3CU3Ec_t7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259_StaticFields::get_offset_of_U3CU3E9_0(),
	U3CU3Ec_t7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259_StaticFields::get_offset_of_U3CU3E9__3_0_1(),
	U3CU3Ec_t7F5E25EEA9C60BE36435EB95E5CBCE309A7E1259_StaticFields::get_offset_of_U3CU3E9__3_1_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3612 = { sizeof (PostProcessEvent_tB213B5070E972AC9A0D6983CF2686144655765D0)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3612[4] = 
{
	PostProcessEvent_tB213B5070E972AC9A0D6983CF2686144655765D0::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3613 = { sizeof (PostProcessEventComparer_t943CF37B2BE35AAB0807B330F79E75FF4359088F)+ sizeof (RuntimeObject), sizeof(PostProcessEventComparer_t943CF37B2BE35AAB0807B330F79E75FF4359088F ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3614 = { sizeof (PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3614[36] = 
{
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_volumeTrigger_4(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_volumeLayer_5(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_stopNaNPropagation_6(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_finalBlitToCameraTarget_7(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_antialiasingMode_8(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_temporalAntialiasing_9(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_subpixelMorphologicalAntialiasing_10(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_fastApproximateAntialiasing_11(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_fog_12(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_dithering_13(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_debugLayer_14(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_Resources_15(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_ShowToolkit_16(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_ShowCustomSorter_17(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_breakBeforeColorGrading_18(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_BeforeTransparentBundles_19(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_BeforeStackBundles_20(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_AfterStackBundles_21(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_U3CsortedBundlesU3Ek__BackingField_22(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_U3CcameraDepthFlagsU3Ek__BackingField_23(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_U3ChaveBundlesBeenInitedU3Ek__BackingField_24(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_Bundles_25(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_PropertySheetFactory_26(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_LegacyCmdBufferBeforeReflections_27(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_LegacyCmdBufferBeforeLighting_28(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_LegacyCmdBufferOpaque_29(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_LegacyCmdBuffer_30(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_Camera_31(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_CurrentContext_32(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_LogHistogram_33(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_SettingsUpdateNeeded_34(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_IsRenderingInSceneView_35(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_TargetPool_36(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_NaNKilled_37(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_ActiveEffects_38(),
	PostProcessLayer_t7F64D9904D7F3FACA164BDE6C4BDA1FD16F23E08::get_offset_of_m_Targets_39(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3615 = { sizeof (Antialiasing_tDAE4B0628ECF95DB3628B368E6E2BFA8B4E25CFC)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3615[5] = 
{
	Antialiasing_tDAE4B0628ECF95DB3628B368E6E2BFA8B4E25CFC::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3616 = { sizeof (SerializedBundleRef_t6EBF67645AD3B5BD0BEE52333F201406A72DAD4D), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3616[2] = 
{
	SerializedBundleRef_t6EBF67645AD3B5BD0BEE52333F201406A72DAD4D::get_offset_of_assemblyQualifiedName_0(),
	SerializedBundleRef_t6EBF67645AD3B5BD0BEE52333F201406A72DAD4D::get_offset_of_bundle_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3617 = { sizeof (U3CU3Ec__DisplayClass51_0_tA2801E966AB67197C58DAE39A9D974BEB417D698), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3617[2] = 
{
	U3CU3Ec__DisplayClass51_0_tA2801E966AB67197C58DAE39A9D974BEB417D698::get_offset_of_evt_0(),
	U3CU3Ec__DisplayClass51_0_tA2801E966AB67197C58DAE39A9D974BEB417D698::get_offset_of_effects_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3618 = { sizeof (U3CU3Ec__DisplayClass51_1_tDFC3417FA4C71D48EB9BB0B0E6BAE5833C5802E3), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3618[1] = 
{
	U3CU3Ec__DisplayClass51_1_tDFC3417FA4C71D48EB9BB0B0E6BAE5833C5802E3::get_offset_of_searchStr_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3619 = { sizeof (U3CU3Ec__DisplayClass51_2_t6A295F3472A366F5169B8AB8EC6EE16C4A92F7FB), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3619[1] = 
{
	U3CU3Ec__DisplayClass51_2_t6A295F3472A366F5169B8AB8EC6EE16C4A92F7FB::get_offset_of_typeName_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3620 = { sizeof (U3CU3Ec__DisplayClass51_3_t3226CA30517840AD21DEDB488DDEF96FC56504FA), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3620[1] = 
{
	U3CU3Ec__DisplayClass51_3_t3226CA30517840AD21DEDB488DDEF96FC56504FA::get_offset_of_typeName_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3621 = { sizeof (U3CU3Ec_t2977F22C91A261508C6D6D65BBDB8A5D4A504EEC), -1, sizeof(U3CU3Ec_t2977F22C91A261508C6D6D65BBDB8A5D4A504EEC_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3621[2] = 
{
	U3CU3Ec_t2977F22C91A261508C6D6D65BBDB8A5D4A504EEC_StaticFields::get_offset_of_U3CU3E9_0(),
	U3CU3Ec_t2977F22C91A261508C6D6D65BBDB8A5D4A504EEC_StaticFields::get_offset_of_U3CU3E9__51_1_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3622 = { sizeof (PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399), -1, sizeof(PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3622[8] = 
{
	PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399_StaticFields::get_offset_of_s_Instance_0(),
	0,
	PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399::get_offset_of_m_SortedVolumes_2(),
	PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399::get_offset_of_m_Volumes_3(),
	PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399::get_offset_of_m_SortNeeded_4(),
	PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399::get_offset_of_m_BaseSettings_5(),
	PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399::get_offset_of_m_TempColliders_6(),
	PostProcessManager_tFC810FE0B8D374295EA43955753CF7128E987399::get_offset_of_settingsTypes_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3623 = { sizeof (U3CU3Ec_tC99B445AA5A4C0EA4158842F9AD8C3A013A0503C), -1, sizeof(U3CU3Ec_tC99B445AA5A4C0EA4158842F9AD8C3A013A0503C_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3623[2] = 
{
	U3CU3Ec_tC99B445AA5A4C0EA4158842F9AD8C3A013A0503C_StaticFields::get_offset_of_U3CU3E9_0(),
	U3CU3Ec_tC99B445AA5A4C0EA4158842F9AD8C3A013A0503C_StaticFields::get_offset_of_U3CU3E9__12_0_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3624 = { sizeof (PostProcessProfile_t8C94889A4E09E180663F26AB74D53B1E98D8C45F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3624[2] = 
{
	PostProcessProfile_t8C94889A4E09E180663F26AB74D53B1E98D8C45F::get_offset_of_settings_4(),
	PostProcessProfile_t8C94889A4E09E180663F26AB74D53B1E98D8C45F::get_offset_of_isDirty_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3625 = { sizeof (U3CU3Ec_tC57F65B5DBD077E50FD91FE1F471440D65CE6818), -1, sizeof(U3CU3Ec_tC57F65B5DBD077E50FD91FE1F471440D65CE6818_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3625[2] = 
{
	U3CU3Ec_tC57F65B5DBD077E50FD91FE1F471440D65CE6818_StaticFields::get_offset_of_U3CU3E9_0(),
	U3CU3Ec_tC57F65B5DBD077E50FD91FE1F471440D65CE6818_StaticFields::get_offset_of_U3CU3E9__2_0_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3626 = { sizeof (PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3626[29] = 
{
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_m_Camera_0(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CcommandU3Ek__BackingField_1(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CsourceU3Ek__BackingField_2(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CdestinationU3Ek__BackingField_3(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CsourceFormatU3Ek__BackingField_4(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CflipU3Ek__BackingField_5(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CresourcesU3Ek__BackingField_6(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CpropertySheetsU3Ek__BackingField_7(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CuserDataU3Ek__BackingField_8(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CdebugLayerU3Ek__BackingField_9(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CwidthU3Ek__BackingField_10(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CheightU3Ek__BackingField_11(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CstereoActiveU3Ek__BackingField_12(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CxrActiveEyeU3Ek__BackingField_13(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CnumberOfEyesU3Ek__BackingField_14(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CstereoRenderingModeU3Ek__BackingField_15(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CscreenWidthU3Ek__BackingField_16(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CscreenHeightU3Ek__BackingField_17(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CisSceneViewU3Ek__BackingField_18(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CantialiasingU3Ek__BackingField_19(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_U3CtemporalAntialiasingU3Ek__BackingField_20(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_uberSheet_21(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_autoExposureTexture_22(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_logHistogram_23(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_logLut_24(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_autoExposure_25(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_bloomBufferNameID_26(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_physicalCamera_27(),
	PostProcessRenderContext_t601F1237B2FF9EFE88E3A15A0EFF801072474A18::get_offset_of_m_sourceDescriptor_28(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3627 = { sizeof (StereoRenderingMode_t0875357164ABD8348545BC304C58EF81F44C78F3)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable3627[5] = 
{
	StereoRenderingMode_t0875357164ABD8348545BC304C58EF81F44C78F3::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3628 = { sizeof (PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3628[5] = 
{
	PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98::get_offset_of_blueNoise64_4(),
	PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98::get_offset_of_blueNoise256_5(),
	PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98::get_offset_of_smaaLuts_6(),
	PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98::get_offset_of_shaders_7(),
	PostProcessResources_t63243B16DDFD1A240B4AA1F69A063C2996E38B98::get_offset_of_computeShaders_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3629 = { sizeof (Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3629[24] = 
{
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_bloom_0(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_copy_1(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_copyStd_2(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_copyStdFromTexArray_3(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_copyStdFromDoubleWide_4(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_discardAlpha_5(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_depthOfField_6(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_finalPass_7(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_grainBaker_8(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_motionBlur_9(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_temporalAntialiasing_10(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_subpixelMorphologicalAntialiasing_11(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_texture2dLerp_12(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_uber_13(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_lut2DBaker_14(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_lightMeter_15(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_gammaHistogram_16(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_waveform_17(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_vectorscope_18(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_debugOverlays_19(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_deferredFog_20(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_scalableAO_21(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_multiScaleAO_22(),
	Shaders_t15D6AD5C461051D7B09E20AEBE06E168CD133510::get_offset_of_screenSpaceReflections_23(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3630 = { sizeof (ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3630[12] = 
{
	ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2::get_offset_of_autoExposure_0(),
	ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2::get_offset_of_exposureHistogram_1(),
	ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2::get_offset_of_lut3DBaker_2(),
	ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2::get_offset_of_texture3dLerp_3(),
	ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2::get_offset_of_gammaHistogram_4(),
	ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2::get_offset_of_waveform_5(),
	ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2::get_offset_of_vectorscope_6(),
	ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2::get_offset_of_multiScaleAODownsample1_7(),
	ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2::get_offset_of_multiScaleAODownsample2_8(),
	ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2::get_offset_of_multiScaleAORender_9(),
	ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2::get_offset_of_multiScaleAOUpsample_10(),
	ComputeShaders_t1889552AF93D82A2D22F9779BC3BC8B133299EE2::get_offset_of_gaussianDownsample_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3631 = { sizeof (SMAALuts_t4E0EB2F1BAD60C948B7153C88F485EE928445519), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3631[2] = 
{
	SMAALuts_t4E0EB2F1BAD60C948B7153C88F485EE928445519::get_offset_of_area_0(),
	SMAALuts_t4E0EB2F1BAD60C948B7153C88F485EE928445519::get_offset_of_search_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3632 = { sizeof (PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3632[9] = 
{
	PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3::get_offset_of_sharedProfile_4(),
	PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3::get_offset_of_isGlobal_5(),
	PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3::get_offset_of_blendDistance_6(),
	PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3::get_offset_of_weight_7(),
	PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3::get_offset_of_priority_8(),
	PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3::get_offset_of_m_PreviousLayer_9(),
	PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3::get_offset_of_m_PreviousPriority_10(),
	PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3::get_offset_of_m_TempColliders_11(),
	PostProcessVolume_tDAC3328E4F7CD84FAE50C7D56DF73E5340DC35C3::get_offset_of_m_InternalProfile_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3633 = { sizeof (ColorUtilities_tF84C1711080D0558866FCCF002017078DBD20F8C), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3633[7] = 
{
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3634 = { sizeof (HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3634[6] = 
{
	HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78::get_offset_of_U3CwhitePointU3Ek__BackingField_0(),
	HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78::get_offset_of_U3CinverseWhitePointU3Ek__BackingField_1(),
	HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78::get_offset_of_U3Cx0U3Ek__BackingField_2(),
	HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78::get_offset_of_U3Cx1U3Ek__BackingField_3(),
	HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78::get_offset_of_m_Segments_4(),
	HableCurve_tB007C0ED54E49D4837CAE21029C1C6663461AC78::get_offset_of_uniforms_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3635 = { sizeof (Segment_t1B591F583A7B52D1BC04C0669068E1D19E592065), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3635[6] = 
{
	Segment_t1B591F583A7B52D1BC04C0669068E1D19E592065::get_offset_of_offsetX_0(),
	Segment_t1B591F583A7B52D1BC04C0669068E1D19E592065::get_offset_of_offsetY_1(),
	Segment_t1B591F583A7B52D1BC04C0669068E1D19E592065::get_offset_of_scaleX_2(),
	Segment_t1B591F583A7B52D1BC04C0669068E1D19E592065::get_offset_of_scaleY_3(),
	Segment_t1B591F583A7B52D1BC04C0669068E1D19E592065::get_offset_of_lnA_4(),
	Segment_t1B591F583A7B52D1BC04C0669068E1D19E592065::get_offset_of_B_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3636 = { sizeof (DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28)+ sizeof (RuntimeObject), sizeof(DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28 ), 0, 0 };
extern const int32_t g_FieldOffsetTable3636[8] = 
{
	DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28::get_offset_of_x0_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28::get_offset_of_y0_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28::get_offset_of_x1_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28::get_offset_of_y1_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
	DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28::get_offset_of_W_4() + static_cast<int32_t>(sizeof(RuntimeObject)),
	DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28::get_offset_of_overshootX_5() + static_cast<int32_t>(sizeof(RuntimeObject)),
	DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28::get_offset_of_overshootY_6() + static_cast<int32_t>(sizeof(RuntimeObject)),
	DirectParams_t51DA8B018065DC940CFA6E3920C8E686F422FE28::get_offset_of_gamma_7() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3637 = { sizeof (Uniforms_t6CD449DACCAE348F7E606DBACF2481FA9BCDF2AF), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3637[1] = 
{
	Uniforms_t6CD449DACCAE348F7E606DBACF2481FA9BCDF2AF::get_offset_of_parent_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3638 = { sizeof (HaltonSeq_tEC1E3058C08C10B5FA48B5084B2FCFA4135C7682), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3639 = { sizeof (LogHistogram_t047FFE5627C5FCEF5FFB5DBCCAEC406DA7F07AB8), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3639[4] = 
{
	0,
	0,
	0,
	LogHistogram_t047FFE5627C5FCEF5FFB5DBCCAEC406DA7F07AB8::get_offset_of_U3CdataU3Ek__BackingField_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3640 = { sizeof (MeshUtilities_t1789BBBAF048DEB18CBADF1446C7367C805C6127), -1, sizeof(MeshUtilities_t1789BBBAF048DEB18CBADF1446C7367C805C6127_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3640[2] = 
{
	MeshUtilities_t1789BBBAF048DEB18CBADF1446C7367C805C6127_StaticFields::get_offset_of_s_Primitives_0(),
	MeshUtilities_t1789BBBAF048DEB18CBADF1446C7367C805C6127_StaticFields::get_offset_of_s_ColliderPrimitives_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3641 = { sizeof (PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3641[2] = 
{
	PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212::get_offset_of_U3CpropertiesU3Ek__BackingField_0(),
	PropertySheet_t24C92FDC502E601797E65D23B427D05B15840212::get_offset_of_U3CmaterialU3Ek__BackingField_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3642 = { sizeof (PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3642[1] = 
{
	PropertySheetFactory_t50203E3FC9B139F932F1F4A135A9C64D954B2F68::get_offset_of_m_Sheets_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3643 = { sizeof (RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63), -1, sizeof(RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3643[16] = 
{
	RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields::get_offset_of_m_WhiteTexture_0(),
	RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields::get_offset_of_m_WhiteTexture3D_1(),
	RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields::get_offset_of_m_BlackTexture_2(),
	RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields::get_offset_of_m_BlackTexture3D_3(),
	RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields::get_offset_of_m_TransparentTexture_4(),
	RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields::get_offset_of_m_TransparentTexture3D_5(),
	RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields::get_offset_of_m_LutStrips_6(),
	RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields::get_offset_of_s_Resources_7(),
	RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields::get_offset_of_s_FullscreenTriangle_8(),
	RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields::get_offset_of_s_CopyStdMaterial_9(),
	RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields::get_offset_of_s_CopyStdFromDoubleWideMaterial_10(),
	RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields::get_offset_of_s_CopyMaterial_11(),
	RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields::get_offset_of_s_CopyFromTexArrayMaterial_12(),
	RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields::get_offset_of_s_CopySheet_13(),
	RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields::get_offset_of_s_CopyFromTexArraySheet_14(),
	RuntimeUtilities_t9998328C3C1997217B0442B08ABE0A0122481C63_StaticFields::get_offset_of_m_AssemblyTypes_15(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3644 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable3644[7] = 
{
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3645 = { sizeof (U3CU3Ec_t44F15B9D7FCBEA92C1FA19C255E68AB99C127FD8), -1, sizeof(U3CU3Ec_t44F15B9D7FCBEA92C1FA19C255E68AB99C127FD8_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3645[2] = 
{
	U3CU3Ec_t44F15B9D7FCBEA92C1FA19C255E68AB99C127FD8_StaticFields::get_offset_of_U3CU3E9_0(),
	U3CU3Ec_t44F15B9D7FCBEA92C1FA19C255E68AB99C127FD8_StaticFields::get_offset_of_U3CU3E9__87_0_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3646 = { sizeof (ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22), -1, sizeof(ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3646[130] = 
{
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_MainTex_0(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Jitter_1(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Sharpness_2(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_FinalBlendParameters_3(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_HistoryTex_4(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_SMAA_Flip_5(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_SMAA_Flop_6(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_AOParams_7(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_AOColor_8(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_OcclusionTexture1_9(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_OcclusionTexture2_10(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_SAOcclusionTexture_11(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_MSVOcclusionTexture_12(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_DepthCopy_13(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_LinearDepth_14(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_LowDepth1_15(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_LowDepth2_16(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_LowDepth3_17(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_LowDepth4_18(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_TiledDepth1_19(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_TiledDepth2_20(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_TiledDepth3_21(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_TiledDepth4_22(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Occlusion1_23(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Occlusion2_24(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Occlusion3_25(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Occlusion4_26(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Combined1_27(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Combined2_28(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Combined3_29(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_SSRResolveTemp_30(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Noise_31(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Test_32(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Resolve_33(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_History_34(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_ViewMatrix_35(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_InverseViewMatrix_36(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_InverseProjectionMatrix_37(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_ScreenSpaceProjectionMatrix_38(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Params2_39(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_FogColor_40(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_FogParams_41(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_VelocityScale_42(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_MaxBlurRadius_43(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_RcpMaxBlurRadius_44(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_VelocityTex_45(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Tile2RT_46(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Tile4RT_47(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Tile8RT_48(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_TileMaxOffs_49(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_TileMaxLoop_50(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_TileVRT_51(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_NeighborMaxTex_52(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_LoopCount_53(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_DepthOfFieldTemp_54(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_DepthOfFieldTex_55(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Distance_56(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_LensCoeff_57(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_MaxCoC_58(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_RcpMaxCoC_59(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_RcpAspect_60(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_CoCTex_61(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_TaaParams_62(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_AutoExposureTex_63(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_HistogramBuffer_64(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Params_65(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_ScaleOffsetRes_66(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_BloomTex_67(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_SampleScale_68(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Threshold_69(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_ColorIntensity_70(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Bloom_DirtTex_71(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Bloom_Settings_72(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Bloom_Color_73(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Bloom_DirtTileOffset_74(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_ChromaticAberration_Amount_75(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_ChromaticAberration_SpectralLut_76(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Distortion_CenterScale_77(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Distortion_Amount_78(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Lut2D_79(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Lut3D_80(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Lut3D_Params_81(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Lut2D_Params_82(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_UserLut2D_Params_83(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_PostExposure_84(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_ColorBalance_85(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_ColorFilter_86(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_HueSatCon_87(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Brightness_88(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_ChannelMixerRed_89(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_ChannelMixerGreen_90(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_ChannelMixerBlue_91(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Lift_92(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_InvGamma_93(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Gain_94(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Curves_95(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_CustomToneCurve_96(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_ToeSegmentA_97(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_ToeSegmentB_98(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_MidSegmentA_99(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_MidSegmentB_100(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_ShoSegmentA_101(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_ShoSegmentB_102(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Vignette_Color_103(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Vignette_Center_104(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Vignette_Settings_105(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Vignette_Mask_106(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Vignette_Opacity_107(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Vignette_Mode_108(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Grain_Params1_109(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Grain_Params2_110(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_GrainTex_111(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Phase_112(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_GrainNoiseParameters_113(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_LumaInAlpha_114(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_DitheringTex_115(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Dithering_Coords_116(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_From_117(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_To_118(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_Interp_119(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_TargetColor_120(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_HalfResFinalCopy_121(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_WaveformSource_122(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_WaveformBuffer_123(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_VectorscopeBuffer_124(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_RenderViewportScaleFactor_125(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_UVTransform_126(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_DepthSlice_127(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_UVScaleOffset_128(),
	ShaderIDs_t50801F2461934475540F10C0595A9C3AF7459A22_StaticFields::get_offset_of_PosScaleOffset_129(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3647 = { sizeof (Spline_tE37069226E0B86697627CCEA38297277E55030CD), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3647[9] = 
{
	0,
	0,
	Spline_tE37069226E0B86697627CCEA38297277E55030CD::get_offset_of_curve_2(),
	Spline_tE37069226E0B86697627CCEA38297277E55030CD::get_offset_of_m_Loop_3(),
	Spline_tE37069226E0B86697627CCEA38297277E55030CD::get_offset_of_m_ZeroValue_4(),
	Spline_tE37069226E0B86697627CCEA38297277E55030CD::get_offset_of_m_Range_5(),
	Spline_tE37069226E0B86697627CCEA38297277E55030CD::get_offset_of_m_InternalLoopingCurve_6(),
	Spline_tE37069226E0B86697627CCEA38297277E55030CD::get_offset_of_frameCount_7(),
	Spline_tE37069226E0B86697627CCEA38297277E55030CD::get_offset_of_cachedData_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3648 = { sizeof (TargetPool_t284FB269C2EF33308F1CFC69124C115985AEA7E4), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable3648[2] = 
{
	TargetPool_t284FB269C2EF33308F1CFC69124C115985AEA7E4::get_offset_of_m_Pool_0(),
	TargetPool_t284FB269C2EF33308F1CFC69124C115985AEA7E4::get_offset_of_m_Current_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3649 = { sizeof (TextureFormatUtilities_t1051A2979F6D9A38B36D87CDDDED9CAFC7DC4B97), -1, sizeof(TextureFormatUtilities_t1051A2979F6D9A38B36D87CDDDED9CAFC7DC4B97_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3649[3] = 
{
	TextureFormatUtilities_t1051A2979F6D9A38B36D87CDDDED9CAFC7DC4B97_StaticFields::get_offset_of_s_FormatAliasMap_0(),
	TextureFormatUtilities_t1051A2979F6D9A38B36D87CDDDED9CAFC7DC4B97_StaticFields::get_offset_of_s_SupportedRenderTextureFormats_1(),
	TextureFormatUtilities_t1051A2979F6D9A38B36D87CDDDED9CAFC7DC4B97_StaticFields::get_offset_of_s_SupportedTextureFormats_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3650 = { sizeof (TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A), -1, sizeof(TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3650[6] = 
{
	TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A_StaticFields::get_offset_of_m_Instance_0(),
	TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A::get_offset_of_m_Command_1(),
	TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A::get_offset_of_m_PropertySheets_2(),
	TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A::get_offset_of_m_Resources_3(),
	TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A::get_offset_of_m_Recycled_4(),
	TextureLerper_tC341FEDCAFD8DE7C0F9B0B492FD18969B499F46A::get_offset_of_m_Actives_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3651 = { sizeof (U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A), -1, sizeof(U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable3651[1] = 
{
	U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_StaticFields::get_offset_of_U30ED907628EE272F93737B500A23D77C9B1C88368_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3652 = { sizeof (__StaticArrayInitTypeSizeU3D20_tD65589242911778C66D1E5AC9009597568746382)+ sizeof (RuntimeObject), sizeof(__StaticArrayInitTypeSizeU3D20_tD65589242911778C66D1E5AC9009597568746382 ), 0, 0 };
#ifdef __clang__
#pragma clang diagnostic pop
#endif
